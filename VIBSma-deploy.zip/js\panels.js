'use strict';
/* VIBSma — side panels: pages, layers, assets, design properties, code (inspect) */
(function () {
  const O = window.O, M = O.M, G = O.G, R = O.R, model = O.model, S = O.state, V = O.view;
  const esc = O.esc, fmt = O.fmt;
  const t = (s, v) => O.t(s, v);
  const tc = s => /[Ѐ-ӿ]/.test(s) ? O.t(s) : s; // translate only Ukrainian keys, keep brand names
  const panels = O.panels = {};
  const expanded = new Set();
  let renaming = false;

  // ---------- helpers ----------
  const iconFor = n => {
    switch (n.type) {
      case 'frame': return n.component ? 'component' : (n.layout ? 'autolayout' : 'frame');
      case 'instance': return 'instance';
      case 'raster': return 'image';
      case 'group': return n.mask ? 'mask' : 'group';
      case 'bool': return { union: 'union', subtract: 'subtract', intersect: 'intersect', exclude: 'exclude' }[n.op] || 'bool';
      case 'text': return n.path ? 'textpath' : 'text';
      case 'rect': return (n.fills || []).some(f => f.type === 'image') ? 'image' : 'rect';
      case 'path': return n.subpaths.length === 1 && n.subpaths[0].pts.length === 2 && !n.subpaths[0].closed ? 'line' : 'path';
      default: return n.type;
    }
  };
  const evalNum = s => {
    s = String(s).replace(',', '.').trim();
    if (/^[-+]?\d*\.?\d+(e[-+]?\d+)?$/i.test(s)) return parseFloat(s);
    if (/^[\d+\-*/().\s]+$/.test(s)) { try { const v = Function('"use strict";return (' + s + ')')(); return isFinite(v) ? v : NaN; } catch (e) { return NaN; } }
    return NaN;
  };
  const frameSpace = n => {
    const anc = model.ancestors(n).find(a => a.type === 'frame');
    return anc ? model.worldMatrix(anc) : M.id();
  };
  const refPos = n => {
    const lb = model.localBounds(n);
    const F = frameSpace(n);
    return M.apply(M.inv(F), M.apply(model.worldMatrix(n), { x: lb.x, y: lb.y }));
  };
  const relRot = n => {
    let r = -O.deg(M.decompose(M.mul(M.inv(frameSpace(n)), model.worldMatrix(n))).rot);
    r = ((r % 360) + 540) % 360 - 180;
    return Math.abs(r) < 1e-6 ? 0 : (Math.abs(r + 180) < 1e-6 ? 180 : r);
  };
  const dispSize = n => {
    const lb = model.localBounds(n), d = M.decompose(n.m);
    return { w: lb.w * Math.abs(d.sx), h: lb.h * Math.abs(d.sy) };
  };
  const BLENDS = [['normal', 'Звичайний'], ['darken', 'Затемнення'], ['multiply', 'Множення'], ['color-burn', 'Затемнення основи'], ['lighten', 'Освітлення'], ['screen', 'Екран'], ['color-dodge', 'Освітлення основи'], ['overlay', 'Перекриття'], ['soft-light', 'М’яке світло'], ['hard-light', 'Жорстке світло'], ['difference', 'Різниця'], ['exclusion', 'Виключення'], ['hue', 'Тон'], ['saturation', 'Насиченість'], ['color', 'Колір'], ['luminosity', 'Яскравість']];
  const FX = [['shadow', 'Тінь'], ['inner', 'Внутрішня тінь'], ['glow', 'Зовнішнє світіння'], ['innerglow', 'Внутрішнє світіння'], ['blur', 'Розмиття шару'], ['glass', 'Liquid Glass']];
  const MARK = [['none', 'Немає'], ['arrow', 'Стрілка'], ['triangle', 'Трикутник'], ['circle', 'Коло'], ['square', 'Квадрат'], ['diamond', 'Ромб'], ['bar', 'Риска']];
  const WEIGHTS = [[100, 'Thin'], [200, 'Extra Light'], [300, 'Light'], [400, 'Regular'], [500, 'Medium'], [600, 'Semi Bold'], [700, 'Bold'], [800, 'Extra Bold'], [900, 'Black']];
  const FONTS = ['Arial', 'Helvetica', 'Segoe UI', 'Roboto', 'Inter', 'Verdana', 'Tahoma', 'Trebuchet MS', 'Georgia', 'Times New Roman', 'Palatino Linotype', 'Garamond', 'Courier New', 'Consolas', 'Impact', 'Comic Sans MS', 'Calibri', 'Cambria', 'serif', 'sans-serif', 'monospace'];
  const OPS = { union: 'Об’єднання', subtract: 'Віднімання', intersect: 'Перетин', exclude: 'Виключення' };
  const EXPORT_FMTS = [['png', 'PNG'], ['jpg', 'JPG'], ['webp', 'WEBP'], ['svg', 'SVG'], ['pdf', 'PDF']];
  const EXPORT_SCALES = [[0.5, '0.5×'], [1, '1×'], [2, '2×'], [3, '3×'], [4, '4×']];
  O.FRAME_PRESETS = [
    ['Телефон', [['iPhone 16', 393, 852], ['iPhone 16 Pro Max', 440, 956], ['iPhone SE', 375, 667], ['Android', 412, 917], ['Android (малий)', 360, 800]]],
    ['Планшет', [['iPad mini', 744, 1133], ['iPad Pro 11"', 834, 1194], ['Surface Pro', 1440, 960]]],
    ['Комп’ютер', [['Desktop', 1440, 1024], ['MacBook Air', 1280, 832], ['Full HD', 1920, 1080], ['Мінімальний', 1024, 768]]],
    ['Друк', [['A4', 595, 842], ['A3', 842, 1191], ['A5', 420, 595], ['Letter', 612, 792], ['Візитка 90×50 мм', 255, 142]]],
    ['Соцмережі', [['Instagram пост', 1080, 1350], ['Instagram квадрат', 1080, 1080], ['Story / Reels', 1080, 1920], ['Facebook обкладинка', 1640, 624], ['YouTube прев’ю', 1280, 720], ['X пост', 1600, 900]]],
    ['Презентація', [['Слайд 16:9', 1920, 1080], ['Слайд 4:3', 1024, 768]]]
  ];
  const sel = () => O.topSel();

  // ======================================================================
  // LEFT: pages + layers
  // ======================================================================
  // several pages can be selected at once (Ctrl/Shift+click) for batch duplicate / delete / export
  const pageSel = O.pageSel = new Set();
  panels.renderPages = () => {
    const el = O.$('#pages-list');
    if (!el || renaming) return;
    for (const id of Array.from(pageSel)) if (!S.doc.pages.some(p => p.id === id)) pageSel.delete(id);
    const multi = pageSel.size > 1;
    el.innerHTML = S.doc.pages.map(p => `<div class="pg-row${p.id === S.pageId ? ' on' : ''}${multi && pageSel.has(p.id) ? ' sel' : ''}" data-pg="${p.id}" role="option" aria-selected="${pageSel.has(p.id) || p.id === S.pageId}" tabindex="0" draggable="true">${O.icon('page', 14)}<span class="pg-name">${esc(p.name)}</span>${p.id === S.pageId ? O.icon('check', 14, 'pg-chk') : ''}</div>`).join('');
  };
  panels.selectedPages = () => {
    const ids = pageSel.size ? S.doc.pages.filter(p => pageSel.has(p.id)).map(p => p.id) : [];
    return ids.length ? ids : [S.pageId];
  };
  const switchPage = id => {
    if (id === S.pageId) return;
    if (S.textEdit) O.textEdit.end(true);
    S.pageId = id; S.sel = []; S.edit = null;
    O.emit('page');
  };
  const pagesDuplicate = ids => {
    let last = null;
    for (const id of ids) {
      const pg = S.doc.pages.find(p => p.id === id);
      if (!pg) continue;
      const c = O.clone(pg);
      c.id = O.uid(); c.name = pg.name + ' (' + t('копія') + ')';
      const re = x => { x.id = O.uid(); (x.children || []).forEach(re); };
      c.children.forEach(re);
      S.doc.pages.splice(S.doc.pages.indexOf(pg) + 1, 0, c);
      last = c;
    }
    if (!last) return;
    pageSel.clear();
    S.pageId = last.id; S.sel = [];
    model.reindex(); O.history.commit('Дублювання сторінки'); O.emit('page');
  };
  const pagesDelete = ids => {
    const keep = S.doc.pages.filter(p => !ids.includes(p.id));
    if (!keep.length) { O.toast('Потрібна хоча б одна сторінка'); return; }
    S.doc.pages = keep;
    if (!keep.some(p => p.id === S.pageId)) S.pageId = keep[0].id;
    pageSel.clear(); S.sel = [];
    model.reindex(); O.history.commit('Видалення сторінки'); O.emit('page');
  };
  panels.renderLayers = () => {
    const list = O.$('#layers-list');
    if (!list || renaming) return;
    const pg = model.page();
    for (const n of O.sel()) model.ancestors(n).forEach(a => expanded.add(a.id));
    const selSet = new Set(S.sel);
    const L = { expand: esc(t('Розгорнути')), lock: esc(t('Заблокувати')), unlock: esc(t('Розблокувати')), hide: esc(t('Приховати')), show: esc(t('Показати')) };
    let html = '';
    const row = (n, depth, parentSel, maskChild) => {
      const isC = !!n.children;
      const open = expanded.has(n.id);
      const isSel = selSet.has(n.id);
      const icon = maskChild ? 'mask' : iconFor(n);
      const comp = n.component || n.type === 'instance';
      html += `<div class="ly${isSel ? ' sel' : ''}${parentSel ? ' psel' : ''}${n.visible === false ? ' hid' : ''}${n.locked ? ' lck' : ''}${comp ? ' comp' : ''}" data-id="${n.id}" draggable="true" style="--d:${depth}" role="treeitem" aria-selected="${isSel}"${isC ? ` aria-expanded="${open}"` : ''}>
        <button type="button" class="ly-car${isC && n.children.length ? '' : ' none'}" data-a="toggle" tabindex="-1" aria-label="${L.expand}">${isC && n.children.length ? O.icon(open ? 'chevdown' : 'chevright', 12) : ''}</button>
        <span class="ly-ic">${O.icon(icon, 14)}</span><span class="ly-name">${esc(n.name)}</span>
        <button type="button" class="ly-b${n.locked ? ' on' : ''}" data-a="lock" tabindex="-1" aria-label="${n.locked ? L.unlock : L.lock}">${O.icon(n.locked ? 'lock' : 'unlock', 13)}</button>
        <button type="button" class="ly-b${n.visible === false ? ' on' : ''}" data-a="eye" tabindex="-1" aria-label="${n.visible === false ? L.show : L.hide}">${O.icon(n.visible === false ? 'eyeoff' : 'eye', 13)}</button></div>`;
      if (isC && open) for (let i = n.children.length - 1; i >= 0; i--) row(n.children[i], depth + 1, parentSel || isSel, n.mask && i === 0);
    };
    for (let i = pg.children.length - 1; i >= 0; i--) row(pg.children[i], 0, false, false);
    const st = list.scrollTop;
    list.innerHTML = html || `<div class="ly-empty">${esc(t('Сторінка порожня.'))}<br>${esc(t('Оберіть інструмент на панелі знизу й малюйте на полотні, або перетягніть сюди зображення чи SVG.'))}</div>`;
    list.scrollTop = st;
    const first = list.querySelector('.ly.sel');
    if (first && panels._scrollToSel) { first.scrollIntoView({ block: 'nearest' }); panels._scrollToSel = false; }
  };
  const startRename = (span, initial, done) => {
    renaming = true;
    const inp = document.createElement('input');
    inp.className = 'rename'; inp.value = initial;
    span.replaceWith(inp);
    inp.focus(); inp.select();
    let finished = false;
    const finish = ok => {
      if (finished) return; finished = true;
      renaming = false;
      if (ok && inp.value.trim()) done(inp.value.trim());
      O.emit('change');
    };
    inp.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') finish(true); if (e.key === 'Escape') finish(false); });
    inp.addEventListener('blur', () => finish(true));
  };
  panels.initLeft = () => {
    const tabs = O.$('#left .ptabs');
    tabs.addEventListener('click', e => {
      const b = e.target.closest('[data-lt]');
      if (!b) return;
      tabs.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
      O.$('#lp-layers').hidden = b.dataset.lt !== 'layers';
      O.$('#lp-assets').hidden = b.dataset.lt !== 'assets';
      if (b.dataset.lt === 'assets') panels.renderAssets();
    });
    // pages
    const pages = O.$('#pages-list');
    let lastPage = null;
    pages.addEventListener('click', e => {
      const r = e.target.closest('[data-pg]');
      if (!r) return;
      const id = r.dataset.pg;
      if (e.ctrlKey || e.metaKey) {
        if (!pageSel.size) pageSel.add(S.pageId);
        if (pageSel.has(id) && pageSel.size > 1) pageSel.delete(id); else pageSel.add(id);
        lastPage = id;
        panels.renderPages();
        return;
      }
      if (e.shiftKey && (lastPage || S.pageId)) {
        const ids = S.doc.pages.map(p => p.id);
        const a = ids.indexOf(lastPage || S.pageId), b = ids.indexOf(id);
        pageSel.clear();
        ids.slice(Math.min(a, b), Math.max(a, b) + 1).forEach(x => pageSel.add(x));
        panels.renderPages();
        return;
      }
      pageSel.clear(); pageSel.add(id);
      lastPage = id;
      if (id === S.pageId) { panels.renderPages(); return; }
      switchPage(id);
    });
    pages.addEventListener('dblclick', e => {
      const r = e.target.closest('[data-pg]');
      if (!r) return;
      const pg = S.doc.pages.find(p => p.id === r.dataset.pg);
      startRename(r.querySelector('.pg-name'), pg.name, v => { pg.name = v; O.history.commit('Перейменування сторінки'); });
    });
    pages.addEventListener('contextmenu', e => {
      const r = e.target.closest('[data-pg]');
      if (!r) return;
      e.preventDefault();
      const id = r.dataset.pg;
      if (!pageSel.has(id)) { pageSel.clear(); pageSel.add(id); panels.renderPages(); }
      const ids = panels.selectedPages().includes(id) ? panels.selectedPages() : [id];
      const many = ids.length > 1;
      O.ui.menu([
        { id: 'pg-rename', label: 'Перейменувати', enabled: () => !many },
        { id: 'pg-dup', label: many ? 'Дублювати сторінки' : 'Дублювати сторінку' },
        { id: 'pg-del', label: many ? 'Видалити сторінки' : 'Видалити сторінку', enabled: () => S.doc.pages.length > ids.length },
        '-',
        { id: 'pg-png', label: 'Експортувати сторінки: PNG' }, { id: 'pg-svg', label: 'Експортувати сторінки: SVG' }, { id: 'pg-pdf', label: 'Експортувати сторінки в один PDF' },
        '-',
        { id: 'pg-all', label: 'Виділити всі сторінки' }
      ], e.clientX, e.clientY, {
        onPick: a => {
          const pg = S.doc.pages.find(p => p.id === id);
          if (a === 'pg-rename') startRename(r.querySelector('.pg-name'), pg.name, v => { pg.name = v; O.history.commit('Перейменування сторінки'); });
          if (a === 'pg-dup') pagesDuplicate(ids);
          if (a === 'pg-del') pagesDelete(ids);
          if (a === 'pg-png') O.io.exportPages(ids, 'png', O.ls.get('expScale', 1));
          if (a === 'pg-svg') O.io.exportPages(ids, 'svg', 1);
          if (a === 'pg-pdf') O.io.exportPages(ids, 'pdf', 1);
          if (a === 'pg-all') { S.doc.pages.forEach(p => pageSel.add(p.id)); panels.renderPages(); }
        }
      });
    });
    pages.addEventListener('keydown', e => {
      if ((e.key === 'Delete' || e.key === 'Backspace') && pageSel.size > 1) { e.preventDefault(); e.stopPropagation(); pagesDelete(panels.selectedPages()); }
    });
    // reorder pages by dragging
    let dragPage = null;
    pages.addEventListener('dragstart', e => { const r = e.target.closest('[data-pg]'); if (!r) return; dragPage = r.dataset.pg; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'obrys-page'); });
    pages.addEventListener('dragover', e => { if (!dragPage) return; e.preventDefault(); pages.querySelectorAll('.drop-b,.drop-a').forEach(x => x.classList.remove('drop-b', 'drop-a')); const r = e.target.closest('[data-pg]'); if (r) { const b = r.getBoundingClientRect(); r.classList.add(e.clientY < b.top + b.height / 2 ? 'drop-b' : 'drop-a'); } });
    pages.addEventListener('drop', e => {
      if (!dragPage) return;
      e.preventDefault();
      const r = e.target.closest('[data-pg]');
      const moving = S.doc.pages.find(p => p.id === dragPage);
      dragPage = null;
      pages.querySelectorAll('.drop-b,.drop-a').forEach(x => x.classList.remove('drop-b', 'drop-a'));
      if (!r || !moving || r.dataset.pg === moving.id) return;
      const b = r.getBoundingClientRect(), after = e.clientY >= b.top + b.height / 2;
      S.doc.pages.splice(S.doc.pages.indexOf(moving), 1);
      const target = S.doc.pages.findIndex(p => p.id === r.dataset.pg);
      S.doc.pages.splice(target + (after ? 1 : 0), 0, moving);
      O.history.commit('Порядок сторінок');
    });
    pages.addEventListener('dragend', () => { dragPage = null; });
    O.$('[data-a="addpage"]').addEventListener('click', () => {
      const pg = model.newPage(t('Сторінка {n}', { n: S.doc.pages.length + 1 }));
      S.doc.pages.push(pg); S.pageId = pg.id; S.sel = [];
      model.reindex(); O.history.commit('Нова сторінка'); O.emit('page');
    });
    // layers
    const list = O.$('#layers-list');
    let lastClicked = null;
    list.addEventListener('click', e => {
      const row = e.target.closest('.ly');
      if (!row) { if (e.target === list) O.select([]); return; }
      const n = model.get(row.dataset.id);
      if (!n) return;
      const a = e.target.closest('[data-a]');
      if (a && a.dataset.a === 'toggle') { if (expanded.has(n.id)) expanded.delete(n.id); else expanded.add(n.id); panels.renderLayers(); return; }
      if (a && a.dataset.a === 'eye') { n.visible = n.visible === false; O.history.commit(n.visible ? 'Показ' : 'Приховування'); return; }
      if (a && a.dataset.a === 'lock') { n.locked = !n.locked; if (n.locked) O.select(S.sel.filter(id => id !== n.id)); O.history.commit(n.locked ? 'Блокування' : 'Розблокування'); return; }
      if (e.shiftKey && lastClicked) {
        const rows = Array.from(list.querySelectorAll('.ly')).map(r => r.dataset.id);
        const i0 = rows.indexOf(lastClicked), i1 = rows.indexOf(n.id);
        if (i0 >= 0 && i1 >= 0) { O.select(rows.slice(Math.min(i0, i1), Math.max(i0, i1) + 1)); return; }
      }
      if (e.ctrlKey || e.metaKey) { if (S.sel.includes(n.id)) O.select(S.sel.filter(i => i !== n.id)); else O.select([n.id], true); }
      else O.select([n.id]);
      lastClicked = n.id;
      const par = model.parent(n);
      S.enteredGroup = par && !model.isPage(par) ? par.id : null;
    });
    list.addEventListener('dblclick', e => {
      const row = e.target.closest('.ly');
      const name = e.target.closest('.ly-name');
      if (!row || !name) return;
      const n = model.get(row.dataset.id);
      startRename(name, n.name, v => { n.name = v; n.nameAuto = false; O.history.commit('Перейменування'); });
    });
    list.addEventListener('pointerover', e => {
      const row = e.target.closest('.ly');
      const id = row ? row.dataset.id : null;
      if (S.hover !== id) { S.hover = id; O.requestOverlay(); }
    });
    list.addEventListener('pointerleave', () => { S.hover = null; O.requestOverlay(); });
    list.addEventListener('contextmenu', e => {
      const row = e.target.closest('.ly');
      if (!row) return;
      e.preventDefault();
      if (!S.sel.includes(row.dataset.id)) O.select([row.dataset.id]);
      O.showContextMenu(e.clientX, e.clientY);
    });
    // drag & drop
    let dragIds = null;
    list.addEventListener('dragstart', e => {
      const row = e.target.closest('.ly');
      if (!row) return;
      const id = row.dataset.id;
      dragIds = S.sel.includes(id) ? O.ops.zsort(sel()).map(n => n.id) : [id];
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', 'obrys-layers');
    });
    const clearMarks = () => list.querySelectorAll('.drop-b,.drop-a,.drop-i').forEach(r => r.classList.remove('drop-b', 'drop-a', 'drop-i'));
    const posOf = (row, e) => {
      const r = row.getBoundingClientRect(), y = (e.clientY - r.top) / r.height;
      const n = model.get(row.dataset.id);
      const can = n && n.children && n.type !== 'instance';
      if (can && y > 0.28 && y < 0.72) return 'i';
      return y < 0.5 ? 'b' : 'a';
    };
    list.addEventListener('dragover', e => {
      if (!dragIds) return;
      e.preventDefault();
      clearMarks();
      const row = e.target.closest('.ly');
      if (row) row.classList.add('drop-' + posOf(row, e));
    });
    list.addEventListener('dragleave', e => { if (!list.contains(e.relatedTarget)) clearMarks(); });
    list.addEventListener('drop', e => {
      if (!dragIds) return;
      e.preventDefault();
      clearMarks();
      const row = e.target.closest('.ly');
      const nodes = dragIds.map(model.get).filter(Boolean);
      dragIds = null;
      let par, idx;
      if (row) {
        const target = model.get(row.dataset.id);
        if (!target || nodes.includes(target) || nodes.some(n => model.isAncestor(n, target))) return;
        const pos = posOf(row, e);
        const W = nodes.map(n => model.worldMatrix(n));
        nodes.forEach(n => model.remove(n));
        if (pos === 'i') { par = target; idx = target.children.length; expanded.add(target.id); }
        else { par = model.parent(target); idx = par.children.indexOf(target) + (pos === 'b' ? 1 : 0); }
        const Pm = model.containerMatrix(par);
        nodes.forEach((n, i) => { n.m = M.mul(M.inv(Pm), W[i]); model.insert(n, par, idx + i); });
      } else {
        par = model.page();
        nodes.forEach(n => model.reparent(n, par));
      }
      O.select(nodes.map(n => n.id));
      O.history.commit('Порядок шарів');
    });
    list.addEventListener('dragend', () => { dragIds = null; clearMarks(); });
  };

  // ---------- assets ----------
  const thumbCache = new Map();
  panels.renderAssets = () => {
    const box = O.$('#lp-assets');
    if (!box || box.hidden) return;
    const comps = [];
    for (const pg of S.doc.pages) model.walk(pg.children, n => { if (n.type === 'frame' && n.component) comps.push(n); });
    const thumb = c => {
      const key = c.id + JSON.stringify(c).length;
      if (thumbCache.get(c.id) && thumbCache.get(c.id).key === key) return thumbCache.get(c.id).url;
      let url = '';
      try {
        const pg = model.pageOf(c);
        const prev = S.pageId; S.pageId = pg.id;
        const { svg } = O.render.svg([c], {});
        S.pageId = prev;
        url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
      } catch (e) { /* ignore */ }
      thumbCache.set(c.id, { key, url });
      return url;
    };
    O.$('#as-comps').innerHTML = comps.length ? comps.map(c => `<button type="button" class="as-comp" data-comp="${c.id}" title="${esc(t('Клацніть, щоб вставити екземпляр'))}"><span class="as-th">${thumb(c) ? `<img src="${thumb(c)}" alt="">` : ''}</span><span>${esc(c.name)}</span></button>`).join('')
      : `<div class="as-empty">${esc(t('Компонентів ще немає. Виділіть об’єкти й натисніть Ctrl+Alt+K.'))}</div>`;
    const swHint = t('клік: заливка, Shift+клік: обведення');
    O.$('#as-sw').innerHTML = (S.doc.swatches || []).map(s => `<button type="button" class="sw big" style="--c:${s.color}" data-sw="${s.id}" title="${esc(s.name)} ${s.color} — ${esc(swHint)}"></button>`).join('');
    const custom = (S.doc.fonts || []).map(f => `<div class="as-font" style="font-family:'${esc(f.family)}'">${esc(f.family)}</div>`).join('');
    O.$('#as-fonts').innerHTML = custom || `<div class="as-empty">${esc(t('Власних шрифтів немає'))}</div>`;
  };
  panels.initAssets = () => {
    const box = O.$('#lp-assets');
    box.addEventListener('click', e => {
      const c = e.target.closest('[data-comp]');
      if (c) { O.ops.insertInstance(c.dataset.comp); return; }
      const sw = e.target.closest('[data-sw]');
      if (sw) {
        const s = S.doc.swatches.find(x => x.id === sw.dataset.sw);
        const nodes = sel();
        if (!nodes.length) { O.copyText(s.color); O.toast('Колір {c} скопійовано', { c: s.color }); return; }
        nodes.forEach(n => { if (e.shiftKey) { n.strokes = [O.paint.solid(s.color)]; if (!n.sw) n.sw = 1; } else n.fills = [O.paint.solid(s.color)]; });
        O.history.commit('Колір зі зразка');
        return;
      }
      const a = e.target.closest('[data-a]');
      if (!a) return;
      if (a.dataset.a === 'addsw') {
        const n = sel()[0];
        const f = n && (n.fills || []).find(x => x.type === 'solid');
        const color = f ? f.color : '#0D99FF';
        S.doc.swatches.push({ id: O.uid(), name: t('Колір {n}', { n: S.doc.swatches.length + 1 }), color });
        O.history.commit('Зразок кольору');
      }
      if (a.dataset.a === 'addfont') O.io.uploadFont();
      if (a.dataset.a === 'localfonts') O.io.queryLocalFonts();
      if (a.dataset.a === 'gfonts') { const tx = O.sel().find(x => x.type === 'text'); O.fonts.picker(a, tx ? tx.font : 'Inter', O.fonts.apply); }
    });
    box.addEventListener('contextmenu', e => {
      const sw = e.target.closest('[data-sw]');
      if (!sw) return;
      e.preventDefault();
      O.ui.menu([{ id: 'del', label: 'Видалити зразок' }], e.clientX, e.clientY, { onPick: () => { S.doc.swatches = S.doc.swatches.filter(x => x.id !== sw.dataset.sw); O.history.commit('Видалення зразка'); } });
    });
  };

  // ======================================================================
  // RIGHT: design properties
  // ======================================================================
  // label: translation key or icon markup (icons are passed through), title: translation key
  const inp = (f, val, label, opts = {}) => {
    const lab = label && label.startsWith('<') ? label : (label ? esc(tc(label)) : '');
    const ttl = esc(tc(opts.title || (label && !label.startsWith('<') ? label : '')));
    return `<label class="fld${opts.cls ? ' ' + opts.cls : ''}" title="${ttl}">${label ? `<span class="fl scrub" data-scrub="${f}"${opts.step ? ` data-step="${opts.step}"` : ''}>${lab}</span>` : ''}<input type="text" inputmode="decimal" data-f="${f}"${opts.i !== undefined ? ` data-i="${opts.i}"` : ''} value="${esc(val)}" spellcheck="false" aria-label="${ttl}">${opts.unit ? `<em>${opts.unit}</em>` : ''}</label>`;
  };
  const selectF = (f, val, options, opts = {}) => `<select class="sel${opts.cls ? ' ' + opts.cls : ''}" data-f="${f}"${opts.i !== undefined ? ` data-i="${opts.i}"` : ''} aria-label="${esc(t(opts.label || ''))}">${options.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(val) ? ' selected' : ''}>${esc(opts.raw ? l : t(l))}</option>`).join('')}</select>`;
  const ib = (attrs, icon, title, on) => { const tt = esc(t(title)); return `<button type="button" class="ib${on ? ' on' : ''}" ${attrs} title="${tt}" aria-label="${tt}">${O.icon(icon, 16)}</button>`; };
  const sec = (title, body, extra = '') => `<section class="ps"><div class="ps-h"><span>${esc(t(title))}</span><span class="ps-x">${extra}</span></div>${body}</section>`;
  const swatchStyle = p => {
    if (!p) return 'background:transparent';
    if (p.type === 'solid') return `background:${O.color.rgba(p.color, p.opacity === undefined ? 1 : p.opacity)}`;
    if (p.type === 'linear' || p.type === 'radial') return `background:${p.type === 'linear' ? 'linear-gradient(90deg,' : 'radial-gradient(circle,'}${p.stops.slice().sort((a, b) => a.o - b.o).map(s => O.color.rgba(s.color, s.a === undefined ? 1 : s.a) + ' ' + Math.round(s.o * 100) + '%').join(',')})`;
    if (p.type === 'image') { const u = O.assetURL(p.asset); return u ? `background:url('${u}') center/cover` : 'background:#ccc'; }
    return '';
  };
  const paintLabel = p => p.type === 'solid' ? p.color.replace('#', '') : t({ linear: 'Лінійний', radial: 'Радіальний', image: 'Зображення' }[p.type]);
  const paintRows = (kind, paints) => paints.map((p, i) => ({ p, i })).reverse().map(({ p, i }) => `<div class="pr${p.visible === false ? ' off' : ''}">
      <button type="button" class="swb" data-a="${kind}-pick" data-i="${i}" aria-label="${esc(t('Обрати колір'))}"><span class="chk"><span style="${swatchStyle(p)}"></span></span></button>
      ${p.type === 'solid' ? `<input class="hexin" type="text" data-f="${kind}-hex" data-i="${i}" value="${esc(paintLabel(p))}" spellcheck="false" aria-label="HEX">` : `<button type="button" class="plabel" data-a="${kind}-pick" data-i="${i}">${esc(paintLabel(p))}</button>`}
      <label class="fld op"><input type="text" inputmode="decimal" data-f="${kind}-op" data-i="${i}" value="${Math.round((p.opacity === undefined ? 1 : p.opacity) * 100)}" aria-label="${esc(t('Непрозорість'))}"><em>%</em></label>
      ${ib(`data-a="${kind}-eye" data-i="${i}"`, p.visible === false ? 'eyeoff' : 'eye', p.visible === false ? 'Показати' : 'Приховати')}
      ${ib(`data-a="${kind}-del" data-i="${i}"`, 'minus', 'Видалити')}</div>`).join('');
  // several selected objects go into one file unless «Each object as a separate file» is ticked
  panels.exportTogether = () => O.topSel().length > 1 && O.ls.get('expSelTogether', true);
  const exportSection = (title, buttonText, multi) => sec(title, `<div class="row">${selectF('exp-fmt', O.ls.get('expFmt', 'png'), EXPORT_FMTS, { label: 'Формат', raw: true })}${selectF('exp-scale', O.ls.get('expScale', 1), EXPORT_SCALES, { label: 'Масштаб', raw: true })}</div>${multi ? `<label class="chk exp-sep"><input type="checkbox" data-f="exp-separate"${O.ls.get('expSelTogether', true) ? '' : ' checked'}><span>${esc(t('Кожен об’єкт окремим файлом'))}</span></label>` : ''}<button type="button" class="btn wide" data-a="export">${O.icon('download', 14)} ${esc(buttonText)}</button>`);

  // extension points: whole panel for a tool (e.g. link pens), extra sections for a selection
  panels.toolProps = {};
  panels.extraSections = [];
  const extras = nodes => panels.extraSections.map(fn => { try { return fn(nodes) || ''; } catch (e) { console.error(e); return ''; } }).join('');
  panels.buildProps = () => {
    const nodes = sel();
    const allSel = O.sel();
    const n = nodes[0];
    let h = '';
    if (panels.toolProps[S.tool]) { const r = panels.toolProps[S.tool](nodes); if (r !== undefined && r !== null) return r; }
    if (!allSel.length) {
      const pg = model.page();
      if (S.tool === 'frame') {
        h += O.FRAME_PRESETS.map(([g, list]) => sec(g, `<div class="presets">${list.map(([name, w, hh]) => `<button type="button" class="preset" data-preset="${w}x${hh}" data-pname="${esc(tc(name))}"><span>${esc(tc(name))}</span><em>${w}×${hh}</em></button>`).join('')}</div>`)).join('');
        return h;
      }
      h += sec('Сторінка', `<div class="row"><button type="button" class="swb" data-a="page-bg" aria-label="${esc(t('Колір тла'))}"><span class="chk"><span style="background:${pg.bg || 'var(--canvas)'}"></span></span></button><input class="hexin" type="text" data-f="page-bg" value="${esc(pg.bg ? pg.bg.replace('#', '') : '')}" placeholder="${esc(t('Як у темі'))}" aria-label="${esc(t('Колір тла сторінки'))}">${pg.bg ? ib('data-a="page-bg-reset"', 'close', 'Скинути') : ''}</div>`);
      const st = S.settings;
      const tg = (k, label) => `<label class="chk"><input type="checkbox" data-s="${k}"${st[k] ? ' checked' : ''}><span>${esc(t(label))}</span></label>`;
      h += sec('Сітка та прив’язки', `<div class="col">${tg('grid', 'Показати сітку')}<div class="row">${inp('gridSize', st.gridSize, 'Крок', { unit: 'px' })}</div>${tg('snapGrid', 'Прив’язка до сітки')}${tg('snapPixel', 'Прив’язка до пікселів')}${tg('smart', 'Розумні напрямні')}${tg('snapGuides', 'Прив’язка до напрямних')}${tg('scaleStrokes', 'Масштабувати обведення')}</div>`);
      h += extras([]);
      h += exportSection('Експорт', model.page().children.some(c => c.type === 'frame') ? t('Експортувати фрейми') : t('Експортувати сторінку'));
      return h;
    }
    // alignment
    h += `<div class="align-row">${ib('data-cmd="alignLeft"', 'alignLeft', 'Вирівняти ліворуч (Alt+A)')}${ib('data-cmd="alignHCenter"', 'alignHCenter', 'Вирівняти по центру (Alt+H)')}${ib('data-cmd="alignRight"', 'alignRight', 'Вирівняти праворуч (Alt+D)')}${ib('data-cmd="alignTop"', 'alignTop', 'Вирівняти вгору (Alt+W)')}${ib('data-cmd="alignVCenter"', 'alignVCenter', 'Вирівняти по середині (Alt+V)')}${ib('data-cmd="alignBottom"', 'alignBottom', 'Вирівняти вниз (Alt+S)')}${ib('data-cmd="distH"', 'distH', 'Розподілити по горизонталі')}${ib('data-cmd="distV"', 'distV', 'Розподілити по вертикалі')}</div>`;
    if (!n) return h;
    const single = nodes.length === 1;
    // type badge
    const tname = n.component ? 'Компонент' : n.type === 'instance' ? 'Екземпляр' : n.type === 'frame' ? 'Фрейм' : n.type === 'group' ? (n.mask ? 'Обтравочна група' : 'Група') : n.type === 'bool' ? 'Булева група' : n.type === 'text' ? 'Текст' : (n.fills || []).some(f => f.type === 'image') ? 'Зображення' : (model.TYPE_NAMES[n.type] || 'Об’єкт');
    h += `<div class="ps-type"><span class="ly-ic">${O.icon(iconFor(n), 14)}</span><span>${esc(single ? t(tname) : t('Виділено: {n}', { n: nodes.length }))}</span></div>`;
    // transform
    let x, y, w, hh, rot = 0;
    if (single) { const p = refPos(n); x = p.x; y = p.y; const s = dispSize(n); w = s.w; hh = s.h; rot = relRot(n); }
    else { const b = model.selBounds(nodes); x = b.x; y = b.y; w = b.w; hh = b.h; }
    let tf = `<div class="grid2">${inp('x', fmt(x), 'X')}${inp('y', fmt(y), 'Y')}${inp('w', fmt(w), 'Ш', { title: 'Ширина' })}${inp('h', fmt(hh), 'В', { title: 'Висота' })}</div>`;
    tf += `<div class="grid2">${single ? inp('rot', fmt(rot, 1), O.icon('rotate', 12), { unit: '°', title: 'Поворот' }) : '<span></span>'}<div class="btns">${ib('data-a="ratio"', 'ratio', 'Зберігати пропорції', single && n.lockRatio)}${ib('data-cmd="flipH"', 'flipH', 'Віддзеркалити по горизонталі (Shift+H)')}${ib('data-cmd="flipV"', 'flipV', 'Віддзеркалити по вертикалі (Shift+V)')}${ib('data-cmd="rotate90"', 'rot90', 'Повернути на 90°')}</div></div>`;
    if (single && ['rect', 'frame', 'instance'].includes(n.type)) tf += `<div class="grid2">${inp('radius', Array.isArray(n.radius) ? n.radius.map(v => fmt(v)).join(', ') : fmt(n.radius || 0), O.icon('radius', 12), { title: 'Радіус кутів (одне число або чотири через кому)' })}<span></span></div>`;
    if (single && n.type === 'polygon') tf += `<div class="grid2">${inp('sides', n.sides, 'Сторін')}<span></span></div>`;
    if (single && n.type === 'star') tf += `<div class="grid2">${inp('points', n.points, 'Промені')}${inp('inner', fmt(n.inner * 100, 1), 'Глиб.', { unit: '%', title: 'Внутрішній радіус' })}</div>`;
    const presetSel = `<select class="sel mini" data-f="preset" aria-label="${esc(t('Розмір фрейма'))}"><option value="">${esc(t('Розмір…'))}</option>${O.FRAME_PRESETS.map(([g, l]) => `<optgroup label="${esc(t(g))}">${l.map(([nm, w2, h2]) => `<option value="${w2}x${h2}">${esc(tc(nm))} ${w2}×${h2}</option>`).join('')}</optgroup>`).join('')}</select>`;
    h += sec(single && n.type === 'frame' ? 'Фрейм' : 'Трансформація', tf, single && n.type === 'frame' ? presetSel : '');
    // component / instance / bool
    if (single && n.type === 'instance') {
      const comp = model.get(n.ref);
      h += sec('Екземпляр', `<div class="row note">${O.icon('component', 14)} ${comp ? esc(comp.name) : esc(t('Компонент видалено'))}</div><div class="row"><button type="button" class="btn" data-cmd="goToComponent">${esc(t('Перейти до компонента'))}</button><button type="button" class="btn" data-cmd="detach">${esc(t('Від’єднати'))}</button></div>`);
    }
    if (single && n.component) {
      let cnt = 0; for (const pg of S.doc.pages) model.walk(pg.children, x2 => { if (x2.type === 'instance' && x2.ref === n.id) cnt++; });
      h += sec('Основний компонент', `<div class="row note">${esc(t('Екземплярів: {n}. Зміни тут оновлять усі екземпляри.', { n: cnt }))}</div><div class="row"><button type="button" class="btn" data-a="instance">${esc(t('Створити екземпляр'))}</button></div>`);
    }
    if (single && n.type === 'bool') h += sec('Булева операція', `<div class="row">${['union', 'subtract', 'intersect', 'exclude'].map(op => ib(`data-f="op" data-v="${op}"`, op, OPS[op], n.op === op)).join('')}<button type="button" class="btn" data-cmd="expand">${esc(t('Розібрати'))}</button></div>`);
    // auto layout
    if (single && n.type === 'frame') {
      const L = n.layout;
      let al = '';
      if (L) {
        al += `<div class="row">${ib('data-f="al-dir" data-v="h"', 'dirH', 'Горизонтально', L.dir !== 'v')}${ib('data-f="al-dir" data-v="v"', 'dirV', 'Вертикально', L.dir === 'v')}${inp('al-gap', fmt(L.gap), 'Проміжок', { title: 'Проміжок між елементами' })}</div>`;
        al += `<div class="row">${inp('al-pad', L.pad.every(v => v === L.pad[0]) ? fmt(L.pad[0]) : L.pad.map(v => fmt(v)).join(', '), 'Відступи', { title: 'Внутрішні відступи: одне число або «верх, право, низ, ліво»' })}</div>`;
        al += `<div class="row">${selectF('al-align', L.align, [['start', 'Поперек: початок'], ['center', 'Поперек: центр'], ['end', 'Поперек: кінець']], { label: 'Вирівнювання' })}${selectF('al-justify', L.justify, [['start', 'Вздовж: початок'], ['center', 'Вздовж: центр'], ['end', 'Вздовж: кінець'], ['between', 'Рівномірно']], { label: 'Розподіл' })}</div>`;
        al += `<div class="row">${selectF('al-w', L.wMode, [['hug', 'Ширина: за вмістом'], ['fixed', 'Ширина: фіксована']], { label: 'Ширина' })}${selectF('al-h', L.hMode, [['hug', 'Висота: за вмістом'], ['fixed', 'Висота: фіксована']], { label: 'Висота' })}</div>`;
      }
      al += `<label class="chk"><input type="checkbox" data-f="clip"${n.clip ? ' checked' : ''}><span>${esc(t('Обрізати вміст'))}</span></label>`;
      h += sec('Автолейаут', al, ib('data-cmd="autoLayout"', L ? 'minus' : 'plus', L ? 'Вимкнути автолейаут' : 'Увімкнути автолейаут (Shift+A)'));
    }
    // layer
    const op = Math.round((n.opacity === undefined ? 1 : n.opacity) * 100);
    h += sec('Шар', `<div class="row">${selectF('blend', n.blend || 'normal', BLENDS, { label: 'Режим накладання' })}<label class="fld op" title="${esc(t('Непрозорість'))}">${O.icon('eye', 12)}<input type="text" inputmode="decimal" data-f="opacity" value="${op}" aria-label="${esc(t('Непрозорість'))}"><em>%</em></label></div>`);
    // text
    const texts = allSel.filter(x2 => x2.type === 'text');
    // area / point text: InDesign-style sections (typeui.js); text on a path keeps the compact section
    if (texts.length && O.typeui && texts.some(x2 => !x2.path)) h += O.typeui.sections(texts, nodes);
    else if (texts.length) {
      const tx0 = texts[0];
      // suggestions while typing: system, uploaded and installed fonts, then the whole Google Fonts catalogue
      const fonts = Array.from(new Set(FONTS.concat((S.doc.fonts || []).map(f => f.family), O.io.localFonts || [], O.fonts && O.fonts.google ? O.fonts.google.map(g => g.family) : [])));
      if (tx0.font && !fonts.some(f => f.toLowerCase() === tx0.font.toLowerCase())) fonts.unshift(tx0.font);
      const gf = O.fonts && O.fonts.get(tx0.font);
      let tx = `<div class="row font-row"><select class="fontin sel" data-f="font" aria-label="${esc(t('Шрифт'))}"${gf ? ` style="font-family:'${esc(gf.family)}', var(--font)"` : ''}>${fonts.map(f => `<option value="${esc(f)}"${f === tx0.font ? ' selected' : ''}>${esc(f)}</option>`).join('')}</select><button type="button" class="btn font-pick" data-a="font-pick" title="${esc(t('Усі шрифти, включно з Google Fonts'))}">${O.icon('search', 13)}<span>${esc(t('Шрифти'))}</span></button></div>`;
      const sizes = Array.from(new Set([6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 30, 36, 48, 60, 72, 96, 120, 144, +fmt(tx0.size)].filter(x => x > 0)));
      tx += `<div class="row">${selectF('weight', tx0.weight, WEIGHTS, { label: 'Накреслення', raw: true })}<label class="fld ty-sizefld" title="${esc(t('Розмір шрифту'))}"><span class="fl">${O.icon('font', 12)}</span><select class="sel" data-f="size" aria-label="${esc(t('Розмір шрифту'))}">${sizes.map(s => `<option value="${s}"${Math.abs(s - tx0.size) < 0.01 ? ' selected' : ''}>${s} px</option>`).join('')}<option value="custom">${esc(t('Інший…'))}</option></select></label></div>`;
      tx += `<div class="grid2">${inp('lh', tx0.lh ? fmt(tx0.lh * 100, 1) : t('Авто'), 'Рядок', { unit: tx0.lh ? '%' : '', title: 'Міжрядковий інтервал' })}${inp('ls', fmt(tx0.ls || 0, 2), 'Трекінг', { unit: 'px', title: 'Міжлітерний інтервал' })}</div>`;
      tx += `<div class="row">${['left', 'center', 'right', 'justify'].map(a => ib(`data-f="align" data-v="${a}"`, { left: 'tLeft', center: 'tCenter', right: 'tRight', justify: 'tJustify' }[a], { left: 'Ліворуч', center: 'По центру', right: 'Праворуч', justify: 'За шириною' }[a], tx0.align === a)).join('')}<span class="sp"></span>${ib('data-f="deco" data-v="underline"', 'underline', 'Підкреслення', tx0.deco === 'underline')}${ib('data-f="deco" data-v="line-through"', 'strike', 'Закреслення', tx0.deco === 'line-through')}${ib('data-f="italic"', 'text', 'Курсив', tx0.italic)}</div>`;
      tx += `<div class="row">${selectF('tcase', tx0.tcase || 'none', [['none', 'Регістр як є'], ['upper', 'ВЕЛИКІ'], ['lower', 'малі'], ['title', 'Кожне Слово']], { label: 'Регістр' })}${selectF('tmode', tx0.width === null || tx0.width === undefined ? 'auto' : 'fixed', [['auto', 'Автоширина'], ['fixed', 'Фіксована ширина']], { label: 'Ширина тексту' })}</div>`;
      if (tx0.path) tx += `<div class="row">${inp('pathOffset', fmt(tx0.pathOffset || 0, 1), 'Зсув', { unit: '%', title: 'Початок тексту на контурі' })}<button type="button" class="btn" data-cmd="releaseTextPath">${esc(t('Звільнити'))}</button></div>`;
      tx += `<div class="row"><button type="button" class="btn" data-cmd="createOutlines">${O.icon('path', 14)} ${esc(t('Перетворити на криві'))}</button></div>`;
      h += sec('Текст', tx);
    }
    // fills & strokes
    const hasGeom = nodes.some(x2 => x2.type !== 'group' && x2.type !== 'raster');
    if (hasGeom) {
      const fillsSame = nodes.every(x2 => JSON.stringify(x2.fills || []) === JSON.stringify(n.fills || []));
      h += sec('Заливка', fillsSame ? paintRows('fill', n.fills || []) : `<div class="row note">${esc(t('Різні заливки.'))} <button type="button" class="link" data-a="fill-unify">${esc(t('Зробити однаковими'))}</button></div>`, ib('data-a="fill-add"', 'plus', 'Додати заливку'));
      const strokesSame = nodes.every(x2 => JSON.stringify(x2.strokes || []) === JSON.stringify(n.strokes || []));
      let sb = strokesSame ? paintRows('stroke', n.strokes || []) : `<div class="row note">${esc(t('Різні обведення.'))} <button type="button" class="link" data-a="stroke-unify">${esc(t('Зробити однаковими'))}</button></div>`;
      if ((n.strokes || []).length) {
        const open = n.type === 'path' && n.subpaths.some(sp => !sp.closed);
        sb += `<div class="row">${inp('sw', fmt(n.sw), O.icon('minus', 12), { title: 'Товщина обведення' })}${open ? '' : selectF('sa', n.sa || 'center', [['inside', 'Всередині'], ['center', 'По центру'], ['outside', 'Ззовні']], { label: 'Розташування' })}</div>`;
        sb += `<div class="row">${selectF('cap', n.cap || 'butt', [['butt', 'Кінці: без'], ['round', 'Кінці: круглі'], ['square', 'Кінці: квадратні']], { label: 'Кінці' })}${selectF('join', n.join || 'miter', [['miter', 'Кути: гострі'], ['round', 'Кути: круглі'], ['bevel', 'Кути: скошені']], { label: 'Кути' })}</div>`;
        sb += `<div class="row">${inp('dash', (n.dash || []).map(v => fmt(v)).join(' ') || '', 'Пунктир', { title: 'Штрих і проміжок, наприклад «6 3»' })}${n.join === 'miter' || !n.join ? inp('miter', fmt(n.miter || 4), 'Межа', { title: 'Межа гострих кутів' }) : ''}</div>`;
        if (open) sb += `<div class="row">${selectF('ms', n.ms || 'none', MARK, { label: 'Початок' })}${selectF('me', n.me || 'none', MARK, { label: 'Кінець' })}</div>`;
      }
      h += sec('Обведення', sb, ib('data-a="stroke-add"', 'plus', 'Додати обведення'));
    }
    // effects
    const fx = n.effects || [];
    const eb = fx.map((e, i) => `<div class="fx${e.visible === false ? ' off' : ''}"><div class="row">${selectF('fx-type', e.type, FX, { i, label: 'Тип ефекту' })}${ib(`data-a="fx-eye" data-i="${i}"`, e.visible === false ? 'eyeoff' : 'eye', 'Показати/приховати')}${ib(`data-a="fx-del" data-i="${i}"`, 'minus', 'Видалити')}</div>
      <div class="grid2">${e.type !== 'blur' && e.type !== 'glow' && e.type !== 'innerglow' && e.type !== 'glass' ? inp('fx-x', fmt(e.x), 'X', { i, title: 'Зсув по горизонталі' }) + inp('fx-y', fmt(e.y), 'Y', { i, title: 'Зсув по вертикалі' }) : ''}${inp('fx-blur', fmt(e.blur), 'Розмиття', { i, title: e.type === 'glass' ? 'Розмиття того, що під склом (матовість)' : 'Розмиття' })}${e.type === 'shadow' || e.type === 'glow' ? inp('fx-spread', fmt(e.spread || 0), 'Поширення', { i, title: 'Поширення' }) : ''}${e.type === 'glass' ? inp('fx-refract', fmt(e.refract === undefined ? 36 : e.refract), 'Заломл.', { i, title: 'Заломлення на краях (сила лінзи)' }) + inp('fx-depth', fmt(e.depth || 22), 'Край', { i, title: 'Товщина скла: ширина зони заломлення' }) + inp('fx-light', fmt((e.light === undefined ? 0.7 : e.light) * 100), 'Блиск', { i, unit: '%', title: 'Яскравість відблиску на краях' }) + inp('fx-sat', fmt((e.sat === undefined ? 1.6 : e.sat) * 100), 'Насич.', { i, unit: '%', title: 'Насиченість кольорів під склом' }) + inp('fx-rim', fmt(e.rim || 0), 'Контур', { i, title: 'Товщина світлого контуру (0 — авто)' }) + inp('fx-sheen', fmt((e.sheen === undefined ? (e.light === undefined ? 0.7 : e.light) * 0.22 : e.sheen) * 100), 'Глянець', { i, unit: '%', title: 'Глянець зверху' }) : ''}</div>
      ${e.type === 'glass' ? `<div class="row glass-cols"><input type="color" data-f="fx-rimc" data-i="${i}" value="${esc(e.rimColor || '#FFFFFF')}" title="${esc(t('Колір контуру зверху зліва'))}" aria-label="${esc(t('Колір контуру зверху зліва'))}"><input type="color" data-f="fx-rimc2" data-i="${i}" value="${esc(e.rimColor2 || e.rimColor || '#FFFFFF')}" title="${esc(t('Колір контуру знизу справа'))}" aria-label="${esc(t('Колір контуру знизу справа'))}"><input type="color" data-f="fx-tint" data-i="${i}" value="${esc(e.tint || '#FFFFFF')}" title="${esc(t('Колір скла'))}" aria-label="${esc(t('Колір скла'))}"><label class="fld op" title="${esc(t('Сила кольору скла'))}"><input type="text" inputmode="decimal" data-f="fx-tintop" data-i="${i}" value="${Math.round((e.tintOp || 0) * 100)}" aria-label="${esc(t('Сила кольору скла'))}"><em>%</em></label><button type="button" class="btn" data-a="glass-dlg" data-i="${i}">${esc(t('Ще…'))}</button></div>` : ''}
      ${e.type !== 'blur' && e.type !== 'glass' ? `<div class="row"><input type="color" data-f="fx-color" data-i="${i}" value="${e.color || '#000000'}" aria-label="${esc(t('Колір'))}"><label class="fld op"><input type="text" inputmode="decimal" data-f="fx-op" data-i="${i}" value="${Math.round((e.opacity === undefined ? 0.25 : e.opacity) * 100)}" aria-label="${esc(t('Непрозорість'))}"><em>%</em></label></div>` : ''}</div>`).join('');
    h += sec('Ефекти', eb, ib('data-a="fx-add"', 'plus', 'Додати ефект'));
    // selection colors
    const colors = new Map();
    const scan = x2 => { for (const p of (x2.fills || []).concat(x2.strokes || [])) if (p.type === 'solid' && p.visible !== false) colors.set(p.color, (colors.get(p.color) || 0) + 1); (x2.children || []).forEach(scan); };
    allSel.forEach(scan);
    if (colors.size > 1 || (colors.size && allSel.some(x2 => x2.children))) {
      h += sec('Кольори виділення', `<div class="selcols">${Array.from(colors.keys()).slice(0, 24).map(c => `<button type="button" class="sw" style="--c:${c}" data-a="selcolor" data-c="${c}" title="${c}" aria-label="${c}"></button>`).join('')}</div>`);
    }
    // booleans & pathfinder
    if (nodes.length >= 2) {
      h += sec('Булеві операції', `<div class="row">${ib('data-cmd="boolUnion"', 'union', 'Об’єднання (редаговане)')}${ib('data-cmd="boolSubtract"', 'subtract', 'Віднімання (редаговане)')}${ib('data-cmd="boolIntersect"', 'intersect', 'Перетин (редаговане)')}${ib('data-cmd="boolExclude"', 'exclude', 'Виключення (редаговане)')}<span class="sp"></span>${ib('data-cmd="flatten"', 'path', 'Звести в один вектор (Ctrl+E)')}</div>`);
      h += sec('Обробка контурів', `<div class="row">${ib('data-cmd="pfUnite"', 'union', 'Об’єднати')}${ib('data-cmd="pfMinusFront"', 'subtract', 'Мінус передній')}${ib('data-cmd="pfIntersect"', 'intersect', 'Перетин')}${ib('data-cmd="pfExclude"', 'exclude', 'Виключити')}</div><div class="row">${ib('data-cmd="pfDivide"', 'divide', 'Розділити')}${ib('data-cmd="pfTrim"', 'trim', 'Обрізати')}${ib('data-cmd="pfMerge"', 'merge', 'Злити')}${ib('data-cmd="pfCrop"', 'crop', 'Кадрувати')}${ib('data-cmd="pfOutline"', 'outline', 'Контурні лінії')}${ib('data-cmd="pfMinusBack"', 'minusback', 'Мінус задній')}</div>`);
    }
    h += extras(nodes);
    // export
    h += exportSection('Експорт', single ? t('Експортувати «{name}»', { name: n.name.slice(0, 24) }) : O.ls.get('expSelTogether', true) ? t('Експортувати виділене разом') : t('Експортувати виділене'), nodes.length > 1);
    return h;
  };

  // apply a field value to selection
  const applyField = (f, raw, el, opts = {}) => {
    if (raw === undefined || raw === null) raw = '';
    const nodes = sel();
    const allSel = O.sel();
    const i = el && el.dataset.i !== undefined ? +el.dataset.i : null;
    const v = evalNum(raw);
    const num = isFinite(v);
    const pg = model.page();
    let label = 'Властивість';
    switch (f) {
      case 'page-bg': { const c = O.color.field(raw); pg.bg = c ? c.hex : null; label = 'Тло сторінки'; break; }
      case 'gridSize': if (num && v > 0) { S.settings.gridSize = v; O.saveSettings(); O.requestOverlay(); } return;
      case 'x': case 'y': {
        if (!num) return;
        if (nodes.length === 1) {
          const n = nodes[0], p = refPos(n), F = frameSpace(n);
          const d = f === 'x' ? { x: v - p.x, y: 0 } : { x: 0, y: v - p.y };
          model.applyWorld(n, M.mul(F, M.mul(M.translate(d.x, d.y), M.inv(F))), 'resize');
        } else {
          const b = model.selBounds(nodes);
          const d = v - b[f];
          nodes.forEach(n => model.applyWorld(n, f === 'x' ? M.translate(d, 0) : M.translate(0, d), 'resize'));
        }
        label = 'Позиція'; break;
      }
      case 'w': case 'h': {
        if (!num || v <= 0) return;
        if (nodes.length === 1) {
          const n = nodes[0], lb = model.localBounds(n), s = dispSize(n);
          const cur = f === 'w' ? s.w : s.h;
          if (cur <= 1e-9) return;
          const k = v / cur;
          const lock = n.lockRatio;
          const L = M.about(f === 'w' ? M.scale(k, lock ? k : 1) : M.scale(lock ? k : 1, k), { x: lb.x, y: lb.y });
          model.applyLocal(n, L, 'resize');
        } else {
          const b = model.selBounds(nodes);
          const k = v / (f === 'w' ? b.w : b.h);
          const Gm = M.about(f === 'w' ? M.scale(k, 1) : M.scale(1, k), { x: b.x, y: b.y });
          nodes.forEach(n => model.applyWorld(n, Gm, 'resize'));
        }
        label = 'Розмір'; break;
      }
      case 'rot': {
        if (!num || nodes.length !== 1) return;
        const n = nodes[0];
        const d = v - relRot(n);
        const c = R.center(model.worldBounds(n));
        model.applyWorld(n, M.about(M.rotate(-O.rad(d)), c), 'resize');
        label = 'Поворот'; break;
      }
      case 'radius': {
        const list = String(raw).split(/[,\s]+/).map(evalNum).filter(isFinite).map(x => Math.max(0, x));
        if (!list.length) return;
        nodes.forEach(n => { if ('radius' in n) n.radius = list.length >= 4 ? list.slice(0, 4) : list[0]; });
        label = 'Радіус'; break;
      }
      case 'sides': if (num) nodes.forEach(n => { if (n.type === 'polygon') n.sides = O.clamp(Math.round(v), 3, 100); }); break;
      case 'points': if (num) nodes.forEach(n => { if (n.type === 'star') n.points = O.clamp(Math.round(v), 3, 100); }); break;
      case 'inner': if (num) nodes.forEach(n => { if (n.type === 'star') n.inner = O.clamp(v / 100, 0.01, 1); }); break;
      case 'preset': {
        if (!raw) return;
        const [w, h] = raw.split('x').map(Number);
        nodes.forEach(n => { if (n.type === 'frame') { n.w = w; n.h = h; } });
        label = 'Розмір фрейма'; break;
      }
      case 'opacity': if (num) allSel.forEach(n => { n.opacity = O.clamp(v / 100, 0, 1); }); label = 'Непрозорість'; break;
      case 'blend': allSel.forEach(n => { n.blend = raw; }); label = 'Режим накладання'; break;
      case 'clip': nodes.forEach(n => { if (n.type === 'frame') n.clip = !!el.checked; }); break;
      case 'op': nodes.forEach(n => { if (n.type === 'bool') { n.op = raw; n.name = t(OPS[raw]); } }); break;
      // auto layout
      case 'al-dir': case 'al-gap': case 'al-pad': case 'al-align': case 'al-justify': case 'al-w': case 'al-h': {
        nodes.forEach(n => {
          const L = n.layout;
          if (!L) return;
          if (f === 'al-dir') L.dir = raw;
          if (f === 'al-gap' && num) L.gap = v;
          if (f === 'al-pad') { const l = String(raw).split(/[,\s]+/).map(evalNum).filter(isFinite); if (l.length === 1) L.pad = [l[0], l[0], l[0], l[0]]; else if (l.length === 2) L.pad = [l[0], l[1], l[0], l[1]]; else if (l.length >= 4) L.pad = l.slice(0, 4); }
          if (f === 'al-align') L.align = raw;
          if (f === 'al-justify') L.justify = raw;
          if (f === 'al-w') L.wMode = raw;
          if (f === 'al-h') L.hMode = raw;
        });
        label = 'Автолейаут'; break;
      }
      // text: font, weight, size, lh, ls, align, deco, italic, tcase and every InDesign attribute go to panels.fieldHook (typeui.js):
      // they apply to the selected characters / paragraphs while editing, otherwise to whole text frames
      case 'tmode': allSel.forEach(n => { if (n.type === 'text') n.width = raw === 'auto' ? null : Math.max(10, O.text.layout(n).w); }); break;
      case 'pathOffset': if (num) allSel.forEach(n => { if (n.type === 'text') n.pathOffset = O.clamp(v, 0, 100); }); break;
      // paints
      case 'fill-hex': case 'stroke-hex': {
        const key = f.startsWith('fill') ? 'fills' : 'strokes';
        const c = O.color.field(raw);
        if (!c) { if (el && !opts.live) { el.classList.add('bad'); setTimeout(() => el.classList.remove('bad'), 900); } return; }
        nodes.forEach(n => { const p = (n[key] || [])[i]; if (p && p.type === 'solid') { p.color = c.hex; if (c.a !== null) p.opacity = c.a; } });
        label = 'Колір'; break;
      }
      case 'fill-op': case 'stroke-op': {
        if (!num) return;
        const key = f.startsWith('fill') ? 'fills' : 'strokes';
        nodes.forEach(n => { const p = (n[key] || [])[i]; if (p) p.opacity = O.clamp(v / 100, 0, 1); });
        label = 'Непрозорість'; break;
      }
      case 'sw': if (num && v >= 0) nodes.forEach(n => { n.sw = v; }); label = 'Товщина'; break;
      case 'sa': nodes.forEach(n => { n.sa = raw; }); break;
      case 'cap': nodes.forEach(n => { n.cap = raw; }); break;
      case 'join': nodes.forEach(n => { n.join = raw; }); break;
      case 'miter': if (num) nodes.forEach(n => { n.miter = Math.max(1, v); }); break;
      case 'dash': { const l = String(raw).split(/[,\s]+/).map(evalNum).filter(x => isFinite(x) && x >= 0); nodes.forEach(n => { n.dash = l.some(x => x > 0) ? l : []; }); break; }
      case 'ms': nodes.forEach(n => { n.ms = raw; }); break;
      case 'me': nodes.forEach(n => { n.me = raw; }); break;
      // effects
      case 'fx-type': nodes.forEach(n => { const e = (n.effects || [])[i]; if (!e) return; e.type = raw; if (raw === 'glass' && O.glass) { Object.assign(e, O.glass.DEFAULT, { visible: e.visible }); if ((n.fills || []).every(p => p.type === 'solid' && (p.opacity === undefined || p.opacity > 0.5))) n.fills = [O.paint.solid('#FFFFFF', 0.12)]; } }); break;
      case 'fx-x': case 'fx-y': case 'fx-blur': case 'fx-spread': case 'fx-refract': case 'fx-depth': {
        if (!num) return;
        const k = f.slice(3);
        nodes.forEach(n => { const e = (n.effects || [])[i]; if (e) e[k] = k === 'blur' || k === 'depth' ? Math.max(0, v) : v; });
        label = 'Ефект'; break;
      }
      case 'fx-light': case 'fx-sat': case 'fx-sheen': case 'fx-tintop': {
        if (!num) return;
        const k = { 'fx-tintop': 'tintOp' }[f] || f.slice(3);
        nodes.forEach(n => { const e = (n.effects || [])[i]; if (e) e[k] = k === 'tintOp' || k === 'sheen' ? O.clamp(v / 100, 0, 1) : Math.max(0, v / 100); });
        label = 'Ефект'; break;
      }
      case 'fx-rim': if (num) nodes.forEach(n => { const e = (n.effects || [])[i]; if (e) e.rim = Math.max(0, v); }); label = 'Ефект'; break;
      case 'fx-rimc': case 'fx-rimc2': case 'fx-tint': {
        const k = { 'fx-rimc': 'rimColor', 'fx-rimc2': 'rimColor2', 'fx-tint': 'tint' }[f];
        const c = O.color.norm(raw);
        if (!c) return;
        nodes.forEach(n => { const e = (n.effects || [])[i]; if (e) { e[k] = c; if (k !== 'tint') e.rainbow = false; if (k === 'tint' && !(e.tintOp > 0)) e.tintOp = 0.2; } });
        label = 'Ефект'; break;
      }
      case 'fx-color': nodes.forEach(n => { const e = (n.effects || [])[i]; if (e) e.color = O.color.norm(raw); }); break;
      case 'fx-op': if (num) nodes.forEach(n => { const e = (n.effects || [])[i]; if (e) e.opacity = O.clamp(v / 100, 0, 1); }); break;
      case 'exp-fmt': O.ls.set('expFmt', raw); return;
      case 'exp-scale': O.ls.set('expScale', +raw); return;
      case 'exp-separate': O.ls.set('expSelTogether', !raw); panels.refresh(true, true); return;
      default: {
        const r = panels.fieldHook ? panels.fieldHook(f, raw, el, v, num, opts) : false;
        if (!r) return;
        label = r; break;
      }
    }
    if (opts.noCommit) { O.requestRender(); O.emit('change-soft'); return; }
    O.history.commit(label);
  };
  panels.applyField = applyField;

  const openPaintPicker = (kind, i, anchor) => {
    const key = kind === 'fill' ? 'fills' : 'strokes';
    const nodes = sel();
    if (!nodes.length) return;
    const p = (nodes[0][key] || [])[i];
    if (!p) return;
    O.ui.picker.open(anchor, p, {
      nodes: kind === 'fill' ? nodes : [], // image fills edit the nodes' photo adjustments
      onChange: np => { nodes.forEach(n => { if (n[key] && n[key][i]) n[key][i] = O.clone(np); }); O.requestRender(); },
      onClose: () => O.history.commit(kind === 'fill' ? 'Заливка' : 'Обведення')
    });
  };

  panels.initRight = () => {
    const tabs = O.$('#right .ptabs');
    tabs.addEventListener('click', e => {
      const b = e.target.closest('[data-rt]');
      if (!b) return;
      tabs.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
      O.$('#props').hidden = b.dataset.rt !== 'design';
      O.$('#code').hidden = b.dataset.rt !== 'code';
      panels.refresh(true);
    });
    const box = O.$('#props');
    box.addEventListener('change', e => {
      const tg = e.target;
      if (tg.dataset.s) {
        S.settings[tg.dataset.s] = tg.type === 'checkbox' ? tg.checked : tg.value;
        O.saveSettings(); O.requestOverlay(); O.emit('settings');
        return;
      }
      if (tg.dataset.f) applyField(tg.dataset.f, tg.type === 'checkbox' ? tg.checked : tg.value, tg);
    });
    // HEX fields: Cyrillic layout letters become A–F, a complete colour is shown while typing (Enter / leaving the field commits)
    box.addEventListener('input', e => {
      const tg = e.target;
      if (!tg.classList || !tg.classList.contains('hexin') || !tg.dataset.f) return;
      const lat = O.color.latinHex(tg.value);
      if (lat !== tg.value) { const p = tg.selectionStart; tg.value = lat; try { tg.setSelectionRange(p, p); } catch (err) { /* ignore */ } }
      if (/^#?([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(lat.trim())) applyField(tg.dataset.f, lat, tg, { noCommit: true, live: true });
    });
    box.addEventListener('keydown', e => {
      const tg = e.target;
      if (!tg.dataset || !tg.dataset.f) return;
      e.stopPropagation();
      if (e.key === 'Enter') { tg.blur(); }
      else if (e.key === 'Escape') { panels.refresh(true, true); tg.blur(); }
      else if ((e.key === 'ArrowUp' || e.key === 'ArrowDown') && tg.tagName === 'INPUT' && tg.type === 'text') {
        const v = evalNum(tg.value);
        if (!isFinite(v)) return;
        e.preventDefault();
        const step = (e.shiftKey ? 10 : 1) * (e.key === 'ArrowUp' ? 1 : -1);
        tg.value = fmt(v + step);
        applyField(tg.dataset.f, tg.value, tg);
        tg.select();
      }
    });
    box.addEventListener('focusout', () => setTimeout(() => panels.refresh(), 0));
    box.addEventListener('click', e => {
      const c = e.target.closest('[data-cmd]');
      if (c) { O.run(c.dataset.cmd); return; }
      const fv = e.target.closest('[data-f][data-v]');
      if (fv && fv.tagName === 'BUTTON') { applyField(fv.dataset.f, fv.dataset.v, fv); return; }
      const fb = e.target.closest('button[data-f]');
      if (fb) { applyField(fb.dataset.f, '', fb); return; }
      const pr = e.target.closest('[data-preset]');
      if (pr) {
        const [w, h] = pr.dataset.preset.split('x').map(Number);
        const c2 = R.center(V.viewRect());
        const f = model.create('frame', { w, h, name: `${pr.dataset.pname} — ${w}×${h}`, m: M.translate(Math.round(c2.x - w / 2), Math.round(c2.y - h / 2)) });
        model.insert(f, model.page());
        O.select([f.id]); O.setTool('select');
        O.history.commit('Фрейм');
        V.fit(model.worldBounds(f), 80, 1);
        return;
      }
      const a = e.target.closest('[data-a]');
      if (!a) return;
      const act = a.dataset.a, i = a.dataset.i !== undefined ? +a.dataset.i : null;
      const nodes = sel();
      const kind = act.split('-')[0], key = kind === 'fill' ? 'fills' : 'strokes';
      switch (act) {
        case 'fill-pick': case 'stroke-pick': openPaintPicker(kind, i, a); return;
        case 'fill-add': case 'stroke-add':
          nodes.forEach(n => {
            n[key] = n[key] || [];
            if (key === 'strokes' && !n.strokes.length && !(n.sw > 0)) n.sw = 1;
            n[key].push(O.paint.solid(key === 'fills' ? (n[key].length ? '#FFFFFF' : '#D9D9D9') : '#000000'));
          });
          O.history.commit(kind === 'fill' ? 'Заливка' : 'Обведення'); return;
        case 'fill-del': case 'stroke-del': nodes.forEach(n => { if (n[key]) n[key].splice(i, 1); }); O.history.commit('Видалення'); return;
        case 'fill-eye': case 'stroke-eye': nodes.forEach(n => { const p = (n[key] || [])[i]; if (p) p.visible = p.visible === false; }); O.history.commit('Видимість'); return;
        case 'fill-unify': case 'stroke-unify': nodes.forEach(n => { n[key] = O.clone(nodes[0][key] || []); }); O.history.commit('Однакове оформлення'); return;
        case 'fx-add':
          nodes.forEach(n => { n.effects = n.effects || []; n.effects.push({ type: 'shadow', x: 0, y: 4, blur: 8, spread: 0, color: '#000000', opacity: 0.25, visible: true }); });
          O.history.commit('Ефект'); return;
        case 'fx-del': nodes.forEach(n => { (n.effects || []).splice(i, 1); }); O.history.commit('Видалення ефекту'); return;
        case 'fx-eye': nodes.forEach(n => { const e2 = (n.effects || [])[i]; if (e2) e2.visible = e2.visible === false; }); O.history.commit('Видимість ефекту'); return;
        case 'glass-dlg': if (O.glass) O.glass.dialog(); return;
        case 'ratio': nodes.forEach(n => { n.lockRatio = !n.lockRatio; }); O.history.commit('Пропорції'); return;
        case 'export': O.io.export(O.ls.get('expFmt', 'png'), O.ls.get('expScale', 1), null, { embedFonts: O.ls.get('expFonts', true), together: panels.exportTogether() }); return;
        case 'font-pick': { const tx = O.sel().find(x2 => x2.type === 'text'); O.fonts.picker(a, tx ? tx.font : 'Inter', O.fonts.apply); return; }
        case 'instance': O.ops.insertInstance(nodes[0].id); return;
        case 'page-bg': {
          const pg = model.page();
          O.ui.picker.open(a, O.paint.solid(pg.bg || '#F5F5F5'), { types: ['solid'], onChange: p => { pg.bg = p.color; O.requestRender(); O.emit('settings'); }, onClose: () => O.history.commit('Тло сторінки') });
          return;
        }
        case 'page-bg-reset': model.page().bg = null; O.history.commit('Тло сторінки'); return;
        case 'selcolor': {
          const from = a.dataset.c;
          const targets = [];
          const scan = x => { for (const p of (x.fills || []).concat(x.strokes || [])) if (p.type === 'solid' && p.color === from) targets.push(p); (x.children || []).forEach(scan); };
          O.sel().forEach(scan);
          O.ui.picker.open(a, O.paint.solid(from), { types: ['solid'], onChange: p => { targets.forEach(tg => { tg.color = p.color; }); O.requestRender(); }, onClose: () => O.history.commit('Кольори виділення') });
          return;
        }
      }
    });
    // scrubbing labels
    box.addEventListener('pointerdown', e => {
      const lab = e.target.closest('.scrub');
      if (!lab) return;
      const input = lab.parentElement.querySelector('input');
      const v0 = evalNum(input.value);
      if (!isFinite(v0)) return;
      e.preventDefault();
      try { lab.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      const x0 = e.clientX;
      const step = parseFloat(lab.dataset.step) || 1;
      let moved = false;
      const mv = ev => {
        const d = Math.round((ev.clientX - x0) / 2) * step * (ev.shiftKey ? 10 : 1);
        if (!d && !moved) return;
        moved = true;
        input.value = fmt(v0 + d);
        applyField(input.dataset.f, input.value, input, { noCommit: true });
      };
      const up = () => {
        lab.removeEventListener('pointermove', mv); lab.removeEventListener('pointerup', up);
        if (moved) O.history.commit('Зміна значення'); else { input.focus(); input.select(); }
      };
      lab.addEventListener('pointermove', mv); lab.addEventListener('pointerup', up);
    });
  };

  // ---------- code (inspect) ----------
  const cssPaint = (p, n) => {
    if (p.type === 'solid') return O.color.rgba(p.color, p.opacity === undefined ? 1 : p.opacity).replace(/rgba\((\d+),(\d+),(\d+),1\)/, (m, r, g, b) => O.color.hex({ r: +r, g: +g, b: +b }).toLowerCase());
    if (p.type === 'linear') {
      const b = model.localBounds(n);
      const dx = (p.to.x - p.from.x) * b.w, dy = (p.to.y - p.from.y) * b.h;
      const ang = Math.round(O.deg(Math.atan2(dx, -dy)));
      return `linear-gradient(${ang}deg, ${p.stops.slice().sort((a, c) => a.o - c.o).map(s => O.color.rgba(s.color, (s.a === undefined ? 1 : s.a) * (p.opacity === undefined ? 1 : p.opacity)) + ' ' + Math.round(s.o * 100) + '%').join(', ')})`;
    }
    if (p.type === 'radial') return `radial-gradient(${p.stops.slice().sort((a, c) => a.o - c.o).map(s => O.color.rgba(s.color, s.a === undefined ? 1 : s.a) + ' ' + Math.round(s.o * 100) + '%').join(', ')})`;
    if (p.type === 'image') return `url(${(S.doc.assets[p.asset] || {}).name || 'image'}) center / ${p.mode === 'fit' ? 'contain' : p.mode === 'stretch' ? '100% 100%' : p.mode === 'tile' ? 'auto' : 'cover'}${p.mode === 'tile' ? ' repeat' : ' no-repeat'}`;
    return '';
  };
  panels.cssFor = n => {
    const lines = [];
    const p = refPos(n), s = dispSize(n), rot = relRot(n);
    lines.push(`/* ${n.name} */`);
    lines.push('position: absolute;', `left: ${fmt(p.x)}px;`, `top: ${fmt(p.y)}px;`, `width: ${fmt(s.w)}px;`, `height: ${fmt(s.h)}px;`);
    if (rot) lines.push(`transform: rotate(${fmt(-rot, 2)}deg);`, 'transform-origin: 0 0;');
    const fills = (n.fills || []).filter(f => f.visible !== false);
    if (n.type === 'text') {
      if (fills[0]) lines.push(`color: ${cssPaint(fills[0], n)};`);
      lines.push(`font-family: ${O.text.family(n.font)};`, `font-size: ${fmt(n.size)}px;`, `font-weight: ${n.weight};`);
      if (n.italic) lines.push('font-style: italic;');
      lines.push(`line-height: ${n.lh ? fmt(n.lh * 100) + '%' : 'normal'};`);
      if (n.ls) lines.push(`letter-spacing: ${fmt(n.ls)}px;`);
      if (n.align !== 'left') lines.push(`text-align: ${n.align};`);
      if (n.deco !== 'none') lines.push(`text-decoration: ${n.deco};`);
      if (n.tcase && n.tcase !== 'none') lines.push(`text-transform: ${{ upper: 'uppercase', lower: 'lowercase', title: 'capitalize' }[n.tcase]};`);
    } else if (fills.length) {
      lines.push(`background: ${fills.slice().reverse().map(f => cssPaint(f, n)).join(', ')};`);
    }
    if (n.radius) lines.push(`border-radius: ${Array.isArray(n.radius) ? n.radius.map(v => fmt(v) + 'px').join(' ') : fmt(n.radius) + 'px'};`);
    if (n.type === 'ellipse') lines.push('border-radius: 50%;');
    const st = (n.strokes || []).filter(f => f.visible !== false);
    if (st.length && n.sw > 0 && n.type !== 'text') {
      const c = cssPaint(st[0], n);
      const style = n.dash && n.dash.length ? 'dashed' : 'solid';
      if (n.sa === 'outside') lines.push(`outline: ${fmt(n.sw)}px ${style} ${c};`);
      else lines.push(`border: ${fmt(n.sw)}px ${style} ${c};`, n.sa === 'inside' ? 'box-sizing: border-box;' : '');
    }
    if (n.opacity !== undefined && n.opacity < 1) lines.push(`opacity: ${fmt(n.opacity)};`);
    if (n.blend && n.blend !== 'normal') lines.push(`mix-blend-mode: ${n.blend};`);
    const fx = (n.effects || []).filter(e => e.visible !== false);
    const sh = fx.filter(e => e.type !== 'blur').map(e => `${e.type === 'inner' || e.type === 'innerglow' ? 'inset ' : ''}${fmt(e.type.includes('glow') ? 0 : e.x)}px ${fmt(e.type.includes('glow') ? 0 : e.y)}px ${fmt(e.blur)}px ${fmt(e.spread || 0)}px ${O.color.rgba(e.color || '#000000', e.opacity === undefined ? 0.25 : e.opacity)}`);
    if (sh.length) lines.push(`${n.type === 'text' ? 'text-shadow' : 'box-shadow'}: ${sh.join(', ')};`);
    const bl = fx.find(e => e.type === 'blur');
    if (bl) lines.push(`filter: blur(${fmt(bl.blur / 2)}px);`);
    if (n.type === 'frame' && n.layout) {
      const L = n.layout;
      lines.push('display: flex;', `flex-direction: ${L.dir === 'v' ? 'column' : 'row'};`, `gap: ${fmt(L.gap)}px;`, `padding: ${L.pad.map(v => fmt(v) + 'px').join(' ')};`);
      lines.push(`align-items: ${{ start: 'flex-start', center: 'center', end: 'flex-end' }[L.align]};`, `justify-content: ${{ start: 'flex-start', center: 'center', end: 'flex-end', between: 'space-between' }[L.justify]};`);
    }
    return lines.filter(Boolean).join('\n');
  };
  panels.renderCode = () => {
    const box = O.$('#code');
    if (!box || box.hidden) return;
    const nodes = sel();
    if (!nodes.length) { box.innerHTML = `<div class="code-empty">${esc(t('Виділіть об’єкт або фрейм, щоб побачити його HTML, CSS та SVG-код.'))}</div>`; return; }
    const css = nodes.slice(0, 20).map(panels.cssFor).join('\n\n');
    let svg = '';
    // shown with short image paths (the photo data would be megabytes of text); «Copy SVG» keeps the data
    try { svg = O.render.svg(nodes, { assetURL: id => 'images/' + ((S.doc.assets[id] && S.doc.assets[id].name) || id) }).svg.replace(/></g, '>\n<'); } catch (e) { svg = ''; }
    if (svg.length > 60000) svg = svg.slice(0, 60000) + '\n…';
    // HTML + its CSS (the same generator as «Export HTML/CSS»)
    let snip = null;
    try { snip = O.html && O.html.snippet ? O.html.snippet(nodes.slice(0, 40)) : null; } catch (e) { console.warn(e); }
    const cut = s => (s.length > 60000 ? s.slice(0, 60000) + '\n…' : s);
    const ic = (k, label) => `<button type="button" class="ib" data-copy="${k}" title="${esc(t(label))}" aria-label="${esc(t(label))}">${O.icon(k === 'preview' ? 'play' : k === 'dl' ? 'download' : 'copy', 15)}</button>`;
    box.innerHTML = (snip ? `<section class="ps"><div class="ps-h"><span>HTML</span><span class="ps-x code-actions">${ic('preview', 'Переглянути у браузері')}${ic('dl', 'Завантажити index.html')}${ic('html', 'Копіювати HTML разом зі стилями')}</span></div><pre class="code">${esc(cut((snip.fonts ? snip.fonts + '\n' : '') + snip.html))}</pre></section>
      <section class="ps"><div class="ps-h"><span>${esc(t('CSS для HTML'))}</span><span class="ps-x">${ic('hcss', 'Копіювати CSS')}</span></div><pre class="code">${esc(cut(snip.css))}</pre>${snip.assets.length ? `<div class="row note">${esc(t('Зображення: {list}', { list: snip.assets.map(a => a.path).slice(0, 8).join(', ') + (snip.assets.length > 8 ? '…' : '') }))}</div>` : ''}</section>` : '') +
      `<section class="ps"><div class="ps-h"><span>${esc(t('CSS властивостей'))}</span><span class="ps-x">${ic('css', 'Копіювати CSS')}</span></div><pre class="code">${esc(css)}</pre></section>
      <section class="ps"><div class="ps-h"><span>SVG</span><span class="ps-x">${ic('svg', 'Копіювати SVG')}</span></div><pre class="code">${esc(svg)}</pre></section>`;
    // a standalone page with the images inside (data URLs), for copy / preview / download
    const page = () => O.html.pageHTML(nodes.slice(0, 40), { title: nodes[0].name });
    const on = (k, fn) => { const b = box.querySelector(`[data-copy="${k}"]`); if (b) b.onclick = fn; };
    on('css', () => { O.copyText(css); O.toast('CSS скопійовано'); });
    on('svg', () => { O.copyText(O.render.svg(nodes, {}).svg); O.toast('SVG скопійовано'); });
    on('hcss', () => { O.copyText(snip.css); O.toast('CSS скопійовано'); });
    on('html', () => { O.copyText(page()); O.toast('HTML скопійовано'); });
    on('preview', () => { if (O.html.previewHTML) O.html.previewHTML(page(), { title: nodes[0].name }); });
    on('dl', () => O.download(new Blob([page()], { type: 'text/html' }), 'index.html'));
  };

  // ---------- refresh scheduling ----------
  let pending = false;
  // a rebuild between pointerdown and click would replace the pressed button and swallow the click
  // (e.g. Export right after changing the format select), so wait for the button to be released
  let pressedInProps = false;
  document.addEventListener('pointerdown', e => { const box = O.$('#props'); pressedInProps = !!(box && box.contains(e.target)); }, true);
  const release = () => { if (!pressedInProps) return; pressedInProps = false; setTimeout(() => panels.refresh(), 0); };
  document.addEventListener('pointerup', release, true);
  document.addEventListener('pointercancel', release, true);
  let lastProps = '';
  panels.refresh = (force, hard) => {
    if (pending && !force) return;
    pending = true;
    const run = () => {
      pending = false;
      if (!S.doc) return;
      panels.renderLayers();
      panels.renderPages();
      const box = O.$('#props');
      const active = document.activeElement;
      if (!hard && box && box.contains(active) && active.matches('input,select,textarea')) return;
      if (box && !box.hidden && !(pressedInProps && !hard)) {
        const html = panels.buildProps();
        const edited = () => Array.from(box.querySelectorAll('input')).some(i => (i.type === 'checkbox' ? i.checked !== i.defaultChecked : i.value !== i.defaultValue)) || Array.from(box.querySelectorAll('select')).some(s => Array.from(s.options).some(o => o.selected !== o.defaultSelected));
        if (hard || html !== lastProps || !box.firstChild || edited()) {
          const st = box.scrollTop;
          box.innerHTML = html;
          lastProps = html;
          box.scrollTop = st;
        }
      }
      panels.renderCode();
      panels.renderAssets();
    };
    if (force) run(); else setTimeout(() => requestAnimationFrame(run), 30);
  };
  O.on('change', () => panels.refresh());
  O.on('change-soft', () => panels.refresh());
  O.on('selection', () => { panels._scrollToSel = true; panels.refresh(); });
  O.on('tool', () => panels.refresh());
  O.on('fonts', () => panels.refresh());
  O.on('page', () => { panels.refresh(); });
  O.on('lang', () => { thumbCache.clear(); if (S.doc) panels.refresh(true, true); });
})();
