'use strict';
/* VIBSma — application: commands, menus, shortcuts, pointer input, init */
(function () {
  const O = window.O, M = O.M, G = O.G, R = O.R, model = O.model, S = O.state, V = O.view, ops = O.ops, ui = O.ui;
  const t = (s, v) => O.t(s, v);
  const esc = O.esc;
  const has = n => () => O.sel().length >= n;
  const hasText = () => O.sel().some(n => n.type === 'text');
  // labels and groups are translation keys (Ukrainian source strings)
  const C = (id, label, run, keys, extra) => O.cmd(id, label, run, Object.assign({ keys: keys || [] }, extra || {}));
  const setOpt = (k, v) => { S.settings[k] = v; O.saveSettings(); O.emit('settings'); O.requestRender(); V.drawRulers(); };
  const toggleOpt = k => setOpt(k, !S.settings[k]);
  const chk = k => () => !!S.settings[k];
  const numDlg = (title, fields, fn) => ui.dialog({ title, fields, preview: true, apply: v => fn(v), label: title });

  // ======================================================================
  // COMMANDS
  // ======================================================================
  // File
  C('new', 'Новий документ', () => ui.dialog({ title: 'Новий документ', body: `<div class="dlg-text">${esc(t('Поточний документ буде закрито. Якщо він потрібен, спершу збережіть його (Ctrl+S).'))}</div>`, buttons: [{ id: 'ok', label: 'Створити', primary: true }], onOk: () => O.io.newDoc() }), ['Ctrl+Alt+N'], { group: 'Файл' });
  C('open', 'Відкрити…', () => O.io.open(), ['Ctrl+O'], { group: 'Файл' });
  C('save', 'Зберегти', () => O.io.save(false), ['Ctrl+S'], { group: 'Файл' });
  C('saveAs', 'Зберегти як…', () => O.io.save(true), ['Ctrl+Shift+S'], { group: 'Файл' });
  C('placeImage', 'Помістити зображення…', () => O.io.importImageDialog(), ['Ctrl+Shift+K', 'Ctrl+Shift+P'], { group: 'Файл' });
  C('importSVG', 'Імпортувати SVG…', () => O.io.importSVGDialog(), [], { group: 'Файл' });
  C('exportDialog', 'Експорт…', () => exportDialog(), ['Ctrl+Shift+E'], { group: 'Файл' });
  C('exportPNG', 'Експорт PNG', () => O.io.export('png', O.ls.get('expScale', 1)), [], { group: 'Файл' });
  C('exportJPG', 'Експорт JPG', () => O.io.export('jpg', O.ls.get('expScale', 1)), [], { group: 'Файл' });
  C('exportSVG', 'Експорт SVG', () => O.io.export('svg', 1), [], { group: 'Файл' });
  C('exportPDF', 'Експорт PDF (друк)', () => O.io.export('pdf', 1), [], { group: 'Файл' });
  C('copySVG', 'Копіювати як SVG', () => O.io.copySVG(), [], { group: 'Файл', enabled: has(1) });
  // W — presentation mode, as in InDesign (W or Esc returns)
  C('present', 'Режим презентації', () => present(), ['W', 'Ctrl+Alt+Enter'], { group: 'Файл' });
  C('sample', 'Відкрити приклад', () => { if (O.projects && !O.projects.disabled) O.projects.createFrom(sampleDoc()); else { model.load(sampleDoc()); setTimeout(() => V.fit(null, 80, 1), 0); } }, [], { group: 'Файл' });
  // Edit
  const undoLabel = () => { const l = O.history.undoLabel(); return l ? t('Скасувати: {a}', { a: t(l) }) : t('Скасувати дію'); };
  const redoLabel = () => { const l = O.history.redoLabel(); return l ? t('Повторити: {a}', { a: t(l) }) : t('Повторити'); };
  C('undo', undoLabel, () => O.history.undo(), ['Ctrl+Z'], { group: 'Редагування', enabled: () => O.history.idx > 0 });
  C('redo', redoLabel, () => O.history.redo(), ['Ctrl+Shift+Z'], { group: 'Редагування', enabled: () => O.history.idx < O.history.stack.length - 1 });
  C('cut', 'Вирізати', () => { if (ops.copy()) ops.del(); }, ['Ctrl+X'], { group: 'Редагування', enabled: has(1), native: true });
  C('copy', 'Копіювати', () => { ops.copy(); O.toast('Скопійовано'); }, ['Ctrl+C'], { group: 'Редагування', enabled: has(1), native: true });
  C('paste', 'Вставити', () => menuPaste(false), ['Ctrl+V'], { group: 'Редагування', native: true });
  C('pasteInPlace', 'Вставити на місце', () => menuPaste(true), ['Ctrl+Shift+V'], { group: 'Редагування', native: true });
  C('copyStyle', 'Копіювати властивості', () => { ops.copy(); O.toast('Властивості скопійовано'); }, ['Ctrl+Alt+C'], { group: 'Редагування', enabled: has(1) });
  C('pasteStyle', 'Вставити властивості', () => ops.pasteStyle(), ['Ctrl+Alt+V'], { group: 'Редагування', enabled: has(1) });
  C('duplicate', 'Дублювати', () => ops.duplicateCmd(), ['Ctrl+D'], { group: 'Редагування', enabled: has(1) });
  C('delete', 'Видалити', () => ops.del(), ['Delete'], { group: 'Редагування' });
  C('selectAll', 'Виділити все', () => ops.selectAll(), ['Ctrl+A'], { group: 'Виділення' });
  C('deselect', 'Скасувати виділення', () => O.select([]), ['Ctrl+Shift+A'], { group: 'Виділення' });
  C('selectInverse', 'Інвертувати виділення', () => ops.selectInverse(), [], { group: 'Виділення' });
  [['sameFill', 'fill', 'Однакова заливка'], ['sameStroke', 'stroke', 'Однакове обведення'], ['sameSW', 'sw', 'Однакова товщина обведення'], ['sameOpacity', 'opacity', 'Однакова непрозорість'], ['sameBlend', 'blend', 'Однаковий режим накладання'], ['sameFont', 'font', 'Однаковий шрифт'], ['sameType', 'type', 'Однаковий тип об’єкта']]
    .forEach(([id, p, l]) => C(id, l, () => ops.selectSame(p), [], { group: 'Виділити схоже', enabled: has(1) }));
  C('palette', 'Швидкі дії…', () => ui.palette(), ['Ctrl+/', 'Ctrl+K'], { group: 'Довідка' });
  // Object
  C('group', 'Згрупувати', () => ops.group(), ['Ctrl+G'], { group: 'Об’єкт', enabled: has(1) });
  C('ungroup', 'Розгрупувати', () => ops.ungroup(), ['Ctrl+Shift+G'], { group: 'Об’єкт', enabled: has(1) });
  C('frameSelection', 'Фрейм із виділення', () => ops.frameSelection(null, { fill: false }), ['Ctrl+Alt+G'], { group: 'Об’єкт', enabled: has(1) });
  C('bringFront', 'На передній план', () => ops.arrange('front'), ['Ctrl+Shift+]'], { group: 'Порядок', enabled: has(1) });
  C('bringForward', 'Перемістити вперед', () => ops.arrange('forward'), ['Ctrl+]'], { group: 'Порядок', enabled: has(1) });
  C('sendBackward', 'Перемістити назад', () => ops.arrange('backward'), ['Ctrl+['], { group: 'Порядок', enabled: has(1) });
  C('sendBack', 'На задній план', () => ops.arrange('back'), ['Ctrl+Shift+['], { group: 'Порядок', enabled: has(1) });
  C('transformAgain', 'Повторити трансформацію', () => ops.transformAgain(), ['Ctrl+Alt+D'], { group: 'Трансформація', enabled: has(1) });
  C('moveDlg', 'Перемістити…', () => ops.transformDialog('move'), ['Ctrl+Shift+M'], { group: 'Трансформація', enabled: has(1) });
  C('rotateDlg', 'Повернути…', () => ops.transformDialog('rotate'), [], { group: 'Трансформація', enabled: has(1) });
  C('reflectDlg', 'Віддзеркалити…', () => ops.transformDialog('reflect'), [], { group: 'Трансформація', enabled: has(1) });
  C('scaleDlg', 'Масштабувати…', () => ops.transformDialog('scale'), [], { group: 'Трансформація', enabled: has(1) });
  C('shearDlg', 'Нахилити…', () => ops.transformDialog('shear'), [], { group: 'Трансформація', enabled: has(1) });
  C('transformEach', 'Трансформувати кожен…', () => ops.transformEachDialog(), ['Ctrl+Alt+Shift+D'], { group: 'Трансформація', enabled: has(1) });
  C('resetBox', 'Скинути обмежувальну рамку', () => ops.resetBox(), [], { group: 'Трансформація', enabled: has(1) });
  C('flipH', 'Віддзеркалити по горизонталі', () => ops.flip('h'), ['Shift+H'], { group: 'Трансформація', enabled: has(1) });
  C('flipV', 'Віддзеркалити по вертикалі', () => ops.flip('v'), ['Shift+V'], { group: 'Трансформація', enabled: has(1) });
  C('rotate90', 'Повернути на 90° за годинниковою', () => ops.rotateBy(-90), [], { group: 'Трансформація', enabled: has(1) });
  C('alignLeft', 'Вирівняти ліворуч', () => ops.align('left'), ['Alt+A'], { group: 'Вирівнювання', enabled: has(1) });
  C('alignHCenter', 'Вирівняти по центру', () => ops.align('hcenter'), ['Alt+H'], { group: 'Вирівнювання', enabled: has(1) });
  C('alignRight', 'Вирівняти праворуч', () => ops.align('right'), ['Alt+D'], { group: 'Вирівнювання', enabled: has(1) });
  C('alignTop', 'Вирівняти вгору', () => ops.align('top'), ['Alt+W'], { group: 'Вирівнювання', enabled: has(1) });
  C('alignVCenter', 'Вирівняти по середині', () => ops.align('vcenter'), ['Alt+V'], { group: 'Вирівнювання', enabled: has(1) });
  C('alignBottom', 'Вирівняти вниз', () => ops.align('bottom'), ['Alt+S'], { group: 'Вирівнювання', enabled: has(1) });
  C('distH', 'Розподілити по горизонталі', () => ops.distribute('h'), ['Alt+Shift+H'], { group: 'Вирівнювання', enabled: has(3) });
  C('distV', 'Розподілити по вертикалі', () => ops.distribute('v'), ['Alt+Shift+V'], { group: 'Вирівнювання', enabled: has(3) });
  C('editPath', 'Редагувати вузли', () => { const n = O.sel()[0]; if (O.isEditablePath(n)) { S.edit = { id: n.id, sel: new Set() }; O.setTool('direct'); } }, [], { group: 'Контур', enabled: () => O.isEditablePath(O.sel()[0]) });
  C('join', 'З’єднати', () => ops.join(), ['Ctrl+J'], { group: 'Контур', enabled: has(1) });
  C('average', 'Усереднити…', () => ui.dialog({ title: 'Усереднення', fields: [{ key: 'axis', label: 'Вісь', type: 'select', value: 'both', options: [['both', 'Обидві'], ['h', 'Горизонтальна'], ['v', 'Вертикальна']] }], apply: v => ops.average(v.axis), label: 'Усереднення' }), ['Ctrl+Alt+J'], { group: 'Контур', enabled: has(1) });
  C('outlineStroke', 'Обведення в контур', () => ops.outlineStroke(), [], { group: 'Контур', enabled: has(1) });
  C('offsetPath', 'Зміщення контуру…', () => numDlg('Зміщення контуру', [{ key: 'd', label: 'Зміщення', type: 'number', value: 10, unit: 'px' }, { key: 'join', label: 'Стики', type: 'select', value: 'miter', options: [['miter', 'Гострі'], ['round', 'Круглі'], ['bevel', 'Скошені']] }, { key: 'miter', label: 'Межа гострих кутів', type: 'number', value: 4 }], v => ops.offsetPath(v.d, v.join, v.miter)), [], { group: 'Контур', enabled: has(1) });
  C('simplify', 'Спростити…', () => numDlg('Спрощення контуру', [{ key: 't', label: 'Допуск', type: 'number', value: 2, step: 0.5 }], v => ops.simplifyPath(Math.max(0.05, v.t))), [], { group: 'Контур', enabled: has(1) });
  C('smooth', 'Згладити', () => ops.smoothPath(), [], { group: 'Контур', enabled: has(1) });
  C('addAnchors', 'Додати вузли', () => ops.addAnchors(), [], { group: 'Контур', enabled: has(1) });
  C('removeAnchors', 'Видалити вибрані вузли', () => ops.deleteAnchors(), [], { group: 'Контур', enabled: () => !!(S.edit && S.edit.sel.size) });
  C('reversePath', 'Змінити напрямок контуру', () => ops.reverse(), [], { group: 'Контур', enabled: has(1) });
  C('splitGrid', 'Розбити на сітку…', () => ui.dialog({ title: 'Розбиття на сітку', fields: [{ key: 'r', label: 'Рядків', type: 'number', value: 2, min: 1 }, { key: 'c', label: 'Стовпців', type: 'number', value: 2, min: 1 }, { key: 'gy', label: 'Проміжок між рядками', type: 'number', value: 10 }, { key: 'gx', label: 'Проміжок між стовпцями', type: 'number', value: 10 }], preview: true, apply: v => ops.splitGrid(Math.max(1, Math.round(v.r)), Math.max(1, Math.round(v.c)), v.gx, v.gy), label: 'Розбиття на сітку' }), [], { group: 'Контур', enabled: has(1) });
  C('cleanup', 'Очистити сторінку', () => ops.cleanup(), [], { group: 'Контур' });
  C('boolUnion', 'Об’єднання (булева група)', () => ops.boolean('union'), [], { group: 'Булеві', enabled: has(2) });
  C('boolSubtract', 'Віднімання (булева група)', () => ops.boolean('subtract'), [], { group: 'Булеві', enabled: has(2) });
  C('boolIntersect', 'Перетин (булева група)', () => ops.boolean('intersect'), [], { group: 'Булеві', enabled: has(2) });
  C('boolExclude', 'Виключення (булева група)', () => ops.boolean('exclude'), [], { group: 'Булеві', enabled: has(2) });
  C('flatten', 'Звести в один вектор', () => ops.flatten(), ['Ctrl+E'], { group: 'Булеві', enabled: has(1) });
  C('expand', 'Розібрати (перетворити на контури)', () => ops.expand(), [], { group: 'Об’єкт', enabled: has(1) });
  [['pfUnite', 'union', 'Об’єднати'], ['pfMinusFront', 'subtract', 'Мінус передній'], ['pfIntersect', 'intersect', 'Перетин'], ['pfExclude', 'exclude', 'Виключити']]
    .forEach(([id, op, l]) => C(id, l, () => ops.boolean(op, null, { destructive: true }), [], { group: 'Обробка контурів', enabled: has(2) }));
  [['pfDivide', 'divide', 'Розділити'], ['pfTrim', 'trim', 'Обрізати'], ['pfMerge', 'merge', 'Злити'], ['pfCrop', 'crop', 'Кадрувати'], ['pfOutline', 'outline', 'Контурні лінії'], ['pfMinusBack', 'minusback', 'Мінус задній']]
    .forEach(([id, k, l]) => C(id, l, () => ops.pathfinder(k), [], { group: 'Обробка контурів', enabled: has(2) }));
  C('makeClip', 'Створити обтравочну маску', () => ops.makeClip('top'), ['Ctrl+7'], { group: 'Маска', enabled: has(2) });
  C('useAsMask', 'Використати як маску (нижній шар)', () => ops.makeClip('bottom'), ['Ctrl+Alt+M'], { group: 'Маска', enabled: has(2) });
  C('releaseClip', 'Звільнити обтравочну маску', () => ops.releaseClip(), ['Ctrl+Alt+7'], { group: 'Маска', enabled: has(1) });
  C('makeCompound', 'Створити складений контур', () => ops.makeCompound(), ['Ctrl+8'], { group: 'Складений контур', enabled: has(2) });
  C('releaseCompound', 'Звільнити складений контур', () => ops.releaseCompound(), ['Ctrl+Alt+Shift+8'], { group: 'Складений контур', enabled: has(1) });
  C('blendMake', 'Створити перехід', () => { const s = ops.zsort(O.topSel()); if (s.length !== 2) return O.toast('Виділіть рівно 2 об’єкти'); ops.blend(s[0], s[1], O.toolOpts.blendSteps); }, ['Ctrl+Alt+Shift+B'], { group: 'Перехід', enabled: has(2) });
  C('blendOptions', 'Параметри переходу…', () => ui.dialog({ title: 'Параметри переходу', fields: [{ key: 's', label: 'Кількість кроків', type: 'number', value: O.toolOpts.blendSteps, min: 1, max: 200 }], onOk: v => { O.toolOpts.blendSteps = Math.max(1, Math.round(v.s)); O.saveToolOpts(); } }), [], { group: 'Перехід' });
  C('createComponent', 'Створити компонент', () => ops.createComponent(), ['Ctrl+Alt+K'], { group: 'Компоненти', enabled: has(1) });
  C('detach', 'Від’єднати екземпляр', () => ops.detach(), ['Ctrl+Alt+B'], { group: 'Компоненти', enabled: () => O.sel().some(n => n.type === 'instance') });
  C('goToComponent', 'Перейти до основного компонента', () => ops.goToComponent(), [], { group: 'Компоненти', enabled: () => O.sel().some(n => n.type === 'instance') });
  C('autoLayout', 'Автолейаут', () => ops.autoLayout(), ['Shift+A'], { group: 'Об’єкт', enabled: has(1) });
  C('lock', 'Заблокувати / розблокувати', () => ops.toggleLock(), ['Ctrl+Shift+L', 'Ctrl+2'], { group: 'Об’єкт', enabled: has(1) });
  C('unlockAll', 'Розблокувати все', () => ops.unlockAll(), ['Ctrl+Alt+2'], { group: 'Об’єкт' });
  C('hide', 'Приховати / показати', () => ops.toggleHide(), ['Ctrl+Shift+H', 'Ctrl+3'], { group: 'Об’єкт', enabled: has(1) });
  C('showAll', 'Показати все', () => ops.showAll(), ['Ctrl+Alt+3'], { group: 'Об’єкт' });
  C('rasterize', 'Растеризувати', () => ops.rasterize(2), [], { group: 'Об’єкт', enabled: has(1) });
  [['traceDefault', 'default', 'Трасування: за замовчуванням'], ['tracePhoto', 'photo', 'Трасування: фото (детально)'], ['tracePoster', 'poster', 'Трасування: постер (4 кольори)'], ['traceBW', 'bw', 'Трасування: чорно-біле'], ['traceSketch', 'sketch', 'Трасування: ескіз']]
    .forEach(([id, p, l]) => C(id, l, () => ops.imageTrace(p), [], { group: 'Трасування зображення', enabled: () => O.sel().some(n => (n.fills || []).some(f => f.type === 'image')) }));
  // Type
  C('createOutlines', 'Перетворити на криві', () => { if (hasText()) ops.createOutlines(); else ops.outlineStroke(); }, ['Ctrl+Shift+O'], { group: 'Текст', enabled: has(1) });
  C('textOnPath', 'Розмістити текст на контурі', () => ops.textToPathCmd(), [], { group: 'Текст', enabled: has(1) });
  C('releaseTextPath', 'Звільнити текст із контуру', () => ops.releaseTextPath(), [], { group: 'Текст', enabled: hasText });
  C('uploadFont', 'Завантажити шрифт…', () => O.io.uploadFont(), [], { group: 'Текст' });
  C('localFonts', 'Показати встановлені шрифти', () => O.io.queryLocalFonts(), [], { group: 'Текст' });
  C('fontBigger', 'Збільшити шрифт', () => fontStep(1), ['Ctrl+Shift+.'], { group: 'Текст', enabled: hasText });
  C('fontSmaller', 'Зменшити шрифт', () => fontStep(-1), ['Ctrl+Shift+,'], { group: 'Текст', enabled: hasText });
  [['caseUpper', 'upper', 'ВЕЛИКІ ЛІТЕРИ'], ['caseLower', 'lower', 'малі літери'], ['caseTitle', 'title', 'Кожне Слово З Великої'], ['caseNone', 'none', 'Регістр як є']]
    .forEach(([id, v, l]) => C(id, l, () => O.panels.applyField('tcase', v), [], { group: 'Регістр', enabled: hasText }));
  // Effects
  const addFx = (type, extra) => () => { const ns = O.topSel(); if (!ns.length) return O.toast('Спершу виділіть об’єкт'); ns.forEach(n => { n.effects = n.effects || []; n.effects.push(Object.assign({ type, x: 0, y: 4, blur: 8, spread: 0, color: '#000000', opacity: 0.25, visible: true }, extra || {})); }); O.history.commit('Ефект'); };
  C('fxShadow', 'Тінь', addFx('shadow'), [], { group: 'Ефект' });
  C('fxInner', 'Внутрішня тінь', addFx('inner', { y: 2, blur: 6 }), [], { group: 'Ефект' });
  C('fxGlow', 'Зовнішнє світіння', addFx('glow', { blur: 16, color: '#FFD84D', opacity: 0.8 }), [], { group: 'Ефект' });
  C('fxInnerGlow', 'Внутрішнє світіння', addFx('innerglow', { blur: 12, color: '#FFFFFF', opacity: 0.7 }), [], { group: 'Ефект' });
  C('fxBlur', 'Розмиття за Гаусом', addFx('blur', { blur: 8 }), [], { group: 'Ефект' });
  C('puckerBloat', 'Втягування і роздування…', () => numDlg('Втягування і роздування', [{ key: 'a', label: 'Величина (− втягнути, + роздути)', type: 'number', value: 30, unit: '%' }], v => ops.puckerBloat(v.a)), [], { group: 'Спотворення', enabled: has(1) });
  C('roughen', 'Огрубіння…', () => numDlg('Огрубіння', [{ key: 's', label: 'Розмір', type: 'number', value: 3, unit: '%' }, { key: 'd', label: 'Деталізація (на дюйм)', type: 'number', value: 20 }, { key: 'sm', label: 'Плавні точки', type: 'checkbox', value: false }], v => ops.roughen(v.s, v.d, v.sm)), [], { group: 'Спотворення', enabled: has(1) });
  C('zigzag', 'Зигзаг…', () => numDlg('Зигзаг', [{ key: 's', label: 'Розмір', type: 'number', value: 6, unit: 'px' }, { key: 'r', label: 'Гребенів на сегмент', type: 'number', value: 6 }, { key: 'sm', label: 'Плавні точки', type: 'checkbox', value: false }], v => ops.zigzag(v.s, Math.max(1, Math.round(v.r)), v.sm)), [], { group: 'Спотворення', enabled: has(1) });
  C('twist', 'Скручування…', () => numDlg('Скручування', [{ key: 'a', label: 'Кут', type: 'number', value: 60, unit: '°' }], v => ops.twist(v.a)), [], { group: 'Спотворення', enabled: has(1) });
  C('roundCorners', 'Округлення кутів…', () => numDlg('Округлення кутів', [{ key: 'r', label: 'Радіус', type: 'number', value: 10, unit: 'px' }], v => ops.roundCorners(Math.max(0, v.r))), [], { group: 'Спотворення', enabled: has(1) });
  // View
  C('zoomIn', 'Збільшити', () => V.zoomStep(1), ['Ctrl+=', 'Ctrl+Shift+='], { group: 'Вигляд' });
  C('zoomOut', 'Зменшити', () => V.zoomStep(-1), ['Ctrl+-'], { group: 'Вигляд' });
  C('zoom100', 'Масштаб 100%', () => V.setZoom(1), ['Shift+0', 'Ctrl+1'], { group: 'Вигляд' });
  C('zoomFit', 'Показати все', () => V.fit(null, 64, 8), ['Shift+1', 'Ctrl+0'], { group: 'Вигляд' });
  C('zoomSel', 'Масштаб до виділення', () => { const b = model.selBounds(O.sel()); if (b) V.fit(b, 80, 64); }, ['Shift+2'], { group: 'Вигляд', enabled: has(1) });
  C('outline', 'Режим контурів', () => toggleOpt('outline'), ['Ctrl+Y'], { group: 'Вигляд', check: chk('outline') });
  C('pixelPreview', 'Попередній перегляд пікселів', () => toggleOpt('pixelPreview'), ['Ctrl+Alt+Y'], { group: 'Вигляд', check: chk('pixelPreview') });
  C('rulers', 'Лінійки', () => toggleOpt('rulers'), ['Ctrl+R'], { group: 'Вигляд', check: chk('rulers') });
  C('guides', 'Напрямні', () => toggleOpt('guides'), ['Ctrl+;'], { group: 'Вигляд', check: chk('guides') });
  C('clearGuides', 'Видалити всі напрямні', () => { model.page().guides = []; S.guideSel = null; O.history.commit('Напрямні'); }, [], { group: 'Вигляд' });
  C('deleteGuide', 'Видалити напрямну', () => {
    const pg = model.page();
    if (S.guideSel === null || S.guideSel === undefined || !pg.guides[S.guideSel]) return;
    pg.guides.splice(S.guideSel, 1);
    S.guideSel = null;
    O.history.commit('Видалення напрямної');
    O.requestOverlay();
  }, [], { group: 'Вигляд', enabled: () => S.guideSel !== null && S.guideSel !== undefined && !!model.page().guides[S.guideSel] });
  C('lockGuides', 'Заблокувати напрямні', () => toggleOpt('guidesLocked'), ['Ctrl+Alt+;'], { group: 'Вигляд', check: chk('guidesLocked') });
  C('grid', 'Сітка', () => toggleOpt('grid'), ["Ctrl+'"], { group: 'Вигляд', check: chk('grid') });
  C('snapGrid', 'Прив’язка до сітки', () => toggleOpt('snapGrid'), ["Ctrl+Shift+'"], { group: 'Вигляд', check: chk('snapGrid') });
  C('snapPixel', 'Прив’язка до пікселів', () => toggleOpt('snapPixel'), [], { group: 'Вигляд', check: chk('snapPixel') });
  C('smartGuides', 'Розумні напрямні', () => toggleOpt('smart'), ['Ctrl+U'], { group: 'Вигляд', check: chk('smart') });
  C('themeLight', 'Світла тема', () => setTheme('light'), [], { group: 'Вигляд', check: () => S.settings.theme === 'light' });
  C('themeDark', 'Темна тема', () => setTheme('dark'), [], { group: 'Вигляд', check: () => S.settings.theme === 'dark' });
  C('themeSystem', 'Тема як у системі', () => setTheme('system'), [], { group: 'Вигляд', check: () => S.settings.theme === 'system' });
  C('toggleUI', 'Сховати/показати панелі', () => document.body.classList.toggle('noui'), ['Ctrl+\\'], { group: 'Вигляд' });
  C('returnToSelect', 'Повертатися до виділення після малювання', () => toggleOpt('returnToSelect'), [], { group: 'Вигляд', check: chk('returnToSelect') });
  // Language (native names, never translated)
  Object.entries(O.LANGS).forEach(([code, name]) => C('lang:' + code, name, () => O.setLang(code), [], { group: 'Мова', raw: true, check: () => O.lang === code }));
  // Help
  C('shortcuts', 'Гарячі клавіші', () => shortcutsDialog(), ['Ctrl+Shift+/'], { group: 'Довідка' });
  C('about', 'Про VIBSma', () => ui.alert('VIBSma', [
    `<p style="text-align:center;margin:4px 0 14px">${O.logo(140, true)}</p>`,
    `<p><b>${esc(t('VIBSma'))}</b> — ${esc(t('векторний редактор у браузері: інтерфейс у стилі Figma та інструменти в стилі Illustrator.'))}</p>`,
    `<p>${esc(t('Документи зберігаються у файли .obrys і автоматично в браузері. Експорт: PNG, JPG, WEBP, SVG, PDF.'))}</p>`,
    `<p>${esc(t('Мови інтерфейсу: українська, англійська, російська, німецька.'))}</p>`,
    `<p>${esc(t('Бібліотеки: paper.js (булеві операції), Clipper (зміщення контурів), ImageTracer (трасування), opentype.js (криві з тексту).'))}</p>`
  ].join('')), [], { group: 'Довідка' });
  // tools as commands (palette)
  Object.entries(ui.TOOLS).forEach(([id, tl]) => C('tool:' + id, tl.label, () => O.setTool(id), tl.key ? [tl.key] : [], { group: 'Інструмент' }));

  const fontStep = d => { O.sel().filter(n => n.type === 'text').forEach(n => { n.size = Math.max(1, Math.round(n.size + d * (n.size >= 48 ? 4 : n.size >= 16 ? 2 : 1))); }); O.history.commit('Розмір шрифту'); };
  const setTheme = th => {
    S.settings.theme = th; O.saveSettings();
    if (th === 'system') delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = th;
    V.drawRulers(); O.requestRender();
  };
  const menuPaste = async inPlace => {
    try {
      const text = navigator.clipboard && navigator.clipboard.readText ? await navigator.clipboard.readText() : '';
      if (text && text.startsWith('OBRYS:')) return ops.paste(JSON.parse(text.slice(6)), { inPlace });
    } catch (e) { /* clipboard read not allowed */ }
    if (S.clipboard) ops.paste(S.clipboard, { inPlace });
    else O.toast('Буфер порожній. Скористайтеся Ctrl+V');
  };

  // ======================================================================
  // MENUS (labels are translation keys)
  // ======================================================================
  const sub = (label, items) => ({ label, items });
  const LANG_ITEMS = Object.keys(O.LANGS).map(c => 'lang:' + c);
  O.MENUS = [
    ['Файл', ['new', 'open', 'sample', '-', 'save', 'saveAs', '-', 'placeImage', 'importSVG', '-', 'exportDialog', sub('Швидкий експорт', ['exportPNG', 'exportJPG', 'exportSVG', 'exportPDF']), 'copySVG', '-', 'present']],
    ['Редагування', ['undo', 'redo', '-', 'cut', 'copy', 'paste', 'pasteInPlace', '-', 'copyStyle', 'pasteStyle', '-', 'duplicate', 'delete', '-', 'palette']],
    ['Об’єкт', [sub('Трансформація', ['transformAgain', '-', 'moveDlg', 'rotateDlg', 'reflectDlg', 'scaleDlg', 'shearDlg', 'transformEach', '-', 'flipH', 'flipV', 'rotate90', '-', 'resetBox']),
      sub('Порядок', ['bringFront', 'bringForward', 'sendBackward', 'sendBack']),
      sub('Вирівнювання', ['alignLeft', 'alignHCenter', 'alignRight', 'alignTop', 'alignVCenter', 'alignBottom', '-', 'distH', 'distV']), '-',
      'group', 'ungroup', 'frameSelection', 'autoLayout', '-',
      sub('Контур', ['editPath', 'join', 'average', '-', 'outlineStroke', 'offsetPath', '-', 'simplify', 'smooth', 'addAnchors', 'removeAnchors', 'reversePath', '-', 'splitGrid', 'cleanup']),
      sub('Булеві групи', ['boolUnion', 'boolSubtract', 'boolIntersect', 'boolExclude', '-', 'flatten']),
      sub('Обробка контурів', ['pfUnite', 'pfMinusFront', 'pfIntersect', 'pfExclude', '-', 'pfDivide', 'pfTrim', 'pfMerge', 'pfCrop', 'pfOutline', 'pfMinusBack']),
      sub('Обтравочна маска', ['makeClip', 'useAsMask', 'releaseClip']),
      sub('Складений контур', ['makeCompound', 'releaseCompound']),
      sub('Перехід', ['blendMake', 'blendOptions']),
      sub('Компоненти', ['createComponent', 'detach', 'goToComponent']), '-',
      'expand', 'rasterize', sub('Трасування зображення', ['traceDefault', 'tracePhoto', 'tracePoster', 'traceBW', 'traceSketch']), '-',
      'lock', 'unlockAll', 'hide', 'showAll']],
    ['Текст', ['createOutlines', '-', 'textOnPath', 'releaseTextPath', '-', 'fontBigger', 'fontSmaller', sub('Регістр', ['caseUpper', 'caseLower', 'caseTitle', 'caseNone']), '-', 'uploadFont', 'localFonts']],
    ['Виділення', ['selectAll', 'deselect', 'selectInverse', '-', sub('Схоже', ['sameFill', 'sameStroke', 'sameSW', 'sameOpacity', 'sameBlend', 'sameFont', 'sameType'])]],
    ['Ефект', ['fxShadow', 'fxInner', 'fxGlow', 'fxInnerGlow', 'fxBlur', '-', sub('Спотворення і трансформація', ['puckerBloat', 'roughen', 'zigzag', 'twist', 'transformEach']), sub('Стилізація', ['roundCorners']), sub('Контур', ['offsetPath', 'outlineStroke']), '-', 'rasterize']],
    ['Вигляд', ['zoomIn', 'zoomOut', 'zoom100', 'zoomFit', 'zoomSel', '-', 'outline', 'pixelPreview', '-', 'rulers', 'guides', 'lockGuides', 'deleteGuide', 'clearGuides', 'grid', '-', 'snapGrid', 'snapPixel', 'smartGuides', '-', sub('Тема', ['themeLight', 'themeDark', 'themeSystem']), sub('Мова', LANG_ITEMS), 'toggleUI', 'returnToSelect']],
    ['Довідка', ['palette', 'shortcuts', '-', 'about']]
  ];
  O.showContextMenu = (x, y) => {
    const n = O.sel();
    let items;
    if (!n.length) items = ['paste', 'pasteInPlace', '-', 'selectAll', '-', 'zoomFit', 'zoom100', '-', 'rulers', 'grid', 'outline'];
    else {
      items = ['copy', 'paste', 'cut', 'duplicate', 'delete', '-',
        sub('Порядок', ['bringFront', 'bringForward', 'sendBackward', 'sendBack']), '-',
        'group', 'ungroup', 'frameSelection', 'autoLayout', '-',
        sub('Булеві групи', ['boolUnion', 'boolSubtract', 'boolIntersect', 'boolExclude']),
        sub('Обробка контурів', ['pfUnite', 'pfMinusFront', 'pfIntersect', 'pfExclude', 'pfDivide', 'pfTrim', 'pfMerge', 'pfCrop', 'pfOutline', 'pfMinusBack']),
        'flatten', 'createOutlines', 'editPath', '-',
        'makeClip', 'useAsMask', 'releaseClip', '-',
        n.some(x2 => x2.type === 'instance') ? 'detach' : 'createComponent', '-',
        'flipH', 'flipV', 'rotate90', '-', 'copyStyle', 'pasteStyle', 'copySVG', '-', 'hide', 'lock'];
    }
    ui.menu(items, x, y);
  };

  // ======================================================================
  // DIALOGS
  // ======================================================================
  function exportDialog() {
    const sel = O.sel();
    const frames = model.page().children.some(c => c.type === 'frame');
    const what = sel.length > 1 ? t('Виділено об’єктів: {n}.', { n: sel.length }) : sel.length ? t('Буде експортовано «{name}».', { name: sel[0].name }) : frames ? t('Буде експортовано всі фрейми сторінки.') : t('Буде експортовано всю сторінку.');
    const fields = [
      { key: 'fmt', label: 'Формат', type: 'select', value: O.ls.get('expFmt', 'png'), options: [['png', 'PNG'], ['jpg', 'JPG'], ['webp', 'WEBP'], ['svg', 'SVG'], ['pdf', 'PDF (векторний)'], ['pdfprint', 'PDF через друк браузера'], ['html', 'HTML + CSS']] },
      { key: 'scale', label: 'Масштаб', type: 'select', value: String(O.ls.get('expScale', 1)), options: [['0.5', '0.5×'], ['0.75', '0.75×'], ['1', '1×'], ['1.5', '1.5×'], ['2', '2×'], ['3', '3×'], ['4', '4×']] }
    ];
    // selected objects export together by default; the page's frames stay one file per frame
    const selKey = sel.length > 1 ? 'expSelTogether' : 'expTogether';
    if (sel.length > 1 || (!sel.length && frames)) fields.push({ key: 'together', label: 'Усе в одному файлі', type: 'checkbox', value: O.ls.get(selKey, sel.length > 1) });
    fields.push({ key: 'fonts', label: 'Вбудувати шрифти', type: 'checkbox', value: O.ls.get('expFonts', true) });
    ui.dialog({
      title: 'Експорт',
      body: `<div class="dlg-text">${esc(what)} ${esc(t('Кілька файлів буде зібрано в ZIP-архів.'))}</div>`,
      fields,
      buttons: [{ id: 'ok', label: 'Експортувати', primary: true }],
      onOk: v => {
        O.ls.set('expFmt', v.fmt); O.ls.set('expScale', +v.scale); O.ls.set('expFonts', !!v.fonts);
        if (v.together !== undefined) O.ls.set(selKey, !!v.together);
        O.io.export(v.fmt, +v.scale, null, { together: !!v.together, embedFonts: !!v.fonts });
      }
    });
  }
  function shortcutsDialog() {
    const groups = new Map();
    for (const c of O.cmds.values()) {
      if (!c.keys || !c.keys.length) continue;
      const g = c.group || 'Інше';
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g).push(c);
    }
    const extra = [['Пробіл + перетягування', 'Панорамування'], ['Ctrl + коліщатко / щипок', 'Масштаб перегляду'], ['Alt + перетягування', 'Копіювати об’єкт'], ['Shift при малюванні', 'Пропорції / кути 45°'], ['Alt при малюванні', 'Від центру'], ['Ctrl + клік', 'Виділити вкладений шар'], ['Подвійний клік', 'Увійти в групу / редагувати текст / вузли'], ['Enter / Shift+Enter', 'Дочірні / батьківський шар'], ['Tab / Shift+Tab', 'Наступний / попередній шар'], ['Стрілки (+Shift)', 'Зсув на 1 (10) px'], ['1 … 0', 'Непрозорість 10 … 100%'], ['Alt (утримувати)', 'Відстані до об’єктів'], ['Ctrl + перетягування сторони', 'Нахил']];
    const tc = s => /[Ѐ-ӿ]/.test(s) ? t(s) : s;
    const html = `<div class="keys">${Array.from(groups).map(([g, list]) => `<div class="keys-g"><h4>${esc(t(g))}</h4>${list.map(c => `<div class="keys-r"><span>${esc(O.cmdLabel(c))}</span><kbd>${esc(c.keys.map(O.keyLabel).join('  /  '))}</kbd></div>`).join('')}</div>`).join('')}<div class="keys-g"><h4>${esc(t('Миша та модифікатори'))}</h4>${extra.map(([k, l]) => `<div class="keys-r"><span>${esc(t(l))}</span><kbd>${esc(O.keyLabel(tc(k)))}</kbd></div>`).join('')}</div></div>`;
    ui.dialog({ title: 'Гарячі клавіші', body: html, buttons: [{ id: 'ok', label: 'Закрити', primary: true }] });
  }

  // ======================================================================
  // PRESENT MODE
  // ======================================================================
  function present() {
    if (O.$('.present')) return;
    const frames = model.page().children.filter(n => n.type === 'frame' && n.visible !== false);
    // no frames: the whole page is one slide (InDesign shows the spread)
    const loose = model.page().children.filter(n => n.visible !== false);
    if (!frames.length && !loose.length) return O.toast('На сторінці немає фреймів для показу');
    frames.sort((a, b) => { const A = model.worldBounds(a), B = model.worldBounds(b); return Math.abs(A.y - B.y) > 40 ? A.y - B.y : A.x - B.x; });
    const slides = frames.length ? frames.map(f => [f]) : [loose];
    let i = Math.max(0, frames.findIndex(f => S.sel.includes(f.id)));
    const el = O.h(`<div class="present" role="dialog" aria-label="${esc(t('Режим презентації'))}"><div class="pr-stage"></div><div class="pr-bar"><button type="button" data-p="-1" aria-label="${esc(t('Попередній'))}">‹</button><span class="pr-n"></span><button type="button" data-p="1" aria-label="${esc(t('Наступний'))}">›</button><button type="button" data-p="x" aria-label="${esc(t('Закрити'))}" title="W / Esc">${O.icon('close', 14)}</button></div></div>`);
    document.body.appendChild(el);
    const show = () => {
      const { svg } = O.render.svg(slides[i], {});
      el.querySelector('.pr-stage').innerHTML = svg;
      el.querySelector('.pr-n').textContent = frames.length ? `${i + 1} / ${frames.length} · ${frames[i].name}` : model.page().name;
      if (frames.length) O.emit('present-slide', el.querySelector('.pr-stage'), frames[i], i);
    };
    const close = () => { el.remove(); document.removeEventListener('keydown', key, true); if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(() => {}); O.emit('present-close'); };
    const go = d => { i = O.clamp(i + d, 0, slides.length - 1); show(); };
    const key = e => {
      // removed from the page some other way: let the keys go
      if (!el.isConnected) { document.removeEventListener('keydown', key, true); return; }
      e.stopPropagation();
      if (e.key === 'Escape' || (e.code === 'KeyW' && !e.ctrlKey && !e.metaKey && !e.altKey)) { close(); e.preventDefault(); return; }
      if (e.key === 'Home') { i = 0; show(); e.preventDefault(); }
      if (e.key === 'End') { i = slides.length - 1; show(); e.preventDefault(); }
      if (['ArrowRight', 'ArrowDown', ' ', 'PageDown', 'Enter'].includes(e.key)) { go(1); e.preventDefault(); }
      if (['ArrowLeft', 'ArrowUp', 'PageUp', 'Backspace'].includes(e.key)) { go(-1); e.preventDefault(); }
    };
    document.addEventListener('keydown', key, true);
    el.addEventListener('click', e => {
      const b = e.target.closest('[data-p]');
      if (b) { if (b.dataset.p === 'x') close(); else go(+b.dataset.p); return; }
      if (e.target.closest('.pr-stage')) go(1);
    });
    if (el.requestFullscreen) el.requestFullscreen().catch(() => {});
    show();
  }

  // ======================================================================
  // KEYBOARD (physical keys, so shortcuts work in any keyboard layout)
  // ======================================================================
  const CODE = { Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']', Semicolon: ';', Quote: "'", Backslash: '\\', Comma: ',', Period: '.', Slash: '/', Backquote: '`', Space: 'Space', NumpadAdd: '=', NumpadSubtract: '-' };
  const keyName = e => {
    let k;
    // Latin layouts (QWERTZ, AZERTY…): use the printed letter, so Strg+Z on a German keyboard is Undo.
    // Non-Latin layouts (Ukrainian, Russian…): fall back to the physical key position.
    if (e.key && e.key.length === 1 && /[a-z]/i.test(e.key)) k = e.key.toUpperCase();
    else if (/^Key[A-Z]$/.test(e.code)) k = e.code.slice(3);
    else if (/^Digit\d$/.test(e.code)) k = e.code.slice(5);
    else if (/^Numpad\d$/.test(e.code)) k = e.code.slice(6);
    else if (CODE[e.code]) k = CODE[e.code];
    else k = e.key.length === 1 ? e.key.toUpperCase() : e.key;
    const parts = [];
    if (e.ctrlKey || e.metaKey) parts.push('Ctrl');
    if (e.altKey) parts.push('Alt');
    if (e.shiftKey) parts.push('Shift');
    parts.push(k);
    return parts.join('+');
  };
  const normKey = k => {
    const parts = k.split('+');
    const key = parts.pop() || '+';
    const mods = ['Ctrl', 'Alt', 'Shift'].filter(m => parts.includes(m));
    return mods.concat([key]).join('+');
  };
  const keymap = new Map();
  // a key may belong to several commands: one with `when` (e.g. «an image is selected») wins while it applies
  const whenMap = new Map();
  const buildKeymap = () => {
    keymap.clear(); whenMap.clear();
    for (const c of O.cmds.values()) for (const k of c.keys || []) {
      const nk = normKey(k);
      if (c.when) { if (!whenMap.has(nk)) whenMap.set(nk, []); whenMap.get(nk).push(c.id); }
      else if (!keymap.has(nk)) keymap.set(nk, c.id);
    }
  };
  O.keyCommand = k => {
    for (const id of whenMap.get(k) || []) { const c = O.cmds.get(id); try { if (c && c.when()) return id; } catch (e) { /* ignore */ } }
    return keymap.get(k);
  };
  let spaceDown = false;
  const isTyping = tg => tg && tg.closest && tg.closest('input, textarea, select, [contenteditable="true"]');
  const selectRelative = which => {
    const n = O.sel()[0];
    if (!n) return;
    if (which === 'children') {
      if (n.children && n.children.length) { S.enteredGroup = n.id; O.select(n.children.filter(c => !c.locked).map(c => c.id)); }
      else if (n.type === 'text') O.textEdit.start(n);
      else if (O.isEditablePath(n)) { S.edit = { id: n.id, sel: new Set() }; O.setTool('direct'); }
      return;
    }
    const par = model.parent(n);
    if (which === 'parent') { if (par && !model.isPage(par)) { O.select([par.id]); S.enteredGroup = null; } return; }
    const sibs = par.children;
    const i = sibs.indexOf(n);
    const j = which === 'next' ? (i - 1 + sibs.length) % sibs.length : (i + 1) % sibs.length;
    O.select([sibs[j].id]);
  };
  document.addEventListener('keydown', e => {
    const tg = e.target;
    if (isTyping(tg)) {
      if (tg.id === 'text-editor' && (e.key === 'Escape' || ((e.ctrlKey || e.metaKey) && e.key === 'Enter'))) { e.preventDefault(); O.textEdit.end(); }
      return;
    }
    if (O.$('.dlg-back, .pal-back, .present')) return;
    if (e.code === 'Space') {
      if (!spaceDown) { spaceDown = true; V.el.style.cursor = 'grab'; }
      e.preventDefault();
      return;
    }
    const tool = O.tools[S.tool];
    if (tool && tool.key && tool.key(e)) { e.preventDefault(); return; }
    const k = keyName(e);
    const arrows = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
    // a selected guide: Delete removes it, arrows move it, Esc deselects it
    const guide = S.guideSel !== null && S.guideSel !== undefined ? model.page().guides[S.guideSel] : null;
    if (guide) {
      if (e.key === 'Delete' || e.key === 'Backspace') { O.run('deleteGuide'); e.preventDefault(); return; }
      if (arrows[e.key] && !e.ctrlKey && !e.metaKey) {
        const d = (e.shiftKey ? 10 : 1) * (guide.axis === 'x' ? arrows[e.key][0] : arrows[e.key][1]);
        if (d) { guide.v += d; O.requestOverlay(); O.history.commit('Напрямна'); }
        e.preventDefault();
        return;
      }
      if (e.key === 'Escape') { S.guideSel = null; O.requestOverlay(); return; }
    }
    if (arrows[e.key] && !e.ctrlKey && !e.metaKey && !e.altKey) {
      const d = e.shiftKey ? 10 : 1;
      ops.nudge(arrows[e.key][0] * d, arrows[e.key][1] * d);
      e.preventDefault();
      return;
    }
    if (e.key === 'Delete' || e.key === 'Backspace') { ops.del(); e.preventDefault(); return; }
    if (e.key === 'Escape') {
      ui.closeMenus();
      if (O.ui.picker.el) { O.ui.picker.close(); return; }
      if (S.edit) { const id = S.edit.id; S.edit = null; O.setTool('select'); O.select([id]); return; }
      if (S.tool !== 'select') { O.setTool('select'); return; }
      const n = O.sel()[0];
      const par = n && model.parent(n);
      if (par && !model.isPage(par) && !(par.type === 'frame' && model.isPage(model.parent(par)))) { O.select([par.id]); S.enteredGroup = null; }
      else O.select([]);
      return;
    }
    if (k === 'Enter') { selectRelative('children'); e.preventDefault(); return; }
    if (k === 'Shift+Enter') { selectRelative('parent'); e.preventDefault(); return; }
    if (k === 'Tab' || k === 'Shift+Tab') { selectRelative(k === 'Tab' ? 'next' : 'prev'); e.preventDefault(); return; }
    if (/^[0-9]$/.test(k) && O.sel().length) {
      const v = k === '0' ? 1 : (+k) / 10;
      O.sel().forEach(n => { n.opacity = v; });
      O.history.commit('Непрозорість');
      return;
    }
    if (k === 'Ctrl+Shift+V') { O.pasteInPlace = true; return; }
    const id = O.keyCommand(k);
    if (id) {
      const c = O.cmds.get(id);
      if (c && c.native) return;
      e.preventDefault();
      O.run(id);
    }
  });
  document.addEventListener('keyup', e => {
    if (e.code === 'Space' && spaceDown) { spaceDown = false; V.el.style.cursor = (O.tools[S.tool] || {}).cursor || 'default'; }
    if (e.key === 'Alt' && S.measure) { S.measure = null; O.requestOverlay(); }
  });
  window.addEventListener('blur', () => { spaceDown = false; });

  // ======================================================================
  // POINTER INPUT
  // ======================================================================
  const mk = e => {
    const s = V.local(e);
    const hEl = e.target && e.target.closest ? e.target.closest('[data-h]') : null;
    return { e, clientX: e.clientX, clientY: e.clientY, s, p: V.toWorld(s), shift: e.shiftKey, alt: e.altKey, ctrl: e.ctrlKey || e.metaKey, h: hEl ? hEl.getAttribute('data-h') : null, button: e.button };
  };
  let dragging = false, activeTool = null, pan = null, guideDrag = null, hoverRaf = 0, lastMove = null;
  const pointers = new Map();
  const capture = (el, id) => { try { el.setPointerCapture(id); } catch (err) { /* pointer already released */ } };
  let pinch = null;
  const initPointer = () => {
    const cv = V.el;
    cv.addEventListener('pointerdown', e => {
      if (e.target.closest('#text-editor, #toolbar, #tool-options, .zoom-ctl')) return;
      ui.closeMenus();
      if (O.ui.picker.el) O.ui.picker.close();
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pointers.size === 2) {
        // pinch zoom: cancel current tool drag
        if (dragging && activeTool) { O.history.revert(); dragging = false; }
        const [a, b] = Array.from(pointers.values());
        pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2, z: V.zoom, x: V.x, y: V.y };
        return;
      }
      if (S.textEditActive && !e.target.closest('#text-editor')) O.textEdit.end(true);
      const ev = mk(e);
      if (e.button === 1 || (e.button === 0 && spaceDown) || (e.button === 0 && S.tool === 'hand')) {
        pan = { s0: ev.s, x: V.x, y: V.y };
        capture(cv, e.pointerId);
        cv.style.cursor = 'grabbing';
        e.preventDefault();
        return;
      }
      if (e.button !== 0) return;
      if (ev.h && ev.h.startsWith('guide:') && !S.settings.guidesLocked) {
        const gi = +ev.h.slice(6);
        S.guideSel = gi; S.guideDrag = gi;
        guideDrag = { i: gi };
        capture(cv, e.pointerId);
        O.requestOverlay();
        return;
      }
      if (S.guideSel !== null && S.guideSel !== undefined) { S.guideSel = null; O.requestOverlay(); }
      activeTool = O.tools[S.tool];
      capture(cv, e.pointerId);
      dragging = true;
      if (activeTool && activeTool.down) activeTool.down(ev);
      O.requestOverlay();
    });
    cv.addEventListener('pointermove', e => {
      if (pointers.has(e.pointerId)) pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pinch && pointers.size === 2) {
        const [a, b] = Array.from(pointers.values());
        const d = Math.hypot(a.x - b.x, a.y - b.y), cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2;
        const r = cv.getBoundingClientRect();
        const anchor = { x: pinch.cx - r.left, y: pinch.cy - r.top };
        const w = { x: (anchor.x - pinch.x) / pinch.z, y: (anchor.y - pinch.y) / pinch.z };
        const z = O.clamp(pinch.z * d / pinch.d, 0.02, 256);
        V.zoom = z; V.x = anchor.x - w.x * z + (cx - pinch.cx); V.y = anchor.y - w.y * z + (cy - pinch.cy);
        V.apply();
        return;
      }
      if (pan) { const s = V.local(e); V.x = pan.x + s.x - pan.s0.x; V.y = pan.y + s.y - pan.s0.y; V.apply(); return; }
      if (guideDrag) {
        const ev = mk(e), g = model.page().guides[guideDrag.i];
        if (g) { g.v = Math.round(g.axis === 'x' ? ev.p.x : ev.p.y); O.requestOverlay(); }
        return;
      }
      const ev = mk(e);
      lastMove = ev;
      if (dragging && activeTool) { if (activeTool.move) activeTool.move(ev); return; }
      const gh = ev.h && ev.h.startsWith('guide:') ? +ev.h.slice(6) : null;
      if (gh !== (S.guideHover === undefined ? null : S.guideHover)) { S.guideHover = gh; O.requestOverlay(); }
      if (!hoverRaf) hoverRaf = requestAnimationFrame(() => {
        hoverRaf = 0;
        const tl = O.tools[S.tool];
        if (lastMove && tl && tl.hover) tl.hover(lastMove);
        else if (S.hover) { S.hover = null; O.requestOverlay(); }
        O.emit('pointer', lastMove);
      });
    });
    const end = e => {
      pointers.delete(e.pointerId);
      if (pinch) { if (pointers.size < 2) pinch = null; return; }
      if (pan) { pan = null; cv.style.cursor = spaceDown ? 'grab' : ((O.tools[S.tool] || {}).cursor || 'default'); return; }
      if (guideDrag) {
        const ev = mk(e);
        const pg = model.page();
        const g = pg.guides[guideDrag.i];
        // dropping a guide back on a ruler deletes it
        if (g && ((g.axis === 'x' && ev.s.x < 22) || (g.axis === 'y' && ev.s.y < 22))) { pg.guides.splice(guideDrag.i, 1); S.guideSel = null; }
        guideDrag = null; S.guideDrag = null;
        O.history.commit('Напрямна');
        O.requestOverlay();
        return;
      }
      if (dragging) {
        dragging = false;
        if (activeTool && activeTool.up) activeTool.up(mk(e));
        activeTool = null;
        O.requestOverlay();
      }
    };
    cv.addEventListener('pointerup', end);
    cv.addEventListener('pointercancel', e => { pointers.delete(e.pointerId); pinch = null; if (dragging) { dragging = false; O.history.revert(); } pan = null; });
    cv.addEventListener('dblclick', e => {
      if (e.target.closest('#text-editor, #toolbar, #tool-options')) return;
      const tl = O.tools[S.tool];
      if (tl && tl.dblclick) tl.dblclick(mk(e));
    });
    cv.addEventListener('wheel', e => {
      if (e.target.closest('#toolbar, #tool-options')) return;
      e.preventDefault();
      const s = V.local(e);
      if (e.ctrlKey || e.metaKey) {
        const f = Math.exp(-e.deltaY * (e.deltaMode === 1 ? 0.05 : 0.0025) * (Math.abs(e.deltaY) > 50 ? 1 : 2.5));
        V.zoomBy(f, s);
      } else {
        const k = e.deltaMode === 1 ? 16 : 1;
        if (e.shiftKey && !e.deltaX) V.x -= e.deltaY * k; else { V.x -= e.deltaX * k; V.y -= e.deltaY * k; }
        V.apply();
      }
    }, { passive: false });
    cv.addEventListener('contextmenu', e => {
      e.preventDefault();
      if (e.target.closest('#toolbar, #tool-options, #text-editor')) return;
      const gEl = e.target.closest && e.target.closest('[data-h^="guide:"]');
      if (gEl) {
        S.guideSel = +gEl.getAttribute('data-h').slice(6);
        O.requestOverlay();
        ui.menu(['deleteGuide', 'clearGuides', '-', 'lockGuides'], e.clientX, e.clientY);
        return;
      }
      const id = V.hitLeaf(e.clientX, e.clientY);
      const tg = id ? V.pick(id, e.ctrlKey || e.metaKey) : null;
      if (tg && !S.sel.includes(tg.id)) O.select([tg.id]);
      if (!tg && !S.edit) O.select([]);
      O.showContextMenu(e.clientX, e.clientY);
    });
    cv.addEventListener('pointerleave', () => { if (!dragging && S.hover) { S.hover = null; O.requestOverlay(); } });
    // rulers -> new guides
    for (const [id, axis] of [['#ruler-x', 'y'], ['#ruler-y', 'x']]) {
      const r = O.$(id);
      r.addEventListener('pointerdown', e => {
        e.preventDefault();
        e.stopPropagation();
        const pg = model.page();
        const ev = mk(e);
        pg.guides.push({ axis, v: Math.round(axis === 'x' ? ev.p.x : ev.p.y) });
        guideDrag = { i: pg.guides.length - 1 };
        S.guideSel = S.guideDrag = pg.guides.length - 1;
        S.settings.guides = true;
        capture(cv, e.pointerId);
        O.requestOverlay();
      });
    }
    O.$('#ruler-corner').addEventListener('dblclick', () => O.run('clearGuides'));
  };

  // ======================================================================
  // SAMPLE DOCUMENT (created in the current language)
  // ======================================================================
  function sampleDoc() {
    const prevDoc = S.doc;
    const doc = model.newDoc();
    doc.name = t('Приклад — VIBSma');
    S.doc = doc;
    const pg = doc.pages[0];
    const P = O.paint;
    const T = (x, y) => M.translate(x, y);
    // Poster frame
    const poster = model.create('frame', { name: t('Постер (приклад)'), w: 600, h: 800, m: T(0, 0), fills: [{ type: 'linear', visible: true, opacity: 1, from: { x: 0.5, y: 0 }, to: { x: 0.5, y: 1 }, stops: [{ o: 0, color: '#1D1B4B', a: 1 }, { o: 0.62, color: '#6B3A8C', a: 1 }, { o: 1, color: '#F2A35E', a: 1 }] }] });
    const sun = model.create('ellipse', { name: t('Сонце'), w: 230, h: 230, m: T(185, 300), fills: [{ type: 'radial', visible: true, opacity: 1, from: { x: 0.5, y: 0.45 }, to: { x: 1, y: 0.45 }, stops: [{ o: 0, color: '#FFE29A', a: 1 }, { o: 0.7, color: '#FFB357', a: 1 }, { o: 1, color: '#FF7A59', a: 1 }] }], effects: [{ type: 'glow', x: 0, y: 0, blur: 40, spread: 0, color: '#FFB357', opacity: 0.55, visible: true }] });
    const ring = model.create('text', { name: t('Текст по колу'), text: t('КРИВІ БЕЗЬЄ · БУЛЕВІ ОПЕРАЦІЇ · ГРАДІЄНТИ · МАСКИ ·'), size: 14, weight: 700, ls: 2.5, fills: [P.solid('#FFFFFF', 0.9)], path: (() => { const e = G.ellipseSub(290, 290)[0]; return [{ closed: true, pts: [e.pts[3], e.pts[0], e.pts[1], e.pts[2]] }]; })(), pathOffset: 2, m: T(155, 270) });
    const far = model.create('path', { name: t('Далекі гори'), fills: [P.solid('#4A2D6E')], strokes: [], subpaths: [{ closed: true, pts: [G.pt(0, 560), G.pt(90, 470), G.pt(160, 520), G.pt(260, 430), G.pt(360, 515), G.pt(450, 455), G.pt(600, 540), G.pt(600, 800), G.pt(0, 800)] }] });
    const near = model.create('path', { name: t('Близькі гори'), fills: [P.solid('#2A1B47')], strokes: [], subpaths: [{ closed: true, pts: [G.pt(0, 640), G.pt(120, 560, null, { x: 150, y: 540 }), G.pt(230, 600, { x: 200, y: 560 }, null), G.pt(330, 540), G.pt(470, 620), G.pt(600, 580), G.pt(600, 800), G.pt(0, 800)] }] });
    const wave = model.create('path', { name: t('Хвиля'), fills: [], strokes: [P.solid('#FFD8A8', 0.9)], sw: 3, cap: 'round', subpaths: [{ closed: false, pts: [G.pt(40, 720, null, { x: 100, y: 690 }), G.pt(180, 720, { x: 120, y: 750 }, { x: 240, y: 690 }), G.pt(320, 720, { x: 260, y: 750 }, { x: 380, y: 690 }), G.pt(460, 720, { x: 400, y: 750 }, { x: 520, y: 690 }), G.pt(560, 720, { x: 540, y: 740 }, null)] }] });
    const title = model.create('text', { name: t('VIBSma'), text: t('VIBSma'), size: 104, weight: 800, align: 'center', width: 600, fills: [P.solid('#FFFFFF')], m: T(0, 70), effects: [{ type: 'shadow', x: 0, y: 6, blur: 18, spread: 0, color: '#120A2A', opacity: 0.45, visible: true }] });
    const subt = model.create('text', { name: t('Підзаголовок'), text: t('Векторний редактор у браузері'), size: 24, weight: 400, align: 'center', width: 600, ls: 0.5, fills: [P.solid('#FFFFFF', 0.85)], m: T(0, 195) });
    const s1 = model.create('star', { name: t('Зірка {n}', { n: 1 }), w: 26, h: 26, points: 4, inner: 0.35, m: T(80, 140), fills: [P.solid('#FFFFFF', 0.9)] });
    const s2 = model.create('star', { name: t('Зірка {n}', { n: 2 }), w: 16, h: 16, points: 4, inner: 0.35, m: T(500, 260), fills: [P.solid('#FFFFFF', 0.8)] });
    const s3 = model.create('star', { name: t('Зірка {n}', { n: 3 }), w: 20, h: 20, points: 5, inner: 0.45, m: T(470, 110), fills: [P.solid('#FFE29A')] });
    poster.children.push(sun, far, near, ring, wave, title, subt, s1, s2, s3);
    pg.children.push(poster);
    // Button component
    const btnLabel = model.create('text', { name: t('Підпис'), text: t('Почати'), size: 17, weight: 600, fills: [P.solid('#FFFFFF')] });
    const btn = model.create('frame', { name: t('Кнопка'), component: true, w: 160, h: 48, radius: 12, m: T(1100, 0), fills: [P.solid('#0D99FF')], layout: { dir: 'h', gap: 8, pad: [14, 24, 14, 24], align: 'center', justify: 'center', wMode: 'hug', hMode: 'hug' }, clip: false });
    btn.children.push(btnLabel);
    pg.children.push(btn);
    // Mobile frame with auto-layout list
    const phone = model.create('frame', { name: t('Мобільний екран (приклад)'), w: 393, h: 852, radius: 0, m: T(660, 0), fills: [P.solid('#F7F7FB')] });
    const hello = model.create('text', { name: t('Привіт'), text: t('Добрий день!'), size: 30, weight: 700, fills: [P.solid('#1E1E2E')], m: T(24, 72) });
    const hint = model.create('text', { name: t('Опис'), text: t('Цей екран зібрано з фреймів, автолейауту та екземплярів компонента «Кнопка».'), size: 15, width: 345, lh: 1.4, fills: [P.solid('#5B5B6E')], m: T(24, 120) });
    const list = model.create('frame', { name: t('Список (автолейаут)'), w: 345, h: 300, m: T(24, 200), fills: [], clip: false, layout: { dir: 'v', gap: 12, pad: [0, 0, 0, 0], align: 'start', justify: 'start', wMode: 'fixed', hMode: 'hug' } });
    const card = (t1, t2, color) => {
      const c = model.create('frame', { name: t('Картка'), w: 345, h: 76, radius: 14, fills: [P.solid('#FFFFFF')], effects: [{ type: 'shadow', x: 0, y: 2, blur: 10, spread: 0, color: '#1E1E2E', opacity: 0.08, visible: true }] });
      const dot = model.create('ellipse', { name: t('Значок'), w: 44, h: 44, m: T(16, 16), fills: [P.solid(color)] });
      const a = model.create('text', { name: t1, text: t1, size: 16, weight: 600, fills: [P.solid('#1E1E2E')], m: T(74, 16) });
      const b = model.create('text', { name: t2, text: t2, size: 13, fills: [P.solid('#7A7A8C')], m: T(74, 42) });
      c.children.push(dot, a, b);
      return c;
    };
    list.children.push(card(t('Перо та криві'), t('Вузли, маркери, ножиці'), '#FF7A59'), card(t('Обробка контурів'), t('Розділити, обрізати, злити'), '#0D99FF'), card(t('Текст по контуру'), t('Шрифти, криві з тексту'), '#14AE5C'));
    const inst1 = model.create('instance', { name: t('Кнопка'), ref: btn.id, w: 160, h: 48, m: T(24, 760) });
    phone.children.push(hello, hint, list, inst1);
    pg.children.push(phone);
    const note = model.create('text', { name: t('Підказка'), text: t('Це приклад. Створіть новий документ: Файл → Новий (Ctrl+Alt+N).') + '\n' + t('Швидкі дії: Ctrl+/'), size: 14, lh: 1.5, fills: [P.solid('#8A8A9A')], m: T(1100, 90) });
    pg.children.push(note);
    S.doc = prevDoc;
    return doc;
  }
  O.sampleDoc = sampleDoc;

  // ======================================================================
  // INIT
  // ======================================================================
  const applyThemeAttr = () => { const th = S.settings.theme; if (th && th !== 'system') document.documentElement.dataset.theme = th; };
  O.on('settings', () => {
    const st = O.$('#stage');
    st.classList.toggle('outline', !!S.settings.outline);
    st.setAttribute('shape-rendering', S.settings.pixelPreview ? 'crispEdges' : 'auto');
    V.drawRulers(); O.requestOverlay();
  });
  O.on('change', () => {
    const pg = model.page();
    O.$('#canvas').style.setProperty('--page-bg', pg.bg || 'var(--canvas)');
    O.$('#doc-name').textContent = S.doc.name;
    O.$('#page-name').textContent = pg.name;
    O.requestRender();
    V.drawRulers();
  });
  O.on('selection', () => { O.requestOverlay(); V.drawRulers(); });
  O.on('page', () => { model.reindex(); O.emit('change'); O.emit('selection'); setTimeout(() => V.fit(null, 80, 1), 0); });
  O.on('zoom', () => { const z = O.$('#zoom-val'); if (z) z.textContent = Math.round(V.zoom * 100) + '%'; });
  O.on('pointer', ev => { const c = O.$('#coords'); if (c && ev) c.textContent = `${Math.round(ev.p.x)}, ${Math.round(ev.p.y)}`; });
  O.on('saved', () => { const s = O.$('#save-state'); if (s) { s.textContent = t('Збережено в браузері'); s.classList.add('on'); clearTimeout(s._t); s._t = setTimeout(() => s.classList.remove('on'), 1600); } });
  O.on('lang', () => { const b = O.$('#lang-code'); if (b) b.textContent = O.lang.toUpperCase(); O.requestOverlay(); });

  async function init() {
    applyThemeAttr();
    O.applyI18n();
    V.el = O.$('#canvas');
    ui.menubar(O.$('#menubar'), O.MENUS);
    ui.buildToolbar(O.$('#toolbar'));
    ui.buildToolOptions(O.$('#tool-options'));
    O.panels.initLeft();
    O.panels.initAssets();
    O.panels.initRight();
    buildKeymap();
    initPointer();
    O.io.initClipboard();
    O.io.initDrop(V.el);
    O.$('#text-editor').addEventListener('input', e => O.textEdit.input(e));
    // formatting in the Design panel, the menus or a text dialog keeps the text in edit mode (typeui.js decides)
    O.$('#text-editor').addEventListener('blur', () => setTimeout(() => { if (S.textEdit && document.activeElement !== O.$('#text-editor') && !(O.typeui && O.typeui.keepEditing())) O.textEdit.end(); }, 120));
    // top bar
    O.$('#btn-menu').addEventListener('click', e => {
      const r = e.currentTarget.getBoundingClientRect();
      ui.menu(O.MENUS.map(([label, items]) => ({ label, items })), r.left, r.bottom + 4);
    });
    O.$('#doc-name').addEventListener('click', e => {
      const span = e.currentTarget;
      const inp = document.createElement('input');
      inp.className = 'rename doc'; inp.value = S.doc.name;
      span.replaceWith(inp); inp.focus(); inp.select();
      const done = ok => { if (ok && inp.value.trim()) { S.doc.name = inp.value.trim(); O.history.commit('Назва документа'); } inp.replaceWith(span); span.textContent = S.doc.name; };
      inp.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.key === 'Enter') done(true); if (ev.key === 'Escape') done(false); });
      inp.addEventListener('blur', () => { if (inp.isConnected) done(true); });
    });
    O.$('#btn-export').addEventListener('click', () => O.run('exportDialog'));
    O.$('#btn-projects').addEventListener('click', () => O.run('projects'));
    O.$('#btn-present').addEventListener('click', () => O.run('present'));
    O.$('#btn-theme').addEventListener('click', () => {
      const dark = document.documentElement.dataset.theme === 'dark' || (!document.documentElement.dataset.theme && matchMedia('(prefers-color-scheme: dark)').matches);
      setTheme(dark ? 'light' : 'dark');
    });
    O.$('#btn-lang').addEventListener('click', e => {
      const r = e.currentTarget.getBoundingClientRect();
      ui.menu(LANG_ITEMS, r.right - 200, r.bottom + 4);
    });
    O.$('#lang-code').textContent = O.lang.toUpperCase();
    O.$('#zoom-btn').addEventListener('click', e => {
      const r = e.currentTarget.getBoundingClientRect();
      ui.menu(['zoomIn', 'zoomOut', '-', 'zoomFit', 'zoomSel', 'zoom100', '-', { id: 'z50', label: '50%', raw: true }, { id: 'z200', label: '200%', raw: true }, { id: 'z400', label: '400%', raw: true }, '-', 'rulers', 'grid', 'outline', 'pixelPreview'], r.right - 230, r.bottom + 4, { onPick: id => { if (id === 'z50') V.setZoom(0.5); else if (id === 'z200') V.setZoom(2); else if (id === 'z400') V.setZoom(4); else O.run(id); } });
    });
    O.$('#btn-left').addEventListener('click', () => { document.body.classList.toggle('show-left'); document.body.classList.remove('show-right'); });
    O.$('#btn-right').addEventListener('click', () => { document.body.classList.toggle('show-right'); document.body.classList.remove('show-left'); });
    O.$('#btn-palette').addEventListener('click', () => ui.palette());
    new ResizeObserver(() => { V.drawRulers(); O.requestOverlay(); O.textEdit.sync(); }).observe(V.el);
    window.addEventListener('beforeunload', () => { try { O.io.autosave(); } catch (e) { /* ignore */ } });
    // Blender-style workspace (areas) — before the document so the canvas has its final size
    if (O.layout) O.layout.init();
    // document
    const params = new URLSearchParams(location.search);
    let restored = null;
    if (!params.has('selftest') && !params.has('fresh') && O.projects) restored = await O.projects.boot();
    if (restored && restored.pages && restored.pages.length) model.load(restored);
    else model.load(sampleDoc());
    O.emit('settings');
    O.setTool('select');
    V.fit(null, 80, 1);
    if (params.has('selftest')) setTimeout(() => O.selftest && O.selftest(), 50);
  }
  O.init = init;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
