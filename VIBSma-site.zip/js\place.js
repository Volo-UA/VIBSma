'use strict';
/* VIBSma — InDesign placement of photos:
   • the loaded «place gun» (File → Place photo, Ctrl+Alt+Shift+I): the cursor carries the photos; drag to draw a
     frame (the photo fills it proportionally, Shift keeps the photo's proportions), click to place at the photo's
     own size, click into an empty frame or shape to put the photo into it. Esc drops the rest.
   • Live Corners: the yellow square on a selected frame / rectangle switches on corner handles; drag a yellow
     diamond to round all corners, Shift-drag rounds only that corner. */
(function () {
  const O = window.O, M = O.M, model = O.model, S = O.state, V = O.view, io = O.io, PF = O.photo;
  const t = (s, v) => O.t(s, v), esc = O.esc, n_ = O.n;
  const PG = O.placeGun = { queue: [], el: null };

  // ======================================================================
  // place gun
  // ======================================================================
  const SHAPES = ['frame', 'rect', 'ellipse', 'polygon', 'star', 'path'];
  // an empty frame or a plain shape under the pointer takes the photo (never an artboard, never a photo)
  const emptyTargetAt = e => {
    for (const id of V.hitAll(e.clientX, e.clientY)) {
      for (let n = model.get(id); n && !model.isPage(n); n = model.parent(n)) {
        if (n.photo || PF.isFrame(n) || n.gframe) break;
        if (n.type === 'frame' && !V.isTopFrame(n) && !(n.children || []).length) return n;
        if (n.type !== 'frame' && SHAPES.includes(n.type) && !(n.fills || []).some(f => f.type === 'image')) return n;
        if (n.type === 'frame') break;
      }
    }
    return null;
  };
  const frameAt = (x, y, w, h, name) => {
    const c = { x: x + w / 2, y: y + h / 2 };
    const cont = V.containerAt(c);
    const lp = M.apply(M.inv(model.containerMatrix(cont)), { x, y });
    const f = model.create('frame', { name, w: Math.max(1, Math.round(w)), h: Math.max(1, Math.round(h)), m: M.translate(Math.round(lp.x), Math.round(lp.y)), fills: [], clip: true });
    model.insert(f, cont);
    return f;
  };
  const cursorHTML = () => {
    const a = PG.queue[0];
    return a ? `<img src="${esc(O.assetURL(a.id))}" alt=""><b>${PG.queue.length}</b>` : '';
  };
  PG.stop = () => {
    PG.queue = [];
    if (PG.el) { PG.el.remove(); PG.el = null; }
    if (PG.cur) { PG.cur.remove(); PG.cur = null; }
    document.removeEventListener('keydown', PG.onKey, true);
    window.removeEventListener('pointermove', PG.follow, true);
  };
  PG.onKey = e => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); PG.stop(); O.toast('Розміщення скасовано'); } };
  PG.follow = e => { if (PG.cur) { PG.cur.style.left = e.clientX + 14 + 'px'; PG.cur.style.top = e.clientY + 14 + 'px'; } };
  // files → assets, then the cursor is loaded
  PG.start = async files => {
    const list = [];
    for (const f of files) {
      try { const a = await io.addAsset(await io.blobToData(f), f.name.replace(/\.[^.]+$/, '')); list.push({ id: a.id, w: a.w, h: a.h, name: f.name.replace(/\.[^.]+$/, '') }); }
      catch (e) { O.toast('Не вдалося відкрити «{name}»', { name: f.name }); }
    }
    if (!list.length) return;
    PG.stop();
    PG.queue = list;
    O.select([]);
    PG.el = O.h(`<div class="pg-layer" title="${esc(t('Тягніть, щоб намалювати фрейм; клік — фото в його розмірі; клік у порожній фрейм — фото в нього. Esc — скасувати'))}"><div class="pg-rect"></div></div>`);
    V.el.appendChild(PG.el);
    PG.cur = O.h(`<div class="pg-cur">${cursorHTML()}</div>`);
    document.body.appendChild(PG.cur);
    document.addEventListener('keydown', PG.onKey, true);
    window.addEventListener('pointermove', PG.follow, true);
    const rectEl = PG.el.querySelector('.pg-rect');
    let drag = null;
    const box = (e, shift) => {
      const p = V.toWorld(V.local(e)), a = PG.queue[0];
      let w = p.x - drag.p0.x, h = p.y - drag.p0.y;
      if (shift && a && a.w && a.h) { const k = Math.max(Math.abs(w) / a.w, Math.abs(h) / a.h); w = Math.sign(w || 1) * a.w * k; h = Math.sign(h || 1) * a.h * k; }
      return { x: Math.min(drag.p0.x, drag.p0.x + w), y: Math.min(drag.p0.y, drag.p0.y + h), w: Math.abs(w), h: Math.abs(h) };
    };
    PG.el.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      e.preventDefault(); e.stopPropagation();
      try { PG.el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      drag = { p0: V.toWorld(V.local(e)), x0: e.clientX, y0: e.clientY };
    });
    PG.el.addEventListener('pointermove', e => {
      e.stopPropagation();
      if (!drag) return;
      const b = box(e, e.shiftKey), s0 = V.toScreen(b);
      Object.assign(rectEl.style, { display: 'block', left: s0.x + 'px', top: s0.y + 'px', width: b.w * V.zoom + 'px', height: b.h * V.zoom + 'px' });
    });
    PG.el.addEventListener('pointerup', e => {
      e.stopPropagation();
      if (!drag) return;
      const a = PG.queue[0], isClick = Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) < 4;
      const b = box(e, e.shiftKey);
      const p0 = drag.p0;
      drag = null;
      rectEl.style.display = 'none';
      if (!a) return PG.stop();
      let gf;
      const target = isClick ? emptyTargetAt(e) : null;
      if (target) gf = PF.putInto(target, a.id, 'fill');
      else if (isClick) {
        // the photo's own size (at most 60 % of the view), its top-left corner at the click
        const vr = V.viewRect(), k = Math.min(1, vr.w * 0.6 / a.w, vr.h * 0.6 / a.h);
        gf = PF.putInto(frameAt(p0.x, p0.y, a.w * k, a.h * k, a.name), a.id, 'fill');
      } else gf = PF.putInto(frameAt(b.x, b.y, Math.max(2, b.w), Math.max(2, b.h), a.name), a.id, 'fill');
      PG.queue.shift();
      O.select([gf.id]);
      O.history.commit('Помістити фото');
      if (PG.queue.length) { PG.cur.innerHTML = cursorHTML(); O.toast('Ще фото в курсорі: {n}. Esc — скасувати', { n: PG.queue.length }); }
      else PG.stop();
    });
    O.toast('Тягніть, щоб намалювати фрейм для фото, або клацніть. Фото в курсорі: {n}', { n: list.length });
  };
  // «Place photo»: photos into the selected frames / shapes as before, otherwise the loaded cursor
  {
    const orig = PF.place;
    PF.place = async () => {
      if (O.topSel().some(n => PF.isFrame(n) || SHAPES.includes(n.type))) return orig();
      const files = await io.pickFiles('image/*,' + io.EXTRA_MEDIA, true);
      if (files.length) PG.start(files);
    };
  }
  O.on('page', () => PG.stop());

  // ======================================================================
  // drag a photo onto a frame → the frame's photo is replaced (Canva-like)
  // ======================================================================
  const imgFill = n => (n && n.fills || []).find(f => f.type === 'image');
  // the photo a dragged object carries: a graphic frame's photo or an image-filled shape (not the content inside a frame)
  const photoOf = n => {
    if (!n || n.photo) return null;
    const f = imgFill(PF.isFrame(n) ? PF.contentOf(n) : n);
    return f && S.doc.assets[f.asset] ? f.asset : null;
  };
  // what takes the photo under the pointer: a graphic frame, an empty frame (not an artboard) or an image-filled shape
  const photoTargetAt = (x, y, skip) => {
    for (const id of V.hitAll(x, y)) {
      if (skip.has(id)) continue;
      for (let n = model.get(id); n && !model.isPage(n); n = model.parent(n)) {
        if (skip.has(n.id) || n.locked) break;
        if (PF.isFrame(n)) return n;
        // the photo / mask shape of a graphic frame: climb to the frame
        if (n.photo || n.gframe) continue;
        if (n.type === 'frame') { if (!V.isTopFrame(n) && !(n.children || []).length) return n; break; }
        if (SHAPES.includes(n.type) && imgFill(n)) return n;
      }
    }
    return null;
  };
  const putPhoto = (target, assetId) => {
    if (PF.isFrame(target) || target.type === 'frame') return PF.putInto(target, assetId);
    imgFill(target).asset = assetId;
    return target;
  };
  const allIds = nodes => { const s = new Set(); model.walk(nodes, n => { s.add(n.id); }); return s; };
  const setHover = id => { if (S.hover !== id) { S.hover = id; O.requestOverlay(); } };

  // on the canvas: drag one photo (Alt — a copy) and release it over a frame
  {
    const sel = O.tools.select, origMove = sel.move, origUp = sel.up;
    sel.move = function (ev) {
      origMove.call(this, ev);
      const d = this.drag;
      if (!d || d.kind !== 'move' || !d.moved || d.nodes.length !== 1 || !photoOf(d.nodes[0])) return;
      const tg = photoTargetAt(ev.clientX, ev.clientY, allIds(d.nodes));
      d.photoTarget = tg ? tg.id : null;
      setHover(d.photoTarget);
    };
    sel.up = function (ev) {
      const d = this.drag;
      const tg = d && d.kind === 'move' && d.moved && d.photoTarget ? model.get(d.photoTarget) : null;
      const src = tg && d.nodes[0], asset = photoOf(src);
      if (!asset) { if (d && d.photoTarget) setHover(null); return origUp.call(this, ev); }
      this.drag = null;
      O.snap.clear();
      S.hover = null;
      model.remove(src);
      const gf = putPhoto(tg, asset);
      O.select([gf.id]);
      O.history.commit('Заміна фото');
      O.requestRender();
    };
  }

  // from the desktop / another site: a photo dropped on a frame goes into it (the io drop handler asks here first)
  io.dropTarget = e => (V.el && V.el.contains(e.target) ? photoTargetAt(e.clientX, e.clientY, new Set()) : null);
  io.dropInto = async (target, file) => {
    let a;
    try { a = await io.addAsset(await io.blobToData(file), file.name.replace(/\.[^.]+$/, '')); }
    catch (e) { O.toast('Не вдалося відкрити «{name}»', { name: file.name }); return false; }
    if (!model.exists(target.id)) return false;
    const gf = putPhoto(target, a.id);
    O.select([gf.id]);
    O.history.commit('Заміна фото');
    return true;
  };
  // the frame under a dragged file is highlighted (V.el exists only after init, so the listeners sit on the document)
  document.addEventListener('dragover', e => {
    if (!Array.from((e.dataTransfer && e.dataTransfer.types) || []).includes('Files')) return;
    const tg = io.dropTarget(e);
    setHover(tg ? tg.id : null);
  });
  document.addEventListener('dragleave', e => { if (V.el && !V.el.contains(e.relatedTarget) && S.hover) setHover(null); });

  // ======================================================================
  // Live Corners
  // ======================================================================
  let liveId = null, cdrag = null, layer = null;
  const DIRS = [[1, 1], [-1, 1], [-1, -1], [1, -1]]; // TL, TR, BR, BL — inwards
  const radii = n => { const r = n.radius || 0; return Array.isArray(r) ? r.slice(0, 4).map(v => +v || 0) : [r, r, r, r]; };
  const cornerNode = () => {
    const sel = O.sel();
    if (sel.length !== 1 || PG.el) return null;
    let n = sel[0];
    if (n.photo) { const p = model.parent(n); if (p && p.gframe) n = p; }
    if (!n || n.locked || !['rect', 'frame'].includes(n.type) || model.pageOf(n) !== model.page()) return null;
    return n;
  };
  const ensureLayer = () => {
    if (layer && layer.isConnected) return layer;
    layer = O.h('<div id="lc-layer"></div>');
    V.el.appendChild(layer);
    layer.addEventListener('pointerdown', e => {
      const b = e.target.closest('[data-lc]');
      if (!b) return;
      e.preventDefault(); e.stopPropagation();
      const n = model.get(b.dataset.n);
      if (!n) return;
      if (b.dataset.lc === 'tog') { liveId = liveId === n.id ? null : n.id; O.requestRender(); return; }
      // the diamonds are redrawn while dragging, so the drag listens on the window
      cdrag = { n, i: +b.dataset.lc, r0: radii(n), x0: e.clientX, y0: e.clientY, P: M.inv(model.worldMatrix(n)) };
      window.addEventListener('pointermove', move, true);
      window.addEventListener('pointerup', end, true);
      window.addEventListener('pointercancel', end, true);
    });
    const move = e => {
      if (!cdrag) return;
      e.stopPropagation();
      const { n, i, r0 } = cdrag;
      const ld = M.applyV(cdrag.P, { x: (e.clientX - cdrag.x0) / V.zoom, y: (e.clientY - cdrag.y0) / V.zoom });
      const [dx, dy] = DIRS[i];
      const r = O.clamp(Math.round(r0[i] + (ld.x * dx + ld.y * dy) / 2), 0, Math.floor(Math.min(n.w, n.h) / 2));
      const all = e.shiftKey ? r0.map((v, k) => (k === i ? r : v)) : [r, r, r, r];
      n.radius = all.every(v => v === all[0]) ? all[0] : all;
      O.requestRender();
    };
    const end = e => {
      window.removeEventListener('pointermove', move, true);
      window.removeEventListener('pointerup', end, true);
      window.removeEventListener('pointercancel', end, true);
      if (!cdrag) return;
      e.stopPropagation();
      cdrag = null;
      O.history.commit('Заокруглення кутів');
    };
    return layer;
  };
  O.overlayHooks.push(() => {
    if (!S.doc || !V.el) return '';
    const L = ensureLayer();
    const n = cornerNode();
    let h = '';
    if (n) {
      const W = model.worldMatrix(n), scr = p => V.toScreen(M.apply(W, p));
      const c = [scr({ x: 0, y: 0 }), scr({ x: n.w, y: 0 }), scr({ x: n.w, y: n.h }), scr({ x: 0, y: n.h })];
      const sw = Math.hypot(c[1].x - c[0].x, c[1].y - c[0].y), sh = Math.hypot(c[3].x - c[0].x, c[3].y - c[0].y);
      if (sw > 50 && sh > 50) {
        // the yellow square on the right edge, a little below the top corner
        const k = Math.min(0.25, 26 / sh), tg = { x: c[1].x + (c[2].x - c[1].x) * k, y: c[1].y + (c[2].y - c[1].y) * k };
        const on = liveId === n.id;
        h += `<button type="button" class="lc-tog${on ? ' on' : ''}" data-lc="tog" data-n="${n.id}" style="left:${n_(tg.x)}px;top:${n_(tg.y)}px" title="${esc(t(on ? 'Сховати кутові маркери' : 'Кути: клацніть, потім тягніть жовті ромби (Shift — один кут)'))}" aria-label="${esc(t('Заокруглення кутів'))}"></button>`;
        if (on) {
          const r = radii(n), pts = [[0, 0], [n.w, 0], [n.w, n.h], [0, n.h]];
          r.forEach((rv, i) => {
            const [dx, dy] = DIRS[i];
            const cs = c[i];
            let p = scr({ x: pts[i][0] + dx * rv, y: pts[i][1] + dy * rv });
            // keep the diamond off the corner handle when the radius is small
            const dl = Math.hypot(p.x - cs.x, p.y - cs.y);
            if (dl < 14) { const u = scr({ x: pts[i][0] + dx, y: pts[i][1] + dy }), ul = Math.hypot(u.x - cs.x, u.y - cs.y) || 1; p = { x: cs.x + (u.x - cs.x) / ul * 14, y: cs.y + (u.y - cs.y) / ul * 14 }; }
            h += `<button type="button" class="lc-d" data-lc="${i}" data-n="${n.id}" style="left:${n_(p.x)}px;top:${n_(p.y)}px" title="${esc(t('Радіус {r} px. Тягніть; Shift — лише цей кут', { r: Math.round(rv) }))}" aria-label="${esc(t('Заокруглення кутів'))}"></button>`;
          });
        }
      }
    }
    if (L.innerHTML !== h) L.innerHTML = h;
    return '';
  });
})();
