'use strict';
/* VIBSma — projects: unlimited projects stored in the browser, project manager, templates, version history, libraries */
(function () {
  const O = window.O, M = O.M, model = O.model, S = O.state, V = O.view, ui = O.ui, idb = O.idb;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const P = O.projects = {};
  const params = new URLSearchParams(location.search);
  P.disabled = params.has('selftest');
  const AUTO_VERSION_MS = 10 * 60 * 1000, MAX_AUTO_VERSIONS = 30;
  let lastAutoVersion = Date.now(), lastAutoData = '';

  // ---------- storage ----------
  // Asset data (photos, video, audio) is stored once per asset in «adata» under "projectId/assetId";
  // the project JSON keeps only references (ext: true), so saving after every change stays fast.
  const AKEY = (pid, aid) => pid + '/' + aid;
  const stored = new Set();
  P.pack = (doc, pid) => {
    const assets = {}, pending = [];
    let bytes = 0;
    for (const [id, a] of Object.entries(doc.assets || {})) {
      if (!a) continue;
      if (typeof a.data === 'string' && a.data.length > 2048) {
        const key = AKEY(pid, id);
        if (!stored.has(key)) pending.push([key, a.data]);
        bytes += a.data.length;
        const meta = Object.assign({}, a); delete meta.data; meta.ext = true;
        assets[id] = meta;
      } else assets[id] = a;
    }
    const json = JSON.stringify(Object.assign({}, doc, { assets, savedAt: new Date().toISOString() }));
    return { json, pending, bytes };
  };
  P.writeAssets = async pending => { for (const [key, data] of pending) { await idb.put('adata', data, key); stored.add(key); } };
  // put the asset data back into a stored document (older projects keep their data inline)
  P.hydrate = async (doc, pid) => {
    for (const [id, a] of Object.entries((doc && doc.assets) || {})) {
      if (!a || !a.ext || a.data) continue;
      const key = AKEY(pid, id);
      try { const data = await idb.get('adata', key); if (data) { a.data = data; delete a.ext; stored.add(key); } } catch (e) { /* missing */ }
    }
    return doc;
  };
  P.readDoc = async id => { const data = await idb.get('pdata', id); return data ? P.hydrate(JSON.parse(data), id) : null; };
  const adataRange = pid => IDBKeyRange.bound(pid + '/', pid + '/￿');
  P.list = async () => (await idb.all('projects')).sort((a, b) => (b.updated || 0) - (a.updated || 0));
  P.saveNow = async () => {
    if (P.disabled || !S.doc) return;
    if (!S.projectId) S.projectId = O.uid();
    const pid = S.projectId;
    const { json: data, pending, bytes } = P.pack(S.doc, pid);
    await P.writeAssets(pending);
    const meta = (await idb.get('projects', pid)) || { id: pid, created: Date.now() };
    meta.name = S.doc.name; meta.updated = Date.now(); meta.size = data.length + bytes; meta.pages = S.doc.pages.length;
    await idb.put('pdata', data, pid);
    await idb.put('projects', meta);
    O.ls.set('project', S.projectId);
    if (Date.now() - lastAutoVersion > AUTO_VERSION_MS && data !== lastAutoData) {
      lastAutoVersion = Date.now(); lastAutoData = data;
      P.saveVersion('', true).catch(() => {});
    }
    P.thumbSoon();
    O.emit('saved');
  };
  P.save = O.debounce(() => { P.saveNow().catch(e => console.warn(e)); }, 800);
  // thumbnail of the first page (or current page)
  P.makeThumb = async () => {
    const pg = S.doc.pages[0] || model.page();
    const nodes = pg.children.filter(n => n.visible !== false);
    if (!nodes.length) return '';
    const prev = S.pageId; S.pageId = pg.id;
    try {
      let b = model.selBounds(nodes);
      if (!b || b.w <= 0 || b.h <= 0) return '';
      const scale = Math.min(1, 320 / Math.max(b.w, b.h));
      // small copies of the photos: decoding full-size images for a 320 px thumbnail froze the editor
      const ids = new Set();
      model.walk(nodes, n => { for (const f of n.fills || []) if (f.type === 'image') ids.add(f.asset); if (n.type === 'raster' && n.asset) ids.add(n.asset); });
      const small = new Map();
      for (const id of ids) small.set(id, await O.assetPreview(id, 480));
      const { canvas } = await O.io.renderImage(nodes, { scale, type: 'image/png', assetURL: id => small.get(id) || '', embedFonts: false });
      return canvas.toDataURL('image/webp', 0.8);
    } catch (e) { return ''; } finally { S.pageId = prev; }
  };
  P.thumbSoon = O.debounce(async () => {
    if (P.disabled || !S.projectId) return;
    try {
      const thumb = await P.makeThumb();
      const meta = await idb.get('projects', S.projectId);
      if (meta) { meta.thumb = thumb; await idb.put('projects', meta); }
    } catch (e) { /* ignore */ }
  }, 4000);

  // first load: last project, legacy autosave, or a new example project
  P.boot = async () => {
    if (P.disabled) return null;
    try {
      const list = await P.list();
      const want = O.ls.get('project', null);
      const pick = list.find(p => p.id === want) || list[0];
      if (pick) {
        const doc = await P.readDoc(pick.id);
        if (doc) { S.projectId = pick.id; return doc; }
      }
      const legacy = await O.io.restore();
      if (legacy && legacy.pages) { S.projectId = O.uid(); return legacy; }
    } catch (e) { console.warn(e); }
    S.projectId = O.uid();
    return null;
  };
  P.open = async id => {
    if (id === S.projectId) { P.closeManager(); return; }
    await P.saveNow().catch(() => {});
    const doc = await P.readDoc(id);
    if (!doc) { O.toast('Проєкт не знайдено'); return; }
    S.projectId = id;
    O.ls.set('project', id);
    model.load(doc);
    setTimeout(() => V.fit(null, 80, 1), 0);
    P.closeManager();
  };
  P.createFrom = async doc => {
    await P.saveNow().catch(() => {});
    S.projectId = O.uid();
    model.load(doc);
    await P.saveNow().catch(() => {});
    setTimeout(() => V.fit(null, 80, 1), 0);
    P.closeManager();
    O.toast('Створено проєкт «{name}»', { name: doc.name });
  };
  P.rename = async (id, name) => {
    const meta = await idb.get('projects', id);
    if (!meta) return;
    meta.name = name;
    if (id === S.projectId) { S.doc.name = name; O.history.commit('Назва документа'); }
    else {
      const data = await idb.get('pdata', id);
      if (data) { const d = JSON.parse(data); d.name = name; await idb.put('pdata', JSON.stringify(d), id); }
    }
    await idb.put('projects', meta);
  };
  P.duplicate = async id => {
    if (id === S.projectId) await P.saveNow();
    const d = await P.readDoc(id), meta = await idb.get('projects', id);
    if (!d || !meta) return;
    const nid = O.uid();
    d.name = (d.name || meta.name) + ' (' + t('копія') + ')';
    const pk = P.pack(d, nid);
    await P.writeAssets(pk.pending);
    await idb.put('pdata', pk.json, nid);
    await idb.put('projects', Object.assign({}, meta, { id: nid, name: d.name, created: Date.now(), updated: Date.now() }));
  };
  P.remove = async id => {
    await idb.del('pdata', id);
    await idb.del('projects', id);
    try { await idb.delRange('adata', adataRange(id)); } catch (e) { /* ignore */ }
    for (const k of Array.from(stored)) if (k.startsWith(id + '/')) stored.delete(k);
    try { for (const v of await idb.byIndex('versions', 'project', id)) await idb.del('versions', v.id); } catch (e) { /* ignore */ }
    if (id === S.projectId) {
      const rest = await P.list();
      if (rest.length) { S.projectId = null; await P.openDirect(rest[0].id); }
      else { S.projectId = O.uid(); model.load(model.newDoc()); await P.saveNow(); }
    }
  };
  P.openDirect = async id => {
    const doc = await P.readDoc(id);
    if (!doc) return;
    S.projectId = id; O.ls.set('project', id);
    model.load(doc);
    setTimeout(() => V.fit(null, 80, 1), 0);
  };
  // a portable .obrys file: every photo, video and sound inside
  P.fileData = async id => {
    if (id === S.projectId) { await P.saveNow(); return O.io.serialize(); }
    const doc = await P.readDoc(id);
    return doc ? JSON.stringify(doc) : null;
  };
  const fileName = s => String(s || 'obrys').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 80) || 'obrys';
  P.download = async id => {
    const data = await P.fileData(id), meta = await idb.get('projects', id);
    if (!data) return;
    O.download(new Blob([data], { type: 'application/json' }), fileName(meta && meta.name) + '.obrys');
  };
  // all projects in one ZIP of .obrys files (to move them to another computer or browser)
  P.downloadAll = async () => {
    const list = await P.list();
    if (!list.length) return O.toast('Проєктів немає');
    O.toast('Пакування {n} проєктів…', { n: list.length });
    const files = [];
    for (const p of list) { const data = await P.fileData(p.id); if (data) files.push({ name: fileName(p.name) + '.obrys', blob: new Blob([data], { type: 'application/json' }) }); }
    O.download(await O.io.zip(files), t('Проєкти VIBSma') + ' ' + new Date().toISOString().slice(0, 10) + '.zip');
    O.toast('Збережено проєктів: {n}', { n: files.length });
  };
  // .obrys / .json → a new project (never replaces the open one)
  P.importDocFile = async f => {
    let doc = null;
    try { doc = JSON.parse(await f.text()); } catch (e) { /* not JSON */ }
    if (!doc || !Array.isArray(doc.pages)) { O.toast('«{name}» — це не документ VIBSma', { name: f.name }); return false; }
    doc.name = doc.name && doc.name !== 'Без назви' ? doc.name : f.name.replace(/\.(obrys|json)$/i, '');
    await P.createFrom(doc);
    return true;
  };
  // a ZIP of .obrys files (from «Download all projects»)
  P.importZip = async f => {
    const entries = O.interop && O.interop.unzip ? O.interop.unzip(new Uint8Array(await f.arrayBuffer())) : {};
    let n = 0;
    for (const [name, e] of Object.entries(entries)) {
      if (!/\.(obrys|json)$/i.test(name)) continue;
      try { const doc = JSON.parse(new TextDecoder().decode(e.data)); if (doc && doc.pages) { doc.name = doc.name || name.replace(/\.(obrys|json)$/i, ''); await P.createFrom(doc); n++; } } catch (err) { /* skip */ }
    }
    O.toast(n ? 'Імпортовано проєктів: {n}' : 'В архіві немає файлів .obrys', { n });
    return n;
  };
  P.importFiles = async () => {
    const files = await O.io.pickFiles('.obrys,.json,.zip,.svg,.psd,.fig,.pdf,image/*,video/*,audio/*,' + O.io.EXTRA_MEDIA, true);
    await P.importAny(files);
  };
  // files dropped on (or picked in) the project manager: projects become projects, everything else a new project with it
  P.importAny = async files => {
    for (const f of files) {
      if (/\.(obrys|json)$/i.test(f.name)) await P.importDocFile(f);
      else if (/\.zip$/i.test(f.name)) await P.importZip(f);
      else {
        const doc = model.newDoc();
        doc.name = f.name.replace(/\.[a-z0-9]+$/i, '');
        await P.createFrom(doc);
        await O.io.openFile(f);
        setTimeout(() => V.fit(null, 80, 4), 50);
      }
    }
  };

  // ---------- templates ----------
  const framesDoc = (name, list, opts = {}) => {
    const prev = S.doc;
    const doc = model.newDoc();
    doc.name = name;
    S.doc = doc;
    let x = 0;
    for (const [fname, w, h] of list) {
      const f = model.create('frame', { name: fname, w, h, m: M.translate(x, 0), fills: [O.paint.solid(opts.bg || '#FFFFFF')] });
      doc.pages[0].children.push(f);
      x += w + (opts.gap || 80);
    }
    if (opts.after) opts.after(doc);
    S.doc = prev;
    return doc;
  };
  P.templates = [
    { id: 'blank', name: 'Порожній проєкт', icon: 'page', make: () => { const d = model.newDoc(); d.name = t('Без назви'); return d; } },
    { id: 'sample', name: 'Приклад', icon: 'star', make: () => O.sampleDoc() },
    { id: 'mobile', name: 'Мобільний застосунок', icon: 'frame', size: '393×852', make: () => framesDoc(t('Мобільний застосунок'), [1, 2, 3].map(n => [t('Екран {n}', { n }), 393, 852])) },
    { id: 'web', name: 'Вебсайт', icon: 'frame', size: '1440×1024', make: () => framesDoc(t('Вебсайт'), [[t('Головна'), 1440, 1024], [t('Сторінка {n}', { n: 2 }), 1440, 1024]]) },
    { id: 'a4', name: 'Постер A4', icon: 'page', size: '595×842', make: () => framesDoc(t('Постер A4'), [['A4', 595, 842]]) },
    { id: 'slides', name: 'Презентація 16:9', icon: 'play', size: '1920×1080', make: () => framesDoc(t('Презентація 16:9'), [1, 2, 3].map(n => [t('Слайд {n}', { n }), 1920, 1080]), { gap: 120 }) },
    { id: 'insta', name: 'Пост Instagram', icon: 'image', size: '1080×1350', make: () => framesDoc(t('Пост Instagram'), [[t('Пост'), 1080, 1350]]) }
  ];
  P.framesDoc = framesDoc;
  P.newDialog = () => {
    const back = O.h(`<div class="dlg-back"><div class="dlg wide" role="dialog" aria-modal="true" aria-label="${esc(t('Новий проєкт'))}">
      <div class="dlg-h"><span>${esc(t('Новий проєкт'))}</span><button type="button" class="ib" data-x="1" aria-label="${esc(t('Закрити'))}">${O.icon('close', 14)}</button></div>
      <div class="dlg-b"><div class="tpl-grid">${P.templates.map(tp => `<button type="button" class="tpl" data-tpl="${tp.id}"><span class="tpl-ic">${O.icon(tp.icon || 'page', 26)}</span><span class="tpl-n">${esc(t(tp.name))}</span>${tp.size ? `<em>${tp.size}</em>` : ''}</button>`).join('')}</div></div>
    </div></div>`);
    document.body.appendChild(back);
    const close = () => back.remove();
    back.addEventListener('click', async e => {
      if (e.target === back || e.target.closest('[data-x]')) return close();
      const b = e.target.closest('[data-tpl]');
      if (!b) return;
      const tp = P.templates.find(x => x.id === b.dataset.tpl);
      close();
      // a template may ask questions first (e.g. which devices) and resolve with null when cancelled
      const doc = await tp.make();
      if (doc) await P.createFrom(doc);
    });
    back.addEventListener('keydown', e => { if (e.key === 'Escape') { e.stopPropagation(); close(); } });
    setTimeout(() => { const f = back.querySelector('.tpl'); if (f) f.focus(); }, 0);
  };

  // ---------- project manager ----------
  let pmEl = null;
  P.closeManager = () => { if (pmEl) { pmEl.remove(); pmEl = null; } };
  const ago = ts => {
    const s = Math.round((ts - Date.now()) / 1000);
    const rtf = new Intl.RelativeTimeFormat(O.lang, { numeric: 'auto' });
    const a = Math.abs(s);
    if (a < 60) return rtf.format(s, 'second');
    if (a < 3600) return rtf.format(Math.round(s / 60), 'minute');
    if (a < 86400) return rtf.format(Math.round(s / 3600), 'hour');
    if (a < 86400 * 30) return rtf.format(Math.round(s / 86400), 'day');
    return new Date(ts).toLocaleDateString(O.lang);
  };
  const fmtSize = b => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
  P.openManager = async () => {
    await P.saveNow().catch(() => {});
    P.closeManager();
    pmEl = O.h(`<div class="pm-back"><div class="pm" role="dialog" aria-modal="true" aria-label="${esc(t('Проєкти'))}">
      <div class="pm-h"><h2>${esc(t('Проєкти'))}</h2>
        <input type="search" class="pm-q" placeholder="${esc(t('Пошук проєктів'))}" aria-label="${esc(t('Пошук проєктів'))}">
        <select class="pm-sort" aria-label="${esc(t('Сортування'))}"><option value="recent">${esc(t('Нещодавні'))}</option><option value="name">${esc(t('За назвою'))}</option><option value="created">${esc(t('Нові спочатку'))}</option></select>
        <span class="sp"></span>
        <button type="button" class="btn" data-a="import" title="${esc(t('Файли .obrys, ZIP з проєктами, фото, відео, PDF… Їх також можна просто перетягнути у вікно'))}">${O.icon('download', 14)} ${esc(t('Імпортувати файл…'))}</button>
        <button type="button" class="btn" data-a="figma" title="${esc(t('Вставте посилання на файл Figma — він стане новим проєктом'))}">${O.icon('link', 14)} ${esc(t('Figma за посиланням'))}</button>
        <button type="button" class="btn" data-a="exportall" title="${esc(t('Усі проєкти з фото й відео в одному ZIP — щоб перенести на інший комп’ютер чи в інший браузер'))}">${O.icon('copy', 14)} ${esc(t('Завантажити всі'))}</button>
        <button type="button" class="btn primary" data-a="new">${O.icon('plus', 14)} ${esc(t('Новий проєкт'))}</button>
        <button type="button" class="ib" data-a="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 16)}</button></div>
      <div class="pm-grid" role="list"></div>
      <div class="pm-f"><span class="pm-usage"></span><span class="pm-tip">${esc(t('Перетягніть сюди файли .obrys, ZIP або фото'))}</span><button type="button" class="link" data-a="persist">${esc(t('Зберігати проєкти назавжди'))}</button></div>
    </div></div>`);
    document.body.appendChild(pmEl);
    const grid = pmEl.querySelector('.pm-grid'), q = pmEl.querySelector('.pm-q'), sortSel = pmEl.querySelector('.pm-sort');
    sortSel.value = O.ls.get('pmSort', 'recent');
    let all = await P.list();
    const render = () => {
      const s = q.value.trim().toLowerCase();
      let list = all.filter(p => !s || String(p.name || '').toLowerCase().includes(s));
      if (sortSel.value === 'name') list.sort((a, b) => String(a.name).localeCompare(String(b.name), O.lang));
      else if (sortSel.value === 'created') list.sort((a, b) => (b.created || 0) - (a.created || 0));
      grid.innerHTML = list.map(p => `<div class="pm-card${p.id === S.projectId ? ' cur' : ''}" role="listitem" data-p="${p.id}">
          <button type="button" class="pm-th" data-a="open" aria-label="${esc(t('Відкрити'))} ${esc(p.name)}">${p.thumb ? `<img src="${p.thumb}" alt="">` : O.icon('frame', 36)}</button>
          <div class="pm-meta"><div class="pm-n" title="${esc(p.name)}">${esc(p.name || t('Без назви'))}</div><div class="pm-d">${esc(t('Змінено'))} ${esc(ago(p.updated || p.created || Date.now()))} · ${fmtSize(p.size || 0)}</div></div>
          ${p.id === S.projectId ? `<span class="pm-badge">${esc(t('Відкрито'))}</span>` : ''}
          <button type="button" class="ib pm-more" data-a="more" aria-label="${esc(t('Дії з проєктом'))}">${O.icon('more', 16)}</button>
        </div>`).join('') || `<div class="pm-empty">${esc(t('Проєктів не знайдено'))}</div>`;
    };
    render();
    q.addEventListener('input', () => {
      // a Figma link pasted into the search box imports that file
      const v = q.value.trim();
      if (O.formats && /figma\.com\//i.test(v) && O.formats.parseFigmaURL(v)) { P.closeManager(); O.formats.figmaDialog({ url: v }); return; }
      render();
    });
    sortSel.addEventListener('change', () => { O.ls.set('pmSort', sortSel.value); render(); });
    const refresh = async () => { all = await P.list(); render(); };
    pmEl.addEventListener('click', async e => {
      if (e.target === pmEl) return P.closeManager();
      const a = e.target.closest('[data-a]');
      if (!a) return;
      const card = e.target.closest('[data-p]'), id = card && card.dataset.p;
      const act = a.dataset.a;
      if (act === 'close') P.closeManager();
      if (act === 'new') P.newDialog();
      if (act === 'import') { P.closeManager(); P.importFiles(); }
      if (act === 'exportall') P.downloadAll();
      if (act === 'figma' && O.formats) { P.closeManager(); O.formats.figmaDialog(); }
      if (act === 'persist') {
        try { const ok = navigator.storage && navigator.storage.persist && await navigator.storage.persist(); O.toast(ok ? 'Сховище закріплено: браузер не видалить проєкти' : 'Браузер не дозволив закріпити сховище'); } catch (err) { /* ignore */ }
      }
      if (act === 'open') P.open(id);
      if (act === 'more') {
        const r = a.getBoundingClientRect();
        ui.menu([{ id: 'open', label: 'Відкрити' }, { id: 'rename', label: 'Перейменувати' }, { id: 'dup', label: 'Дублювати' }, { id: 'dl', label: 'Завантажити файл .obrys' }, '-', { id: 'del', label: 'Видалити проєкт' }], r.left - 160, r.bottom + 4, {
          onPick: async m => {
            const meta = all.find(p => p.id === id);
            if (m === 'open') P.open(id);
            if (m === 'rename') ui.dialog({ title: 'Перейменувати', fields: [{ key: 'n', label: 'Назва', type: 'text', value: meta.name || '' }], onOk: async v => { if (v.n.trim()) { await P.rename(id, v.n.trim()); refresh(); } } });
            if (m === 'dup') { await P.duplicate(id); refresh(); }
            if (m === 'dl') P.download(id);
            if (m === 'del') ui.dialog({ title: 'Видалити проєкт', body: `<div class="dlg-text">${esc(t('Видалити проєкт «{name}»? Цю дію не можна скасувати.', { name: meta.name }))}</div>`, buttons: [{ id: 'ok', label: 'Видалити', primary: true }], onOk: async () => { await P.remove(id); refresh(); } });
          }
        });
      }
    });
    pmEl.addEventListener('keydown', e => { if (e.key === 'Escape' && !O.$('.dlg-back')) { e.stopPropagation(); P.closeManager(); } });
    try {
      if (navigator.storage && navigator.storage.estimate) {
        const est = await navigator.storage.estimate();
        const pers = navigator.storage.persisted ? await navigator.storage.persisted() : false;
        const u = pmEl && pmEl.querySelector('.pm-usage');
        if (u) u.textContent = t('Проєктів: {n} · використано {used} із {quota}', { n: all.length, used: fmtSize(est.usage || 0), quota: fmtSize(est.quota || 0) }) + (pers ? ' · ' + t('сховище закріплено') : '');
      }
    } catch (e) { /* ignore */ }
    setTimeout(() => q.focus(), 0);
  };

  // ---------- version history ----------
  P.saveVersion = async (label, auto) => {
    if (P.disabled) return;
    if (!S.projectId) await P.saveNow();
    // versions reference the project's stored photos instead of copying them every time
    const pk = P.pack(S.doc, S.projectId);
    await P.writeAssets(pk.pending);
    const data = pk.json;
    await idb.put('versions', { id: O.uid(), projectId: S.projectId, label: label || '', auto: !!auto, created: Date.now(), data, size: data.length });
    if (auto) {
      const autos = (await idb.byIndex('versions', 'project', S.projectId)).filter(v => v.auto).sort((a, b) => b.created - a.created);
      for (const v of autos.slice(MAX_AUTO_VERSIONS)) await idb.del('versions', v.id);
    }
  };
  P.versionDialog = async () => {
    await P.saveNow().catch(() => {});
    const versions = (await idb.byIndex('versions', 'project', S.projectId)).sort((a, b) => b.created - a.created);
    const row = v => `<div class="ver" data-v="${v.id}"><div class="ver-m"><b>${esc(v.label || (v.auto ? t('Автозбереження') : t('Версія')))}</b><span>${esc(new Date(v.created).toLocaleString(O.lang))} · ${fmtSize(v.size || 0)}</span></div>
      <button type="button" class="btn" data-va="restore">${esc(t('Відновити'))}</button><button type="button" class="btn" data-va="copy">${esc(t('Як копію'))}</button><button type="button" class="ib" data-va="del" aria-label="${esc(t('Видалити'))}">${O.icon('trash', 14)}</button></div>`;
    const d = ui.dialog({
      title: 'Історія версій',
      body: `<div class="ver-new"><input id="ver-label" type="text" placeholder="${esc(t('Назва нової версії'))}" aria-label="${esc(t('Назва нової версії'))}"><button type="button" class="btn primary" data-va="save">${esc(t('Зберегти версію'))}</button></div><div class="ver-list">${versions.map(row).join('') || `<div class="dlg-text">${esc(t('Версій ще немає. Автоматичні версії зберігаються кожні 10 хвилин роботи.'))}</div>`}</div>`,
      buttons: [{ id: 'ok', label: 'Закрити', primary: true }]
    });
    d.el.querySelector('.dlg').classList.add('wide');
    d.el.addEventListener('click', async e => {
      const b = e.target.closest('[data-va]');
      if (!b) return;
      e.stopPropagation();
      const act = b.dataset.va;
      if (act === 'save') {
        const label = d.el.querySelector('#ver-label').value.trim() || t('Версія від {date}', { date: new Date().toLocaleString(O.lang) });
        await P.saveVersion(label, false);
        d.close(); P.versionDialog(); O.toast('Версію збережено');
        return;
      }
      const vid = b.closest('[data-v]').dataset.v;
      const v = versions.find(x => x.id === vid);
      if (act === 'restore') {
        await P.saveVersion(t('Перед відновленням'), true);
        const doc = await P.hydrate(JSON.parse(v.data), S.projectId);
        model.load(doc);
        await P.saveNow();
        d.close(); O.toast('Версію відновлено');
        setTimeout(() => V.fit(null, 80, 1), 0);
      }
      if (act === 'copy') {
        const doc = await P.hydrate(JSON.parse(v.data), S.projectId);
        doc.name = (doc.name || '') + ' — ' + (v.label || new Date(v.created).toLocaleString(O.lang));
        d.close();
        await P.createFrom(doc);
      }
      if (act === 'del') { await idb.del('versions', vid); b.closest('[data-v]').remove(); }
    });
  };

  // ---------- libraries (components and colors from other projects) ----------
  const withDoc = (doc, fn) => {
    const prev = S.doc, prevPage = S.pageId;
    S.doc = doc; S.pageId = doc.pages[0].id; model.reindex();
    try { return fn(); } finally { S.doc = prev; S.pageId = prevPage; model.reindex(); }
  };
  P.libraryDialog = async () => {
    await P.saveNow().catch(() => {});
    const others = (await P.list()).filter(p => p.id !== S.projectId);
    const d = ui.dialog({
      title: 'Бібліотеки',
      body: `<div class="lib"><div class="lib-side">${others.map(p => `<button type="button" class="lib-p" data-lp="${p.id}">${esc(p.name || t('Без назви'))}</button>`).join('') || `<div class="dlg-text">${esc(t('Інших проєктів немає. Створіть проєкт із компонентами, і він стане бібліотекою.'))}</div>`}</div><div class="lib-main"><div class="dlg-text">${esc(t('Оберіть проєкт ліворуч, щоб побачити його компоненти та кольори.'))}</div></div></div>`,
      buttons: [{ id: 'ok', label: 'Закрити', primary: true }]
    });
    d.el.querySelector('.dlg').classList.add('wide');
    let lib = null;
    d.el.addEventListener('click', async e => {
      const pbtn = e.target.closest('[data-lp]');
      if (pbtn) {
        e.stopPropagation();
        d.el.querySelectorAll('.lib-p').forEach(x => x.classList.toggle('on', x === pbtn));
        const ldoc = await P.readDoc(pbtn.dataset.lp);
        if (!ldoc) return;
        lib = { id: pbtn.dataset.lp, doc: ldoc };
        const comps = [];
        lib.doc.pages.forEach(pg => model.walk(pg.children, n => { if (n.type === 'frame' && n.component) comps.push(n); }));
        const thumbs = withDoc(lib.doc, () => comps.map(c => { try { return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(O.render.svg([c], {}).svg); } catch (err) { return ''; } }));
        d.el.querySelector('.lib-main').innerHTML = `<h4>${esc(t('Компоненти'))}</h4><div class="as-grid lib-grid">${comps.map((c, i) => `<button type="button" class="as-comp" data-lc="${c.id}"><span class="as-th">${thumbs[i] ? `<img src="${thumbs[i]}" alt="">` : ''}</span><span>${esc(c.name)}</span></button>`).join('') || `<div class="dlg-text">${esc(t('У цьому проєкті немає компонентів'))}</div>`}</div>
          <h4>${esc(t('Кольори'))}</h4><div class="as-sw">${(lib.doc.swatches || []).map(s => `<span class="sw big" style="--c:${s.color}" title="${esc(s.name)} ${s.color}"></span>`).join('')}</div>
          <button type="button" class="btn" data-lcol="1">${esc(t('Додати кольори в цей проєкт'))}</button>`;
        return;
      }
      const cbtn = e.target.closest('[data-lc]');
      if (cbtn && lib) { e.stopPropagation(); P.insertLibraryComponent(lib, cbtn.dataset.lc); return; }
      if (e.target.closest('[data-lcol]') && lib) {
        e.stopPropagation();
        const have = new Set((S.doc.swatches || []).map(s => s.color));
        let added = 0;
        for (const s of lib.doc.swatches || []) if (!have.has(s.color)) { S.doc.swatches.push({ id: O.uid(), name: s.name, color: s.color }); added++; }
        O.history.commit('Кольори бібліотеки');
        O.toast('Додано кольорів: {n}', { n: added });
      }
    });
  };
  // copy a component (and components it uses) from a library project, then insert an instance
  P.insertLibraryComponent = (lib, compId) => {
    const map = S.doc.libraryMap || (S.doc.libraryMap = {});
    const byId = id => { let f = null; lib.doc.pages.forEach(pg => model.walk(pg.children, n => { if (!f && n.id === id) f = n; })); return f; };
    let libPage = S.doc.pages.find(p => p.libraryOf === lib.id);
    const copyComp = id => {
      const key = lib.id + ':' + id;
      if (map[key] && model.exists(map[key])) return map[key];
      const src = byId(id);
      if (!src) return null;
      if (!libPage) {
        libPage = model.newPage(t('Бібліотека: {name}', { name: lib.doc.name || '' }));
        libPage.libraryOf = lib.id;
        S.doc.pages.push(libPage);
      }
      const c = model.cloneNode(src);
      // remap nested instances to copied components, copy image assets
      model.walk([c], n => {
        if (n.type === 'instance' && n.ref) { const r = copyComp(n.ref); if (r) n.ref = r; }
        for (const f of n.fills || []) if (f.type === 'image' && lib.doc.assets && lib.doc.assets[f.asset]) S.doc.assets[f.asset] = lib.doc.assets[f.asset];
      });
      const x = libPage.children.reduce((m, n) => Math.max(m, (model.worldBounds(n) || { x: 0, w: 0 }).x + (model.worldBounds(n) || { w: 0 }).w + 60), 0);
      c.m = M.translate(x, 0);
      libPage.children.push(c);
      model.reindex();
      map[key] = c.id;
      return c.id;
    };
    const newId = copyComp(compId);
    model.reindex();
    if (newId) O.ops.insertInstance(newId);
    O.toast('Компонент додано з бібліотеки');
  };

  // ---------- commands & menus ----------
  O.cmd('projects', 'Усі проєкти…', () => P.openManager(), { keys: ['Ctrl+Alt+O'], group: 'Файл' });
  O.cmd('new', 'Новий проєкт…', () => P.newDialog(), { keys: ['Ctrl+Alt+N'], group: 'Файл' });
  O.cmd('saveVersion', 'Зберегти версію…', () => ui.dialog({ title: 'Зберегти версію', fields: [{ key: 'l', label: 'Назва версії', type: 'text', value: '' }], buttons: [{ id: 'ok', label: 'Зберегти', primary: true }], onOk: async v => { await P.saveVersion(v.l.trim() || t('Версія від {date}', { date: new Date().toLocaleString(O.lang) }), false); O.toast('Версію збережено'); } }), { keys: ['Ctrl+Alt+S'], group: 'Файл' });
  O.cmd('versionHistory', 'Історія версій…', () => P.versionDialog(), { group: 'Файл' });
  O.cmd('libraries', 'Бібліотеки…', () => P.libraryDialog(), { keys: ['Alt+3'], group: 'Ресурси' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл')[1];
  fileMenu.splice(0, fileMenu.indexOf('open'), 'projects', 'new');
  fileMenu.splice(fileMenu.indexOf('saveAs') + 1, 0, 'saveVersion', 'versionHistory', '-', 'libraries');
})();
