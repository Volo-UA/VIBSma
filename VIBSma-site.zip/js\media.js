'use strict';
/* VIBSma — media: photos in every format the browser can decode (+ HEIC, TIFF, camera RAW previews),
   video and audio clips on the canvas, project background music, playback in presentation mode,
   <video>/<audio> in the HTML export, and a slideshow video export (WebM / MP4) with music.
   A clip is a rectangle whose fill is its poster frame (or waveform); n.media points to the clip asset. */
(function () {
  const O = window.O, M = O.M, R = O.R, model = O.model, S = O.state, V = O.view, ui = O.ui, io = O.io;
  const t = (s, v) => O.t(s, v), esc = O.esc, n_ = O.n;
  const MD = O.media = {};
  const VIDEO_RE = /\.(mp4|m4v|webm|mov|mkv|ogv|avi|wmv|flv|3gp|mpg|mpeg|ts|mts)$/i;
  const AUDIO_RE = /\.(mp3|wav|ogg|oga|opus|m4a|aac|flac|weba|wma|aiff?|mid|midi)$/i;
  const HEIC_RE = /\.(heic|heif)$/i;
  const TIFF_RE = /\.(tiff?|dng|cr2|cr3|nef|arw|orf|rw2|raf)$/i;
  const BIG = 150 * 1048576;
  const kindOf = f => (/^video\//.test(f.type) || VIDEO_RE.test(f.name || '') ? 'video' : /^audio\//.test(f.type) || AUDIO_RE.test(f.name || '') ? 'audio' : null);
  const fmtTime = s => { if (!isFinite(s)) return '—'; s = Math.max(0, Math.round(s)); const m = Math.floor(s / 60); return m + ':' + String(s % 60).padStart(2, '0'); };
  const baseName = f => (f.name || '').replace(/\.[a-z0-9]+$/i, '') || t('Медіа');
  // data URL with a usable MIME type (some systems give video files an empty type)
  const MIME = { mp4: 'video/mp4', m4v: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime', mkv: 'video/x-matroska', ogv: 'video/ogg', avi: 'video/x-msvideo', wmv: 'video/x-ms-wmv', flv: 'video/x-flv', '3gp': 'video/3gpp', mpg: 'video/mpeg', mpeg: 'video/mpeg', ts: 'video/mp2t', mts: 'video/mp2t', mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', weba: 'audio/webm', wma: 'audio/x-ms-wma', aif: 'audio/aiff', aiff: 'audio/aiff', mid: 'audio/midi', midi: 'audio/midi' };
  const toData = async file => {
    const ext = ((file.name || '').split('.').pop() || '').toLowerCase();
    const type = file.type || MIME[ext] || 'application/octet-stream';
    const blob = file.type ? file : new Blob([file], { type });
    return io.blobToData(blob);
  };

  // ---------- posters ----------
  const posterCanvas = (w, h, draw) => { const cv = document.createElement('canvas'); cv.width = w; cv.height = h; draw(cv.getContext('2d'), w, h); return cv; };
  const placeholder = (kind, name, w = 640, h = 360) => posterCanvas(w, h, (c) => {
    const g = c.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#26262E'); g.addColorStop(1, '#3A3A48');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
    c.fillStyle = 'rgba(255,255,255,.85)'; c.font = '600 22px Inter, system-ui, sans-serif'; c.textAlign = 'center';
    c.fillText(kind === 'video' ? '🎬' : '♪', w / 2, h / 2 - 8);
    c.font = '500 15px Inter, system-ui, sans-serif'; c.fillStyle = 'rgba(255,255,255,.7)';
    c.fillText(String(name).slice(0, 60), w / 2, h / 2 + 22);
  });
  // first useful frame of a video (1 s in, or a third of a short clip)
  const videoPoster = url => new Promise(res => {
    const v = document.createElement('video');
    v.muted = true; v.preload = 'auto'; v.playsInline = true; v.crossOrigin = 'anonymous';
    let done = false;
    const fail = () => { if (!done) { done = true; res(null); } };
    const tm = setTimeout(fail, 15000);
    v.onerror = fail;
    v.onloadedmetadata = () => { try { v.currentTime = Math.min(1, (v.duration || 0) / 3); } catch (e) { fail(); } };
    v.onseeked = () => {
      if (done) return;
      try {
        const w = v.videoWidth || 640, h = v.videoHeight || 360;
        const k = Math.min(1, 1600 / Math.max(w, h));
        const cv = posterCanvas(Math.round(w * k), Math.round(h * k), (c, W, H) => c.drawImage(v, 0, 0, W, H));
        done = true; clearTimeout(tm);
        res({ canvas: cv, w, h, duration: v.duration });
      } catch (e) { fail(); }
    };
    v.src = url;
  });
  // waveform of an audio clip
  const audioInfo = async file => {
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      const ac = new AC();
      const buf = await ac.decodeAudioData(await file.arrayBuffer());
      ac.close && ac.close();
      const ch = buf.getChannelData(0), bars = 120, step = Math.floor(ch.length / bars) || 1;
      const peaks = [];
      for (let i = 0; i < bars; i++) { let m = 0; for (let j = i * step; j < Math.min(ch.length, (i + 1) * step); j += 16) m = Math.max(m, Math.abs(ch[j])); peaks.push(m); }
      return { peaks, duration: buf.duration };
    } catch (e) { return null; }
  };
  const waveform = (name, info, w = 960, h = 192) => posterCanvas(w, h, (c) => {
    c.fillStyle = '#1E1E24'; c.fillRect(0, 0, w, h);
    const pk = info ? info.peaks : Array.from({ length: 120 }, (_, i) => 0.25 + 0.2 * Math.sin(i / 3));
    const max = Math.max(0.01, ...pk), bw = (w - 220) / pk.length;
    const g = c.createLinearGradient(200, 0, w, 0); g.addColorStop(0, '#0D99FF'); g.addColorStop(1, '#9747FF');
    c.fillStyle = g;
    pk.forEach((p, i) => { const bh = Math.max(4, (p / max) * (h - 56)); c.fillRect(200 + i * bw, h / 2 - bh / 2, Math.max(2, bw - 3), bh); });
    c.fillStyle = '#0D99FF'; c.beginPath(); c.arc(96, h / 2, 54, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#fff'; c.beginPath(); c.moveTo(80, h / 2 - 26); c.lineTo(80, h / 2 + 26); c.lineTo(122, h / 2); c.closePath(); c.fill();
    c.font = '600 22px Inter, system-ui, sans-serif'; c.fillStyle = '#fff'; c.textAlign = 'left';
    c.fillText(String(name).slice(0, 48), 200, 34);
    c.font = '500 18px Inter, system-ui, sans-serif'; c.fillStyle = '#A6A6B4';
    c.fillText(info ? fmtTime(info.duration) : '', 200, h - 16);
  });
  const addPoster = async (cv, name) => {
    const data = cv.toDataURL('image/jpeg', 0.86);
    return io.addAsset(data, name + ' — ' + t('обкладинка'));
  };

  // ---------- import ----------
  MD.importMedia = async (file, at) => {
    const kind = kindOf(file);
    if (!kind) return null;
    if (file.size > BIG) O.toast('Великий файл ({mb} МБ): проєкт зберігатиметься повільніше', { mb: Math.round(file.size / 1048576) });
    else O.toast(kind === 'video' ? 'Додаю відео…' : 'Додаю аудіо…');
    const name = baseName(file);
    const data = await toData(file);
    const id = O.uid();
    let info = null, poster, w, h, playable = true;
    if (kind === 'video') {
      const url = URL.createObjectURL(file);
      info = await videoPoster(url);
      URL.revokeObjectURL(url);
      if (!info) { playable = false; info = { canvas: placeholder('video', name), w: 640, h: 360, duration: NaN }; }
      poster = await addPoster(info.canvas, name);
      w = info.w; h = info.h;
    } else {
      info = await audioInfo(file);
      if (!info) playable = !!document.createElement('audio').canPlayType(file.type || MIME[(file.name.split('.').pop() || '').toLowerCase()] || '');
      poster = await addPoster(waveform(name, info), name);
      w = 480; h = 96;
    }
    S.doc.assets[id] = { data, kind, name, mime: (/^data:([^;,]+)/.exec(data) || [])[1] || '', size: file.size, duration: info ? info.duration : NaN, w, h };
    const vr = V.viewRect();
    const k = vr.w > 10 && vr.h > 10 ? Math.min(1, (vr.w * 0.7) / w, (vr.h * 0.7) / h) : 1;
    w = Math.round(w * k); h = Math.round(h * k);
    const c = at || R.center(vr);
    const cont = V.containerAt(c);
    const lp = M.apply(M.inv(model.containerMatrix(cont)), c);
    const n = model.create('rect', { name: (kind === 'video' ? '▶ ' : '♪ ') + name, w, h, radius: kind === 'audio' ? 14 : 0, m: M.translate(Math.round(lp.x - w / 2), Math.round(lp.y - h / 2)), fills: [Object.assign(O.paint.image(poster.id), { mode: 'fill' })] });
    n.media = { asset: id, kind, poster: poster.id, controls: true, loop: false, autoplay: false, muted: false, volume: 1 };
    model.insert(n, cont);
    O.select([n.id]);
    O.history.commit(kind === 'video' ? 'Відео' : 'Аудіо');
    O.toast(playable ? (kind === 'video' ? 'Відео додано: {d}' : 'Аудіо додано: {d}') : 'Файл додано, але браузер не може його відтворити (кодек не підтримується). Найкраще працюють MP4 (H.264), WebM, MP3, WAV, OGG, M4A.', { d: fmtTime(info && info.duration) });
    return n;
  };

  // photos the browser cannot decode by itself: HEIC (heic2any) and TIFF / camera RAW previews (UTIF), loaded on demand
  const CDN = { heic: 'https://cdn.jsdelivr.net/npm/heic2any@0.0.4/dist/heic2any.min.js', utif: 'https://cdn.jsdelivr.net/npm/utif@3.1.0/UTIF.js' };
  MD.importPhoto = async (file, at) => {
    const name = file.name || '';
    try {
      if (HEIC_RE.test(name) || /hei[cf]/i.test(file.type)) {
        // Safari decodes HEIC natively
        try { const d = await io.blobToData(file); await io.loadImage(d, 4000); return io.importImage(file, at); } catch (e) { /* convert */ }
        O.toast('Перетворюю HEIC…');
        await O.loadScript(CDN.heic);
        let out = await window.heic2any({ blob: file, toType: 'image/jpeg', quality: 0.92 });
        if (Array.isArray(out)) out = out[0];
        return io.importImage(new File([out], name.replace(HEIC_RE, '.jpg'), { type: 'image/jpeg' }), at);
      }
      if (TIFF_RE.test(name) || /tiff/i.test(file.type)) {
        try { const d = await io.blobToData(file); await io.loadImage(d, 4000); return io.importImage(file, at); } catch (e) { /* decode */ }
        O.toast('Декодую {f}…', { f: name.split('.').pop().toUpperCase() });
        await O.loadScript(CDN.utif);
        const U = window.UTIF;
        const buf = await file.arrayBuffer();
        const ifds = U.decode(buf);
        // the biggest image (RAW files carry a full-size preview)
        let best = null;
        for (const f of ifds) { try { U.decodeImage(buf, f, ifds); } catch (e) { continue; } if (f.width && (!best || f.width * f.height > best.width * best.height)) best = f; }
        if (!best) throw new Error('no image');
        const rgba = U.toRGBA8(best);
        const cv = posterCanvas(best.width, best.height, c => { const id = c.createImageData(best.width, best.height); id.data.set(rgba); c.putImageData(id, 0, 0); });
        const blob = await io.canvasToBlob(cv, 'image/png');
        return io.importImage(new File([blob], name.replace(/\.[^.]+$/, '.png'), { type: 'image/png' }), at);
      }
    } catch (e) {
      console.warn(e);
      O.toast('Не вдалося відкрити «{name}». Для HEIC/TIFF/RAW потрібен інтернет (декодер завантажується за потреби).', { name });
      return null;
    }
    return null;
  };
  io.openHooks.unshift(
    { test: f => !!kindOf(f), open: (f, at) => MD.importMedia(f, at) },
    { test: f => HEIC_RE.test(f.name || '') || TIFF_RE.test(f.name || '') || /hei[cf]|tiff/i.test(f.type || ''), open: (f, at) => MD.importPhoto(f, at) }
  );
  {
    const c = O.cmds.get('placeImage');
    if (c) c.label = 'Помістити фото, відео або аудіо…';
  }

  // ---------- canvas: play badge ----------
  O.render.fxHooks.push((n, ctx) => {
    if (!n.media || ctx.exp || ctx.ghost || n.media.kind !== 'video') return null;
    const r = Math.max(8, Math.min(32, Math.min(n.w, n.h) * 0.12));
    const cx = n.w / 2, cy = n.h / 2;
    return { post: `<g pointer-events="none"><circle cx="${n_(cx)}" cy="${n_(cy)}" r="${n_(r)}" fill="rgba(0,0,0,.45)" stroke="rgba(255,255,255,.9)" stroke-width="${n_(r / 12)}"/><path d="M${n_(cx - r * 0.3)} ${n_(cy - r * 0.42)}L${n_(cx + r * 0.46)} ${n_(cy)}L${n_(cx - r * 0.3)} ${n_(cy + r * 0.42)}Z" fill="#fff"/></g>` };
  });

  // ---------- Design panel ----------
  const mediaURL = id => O.assetURL(id);
  O.panels.extraSections.push(nodes => {
    if (nodes.length !== 1 || !nodes[0].media) return '';
    const n = nodes[0], m = n.media, a = S.doc.assets[m.asset] || {};
    const url = esc(mediaURL(m.asset));
    const tg = (k, label) => `<label class="chk"><input type="checkbox" data-md="${k}"${m[k] ? ' checked' : ''}><span>${esc(t(label))}</span></label>`;
    return `<section class="ps"><div class="ps-h"><span>${esc(t(m.kind === 'video' ? 'Відео' : 'Аудіо'))}</span><span class="ps-x note">${esc(fmtTime(a.duration))}${a.size ? ' · ' + Math.max(1, Math.round(a.size / 1048576)) + ' МБ' : ''}</span></div>
      ${m.kind === 'video' ? `<video class="md-prev" src="${url}" controls preload="metadata" playsinline></video>` : `<audio class="md-prev" src="${url}" controls preload="metadata"></audio>`}
      <div class="col">${tg('controls', 'Показувати керування')}${tg('autoplay', m.kind === 'video' ? 'Автозапуск (без звуку)' : 'Автозапуск')}${tg('loop', 'Повторювати')}${m.kind === 'video' ? tg('muted', 'Без звуку') : ''}</div>
      <div class="row"><label class="fld" title="${esc(t('Гучність'))}"><span class="fl">${esc(t('Гучність'))}</span><input type="text" inputmode="decimal" data-md="volume" value="${Math.round((m.volume === undefined ? 1 : m.volume) * 100)}" aria-label="${esc(t('Гучність'))}"><em>%</em></label></div>
      <div class="row">${m.kind === 'video' ? `<button type="button" class="btn" data-mda="poster" title="${esc(t('Зупиніть відео на потрібному кадрі й натисніть'))}">${esc(t('Кадр як обкладинка'))}</button>` : ''}<button type="button" class="btn" data-mda="save">${esc(t('Зберегти файл'))}</button><button type="button" class="btn" data-mda="music" title="${esc(t('Використати як фонову музику презентації та слайд-шоу'))}">${esc(t('Як фонова музика'))}</button></div></section>`;
  });
  const props = () => O.$('#props');
  document.addEventListener('change', e => {
    const el = e.target;
    if (!el.dataset || !el.dataset.md || !props() || !props().contains(el)) return;
    const n = O.sel()[0];
    if (!n || !n.media) return;
    const k = el.dataset.md;
    if (k === 'volume') { const v = parseFloat(el.value); if (isFinite(v)) n.media.volume = O.clamp(v / 100, 0, 1); }
    else n.media[k] = el.checked;
    if (k === 'autoplay' && el.checked && n.media.kind === 'video') n.media.muted = true;
    O.history.commit('Медіа');
  });
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('button[data-mda]');
    if (!b || !props() || !props().contains(b)) return;
    const n = O.sel()[0];
    if (!n || !n.media) return;
    const a = S.doc.assets[n.media.asset];
    if (b.dataset.mda === 'save' && a) {
      const ext = ((/^data:[^/]+\/([\w.+-]+)/.exec(a.data) || [])[1] || 'bin').replace('quicktime', 'mov').replace('mpeg', n.media.kind === 'audio' ? 'mp3' : 'mpg').replace('x-matroska', 'mkv');
      O.download(O.dataToBlob(a.data), (a.name || 'media') + '.' + ext);
    }
    if (b.dataset.mda === 'poster') {
      const v = props().querySelector('video.md-prev');
      if (!v || !v.videoWidth) return O.toast('Відео ще не завантажилося');
      const cv = posterCanvas(v.videoWidth, v.videoHeight, (c, W, H) => c.drawImage(v, 0, 0, W, H));
      addPoster(cv, a ? a.name : n.name).then(p => { n.fills = [Object.assign(O.paint.image(p.id), { mode: 'fill' })]; n.media.poster = p.id; O.history.commit('Обкладинка відео'); });
    }
    if (b.dataset.mda === 'music' && a) { S.doc.music = { asset: n.media.asset, name: a.name, volume: 0.8, loop: true }; O.history.commit('Фонова музика'); O.toast('Фонова музика: «{name}»', { name: a.name }); }
  });

  // ---------- background music ----------
  MD.musicDialog = async () => {
    const cur = S.doc.music && S.doc.assets[S.doc.music.asset] ? S.doc.music : null;
    ui.dialog({
      title: 'Фонова музика проєкту',
      body: `<div class="dlg-text">${esc(cur ? t('Зараз: «{name}». Грає в режимі презентації та записується в слайд-шоу.', { name: cur.name }) : t('Музика грає в режимі презентації (Ctrl+Alt+Enter) і додається до відео слайд-шоу. Формати: MP3, WAV, OGG, M4A, AAC, FLAC, WEBM.'))}</div>${cur ? `<audio class="md-prev" src="${esc(O.assetURL(cur.asset))}" controls></audio>` : ''}`,
      fields: cur ? [{ key: 'vol', label: 'Гучність', type: 'number', value: Math.round((cur.volume === undefined ? 0.8 : cur.volume) * 100), unit: '%' }, { key: 'loop', label: 'Повторювати', type: 'checkbox', value: cur.loop !== false }] : [],
      buttons: cur ? [{ id: 'del', label: 'Прибрати' }, { id: 'pick', label: 'Інший файл…' }, { id: 'ok', label: 'Готово', primary: true }] : [{ id: 'pick', label: 'Обрати файл…', primary: true }],
      onOk: async (v, btn) => {
        if (btn === 'del') { delete S.doc.music; O.history.commit('Фонова музика'); return; }
        if (cur && btn === 'ok') { cur.volume = O.clamp((v.vol || 0) / 100, 0, 1); cur.loop = !!v.loop; O.history.commit('Фонова музика'); return; }
        const files = await io.pickFiles('audio/*,.mp3,.wav,.ogg,.oga,.opus,.m4a,.aac,.flac,.weba', false);
        if (!files[0]) return;
        const id = O.uid();
        S.doc.assets[id] = { data: await toData(files[0]), kind: 'audio', name: baseName(files[0]), size: files[0].size };
        S.doc.music = { asset: id, name: baseName(files[0]), volume: 0.8, loop: true };
        O.history.commit('Фонова музика');
        O.toast('Фонова музика: «{name}»', { name: baseName(files[0]) });
      }
    });
  };
  let musicEl = null;
  const playMusic = () => {
    const mu = S.doc.music;
    if (!mu || !S.doc.assets[mu.asset] || musicEl) return;
    musicEl = new Audio(O.assetURL(mu.asset));
    musicEl.loop = mu.loop !== false; musicEl.volume = mu.volume === undefined ? 0.8 : mu.volume;
    musicEl.play().catch(() => {});
  };
  const stopMusic = () => { if (musicEl) { musicEl.pause(); musicEl.src = ''; musicEl = null; } };

  // ---------- presentation: real players over the slide ----------
  const mediaIn = f => { const out = []; model.walk(f.children, n => { if (n.visible === false) return false; if (n.media) out.push(n); }); return out; };
  let layoutPresent = null;
  O.on('present-slide', (stage, frame) => {
    playMusic();
    stage.style.position = 'relative';
    const list = mediaIn(frame);
    if (!list.length) { layoutPresent = null; return; }
    const fb = model.worldBounds(frame);
    const els = list.map(n => {
      const m = n.media;
      const el = document.createElement(m.kind === 'video' ? 'video' : 'audio');
      el.src = O.assetURL(m.asset); el.className = 'pr-media';
      el.controls = m.controls !== false; el.loop = !!m.loop; el.playsInline = true; el.preload = 'auto';
      el.volume = m.volume === undefined ? 1 : m.volume;
      if (m.kind === 'video') { el.poster = O.assetURL(m.poster); el.muted = !!m.muted; }
      if (m.autoplay) { if (m.kind === 'video') el.muted = el.muted || !!m.muted; el.play().catch(() => { el.muted = true; el.play().catch(() => {}); }); }
      el.addEventListener('click', e => e.stopPropagation());
      stage.appendChild(el);
      return { n, el };
    });
    layoutPresent = () => {
      const svg = stage.querySelector('svg');
      if (!svg) return;
      const sr = svg.getBoundingClientRect(), st = stage.getBoundingClientRect();
      const k = sr.width / fb.w;
      for (const { n, el } of els) {
        const b = model.worldBounds(n);
        Object.assign(el.style, { position: 'absolute', left: (sr.left - st.left + (b.x - fb.x) * k) + 'px', top: (sr.top - st.top + (b.y - fb.y) * k) + 'px', width: b.w * k + 'px', height: n.media.kind === 'video' ? b.h * k + 'px' : 'auto', objectFit: 'cover', borderRadius: (n.radius ? (Array.isArray(n.radius) ? n.radius[0] : n.radius) * k : 0) + 'px' });
      }
    };
    requestAnimationFrame(layoutPresent);
  });
  window.addEventListener('resize', () => { if (layoutPresent && O.$('.present')) layoutPresent(); });
  O.on('present-close', () => { stopMusic(); layoutPresent = null; });

  // ---------- HTML export ----------
  MD.htmlFor = (n, ctx) => {
    const m = n.media;
    if (!m || !S.doc.assets[m.asset]) return null;
    const src = esc(ctx.url(m.asset));
    const flags = `${m.controls !== false ? ' controls' : ''}${m.loop ? ' loop' : ''}${m.autoplay ? ' autoplay' : ''}${m.autoplay || m.muted ? ' muted' : ''}`;
    if (m.kind === 'video') return { el: { tag: 'video', attrs: ` src="${src}"${m.poster ? ` poster="${esc(ctx.url(m.poster))}"` : ''}${flags} playsinline preload="metadata"`, html: '' }, css: ['object-fit: cover', 'display: block', 'background: #000'] };
    return { el: { tag: 'audio', attrs: ` src="${src}"${flags} preload="metadata"`, html: '' }, css: ['display: block'] };
  };

  // ---------- slideshow video (frames + music) ----------
  MD.slideshow = () => {
    const frames = model.page().children.filter(n => n.type === 'frame' && n.visible !== false);
    if (!frames.length) return O.toast('Додайте на сторінку фрейми — кожен стане слайдом');
    if (!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream) return O.toast('Цей браузер не вміє записувати відео. Скористайтеся Chrome, Edge або Firefox.');
    frames.sort((a, b) => { const A = model.worldBounds(a), B = model.worldBounds(b); return Math.abs(A.y - B.y) > 40 ? A.y - B.y : A.x - B.x; });
    const mu = S.doc.music && S.doc.assets[S.doc.music.asset] ? S.doc.music : null;
    ui.dialog({
      title: 'Відео слайд-шоу з музикою',
      body: `<div class="dlg-text">${esc(t('Кожен фрейм сторінки стає слайдом ({n} шт.). Відеокліпи всередині фреймів відтворюються. Запис іде в реальному часі, не закривайте вкладку.', { n: frames.length }))}${mu ? '' : ' ' + esc(t('Щоб додати музику: Файл → Фонова музика проєкту.'))}</div>`,
      fields: [
        { key: 'sec', label: 'Секунд на слайд', type: 'number', value: O.ls.get('ssSec', 3), min: 0.5, step: 0.5 },
        { key: 'fade', label: 'Плавний перехід', type: 'number', value: O.ls.get('ssFade', 0.6), unit: 'с', min: 0, step: 0.1 },
        { key: 'size', label: 'Розмір відео', type: 'select', value: O.ls.get('ssSize', '1920'), options: [['1280', '1280 px (720p)'], ['1920', '1920 px (1080p)'], ['3840', '3840 px (4K)']] },
        { key: 'fps', label: 'Кадрів за секунду', type: 'select', value: String(O.ls.get('ssFps', 30)), options: [['24', '24'], ['30', '30'], ['60', '60']] },
        mu ? { key: 'music', label: `${t('Музика')}: ${mu.name}`, type: 'checkbox', value: true } : null,
        mu ? { key: 'fit', label: 'Розтягнути слайди на всю довжину музики', type: 'checkbox', value: false } : null
      ].filter(Boolean),
      buttons: [{ id: 'ok', label: 'Записати відео', primary: true }],
      onOk: v => {
        O.ls.set('ssSec', v.sec); O.ls.set('ssFade', v.fade); O.ls.set('ssSize', v.size); O.ls.set('ssFps', +v.fps);
        MD.recordSlideshow(frames, { sec: Math.max(0.5, v.sec), fade: Math.max(0, v.fade), maxW: +v.size, fps: +v.fps, music: mu && v.music ? mu : null, fit: !!v.fit }).catch(e => { console.error(e); O.toast('Помилка запису: {msg}', { msg: e.message }); });
      }
    });
  };
  MD.recordSlideshow = async (frames, o) => {
    const prog = O.h(`<div class="dlg-back"><div class="dlg" role="dialog" aria-label="${esc(t('Запис відео'))}"><div class="dlg-h"><span>${esc(t('Запис відео'))}</span></div><div class="dlg-b"><div class="dlg-text ss-st">${esc(t('Підготовка слайдів…'))}</div><progress class="ss-pr" max="1" value="0" style="width:100%"></progress></div><div class="dlg-f"><span class="sp"></span><button type="button" class="btn" data-ss="stop">${esc(t('Зупинити'))}</button></div></div></div>`);
    document.body.appendChild(prog);
    let cancelled = false;
    prog.querySelector('[data-ss="stop"]').onclick = () => { cancelled = true; };
    const status = s => { prog.querySelector('.ss-st').textContent = s; };
    try {
      // output size from the first slide, even numbers for the encoders
      const fb0 = model.worldBounds(frames[0]);
      const k0 = Math.min(1, o.maxW / Math.max(fb0.w, fb0.h)) || 1;
      const W = Math.round(fb0.w * k0 / 2) * 2, H = Math.round(fb0.h * k0 / 2) * 2;
      const slides = [];
      for (let i = 0; i < frames.length; i++) {
        if (cancelled) throw new Error(t('Скасовано'));
        status(t('Підготовка слайда {i} із {n}…', { i: i + 1, n: frames.length }));
        const fb = model.worldBounds(frames[i]);
        const sc = Math.min(W / fb.w, H / fb.h);
        const { canvas } = await io.renderImage([frames[i]], { scale: sc, type: 'image/png' });
        const vids = mediaIn(frames[i]).filter(n => n.media.kind === 'video').map(n => {
          const el = document.createElement('video');
          el.src = O.assetURL(n.media.asset); el.muted = true; el.playsInline = true; el.preload = 'auto'; el.loop = true;
          const b = model.worldBounds(n);
          return { el, x: (b.x - fb.x) * sc, y: (b.y - fb.y) * sc, w: b.w * sc, h: b.h * sc };
        });
        slides.push({ canvas, sc, fb, vids });
      }
      let audio = null, ac = null, gain = null, dur = slides.length * o.sec;
      if (o.music) {
        audio = new Audio(O.assetURL(o.music.asset));
        await new Promise(r => { audio.onloadedmetadata = r; audio.onerror = r; setTimeout(r, 5000); });
        if (o.fit && isFinite(audio.duration) && audio.duration > 1) dur = audio.duration;
      }
      const per = dur / slides.length;
      const cv = posterCanvas(W, H, () => {});
      const c = cv.getContext('2d');
      const stream = cv.captureStream(o.fps);
      if (audio) {
        const AC = window.AudioContext || window.webkitAudioContext;
        ac = new AC();
        const src = ac.createMediaElementSource(audio);
        gain = ac.createGain(); gain.gain.value = o.music.volume === undefined ? 0.8 : o.music.volume;
        const dest = ac.createMediaStreamDestination();
        src.connect(gain); gain.connect(dest);
        dest.stream.getAudioTracks().forEach(tr => stream.addTrack(tr));
      }
      const types = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
      const mime = types.find(x => MediaRecorder.isTypeSupported(x)) || '';
      const rec = new MediaRecorder(stream, { mimeType: mime || undefined, videoBitsPerSecond: Math.round(W * H * o.fps * 0.12) });
      const chunks = [];
      rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
      const stopped = new Promise(r => { rec.onstop = r; });
      const drawSlide = (s, alpha) => {
        c.globalAlpha = alpha;
        const dx = (W - s.fb.w * s.sc) / 2, dy = (H - s.fb.h * s.sc) / 2;
        c.drawImage(s.canvas, dx, dy);
        for (const v of s.vids) if (v.el.readyState >= 2) { try { c.drawImage(v.el, dx + v.x, dy + v.y, v.w, v.h); } catch (e) { /* not ready */ } }
        c.globalAlpha = 1;
      };
      rec.start(500);
      if (audio) { audio.currentTime = 0; await audio.play().catch(() => {}); }
      const t0 = performance.now();
      let cur = -1;
      await new Promise(resolve => {
        const tick = () => {
          const el = (performance.now() - t0) / 1000;
          if (cancelled || el >= dur) return resolve();
          const i = Math.min(slides.length - 1, Math.floor(el / per));
          if (i !== cur) { if (cur >= 0) slides[cur].vids.forEach(v => v.el.pause()); slides[i].vids.forEach(v => { v.el.currentTime = 0; v.el.play().catch(() => {}); }); cur = i; }
          const local = el - i * per;
          c.fillStyle = '#000'; c.fillRect(0, 0, W, H);
          drawSlide(slides[i], 1);
          // cross-fade into the next slide
          if (o.fade > 0 && i < slides.length - 1 && local > per - o.fade) drawSlide(slides[i + 1], (local - (per - o.fade)) / o.fade);
          // fade the music out over the last second
          if (gain && dur - el < 1) gain.gain.value = Math.max(0, (dur - el)) * (o.music.volume === undefined ? 0.8 : o.music.volume);
          status(t('Запис: {a} із {b}', { a: fmtTime(el), b: fmtTime(dur) }));
          prog.querySelector('.ss-pr').value = el / dur;
          setTimeout(tick, 1000 / o.fps);
        };
        tick();
      });
      rec.stop();
      await stopped;
      if (audio) audio.pause();
      if (ac) ac.close();
      slides.forEach(s => s.vids.forEach(v => { v.el.pause(); v.el.src = ''; }));
      if (cancelled && !chunks.length) throw new Error(t('Скасовано'));
      const type = (mime || 'video/webm').split(';')[0];
      const blob = new Blob(chunks, { type });
      O.download(blob, String(S.doc.name || 'slideshow').replace(/[\\/:*?"<>|]+/g, '_') + (type === 'video/mp4' ? '.mp4' : '.webm'));
      O.toast('Відео збережено ({mb} МБ)', { mb: (blob.size / 1048576).toFixed(1) });
    } finally { prog.remove(); }
  };

  O.cmd('placeMedia', 'Додати відео або аудіо…', async () => { const files = await io.pickFiles('video/*,audio/*,' + io.EXTRA_MEDIA, true); for (const f of files) await io.openFile(f); }, { group: 'Файл' });
  O.cmd('music', 'Фонова музика проєкту…', () => MD.musicDialog(), { group: 'Файл' });
  O.cmd('slideshow', 'Експорт відео слайд-шоу з музикою…', () => MD.slideshow(), { group: 'Файл' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл')[1];
  fileMenu.splice(fileMenu.indexOf('placeImage') + 1, 0, 'placeMedia', 'music');
  fileMenu.splice(fileMenu.indexOf('exportDialog') + 1, 0, 'slideshow');
})();
