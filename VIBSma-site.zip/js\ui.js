'use strict';
/* VIBSma — UI primitives: icons, menus, context menu, dialogs, toasts, command palette, color picker, toolbar */
(function () {
  const O = window.O, model = O.model, S = O.state;
  const ui = O.ui = {};
  const esc = O.esc, t = (s, v) => O.t(s, v);

  // ---------- icons (24x24, stroke) ----------
  const I = {
    select: '<path d="M6 3.5l12 9.2-5.3.7 3 6.2-2.2 1-3-6.3-4.5 3.9z" fill="currentColor" stroke="none"/>',
    direct: '<path d="M6 3.5l12 9.2-5.3.7 3 6.2-2.2 1-3-6.3-4.5 3.9z"/>',
    free: '<rect x="6" y="6" width="12" height="12" stroke-dasharray="2 2"/><rect x="4" y="4" width="4" height="4" fill="var(--panel)"/><rect x="16" y="16" width="4" height="4" fill="var(--panel)"/><rect x="16" y="4" width="4" height="4" fill="var(--panel)"/><rect x="4" y="16" width="4" height="4" fill="var(--panel)"/>',
    hand: '<path d="M8 12V6.5a1.5 1.5 0 0 1 3 0V11M11 11V5a1.5 1.5 0 0 1 3 0v6M14 11V6.5a1.5 1.5 0 0 1 3 0V14c0 4-2.6 7-6.2 7-2.6 0-4.4-1.3-5.8-3.6l-1.8-3a1.5 1.5 0 0 1 2.5-1.6L8 14.5"/>',
    zoom: '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l5 5M8 10.5h5M10.5 8v5"/>',
    frame: '<path d="M8 3v18M16 3v18M3 8h18M3 16h18"/>',
    rect: '<rect x="4.5" y="4.5" width="15" height="15" rx="1"/>',
    ellipse: '<circle cx="12" cy="12" r="7.5"/>',
    line: '<path d="M5 19L19 5"/>',
    arrow: '<path d="M5 19L19 5M10 5h9v9"/>',
    polygon: '<path d="M12 4.5l8 14H4z"/>',
    star: '<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.9 6.8 19.6l1-5.8-4.3-4.1 5.9-.8z"/>',
    arc: '<path d="M5 19C5 11 11 5 19 5"/>',
    spiral: '<path d="M12 12a1 1 0 0 1 2 0a2 2 0 0 1-4 0a3 3 0 0 1 6 0a4 4 0 0 1-8 0a5 5 0 0 1 10 0a6 6 0 0 1-12 0"/>',
    grid: '<rect x="4" y="4" width="16" height="16"/><path d="M4 9.3h16M4 14.6h16M9.3 4v16M14.6 4v16"/>',
    polar: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="M12 4v16M4 12h16"/>',
    image: '<rect x="3.5" y="5" width="17" height="14" rx="1.5"/><circle cx="9" cy="10" r="1.6"/><path d="M4 17l5-4.5 3.5 3 3-2.5 4.5 4"/>',
    pen: '<path d="M12 3l5.5 8.5L15 17H9l-2.5-5.5z"/><circle cx="12" cy="11" r="1.4"/><path d="M12 3v6.6M9 20.5h6"/>',
    pencil: '<path d="M4 20l1.2-4.5L16 4.7l3.3 3.3L8.5 18.8z"/><path d="M14 6.7l3.3 3.3"/>',
    brush: '<path d="M20 4l-8.5 9.5"/><path d="M11.5 13.5c-.8-.8-2.7-1-4 .3-1.6 1.6-.6 3.6-2.5 5.7 2.5.6 5.3.1 6.8-1.4 1.3-1.3 1.2-3.2-.3-4.6z"/>',
    blob: '<path d="M20 4l-7 7"/><path d="M6 13c2-2.5 6-2.4 7 .2 1 2.6-1 6.3-4.8 6.3C5 19.5 4 15.5 6 13z" fill="currentColor" fill-opacity=".25"/>',
    eraser: '<path d="M15.5 4.5l5 5L11 19H6.5L3.5 16z"/><path d="M8.5 9.5l6 6M11 19h9"/>',
    scissors: '<circle cx="6" cy="6.5" r="2.5"/><circle cx="6" cy="17.5" r="2.5"/><path d="M8 8l12 9M8 16L20 7"/>',
    knife: '<path d="M4 20L16.5 7.5c1.5-1.5 3.5-1 3.5-1s.5 2-1 3.5L10 19z"/><path d="M4 20l3-3"/>',
    text: '<path d="M5 7V5h14v2M12 5v14M9 19h6"/>',
    textpath: '<path d="M3 18c4-6 10-6 18-2" stroke-dasharray="2 2"/><path d="M7 5h8M11 5v8"/>',
    rotate: '<path d="M19 12a7 7 0 1 1-2.1-5"/><path d="M17.5 3v4.5H13"/>',
    reflect: '<path d="M12 3v18" stroke-dasharray="2 2"/><path d="M9 7v10L4 17z"/><path d="M15 7v10h5z" fill="currentColor" fill-opacity=".25"/>',
    scale: '<rect x="4" y="11" width="9" height="9"/><path d="M4 8V4h16v16h-4M13 11l6-6M15 5h4v4"/>',
    shear: '<path d="M8 5h12l-4 14H4z"/>',
    gradient: '<rect x="4" y="4" width="16" height="16" rx="1"/><path d="M8 4v16M11.5 4v16M14 4v16M16 4v16M17.6 4v16" stroke-width="1"/>',
    eyedropper: '<path d="M14.5 6.5l3 3M19.5 4.5a2.1 2.1 0 0 0-3 0L14 7l3 3 2.5-2.5a2.1 2.1 0 0 0 0-3z"/><path d="M15.5 8.5L6 18l-2 2.5-.5-.5L6 18"/>',
    blend: '<circle cx="6" cy="12" r="3"/><circle cx="12" cy="12" r="4" stroke-dasharray="2 1.5"/><rect x="15.5" y="7" width="5" height="10"/>',
    shapebuilder: '<circle cx="9" cy="12" r="5.5"/><circle cx="15" cy="12" r="5.5"/><path d="M12 7.8v8.4" stroke-width="3" stroke="var(--panel)"/><path d="M12 9.5v5M9.5 12h5"/>',
    group: '<rect x="4" y="4" width="16" height="16" rx="1" stroke-dasharray="2.5 2"/>',
    component: '<path d="M12 3.5l2.8 2.8L12 9.1 9.2 6.3zM12 14.9l2.8 2.8-2.8 2.8-2.8-2.8zM6.3 9.2l2.8 2.8-2.8 2.8L3.5 12zM17.7 9.2l2.8 2.8-2.8 2.8-2.8-2.8z"/>',
    instance: '<path d="M12 4l8 8-8 8-8-8z"/>',
    bool: '<rect x="4" y="4" width="11" height="11"/><rect x="9" y="9" width="11" height="11"/>',
    path: '<path d="M4 18C8 4 16 20 20 6"/><circle cx="4" cy="18" r="1.4" fill="currentColor"/><circle cx="20" cy="6" r="1.4" fill="currentColor"/>',
    mask: '<rect x="4" y="4" width="16" height="16" rx="1"/><circle cx="12" cy="12" r="4.5" fill="currentColor" fill-opacity=".3"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
    eyeoff: '<path d="M3 3l18 18M10.6 6.6c.5-.1.9-.1 1.4-.1 6 0 9.5 5.5 9.5 5.5a17 17 0 0 1-2.6 3.1M6.6 6.6C4 8.3 2.5 12 2.5 12S6 18.5 12 18.5c1.7 0 3.2-.5 4.4-1.2M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="1.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/>',
    unlock: '<rect x="5" y="10.5" width="14" height="10" rx="1.5"/><path d="M8 10.5V7.5a4 4 0 0 1 7.6-1.7"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    chevdown: '<path d="M7 10l5 5 5-5"/>',
    chevright: '<path d="M10 7l5 5-5 5"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/>',
    moon: '<path d="M19.5 14.5A7.5 7.5 0 0 1 9.5 4.5a7.5 7.5 0 1 0 10 10z"/>',
    globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.4 2.4 3.5 5.2 3.5 8.5s-1.1 6.1-3.5 8.5c-2.4-2.4-3.5-5.2-3.5-8.5s1.1-6.1 3.5-8.5z"/>',
    play: '<path d="M8 5.5v13l10.5-6.5z"/>',
    download: '<path d="M12 4v11M7 10.5l5 5 5-5M5 19.5h14"/>',
    layers: '<path d="M12 4l8.5 4.5L12 13 3.5 8.5z"/><path d="M3.5 12.5L12 17l8.5-4.5M3.5 16.5L12 21l8.5-4.5"/>',
    sliders: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
    code: '<path d="M8.5 7L3.5 12l5 5M15.5 7l5 5-5 5"/>',
    more: '<circle cx="6" cy="12" r="1.2" fill="currentColor"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/><circle cx="18" cy="12" r="1.2" fill="currentColor"/>',
    alignLeft: '<path d="M4 3v18"/><rect x="7" y="6" width="12" height="4" rx=".5"/><rect x="7" y="14" width="7" height="4" rx=".5"/>',
    alignHCenter: '<path d="M12 3v18"/><rect x="5" y="6" width="14" height="4" rx=".5"/><rect x="8" y="14" width="8" height="4" rx=".5"/>',
    alignRight: '<path d="M20 3v18"/><rect x="5" y="6" width="12" height="4" rx=".5"/><rect x="10" y="14" width="7" height="4" rx=".5"/>',
    alignTop: '<path d="M3 4h18"/><rect x="6" y="7" width="4" height="12" rx=".5"/><rect x="14" y="7" width="4" height="7" rx=".5"/>',
    alignVCenter: '<path d="M3 12h18"/><rect x="6" y="5" width="4" height="14" rx=".5"/><rect x="14" y="8" width="4" height="8" rx=".5"/>',
    alignBottom: '<path d="M3 20h18"/><rect x="6" y="5" width="4" height="12" rx=".5"/><rect x="14" y="10" width="4" height="7" rx=".5"/>',
    distH: '<path d="M4 3v18M20 3v18"/><rect x="9.5" y="7" width="5" height="10" rx=".5"/>',
    distV: '<path d="M3 4h18M3 20h18"/><rect x="7" y="9.5" width="10" height="5" rx=".5"/>',
    union: '<path d="M4 4h10v6h6v10H10v-6H4z" fill="currentColor" fill-opacity=".35"/>',
    subtract: '<path d="M4 4h10v6h-4v4H4z" fill="currentColor" fill-opacity=".35"/><rect x="10" y="10" width="10" height="10" stroke-dasharray="2 1.5"/>',
    intersect: '<rect x="4" y="4" width="10" height="10" stroke-dasharray="2 1.5"/><rect x="10" y="10" width="10" height="10" stroke-dasharray="2 1.5"/><rect x="10" y="10" width="4" height="4" fill="currentColor" fill-opacity=".5"/>',
    exclude: '<path d="M4 4h10v6h-4v4H4zM14 10h6v10H10v-6h4z" fill="currentColor" fill-opacity=".35"/>',
    divide: '<rect x="4" y="4" width="10" height="10"/><rect x="10" y="10" width="10" height="10"/><path d="M10 10h4v4h-4z" fill="currentColor" fill-opacity=".4"/>',
    trim: '<rect x="4" y="4" width="10" height="10" fill="currentColor" fill-opacity=".2"/><path d="M10 14v6h10V10h-6"/>',
    merge: '<path d="M4 4h10v6h6v10H10v-6H4z"/><path d="M10 10h4v4" stroke-dasharray="2 1.5"/>',
    crop: '<path d="M7 3v14h14M3 7h14v14"/>',
    outline: '<rect x="4" y="4" width="10" height="10" stroke-dasharray="2 1.5"/><rect x="10" y="10" width="10" height="10" stroke-dasharray="2 1.5"/>',
    minusback: '<rect x="4" y="4" width="10" height="10" stroke-dasharray="2 1.5"/><path d="M14 10h6v10H10v-6h4z" fill="currentColor" fill-opacity=".35"/>',
    flipH: '<path d="M12 3v18" stroke-dasharray="2 2"/><path d="M9 6L3 18h6zM15 6l6 12h-6z"/>',
    flipV: '<path d="M3 12h18" stroke-dasharray="2 2"/><path d="M6 9L18 3v6zM6 15l12 6v-6z"/>',
    rot90: '<path d="M5 12a7 7 0 1 0 2-5"/><path d="M4 4v4h4"/>',
    dirH: '<path d="M4 12h15M14 7l5 5-5 5"/>',
    dirV: '<path d="M12 4v15M7 14l5 5 5-5"/>',
    tLeft: '<path d="M4 6h16M4 10h10M4 14h16M4 18h10"/>',
    tCenter: '<path d="M4 6h16M7 10h10M4 14h16M7 18h10"/>',
    tRight: '<path d="M4 6h16M10 10h10M4 14h16M10 18h10"/>',
    tJustify: '<path d="M4 6h16M4 10h16M4 14h16M4 18h16"/>',
    underline: '<path d="M7 4v7a5 5 0 0 0 10 0V4M5 20h14"/>',
    strike: '<path d="M4 12h16M16.5 7.5C16 5.5 14 4.5 12 4.5c-2.5 0-4.5 1.3-4.5 3.5M7.5 16.5c.5 2 2.4 3 4.5 3 2.6 0 4.5-1.4 4.5-3.5"/>',
    autolayout: '<rect x="3.5" y="6" width="6" height="12" rx="1"/><rect x="14.5" y="6" width="6" height="12" rx="1"/><path d="M11 12h2"/>',
    ratio: '<path d="M9 15l6-6M10.5 6.5l1-1a3.5 3.5 0 0 1 5 5l-1 1M13.5 17.5l-1 1a3.5 3.5 0 0 1-5-5l1-1"/>',
    radius: '<path d="M5 19V11a6 6 0 0 1 6-6h8"/>',
    page: '<path d="M6 3.5h8l4 4v13H6z"/><path d="M14 3.5v4h4"/>',
    font: '<path d="M4 19l5.5-14L15 19M6.2 14h6.6M15 19l3.5-9 3.5 9M16.2 16.5h4.6"/>',
    trash: '<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3A4 4 0 0 0 13 5.3l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="1.5"/><path d="M16 8V5.5A1.5 1.5 0 0 0 14.5 4h-9A1.5 1.5 0 0 0 4 5.5v9A1.5 1.5 0 0 0 5.5 16H8"/>',
    help: '<circle cx="12" cy="12" r="8.5"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6M12 17v.1"/>'
  };
  O.icon = (name, size = 16, cls = '') => `<svg class="ic ${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[name] || I.rect}</svg>`;
  O.ICONS = I;

  // ---------- commands ----------
  const cmds = O.cmds = new Map();
  O.cmd = (id, label, run, opts = {}) => cmds.set(id, Object.assign({ id, label, run, keys: [] }, opts));
  // display label of a command (labels are translation keys, or functions, or raw text)
  O.cmdLabel = c => typeof c.label === 'function' ? c.label() : (c.raw ? c.label : t(c.label));
  O.run = id => {
    const c = cmds.get(id);
    if (!c) return;
    if (c.enabled && !c.enabled()) { if (c.why) O.toast(c.why); return; }
    try { const r = c.run(); if (r && r.catch) r.catch(e => { console.error(e); O.toast('Помилка: {msg}', { msg: e.message }); }); }
    catch (e) { console.error(e); O.toast('Помилка: {msg}', { msg: e.message }); }
  };

  // ---------- toasts ----------
  let toastTimer = null;
  O.toast = (msg, vars) => {
    let el = O.$('#toast');
    if (!el) { el = O.h('<div id="toast" role="status" aria-live="polite"></div>'); document.body.appendChild(el); }
    el.textContent = t(msg, vars);
    el.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('on'), 2800);
  };

  // ---------- menus ----------
  let openMenus = [];
  ui.closeMenus = () => { openMenus.forEach(m => m.remove()); openMenus = []; O.$$('.mb-item.open').forEach(b => b.classList.remove('open')); };
  const itemHTML = (it, i) => {
    if (it === '-') return '<div class="mi-sep" role="separator"></div>';
    if (it.items) return `<div class="mi sub" role="menuitem" tabindex="-1" data-sub="1" data-idx="${i}"><span class="mi-l">${esc(t(it.label))}</span>${O.icon('chevright', 14)}</div>`;
    const c = typeof it === 'string' ? cmds.get(it) : it;
    if (!c || (c.hidden && c.hidden())) return '';
    const dis = c.enabled && !c.enabled();
    const chk = c.check ? (c.check() ? O.icon('check', 14) : '<span class="ic-sp"></span>') : '';
    const keys = (c.keys || [])[0] ? `<span class="mi-k">${esc(O.keyLabel(c.keys[0]))}</span>` : '';
    return `<div class="mi${dis ? ' dis' : ''}" role="menuitem" tabindex="-1" data-cmd="${esc(c.id || '')}" data-idx="${i}">${chk}<span class="mi-l">${esc(O.cmdLabel(c))}</span>${keys}</div>`;
  };
  ui.menu = (items, x, y, opts = {}) => {
    const el = O.h(`<div class="menu" role="menu">${items.map(itemHTML).join('')}</div>`);
    document.body.appendChild(el);
    openMenus.push(el);
    const r = el.getBoundingClientRect();
    const vw = window.innerWidth, vh = window.innerHeight;
    if (x + r.width > vw - 4) x = Math.max(4, (opts.alignRight ? opts.alignRight : vw) - r.width - 4);
    if (y + r.height > vh - 4) y = Math.max(4, vh - r.height - 4);
    el.style.left = x + 'px'; el.style.top = y + 'px';
    let subEl = null;
    const closeFrom = m => { const i = openMenus.indexOf(m); if (i >= 0) { openMenus.slice(i).forEach(x2 => x2.remove()); openMenus = openMenus.slice(0, i); } };
    el.addEventListener('pointerover', e => {
      const mi = e.target.closest('.mi');
      if (!mi || !el.contains(mi)) return;
      if (mi.dataset.sub) {
        const it = items[+mi.dataset.idx];
        if (subEl && subEl._for === mi) return;
        if (subEl) closeFrom(subEl);
        const rr = mi.getBoundingClientRect();
        subEl = ui.menu(it.items, rr.right - 2, rr.top - 4, { sub: true, onPick: opts.onPick });
        subEl._for = mi;
        const sr = subEl.getBoundingClientRect();
        if (rr.right - 2 + sr.width > window.innerWidth - 4) subEl.style.left = (rr.left - sr.width + 2) + 'px';
      } else if (subEl && !subEl.contains(mi)) { closeFrom(subEl); subEl = null; }
    });
    el.addEventListener('click', e => {
      const mi = e.target.closest('.mi');
      if (!mi || mi.dataset.sub || mi.classList.contains('dis')) return;
      const id = mi.dataset.cmd;
      ui.closeMenus();
      if (opts.onPick) opts.onPick(id); else O.run(id);
    });
    return el;
  };
  document.addEventListener('pointerdown', e => {
    if (!openMenus.length) return;
    if (e.target.closest('.menu') || e.target.closest('.mb-item')) return;
    ui.closeMenus();
  }, true);
  ui.menubar = (el, menus) => {
    // menus that do not fit move into a «⋯» menu at the end of the bar
    const fit = () => {
      const items = Array.from(el.querySelectorAll('.mb-item[data-i]'));
      const more = el.querySelector('.mb-more');
      if (!more) return;
      items.forEach(b => { b.hidden = false; });
      more.hidden = true;
      if (el.scrollWidth <= el.clientWidth + 1) return;
      more.hidden = false;
      for (let k = items.length - 1; k >= 0 && el.scrollWidth > el.clientWidth + 1; k--) items[k].hidden = true;
    };
    const render = () => { el.innerHTML = menus.map(([label], i) => `<button class="mb-item" data-i="${i}" type="button">${esc(t(label))}</button>`).join('') + `<button class="mb-item mb-more" type="button" hidden aria-label="${esc(t('Інші меню'))}" title="${esc(t('Інші меню'))}">⋯</button>`; fit(); };
    render();
    O.on('lang', render);
    if (window.ResizeObserver) new ResizeObserver(() => fit()).observe(el.parentElement || el);
    window.addEventListener('resize', fit);
    const open = btn => {
      ui.closeMenus();
      btn.classList.add('open');
      const r = btn.getBoundingClientRect();
      if (btn.classList.contains('mb-more')) {
        const hidden = Array.from(el.querySelectorAll('.mb-item[data-i]')).filter(b => b.hidden).map(b => menus[+b.dataset.i]);
        ui.menu(hidden.map(([label, items]) => ({ label, items })), r.left, r.bottom + 4);
        return;
      }
      ui.menu(menus[+btn.dataset.i][1], r.left, r.bottom + 4);
    };
    el.addEventListener('click', e => {
      const b = e.target.closest('.mb-item');
      if (!b) return;
      if (b.classList.contains('open')) { ui.closeMenus(); return; }
      open(b);
    });
    el.addEventListener('pointerover', e => {
      const b = e.target.closest('.mb-item');
      if (b && openMenus.length && !b.classList.contains('open') && O.$('.mb-item.open')) open(b);
    });
  };
  O.on('lang', () => ui.closeMenus());

  // ---------- dialogs (title, labels, options and buttons are translation keys) ----------
  ui.dialog = spec => {
    const fields = spec.fields || [];
    const fieldHTML = f => {
      const id = 'dlg-' + f.key;
      if (f.type === 'checkbox') return `<label class="dlg-row chk"><input type="checkbox" id="${id}" data-k="${f.key}"${f.value ? ' checked' : ''}><span>${esc(t(f.label))}</span></label>`;
      if (f.type === 'select') return `<label class="dlg-row" for="${id}"><span>${esc(t(f.label))}</span><select id="${id}" data-k="${f.key}">${f.options.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(f.value) ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select></label>`;
      if (f.type === 'html') return f.html;
      return `<label class="dlg-row" for="${id}"><span>${esc(t(f.label))}</span><span class="dlg-in"><input id="${id}" data-k="${f.key}" type="${f.type === 'number' ? 'number' : 'text'}" value="${esc(f.value)}"${f.step ? ` step="${f.step}"` : ' step="any"'}${f.min !== undefined ? ` min="${f.min}"` : ''}${f.max !== undefined ? ` max="${f.max}"` : ''}>${f.unit ? `<em>${esc(t(f.unit))}</em>` : ''}</span></label>`;
    };
    const btns = (spec.buttons || [{ id: 'ok', label: 'OK', primary: true }]).map(b => `<button type="button" class="btn${b.primary ? ' primary' : ''}" data-b="${b.id}">${esc(t(b.label))}</button>`).join('');
    const title = t(spec.title);
    const wrap = O.h(`<div class="dlg-back"><div class="dlg" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="dlg-h"><span>${esc(title)}</span><button type="button" class="ib" data-b="cancel" aria-label="${esc(t('Закрити'))}">${O.icon('close', 14)}</button></div>
      <form class="dlg-b">${spec.body || ''}${fields.map(fieldHTML).join('')}</form>
      <div class="dlg-f">${spec.preview ? `<label class="chk"><input type="checkbox" id="dlg-preview" checked><span>${esc(t('Попередній перегляд'))}</span></label>` : ''}<span class="sp"></span><button type="button" class="btn" data-b="cancel">${esc(t('Скасувати'))}</button>${btns}</div>
    </div></div>`);
    document.body.appendChild(wrap);
    const values = () => {
      const v = {};
      fields.forEach(f => {
        const el = wrap.querySelector(`[data-k="${f.key}"]`);
        if (!el) return;
        v[f.key] = f.type === 'checkbox' ? el.checked : f.type === 'number' ? (parseFloat(el.value) || 0) : el.value;
      });
      return v;
    };
    let previewed = false;
    const runApply = btn => {
      O.suspendCommit = true;
      try { spec.apply(values(), btn); } catch (e) { console.error(e); O.toast('Помилка: {msg}', { msg: e.message }); }
      O.suspendCommit = false;
      model.reindex();
      O.emit('change');
    };
    const preview = () => {
      if (!spec.preview || !spec.apply) return;
      const pv = wrap.querySelector('#dlg-preview');
      if (previewed) { O.history.revert(); previewed = false; }
      if (pv && pv.checked) { runApply('ok'); previewed = true; }
      O.requestRender();
    };
    const close = () => { wrap.remove(); document.removeEventListener('keydown', onKey, true); O.off && O.off('lang', close); };
    const finish = btn => {
      if (btn === 'cancel') { if (previewed) O.history.revert(); close(); if (spec.onCancel) spec.onCancel(); return; }
      if (previewed) { O.history.revert(); previewed = false; }
      if (spec.apply) { runApply(btn); O.history.commit(spec.label || spec.title); }
      if (spec.onOk) spec.onOk(values(), btn);
      // keepOpen: the caller closes the dialog itself (long jobs that report progress and errors inside it)
      if (spec.keepOpen) return;
      close();
    };
    const onKey = e => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish('cancel'); }
      if (e.key === 'Enter' && !e.target.matches('textarea')) { e.preventDefault(); e.stopPropagation(); finish((spec.buttons || [{ id: 'ok' }]).slice(-1)[0].id); }
    };
    document.addEventListener('keydown', onKey, true);
    wrap.addEventListener('click', e => { const b = e.target.closest('[data-b]'); if (b) finish(b.dataset.b); else if (e.target === wrap) finish('cancel'); });
    wrap.addEventListener('input', O.debounce(preview, 120));
    wrap.addEventListener('change', preview);
    if (spec.preview) setTimeout(preview, 0);
    const first = wrap.querySelector('input,select');
    if (first) setTimeout(() => { first.focus(); if (first.select) first.select(); }, 0);
    if (spec.onOpen) spec.onOpen(wrap);
    return { el: wrap, close, values };
  };
  ui.alert = (title, html) => ui.dialog({ title, body: `<div class="dlg-text">${html}</div>`, buttons: [{ id: 'ok', label: 'Зрозуміло', primary: true }] });

  // ---------- command palette ----------
  ui.palette = () => {
    if (O.$('.pal-back')) return;
    const list = Array.from(cmds.values()).filter(c => c.label && !c.hidden);
    const wrap = O.h(`<div class="pal-back"><div class="pal" role="dialog" aria-label="${esc(t('Швидкі дії'))}">
      <div class="pal-in">${O.icon('search', 16)}<input id="pal-q" placeholder="${esc(t('Пошук команд та інструментів…'))}" autocomplete="off" aria-label="${esc(t('Пошук команд'))}"></div>
      <div class="pal-list" role="listbox"></div></div></div>`);
    document.body.appendChild(wrap);
    const inp = wrap.querySelector('input'), box = wrap.querySelector('.pal-list');
    let items = [], idx = 0;
    const norm = s => String(s).toLowerCase().replace(/[’']/g, '');
    const render = () => {
      const q = norm(inp.value.trim());
      items = list.filter(c => !q || norm(O.cmdLabel(c)).includes(q) || norm(c.group ? t(c.group) : '').includes(q) || norm(c.label && typeof c.label === 'string' ? c.label : '').includes(q) || c.id.toLowerCase().includes(q)).slice(0, 60);
      idx = Math.min(idx, Math.max(0, items.length - 1));
      box.innerHTML = items.map((c, i) => `<div class="pal-it${i === idx ? ' on' : ''}${c.enabled && !c.enabled() ? ' dis' : ''}" data-i="${i}" role="option"><span>${c.group ? `<em>${esc(t(c.group))}</em>` : ''}${esc(O.cmdLabel(c))}</span><span class="mi-k">${esc(O.keyLabel((c.keys || [])[0] || ''))}</span></div>`).join('') || `<div class="pal-empty">${esc(t('Нічого не знайдено'))}</div>`;
      const on = box.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest' });
    };
    const close = () => wrap.remove();
    const go = i => { const c = items[i]; close(); if (c) O.run(c.id); };
    inp.addEventListener('input', () => { idx = 0; render(); });
    inp.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') { idx = Math.min(items.length - 1, idx + 1); render(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { idx = Math.max(0, idx - 1); render(); e.preventDefault(); }
      else if (e.key === 'Enter') { go(idx); e.preventDefault(); }
      else if (e.key === 'Escape') { close(); e.preventDefault(); }
      e.stopPropagation();
    });
    box.addEventListener('click', e => { const it = e.target.closest('.pal-it'); if (it) go(+it.dataset.i); });
    wrap.addEventListener('pointerdown', e => { if (e.target === wrap) close(); });
    render();
    setTimeout(() => inp.focus(), 0);
  };

  // ---------- color picker ----------
  const pk = ui.picker = { el: null, st: null };
  const hsvOf = hex => { const c = O.color.parse(hex) || { r: 0, g: 0, b: 0 }; return O.color.toHsv(c); };
  const TYPE_TITLES = { solid: 'Суцільний', linear: 'Лінійний градієнт', radial: 'Радіальний градієнт', image: 'Зображення' };
  pk.close = () => {
    if (!pk.el) return;
    pk.el.remove(); pk.el = null;
    const st = pk.st; pk.st = null;
    document.removeEventListener('pointerdown', pk.outside, true);
    if (st && st.onClose) st.onClose();
  };
  pk.outside = e => { if (pk.el && !pk.el.contains(e.target) && !(pk.st && pk.st.anchor && pk.st.anchor.contains(e.target))) pk.close(); };
  pk.open = (anchor, paint, opts = {}) => {
    if (pk.el) pk.close();
    pk.st = Object.assign({ anchor, paint: O.clone(paint), stop: 0, mode: O.ls.get('pickerMode', 'hex') }, opts);
    const el = pk.el = O.h(`<div class="picker" role="dialog" aria-label="${esc(t('Колір'))}">
      <div class="pk-top"><div class="pk-tabs">${(opts.types || ['solid', 'linear', 'radial', 'image']).map(ty => `<button type="button" data-t="${ty}" title="${esc(t(TYPE_TITLES[ty]))}" aria-label="${esc(t(TYPE_TITLES[ty]))}">${{ solid: '<span class="sw-ic solid"></span>', linear: '<span class="sw-ic lin"></span>', radial: '<span class="sw-ic rad"></span>', image: O.icon('image', 15) }[ty]}</button>`).join('')}</div><button type="button" class="ib" data-a="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 14)}</button></div>
      <div class="pk-body"></div></div>`);
    document.body.appendChild(el);
    const r = anchor.getBoundingClientRect();
    const w = 252;
    let x = r.left - w - 12;
    if (x < 8) x = Math.min(window.innerWidth - w - 8, r.right + 12);
    el.style.left = Math.max(8, x) + 'px';
    el.style.top = Math.max(8, Math.min(window.innerHeight - 470, r.top - 40)) + 'px';
    el.addEventListener('click', e => {
      const tb = e.target.closest('[data-t]');
      if (tb) { pk.setType(tb.dataset.t); return; }
      if (e.target.closest('[data-a="close"]')) pk.close();
    });
    setTimeout(() => document.addEventListener('pointerdown', pk.outside, true), 0);
    pk.build();
  };
  O.on('lang', () => pk.close());
  pk.emit = () => { if (pk.st && pk.st.onChange) pk.st.onChange(O.clone(pk.st.paint)); };
  pk.setType = ty => {
    const st = pk.st, p = st.paint;
    if (p.type === ty) return;
    const base = O.paintColor(p);
    let np;
    if (ty === 'solid') np = O.paint.solid(base, p.opacity);
    else if (ty === 'linear' || ty === 'radial') {
      np = ty === 'linear' ? O.paint.linear(base, '#FFFFFF') : O.paint.radial(base, '#FFFFFF');
      if (p.stops) np.stops = O.clone(p.stops);
      np.opacity = p.opacity === undefined ? 1 : p.opacity;
    } else if (ty === 'image') np = Object.assign(O.paint.image(p.asset || null), { opacity: p.opacity === undefined ? 1 : p.opacity });
    st.paint = np; st.stop = 0;
    pk.build(); pk.emit();
  };
  pk.color = () => { const p = pk.st.paint; if (p.type === 'solid') return { hex: p.color, a: p.opacity }; const s = p.stops && p.stops[pk.st.stop]; return s ? { hex: s.color, a: s.a === undefined ? 1 : s.a } : { hex: '#000000', a: 1 }; };
  pk.setColor = (hex, a) => {
    const p = pk.st.paint;
    if (p.type === 'solid') { p.color = hex; if (a !== undefined) p.opacity = a; }
    else if (p.stops && p.stops[pk.st.stop]) { p.stops[pk.st.stop].color = hex; if (a !== undefined) p.stops[pk.st.stop].a = a; }
    pk.refresh(); pk.emit();
  };
  pk.build = () => {
    const st = pk.st, p = st.paint, body = pk.el.querySelector('.pk-body');
    pk.el.querySelectorAll('.pk-tabs button').forEach(b => b.classList.toggle('on', b.dataset.t === p.type));
    if (p.type === 'image') {
      // like Figma's image fill: mode, 90° turn, crop (zoom + position), adjustments, background removal
      const a = p.asset && S.doc.assets[p.asset];
      const nodes = (st.nodes || []).filter(n => n && n.fills && n.fills.some(f => f.type === 'image'));
      const PF = O.photo, adj = (nodes[0] && nodes[0].adjust) || {}, cr = p.crop || {};
      const range = (attr, label, min, max, v, unit = '') => `<label class="pk-rng"><span>${esc(t(label))}</span><input type="range" ${attr} min="${min}" max="${max}" step="1" value="${Math.round(v)}" aria-label="${esc(t(label))}"><em>${Math.round(v)}${unit}</em></label>`;
      body.innerHTML = `<div class="pk-img">${a ? `<img src="${esc(O.assetURL(p.asset))}" alt=""${p.rot ? ` style="transform:rotate(${p.rot}deg)"` : ''}>` : `<div class="pk-noimg">${esc(t('Зображення не обрано'))}</div>`}</div>
        <div class="pk-imgbar"><button type="button" class="btn" data-a="pickimg">${O.icon('image', 14)} ${esc(t('Обрати…'))}</button><button type="button" class="ib" data-a="rot90" title="${esc(t('Повернути на 90°'))}" aria-label="${esc(t('Повернути на 90°'))}">${O.icon('rot90', 15)}</button><button type="button" class="ib" data-a="rmbg" title="${esc(t('Видалити фон'))}" aria-label="${esc(t('Видалити фон'))}"${a ? '' : ' disabled'}>${O.icon('eraser', 15)}</button>${p.origAsset ? `<button type="button" class="ib" data-a="orig" title="${esc(t('Повернути оригінал'))}" aria-label="${esc(t('Повернути оригінал'))}">${O.icon('image', 15)}</button>` : ''}</div>
        <label class="pk-row"><span>${esc(t('Режим'))}</span><select id="pk-imgmode">${[['fill', 'Заповнити'], ['fit', 'Вмістити'], ['crop', 'Кадрувати'], ['tile', 'Плитка'], ['stretch', 'Розтягнути']].map(([v, l]) => `<option value="${v}"${(p.mode || 'fill') === v ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select></label>
        ${p.mode === 'tile' ? `<label class="pk-row"><span>${esc(t('Масштаб плитки'))}</span><input id="pk-imgscale" type="number" step="0.1" min="0.05" value="${p.scale || 1}"></label>` : ''}
        ${p.mode === 'crop' ? range('data-cr="z"', 'Масштаб', 100, 500, (cr.z || 1) * 100, '%') + range('data-cr="x"', 'Положення X', 0, 100, (cr.x === undefined ? 0.5 : cr.x) * 100, '%') + range('data-cr="y"', 'Положення Y', 0, 100, (cr.y === undefined ? 0.5 : cr.y) * 100, '%') : ''}
        <label class="pk-row"><span>${esc(t('Непрозорість'))}</span><input id="pk-imgop" type="number" min="0" max="100" value="${Math.round((p.opacity === undefined ? 1 : p.opacity) * 100)}"></label>
        ${PF && nodes.length ? `<div class="pk-sub">${esc(t('Налаштування'))}${PF.hasAdj(adj) ? `<button type="button" class="link" data-a="adjreset">${esc(t('Скинути'))}</button>` : ''}</div>${PF.ADJ.map(([k, l, mn, mx]) => range(`data-adj="${k}"`, l, mn, mx, adj[k] || 0)).join('')}` : ''}
        <div class="pk-st" role="status" aria-live="polite"></div>`;
      const setImg = id => { p.asset = id; pk.build(); pk.emit(); };
      body.querySelector('[data-a="pickimg"]').onclick = async () => {
        const files = await O.io.pickFiles('image/*');
        if (!files[0]) return;
        const data = await O.io.blobToData(files[0]);
        const asset = await O.io.addAsset(data, files[0].name);
        delete p.origAsset;
        setImg(asset.id);
      };
      body.querySelector('[data-a="rot90"]').onclick = () => { p.rot = ((p.rot || 0) + 90) % 360; pk.build(); pk.emit(); };
      body.querySelector('[data-a="rmbg"]').onclick = async e => {
        if (!O.imgfx || !p.asset) return;
        const btn = e.currentTarget, stEl = body.querySelector('.pk-st');
        btn.disabled = true;
        const id = await O.imgfx.removeBg(p.asset, msg => { if (stEl.isConnected) stEl.textContent = msg; });
        if (!pk.st || pk.st.paint !== p) return; // the picker was closed or switched meanwhile
        if (!id) { btn.disabled = false; stEl.textContent = ''; return; }
        if (!p.origAsset) p.origAsset = p.asset;
        setImg(id);
      };
      const orig = body.querySelector('[data-a="orig"]');
      if (orig) orig.onclick = () => { const id = p.origAsset; delete p.origAsset; setImg(id); };
      const reset = body.querySelector('[data-a="adjreset"]');
      if (reset) reset.onclick = () => { nodes.forEach(n => { delete n.adjust; }); O.requestRender(); pk.build(); };
      body.querySelector('#pk-imgmode').onchange = e => { p.mode = e.target.value; pk.build(); pk.emit(); };
      const sc = body.querySelector('#pk-imgscale');
      if (sc) sc.onchange = e => { p.scale = Math.max(0.05, parseFloat(e.target.value) || 1); pk.emit(); };
      body.querySelector('#pk-imgop').onchange = e => { p.opacity = O.clamp((parseFloat(e.target.value) || 0) / 100, 0, 1); pk.emit(); };
      body.querySelectorAll('.pk-rng input').forEach(inp => inp.addEventListener('input', () => {
        const v = +inp.value;
        inp.nextElementSibling.textContent = v + (inp.dataset.cr ? '%' : '');
        if (inp.dataset.cr) { p.crop = Object.assign({ z: 1, x: 0.5, y: 0.5 }, p.crop, { [inp.dataset.cr]: v / 100 }); pk.emit(); }
        else { nodes.forEach(n => { n.adjust = Object.assign({}, n.adjust, { [inp.dataset.adj]: v }); }); O.requestRender(); }
      }));
      return;
    }
    const grad = p.type === 'linear' || p.type === 'radial';
    body.innerHTML = `${grad ? `<div class="pk-grad"><div class="pk-gbar"></div><div class="pk-gstops"></div></div>
      <div class="pk-gtools"><button type="button" class="ib" data-a="flip" title="${esc(t('Розвернути градієнт'))}" aria-label="${esc(t('Розвернути градієнт'))}">${O.icon('flipH', 14)}</button><button type="button" class="ib" data-a="delstop" title="${esc(t('Видалити точку'))}" aria-label="${esc(t('Видалити точку'))}">${O.icon('trash', 14)}</button><span class="pk-hint">${esc(t('Клацніть на смугу, щоб додати точку'))}</span></div>` : ''}
      <div class="pk-sv"><canvas width="232" height="150"></canvas><i class="pk-svh"></i></div>
      <div class="pk-sl"><button type="button" class="ib" data-a="drop" title="${esc(t('Піпетка з екрана'))}" aria-label="${esc(t('Піпетка з екрана'))}"${window.EyeDropper ? '' : ' disabled'}>${O.icon('eyedropper', 16)}</button>
        <div class="pk-bars"><div class="pk-hue"><i></i></div><div class="pk-alpha"><div class="pk-alpha-c"></div><i></i></div></div></div>
      <div class="pk-vals"><select id="pk-mode" aria-label="${esc(t('Модель кольору'))}">${['hex', 'rgb', 'hsl', 'hsb', 'cmyk'].map(m => `<option value="${m}"${st.mode === m ? ' selected' : ''}>${m.toUpperCase()}</option>`).join('')}</select><div class="pk-fields"></div><label class="pk-op"><input id="pk-a" type="number" min="0" max="100" aria-label="${esc(t('Непрозорість'))}"><em>%</em></label></div>
      <div class="pk-sw"><div class="pk-swl">${esc(t('Кольори документа'))}</div><div class="pk-swatches"></div></div>`;
    const cv = body.querySelector('canvas'), svh = body.querySelector('.pk-svh');
    const hue = body.querySelector('.pk-hue'), alpha = body.querySelector('.pk-alpha');
    const hsv = hsvOf(pk.color().hex);
    const drawSV = () => {
      const c = cv.getContext('2d'), W = cv.width, H = cv.height;
      const base = O.color.fromHsv({ h: hsv.h, s: 1, v: 1 });
      c.fillStyle = `rgb(${base.r},${base.g},${base.b})`; c.fillRect(0, 0, W, H);
      let g = c.createLinearGradient(0, 0, W, 0); g.addColorStop(0, '#fff'); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(0, 0, W, H);
      g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, '#000'); c.fillStyle = g; c.fillRect(0, 0, W, H);
    };
    pk.refresh = () => {
      const { hex, a } = pk.color();
      const cur = hsvOf(hex);
      if (cur.v > 0 && cur.s > 0) hsv.h = cur.h;
      hsv.s = cur.s; hsv.v = cur.v;
      drawSV();
      svh.style.left = (hsv.s * 100) + '%'; svh.style.top = ((1 - hsv.v) * 100) + '%';
      hue.querySelector('i').style.left = (hsv.h / 360 * 100) + '%';
      alpha.querySelector('.pk-alpha-c').style.background = `linear-gradient(90deg, transparent, ${hex})`;
      alpha.querySelector('i').style.left = (a * 100) + '%';
      const aIn = body.querySelector('#pk-a');
      if (document.activeElement !== aIn) aIn.value = Math.round(a * 100);
      pk.fields(hex);
      if (grad) pk.gradUI();
      pk.swatches();
    };
    pk.fields = hex => {
      const box = body.querySelector('.pk-fields');
      if (box.contains(document.activeElement)) return;
      const c = O.color.parse(hex) || { r: 0, g: 0, b: 0 };
      const mode = st.mode;
      const R0 = v => Math.round(v);
      let vals;
      if (mode === 'hex') vals = [['hex', hex.replace('#', '')]];
      else if (mode === 'rgb') vals = [['r', R0(c.r)], ['g', R0(c.g)], ['b', R0(c.b)]];
      else if (mode === 'hsl') { const h = O.color.toHsl(c); vals = [['h', R0(h.h)], ['s', R0(h.s * 100)], ['l', R0(h.l * 100)]]; }
      else if (mode === 'hsb') { const h = O.color.toHsv(c); vals = [['h', R0(h.h)], ['s', R0(h.s * 100)], ['b', R0(h.v * 100)]]; }
      else { const k = O.color.toCmyk(c); vals = [['c', R0(k.c * 100)], ['m', R0(k.m * 100)], ['y', R0(k.y * 100)], ['k', R0(k.k * 100)]]; }
      box.innerHTML = vals.map(([k, v]) => `<input data-c="${k}" value="${v}" aria-label="${k.toUpperCase()}" ${k === 'hex' ? 'class="hex" maxlength="9" spellcheck="false"' : ''}>`).join('');
    };
    const readFields = () => {
      const box = body.querySelector('.pk-fields');
      const v = {}; box.querySelectorAll('input').forEach(i => { v[i.dataset.c] = i.value; });
      const mode = st.mode; let c;
      if (mode === 'hex') { const f = O.color.field(v.hex); if (f) { pk.setColor(f.hex, f.a === null ? undefined : f.a); return; } c = null; }
      else if (mode === 'rgb') c = { r: +v.r, g: +v.g, b: +v.b };
      else if (mode === 'hsl') c = O.color.fromHsl({ h: (+v.h % 360 + 360) % 360, s: O.clamp(+v.s / 100, 0, 1), l: O.clamp(+v.l / 100, 0, 1) });
      else if (mode === 'hsb') c = O.color.fromHsv({ h: (+v.h % 360 + 360) % 360, s: O.clamp(+v.s / 100, 0, 1), v: O.clamp(+v.b / 100, 0, 1) });
      else c = O.color.fromCmyk({ c: O.clamp(+v.c / 100, 0, 1), m: O.clamp(+v.m / 100, 0, 1), y: O.clamp(+v.y / 100, 0, 1), k: O.clamp(+v.k / 100, 0, 1) });
      if (c && [c.r, c.g, c.b].every(isFinite)) pk.setColor(O.color.hex(c));
    };
    body.querySelector('.pk-fields').addEventListener('change', readFields);
    // HEX: Cyrillic layout letters → A–F; a complete value applies while typing
    body.querySelector('.pk-fields').addEventListener('input', e => {
      const i = e.target;
      if (!i.classList.contains('hex')) return;
      const lat = O.color.latinHex(i.value);
      if (lat !== i.value) { const p = i.selectionStart; i.value = lat; try { i.setSelectionRange(p, p); } catch (err) { /* ignore */ } }
      if (/^#?([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(lat.trim())) readFields();
    });
    body.querySelector('.pk-fields').addEventListener('keydown', e => { if (e.key === 'Enter') { readFields(); e.target.blur(); } e.stopPropagation(); });
    body.querySelector('#pk-mode').onchange = e => { st.mode = e.target.value; O.ls.set('pickerMode', st.mode); pk.fields(pk.color().hex); };
    body.querySelector('#pk-a').onchange = e => pk.setColor(pk.color().hex, O.clamp((parseFloat(e.target.value) || 0) / 100, 0, 1));
    const drag = (target, fn) => target.addEventListener('pointerdown', e => {
      e.preventDefault();
      try { target.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      const r = target.getBoundingClientRect();
      const mv = ev => fn(O.clamp((ev.clientX - r.left) / r.width, 0, 1), O.clamp((ev.clientY - r.top) / r.height, 0, 1));
      mv(e);
      const up = () => { target.removeEventListener('pointermove', mv); target.removeEventListener('pointerup', up); };
      target.addEventListener('pointermove', mv); target.addEventListener('pointerup', up);
    });
    drag(body.querySelector('.pk-sv'), (x, y) => { hsv.s = x; hsv.v = 1 - y; pk.setColor(O.color.hex(O.color.fromHsv(hsv))); });
    drag(hue, x => { hsv.h = Math.min(359.9, x * 360); pk.setColor(O.color.hex(O.color.fromHsv(hsv))); });
    drag(alpha, x => pk.setColor(pk.color().hex, Math.round(x * 100) / 100));
    body.querySelector('[data-a="drop"]').onclick = async () => {
      if (!window.EyeDropper) return;
      try { const r = await new window.EyeDropper().open(); pk.setColor(O.color.norm(r.sRGBHex)); } catch (e) { /* cancelled */ }
    };
    pk.swatches = () => {
      const box = body.querySelector('.pk-swatches');
      box.innerHTML = (S.doc.swatches || []).map(s => `<button type="button" class="sw" style="--c:${s.color}" data-hex="${s.color}" title="${esc(s.name)} ${s.color}"></button>`).join('') + `<button type="button" class="sw add" data-a="addsw" title="${esc(t('Додати поточний колір у зразки'))}" aria-label="${esc(t('Додати поточний колір у зразки'))}">${O.icon('plus', 12)}</button>`;
    };
    body.querySelector('.pk-swatches').addEventListener('click', e => {
      const b = e.target.closest('.sw');
      if (!b) return;
      if (b.dataset.a === 'addsw') {
        S.doc.swatches.push({ id: O.uid(), name: t('Колір {n}', { n: S.doc.swatches.length + 1 }), color: pk.color().hex });
        O.history.commit('Зразок кольору');
        pk.swatches();
        return;
      }
      pk.setColor(b.dataset.hex);
    });
    if (grad) {
      const bar = body.querySelector('.pk-gbar'), stopsBox = body.querySelector('.pk-gstops');
      pk.gradUI = () => {
        const sorted = p.stops.slice().sort((a, b) => a.o - b.o);
        bar.style.background = `linear-gradient(90deg, ${sorted.map(s => O.color.rgba(s.color, s.a === undefined ? 1 : s.a) + ' ' + (s.o * 100) + '%').join(', ')}), var(--checker)`;
        stopsBox.innerHTML = p.stops.map((s, i) => `<button type="button" class="pk-stop${i === st.stop ? ' on' : ''}" data-s="${i}" style="left:${s.o * 100}%;--c:${s.color}" aria-label="${esc(t('Точка {n}', { n: i + 1 }))}"></button>`).join('');
      };
      bar.addEventListener('pointerdown', e => {
        const r = bar.getBoundingClientRect();
        const tt = O.clamp((e.clientX - r.left) / r.width, 0, 1);
        const sorted = p.stops.slice().sort((a, b) => a.o - b.o);
        let c = sorted[0].color;
        for (let i = 0; i < sorted.length - 1; i++) if (tt >= sorted[i].o && tt <= sorted[i + 1].o) c = O.color.mix(sorted[i].color, sorted[i + 1].color, (tt - sorted[i].o) / ((sorted[i + 1].o - sorted[i].o) || 1));
        p.stops.push({ o: tt, color: c, a: 1 });
        st.stop = p.stops.length - 1;
        pk.refresh(); pk.emit();
      });
      stopsBox.addEventListener('pointerdown', e => {
        const b = e.target.closest('.pk-stop');
        if (!b) return;
        e.preventDefault();
        st.stop = +b.dataset.s;
        const r = bar.getBoundingClientRect();
        try { b.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        const mv = ev => { p.stops[st.stop].o = O.clamp((ev.clientX - r.left) / r.width, 0, 1); pk.gradUI(); pk.emit(); };
        const up = () => { b.removeEventListener('pointermove', mv); b.removeEventListener('pointerup', up); pk.refresh(); };
        b.addEventListener('pointermove', mv); b.addEventListener('pointerup', up);
        pk.refresh();
      });
      body.querySelector('[data-a="delstop"]').onclick = () => { if (p.stops.length > 2) { p.stops.splice(st.stop, 1); st.stop = 0; pk.refresh(); pk.emit(); } };
      body.querySelector('[data-a="flip"]').onclick = () => { p.stops.forEach(s => { s.o = 1 - s.o; }); pk.refresh(); pk.emit(); };
    } else pk.gradUI = () => {};
    pk.refresh();
  };

  // ---------- toolbar (labels are translation keys) ----------
  ui.TOOLS = {
    select: { label: 'Виділення', key: 'V', icon: 'select' }, direct: { label: 'Пряме виділення', key: 'A', icon: 'direct' },
    free: { label: 'Вільна трансформація (нахил за сторони)', key: 'E', icon: 'free' }, hand: { label: 'Рука', key: 'H', icon: 'hand' }, zoom: { label: 'Масштаб перегляду', key: 'Z', icon: 'zoom' },
    frame: { label: 'Фрейм / монтажна область', key: 'F', icon: 'frame' },
    rect: { label: 'Прямокутник', key: 'R', icon: 'rect' }, line: { label: 'Лінія', key: 'L', icon: 'line' }, arrow: { label: 'Стрілка', key: 'Shift+L', icon: 'arrow' },
    ellipse: { label: 'Еліпс', key: 'O', icon: 'ellipse' }, polygon: { label: 'Багатокутник', key: '', icon: 'polygon' }, star: { label: 'Зірка', key: '', icon: 'star' },
    arc: { label: 'Дуга', key: '', icon: 'arc' }, spiral: { label: 'Спіраль', key: '', icon: 'spiral' }, grid: { label: 'Прямокутна сітка', key: '', icon: 'grid' }, polar: { label: 'Полярна сітка', key: '', icon: 'polar' },
    pen: { label: 'Перо', key: 'P', icon: 'pen' }, pencil: { label: 'Олівець', key: 'Shift+P', icon: 'pencil' }, brush: { label: 'Пензель', key: 'B', icon: 'brush' },
    blob: { label: 'Пензель-клякса', key: 'Shift+B', icon: 'blob' }, eraser: { label: 'Гумка', key: 'Shift+E', icon: 'eraser' }, scissors: { label: 'Ножиці', key: 'C', icon: 'scissors' }, knife: { label: 'Ніж', key: '', icon: 'knife' },
    text: { label: 'Текст', key: 'T', icon: 'text' }, textpath: { label: 'Текст по контуру', key: 'Shift+T', icon: 'textpath' },
    rotate: { label: 'Поворот', key: '', icon: 'rotate' }, reflect: { label: 'Віддзеркалення', key: '', icon: 'reflect' }, scale: { label: 'Масштабування', key: 'K', icon: 'scale' }, shear: { label: 'Нахил', key: '', icon: 'shear' },
    gradient: { label: 'Градієнт', key: 'G', icon: 'gradient' }, eyedropper: { label: 'Піпетка', key: 'I', icon: 'eyedropper' }, blend: { label: 'Перехід', key: 'Alt+Shift+W', icon: 'blend' }, shapebuilder: { label: 'Створення фігур', key: 'Shift+M', icon: 'shapebuilder' }
  };
  ui.TOOL_GROUPS = [
    ['select', 'direct', 'free', 'hand', 'zoom'],
    ['frame'],
    ['rect', 'line', 'arrow', 'ellipse', 'polygon', 'star', 'arc', 'spiral', 'grid', 'polar'],
    ['pen', 'pencil', 'brush', 'blob', 'eraser', 'scissors', 'knife'],
    ['text', 'textpath'],
    ['rotate', 'reflect', 'scale', 'shear'],
    ['gradient', 'eyedropper', 'blend', 'shapebuilder']
  ];
  const groupCurrent = ui.TOOL_GROUPS.map(g => g[0]);
  ui.buildToolbar = el => {
    const render = () => {
      el.setAttribute('aria-label', t('Інструменти'));
      el.innerHTML = ui.TOOL_GROUPS.map((g, gi) => {
        if (g.includes(S.tool)) groupCurrent[gi] = S.tool;
        // groups added by modules after start-up
        if (!groupCurrent[gi] || !g.includes(groupCurrent[gi])) groupCurrent[gi] = g[0];
        const tl = groupCurrent[gi], d = ui.TOOLS[tl];
        const on = g.includes(S.tool);
        const name = t(d.label);
        return `<div class="tb-grp${on ? ' on' : ''}"><button type="button" class="tb-btn" data-tool="${tl}" title="${esc(name)}${d.key ? ' (' + esc(O.keyLabel(d.key)) + ')' : ''}" aria-label="${esc(name)}" aria-pressed="${on}">${O.icon(d.icon, 20)}</button>${g.length > 1 ? `<button type="button" class="tb-more" data-g="${gi}" aria-label="${esc(t('Інші інструменти групи'))}">${O.icon('chevdown', 12)}</button>` : ''}</div>`;
      }).join('<span class="tb-sep"></span>') + '<span class="tb-sep"></span>' + `<button type="button" class="tb-btn" data-cmd="placeImage" title="${esc(t('Помістити зображення'))} (${esc(O.keyLabel('Ctrl+Shift+K'))})" aria-label="${esc(t('Помістити зображення'))}">${O.icon('image', 20)}</button>`;
    };
    render();
    O.on('tool', render);
    O.on('lang', render);
    el.addEventListener('click', e => {
      const b = e.target.closest('[data-tool]');
      if (b) { O.setTool(b.dataset.tool); return; }
      const c = e.target.closest('[data-cmd]');
      if (c) { O.run(c.dataset.cmd); return; }
      const m = e.target.closest('[data-g]');
      if (m) {
        const g = ui.TOOL_GROUPS[+m.dataset.g];
        const r = m.getBoundingClientRect();
        const items = g.map(tl => ({ id: 'tool:' + tl, label: ui.TOOLS[tl].label, keys: ui.TOOLS[tl].key ? [ui.TOOLS[tl].key] : [], check: () => S.tool === tl }));
        const menu = ui.menu(items, r.left - 20, r.top, { onPick: id => O.setTool(id.slice(5)) });
        const mr = menu.getBoundingClientRect();
        menu.style.top = Math.max(4, r.top - mr.height - 8) + 'px';
      }
    });
    el.addEventListener('dblclick', e => {
      const b = e.target.closest('[data-tool]');
      if (b && ['rotate', 'reflect', 'scale', 'shear'].includes(b.dataset.tool)) O.ops.transformDialog(b.dataset.tool);
    });
  };

  // ---------- tool options bar ----------
  const TO = O.toolOpts;
  const optNum = (k, label, min, max, step = 1, unit = '') => `<label class="to-f"><span>${esc(t(label))}</span><input type="number" data-o="${k}" value="${TO[k]}" min="${min}" max="${max}" step="${step}">${unit ? `<em>${unit}</em>` : ''}</label>`;
  const optColor = (k, label) => `<label class="to-f"><span>${esc(t(label))}</span><input type="color" data-o="${k}" value="${TO[k]}"></label>`;
  const hint = s => `<span class="to-hint">${esc(t(s))}</span>`;
  const numBtn = k => `<button type="button" class="btn" data-x="${k}">${esc(t('Числове значення…'))}</button>`;
  ui.TOOL_OPTIONS = {
    pencil: () => optNum('pencilSmooth', 'Згладжування', 0.5, 20, 0.5) + optNum('pencilWidth', 'Товщина', 0.1, 200, 0.5, 'px') + optColor('pencilColor', 'Колір'),
    brush: () => `<label class="to-f"><span>${esc(t('Пензель'))}</span><select data-o="brushType">${[['calligraphic', 'Каліграфічний'], ['round', 'Круглий'], ['taper', 'Конусний']].map(([v, l]) => `<option value="${v}"${TO.brushType === v ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select></label>` + optNum('brushSize', 'Розмір', 0.5, 300, 0.5, 'px') + (TO.brushType === 'calligraphic' ? optNum('brushAngle', 'Кут', -180, 180, 1, '°') + optNum('brushRound', 'Округлість', 0.02, 1, 0.05) : '') + optColor('brushColor', 'Колір'),
    blob: () => optNum('blobSize', 'Розмір', 1, 500, 1, 'px') + optColor('blobColor', 'Колір'),
    eraser: () => optNum('eraserSize', 'Розмір', 2, 400, 1, 'px') + hint('Стирає виділені об’єкти (або все під гумкою)'),
    polygon: () => optNum('polySides', 'Сторін', 3, 60),
    star: () => optNum('starPoints', 'Промені', 3, 60) + optNum('starInner', 'Внутрішній радіус', 0.05, 1, 0.01),
    spiral: () => optNum('spiralSegs', 'Сегментів', 2, 60) + optNum('spiralDecay', 'Згасання', 0.05, 0.99, 0.01),
    grid: () => optNum('gridRows', 'Рядків', 1, 50) + optNum('gridCols', 'Стовпців', 1, 50),
    polar: () => optNum('polarRings', 'Кілець', 1, 50) + optNum('polarRays', 'Променів', 1, 72),
    blend: () => optNum('blendSteps', 'Кроків', 1, 200) + hint('Клацніть перший, потім другий об’єкт'),
    knife: () => hint('Проведіть лінію через фігури, щоб розрізати їх'),
    scissors: () => hint('Клацніть на контур, щоб розрізати його в цій точці'),
    pen: () => hint('Клік — кутовий вузол, тягніть — плавний. Alt — злам маркера. Enter/Esc — завершити'),
    rotate: () => numBtn('rotate') + hint('Клік — центр повороту, Alt — копія'),
    reflect: () => numBtn('reflect') + hint('Клік — точка осі, тягніть — кут осі'),
    scale: () => numBtn('scale') + hint('Shift — пропорційно, Alt — копія'),
    shear: () => numBtn('shear'),
    shapebuilder: () => hint('Тягніть через області — об’єднати, Alt+клік — видалити'),
    gradient: () => hint('Тягніть по об’єкту — напрям градієнта. Подвійний клік на лінії — нова точка'),
    textpath: () => hint('Клацніть на контур, щоб писати вздовж нього'),
    free: () => hint('Тягніть сторони рамки, щоб нахилити об’єкт')
  };
  ui.buildToolOptions = el => {
    const render = () => {
      const f = ui.TOOL_OPTIONS[S.tool];
      el.hidden = !f;
      el.innerHTML = f ? `<span class="to-name">${esc(t(ui.TOOLS[S.tool].label))}</span>${f()}` : '';
    };
    render();
    O.on('tool', render);
    O.on('lang', render);
    el.addEventListener('change', e => {
      const k = e.target.dataset.o;
      if (!k) return;
      TO[k] = e.target.type === 'number' ? parseFloat(e.target.value) : e.target.value;
      O.saveToolOpts();
      if (k === 'brushType') render();
    });
    el.addEventListener('click', e => { const x = e.target.closest('[data-x]'); if (x) O.ops.transformDialog(x.dataset.x); });
    el.addEventListener('keydown', e => e.stopPropagation());
  };
})();
