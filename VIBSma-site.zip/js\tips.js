'use strict';
/* VIBSma — tooltips like Photoshop's.
   Every button with a title gets a dark tooltip with the name and the shortcut in a key cap; the tools of the
   toolbar get Photoshop's «rich tooltip»: a large icon, the name, the shortcut and what the tool does.
   Вигляд → «Розширені підказки» switches the descriptions off, «Показувати підказки» hides them all. */
(function () {
  const O = window.O, S = O.state, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const TP = O.tips = {};
  // what the tools do (translation keys)
  TP.TOOLS = {
    select: 'Виділяє, переміщує й змінює розмір об’єктів. Подвійний клік — увійти в групу.',
    direct: 'Виділяє окремі вузли й маркери контуру, щоб змінити його форму.',
    free: 'Вільна трансформація: тягніть за сторони, щоб нахилити, за кути — щоб масштабувати.',
    hand: 'Пересуває полотно. Утримуйте Пробіл з будь-яким інструментом.',
    zoom: 'Клік — наблизити, Alt+клік — віддалити, протягніть рамку — показати область.',
    frame: 'Створює фрейм (монтажну область) для сторінки, екрана чи слайда.',
    rect: 'Малює прямокутник. Shift — квадрат, Alt — від центру.',
    line: 'Малює пряму лінію. Shift — кроки по 45°.',
    arrow: 'Малює лінію зі стрілкою на кінці.',
    ellipse: 'Малює еліпс. Shift — коло, Alt — від центру.',
    polygon: 'Малює багатокутник. Стрілки ↑↓ під час малювання змінюють кількість сторін.',
    star: 'Малює зірку. Стрілки ↑↓ змінюють кількість променів.',
    arc: 'Малює дугу.',
    spiral: 'Малює спіраль.',
    grid: 'Малює прямокутну сітку.',
    polar: 'Малює полярну (кругову) сітку.',
    pen: 'Ставить вузли контуру: клік — кут, протягнути — крива. Клік на першому вузлі замикає контур.',
    pencil: 'Малює довільну лінію від руки, яка потім згладжується.',
    brush: 'Пензель: штрих із формою пензля (каліграфічний, круглий, конусний).',
    blob: 'Пензель-клякса малює заповнені фігури, які зливаються між собою.',
    eraser: 'Стирає частини векторних фігур.',
    scissors: 'Розрізає контур у точці кліку.',
    knife: 'Розрізає фігури вздовж лінії, яку ви проводите.',
    text: 'Клік — точковий текст, протягнути — текстова рамка з переносом рядків.',
    textpath: 'Розміщує текст уздовж виділеного контуру.',
    rotate: 'Обертає виділене навколо опорної точки. Клік ставить опорну точку.',
    reflect: 'Віддзеркалює виділене відносно осі.',
    scale: 'Масштабує виділене разом з обведенням, ефектами й заливками. Shift — пропорційно, Alt — копія.',
    shear: 'Нахиляє виділене.',
    gradient: 'Тягніть по об’єкту, щоб задати напрямок і довжину градієнта.',
    eyedropper: 'Бере колір і стиль з об’єкта, на який ви клацнули.',
    blend: 'Створює плавний перехід форми й кольору між двома об’єктами.',
    shapebuilder: 'Об’єднує ділянки фігур, через які ви протягуєте. Alt — видаляє ділянки.',
    comment: 'Залишає коментар на полотні для спільної роботи.'
  };
  const settings = () => S.settings || {};
  const on = () => settings().tips !== false;
  const rich = () => settings().richTips !== false;

  let tipEl = null, timer = 0, cur = null;
  const hide = () => { clearTimeout(timer); timer = 0; cur = null; if (tipEl) tipEl.hidden = true; };
  TP.hide = hide;
  const ensure = () => {
    if (tipEl && tipEl.isConnected) return tipEl;
    tipEl = O.h('<div class="ps-tip" role="tooltip" hidden></div>');
    document.body.appendChild(tipEl);
    return tipEl;
  };
  // «Name (Ctrl+S)» → name + key caps
  const split = s => {
    const m = String(s).match(/^(.*?)\s*\(([^()]*(?:Ctrl|Alt|Shift|Strg|Umschalt|Esc|Enter|Space|Пробіл|Tab|F\d+|⌘|⌥|⇧|\b[A-Z0-9]\b)[^()]*)\)\s*$/);
    return m ? { name: m[1], keys: m[2] } : { name: s, keys: '' };
  };
  const caps = k => k.split(/\s*\/\s*|\s*,\s*/).map(part => `<span class="ps-keys">${part.split('+').map(x => `<kbd>${esc(x)}</kbd>`).join('<i>+</i>')}</span>`).join(' ');
  const contentFor = el => {
    const text = el.dataset.tip || '';
    const tool = el.dataset.tool;
    if (tool && ui.TOOLS[tool] && rich()) {
      const d = ui.TOOLS[tool];
      const desc = TP.TOOLS[tool];
      return { rich: true, html: `<div class="ps-tip-ic">${O.icon(d.icon, 30)}</div><div class="ps-tip-b"><div class="ps-tip-h"><b>${esc(t(d.label))}</b>${d.key ? caps(O.keyLabel(d.key)) : ''}</div>${desc ? `<p>${esc(t(desc))}</p>` : ''}${el.parentElement && el.parentElement.querySelector('.tb-more') ? `<em>${esc(t('Стрілка поруч — інші інструменти групи'))}</em>` : ''}</div>` };
    }
    if (!text) return null;
    const { name, keys } = split(text);
    return { rich: false, html: `<span>${esc(name)}</span>${keys ? caps(keys) : ''}` };
  };
  const place = el => {
    const r = el.getBoundingClientRect(), tip = ensure();
    const tr = tip.getBoundingClientRect();
    // below the element; above when there is no room; toolbar (bottom of the canvas) → above
    let y = r.bottom + 8;
    if (el.closest('#toolbar, .pr-bar, .ve-tl-bar') || y + tr.height > window.innerHeight - 6) y = r.top - tr.height - 8;
    let x = r.left + r.width / 2 - tr.width / 2;
    x = Math.max(6, Math.min(window.innerWidth - tr.width - 6, x));
    tip.style.left = Math.round(x) + 'px'; tip.style.top = Math.round(Math.max(6, y)) + 'px';
  };
  const show = el => {
    if (!el.isConnected || !on()) return;
    const c = contentFor(el);
    if (!c) return;
    const tip = ensure();
    tip.className = 'ps-tip' + (c.rich ? ' rich' : '');
    tip.innerHTML = c.html;
    tip.hidden = false;
    place(el);
  };
  // the title moves into data-tip so the browser's own tooltip stays away
  const adopt = el => {
    const tt = el.getAttribute('title');
    if (tt) { el.dataset.tip = tt; el.removeAttribute('title'); if (!el.getAttribute('aria-label') && !el.textContent.trim()) el.setAttribute('aria-label', tt); }
    return el.dataset.tip || el.dataset.tool;
  };
  document.addEventListener('pointerover', e => {
    if (e.pointerType === 'touch') return;
    const el = e.target.closest && e.target.closest('[title], [data-tip], #toolbar [data-tool]');
    if (!el || el === cur) return;
    if (el.closest('svg') && el.tagName !== 'svg' && !el.closest('button')) return;
    hide();
    if (!adopt(el) || !on()) return;
    cur = el;
    // Photoshop shows the tip after a short rest; once one is visible the next appears at once
    const quick = tipEl && !tipEl.hidden;
    timer = setTimeout(() => show(el), quick ? 60 : 550);
  }, true);
  document.addEventListener('pointerout', e => { if (cur && (!e.relatedTarget || !cur.contains(e.relatedTarget))) hide(); }, true);
  ['pointerdown', 'keydown', 'wheel'].forEach(ev => document.addEventListener(ev, hide, true));
  window.addEventListener('blur', hide);
  window.addEventListener('resize', hide);

  const toggle = k => () => { S.settings[k] = S.settings[k] === false; O.saveSettings(); if (S.settings[k] === false) hide(); };
  O.cmd('tipsShow', 'Показувати підказки', toggle('tips'), { group: 'Вигляд', check: () => on() });
  O.cmd('tipsRich', 'Розширені підказки (з описом інструмента)', toggle('richTips'), { group: 'Вигляд', check: () => rich(), enabled: () => on() });
  const view = O.MENUS.find(m => m[0] === 'Вигляд');
  if (view) { const i = view[1].indexOf('toggleUI'); view[1].splice(i < 0 ? view[1].length : i, 0, 'tipsShow', 'tipsRich'); }
})();
