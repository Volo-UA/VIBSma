'use strict';
/* VIBSma — animation: timeline, keyframes, easing, presets, playback, Lottie export (transparent background) */
(function () {
  const O = window.O, M = O.M, G = O.G, R = O.R, model = O.model, S = O.state, V = O.view, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const A = O.anim = { time: 0, playing: false, open: false, autoKey: true, selKey: null, raf: 0 };
  A.settings = () => S.doc.anim || (S.doc.anim = { fps: 30, duration: 3, loop: true });

  // ---------- easing ----------
  const EASE = { linear: [0, 0, 1, 1], inout: [0.42, 0, 0.58, 1], in: [0.42, 0, 1, 1], out: [0, 0, 0.58, 1], back: [0.34, 1.56, 0.64, 1], hold: [0, 0, 1, 1] };
  A.EASE_NAMES = [['inout', 'Плавно'], ['linear', 'Лінійно'], ['in', 'Розгін'], ['out', 'Гальмування'], ['back', 'Пружина'], ['hold', 'Утримання кадру']];
  const bezier = (x1, y1, x2, y2) => u => {
    if (u <= 0) return 0;
    if (u >= 1) return 1;
    const bx = s => 3 * (1 - s) * (1 - s) * s * x1 + 3 * (1 - s) * s * s * x2 + s * s * s;
    const by = s => 3 * (1 - s) * (1 - s) * s * y1 + 3 * (1 - s) * s * s * y2 + s * s * s;
    let lo = 0, hi = 1, s = u;
    for (let i = 0; i < 30; i++) { s = (lo + hi) / 2; if (bx(s) < u) lo = s; else hi = s; }
    return by(s);
  };

  // ---------- keyframe snapshots ----------
  const anchorOf = n => { const b = model.localBounds(n); return { x: b.x + b.w / 2, y: b.y + b.h / 2 }; };
  A.snap = n => {
    const a = anchorOf(n), d = M.decompose(n.m), p = M.apply(n.m, a);
    const s = { p: [p.x, p.y], a: [a.x, a.y], rot: O.deg(d.rot), sx: d.sx, sy: d.sy, sk: O.deg(d.skew), op: n.opacity === undefined ? 1 : n.opacity };
    if (n.w !== undefined && n.type !== 'text') { s.w = n.w; s.h = n.h; }
    s.fills = (n.fills || []).map(f => (f.type === 'solid' ? f.color : null));
    s.strokes = (n.strokes || []).map(f => (f.type === 'solid' ? f.color : null));
    s.sw = n.sw === undefined ? 1 : n.sw;
    s.ts = n.trimS === undefined ? 0 : n.trimS;
    s.te = n.trimE === undefined ? 1 : n.trimE;
    return s;
  };
  const compose = s => M.chain(M.translate(s.p[0], s.p[1]), M.rotate(O.rad(s.rot)), M.skewX(O.rad(s.sk || 0)), M.scale(s.sx, s.sy), M.translate(-s.a[0], -s.a[1]));
  A.applySnap = (n, s) => {
    if (s.w !== undefined && n.w !== undefined) { n.w = Math.max(0, s.w); n.h = Math.max(0, s.h); }
    n.m = compose(s);
    n.opacity = O.clamp(s.op, 0, 1);
    (s.fills || []).forEach((c, i) => { const f = (n.fills || [])[i]; if (c && f && f.type === 'solid') f.color = c; });
    (s.strokes || []).forEach((c, i) => { const f = (n.strokes || [])[i]; if (c && f && f.type === 'solid') f.color = c; });
    if (s.sw !== undefined && n.sw !== undefined) n.sw = Math.max(0, s.sw);
    if (s.ts > 0.0001 || s.te < 0.9999) { n.trimS = s.ts; n.trimE = s.te; } else { delete n.trimS; delete n.trimE; }
  };
  const L = O.lerp;
  A.interp = (a, b, u) => {
    const s = {
      p: [L(a.p[0], b.p[0], u), L(a.p[1], b.p[1], u)], a: [L(a.a[0], b.a[0], u), L(a.a[1], b.a[1], u)],
      rot: L(a.rot, b.rot, u), sx: L(a.sx, b.sx, u), sy: L(a.sy, b.sy, u), sk: L(a.sk || 0, b.sk || 0, u), op: L(a.op, b.op, u),
      sw: L(a.sw === undefined ? 1 : a.sw, b.sw === undefined ? 1 : b.sw, u), ts: L(a.ts || 0, b.ts || 0, u), te: L(a.te === undefined ? 1 : a.te, b.te === undefined ? 1 : b.te, u)
    };
    if (a.w !== undefined && b.w !== undefined) { s.w = L(a.w, b.w, u); s.h = L(a.h, b.h, u); }
    s.fills = (a.fills || []).map((c, i) => (c && b.fills && b.fills[i] ? O.color.mix(c, b.fills[i], u) : c));
    s.strokes = (a.strokes || []).map((c, i) => (c && b.strokes && b.strokes[i] ? O.color.mix(c, b.strokes[i], u) : c));
    return s;
  };
  A.stateAt = (n, time) => {
    const ks = n.anim;
    if (!ks || !ks.length) return null;
    if (time <= ks[0].t) return ks[0].s;
    if (time >= ks[ks.length - 1].t) return ks[ks.length - 1].s;
    for (let i = 0; i < ks.length - 1; i++) {
      const a = ks[i], b = ks[i + 1];
      if (time >= a.t && time <= b.t) {
        if (a.e === 'hold') return a.s;
        const e = EASE[a.e || 'inout'] || EASE.inout;
        return A.interp(a.s, b.s, bezier(e[0], e[1], e[2], e[3])((time - a.t) / ((b.t - a.t) || 1)));
      }
    }
    return ks[ks.length - 1].s;
  };
  A.nodes = () => { const out = []; model.walk(model.page().children, n => { if (n.anim && n.anim.length) out.push(n); }); return out; };
  A.applyAt = (time, quiet) => {
    const set = A.settings();
    A.time = O.clamp(time, 0, set.duration);
    for (const n of A.nodes()) { const s = A.stateAt(n, A.time); if (s) A.applySnap(n, s); }
    O.requestRender();
    A.drawPlayhead();
    if (!quiet && !A.playing) O.emit('change-soft');
  };
  const unwrap = (ref, deg) => { let d = deg; while (d - ref > 180) d -= 360; while (d - ref < -180) d += 360; return d; };
  A.recordKey = (n, time, prevSnap) => {
    n.anim = n.anim || [];
    const s = A.snap(n);
    const before = n.anim.filter(k => k.t < time - 1e-4).pop() || n.anim.find(k => k.t > time + 1e-4);
    if (before) s.rot = unwrap(before.s.rot, s.rot);
    if (!n.anim.length && prevSnap && time > 1e-3) n.anim.push({ t: 0, s: prevSnap, e: 'inout' });
    const ex = n.anim.find(k => Math.abs(k.t - time) < 1e-4);
    if (ex) ex.s = s; else n.anim.push({ t: time, s, e: 'inout' });
    n.anim.sort((a, b) => a.t - b.t);
    const set = A.settings();
    if (time > set.duration) set.duration = Math.ceil(time * 10) / 10;
  };
  A.addKeys = () => {
    const nodes = O.topSel();
    if (!nodes.length) return O.toast('Виділіть об’єкти, щоб додати ключовий кадр');
    nodes.forEach(n => A.recordKey(n, A.time, null));
    O.history.commit('Ключовий кадр');
    A.render();
  };
  A.deleteKey = () => {
    const k = A.selKey;
    if (!k) return O.toast('Оберіть ключовий кадр на таймлайні');
    const n = model.get(k.id);
    if (!n || !n.anim) return;
    n.anim.splice(k.i, 1);
    if (!n.anim.length) delete n.anim;
    A.selKey = null;
    O.history.commit('Видалення ключового кадру');
    A.render();
  };
  A.clearAnim = () => {
    const nodes = O.topSel();
    nodes.forEach(n => { delete n.anim; delete n.trimS; delete n.trimE; });
    O.history.commit('Видалення анімації');
    A.render();
  };
  // automatic keyframes: an edit at the playhead records a key (like After Effects with the stopwatch on)
  let recording = false;
  O.on('commit', label => {
    if (!A.open || !A.autoKey || recording || A.playing || /ключ|анімац|тривалість|частота|повтор|плавність/i.test(label || '')) return;
    const nodes = O.topSel();
    if (!nodes.length) return;
    let prevDoc = null;
    try { const prev = O.history.stack[O.history.idx - 1]; if (prev) { const p = JSON.parse(prev); prevDoc = p.doc || p; } } catch (e) { /* ignore */ }
    const findPrev = id => {
      if (!prevDoc) return null;
      let f = null;
      const walk = list => { for (const x of list) { if (f) return; if (x.id === id) { f = x; return; } if (x.children) walk(x.children); } };
      prevDoc.pages.forEach(pg => walk(pg.children));
      return f;
    };
    recording = true;
    let any = false;
    for (const n of nodes) {
      const animated = n.anim && n.anim.length;
      if (!animated && A.time < 1e-3) continue;
      const pn = !animated ? findPrev(n.id) : null;
      A.recordKey(n, A.time, pn ? A.snap(pn) : null);
      any = true;
    }
    if (any) O.history.amend();
    recording = false;
    if (any) A.render();
  });

  // ---------- presets ----------
  const PRESETS = [
    ['fadeIn', 'Поява', [[0, s => { s.op = 0; }, 'out'], [0.6, null]]],
    ['fadeOut', 'Зникнення', [[0, null, 'in'], [0.6, s => { s.op = 0; }]]],
    ['slideUp', 'Виїзд знизу', [[0, s => { s.p[1] += 60; s.op = 0; }, 'out'], [0.7, null]]],
    ['slideLeft', 'Виїзд справа', [[0, s => { s.p[0] += 120; s.op = 0; }, 'out'], [0.7, null]]],
    ['pop', 'Поп', [[0, s => { s.sx *= 0.3; s.sy *= 0.3; s.op = 0; }, 'out'], [0.35, s => { s.sx *= 1.08; s.sy *= 1.08; }, 'inout'], [0.55, null]]],
    ['spin', 'Обертання', [[0, null, 'linear'], [1, s => { s.rot += 360; }]]],
    ['pulse', 'Пульс', [[0, null, 'inout'], [0.4, s => { s.sx *= 1.1; s.sy *= 1.1; }, 'inout'], [0.8, null]]],
    ['bounce', 'Підстрибування', [[0, null, 'out'], [0.3, s => { s.p[1] -= 40; }, 'in'], [0.6, null]]],
    ['shake', 'Тремтіння', [[0, null, 'linear'], [0.08, s => { s.p[0] -= 10; }, 'linear'], [0.16, s => { s.p[0] += 10; }, 'linear'], [0.24, s => { s.p[0] -= 6; }, 'linear'], [0.32, null]]],
    ['draw', 'Малювання лінії', [[0, s => { s.ts = 0; s.te = 0; }, 'inout'], [1.2, s => { s.ts = 0; s.te = 1; }]]]
  ];
  A.applyPreset = id => {
    const pr = PRESETS.find(p => p[0] === id);
    const nodes = O.topSel();
    if (!pr || !nodes.length) return O.toast('Виділіть об’єкти, щоб додати анімацію');
    if (id === 'draw' && !nodes.some(n => (n.strokes || []).some(s => s.visible !== false) && n.sw > 0)) O.toast('«Малювання лінії» працює з обведенням: додайте обведення об’єкту');
    const t0 = A.time;
    let end = t0;
    for (const n of nodes) {
      const base = A.stateAt(n, t0) || A.snap(n);
      n.anim = (n.anim || []).filter(k => k.t < t0 - 1e-4 || k.t > t0 + pr[2][pr[2].length - 1][0] + 1e-4);
      for (const [dt, fn, ease] of pr[2]) {
        const s = O.clone(base);
        if (fn) fn(s);
        n.anim.push({ t: t0 + dt, s, e: ease || 'inout' });
        end = Math.max(end, t0 + dt);
      }
      n.anim.sort((a, b) => a.t - b.t);
    }
    const set = A.settings();
    if (end > set.duration) set.duration = Math.ceil(end * 10) / 10;
    O.history.commit('Пресет анімації');
    A.open = true;
    A.render();
    A.applyAt(t0);
  };

  // ---------- playback ----------
  A.play = () => {
    if (A.playing) return A.pause();
    const set = A.settings();
    if (A.time >= set.duration - 1e-3) A.time = 0;
    A.playing = true;
    let last = performance.now();
    const step = now => {
      if (!A.playing) return;
      const dt = (now - last) / 1000;
      last = now;
      let tt = A.time + dt;
      if (tt > set.duration) { if (set.loop) tt %= set.duration || 1; else { tt = set.duration; A.playing = false; } }
      A.applyAt(tt, true);
      if (A.playing) A.raf = requestAnimationFrame(step); else A.render();
    };
    A.raf = requestAnimationFrame(step);
    A.render();
  };
  A.pause = () => { A.playing = false; cancelAnimationFrame(A.raf); A.render(); O.emit('change-soft'); };
  A.stop = () => { A.pause(); A.applyAt(0); };
  document.addEventListener('pointerdown', e => { if (A.playing && e.target.closest && e.target.closest('#canvas') && !e.target.closest('#timeline')) A.pause(); }, true);

  // ---------- timeline UI ----------
  const fmtTime = s => { const m = Math.floor(s / 60), sec = s - m * 60; return String(m).padStart(2, '0') + ':' + sec.toFixed(2).padStart(5, '0'); };
  let tl = null;
  const LEFT = 180;
  const pps = () => {
    const tr = tl && tl.querySelector('.tl-track');
    const w = tr && tr.clientWidth ? tr.clientWidth : (tl && tl.clientWidth ? tl.clientWidth - LEFT : 600);
    return Math.max(20, (w - 16) / A.settings().duration);
  };
  const ensureTL = () => {
    if (!tl) { tl = O.h('<div id="timeline" role="region"></div>'); bindTimeline(); }
    return tl;
  };
  // the timeline is an editor of the workspace (an area under the canvas); on phones it floats over the canvas
  if (O.layout) O.layout.register('timeline', { label: 'Таймлайн', icon: 'play', el: ensureTL, onShow: () => { A.open = true; A.render(); O.requestRender(); }, onHide: () => { A.open = false; if (A.playing) A.pause(); O.requestRender(); } });
  A.toggle = force => {
    const want = force === undefined ? !A.open : force;
    const L = O.layout;
    if (L && L.active && !L.mobile) { if (want) L.show('timeline', { dir: 'v', size: 230 }); else L.hide('timeline'); return; }
    A.open = want;
    const el = ensureTL(), cv = O.$('#canvas');
    if (A.open && el.parentElement !== cv) cv.appendChild(el);
    el.hidden = !A.open;
    if (!A.open && A.playing) A.pause();
    A.render();
    O.requestRender();
  };
  A.drawPlayhead = () => {
    if (!tl || tl.hidden) return;
    const x = A.time * pps() + 8;
    const ph = tl.querySelector('.tl-ph');
    if (ph) ph.style.left = x + 'px';
    const tm = tl.querySelector('.tl-time');
    if (tm) tm.textContent = fmtTime(A.time);
  };
  // layer span (After Effects in/out points): n.span = [in, out] in seconds; outside it the layer is hidden
  // while the timeline is open or playing. Without a span the layer lasts the whole animation.
  A.spanOf = n => { const d = A.settings().duration; const s = n.span; return s ? [O.clamp(s[0], 0, d), O.clamp(Math.max(s[0], s[1]), 0, d)] : [0, d]; };
  A.hiddenNow = n => !!(n.span && (A.open || A.playing) && (A.time < n.span[0] - 1e-6 || A.time > n.span[1] + 1e-6));
  // every layer of the page is a row (collapsible tree, like the layers panel)
  // on a big page containers start collapsed (animated or selected layers stay visible); the caret toggles them
  A.collapsed = new Set();
  A.expanded = new Set();
  let bigPage = false;
  const hasHot = n => { let hot = false; model.walk(n.children || [], x => { if (hot) return false; if ((x.anim && x.anim.length) || S.sel.includes(x.id)) hot = true; }); return hot; };
  A.isOpen = n => (A.collapsed.has(n.id) ? false : A.expanded.has(n.id) ? true : !bigPage || hasHot(n));
  const TL_ICON = { frame: 'frame', group: 'group', text: 'text', rect: 'rect', ellipse: 'ellipse', path: 'path', polygon: 'polygon', star: 'star', bool: 'union', instance: 'instance', raster: 'image' };
  const tlRows = () => {
    const out = [];
    const walk = (list, d) => {
      for (let i = list.length - 1; i >= 0; i--) {
        const n = list[i];
        const kids = n.children && n.type !== 'bool' && n.type !== 'instance' ? n.children : null;
        out.push({ n, d, kids: !!(kids && kids.length) });
        if (kids && kids.length && A.isOpen(n) && d < 12) walk(kids, d + 1);
      }
    };
    let cnt = 0;
    model.walk(model.page().children, () => { cnt++; });
    bigPage = cnt > 150;
    walk(model.page().children, 0);
    return out;
  };
  A.render = () => {
    ensureTL();
    // the timeline area can be shown by a saved workspace before the document is loaded
    if (!A.open || !S.doc) return;
    tl.setAttribute('aria-label', t('Таймлайн'));
    const set = A.settings();
    const sel = new Set(O.sel().map(n => n.id));
    const tree = tlRows();
    const rows = tree.map(r => r.n);
    const k = A.selKey && model.get(A.selKey.id) && model.get(A.selKey.id).anim ? model.get(A.selKey.id).anim[A.selKey.i] : null;
    const P = pps();
    const ticks = [];
    const step = set.duration > 12 ? 2 : set.duration > 5 ? 1 : 0.5;
    for (let s = 0; s <= set.duration + 1e-6; s += step) ticks.push(`<span class="tl-tick" style="left:${s * P + 8}px">${Number.isInteger(s) ? s + 's' : ''}</span>`);
    tl.innerHTML = `<div class="tl-head">
        <button type="button" class="ib" data-tl="start" title="${esc(t('На початок'))}" aria-label="${esc(t('На початок'))}">${O.icon('rot90', 16)}</button>
        <button type="button" class="ib tl-play" data-tl="play" title="${esc(t(A.playing ? 'Пауза' : 'Відтворити'))} (Alt+Space)" aria-label="${esc(t(A.playing ? 'Пауза' : 'Відтворити'))}">${A.playing ? '<span class="tl-pause"></span>' : O.icon('play', 16)}</button>
        <span class="tl-time">${fmtTime(A.time)}</span>
        <label class="tl-f">${esc(t('Тривалість'))}<input type="number" data-tl="dur" min="0.1" max="600" step="0.1" value="${set.duration}"><em>s</em></label>
        <label class="tl-f">FPS<select data-tl="fps">${[12, 24, 25, 30, 50, 60].map(f => `<option${f === set.fps ? ' selected' : ''}>${f}</option>`).join('')}</select></label>
        <label class="chk"><input type="checkbox" data-tl="loop"${set.loop ? ' checked' : ''}><span>${esc(t('Повтор'))}</span></label>
        <button type="button" class="btn tl-rec${A.autoKey ? ' on' : ''}" data-tl="rec" title="${esc(t('Зміни об’єктів у позиції курсора часу записуються як ключові кадри'))}"><span class="dot"></span>${esc(t('Запис ключів'))}</button>
        <button type="button" class="btn" data-tl="key">◆ ${esc(t('Ключ'))}</button>
        ${k ? `<select data-tl="ease" aria-label="${esc(t('Плавність'))}">${A.EASE_NAMES.map(([v, l]) => `<option value="${v}"${(k.e || 'inout') === v ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select><button type="button" class="ib" data-tl="delkey" title="${esc(t('Видалити ключовий кадр'))}" aria-label="${esc(t('Видалити ключовий кадр'))}">${O.icon('trash', 15)}</button>` : ''}
        <button type="button" class="btn" data-tl="presets">${esc(t('Пресети'))} ▾</button>
        <span class="sp"></span>
        <button type="button" class="btn" data-tl="preview">${esc(t('Переглянути Lottie'))}</button>
        <button type="button" class="btn primary" data-tl="export">${esc(t('Експорт Lottie'))}</button>
        <button type="button" class="ib" data-tl="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 15)}</button>
      </div>
      <div class="tl-body">
        <div class="tl-names">${tree.map(({ n, d, kids }) => `<div class="tl-name${sel.has(n.id) ? ' is-sel' : ''}${n.visible === false ? ' hid' : ''}${n.anim && n.anim.length ? ' anim' : ''}" data-tn="${n.id}" style="--d:${d}" title="${esc(n.name)}"><button type="button" class="tl-car${kids ? '' : ' none'}" data-tc="${n.id}" tabindex="-1" aria-label="${esc(t(kids && !A.isOpen(n) ? 'Розгорнути' : 'Згорнути'))}">${kids ? O.icon(A.isOpen(n) ? 'chevdown' : 'chevright', 11) : ''}</button><span class="tl-ic">${O.icon(TL_ICON[n.type] || 'rect', 13)}</span><span class="tl-nm">${esc(n.name)}</span>${n.anim && n.anim.length ? `<span class="tl-kc">◆${n.anim.length}</span>` : ''}</div>`).join('') || `<div class="tl-empty">${esc(t('На сторінці ще немає шарів. Намалюйте щось і натисніть «Ключ» або оберіть пресет'))}</div>`}</div>
        <div class="tl-track"><div class="tl-ruler">${ticks.join('')}</div>
          ${tree.map(({ n, d }) => { const sp = A.spanOf(n); return `<div class="tl-row${sel.has(n.id) ? ' is-sel' : ''}${n.visible === false ? ' hid' : ''}" data-tr="${n.id}"><span class="tl-clip t-${n.type}${d ? ' sub' : ''}${n.span ? ' cut' : ''}" data-clip="${n.id}" style="left:${sp[0] * P + 8}px;width:${Math.max(4, (sp[1] - sp[0]) * P)}px" title="${esc(n.name)} · ${fmtTime(sp[0])} – ${fmtTime(sp[1])}"><i class="tl-h l" data-edge="l"></i><b>${esc(n.name)}</b><i class="tl-h r" data-edge="r"></i></span>${(n.anim || []).length > 1 ? `<span class="tl-bar" style="left:${n.anim[0].t * P + 8}px;width:${(n.anim[n.anim.length - 1].t - n.anim[0].t) * P}px"></span>` : ''}${(n.anim || []).map((kk, i) => `<button type="button" class="tl-key${A.selKey && A.selKey.id === n.id && A.selKey.i === i ? ' on' : ''}${kk.e === 'hold' ? ' hold' : ''}" data-k="${n.id}:${i}" style="left:${kk.t * P + 8}px" title="${fmtTime(kk.t)}" aria-label="${esc(t('Ключовий кадр'))} ${fmtTime(kk.t)}"></button>`).join('')}</div>`; }).join('')}
          <div class="tl-ph" style="left:${A.time * P + 8}px"></div>
        </div>
      </div>`;
  };
  const bindTimeline = () => {
    tl.addEventListener('click', e => {
      const b = e.target.closest('[data-tl]');
      if (b && b.tagName === 'BUTTON') {
        const a = b.dataset.tl;
        if (a === 'play') A.play();
        if (a === 'start') A.stop();
        if (a === 'rec') { A.autoKey = !A.autoKey; A.render(); }
        if (a === 'key') A.addKeys();
        if (a === 'delkey') A.deleteKey();
        if (a === 'close') A.toggle(false);
        if (a === 'export') A.exportDialog();
        if (a === 'preview') A.preview();
        if (a === 'presets') { const r = b.getBoundingClientRect(); ui.menu(PRESETS.map(p => ({ id: 'preset:' + p[0], label: p[1] })), r.left, r.top - 8, { onPick: id => A.applyPreset(id.slice(7)) }); const m = O.$$('.menu').pop(); if (m) m.style.top = Math.max(4, r.top - m.getBoundingClientRect().height - 6) + 'px'; }
        return;
      }
      const car = e.target.closest('[data-tc]');
      if (car) { const id = car.dataset.tc, n = model.get(id); if (!n) return; if (A.isOpen(n)) { A.collapsed.add(id); A.expanded.delete(id); } else { A.expanded.add(id); A.collapsed.delete(id); } A.render(); return; }
      const nm = e.target.closest('[data-tn]');
      if (nm) {
        const id = nm.dataset.tn;
        if (e.shiftKey || e.ctrlKey || e.metaKey) O.select(S.sel.includes(id) ? S.sel.filter(x => x !== id) : S.sel.concat([id]));
        else O.select([id]);
      }
    });
    tl.addEventListener('dblclick', e => {
      // double-click a layer bar: reset it to the whole animation
      const c = e.target.closest('[data-clip]');
      if (!c) return;
      const n = model.get(c.dataset.clip);
      if (n && n.span) { delete n.span; O.history.commit('Тривалість шару'); A.render(); A.applyAt(A.time); }
    });
    tl.addEventListener('change', e => {
      const a = e.target.dataset.tl, set = A.settings();
      if (a === 'dur') { set.duration = O.clamp(parseFloat(e.target.value) || 1, 0.1, 600); O.history.commit('Тривалість анімації'); A.render(); }
      if (a === 'fps') { set.fps = +e.target.value; O.history.commit('Частота кадрів'); }
      if (a === 'loop') { set.loop = e.target.checked; O.history.commit('Повтор анімації'); }
      if (a === 'ease' && A.selKey) { const n = model.get(A.selKey.id); if (n && n.anim && n.anim[A.selKey.i]) { n.anim[A.selKey.i].e = e.target.value; O.history.commit('Плавність'); A.applyAt(A.time); A.render(); } }
    });
    tl.addEventListener('keydown', e => e.stopPropagation());
    tl.addEventListener('pointerdown', e => {
      const key = e.target.closest('[data-k]');
      const track = e.target.closest('.tl-track');
      if (!track) return;
      const rect = track.getBoundingClientRect();
      const toTime = cx => O.clamp((cx - rect.left - 8 + track.scrollLeft) / pps(), 0, A.settings().duration);
      const fps = A.settings().fps;
      const snapT = v => Math.round(v * fps) / fps;
      if (key) {
        e.preventDefault();
        const [id, si] = key.dataset.k.split(':');
        A.selKey = { id, i: +si };
        const n = model.get(id);
        if (n) O.select([id]);
        let moved = false;
        const mv = ev => {
          if (!n || !n.anim) return;
          moved = true;
          n.anim[A.selKey.i].t = snapT(toTime(ev.clientX));
          key.style.left = n.anim[A.selKey.i].t * pps() + 8 + 'px';
        };
        const up = () => {
          window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
          if (n && n.anim) {
            const kk = n.anim[A.selKey.i];
            if (moved) { n.anim.sort((a, b) => a.t - b.t); A.selKey.i = n.anim.indexOf(kk); O.history.commit('Переміщення ключового кадру'); }
            A.applyAt(kk.t);
          }
          A.render();
        };
        window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
        return;
      }
      // layer bar: drag the middle to move the layer in time (its keyframes move along), drag an edge to trim it
      const clip = e.target.closest('[data-clip]');
      if (clip) {
        e.preventDefault();
        const n = model.get(clip.dataset.clip);
        if (!n) return;
        const edge = e.target.dataset.edge || null;
        if (!S.sel.includes(n.id)) O.select([n.id]);
        const dur = A.settings().duration, t0 = toTime(e.clientX);
        const sp0 = A.spanOf(n), keys0 = (n.anim || []).map(k => k.t);
        let moved = false;
        const mv = ev => {
          const dt = snapT(toTime(ev.clientX) - t0);
          if (!dt && !moved) return;
          moved = true;
          if (edge === 'l') n.span = [O.clamp(sp0[0] + dt, 0, sp0[1] - 1 / fps), sp0[1]];
          else if (edge === 'r') n.span = [sp0[0], O.clamp(sp0[1] + dt, sp0[0] + 1 / fps, dur)];
          else {
            const d = O.clamp(dt, -sp0[0], dur - sp0[1]);
            n.span = [sp0[0] + d, sp0[1] + d];
            (n.anim || []).forEach((k, i) => { k.t = O.clamp(keys0[i] + d, 0, dur); });
          }
          const P = pps();
          clip.style.left = n.span[0] * P + 8 + 'px';
          clip.style.width = Math.max(4, (n.span[1] - n.span[0]) * P) + 'px';
        };
        const up = () => {
          window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
          if (moved) {
            if (n.span && n.span[0] <= 1e-6 && n.span[1] >= dur - 1e-6) delete n.span;
            O.history.commit('Тривалість шару');
            A.applyAt(A.time);
          }
          A.render();
        };
        window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
        return;
      }
      e.preventDefault();
      if (A.playing) A.pause();
      A.selKey = null;
      A.applyAt(snapT(toTime(e.clientX)));
      const mv = ev => A.applyAt(snapT(toTime(ev.clientX)));
      const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); A.render(); };
      window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    });
  };
  O.on('selection', () => { if (A.open && !A.playing) A.render(); });
  // new, renamed or deleted layers show up in the timeline
  O.on('change', O.debounce(() => { if (A.open && !A.playing && !(tl && tl.contains(document.activeElement) && document.activeElement.matches('input,select'))) A.render(); }, 150));
  O.on('page', () => { if (A.open) A.render(); });
  O.on('docload', () => { A.time = 0; A.selKey = null; if (A.open) A.render(); });
  O.on('lang', () => { if (A.open) A.render(); });
  window.addEventListener('resize', () => { if (A.open) A.render(); });

  // ---------- Lottie export ----------
  const BM = { normal: 0, multiply: 1, screen: 2, overlay: 3, darken: 4, lighten: 5, 'color-dodge': 6, 'color-burn': 7, 'hard-light': 8, 'soft-light': 9, difference: 10, exclusion: 11, hue: 12, saturation: 13, color: 14, luminosity: 15 };
  const rgb = (hex, a) => { const c = O.color.parse(hex) || { r: 0, g: 0, b: 0 }; const out = [c.r / 255, c.g / 255, c.b / 255]; if (a !== undefined) out.push(a); return out.map(v => Math.round(v * 10000) / 10000); };
  const r4 = v => Math.round(v * 1000) / 1000;
  A.lottie = (root, opts = {}) => {
    const set = A.settings();
    const fps = set.fps, OP = Math.max(1, Math.round(set.duration * fps));
    const fr = sec => r4(sec * fps);
    const easeIO = e => { const c = EASE[e] || EASE.inout; return { o: { x: [c[0]], y: [c[1]] }, i: { x: [c[2]], y: [c[3]] } }; };
    const arr = v => (Array.isArray(v) ? v.map(x => (typeof x === 'number' ? r4(x) : x)) : [r4(v)]);
    // static or keyframed property; P maps parent space -> composition space
    const prop = (keys, get, now) => {
      if (!keys || keys.length < 2) return { a: 0, k: Array.isArray(now) ? now.map(r4) : r4(now) };
      const vals = keys.map(k => get(k.s));
      if (vals.every(v => JSON.stringify(v) === JSON.stringify(vals[0]))) return { a: 0, k: Array.isArray(vals[0]) ? vals[0].map(r4) : r4(vals[0]) };
      return { a: 1, k: keys.map((k, i) => { const kf = { t: fr(k.t), s: arr(vals[i]) }; if (i < keys.length - 1) Object.assign(kf, k.e === 'hold' ? { h: 1 } : easeIO(k.e || 'inout')); return kf; }) };
    };
    const ks = (n, keys, P, anchorShift) => {
      const now = A.snap(n);
      const sh = anchorShift || [0, 0];
      const pos = s => { const p = M.apply(P, { x: s.p[0], y: s.p[1] }); return [p.x, p.y, 0]; };
      const prot = O.deg(M.decompose(P).rot);
      return {
        a: prop(keys, s => [s.a[0] - sh[0], s.a[1] - sh[1], 0], [now.a[0] - sh[0], now.a[1] - sh[1], 0]),
        p: prop(keys, pos, pos(now)),
        s: prop(keys, s => [s.sx * 100, s.sy * 100, 100], [now.sx * 100, now.sy * 100, 100]),
        r: prop(keys, s => s.rot + prot, now.rot + prot),
        o: prop(keys, s => s.op * 100, now.op * 100),
        sk: prop(keys, s => -(s.sk || 0), -(now.sk || 0)),
        sa: { a: 0, k: 0 }
      };
    };
    const shPath = sp => ({ c: !!sp.closed, v: sp.pts.map(p => [r4(p.x), r4(p.y)]), i: sp.pts.map(p => (p.i ? [r4(p.i.x - p.x), r4(p.i.y - p.y)] : [0, 0])), o: sp.pts.map(p => (p.o ? [r4(p.o.x - p.x), r4(p.o.y - p.y)] : [0, 0])) });
    const subsOf = n => (n.type === 'bool' ? model.boolResult(n) : (G.shapeSubs(n) || []));
    const trIdentity = () => ({ ty: 'tr', p: { a: 0, k: [0, 0] }, a: { a: 0, k: [0, 0] }, s: { a: 0, k: [100, 100] }, r: { a: 0, k: 0 }, o: { a: 0, k: 100 }, sk: { a: 0, k: 0 }, sa: { a: 0, k: 0 } });
    let skipped = 0;
    const leafItems = (n, keys) => {
      const items = [];
      const sizeAnim = keys && keys.length > 1 && n.w !== undefined && keys.some(k => k.s.w !== keys[0].s.w || k.s.h !== keys[0].s.h);
      if (sizeAnim) {
        const saved = { w: n.w, h: n.h };
        const per = keys.map(k => { n.w = k.s.w; n.h = k.s.h; return subsOf(n).map(shPath); });
        n.w = saved.w; n.h = saved.h;
        per[0].forEach((_, si) => items.push({ ty: 'sh', ks: { a: 1, k: keys.map((k, i) => { const kf = { t: fr(k.t), s: [per[i][si]] }; if (i < keys.length - 1) Object.assign(kf, k.e === 'hold' ? { h: 1 } : easeIO(k.e)); return kf; }) } }));
      } else subsOf(n).forEach(sp => items.push({ ty: 'sh', ks: { a: 0, k: shPath(sp) } }));
      const trimmed = (keys && keys.some(k => (k.s.ts || 0) > 1e-4 || (k.s.te === undefined ? 1 : k.s.te) < 0.9999)) || n.trimS !== undefined;
      if (trimmed) items.push({ ty: 'tm', s: prop(keys, s => (s.ts || 0) * 100, (n.trimS || 0) * 100), e: prop(keys, s => (s.te === undefined ? 1 : s.te) * 100, (n.trimE === undefined ? 1 : n.trimE) * 100), o: { a: 0, k: 0 }, m: 1 });
      const strokes = (n.strokes || []).map((p, i) => ({ p, i })).filter(x => x.p.visible !== false && n.sw > 0).reverse();
      for (const { p, i } of strokes) items.push({ ty: 'st', c: prop(keys, s => rgb((s.strokes && s.strokes[i]) || O.paintColor(p), 1), rgb(O.paintColor(p), 1)), o: { a: 0, k: (p.opacity === undefined ? 1 : p.opacity) * 100 }, w: prop(keys, s => s.sw, n.sw), lc: { round: 2, square: 3 }[n.cap] || 1, lj: { round: 2, bevel: 3 }[n.join] || 1, ml: n.miter || 4 });
      const fills = (n.fills || []).map((p, i) => ({ p, i })).filter(x => x.p.visible !== false).reverse();
      for (const { p, i } of fills) {
        const op = (p.opacity === undefined ? 1 : p.opacity) * 100;
        if (p.type === 'linear' || p.type === 'radial') {
          const b = model.localBounds(n);
          const pt = q => [r4(b.x + q.x * b.w), r4(b.y + q.y * b.h)];
          const stops = p.stops.slice().sort((a, c) => a.o - c.o);
          const k = [];
          stops.forEach(s => k.push(r4(s.o), ...rgb(s.color)));
          stops.forEach(s => k.push(r4(s.o), r4(s.a === undefined ? 1 : s.a)));
          items.push({ ty: 'gf', o: { a: 0, k: op }, r: 1, s: { a: 0, k: pt(p.from) }, e: { a: 0, k: pt(p.to) }, t: p.type === 'linear' ? 1 : 2, g: { p: stops.length, k: { a: 0, k } }, h: { a: 0, k: 0 }, a: { a: 0, k: 0 } });
        } else items.push({ ty: 'fl', c: prop(keys, s => rgb((s.fills && s.fills[i]) || O.paintColor(p), 1), rgb(O.paintColor(p), 1)), o: { a: 0, k: op }, r: n.fillRule === 'evenodd' ? 2 : 1 });
      }
      items.push(trIdentity());
      return items;
    };
    const groupOf = (n) => {
      if (n.visible === false) return null;
      const keys = n.anim && n.anim.length > 1 ? n.anim : null;
      let it;
      if (n.type === 'text' || n.type === 'raster') { skipped++; return null; }
      if (n.type === 'instance') {
        const comp = model.get(n.ref);
        if (!comp) return null;
        const inner = comp.children.slice().reverse().map(groupOf).filter(Boolean);
        const sx = comp.w ? n.w / comp.w : 1, sy = comp.h ? n.h / comp.h : 1;
        it = [{ ty: 'gr', nm: comp.name, it: inner.concat([Object.assign(trIdentity(), { s: { a: 0, k: [r4(sx * 100), r4(sy * 100)] } })]) }];
      } else if (n.children && n.type !== 'bool') {
        it = n.children.slice().reverse().map(groupOf).filter(Boolean);
        if (n.type === 'frame' && (n.fills || []).some(f => f.visible !== false)) it.push({ ty: 'gr', nm: n.name, it: leafItems(Object.assign({}, n, { type: 'rect' }), null) });
      } else it = leafItems(n, keys);
      const tr = ks(n, keys, M.id());
      return { ty: 'gr', nm: n.name, it: it.concat([Object.assign({ ty: 'tr' }, tr)]) };
    };
    // composition = root frame (or selection bounds); P maps each top node's parent space to comp space
    const isFrame = root.frame;
    const nodes = root.nodes;
    const origin = root.origin;
    const assets = [], fonts = [];
    const layers = [];
    let ind = 1;
    const imageLayer = async n => {
      const flat = Object.assign({}, n, { m: M.id(), opacity: 1, anim: null });
      const { canvas } = await O.io.renderImage([flat], { scale: 2, type: 'image/png' });
      const id = 'img_' + assets.length;
      assets.push({ id, w: r4(n.w), h: r4(n.h), u: '', p: canvas.toDataURL('image/png'), e: 1 });
      return id;
    };
    const pending = [];
    for (const n of nodes.slice().reverse()) {
      if (n.visible === false) continue;
      const keys = n.anim && n.anim.length > 1 ? n.anim : null;
      const P = M.mul(origin, model.parentMatrix(n));
      const sp = n.span ? A.spanOf(n) : null;
      const base = { ddd: 0, ind: ind++, nm: n.name, sr: 1, ao: 0, ip: sp ? fr(sp[0]) : 0, op: sp ? Math.max(fr(sp[0]) + 1, fr(sp[1])) : OP, st: 0, bm: BM[n.blend] || 0 };
      if (n.type === 'text' && !n.path) {
        const Lt = O.text.layout(n);
        const xAlign = n.align === 'center' ? Lt.w / 2 : n.align === 'right' ? Lt.w : 0;
        const base0 = Lt.lines[0] ? Lt.lines[0].y : n.size * 0.8;
        const fName = String(n.font || 'Arial').replace(/\s+/g, '') + '-' + (n.weight >= 600 ? 'Bold' : 'Regular') + (n.italic ? 'Italic' : '');
        if (!fonts.some(f => f.fName === fName)) fonts.push({ fName, fFamily: n.font || 'Arial', fStyle: (n.weight >= 600 ? 'Bold' : 'Regular') + (n.italic ? ' Italic' : ''), ascent: 75 });
        const fill = (n.fills || []).find(f => f.visible !== false);
        layers.push(Object.assign(base, {
          ty: 5, ks: ks(n, keys, P, [xAlign, base0]),
          t: { d: { k: [{ s: { s: n.size, f: fName, t: O.text.content(n).replace(/\n/g, '\r'), j: { right: 1, center: 2, justify: 3 }[n.align] || 0, tr: r4((n.ls || 0) / n.size * 1000), lh: r4(O.text.lineHeight(n)), ls: 0, fc: rgb(fill ? O.paintColor(fill) : '#000000') }, t: 0 }] }, p: {}, m: { g: 1, a: { a: 0, k: [0, 0] } }, a: [] }
        }));
        continue;
      }
      if (n.type === 'raster' || (n.type === 'rect' && (n.fills || []).some(f => f.type === 'image' && f.visible !== false))) {
        const layer = Object.assign(base, { ty: 2, ks: ks(n, keys, P), refId: null });
        pending.push(imageLayer(n).then(id => { layer.refId = id; }));
        layers.push(layer);
        continue;
      }
      let shapes;
      if (n.children && n.type !== 'bool') shapes = n.children.slice().reverse().map(groupOf).filter(Boolean);
      else if (n.type === 'instance') shapes = (groupOf(Object.assign({}, n, { anim: null, m: M.id() })) || { it: [] }).it.slice(0, -1);
      else shapes = leafItems(n, keys);
      if (n.type === 'frame' && n.children && (n.fills || []).some(f => f.visible !== false)) shapes.push({ ty: 'gr', nm: n.name, it: leafItems(Object.assign({}, n, { type: 'rect' }), null) });
      layers.push(Object.assign(base, { ty: 4, ks: ks(n, keys, P), shapes }));
    }
    if (opts.bg && isFrame) {
      const f = isFrame;
      const fill = (f.fills || []).find(p => p.visible !== false);
      if (fill) layers.push({ ddd: 0, ind: ind++, ty: 4, nm: t('Тло'), sr: 1, ao: 0, ip: 0, op: OP, st: 0, bm: 0, ks: { a: { a: 0, k: [0, 0, 0] }, p: { a: 0, k: [0, 0, 0] }, s: { a: 0, k: [100, 100, 100] }, r: { a: 0, k: 0 }, o: { a: 0, k: 100 } }, shapes: leafItems(Object.assign({}, f, { type: 'rect', m: M.id(), strokes: [], effects: [] }), null) });
    }
    return Promise.all(pending).then(() => ({
      json: { v: '5.7.4', fr: fps, ip: 0, op: OP, w: Math.round(root.w), h: Math.round(root.h), nm: root.name, ddd: 0, assets, fonts: { list: fonts }, layers, markers: [] },
      skipped
    }));
  };
  A.rootForExport = () => {
    const sel = O.topSel();
    const frame = sel.length === 1 && sel[0].type === 'frame' ? sel[0] : (sel.length ? null : model.page().children.find(n => n.type === 'frame' && n.visible !== false));
    if (frame) return { frame, nodes: frame.children, origin: M.inv(model.worldMatrix(frame)), w: frame.w, h: frame.h, name: frame.name };
    const nodes = sel.length ? sel : model.page().children.filter(n => n.visible !== false);
    const b = model.selBounds(nodes);
    if (!b) return null;
    return { frame: null, nodes, origin: M.translate(-b.x, -b.y), w: b.w, h: b.h, name: S.doc.name };
  };
  A.exportDialog = () => {
    const root = A.rootForExport();
    if (!root) return O.toast('Немає що експортувати');
    ui.dialog({
      title: 'Експорт Lottie',
      body: `<div class="dlg-text">${esc(t('Lottie JSON для вебсайтів і застосунків (lottie-web, Android, iOS). Розмір: {w}×{h}, {d} с, {fps} кадр/с.', { w: Math.round(root.w), h: Math.round(root.h), d: A.settings().duration, fps: A.settings().fps }))}</div>`,
      fields: [{ key: 'bg', label: 'Додати тло фрейму (інакше прозоре)', type: 'checkbox', value: false }],
      buttons: [{ id: 'preview', label: 'Переглянути' }, { id: 'ok', label: 'Завантажити .json', primary: true }],
      onOk: async (v, btn) => {
        const { json, skipped } = await A.lottie(root, { bg: v.bg });
        if (btn === 'preview') return A.preview(json);
        O.download(new Blob([JSON.stringify(json)], { type: 'application/json' }), String(root.name || 'animation').replace(/[\\/:*?"<>|]+/g, '_') + '.json');
        O.toast(skipped ? 'Lottie експортовано. Пропущено вкладених текстів/зображень: {n}' : 'Lottie експортовано', { n: skipped });
      }
    });
  };
  A.preview = async json => {
    try {
      if (!json) { const root = A.rootForExport(); if (!root) return O.toast('Немає що експортувати'); json = (await A.lottie(root, {})).json; }
      await O.loadScript('vendor/lottie_svg.min.js');
      const d = ui.dialog({ title: 'Перегляд Lottie', body: `<div class="lottie-stage"><div class="lottie-box"></div></div><div class="dlg-text">${esc(t('Шахове тло показує прозорість. Так анімація виглядатиме на сайті або в застосунку.'))}</div>`, buttons: [{ id: 'ok', label: 'Закрити', primary: true }] });
      d.el.querySelector('.dlg').classList.add('wide');
      const box = d.el.querySelector('.lottie-box');
      box.style.aspectRatio = json.w + ' / ' + json.h;
      const anim = window.lottie.loadAnimation({ container: box, renderer: 'svg', loop: true, autoplay: true, animationData: JSON.parse(JSON.stringify(json)) });
      const obs = new MutationObserver(() => { if (!document.body.contains(d.el)) { anim.destroy(); obs.disconnect(); } });
      obs.observe(document.body, { childList: true });
    } catch (e) { console.warn(e); O.toast('Помилка: {msg}', { msg: e.message }); }
  };

  // ---------- commands & menu ----------
  O.cmd('timeline', 'Таймлайн', () => A.toggle(), { keys: ['Alt+T'], group: 'Анімація', check: () => A.open });
  O.cmd('animPlay', 'Відтворити / пауза', () => { if (!A.open) A.toggle(true); A.play(); }, { keys: ['Alt+Space'], group: 'Анімація' });
  O.cmd('animKey', 'Додати ключовий кадр', () => { if (!A.open) A.toggle(true); A.addKeys(); }, { keys: ['Alt+K'], group: 'Анімація' });
  O.cmd('animDelKey', 'Видалити ключовий кадр', () => A.deleteKey(), { group: 'Анімація', enabled: () => !!A.selKey });
  O.cmd('animClear', 'Прибрати анімацію з виділеного', () => A.clearAnim(), { group: 'Анімація', enabled: () => O.topSel().some(n => n.anim) });
  O.cmd('animExport', 'Експорт Lottie (JSON)…', () => A.exportDialog(), { keys: ['Ctrl+Alt+L'], group: 'Анімація' });
  O.cmd('animPreview', 'Переглянути Lottie', () => A.preview(), { group: 'Анімація' });
  PRESETS.forEach(p => O.cmd('preset:' + p[0], p[1], () => A.applyPreset(p[0]), { group: 'Анімація' }));
  const viewIdx = O.MENUS.findIndex(m => m[0] === 'Вигляд');
  O.MENUS.splice(viewIdx, 0, ['Анімація', ['timeline', 'animPlay', '-', 'animKey', 'animDelKey', 'animClear', '-', { label: 'Пресети', items: PRESETS.map(p => 'preset:' + p[0]) }, '-', 'animPreview', 'animExport']]);
  // template: animation project
  if (O.projects) O.projects.templates.push({ id: 'lottie', name: 'Анімація Lottie', icon: 'play', size: '512×512', make: () => O.projects.framesDoc(t('Анімація Lottie'), [[t('Анімація'), 512, 512]], { bg: '#FFFFFF' }) });
})();
