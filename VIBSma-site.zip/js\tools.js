'use strict';
/* VIBSma — tools (selection, transform, drawing, painting, text, transform tools) */
(function () {
  const O = window.O, M = O.M, G = O.G, R = O.R, P = O.P, model = O.model, S = O.state, V = O.view;
  const T = O.tools = {};
  const n_ = O.n;
  const ACC = O.COLORS.ACC;

  O.toolOpts = Object.assign({
    pencilSmooth: 2.5, pencilWidth: 2, pencilColor: '#1E1E1E',
    brushType: 'calligraphic', brushSize: 10, brushColor: '#1E1E1E', brushAngle: 30, brushRound: 0.25,
    blobSize: 24, blobColor: '#0D99FF', eraserSize: 24,
    polySides: 3, starPoints: 5, starInner: 0.382,
    spiralSegs: 10, spiralDecay: 0.8, gridRows: 5, gridCols: 5, polarRings: 5, polarRays: 8,
    blendSteps: 5
  }, O.ls.get('toolOpts', {}));
  O.saveToolOpts = () => O.ls.set('toolOpts', O.toolOpts);

  O.setTool = id => {
    if (!T[id]) return;
    const prev = T[S.tool];
    if (S.tool !== id && prev && prev.deactivate) prev.deactivate();
    S.tool = id;
    if (T[id].activate) T[id].activate();
    if (V.el) V.el.style.cursor = T[id].cursor || 'default';
    O.emit('tool', id);
    O.requestOverlay();
  };

  // ---------- helpers ----------
  const restoreNode = (n, data) => { for (const k of Object.keys(n)) delete n[k]; Object.assign(n, O.clone(data)); };
  const snapshot = nodes => nodes.map(n => ({ n, data: O.clone(n) }));
  const restoreAll = snap => { for (const s of snap) restoreNode(s.n, s.data); model.reindex(); };
  O.snapshotNodes = snapshot; O.restoreNodes = restoreAll;
  const topSel = () => {
    const nodes = O.sel().filter(n => !n.locked);
    return nodes.filter(n => !nodes.some(o => o !== n && model.isAncestor(o, n)));
  };
  const descIds = nodes => {
    const out = [];
    for (const n of nodes) { out.push(n.id); if (n.children) model.walk(n.children, c => { out.push(c.id); }); }
    return out;
  };
  const editable = n => n && ['path', 'rect', 'ellipse', 'polygon', 'star'].includes(n.type) && !n.locked;
  O.isEditablePath = editable;
  const label = (x, y, text) => {
    const w = text.length * 6.4 + 10;
    return `<g pointer-events="none"><rect x="${n_(x)}" y="${n_(y)}" width="${n_(w)}" height="17" rx="3" fill="#1E1E1E"/><text x="${n_(x + w / 2)}" y="${n_(y + 12.5)}" fill="#fff" font-size="11" text-anchor="middle" font-family="system-ui,sans-serif">${O.esc(text)}</text></g>`;
  };
  O.ovLabel = label;
  const polyline = (pts, Vm, color) => pts.length < 2 ? '' :
    `<polyline points="${pts.map(p => { const q = M.apply(Vm, p); return n_(q.x) + ',' + n_(q.y); }).join(' ')}" fill="none" stroke="${color || ACC}" stroke-width="1.5" pointer-events="none"/>`;
  const containerLocal = (cont, p) => M.apply(M.inv(model.containerMatrix(cont)), p);

  // measurement overlay (Alt)
  O.measureOverlay = (a, b) => {
    const C = O.COLORS.SMART;
    let s = '';
    const line = (x1, y1, x2, y2, v) => {
      const p = V.toScreen({ x: x1, y: y1 }), q = V.toScreen({ x: x2, y: y2 });
      s += `<line x1="${n_(p.x)}" y1="${n_(p.y)}" x2="${n_(q.x)}" y2="${n_(q.y)}" stroke="${C}" stroke-width="1" pointer-events="none"/>`;
      const t = O.fmt(v), w = t.length * 6.4 + 8;
      s += `<g pointer-events="none"><rect x="${n_((p.x + q.x) / 2 - w / 2)}" y="${n_((p.y + q.y) / 2 - 8)}" width="${n_(w)}" height="16" rx="3" fill="${C}"/><text x="${n_((p.x + q.x) / 2)}" y="${n_((p.y + q.y) / 2 + 4)}" fill="#fff" font-size="10.5" text-anchor="middle" font-family="system-ui,sans-serif">${t}</text></g>`;
    };
    const cy = a.y + a.h / 2, cx = a.x + a.w / 2;
    if (R.containsRect(b, a)) {
      line(b.x, cy, a.x, cy, a.x - b.x); line(a.x + a.w, cy, b.x + b.w, cy, b.x + b.w - a.x - a.w);
      line(cx, b.y, cx, a.y, a.y - b.y); line(cx, a.y + a.h, cx, b.y + b.h, b.y + b.h - a.y - a.h);
    } else {
      if (b.x > a.x + a.w) line(a.x + a.w, cy, b.x, cy, b.x - a.x - a.w);
      else if (b.x + b.w < a.x) line(b.x + b.w, cy, a.x, cy, a.x - b.x - b.w);
      if (b.y > a.y + a.h) line(cx, a.y + a.h, cx, b.y, b.y - a.y - a.h);
      else if (b.y + b.h < a.y) line(cx, b.y + b.h, cx, a.y, a.y - b.y - b.h);
    }
    const bs = V.toScreen(b), be = V.toScreen({ x: b.x + b.w, y: b.y + b.h });
    s = `<rect x="${n_(bs.x)}" y="${n_(bs.y)}" width="${n_(be.x - bs.x)}" height="${n_(be.y - bs.y)}" fill="none" stroke="${C}" stroke-width="1" stroke-dasharray="3 2" pointer-events="none"/>` + s;
    return s;
  };

  // ======================================================================
  // SELECT (V) — also Free Transform (E): edges shear
  // ======================================================================
  const select = T.select = {
    cursor: 'default', drag: null,
    down(ev) {
      const h = ev.h;
      if (S.edit) { S.edit = null; O.requestOverlay(); }
      if (h && O.HANDLES[h]) return this.startResize(ev, h);
      if (h && h.startsWith('rot-')) return this.startRotate(ev);
      if (h && h.startsWith('frame:')) {
        const f = model.get(h.slice(6));
        if (f) {
          if (ev.shift) O.select([f.id], true); else if (!S.sel.includes(f.id)) O.select([f.id]);
          return this.startMove(ev, f.id);
        }
      }
      const leafId = V.hitLeaf(ev.clientX, ev.clientY);
      const target = leafId ? V.pick(leafId, ev.ctrl) : null;
      if (target && V.isTopFrame(target) && leafId === target.id && target.children.length && !S.sel.includes(target.id)) {
        return this.startMarquee(ev, target.children);
      }
      if (target) {
        if (ev.shift) {
          if (S.sel.includes(target.id)) { O.select(S.sel.filter(i => i !== target.id)); this.drag = null; return; }
          O.select([target.id], true);
        } else if (!S.sel.includes(target.id)) O.select([target.id]);
        return this.startMove(ev, target.id);
      }
      S.enteredGroup = null;
      this.startMarquee(ev, null);
    },
    startMove(ev, clickedId) {
      const nodes = topSel();
      this.drag = { kind: 'move', p0: ev.p, s0: ev.s, moved: false, alt: ev.alt, clickedId, nodes, origM: nodes.map(n => n.m.slice()), box0: model.selBounds(nodes) };
    },
    startResize(ev, h) {
      const box = O.selBox();
      if (!box) return;
      const nodes = topSel();
      const edge = h.length === 1;
      const shear = edge && ((S.tool === 'free') !== !!ev.ctrl);
      this.drag = { kind: 'resize', h, box, nodes, snap: snapshot(nodes), p0: ev.p, shear };
      O.snap.prepare(descIds(nodes));
    },
    startRotate(ev) {
      const box = O.selBox();
      if (!box) return;
      const nodes = topSel();
      const c = M.apply(box.W, R.center(box.lb));
      this.drag = { kind: 'rotate', c, a0: P.angle(c, ev.p), nodes, snap: snapshot(nodes), r0: box.single ? M.decompose(box.W).rot : 0 };
    },
    startMarquee(ev, scope) {
      this.drag = { kind: 'marquee', p0: ev.p, scope: scope || model.page().children, base: ev.shift ? S.sel.slice() : [] };
      if (!ev.shift) O.select([]);
    },
    move(ev) {
      const d = this.drag;
      if (!d) return;
      if (d.kind === 'move') {
        if (!d.moved) {
          if (P.dist(d.s0, ev.s) < 3) return;
          d.moved = true;
          if (d.alt) {
            const copies = O.ops.duplicate(d.nodes, { inPlace: true });
            O.select(copies.map(c => c.id));
            d.nodes = copies; d.origM = copies.map(n => n.m.slice());
          }
          O.snap.prepare(descIds(d.nodes));
        }
        let dx = ev.p.x - d.p0.x, dy = ev.p.y - d.p0.y;
        if (ev.shift) { if (Math.abs(dx) > Math.abs(dy)) dy = 0; else dx = 0; }
        // auto-layout reorder (single node)
        if (d.nodes.length === 1) {
          const n = d.nodes[0], par = model.parent(n);
          if (par && par.layout && !model.isPage(par)) {
            const lp = M.apply(M.inv(model.worldMatrix(par)), ev.p);
            const horiz = par.layout.dir !== 'v';
            const sibs = par.children.filter(c => c !== n);
            let idx = 0;
            for (const c of sibs) { const b = model.boundsIn(c, c.m); if ((horiz ? b.x + b.w / 2 : b.y + b.h / 2) < (horiz ? lp.x : lp.y)) idx++; }
            const cur = par.children.indexOf(n);
            if (cur !== idx) { par.children.splice(cur, 1); par.children.splice(idx, 0, n); model.reindex(); O.requestRender(); }
            return;
          }
        }
        if (d.box0) {
          const sn = O.snap.rect({ x: d.box0.x + dx, y: d.box0.y + dy, w: d.box0.w, h: d.box0.h }, { noX: ev.shift && dx === 0, noY: ev.shift && dy === 0 });
          dx += sn.dx; dy += sn.dy;
        }
        d.delta = { x: dx, y: dy };
        const Tw = M.translate(dx, dy);
        d.nodes.forEach((n, i) => {
          const Pm = model.parentMatrix(n);
          n.m = M.mul(M.mul(M.inv(Pm), M.mul(Tw, Pm)), d.origM[i]);
        });
        O.requestRender();
      } else if (d.kind === 'resize') {
        restoreAll(d.snap);
        const { lb, W, single } = d.box;
        const rotated = Math.abs(M.decompose(W).rot) > 1e-6 || Math.abs(M.decompose(W).skew) > 1e-6;
        let p = ev.p;
        if (!rotated && !d.shear) p = O.snap.point(p); else O.snap.clear();
        const lp = M.apply(M.inv(W), p);
        const [fx, fy] = O.HANDLES[d.h];
        const hp = { x: lb.x + lb.w * fx, y: lb.y + lb.h * fy };
        const anchor = ev.alt ? R.center(lb) : { x: lb.x + lb.w * (1 - fx), y: lb.y + lb.h * (1 - fy) };
        let L;
        if (d.shear) {
          if (d.h === 'n' || d.h === 's') { const k = (lp.x - hp.x) / ((hp.y - anchor.y) || 1e-9); L = M.about([1, 0, k, 1, 0, 0], anchor); }
          else { const k = (lp.y - hp.y) / ((hp.x - anchor.x) || 1e-9); L = M.about([1, k, 0, 1, 0, 0], anchor); }
        } else {
          let sx = fx === 0.5 ? 1 : (Math.abs(hp.x - anchor.x) > 1e-9 ? (lp.x - anchor.x) / (hp.x - anchor.x) : 1);
          let sy = fy === 0.5 ? 1 : (Math.abs(hp.y - anchor.y) > 1e-9 ? (lp.y - anchor.y) / (hp.y - anchor.y) : 1);
          const lock = ev.shift || (single && single.lockRatio);
          if (lock) {
            if (fx === 0.5) sx = Math.abs(sy);
            else if (fy === 0.5) sy = Math.abs(sx);
            else { const s = Math.max(Math.abs(sx), Math.abs(sy)); sx = s * (sx < 0 ? -1 : 1); sy = s * (sy < 0 ? -1 : 1); }
          }
          if (Math.abs(sx) < 1e-4) sx = sx < 0 ? -1e-4 : 1e-4;
          if (Math.abs(sy) < 1e-4) sy = sy < 0 ? -1e-4 : 1e-4;
          L = M.about(M.scale(sx, sy), anchor);
        }
        if (single) model.applyLocal(single, L, 'resize');
        else d.nodes.forEach(n => model.applyWorld(n, L, 'resize'));
        O.requestRender();
      } else if (d.kind === 'rotate') {
        restoreAll(d.snap);
        let da = P.angle(d.c, ev.p) - d.a0;
        if (ev.shift) { const step = Math.PI / 12; da = Math.round((d.r0 + da) / step) * step - d.r0; }
        const Gm = M.about(M.rotate(da), d.c);
        d.nodes.forEach(n => model.applyWorld(n, Gm, 'resize'));
        let deg = -O.deg(d.r0 + da); deg = ((deg % 360) + 540) % 360 - 180;
        d.label = { s: ev.s, t: O.fmt(deg, 1) + '°' };
        O.requestRender();
      } else if (d.kind === 'marquee') {
        S.marquee = R.norm(d.p0, ev.p);
        const found = V.nodesInRect(S.marquee, d.scope).map(n => n.id);
        O.select(Array.from(new Set(d.base.concat(found))));
        O.requestOverlay();
      }
    },
    up(ev) {
      const d = this.drag;
      this.drag = null;
      O.snap.clear();
      if (!d) return;
      if (d.kind === 'move') {
        if (d.moved) {
          // drop into frames (Figma-like)
          const ids = new Set(descIds(d.nodes));
          for (const n of d.nodes) {
            const par = model.parent(n);
            if (!par || (!model.isPage(par) && par.type !== 'frame')) continue;
            if (par.layout) continue;
            const b = model.worldBounds(n);
            const target = V.containerAt(R.center(b), ids);
            if (target !== par) model.reparent(n, target);
          }
          if (d.delta) {
            const afterDup = !!(O.lastDupIds && O.lastDupIds.join() === S.sel.join());
            O.lastTransform = { G: M.translate(d.delta.x, d.delta.y), copy: d.alt, afterDup, mode: 'resize', ids: S.sel.slice() };
          }
          O.history.commit(d.alt ? 'Дублювання' : 'Переміщення');
        } else if (!ev.shift && d.clickedId && S.sel.length > 1) O.select([d.clickedId]);
      } else if (d.kind === 'resize' || d.kind === 'rotate') {
        O.history.commit(d.kind === 'rotate' ? 'Поворот' : (d.shear ? 'Нахил' : 'Зміна розміру'));
      } else if (d.kind === 'marquee') {
        S.marquee = null;
      }
      O.requestRender();
    },
    dblclick(ev) {
      const leafId = V.hitLeaf(ev.clientX, ev.clientY);
      if (!leafId) return;
      const target = V.pick(leafId, false);
      if (!target) return;
      if (target.type === 'text' && !target.locked) { O.select([target.id]); return O.textEdit.start(target); }
      if (target.type === 'bool') {
        // operands are not rendered separately: find the topmost operand under the pointer
        const pp = G.paper();
        const pt = new pp.Point(ev.p.x, ev.p.y);
        const hit = target.children.slice().reverse().find(c => c.visible !== false && G.toPaper(model.subsIn(c, model.worldMatrix(c)), c.fillRule).contains(pt));
        S.enteredGroup = target.id;
        if (hit) O.select([hit.id]);
        return;
      }
      if (model.isContainer(target)) {
        S.enteredGroup = target.id;
        const child = V.pick(leafId, false);
        if (child && child !== target) O.select([child.id]);
        return;
      }
      if (editable(target)) {
        O.select([target.id]);
        S.edit = { id: target.id, sel: new Set() };
        O.setTool('direct');
      }
    },
    hover(ev) {
      const leafId = V.hitLeaf(ev.clientX, ev.clientY);
      const t = leafId ? V.pick(leafId, ev.ctrl) : null;
      const id = t ? t.id : null;
      let measure = null;
      if (ev.alt && S.sel.length) {
        const sb = model.selBounds(O.sel());
        let other = t && !S.sel.includes(t.id) ? model.worldBounds(t) : null;
        if (!other) { const par = model.parent(O.sel()[0]); if (par && !model.isPage(par)) other = model.worldBounds(par); }
        if (sb && other) measure = O.measureOverlay(sb, other);
      }
      if (S.hover !== id || measure !== S.measure) { S.hover = id; S.measure = measure; O.requestOverlay(); }
    },
    overlay() {
      const d = this.drag;
      if (d && d.kind === 'rotate' && d.label) return label(d.label.s.x + 14, d.label.s.y + 10, d.label.t);
      return '';
    }
  };
  T.free = Object.assign(Object.create(select), { cursor: 'default' });

  // ======================================================================
  // DIRECT SELECTION (A) — anchor / handle editing
  // ======================================================================
  const allKeys = n => { const s = new Set(); (n.type === 'path' ? n.subpaths : G.shapeSubs(n) || []).forEach((sp, si) => sp.pts.forEach((p, k) => s.add(si + ':' + k))); return s; };
  const parseKey = k => k.split(':').map(Number);
  T.direct = {
    cursor: 'default', drag: null,
    activate() {
      if (!S.edit) { const n = O.sel()[0]; if (editable(n)) S.edit = { id: n.id, sel: new Set() }; }
    },
    deactivate() { S.edit = null; this.drag = null; },
    segmentAt(n, ev) {
      const subs = n.type === 'path' ? n.subpaths : G.shapeSubs(n);
      const W = model.worldMatrix(n);
      const lp = M.apply(M.inv(W), ev.p);
      const near = G.nearest(subs, lp);
      if (!near) return null;
      const sp = M.apply(M.mul(V.m(), W), near);
      return P.dist(sp, ev.s) < 5 ? near : null;
    },
    down(ev) {
      const h = ev.h;
      const n = S.edit && model.get(S.edit.id);
      if (n && h && (h.startsWith('a:') || h.startsWith('hi:') || h.startsWith('ho:'))) {
        if (h.startsWith('a:')) {
          const key = h.slice(2);
          if (ev.shift) { if (S.edit.sel.has(key)) S.edit.sel.delete(key); else S.edit.sel.add(key); }
          else if (!S.edit.sel.has(key)) S.edit.sel = new Set([key]);
          O.requestOverlay();
          return this.startDrag(ev, n, 'anchors', key);
        }
        const [hk, si, k] = h.split(':');
        return this.startDrag(ev, n, 'handle', si + ':' + k, hk === 'hi' ? 'i' : 'o');
      }
      if (n) {
        const seg = this.segmentAt(n, ev);
        if (seg) {
          const N = (n.type === 'path' ? n.subpaths : G.shapeSubs(n))[seg.si].pts.length;
          const keys = [seg.si + ':' + seg.k, seg.si + ':' + ((seg.k + 1) % N)];
          if (!ev.shift) S.edit.sel = new Set(keys); else keys.forEach(k => S.edit.sel.add(k));
          O.requestOverlay();
          return this.startDrag(ev, n, 'anchors', keys[0]);
        }
      }
      const leafId = V.hitLeaf(ev.clientX, ev.clientY);
      const leaf = leafId ? model.get(leafId) : null;
      if (leaf && editable(leaf)) {
        if (!S.edit || S.edit.id !== leaf.id) { O.select([leaf.id]); S.edit = { id: leaf.id, sel: new Set() }; }
        S.edit.sel = allKeys(leaf);
        O.requestOverlay();
        return this.startDrag(ev, leaf, 'anchors', null);
      }
      if (leaf && !leaf.locked) {
        S.edit = null;
        O.select([leaf.id]);
        select.startMove(ev, leaf.id);
        this.drag = { kind: 'fwd' };
        return;
      }
      this.drag = { kind: 'amarq', p0: ev.p, s0: ev.s, base: ev.shift && S.edit ? new Set(S.edit.sel) : new Set() };
    },
    startDrag(ev, n, kind, key, which) {
      this.drag = { kind, n, key, which, p0: ev.p, s0: ev.s, moved: false };
      O.snap.prepare([n.id]);
    },
    move(ev) {
      const d = this.drag;
      if (!d) return;
      if (d.kind === 'fwd') return select.move(ev);
      if (d.kind === 'amarq') {
        S.marquee = R.norm(d.p0, ev.p);
        const n = S.edit && model.get(S.edit.id);
        if (n) {
          const W = model.worldMatrix(n);
          const set = new Set(d.base);
          const subs = n.type === 'path' ? n.subpaths : G.shapeSubs(n);
          subs.forEach((sp, si) => sp.pts.forEach((p, k) => { if (R.contains(S.marquee, M.apply(W, p))) set.add(si + ':' + k); }));
          S.edit.sel = set;
        }
        O.requestOverlay();
        return;
      }
      if (!d.moved) {
        if (P.dist(d.s0, ev.s) < 3) return;
        d.moved = true;
        if (d.n.type !== 'path') model.toPath(d.n);
        d.orig = O.clone(d.n.subpaths);
        d.W = model.worldMatrix(d.n);
      }
      const n = d.n, W = d.W, iW = M.inv(W);
      n.subpaths = O.clone(d.orig);
      if (d.kind === 'anchors') {
        let dw = P.sub(ev.p, d.p0);
        if (ev.shift) { if (Math.abs(dw.x) > Math.abs(dw.y)) dw.y = 0; else dw.x = 0; }
        if (d.key) {
          const [si, k] = parseKey(d.key);
          const a0 = M.apply(W, d.orig[si].pts[k]);
          const t = O.snap.point(P.add(a0, dw));
          dw = P.sub(t, a0);
        }
        const dl = M.applyV(iW, dw);
        for (const key of S.edit.sel) {
          const [si, k] = parseKey(key);
          const p = n.subpaths[si] && n.subpaths[si].pts[k];
          if (!p) continue;
          p.x += dl.x; p.y += dl.y;
          if (p.i) { p.i.x += dl.x; p.i.y += dl.y; }
          if (p.o) { p.o.x += dl.x; p.o.y += dl.y; }
        }
      } else if (d.kind === 'handle') {
        const [si, k] = parseKey(d.key);
        const p = n.subpaths[si].pts[k], op = d.orig[si].pts[k];
        const lp = M.apply(iW, ev.p);
        p[d.which] = { x: lp.x, y: lp.y };
        const other = d.which === 'i' ? 'o' : 'i';
        if (ev.alt) p.t = 'corner';
        else if ((p.t === 'smooth' || p.t === 'sym') && op[other]) {
          const v = P.sub(lp, p);
          const len = p.t === 'sym' ? P.len(v) : P.dist(op[other], op);
          const dir = P.norm(v);
          p[other] = { x: p.x - dir.x * len, y: p.y - dir.y * len };
        }
      }
      O.requestRender();
    },
    up(ev) {
      const d = this.drag;
      this.drag = null;
      O.snap.clear();
      if (!d) return;
      if (d.kind === 'fwd') return select.up(ev);
      if (d.kind === 'amarq') {
        const clicked = !S.marquee || S.marquee.w * V.zoom < 3;
        S.marquee = null;
        if (clicked && !ev.shift) {
          if (S.edit && S.edit.sel.size) S.edit.sel = new Set();
          else { S.edit = null; O.select([]); }
        }
        O.requestOverlay();
        return;
      }
      if (d.moved) O.history.commit(d.kind === 'handle' ? 'Маркер' : 'Вузли');
    },
    dblclick(ev) {
      const h = ev.h;
      const n = S.edit && model.get(S.edit.id);
      if (n && h && h.startsWith('a:')) {
        if (n.type !== 'path') model.toPath(n);
        const [si, k] = parseKey(h.slice(2));
        O.ops.toggleSmooth(n, si, k);
        O.history.commit('Тип вузла');
        return;
      }
      const leafId = V.hitLeaf(ev.clientX, ev.clientY);
      const leaf = leafId && model.get(leafId);
      if (leaf && leaf.type === 'text') { O.select([leaf.id]); O.textEdit.start(leaf); }
    },
    hover(ev) {
      const leafId = V.hitLeaf(ev.clientX, ev.clientY);
      const id = leafId || null;
      if (S.hover !== id) { S.hover = id; O.requestOverlay(); }
    },
    key(e) {
      if (e.key === 'Escape' || e.key === 'Enter') {
        const id = S.edit && S.edit.id;
        S.edit = null;
        O.setTool('select');
        if (id) O.select([id]);
        return true;
      }
    }
  };

  // ======================================================================
  // PEN (P) — with auto add/delete and continue path
  // ======================================================================
  T.pen = {
    cursor: 'crosshair', st: null,
    activate() { this.st = null; O.snap.prepare([]); },
    deactivate() { this.finish(); },
    node() { return this.st && model.get(this.st.id); },
    lastWorld() {
      const n = this.node();
      if (!n) return null;
      const sp = n.subpaths[this.st.si];
      return M.apply(model.worldMatrix(n), sp.pts[sp.pts.length - 1]);
    },
    pt(ev) {
      const last = this.lastWorld();
      if (last && ev.shift) return P.snap45(last, ev.p);
      return O.snap.point(ev.p);
    },
    down(ev) {
      let n = this.node();
      const p = this.pt(ev);
      if (n) {
        const W = model.worldMatrix(n);
        const sp = n.subpaths[this.st.si];
        const fs = M.apply(M.mul(V.m(), W), sp.pts[0]);
        if (sp.pts.length > 1 && P.dist(fs, ev.s) < 8) {
          sp.closed = true;
          this.st.drag = { k: 0, p0: ev.p, s0: ev.s, closing: true };
          O.requestRender();
          return;
        }
        const lp = M.apply(M.inv(W), p);
        sp.pts.push(G.pt(lp.x, lp.y));
        this.st.drag = { k: sp.pts.length - 1, p0: ev.p, s0: ev.s };
        S.edit = { id: n.id, sel: new Set([this.st.si + ':' + (sp.pts.length - 1)]) };
        O.requestRender();
        return;
      }
      const sn = O.sel()[0];
      if (sn && sn.type === 'path' && !sn.locked) {
        const W = model.worldMatrix(sn), SM = M.mul(V.m(), W);
        for (let si = 0; si < sn.subpaths.length; si++) {
          const sp = sn.subpaths[si];
          if (sp.closed || !sp.pts.length) continue;
          for (const end of [sp.pts.length - 1, 0]) {
            if (P.dist(M.apply(SM, sp.pts[end]), ev.s) < 7) {
              if (end === 0 && sp.pts.length > 1) sn.subpaths[si] = G.reverseSub(sp);
              const s2 = sn.subpaths[si];
              this.st = { id: sn.id, si, drag: { k: s2.pts.length - 1, p0: ev.p, s0: ev.s, cont: true } };
              S.edit = { id: sn.id, sel: new Set([si + ':' + (s2.pts.length - 1)]) };
              O.requestRender();
              return;
            }
          }
        }
        for (let si = 0; si < sn.subpaths.length; si++) {
          const sp = sn.subpaths[si];
          for (let k = 0; k < sp.pts.length; k++) {
            if (P.dist(M.apply(SM, sp.pts[k]), ev.s) < 6) {
              sp.pts.splice(k, 1);
              if (sp.pts.length < 2) sn.subpaths.splice(si, 1);
              if (!sn.subpaths.length) { model.remove(sn); O.select([]); }
              O.history.commit('Видалення вузла');
              return;
            }
          }
        }
        const lp = M.apply(M.inv(W), ev.p);
        const near = G.nearest(sn.subpaths, lp);
        if (near && P.dist(M.apply(SM, near), ev.s) < 6) {
          G.insertAt(sn.subpaths[near.si], near.k, near.t);
          S.edit = { id: sn.id, sel: new Set([near.si + ':' + (near.k + 1)]) };
          O.history.commit('Додавання вузла');
          return;
        }
      }
      const cont = V.containerAt(p);
      const lp = containerLocal(cont, p);
      n = model.create('path', { subpaths: [{ closed: false, pts: [G.pt(lp.x, lp.y)] }] });
      model.insert(n, cont);
      this.st = { id: n.id, si: 0, drag: { k: 0, p0: ev.p, s0: ev.s } };
      O.select([n.id]);
      S.edit = { id: n.id, sel: new Set(['0:0']) };
      O.requestRender();
    },
    move(ev) {
      if (!this.st || !this.st.drag) return;
      const n = this.node();
      if (!n) return;
      const d = this.st.drag;
      if (!d.dragging && P.dist(d.s0, ev.s) < 3) return;
      d.dragging = true;
      const W = model.worldMatrix(n);
      const lp = M.apply(M.inv(W), ev.p);
      const pt = n.subpaths[this.st.si].pts[d.k];
      pt.o = { x: lp.x, y: lp.y };
      if (ev.alt || d.cont) pt.t = 'corner';
      else { pt.i = { x: 2 * pt.x - lp.x, y: 2 * pt.y - lp.y }; pt.t = 'sym'; }
      O.requestRender();
    },
    up() {
      if (!this.st) return;
      const d = this.st.drag;
      this.st.drag = null;
      if (d && d.closing) { this.finish(); return; }
      O.snap.prepare([]);
      O.requestOverlay();
    },
    hover(ev) {
      if (this.st) { this.st.hover = this.pt(ev); O.requestOverlay(); }
      else { S.hover = null; }
    },
    dblclick() { this.finish(); },
    finish() {
      const n = this.node();
      this.st = null;
      S.edit = null;
      if (n) {
        n.subpaths = n.subpaths.filter(sp => sp.pts.length > 1);
        if (!n.subpaths.length) { model.remove(n); O.select([]); }
        O.history.commit('Перо');
      }
      O.requestRender();
    },
    key(e) {
      if (e.key === 'Enter' || e.key === 'Escape') {
        if (this.st) { this.finish(); return true; }
        if (e.key === 'Escape') { O.setTool('select'); return true; }
      }
    },
    overlay(Vm) {
      const n = this.node();
      if (!n || !this.st.hover || this.st.drag) return '';
      const W = model.worldMatrix(n), SM = M.mul(Vm, W);
      const sp = n.subpaths[this.st.si];
      const last = sp.pts[sp.pts.length - 1];
      const a = M.apply(SM, last), b = V.toScreen(this.st.hover);
      const c1 = last.o ? M.apply(SM, last.o) : a;
      let s = `<path d="M${n_(a.x)} ${n_(a.y)}C${n_(c1.x)} ${n_(c1.y)} ${n_(b.x)} ${n_(b.y)} ${n_(b.x)} ${n_(b.y)}" fill="none" stroke="${ACC}" stroke-width="1" stroke-dasharray="4 3" pointer-events="none"/>`;
      const fs = M.apply(SM, sp.pts[0]);
      if (sp.pts.length > 1 && P.dist(fs, b) < 8) s += `<circle cx="${n_(fs.x)}" cy="${n_(fs.y)}" r="7" fill="none" stroke="${ACC}" stroke-width="1.5" pointer-events="none"/>`;
      return s;
    }
  };

  // ======================================================================
  // PENCIL / BRUSH / BLOB / ERASER / KNIFE
  // ======================================================================
  const smoothPts = (pts, win) => pts.map((p, i) => {
    let x = 0, y = 0, c = 0;
    for (let j = Math.max(0, i - win); j <= Math.min(pts.length - 1, i + win); j++) { x += pts[j].x; y += pts[j].y; c++; }
    return { x: x / c, y: y / c };
  });
  const freehand = (onUp, color) => ({
    cursor: 'crosshair', pts: null,
    down(ev) { this.pts = [ev.p]; },
    move(ev) {
      if (!this.pts) return;
      const last = this.pts[this.pts.length - 1];
      if (P.dist(last, ev.p) * V.zoom > 1.5) { this.pts.push(ev.p); O.requestOverlay(); }
    },
    up(ev) { const pts = this.pts; this.pts = null; if (pts && pts.length > 1) onUp(pts, ev); O.requestOverlay(); },
    overlay(Vm) { return this.pts ? polyline(this.pts, Vm, typeof color === 'function' ? color() : color) : ''; }
  });
  const toCl = poly => poly.map(p => ({ X: Math.round(p.x * 100), Y: Math.round(p.y * 100) }));
  const fromCl = path => path.map(p => ({ x: p.X / 100, y: p.Y / 100 }));
  const cleanPoly = poly => {
    const CL = window.ClipperLib;
    const res = CL.Clipper.SimplifyPolygon(toCl(poly), CL.PolyFillType.pftNonZero);
    return res.map(fromCl).filter(p => p.length > 2);
  };
  O.variableOutline = (pts, widthAt) => {
    const n = pts.length, L = [], Rr = [];
    for (let i = 0; i < n; i++) {
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
      const dir = P.norm(P.sub(b, a));
      const nrm = { x: -dir.y, y: dir.x };
      const w = Math.max(0.05, widthAt(i, dir) / 2);
      L.push(P.add(pts[i], P.mul(nrm, w)));
      Rr.push(P.sub(pts[i], P.mul(nrm, w)));
    }
    const polys = cleanPoly(L.concat(Rr.reverse()));
    return G.simplify(G.polysToSubs(polys, 0.05), 0.35);
  };

  T.pencil = freehand((pts) => {
    const closed = pts.length > 8 && P.dist(pts[0], pts[pts.length - 1]) * V.zoom < 10;
    const cont = V.containerAt(pts[0]);
    const lpts = pts.map(p => containerLocal(cont, p));
    if (closed) lpts.pop();
    const subs = G.simplify([G.polyToSub(lpts, closed)], O.toolOpts.pencilSmooth / V.zoom);
    const n = model.create('path', { subpaths: subs, strokes: [O.paint.solid(O.toolOpts.pencilColor)], sw: O.toolOpts.pencilWidth, cap: 'round', join: 'round' });
    model.insert(n, cont);
    O.select([n.id]);
    O.history.commit('Олівець');
  }, ACC);

  T.brush = freehand((pts) => {
    const o = O.toolOpts;
    const cont = V.containerAt(pts[0]);
    let lpts = smoothPts(pts.map(p => containerLocal(cont, p)), 2);
    let n;
    if (o.brushType === 'round') {
      const subs = G.simplify([G.polyToSub(lpts, false)], 2 / V.zoom);
      n = model.create('path', { subpaths: subs, strokes: [O.paint.solid(o.brushColor)], sw: o.brushSize, cap: 'round', join: 'round', name: model.autoName('path') });
    } else {
      let widthAt;
      if (o.brushType === 'calligraphic') {
        const th = O.rad(o.brushAngle), r = O.clamp(o.brushRound, 0.02, 1);
        widthAt = (i, dir) => { const a = Math.atan2(dir.y, dir.x) - th; return o.brushSize * Math.sqrt(Math.sin(a) ** 2 + r * r * Math.cos(a) ** 2); };
      } else {
        const cum = [0];
        for (let i = 1; i < lpts.length; i++) cum.push(cum[i - 1] + P.dist(lpts[i - 1], lpts[i]));
        const total = cum[cum.length - 1] || 1;
        widthAt = i => o.brushSize * Math.pow(Math.max(0, Math.sin(Math.PI * cum[i] / total)), 0.7);
      }
      const subs = O.variableOutline(lpts, widthAt);
      if (!subs.length) return;
      n = model.create('path', { subpaths: subs, fills: [O.paint.solid(o.brushColor)], strokes: [] });
    }
    model.insert(n, cont);
    O.select([n.id]);
    O.history.commit('Пензель');
  }, () => O.toolOpts.brushColor);

  T.blob = freehand((pts) => {
    const o = O.toolOpts;
    const cont = V.containerAt(pts[0]);
    const lpts = pts.map(p => containerLocal(cont, p));
    const polys = G.clipperOffset([], [lpts], o.blobSize / 2, { join: 'round', cap: 'round' });
    let subs = G.polysToSubs(polys, 0.05);
    if (!subs.length) return;
    const color = O.color.norm(o.blobColor);
    const cands = O.sel().filter(c => c.type === 'path' && model.parent(c) === cont && !c.locked && c.fills.length === 1 && c.fills[0].type === 'solid' && c.fills[0].color === color && !c.strokes.filter(s => s.visible !== false).length);
    let acc = G.toPaper(subs);
    const merged = [];
    for (const c of cands) {
      const it = G.toPaper(model.subsIn(c, c.m));
      if (!acc.bounds.intersects(it.bounds)) continue;
      acc = acc.unite(it);
      merged.push(c);
    }
    subs = G.simplify(G.fromPaper(acc), 0.4);
    let n;
    if (merged.length) {
      n = merged[0];
      n.subpaths = subs; n.m = M.id();
      merged.slice(1).forEach(c => model.remove(c));
    } else {
      n = model.create('path', { subpaths: subs, fills: [O.paint.solid(color)], strokes: [], name: model.autoName('path') });
      model.insert(n, cont);
    }
    O.select([n.id]);
    O.history.commit('Пензель-клякса');
  }, () => O.toolOpts.blobColor);

  T.eraser = freehand((pts) => {
    const size = O.toolOpts.eraserSize / V.zoom;
    const polys = G.clipperOffset([], [pts], size / 2, { join: 'round', cap: 'round' });
    if (!polys.length) return;
    const eb = R.fromPts(polys.flat());
    let targets = O.sel().length ? O.sel() : model.page().children;
    const leaves = [];
    const collect = list => list.forEach(n => {
      if (n.visible === false || n.locked) return;
      if (n.type === 'group' || n.type === 'frame') return collect(n.children);
      if (['path', 'rect', 'ellipse', 'polygon', 'star', 'bool'].includes(n.type)) leaves.push(n);
    });
    collect(targets);
    let changed = 0;
    for (const t of leaves) {
      const wb = model.worldBounds(t);
      if (!wb || !R.intersects(wb, eb)) continue;
      const iPp = M.inv(model.parentMatrix(t));
      const E = G.toPaper(polys.map(p => G.polyToSub(p.map(q => M.apply(iPp, q)), true)));
      const geom = model.subsIn(t, t.m);
      const A = G.toPaper(geom, t.fillRule);
      const open = geom.some(sp => !sp.closed);
      let res;
      try { res = open ? A.subtract(E, { trace: false }) : A.subtract(E); } catch (e) { continue; }
      const subs = G.fromPaper(res);
      O.ops.replaceGeometry(t, subs);
      if (!subs.length) model.remove(t);
      changed++;
    }
    if (changed) { O.select(S.sel.filter(id => model.exists(id))); O.history.commit('Гумка'); }
  }, '#F24822');
  T.eraser.overlay = function (Vm) {
    if (!this.pts) return '';
    const w = O.toolOpts.eraserSize;
    return `<polyline points="${this.pts.map(p => { const q = M.apply(Vm, p); return n_(q.x) + ',' + n_(q.y); }).join(' ')}" fill="none" stroke="rgba(242,72,34,0.35)" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" pointer-events="none"/>`;
  };

  T.knife = freehand((pts) => {
    if (pts.length < 2) return;
    const targets = [];
    const collect = list => list.forEach(n => {
      if (n.visible === false || n.locked) return;
      if (n.type === 'group' || n.type === 'frame') return collect(n.children);
      if (['path', 'rect', 'ellipse', 'polygon', 'star', 'bool'].includes(n.type)) targets.push(n);
    });
    collect(O.sel().length ? O.sel() : model.page().children);
    const kb = R.fromPts(pts);
    let changed = 0;
    for (const t of targets) {
      const wb = model.worldBounds(t);
      if (!wb || !R.intersects(R.expand(wb, 1), kb)) continue;
      const iPp = M.inv(model.parentMatrix(t));
      const lp = pts.map(p => M.apply(iPp, p));
      const geom = model.subsIn(t, t.m);
      if (geom.some(sp => !sp.closed)) continue;
      const pieces = O.ops.cutWithLine(geom, lp, t.fillRule);
      if (!pieces || pieces.length < 2) continue;
      const par = model.parent(t), idx = par.children.indexOf(t);
      const made = pieces.map(sub => {
        const c = model.cloneNode(t);
        O.ops.replaceGeometry(c, sub);
        return c;
      });
      model.remove(t);
      made.forEach((c, i) => model.insert(c, par, idx + i));
      changed++;
    }
    if (changed) { O.select([]); O.history.commit('Ніж'); }
  }, '#F24822');

  // ======================================================================
  // SCISSORS (C)
  // ======================================================================
  T.scissors = {
    cursor: 'crosshair',
    findTarget(ev) {
      const cands = [];
      const sel = O.sel().filter(editable);
      const leafId = V.hitLeaf(ev.clientX, ev.clientY);
      if (leafId && editable(model.get(leafId))) cands.push(model.get(leafId));
      cands.push(...sel);
      let best = null;
      for (const n of cands) {
        const W = model.worldMatrix(n);
        const subs = n.type === 'path' ? n.subpaths : G.shapeSubs(n);
        const near = G.nearest(subs, M.apply(M.inv(W), ev.p));
        if (!near) continue;
        const d = P.dist(M.apply(M.mul(V.m(), W), near), ev.s);
        if (d < 7 && (!best || d < best.d)) best = { n, near, d };
      }
      return best;
    },
    down(ev) {
      const t = this.findTarget(ev);
      if (!t) return;
      const n = t.n;
      if (n.type !== 'path') model.toPath(n);
      const sp = n.subpaths[t.near.si];
      const pieces = G.cutAt(sp, t.near.k, t.near.t);
      if (pieces.length === 1) {
        n.subpaths[t.near.si] = pieces[0];
        O.select([n.id]);
      } else {
        n.subpaths[t.near.si] = pieces[0];
        const c = model.cloneNode(n);
        c.subpaths = [pieces[1]];
        n.subpaths = n.subpaths.filter((_, i) => i === t.near.si).concat(n.subpaths.filter((_, i) => i !== t.near.si));
        const par = model.parent(n);
        model.insert(c, par, par.children.indexOf(n) + 1);
        O.select([n.id, c.id]);
      }
      O.history.commit('Ножиці');
    },
    hover(ev) {
      const t = this.findTarget(ev);
      this.hoverPt = t ? M.apply(model.worldMatrix(t.n), t.near) : null;
      O.requestOverlay();
    },
    overlay() {
      if (!this.hoverPt) return '';
      const s = V.toScreen(this.hoverPt);
      return `<circle cx="${n_(s.x)}" cy="${n_(s.y)}" r="5" fill="#fff" stroke="#F24822" stroke-width="1.5" pointer-events="none"/>`;
    }
  };

  // ======================================================================
  // SHAPES (R, O, L, ...), FRAME (F)
  // ======================================================================
  const K = 0.5522847498;
  O.spiralSubs = (c, r, a0, segs, decay) => {
    const pts = [];
    let rad = r;
    for (let k = 0; k <= segs; k++) {
      const th = a0 + k * Math.PI / 2;
      const p = { x: c.x + Math.cos(th) * rad, y: c.y + Math.sin(th) * rad };
      const t = { x: -Math.sin(th), y: Math.cos(th) };
      const hin = rad * K, hout = rad * decay * K;
      pts.push(G.pt(p.x, p.y, k > 0 ? { x: p.x - t.x * hin, y: p.y - t.y * hin } : null, k < segs ? { x: p.x + t.x * hout, y: p.y + t.y * hout } : null, 'smooth'));
      rad *= decay;
    }
    // fix in-handles: use previous radius for continuity
    return [{ closed: false, pts }];
  };
  const makeShape = (type, box, line, name) => {
    const o = O.toolOpts;
    const nm = { name: name || model.autoName(type) };
    switch (type) {
      case 'rect': case 'ellipse': case 'frame':
        return model.create(type, Object.assign({ w: box.w, h: box.h, m: M.translate(box.x, box.y) }, nm));
      case 'polygon': return model.create('polygon', Object.assign({ w: box.w, h: box.h, m: M.translate(box.x, box.y), sides: o.polySides }, nm));
      case 'star': return model.create('star', Object.assign({ w: box.w, h: box.h, m: M.translate(box.x, box.y), points: o.starPoints, inner: o.starInner }, nm));
      case 'line': case 'arrow':
        return model.create('path', Object.assign({ subpaths: [{ closed: false, pts: [G.pt(line[0].x, line[0].y), G.pt(line[1].x, line[1].y)] }], me: type === 'arrow' ? 'arrow' : 'none' }, nm));
      case 'arc': {
        const [a, b] = line;
        return model.create('path', Object.assign({ subpaths: [{ closed: false, pts: [G.pt(a.x, a.y, null, { x: a.x, y: a.y + (b.y - a.y) * K }), G.pt(b.x, b.y, { x: b.x - (b.x - a.x) * K, y: b.y }, null)] }] }, nm));
      }
      case 'spiral': {
        const [a, b] = line;
        return model.create('path', Object.assign({ subpaths: O.spiralSubs(a, Math.max(1, P.dist(a, b)), P.angle(a, b), o.spiralSegs, o.spiralDecay) }, nm));
      }
      case 'grid': {
        const g = model.create('group', nm);
        const st = { strokes: [O.paint.solid('#1E1E1E')], fills: [] };
        g.children.push(model.create('rect', Object.assign({ name: O.t('Рамка'), w: box.w, h: box.h, m: M.translate(box.x, box.y) }, st)));
        for (let i = 1; i < o.gridRows; i++) { const y = box.y + box.h * i / o.gridRows; g.children.push(model.create('path', Object.assign({ name: O.t('Рядок {n}', { n: i }), subpaths: [{ closed: false, pts: [G.pt(box.x, y), G.pt(box.x + box.w, y)] }] }, st))); }
        for (let i = 1; i < o.gridCols; i++) { const x = box.x + box.w * i / o.gridCols; g.children.push(model.create('path', Object.assign({ name: O.t('Стовпець {n}', { n: i }), subpaths: [{ closed: false, pts: [G.pt(x, box.y), G.pt(x, box.y + box.h)] }] }, st))); }
        return g;
      }
      case 'polar': {
        const g = model.create('group', nm);
        const st = { strokes: [O.paint.solid('#1E1E1E')], fills: [] };
        const c = R.center(box);
        for (let i = 1; i <= o.polarRings; i++) {
          const w = box.w * i / o.polarRings, h = box.h * i / o.polarRings;
          g.children.push(model.create('ellipse', Object.assign({ name: O.t('Кільце {n}', { n: i }), w, h, m: M.translate(c.x - w / 2, c.y - h / 2) }, st)));
        }
        for (let i = 0; i < o.polarRays; i++) {
          const a = i * 2 * Math.PI / o.polarRays;
          g.children.push(model.create('path', Object.assign({ name: O.t('Промінь {n}', { n: i + 1 }), subpaths: [{ closed: false, pts: [G.pt(c.x, c.y), G.pt(c.x + Math.cos(a) * box.w / 2, c.y + Math.sin(a) * box.h / 2)] }] }, st)));
        }
        return g;
      }
    }
  };
  const LINEY = new Set(['line', 'arrow', 'arc', 'spiral']);
  const shapeTool = type => ({
    cursor: 'crosshair', d: null,
    activate() { O.snap.prepare([]); },
    down(ev) {
      O.snap.prepare([]);
      const p = O.snap.point(ev.p);
      this.d = { p0: p, s0: ev.s, node: null, cont: V.containerAt(p) };
    },
    geom(ev) {
      const d = this.d;
      let p1 = O.snap.point(ev.p);
      const a0 = containerLocal(d.cont, d.p0);
      let b = containerLocal(d.cont, p1);
      if (LINEY.has(type)) {
        if (ev.shift) b = P.snap45(a0, b);
        return { line: [a0, b] };
      }
      let a = { ...a0 };
      let dx = b.x - a.x, dy = b.y - a.y;
      if (ev.shift) { const s = Math.max(Math.abs(dx), Math.abs(dy)); dx = s * (dx < 0 ? -1 : 1); dy = s * (dy < 0 ? -1 : 1); }
      if (ev.alt) { a = { x: a.x - dx, y: a.y - dy }; dx *= 2; dy *= 2; }
      return { box: R.norm(a, { x: a.x + dx, y: a.y + dy }) };
    },
    move(ev) {
      const d = this.d;
      if (!d) return;
      if (!d.node && P.dist(d.s0, ev.s) < 3) return;
      const g = this.geom(ev);
      const fresh = makeShape(type, g.box, g.line, d.node ? d.node.name : undefined);
      if (!d.node) {
        d.node = fresh;
        model.insert(fresh, d.cont);
        O.select([fresh.id]);
      } else {
        const keep = { id: d.node.id, name: d.node.name };
        if (fresh.children) fresh.children.forEach(c => { c.id = O.uid(); });
        restoreNode(d.node, Object.assign(fresh, keep));
        model.reindex();
      }
      O.requestRender();
    },
    up(ev) {
      const d = this.d;
      this.d = null;
      O.snap.clear();
      if (!d) return;
      if (!d.node) {
        const a = containerLocal(d.cont, d.p0);
        const n = LINEY.has(type) ? makeShape(type, null, [a, { x: a.x + 100, y: a.y + (type === 'arc' || type === 'spiral' ? 100 : 0) }]) : makeShape(type, { x: a.x, y: a.y, w: 100, h: 100 });
        model.insert(n, d.cont);
        O.select([n.id]);
      }
      O.history.commit('Фігура');
      // tools stay active (Illustrator-style) unless the user prefers returning to selection
      if (S.settings.returnToSelect && !ev.shift) O.setTool('select');
    }
  });
  ['rect', 'ellipse', 'polygon', 'star', 'line', 'arrow', 'frame', 'arc', 'spiral', 'grid', 'polar'].forEach(t => { T[t] = shapeTool(t); });

  // ======================================================================
  // TEXT (T) and TYPE ON PATH
  // ======================================================================
  T.text = {
    cursor: 'text', d: null,
    down(ev) {
      const leafId = V.hitLeaf(ev.clientX, ev.clientY);
      const leaf = leafId && model.get(leafId);
      if (leaf && leaf.type === 'text' && !leaf.locked) { this.d = { edit: leaf }; return; }
      this.d = { p0: O.snap.point(ev.p), s0: ev.s, cont: V.containerAt(ev.p) };
    },
    move(ev) { if (this.d && !this.d.edit) { this.d.p1 = ev.p; O.requestOverlay(); } },
    up() {
      const d = this.d;
      this.d = null;
      if (!d) return;
      if (d.edit) { O.select([d.edit.id]); O.textEdit.start(d.edit, { selectAll: false }); return; }
      const a = containerLocal(d.cont, d.p0);
      let width = null;
      const n = model.create('text', {});
      if (d.p1 && P.dist(V.toScreen(d.p0), V.toScreen(d.p1)) > 6) {
        const b = containerLocal(d.cont, d.p1);
        width = Math.max(10, Math.abs(b.x - a.x));
        a.x = Math.min(a.x, b.x); a.y = Math.min(a.y, b.y);
      } else a.y -= O.text.lineHeight(n) / 2;
      n.width = width;
      n.m = M.translate(a.x, a.y);
      model.insert(n, d.cont);
      O.select([n.id]);
      O.textEdit.start(n, { created: true });
    },
    overlay() {
      const d = this.d;
      if (!d || !d.p1 || d.edit) return '';
      const a = V.toScreen(d.p0), b = V.toScreen(d.p1);
      const r = R.norm(a, b);
      return `<rect x="${n_(r.x)}" y="${n_(r.y)}" width="${n_(r.w)}" height="${n_(r.h)}" fill="none" stroke="${ACC}" stroke-width="1" pointer-events="none"/>`;
    }
  };
  T.textpath = {
    cursor: 'text',
    down(ev) {
      const leafId = V.hitLeaf(ev.clientX, ev.clientY);
      const n = leafId && model.get(leafId);
      if (n && n.type === 'text') { O.select([n.id]); O.textEdit.start(n); return; }
      if (!n || !editable(n)) { O.toast('Клацніть на контур або фігуру, щоб розмістити текст уздовж неї'); return; }
      O.ops.textOnPath(n);
    }
  };

  // text editing (HTML textarea over the canvas)
  O.textEdit = {
    start(n, opts = {}) {
      if (S.textEdit) this.end(true);
      S.textEdit = { id: n.id, created: !!opts.created, rich: false };
      S.textEditActive = true;
      const ta = O.$('#text-editor');
      ta.hidden = false;
      ta.value = n.text;
      this.sync();
      O.requestRender();
      setTimeout(() => {
        ta.focus();
        if (!opts.created && opts.selectAll !== false) ta.select();
        else ta.setSelectionRange(ta.value.length, ta.value.length);
      }, 0);
    },
    sync() {
      if (!S.textEdit) return;
      const n = model.get(S.textEdit.id);
      const ta = O.$('#text-editor');
      if (!n) return;
      // rich text (columns, mixed formatting…): the canvas shows the text, the textarea only takes input (typeui.js draws caret / selection)
      const rich = !!(O.typeset && O.typeset.rich(n));
      if (rich !== S.textEdit.rich) { S.textEdit.rich = rich; O.requestRender(); }
      ta.classList.toggle('rich', rich);
      const SM = M.mul(V.m(), model.worldMatrix(n));
      const fill = (n.fills || []).find(f => f.visible !== false);
      ta.style.font = O.text.css(n);
      ta.style.letterSpacing = (n.ls || 0) + 'px';
      ta.style.lineHeight = O.text.lineHeight(n) + 'px';
      ta.style.textAlign = n.align;
      ta.style.textDecoration = n.deco && n.deco !== 'none' ? n.deco : 'none';
      ta.style.textTransform = { upper: 'uppercase', lower: 'lowercase', title: 'capitalize' }[n.tcase] || 'none';
      ta.style.color = fill && fill.type === 'solid' ? fill.color : (fill ? O.paintColor(fill) : '#000');
      if (n.path) {
        const p0 = M.apply(SM, n.path[0].pts[0]);
        ta.classList.add('floating');
        ta.style.transform = `translate(${p0.x}px, ${p0.y + 10}px)`;
        ta.style.width = '280px';
        ta.style.height = (O.text.lineHeight(n) * 2 + 8) + 'px';
        ta.style.whiteSpace = 'pre-wrap';
      } else {
        ta.classList.remove('floating');
        const L = O.text.layout(n);
        ta.style.transform = M.css(SM);
        ta.style.width = (rich ? L.w : (n.width !== null && n.width !== undefined) ? n.width : L.w + n.size) + 'px';
        ta.style.height = (rich ? (n.boxH || L.h) : L.h) + 'px';
        ta.style.whiteSpace = rich || (n.width !== null && n.width !== undefined) ? 'pre-wrap' : 'pre';
      }
    },
    input(ev) {
      if (!S.textEdit) return;
      const n = model.get(S.textEdit.id);
      if (!n) return;
      const ta = O.$('#text-editor');
      const old = n.text || '';
      // character runs, notes and tracked changes follow the edit (typeset.js)
      const res = O.typeset ? O.typeset.textChanged(n, old, ta.value, { caret: ta.selectionEnd, inputType: ev && ev.inputType }) : null;
      if (res) { n.text = res.text; ta.value = res.text; ta.setSelectionRange(res.caret, res.caret); }
      else n.text = ta.value;
      if (n.nameAuto !== false) n.name = (n.text.trim().split('\n')[0] || O.t('Текст')).slice(0, 40);
      this.sync();
      O.requestRender();
    },
    end(silent) {
      if (!S.textEdit) return;
      const id = S.textEdit.id, n = model.get(id);
      const ta = O.$('#text-editor');
      S.textEdit = null; S.textEditActive = false;
      ta.hidden = true;
      ta.classList.remove('rich');
      if (document.activeElement === ta) ta.blur();
      if (n) {
        if (!n.text.trim()) { model.remove(n); O.select([]); }
        else O.select([n.id]);
      }
      O.history.commit('Текст');
      O.requestRender();
      if (!silent && S.tool === 'text' && S.settings.returnToSelect) O.setTool('select');
    }
  };
  O.on('zoom', () => O.textEdit.sync());

  // ======================================================================
  // HAND (H), ZOOM (Z)
  // ======================================================================
  T.hand = {
    cursor: 'grab', d: null,
    down(ev) { this.d = { s0: ev.s, x: V.x, y: V.y }; V.el.style.cursor = 'grabbing'; },
    move(ev) { if (this.d) { V.x = this.d.x + ev.s.x - this.d.s0.x; V.y = this.d.y + ev.s.y - this.d.s0.y; V.apply(); } },
    up() { this.d = null; V.el.style.cursor = (T[S.tool] || {}).cursor || 'default'; }
  };
  T.zoom = {
    cursor: 'zoom-in', d: null,
    down(ev) { this.d = { p0: ev.p }; },
    move(ev) { if (this.d) { S.marquee = R.norm(this.d.p0, ev.p); O.requestOverlay(); } },
    up(ev) {
      const m = S.marquee;
      this.d = null; S.marquee = null;
      if (m && m.w * V.zoom > 5) V.fit(m, 20, 256); else V.zoomBy(ev.alt ? 0.5 : 2, ev.s);
      O.requestOverlay();
    }
  };

  // ======================================================================
  // EYEDROPPER (I)
  // ======================================================================
  T.eyedropper = {
    cursor: 'crosshair',
    down(ev) {
      const leafId = V.hitLeaf(ev.clientX, ev.clientY);
      const src = leafId && model.get(leafId);
      if (!src) return;
      const targets = O.sel().filter(n => n.id !== src.id && !n.locked);
      if (!targets.length) {
        const c = O.paintColor((src.fills || []).find(f => f.visible !== false) || (src.strokes || [])[0]);
        O.copyText(c);
        O.toast('Колір {c} скопійовано. Виділіть об’єкти, щоб переносити на них оформлення.', { c });
        return;
      }
      const keys = ['fills', 'strokes', 'sw', 'sa', 'dash', 'cap', 'join', 'miter', 'effects', 'opacity', 'blend'];
      const tkeys = ['font', 'size', 'weight', 'italic', 'lh', 'ls', 'deco', 'tcase'];
      for (const t of targets) {
        for (const k of keys) if (src[k] !== undefined) t[k] = O.clone(src[k]);
        if (src.type === 'text' && t.type === 'text') for (const k of tkeys) t[k] = O.clone(src[k]);
      }
      O.history.commit('Піпетка');
    },
    hover(ev) { select.hover.call(select, Object.assign({}, ev, { ctrl: true })); }
  };

  // ======================================================================
  // GRADIENT (G)
  // ======================================================================
  T.gradient = {
    cursor: 'crosshair', d: null,
    target() { const n = O.sel()[0]; return n && n.fills ? n : null; },
    paint(n, create) {
      let idx = (n.fills || []).findIndex(f => f.visible !== false && (f.type === 'linear' || f.type === 'radial'));
      if (idx < 0 && create) {
        const base = (n.fills || []).find(f => f.visible !== false);
        const c = base ? O.paintColor(base) : '#0D99FF';
        const g = O.paint.linear(c, '#FFFFFF');
        if (base) n.fills[n.fills.indexOf(base)] = g; else n.fills.push(g);
        idx = n.fills.indexOf(g);
      }
      return idx < 0 ? null : n.fills[idx];
    },
    space(n) {
      const b = model.localBounds(n);
      const W = model.worldMatrix(n);
      const U = M.mul(W, [Math.max(b.w, 1e-3), 0, 0, Math.max(b.h, 1e-3), b.x, b.y]);
      return { U, iU: M.inv(U) };
    },
    down(ev) {
      let n = this.target();
      if (!n) {
        const id = V.hitLeaf(ev.clientX, ev.clientY);
        const t = id && V.pick(id, ev.ctrl);
        if (t) O.select([t.id]);
        return;
      }
      const h = ev.h || '';
      if (h.startsWith('g:')) {
        const g = this.paint(n, false);
        this.d = { n, g, h: h.slice(2), snap: O.clone(n.fills) };
        return;
      }
      const g = this.paint(n, true);
      const { iU } = this.space(n);
      const u = M.apply(iU, ev.p);
      this.d = { n, g, h: 'new', start: u, s0: ev.s };
      O.requestRender();
    },
    move(ev) {
      const d = this.d;
      if (!d) return;
      const { iU } = this.space(d.n);
      let u = M.apply(iU, ev.p);
      if (d.h === 'new') {
        if (P.dist(d.s0, ev.s) < 3) return;
        let s = d.start;
        if (ev.shift) { const sw = M.apply(this.space(d.n).U, s); u = M.apply(iU, P.snap45(sw, ev.p)); }
        d.g.from = { ...s }; d.g.to = u;
      } else if (d.h === 'from' || d.h === 'to') {
        d.g[d.h] = u;
      } else if (d.h.startsWith('stop:')) {
        const i = +d.h.slice(5);
        const a = d.g.from, b = d.g.to, ab = P.sub(b, a);
        const t = ((u.x - a.x) * ab.x + (u.y - a.y) * ab.y) / ((ab.x * ab.x + ab.y * ab.y) || 1);
        d.g.stops[i].o = O.clamp(t, 0, 1);
      }
      O.requestRender();
    },
    up() { if (this.d) { this.d = null; O.history.commit('Градієнт'); } },
    dblclick(ev) {
      const n = this.target();
      if (!n) return;
      const g = this.paint(n, false);
      if (!g) return;
      const { iU } = this.space(n);
      const u = M.apply(iU, ev.p), a = g.from, ab = P.sub(g.to, a);
      const t = O.clamp(((u.x - a.x) * ab.x + (u.y - a.y) * ab.y) / ((ab.x * ab.x + ab.y * ab.y) || 1), 0, 1);
      const sorted = g.stops.slice().sort((x, y) => x.o - y.o);
      let c = sorted[0].color;
      for (let i = 0; i < sorted.length - 1; i++) if (t >= sorted[i].o && t <= sorted[i + 1].o) c = O.color.mix(sorted[i].color, sorted[i + 1].color, (t - sorted[i].o) / ((sorted[i + 1].o - sorted[i].o) || 1));
      g.stops.push({ o: t, color: c, a: 1 });
      O.history.commit('Точка градієнта');
    },
    overlay(Vm) {
      const n = this.target();
      if (!n) return '';
      const g = (n.fills || []).find(f => f.visible !== false && (f.type === 'linear' || f.type === 'radial'));
      if (!g) return '';
      const { U } = this.space(n);
      const SU = M.mul(Vm, U);
      const a = M.apply(SU, g.from), b = M.apply(SU, g.to);
      let s = `<line x1="${n_(a.x)}" y1="${n_(a.y)}" x2="${n_(b.x)}" y2="${n_(b.y)}" stroke="#fff" stroke-width="3" pointer-events="none"/><line x1="${n_(a.x)}" y1="${n_(a.y)}" x2="${n_(b.x)}" y2="${n_(b.y)}" stroke="#1E1E1E" stroke-width="1" pointer-events="none"/>`;
      if (g.type === 'radial') { const r = P.dist(a, b); s += `<circle cx="${n_(a.x)}" cy="${n_(a.y)}" r="${n_(r)}" fill="none" stroke="#fff" stroke-width="1" stroke-dasharray="4 3" pointer-events="none"/>`; }
      g.stops.forEach((st, i) => {
        const p = P.lerp(a, b, st.o);
        s += `<rect data-h="g:stop:${i}" x="${n_(p.x - 6)}" y="${n_(p.y - 6)}" width="12" height="12" rx="2" fill="${st.color}" stroke="#fff" stroke-width="2" style="cursor:pointer"/>`;
      });
      s += `<circle data-h="g:from" cx="${n_(a.x)}" cy="${n_(a.y)}" r="5" fill="#fff" stroke="#1E1E1E" stroke-width="1.5" style="cursor:move"/><circle data-h="g:to" cx="${n_(b.x)}" cy="${n_(b.y)}" r="5" fill="#1E1E1E" stroke="#fff" stroke-width="1.5" style="cursor:move"/>`;
      return s;
    }
  };

  // ======================================================================
  // BLEND (W)
  // ======================================================================
  T.blend = {
    cursor: 'crosshair', first: null,
    activate() { this.first = null; },
    down(ev) {
      const id = V.hitLeaf(ev.clientX, ev.clientY);
      const n = id && V.pick(id, false);
      if (!n) return;
      if (!this.first || !model.exists(this.first)) {
        this.first = n.id; O.select([n.id]);
        O.toast('Тепер клацніть другий об’єкт для переходу');
      } else if (n.id !== this.first) {
        const a = model.get(this.first);
        this.first = null;
        O.ops.blend(a, n, O.toolOpts.blendSteps);
      }
    },
    hover(ev) { select.hover.call(select, ev); }
  };

  // ======================================================================
  // SHAPE BUILDER (Shift+M)
  // ======================================================================
  T.shapebuilder = {
    cursor: 'crosshair', regions: [], d: null,
    activate() {
      this.regions = [];
      const nodes = O.sel().filter(n => ['path', 'rect', 'ellipse', 'polygon', 'star', 'bool'].includes(n.type));
      if (nodes.length < 2) { O.toast('Виділіть щонайменше дві перекриті фігури, потім оберіть «Створення фігур»'); return; }
      const made = O.ops.divide(nodes, { quiet: true });
      this.regions = made.map(n => n.id);
      O.select(this.regions);
      O.toast('Тягніть через області, щоб об’єднати. Alt+клік — видалити область.');
    },
    deactivate() { this.regions = []; this.d = null; S.hover = null; },
    regionAt(ev) {
      const ids = V.hitAll(ev.clientX, ev.clientY);
      return ids.find(id => this.regions.includes(id)) || null;
    },
    down(ev) {
      const r = this.regionAt(ev);
      if (!r) return;
      if (ev.alt) {
        model.remove(model.get(r));
        this.regions = this.regions.filter(x => x !== r);
        O.select(this.regions.filter(id => model.exists(id)));
        O.history.commit('Видалення області');
        return;
      }
      this.d = { set: [r] };
      O.requestOverlay();
    },
    move(ev) {
      if (!this.d) return;
      const r = this.regionAt(ev);
      if (r && !this.d.set.includes(r)) { this.d.set.push(r); O.requestOverlay(); }
    },
    up() {
      const d = this.d;
      this.d = null;
      if (!d) return;
      if (d.set.length > 1) {
        const nodes = d.set.map(model.get).filter(Boolean);
        const merged = O.ops.boolean('union', nodes, { destructive: true, quiet: true });
        this.regions = this.regions.filter(id => !d.set.includes(id));
        if (merged) this.regions.push(merged.id);
        O.select(this.regions.filter(id => model.exists(id)));
        O.history.commit('Створення фігур');
      }
      O.requestOverlay();
    },
    hover(ev) {
      const r = this.regionAt(ev);
      if (S.hover !== r) { S.hover = r; O.requestOverlay(); }
    },
    overlay(Vm) {
      let s = '';
      const ids = (this.d ? this.d.set : []).concat(S.hover && this.regions.includes(S.hover) ? [S.hover] : []);
      for (const id of ids) {
        const n = model.get(id);
        if (!n) continue;
        const SM = M.mul(Vm, model.worldMatrix(n));
        s += `<path d="${G.toD(model.subsIn(n, M.id()), SM)}" fill="rgba(13,153,255,0.25)" stroke="${ACC}" stroke-width="1.5" pointer-events="none" style="mix-blend-mode:multiply"/>`;
      }
      return s;
    }
  };

  // ======================================================================
  // ROTATE / REFLECT / SCALE / SHEAR tools (pivot based)
  // ======================================================================
  const reflectM = a => M.chain(M.rotate(a), M.scale(1, -1), M.rotate(-a));
  O.reflectMatrix = reflectM;
  const xformTool = kind => ({
    cursor: 'crosshair', pivot: null, d: null,
    activate() { this.pivot = null; },
    getPivot() {
      if (this.pivot) return this.pivot;
      const b = model.selBounds(topSel());
      return b ? R.center(b) : null;
    },
    mode() { return kind === 'scale' ? 'scale' : 'resize'; },
    down(ev) {
      if (!S.sel.length) {
        const id = V.hitLeaf(ev.clientX, ev.clientY);
        const n = id && V.pick(id, ev.ctrl);
        if (n) O.select([n.id]);
        return;
      }
      if (ev.h === 'pivot') { this.d = { kind: 'pivot' }; return; }
      this.d = { p0: ev.p, s0: ev.s, nodes: topSel(), snap: snapshot(topSel()), moved: false, pivot: this.getPivot(), alt: ev.alt };
    },
    matrix(d, ev) {
      const c = d.pivot;
      switch (kind) {
        case 'rotate': {
          let a = P.angle(c, ev.p) - P.angle(c, d.p0);
          if (ev.shift) a = Math.round(a / (Math.PI / 4)) * (Math.PI / 4);
          d.info = O.fmt(-O.deg(a), 1) + '°';
          return M.about(M.rotate(a), c);
        }
        case 'reflect': {
          let a = P.angle(c, ev.p);
          if (ev.shift) a = Math.round(a / (Math.PI / 4)) * (Math.PI / 4);
          d.info = O.t('вісь') + ' ' + O.fmt(-O.deg(a), 1) + '°';
          return M.about(reflectM(a), c);
        }
        case 'scale': {
          const dx0 = d.p0.x - c.x, dy0 = d.p0.y - c.y;
          let sx = Math.abs(dx0) > 1e-6 ? (ev.p.x - c.x) / dx0 : 1;
          let sy = Math.abs(dy0) > 1e-6 ? (ev.p.y - c.y) / dy0 : 1;
          if (ev.shift) { const s = P.dist(ev.p, c) / (P.dist(d.p0, c) || 1); sx = sy = s; }
          if (Math.abs(sx) < 1e-3) sx = 1e-3; if (Math.abs(sy) < 1e-3) sy = 1e-3;
          d.info = O.fmt(sx * 100, 1) + '% × ' + O.fmt(sy * 100, 1) + '%';
          return M.about(M.scale(sx, sy), c);
        }
        case 'shear': {
          const dy = d.p0.y - c.y, dx = d.p0.x - c.x;
          if (ev.shift || Math.abs(ev.p.y - d.p0.y) > Math.abs(ev.p.x - d.p0.x)) {
            const k = (ev.p.y - d.p0.y) / (Math.abs(dx) > 1e-6 ? dx : 1e-6);
            d.info = O.t('верт.') + ' ' + O.fmt(O.deg(Math.atan(k)), 1) + '°';
            return M.about([1, k, 0, 1, 0, 0], c);
          }
          const k = (ev.p.x - d.p0.x) / (Math.abs(dy) > 1e-6 ? dy : 1e-6);
          d.info = O.t('гориз.') + ' ' + O.fmt(O.deg(Math.atan(k)), 1) + '°';
          return M.about([1, 0, k, 1, 0, 0], c);
        }
      }
    },
    move(ev) {
      const d = this.d;
      if (!d) return;
      if (d.kind === 'pivot') { this.pivot = O.snap.point(ev.p, { noSmart: true }); O.requestOverlay(); return; }
      if (!d.moved && P.dist(d.s0, ev.s) < 3) return;
      d.moved = true;
      restoreAll(d.snap);
      d.G = this.matrix(d, ev);
      d.s = ev.s;
      d.nodes.forEach(n => model.applyWorld(n, d.G, this.mode()));
      O.requestRender();
    },
    up(ev) {
      const d = this.d;
      this.d = null;
      if (!d || d.kind === 'pivot') return;
      if (!d.moved) {
        this.pivot = ev.p;
        if (d.alt) O.ops.transformDialog(kind, this.pivot);
        O.requestOverlay();
        return;
      }
      const copy = ev.alt || d.alt;
      if (copy) {
        restoreAll(d.snap);
        const copies = O.ops.duplicate(d.nodes, { inPlace: true });
        copies.forEach(n => model.applyWorld(n, d.G, this.mode()));
        O.select(copies.map(c => c.id));
      }
      O.lastTransform = { G: d.G, copy, mode: this.mode(), ids: S.sel.slice() };
      O.history.commit({ rotate: 'Поворот', reflect: 'Віддзеркалення', scale: 'Масштабування', shear: 'Нахил' }[kind]);
    },
    dblclick() { O.ops.transformDialog(kind, this.getPivot()); },
    overlay() {
      const c = this.getPivot();
      if (!c || !S.sel.length) return '';
      const p = V.toScreen(c);
      let s = `<g data-h="pivot" style="cursor:move"><circle cx="${n_(p.x)}" cy="${n_(p.y)}" r="9" fill="transparent"/><circle cx="${n_(p.x)}" cy="${n_(p.y)}" r="5" fill="none" stroke="#1E1E1E" stroke-width="1.5"/><path d="M${n_(p.x - 9)} ${n_(p.y)}H${n_(p.x + 9)}M${n_(p.x)} ${n_(p.y - 9)}V${n_(p.y + 9)}" stroke="#1E1E1E" stroke-width="1"/></g>`;
      if (this.d && this.d.info && this.d.s) s += label(this.d.s.x + 14, this.d.s.y + 10, this.d.info);
      return s;
    }
  });
  ['rotate', 'reflect', 'scale', 'shear'].forEach(k => { T[k] = xformTool(k); });
})();
