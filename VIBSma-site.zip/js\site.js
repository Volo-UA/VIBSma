'use strict';
/* VIBSma — websites.
   · device presets: frames are named «Пристрій — W×H»
   · layout grids on frames (columns / rows / square grid), drawn over the canvas, edited in the Design panel
   · «Адаптивний сайт»: one frame per chosen device with a column grid and starter content whose layer names match
     between frames, joined by «Перо адаптації» — the HTML export is one responsive page at once. */
(function () {
  const O = window.O, M = O.M, model = O.model, S = O.state, panels = O.panels;
  const t = (s, v) => O.t(s, v), esc = O.esc, n_ = O.n;
  const SITE = O.site = {};

  // ---------- devices (common web design sizes, width × height in px) ----------
  SITE.DEVICES = [
    ['Десктоп', [['Десктоп', 1440, 1024, 'Найпопулярніший стандарт, з нього найкраще починати', true], ['Full HD', 1920, 1080, 'Великі монітори'], ['Ноутбук', 1366, 768, 'Найпоширеніший розмір ноутбуків'], ['MacBook Air', 1280, 800, 'Менші ноутбуки']]],
    ['Планшет', [['iPad горизонтально', 1024, 768, 'iPad у горизонтальній орієнтації'], ['iPad вертикально', 768, 1024, 'iPad у портретній орієнтації', true], ['iPad Pro 11″', 834, 1194, '']]],
    ['Мобільний', [['iPhone 14/15', 390, 844, 'Найкращий вибір для старту', true], ['iPhone X/11/12 mini', 375, 812, ''], ['Android', 360, 800, 'Типовий Android'], ['iPhone Pro Max', 430, 932, '']]]
  ];
  SITE.GRIDS = { 'Десктоп': { count: 12, gutter: 24, margin: 120 }, 'Планшет': { count: 8, gutter: 24, margin: 32 }, 'Мобільний': { count: 4, gutter: 16, margin: 20 } };
  SITE.kindOf = w => (w >= 1024 ? 'Десктоп' : w >= 600 ? 'Планшет' : 'Мобільний');
  SITE.gridFor = kind => Object.assign({ type: 'columns', color: '#FF4D4D', opacity: 0.1, visible: true }, SITE.GRIDS[kind] || SITE.GRIDS['Десктоп']);
  SITE.frameName = (dev, w, h) => `${t(dev)} — ${w}×${h}`;
  // frame tool presets: the first three groups are the device sizes
  const extra = { 'Десктоп': [['MacBook Air 13″', 1280, 832], ['MacBook Pro 14″', 1512, 982], ['iMac 24″', 2240, 1260], ['Мінімальний', 1024, 768]], 'Планшет': [['iPad mini', 744, 1133], ['Surface Pro', 1440, 960]], 'Мобільний': [['iPhone 16', 393, 852], ['iPhone 16 Pro Max', 440, 956], ['iPhone SE', 375, 667], ['Android великий', 412, 917]] };
  O.FRAME_PRESETS.splice(0, 3, ...SITE.DEVICES.map(([g, list]) => [g, list.map(d => [d[0], d[1], d[2]]).concat(extra[g] || [])]));

  // ---------- layout grids ----------
  const GRID_DEF = { columns: { color: '#FF4D4D' }, rows: { color: '#4D7CFF' }, grid: { color: '#FF4D4D' } };
  const gridShapes = (f, g) => {
    const out = [];
    const W = f.w, H = f.h;
    if (g.type === 'grid') return out;
    const along = g.type === 'columns' ? W : H;
    const count = Math.max(1, Math.round(g.count || 1)), gut = Math.max(0, g.gutter || 0), mar = Math.max(0, g.margin || 0);
    const size = (along - 2 * mar - gut * (count - 1)) / count;
    if (size <= 0) return out;
    for (let i = 0; i < count; i++) {
      const a = mar + i * (size + gut);
      out.push(g.type === 'columns' ? { x: a, y: 0, w: size, h: H } : { x: 0, y: a, w: W, h: size });
    }
    return out;
  };
  SITE.gridShapes = gridShapes;
  O.overlayHooks.unshift(Vm => {
    if (S.settings.layoutGrids === false || !S.doc) return '';
    let s = '';
    model.walk(model.page().children, n => {
      if (n.visible === false) return false;
      if (n.type !== 'frame' || !n.grids || !n.grids.length) return;
      const SM = M.mul(Vm, model.worldMatrix(n));
      for (const g of n.grids) {
        if (g.visible === false) continue;
        const col = g.color || GRID_DEF[g.type].color, op = g.opacity === undefined ? 0.1 : g.opacity;
        if (g.type === 'grid') {
          const step = Math.max(1, g.size || 8);
          const zoom = Math.hypot(SM[0], SM[1]);
          if (step * zoom < 4) continue;
          let d = '';
          for (let x = step; x < n.w; x += step) { const a = M.apply(SM, { x, y: 0 }), b = M.apply(SM, { x, y: n.h }); d += `M${n_(a.x)} ${n_(a.y)}L${n_(b.x)} ${n_(b.y)}`; }
          for (let y = step; y < n.h; y += step) { const a = M.apply(SM, { x: 0, y }), b = M.apply(SM, { x: n.w, y }); d += `M${n_(a.x)} ${n_(a.y)}L${n_(b.x)} ${n_(b.y)}`; }
          s += `<path d="${d}" stroke="${col}" stroke-opacity="${Math.min(1, op * 3)}" stroke-width="1" fill="none" pointer-events="none"/>`;
          continue;
        }
        for (const r of gridShapes(n, g)) {
          const pts = [[r.x, r.y], [r.x + r.w, r.y], [r.x + r.w, r.y + r.h], [r.x, r.y + r.h]].map(([x, y]) => M.apply(SM, { x, y }));
          s += `<polygon points="${pts.map(p => n_(p.x) + ',' + n_(p.y)).join(' ')}" fill="${col}" fill-opacity="${op}" pointer-events="none"/>`;
        }
      }
    });
    return s;
  });
  O.cmd('layoutGrids', 'Сітки макета', () => { S.settings.layoutGrids = S.settings.layoutGrids === false; O.saveSettings(); O.requestOverlay(); }, { keys: ['Ctrl+Shift+4'], group: 'Вигляд', check: () => S.settings.layoutGrids !== false });
  const view = O.MENUS.find(m => m[0] === 'Вигляд');
  if (view) view[1].splice(view[1].indexOf('grid') + 1, 0, 'layoutGrids');

  const GRID_PRESETS = [['desk', 'Десктоп: 12 колонок', () => SITE.gridFor('Десктоп')], ['tab', 'Планшет: 8 колонок', () => SITE.gridFor('Планшет')], ['mob', 'Мобільний: 4 колонки', () => SITE.gridFor('Мобільний')], ['g8', 'Квадратна сітка 8 px', () => ({ type: 'grid', size: 8, color: '#FF4D4D', opacity: 0.1, visible: true })], ['rows', 'Рядки: 6', () => ({ type: 'rows', count: 6, gutter: 24, margin: 0, color: '#4D7CFF', opacity: 0.1, visible: true })]];
  panels.extraSections.push(nodes => {
    if (nodes.length !== 1 || nodes[0].type !== 'frame') return '';
    const f = nodes[0];
    const gs = f.grids || [];
    const num = (i, k, v, label) => `<label class="fld" title="${esc(t(label))}"><span class="fl">${esc(t(label))}</span><input type="text" inputmode="decimal" data-lg="${k}" data-gi="${i}" value="${esc(v)}" aria-label="${esc(t(label))}"></label>`;
    const rows = gs.map((g, i) => `<div class="lg${g.visible === false ? ' off' : ''}"><div class="row"><select class="sel" data-lg="type" data-gi="${i}" aria-label="${esc(t('Тип сітки'))}">${[['columns', 'Колонки'], ['rows', 'Рядки'], ['grid', 'Сітка']].map(([v, l]) => `<option value="${v}"${g.type === v ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select><input type="color" data-lg="color" data-gi="${i}" value="${g.color || '#FF4D4D'}" aria-label="${esc(t('Колір'))}"><button type="button" class="ib" data-lga="eye" data-gi="${i}" title="${esc(t('Показати/приховати'))}" aria-label="${esc(t('Показати/приховати'))}">${O.icon(g.visible === false ? 'eyeoff' : 'eye', 15)}</button><button type="button" class="ib" data-lga="del" data-gi="${i}" title="${esc(t('Видалити'))}" aria-label="${esc(t('Видалити'))}">${O.icon('minus', 15)}</button></div>
      ${g.type === 'grid' ? `<div class="grid2">${num(i, 'size', g.size || 8, 'Крок')}</div>` : `<div class="grid2">${num(i, 'count', g.count, 'Кількість')}${num(i, 'gutter', g.gutter, 'Проміжок')}${num(i, 'margin', g.margin, 'Поля')}</div>`}</div>`).join('');
    const presets = `<select class="sel mini" data-lga="preset" aria-label="${esc(t('Готова сітка'))}"><option value="">${esc(t('Готова сітка…'))}</option>${GRID_PRESETS.map(([k, l]) => `<option value="${k}">${esc(t(l))}</option>`).join('')}</select>`;
    return `<section class="ps"><div class="ps-h"><span>${esc(t('Сітка макета'))}</span><span class="ps-x">${presets}<button type="button" class="ib" data-lga="add" title="${esc(t('Додати сітку'))}" aria-label="${esc(t('Додати сітку'))}">${O.icon('plus', 16)}</button></span></div>${rows}</section>`;
  });
  const props = () => O.$('#props');
  const frameSel = () => { const n = O.sel()[0]; return n && n.type === 'frame' ? n : null; };
  document.addEventListener('change', e => {
    const el = e.target;
    if (!el.dataset || !props() || !props().contains(el)) return;
    const f = frameSel();
    if (!f) return;
    if (el.dataset.lga === 'preset' && el.value) {
      const p = GRID_PRESETS.find(x => x[0] === el.value);
      if (p) { f.grids = (f.grids || []).concat([p[2]()]); O.history.commit('Сітка макета'); }
      return;
    }
    if (!el.dataset.lg) return;
    const g = (f.grids || [])[+el.dataset.gi];
    if (!g) return;
    const k = el.dataset.lg;
    if (k === 'type' || k === 'color') g[k] = el.value;
    else { const v = parseFloat(el.value); if (isFinite(v)) g[k] = Math.max(k === 'count' || k === 'size' ? 1 : 0, v); }
    if (k === 'type' && el.value === 'grid' && !g.size) g.size = 8;
    if (k === 'type' && el.value !== 'grid' && !g.count) Object.assign(g, { count: 4, gutter: 16, margin: 0 });
    O.history.commit('Сітка макета');
  });
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('button[data-lga]');
    if (!b || !props() || !props().contains(b)) return;
    const f = frameSel();
    if (!f) return;
    const i = +b.dataset.gi;
    if (b.dataset.lga === 'add') f.grids = (f.grids || []).concat([SITE.gridFor(SITE.kindOf(f.w))]);
    if (b.dataset.lga === 'del') f.grids.splice(i, 1);
    if (b.dataset.lga === 'eye') f.grids[i].visible = f.grids[i].visible === false;
    O.history.commit('Сітка макета');
  });

  // ---------- starter content (same layer names in every device frame) ----------
  const T = (name, text, x, y, size, o = {}) => model.create('text', { name, text, m: M.translate(Math.round(x), Math.round(y)), size, font: 'Inter', weight: o.weight || 400, lh: o.lh || 1.3, width: o.width === undefined ? null : Math.round(o.width), align: o.align || 'left', fills: [O.paint.solid(o.color || '#1E1E24')] });
  const B = (type, name, x, y, w, h, color, o = {}) => model.create(type, Object.assign({ name, m: M.translate(Math.round(x), Math.round(y)), w: Math.round(w), h: Math.round(h), fills: color ? [O.paint.solid(color)] : [] }, o));
  const textH = n => O.text.layout(n).h;
  const textW = n => O.text.layout(n).w;
  SITE.starter = (f, kind) => {
    const W = f.w, mob = kind === 'Мобільний', tab = kind === 'Планшет';
    const g = SITE.GRIDS[kind] || SITE.GRIDS['Десктоп'];
    const m = g.margin, cw = W - 2 * m;
    const kids = [];
    // header
    const hh = mob ? 64 : 80;
    const header = B('frame', 'Шапка', 0, 0, W, hh, '#FFFFFF', { clip: false });
    const logo = T('Логотип', 'VIBSma', m, 0, mob ? 22 : 24, { weight: 700 });
    logo.m = M.translate(m, Math.round(hh / 2 - textH(logo) / 2));
    const menu = mob ? T('Меню', '☰', 0, 0, 26) : T('Меню', t('Про нас     Послуги     Контакти'), 0, 0, tab ? 15 : 16, { color: '#4B4B57' });
    menu.m = M.translate(Math.round(W - m - textW(menu)), Math.round(hh / 2 - textH(menu) / 2));
    header.children = [logo, menu, B('rect', 'Лінія шапки', 0, hh - 1, W, 1, '#E6E6EB')];
    kids.push(header);
    // first screen
    const top = hh + (mob ? 40 : tab ? 72 : 96);
    const wText = mob || tab ? cw : Math.round(cw * 0.52);
    const title = T('Заголовок', t('Сайти, що чудово виглядають на будь-якому екрані'), m, top, mob ? 34 : tab ? 48 : 60, { weight: 700, width: wText, lh: 1.12 });
    const th = textH(title);
    const desc = T('Опис', t('Десктоп, планшет і мобільний з’єднано «Пером адаптації»: експорт дає одну адаптивну сторінку з медіазапитами.'), m, top + th + 24, mob ? 16 : 19, { width: wText, lh: 1.5, color: '#4B4B57' });
    const dh = textH(desc);
    const btnY = top + th + 24 + dh + 32;
    const btn = B('frame', 'Кнопка', m, btnY, mob ? cw : 220, 56, '#0D99FF', { radius: 12, clip: true, layout: { dir: 'h', gap: 0, pad: [0, 0, 0, 0], align: 'center', justify: 'center', wMode: 'fixed', hMode: 'fixed' } });
    btn.children = [T('Текст кнопки', t('Почати'), 0, 0, 17, { weight: 600, color: '#FFFFFF' })];
    kids.push(title, desc, btn);
    let imgX, imgY, imgW, imgH;
    if (!mob && !tab) { imgX = m + Math.round(cw * 0.58); imgW = W - m - imgX; imgY = top; imgH = Math.round(imgW * 0.78); } else { imgX = m; imgW = cw; imgY = btnY + 56 + 48; imgH = Math.round(cw * (mob ? 0.7 : 0.5)); }
    kids.push(B('rect', 'Зображення', imgX, imgY, imgW, imgH, null, { radius: 20, fills: [O.paint.linear('#7B61FF', '#0D99FF')] }));
    // cards
    const secY = Math.max(btnY + 56, imgY + imgH) + (mob ? 56 : 96);
    const st = T('Заголовок розділу', t('Що ми пропонуємо'), m, secY, mob ? 26 : 36, { weight: 700 });
    kids.push(st);
    const cols = mob ? 1 : tab ? 2 : 3, gap = mob ? 16 : 24;
    const cardW = (cw - gap * (cols - 1)) / cols, cardH = 220;
    const names = [t('Дизайн'), t('Розробка'), t('Підтримка')], colors = ['#0D99FF', '#14AE5C', '#FF3D9A'];
    const cardsY = secY + textH(st) + 32;
    for (let i = 0; i < 3; i++) {
      const card = B('frame', t('Картка {n}', { n: i + 1 }), m + (i % cols) * (cardW + gap), cardsY + Math.floor(i / cols) * (cardH + gap), cardW, cardH, '#F5F6FA', { radius: 16 });
      card.children = [B('ellipse', 'Іконка', 24, 24, 48, 48, colors[i]), T('Назва картки', names[i], 24, 96, 20, { weight: 600 }), T('Текст картки', t('Короткий опис послуги в одне-два речення.'), 24, 132, 15, { width: cardW - 48, lh: 1.5, color: '#4B4B57' })];
      kids.push(card);
    }
    const footY = cardsY + Math.ceil(3 / cols) * (cardH + gap) - gap + (mob ? 56 : 96);
    const fh = mob ? 120 : 140;
    const foot = B('frame', 'Підвал', 0, footY, W, fh, '#1E1E24', { clip: false });
    foot.children = [T('Логотип підвалу', 'VIBSma', m, 36, 22, { weight: 700, color: '#FFFFFF' }), T('Копірайт', '© ' + new Date().getFullYear() + ' ' + t('Усі права захищено'), m, mob ? 74 : 80, 14, { color: '#A6A6B4' })];
    kids.push(foot);
    f.children = (f.children || []).concat(kids);
    f.h = Math.max(f.h, footY + fh);
    return f;
  };
  SITE.makeFrames = (list, devs, opts = {}) => {
    let x = opts.x || 0;
    const y = opts.y || 0;
    const frames = devs.map(d => {
      const f = model.create('frame', { name: SITE.frameName(d.name, d.w, d.h), w: d.w, h: d.h, m: M.translate(x, y), fills: [O.paint.solid('#FFFFFF')], clip: true });
      if (opts.grids) f.grids = [SITE.gridFor(d.group)];
      if (opts.content) SITE.starter(f, d.group);
      list.push(f);
      x += d.w + 160;
      return f;
    });
    if (frames.length > 1 && O.links) { const l = O.links.create('adapt', frames.map(f => f.id)); l.name = opts.name || t('Головна'); }
    return frames;
  };
  // device chooser (resolves with { devs, name, content, grids } or null)
  SITE.chooser = (opts = {}) => new Promise(resolve => {
    const groups = SITE.DEVICES.map(([g, list]) => `<fieldset class="dev-g"><legend>${esc(t(g))}</legend>${list.map(([nm, w, h, note, def]) => `<label class="dev"><input type="checkbox" data-dev="${esc(g)}|${esc(nm)}|${w}|${h}"${def ? ' checked' : ''}><span class="dev-n">${esc(t(nm))}</span><span class="dev-s">${w} × ${h}</span>${note ? `<em>${esc(t(note))}</em>` : ''}</label>`).join('')}</fieldset>`).join('');
    let d = null;
    d = O.ui.dialog({
      title: opts.title || 'Адаптивний сайт',
      body: `<div class="dlg-text">${esc(t('Для кожного пристрою буде створено фрейм із назвою пристрою та розміром у пікселях, сітку колонок і стартовий вміст. Фрейми з’єднуються «Пером адаптації»: експорт дає один адаптивний HTML + CSS з медіазапитами.'))}</div>
        <div class="dev-quick"><button type="button" class="btn" data-devsel="all">${esc(t('Усі розміри'))}</button><button type="button" class="btn" data-devsel="rec">${esc(t('Рекомендовані: 1440 · 768 · 390'))}</button><button type="button" class="btn" data-devsel="none">${esc(t('Жодного'))}</button></div>
        <div class="dev-list">${groups}</div>
        <div class="dlg-text small">${esc(t('Брейкпоінти: мобільний — до 767 px, планшет — 768–1023 px, десктоп — від 1024 px (основний макет 1440 px). Висота фрейму не обмежена: сайт прокручується, тож подовжуйте фрейм під вміст.'))}</div>
        <ul class="dev-tips small">${['Сітка для десктопу 1440: 12 колонок, проміжок (gutter) 24 px, поля 80–120 px.', 'Планшет: 8 колонок, gutter 24 px, поля 32 px. Мобільний: 4 колонки, gutter 16 px, поля 16–20 px.', 'Контентна область зазвичай має максимальну ширину 1200–1280 px по центру.', 'Розміри, кратні 8 (8, 16, 24, 32…), зручні для відступів і елементів.', 'Інструмент «Фрейм» (F): праворуч з’являється список готових розмірів (десктоп, планшет, телефон, друк, Photoshop).'].map(s => `<li>${esc(t(s))}</li>`).join('')}</ul>`,
      fields: [{ key: 'name', label: 'Назва сторінки', type: 'text', value: opts.name || t('Головна') }, { key: 'content', label: 'Стартовий вміст (шапка, заголовок, картки, підвал)', type: 'checkbox', value: true }, { key: 'grids', label: 'Сітка колонок: 12 / 8 / 4', type: 'checkbox', value: true }],
      buttons: [{ id: 'ok', label: 'Створити', primary: true }],
      onOk: v => {
        const devs = Array.from(d.el.querySelectorAll('[data-dev]:checked')).map(i => { const [group, name, w, h] = i.dataset.dev.split('|'); return { group, name, w: +w, h: +h }; });
        resolve(devs.length ? Object.assign({}, v, { devs }) : null);
      },
      onCancel: () => resolve(null)
    });
    d.el.querySelector('.dlg').classList.add('wide');
    d.el.addEventListener('click', e => {
      const b = e.target.closest('[data-devsel]');
      if (!b) return;
      e.stopPropagation();
      const rec = new Set(SITE.DEVICES.flatMap(([g, list]) => list.filter(x => x[4]).map(x => g + '|' + x[0])));
      d.el.querySelectorAll('[data-dev]').forEach(i => { const [g, nm] = i.dataset.dev.split('|'); i.checked = b.dataset.devsel === 'all' || (b.dataset.devsel === 'rec' && rec.has(g + '|' + nm)); });
    });
  });
  // a new project: one page with the device frames
  SITE.siteDoc = v => {
    const prev = S.doc;
    const doc = model.newDoc();
    doc.name = t('Сайт «{name}»', { name: v.name || t('Головна') });
    S.doc = doc;
    try {
      doc.pages[0].name = v.name || t('Головна');
      SITE.makeFrames(doc.pages[0].children, v.devs, { content: v.content, grids: v.grids, name: v.name });
    } finally { S.doc = prev; }
    return doc;
  };
  // the same into the open document (next to what is already there)
  SITE.addFrames = async (newPage) => {
    const v = await SITE.chooser({ title: newPage ? 'Нова сторінка сайту' : 'Фрейми сайту', name: newPage ? t('Сторінка {n}', { n: S.doc.pages.length + 1 }) : t('Головна') });
    if (!v) return;
    if (newPage) {
      const pg = model.newPage(v.name || t('Сторінка'));
      S.doc.pages.push(pg); S.pageId = pg.id; S.sel = [];
      model.reindex(); O.emit('page');
    }
    const page = model.page();
    const b = page.children.length ? model.selBounds(page.children) : null;
    const frames = SITE.makeFrames(page.children, v.devs, { content: v.content, grids: v.grids, name: v.name, x: b ? Math.round(b.x + b.w + 240) : 0, y: b ? Math.round(b.y) : 0 });
    model.reindex();
    O.select(frames.map(f => f.id));
    O.history.commit('Фрейми сайту');
    setTimeout(() => O.view.fit(model.selBounds(frames), 80, 1), 0);
    O.toast('Створено фреймів: {n}. Експорт: Файл → Експорт HTML/CSS', { n: frames.length });
  };
  O.cmd('siteFrames', 'Додати фрейми сайту…', () => SITE.addFrames(false), { group: 'Файл' });
  O.cmd('sitePage', 'Нова сторінка сайту…', () => SITE.addFrames(true), { group: 'Файл' });
  O.cmd('siteExport', 'Згенерувати сайт (HTML + CSS)…', () => O.html.exportDialog(), { group: 'Файл' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл')[1];
  fileMenu.splice(fileMenu.indexOf('exportHTML'), 0, { label: 'Сайт', items: ['siteFrames', 'sitePage', 'siteExport', 'previewHTML'] });
  if (O.projects) {
    const tp = O.projects.templates;
    const i = tp.findIndex(x => x.id === 'web');
    const site = { id: 'site', name: 'Адаптивний сайт', icon: 'adaptpen', size: '1440 · 768 · 390', make: async () => { const v = await SITE.chooser(); return v ? SITE.siteDoc(v) : null; } };
    if (i >= 0) tp.splice(i, 1, site); else tp.splice(2, 0, site);
  }
})();
