'use strict';
/* VIBSma — résumé check for ATS (applicant tracking systems), in the spirit of makemycv.com's checker.
   The résumé is read the way an ATS reads a PDF: the text layers in reading order. The report scores contacts,
   standard section headings, length, bullet points, numbers in achievements, action verbs, dates, fonts and sizes,
   columns, text turned into outlines, pictures, clichés and — when a vacancy is pasted — the keywords it asks for.
   Everything is checked in the browser; nothing is sent anywhere. */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const AT = O.ats = {};

  // ---------- vocabularies (uk, en, ru, de) ----------
  const SECTIONS = {
    exp: ['досвід', 'досвід роботи', 'трудова діяльність', 'experience', 'work experience', 'employment', 'professional experience', 'опыт', 'опыт работы', 'berufserfahrung', 'erfahrung'],
    edu: ['освіта', 'education', 'образование', 'ausbildung', 'bildung', 'studium'],
    skills: ['навички', 'вміння', 'компетенції', 'skills', 'key skills', 'навыки', 'компетенции', 'kenntnisse', 'fähigkeiten', 'kompetenzen'],
    summary: ['профіль', 'про мене', 'summary', 'profile', 'about me', 'objective', 'профиль', 'о себе', 'profil', 'über mich', 'kurzprofil'],
    langs: ['мови', 'languages', 'языки', 'sprachen'],
    certs: ['сертифікати', 'курси', 'certifications', 'certificates', 'courses', 'сертификаты', 'курсы', 'zertifikate', 'weiterbildung']
  };
  const VERBS = ['збільшив', 'збільшила', 'запустив', 'запустила', 'керував', 'керувала', 'створив', 'створила', 'розробив', 'розробила', 'впровадив', 'впровадила', 'організував', 'організувала', 'скоротив', 'скоротила', 'оптимізував', 'оптимізувала', 'підготував', 'підготувала', 'виростила', 'виростив', 'навчив', 'навчила', 'провів', 'провела', 'досяг', 'досягла', 'побудував', 'побудувала', 'автоматизував', 'автоматизувала',
    'increased', 'launched', 'led', 'managed', 'created', 'developed', 'built', 'implemented', 'designed', 'reduced', 'improved', 'grew', 'delivered', 'achieved', 'organized', 'optimized', 'negotiated', 'trained', 'automated', 'drove', 'owned',
    'увеличил', 'увеличила', 'запустил', 'запустила', 'руководил', 'руководила', 'создал', 'создала', 'разработал', 'разработала', 'внедрил', 'внедрила', 'сократил', 'сократила',
    'erhöht', 'entwickelt', 'geleitet', 'eingeführt', 'aufgebaut', 'optimiert', 'gesteigert', 'reduziert', 'verantwortet', 'organisiert'];
  const CLICHES = ['командний гравець', 'стресостійк', 'комунікабельн', 'відповідальн', 'цілеспрямован', 'працьовит', 'team player', 'hard-working', 'hardworking', 'go-getter', 'detail-oriented', 'self-motivated', 'think outside the box', 'стрессоустойчив', 'коммуникабельн', 'ответственн', 'teamfähig', 'belastbar', 'zuverlässig'];
  const SAFE_FONTS = ['arial', 'calibri', 'helvetica', 'georgia', 'times new roman', 'garamond', 'cambria', 'verdana', 'tahoma', 'trebuchet ms', 'roboto', 'open sans', 'lato', 'inter', 'source sans', 'pt sans', 'pt serif', 'noto sans', 'noto serif', 'montserrat', 'merriweather', 'ibm plex sans', 'segoe ui', 'book antiqua', 'palatino', 'eb garamond', 'lora', 'raleway', 'nunito', 'manrope', 'onest'];
  const STOP = new Set('і й та в у на з із за до від для по про як що це ми ви він вона вони бути є або але не так також при під над через між the and or of to in on for with a an is are be as at by from this that will you your we our it its which who have has must should can may their they ли и в во на с со за до от для по о об как что это мы вы он она они быть или но не так также при под над через между der die das und oder mit für von zu im in am auf ist sind ein eine einer wir sie ihr'.split(' '));

  // ---------- read the résumé ----------
  AT.pickFrame = () => {
    const sel = O.sel();
    for (const n of sel) { let x = n; while (x && !model.isPage(model.parent(x)) && model.parent(x)) x = model.parent(x); if (x && x.type === 'frame') return x; }
    const pg = model.page();
    return pg.children.find(f => f.type === 'frame' && f.resume) || pg.children.find(f => f.type === 'frame' && /резюме|resume|cv|lebenslauf/i.test(f.name || '')) || pg.children.find(f => f.type === 'frame') || null;
  };
  AT.extract = frame => {
    const items = [], paths = [], images = [];
    model.walk(frame.children, n => {
      if (n.visible === false) return false;
      const b = model.worldBounds(n);
      if (n.type === 'text') { if (b) items.push({ n, b, text: String(n.text || ''), font: n.font || '', size: n.size || 12 }); return; }
      if ((n.fills || []).some(f => f.type === 'image') || n.type === 'raster') images.push({ n, b });
      if (n.type === 'path' && b && b.h < 40 && (n.subpaths || []).length > 3) paths.push({ n, b });
    });
    // reading order: top to bottom, left to right within a line band
    items.sort((a, c) => (Math.abs(a.b.y - c.b.y) > Math.min(a.size, c.size) * 0.6 ? a.b.y - c.b.y : a.b.x - c.b.x));
    return { items, paths, images, text: items.map(i => i.text).join('\n') };
  };

  // ---------- analysis ----------
  const words = s => (String(s).toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}+#.\-']*/gu) || []).map(w => w.replace(/[.\-']+$/, ''));
  AT.keywords = jd => {
    const ws = words(jd).filter(w => w.length > 2 && !STOP.has(w) && !/^\d+$/.test(w));
    const freq = new Map();
    ws.forEach(w => freq.set(w, (freq.get(w) || 0) + 1));
    // two-word terms («project management», «google analytics»)
    for (let i = 0; i < ws.length - 1; i++) { const b = ws[i] + ' ' + ws[i + 1]; if (b.length > 8) freq.set(b, (freq.get(b) || 0) + 0.8); }
    // single words count from their first mention, word pairs only when repeated
    return Array.from(freq.entries()).filter(([w, n]) => (w.includes(' ') ? n >= 1.6 : w.length > 3)).sort((a, b) => b[1] - a[1] || b[0].length - a[0].length).slice(0, 20).map(x => x[0]);
  };
  AT.analyze = (frame, jd = '') => {
    const ex = AT.extract(frame), text = ex.text, low = text.toLowerCase(), wcount = words(text).length;
    const checks = [];
    const add = (id, ok, title, tip, weight = 1, level) => checks.push({ id, ok, title, tip, weight, level: level || (ok ? 'ok' : 'bad') });
    // contacts
    const email = /[\w.+-]+@[\w-]+\.[\w.]+/.test(text), phone = /(\+?\d[\d\s().-]{8,}\d)/.test(text), link = /(linkedin\.com|github\.com|behance\.net|https?:\/\/)/i.test(text);
    add('email', email, t('E-mail'), email ? t('Адресу пошти знайдено.') : t('Додайте адресу e-mail текстом (не картинкою).'), 2);
    add('phone', phone, t('Телефон'), phone ? t('Номер телефону знайдено.') : t('Додайте номер телефону з кодом країни.'), 1.5);
    add('link', link, t('LinkedIn або портфоліо'), link ? t('Посилання знайдено.') : t('Посилання на LinkedIn чи портфоліо підвищує довіру рекрутера.'), 0.6, link ? 'ok' : 'warn');
    // sections (a heading = a short line that contains a known word)
    const lines = ex.items.map(i => i.text.trim().toLowerCase()).filter(Boolean);
    const has = key => lines.some(l => l.length < 40 && SECTIONS[key].some(w => l === w || l.startsWith(w + ' ') || l.endsWith(' ' + w) || l.replace(/[:\s]+$/, '') === w));
    add('exp', has('exp'), t('Розділ «Досвід роботи»'), has('exp') ? t('Стандартний заголовок знайдено.') : t('Назвіть розділ стандартно: «Досвід роботи» / «Experience». ATS шукає саме такі заголовки.'), 2.5);
    add('edu', has('edu'), t('Розділ «Освіта»'), has('edu') ? t('Знайдено.') : t('Додайте розділ «Освіта» / «Education».'), 1.8);
    add('skills', has('skills'), t('Розділ «Навички»'), has('skills') ? t('Знайдено.') : t('Додайте розділ «Навички» / «Skills» зі списком ключових умінь.'), 1.8);
    add('summary', has('summary'), t('Короткий профіль'), has('summary') ? t('Знайдено.') : t('2–3 речення про вас на початку допомагають і ATS, і людині.'), 0.8, has('summary') ? 'ok' : 'warn');
    // length
    const lenOk = wcount >= 250 && wcount <= 900;
    add('length', lenOk, t('Обсяг: {n} слів', { n: wcount }), wcount < 250 ? t('Замало тексту: опишіть досягнення детальніше (оптимально 300–800 слів).') : wcount > 900 ? t('Задовго: скоротіть до 1–2 сторінок (до ~800 слів).') : t('Оптимальний обсяг.'), 1, lenOk ? 'ok' : 'warn');
    // bullets, numbers, verbs
    const bulletLines = ex.items.flatMap(i => i.text.split('\n')).filter(l => /^\s*[•\-–▪●◦*]\s+/.test(l));
    add('bullets', bulletLines.length >= 3, t('Маркеровані пункти'), bulletLines.length >= 3 ? t('Досягнення оформлено списком ({n}).', { n: bulletLines.length }) : t('Оформіть досягнення списком із маркерами «•» — так їх легше прочитати.'), 1.2, bulletLines.length >= 3 ? 'ok' : 'warn');
    const nums = bulletLines.filter(l => /\d/.test(l)).length;
    add('numbers', nums >= 2, t('Числа в досягненнях'), nums >= 2 ? t('{n} досягнень мають цифри — чудово.', { n: nums }) : t('Додайте цифри: «+38% продажів», «команда з 5 осіб», «бюджет 2 млн».'), 1.4, nums >= 2 ? 'ok' : 'warn');
    const verbHits = bulletLines.filter(l => { const w = words(l)[0]; return w && VERBS.some(v => w.startsWith(v.slice(0, Math.max(5, v.length - 2)))); }).length;
    add('verbs', verbHits >= 2, t('Дієслова дії'), verbHits >= 2 ? t('Пункти починаються з дієслів дії.') : t('Починайте пункти з дієслів: «запустила», «збільшив», «led», «built».'), 0.8, verbHits >= 2 ? 'ok' : 'warn');
    // dates
    const dates = (text.match(/(19|20)\d{2}/g) || []).length;
    add('dates', dates >= 2, t('Дати роботи й навчання'), dates >= 2 ? t('Дати знайдено.') : t('Вкажіть роки (або місяць і рік) для кожної посади.'), 1);
    // fonts & sizes
    const fonts = Array.from(new Set(ex.items.map(i => (i.font || '').trim()).filter(Boolean)));
    const odd = fonts.filter(f => !SAFE_FONTS.some(s => f.toLowerCase().startsWith(s)));
    add('fonts', !odd.length, t('Шрифти'), odd.length ? t('Декоративні шрифти можуть зчитатися з помилками: {f}. Краще Arial, Calibri, Roboto, Inter, Georgia.', { f: odd.slice(0, 3).join(', ') }) : t('Стандартні, добре читаються.'), 1, odd.length ? 'warn' : 'ok');
    const pt = frame.w ? 595 / frame.w : 1;
    const tiny = ex.items.filter(i => i.size * pt < 8.5 && i.text.trim().length > 3).length;
    add('size', !tiny, t('Розмір тексту'), tiny ? t('{n} текстів дрібніші за 9 pt — збільште основний текст до 10–11 pt.', { n: tiny }) : t('Текст достатнього розміру.'), 0.8, tiny ? 'warn' : 'ok');
    // columns: two text blocks side by side through a large part of the page
    const H = frame.h || 842, W = frame.w || 595, fx = model.worldBounds(frame).x;
    // two columns = texts kept in the left part and texts starting in the right part, side by side over much of the page
    const left = ex.items.filter(i => i.b.x - fx + i.b.w < W * 0.48 && i.text.trim().length > 3), right = ex.items.filter(i => i.b.x - fx > W * 0.38 && i.text.trim().length > 3);
    const yr = arr => [Math.min(...arr.map(i => i.b.y)), Math.max(...arr.map(i => i.b.y + i.b.h))];
    const ov = left.length && right.length ? Math.max(0, Math.min(yr(left)[1], yr(right)[1]) - Math.max(yr(left)[0], yr(right)[0])) : 0;
    const cols = left.length >= 4 && right.length >= 4 && ov > H * 0.3;
    add('columns', !cols, t('Одна колонка'), cols ? t('Резюме у дві колонки: частина ATS читає їх упереміш. Для подання через сайти вакансій оберіть одноколонковий шаблон.') : t('Одна колонка — ATS прочитає в правильному порядку.'), 1.6, cols ? 'warn' : 'ok');
    // text as outlines, images
    add('outlines', ex.paths.length < 8, t('Текст як текст'), ex.paths.length >= 8 ? t('Схоже, частину тексту перетворено на криві ({n}). ATS не прочитає його — залиште текст текстом.', { n: ex.paths.length }) : t('Текст можна виділити й скопіювати.'), 2, ex.paths.length >= 8 ? 'bad' : 'ok');
    const bigImg = ex.images.filter(i => i.b && i.b.w * i.b.h > W * H * 0.08).length;
    add('images', !bigImg, t('Зображення'), bigImg ? t('Великі зображення або текст на картинках ATS ігнорує.') : ex.images.length ? t('Фото не заважає, але в США й Великій Британії його зазвичай не додають.') : t('Без зайвих зображень.'), 0.6, bigImg ? 'warn' : 'ok');
    // clichés & pronouns
    const cl = CLICHES.filter(c => low.includes(c));
    add('cliches', !cl.length, t('Без штампів'), cl.length ? t('Замініть загальні фрази доказами: {c}.', { c: cl.slice(0, 3).join(', ') }) : t('Загальних штампів не знайдено.'), 0.5, cl.length ? 'warn' : 'ok');
    // vacancy keywords
    let kw = null;
    if (jd.trim()) {
      const keys = AT.keywords(jd);
      const found = keys.filter(k => low.includes(k)), missing = keys.filter(k => !low.includes(k));
      const share = keys.length ? found.length / keys.length : 1;
      kw = { keys, found, missing, share };
      add('keywords', share >= 0.6, t('Ключові слова вакансії: {p}%', { p: Math.round(share * 100) }), share >= 0.6 ? t('Резюме добре відповідає вакансії.') : t('Додайте слова з вакансії, які описують ваш реальний досвід: {k}.', { k: missing.slice(0, 6).join(', ') }), 3, share >= 0.6 ? 'ok' : share >= 0.35 ? 'warn' : 'bad');
    }
    const total = checks.reduce((a, c) => a + c.weight, 0);
    const got = checks.reduce((a, c) => a + c.weight * (c.level === 'ok' ? 1 : c.level === 'warn' ? 0.5 : 0), 0);
    return { score: Math.round(got / total * 100), checks, kw, wcount, text, items: ex.items.length };
  };

  // ---------- dialog ----------
  AT.dialog = () => {
    const frame = AT.pickFrame();
    if (!frame) return O.toast('Додайте резюме: Файл → «Шаблони резюме…» або виділіть фрейм із резюме');
    const d = ui.dialog({
      title: 'Перевірка резюме на ATS',
      body: `<div class="ats"><div class="ats-l"><div class="dlg-text small">${esc(t('Резюме: «{name}». ATS (системи відбору кандидатів) читають текст резюме автоматично. Перевірка показує, що вони побачать і що покращити. Нічого не надсилається в інтернет.', { name: frame.name }))}</div>
        <label class="fl-row col"><span>${esc(t('Текст вакансії (необов’язково) — для перевірки ключових слів'))}</span><textarea class="ats-jd" rows="7" placeholder="${esc(t('Вставте опис вакансії…'))}">${esc(O.ls.get('atsJD', ''))}</textarea></label>
        <button type="button" class="btn primary" data-ats="run">${esc(t('Перевірити'))}</button>
        <details class="ats-raw"><summary>${esc(t('Що бачить ATS (текст у порядку читання)'))}</summary><pre></pre></details></div>
        <div class="ats-r" aria-live="polite"></div></div>`,
      buttons: [{ id: 'pdf', label: 'Експорт PDF' }, { id: 'ok', label: 'Готово', primary: true }],
      onOk: (v, b) => { if (b === 'pdf') { O.select([frame.id]); O.run('exportPDF'); } }
    });
    d.el.querySelector('.dlg').classList.add('wide', 'ats-wide');
    const out = d.el.querySelector('.ats-r'), jd = d.el.querySelector('.ats-jd');
    const run = () => {
      O.ls.set('atsJD', jd.value);
      const r = AT.analyze(frame, jd.value);
      const col = r.score >= 80 ? '#14AE5C' : r.score >= 60 ? '#F5A623' : '#E5484D';
      const verdict = r.score >= 80 ? t('Чудово: резюме готове для ATS') : r.score >= 60 ? t('Непогано, але є що покращити') : t('ATS може відсіяти це резюме');
      const ic = l => (l === 'ok' ? '✓' : l === 'warn' ? '!' : '✕');
      out.innerHTML = `<div class="ats-score"><svg viewBox="0 0 120 120" width="120" height="120" aria-hidden="true"><circle cx="60" cy="60" r="52" fill="none" stroke="var(--panel-3)" stroke-width="12"/><circle cx="60" cy="60" r="52" fill="none" stroke="${col}" stroke-width="12" stroke-linecap="round" stroke-dasharray="${(r.score / 100 * 326.7).toFixed(1)} 400" transform="rotate(-90 60 60)"/><text x="60" y="68" text-anchor="middle" font-size="30" font-weight="800" fill="currentColor">${r.score}</text></svg><div><b>${esc(verdict)}</b><span>${esc(t('Оцінка відповідності ATS із 100'))}</span></div></div>
        <ul class="ats-list">${r.checks.slice().sort((a, b) => ({ bad: 0, warn: 1, ok: 2 }[a.level] - { bad: 0, warn: 1, ok: 2 }[b.level])).map(c => `<li class="${c.level}"><i>${ic(c.level)}</i><div><b>${esc(c.title)}</b><span>${esc(c.tip)}</span></div></li>`).join('')}</ul>
        ${r.kw ? `<h5>${esc(t('Ключові слова вакансії'))}</h5><div class="ats-kw">${r.kw.found.map(k => `<span class="ok">${esc(k)}</span>`).join('')}${r.kw.missing.map(k => `<span class="bad">${esc(k)}</span>`).join('')}</div>` : ''}`;
      d.el.querySelector('.ats-raw pre').textContent = r.text;
    };
    d.el.addEventListener('click', e => { if (e.target.closest('[data-ats="run"]')) { e.preventDefault(); run(); } });
    run();
  };
  O.cmd('atsCheck', 'Перевірити резюме на ATS…', () => AT.dialog(), { group: 'Файл' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл');
  if (fileMenu) { const i = fileMenu[1].indexOf('resumeTemplates'); fileMenu[1].splice(i < 0 ? fileMenu[1].length : i + 1, 0, 'atsCheck'); }
})();
