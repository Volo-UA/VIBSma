'use strict';
/* VIBSma — the Filter menu of Photoshop.
   Last filter, Convert for Smart Filters, Neural Filters, Filter Gallery, Adaptive Wide Angle, Camera Raw,
   AI Denoise, AI Sharpen, Lens Correction, Liquify, Vanishing Point and the submenus Noise, Render, Sharpen,
   Stylize, Pixelate, Distort, Video, Blur Gallery, Blur and Other.
   Filters work on photos (image fills, photos in graphic frames, pixel layers). Vector objects are rasterized
   first. «Smart» photos keep the original and a list of filters that can be switched off, edited or removed
   (Design panel → «Смарт-фільтри»); otherwise the result replaces the picture and «Повернути оригінал» undoes it.
   Everything runs in the browser on canvas pixels. */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui, io = O.io;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const FL = O.filters = {};

  // ======================================================================
  // PIXEL HELPERS
  // ======================================================================
  const MAX_SIDE = 4096;
  const cl = v => (v < 0 ? 0 : v > 255 ? 255 : v);
  const copy = im => new ImageData(new Uint8ClampedArray(im.data), im.width, im.height);
  const blank = (w, h) => new ImageData(w, h);
  const lum = (d, i) => 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
  const rng = seed => { let s = (seed >>> 0) || 0x9E3779B9; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; };
  const hex = h => { const c = O.color.parse(h) || { r: 0, g: 0, b: 0 }; return [c.r, c.g, c.b]; };
  // premultiplied float copy (blurs do not darken transparent edges)
  const toPre = im => { const d = im.data, a = new Float32Array(d.length); for (let i = 0; i < d.length; i += 4) { const al = d[i + 3] / 255; a[i] = d[i] * al; a[i + 1] = d[i + 1] * al; a[i + 2] = d[i + 2] * al; a[i + 3] = d[i + 3]; } return a; };
  const fromPre = (a, w, h) => { const out = blank(w, h), d = out.data; for (let i = 0; i < a.length; i += 4) { const al = a[i + 3]; d[i + 3] = al; if (al > 0.5) { const k = 255 / al; d[i] = a[i] * k; d[i + 1] = a[i + 1] * k; d[i + 2] = a[i + 2] * k; } } return out; };
  const boxH = (src, dst, w, h, r) => {
    const k = 1 / (r + r + 1);
    for (let y = 0; y < h; y++) {
      const row = y * w * 4;
      for (let c = 0; c < 4; c++) {
        let v = (r + 1) * src[row + c];
        for (let j = 0; j < r; j++) v += src[row + Math.min(j, w - 1) * 4 + c];
        for (let x = 0; x < w; x++) { v += src[row + Math.min(x + r, w - 1) * 4 + c] - src[row + Math.max(x - r - 1, 0) * 4 + c]; dst[row + x * 4 + c] = v * k; }
      }
    }
  };
  const boxV = (src, dst, w, h, r) => {
    const k = 1 / (r + r + 1), st = w * 4;
    for (let x = 0; x < w; x++) {
      for (let c = 0; c < 4; c++) {
        const col = x * 4 + c;
        let v = (r + 1) * src[col];
        for (let j = 0; j < r; j++) v += src[Math.min(j, h - 1) * st + col];
        for (let y = 0; y < h; y++) { v += src[Math.min(y + r, h - 1) * st + col] - src[Math.max(y - r - 1, 0) * st + col]; dst[y * st + col] = v * k; }
      }
    }
  };
  const boxes = sigma => { const wi = Math.sqrt(12 * sigma * sigma / 3 + 1); let wl = Math.floor(wi); if (wl % 2 === 0) wl--; const wu = wl + 2; const m = Math.round((12 * sigma * sigma - 3 * wl * wl - 12 * wl - 9) / (-4 * wl - 4)); return [0, 1, 2].map(i => (i < m ? wl : wu)); };
  const gauss = (im, sigma) => {
    if (!(sigma > 0.25)) return copy(im);
    const { width: w, height: h } = im;
    let a = toPre(im); const b = new Float32Array(a.length);
    for (const s of boxes(sigma)) { const r = Math.max(0, (s - 1) >> 1); boxH(a, b, w, h, r); boxV(b, a, w, h, r); }
    return fromPre(a, w, h);
  };
  const box = (im, r) => { const { width: w, height: h } = im; const a = toPre(im), b = new Float32Array(a.length); r = Math.max(0, Math.round(r)); boxH(a, b, w, h, r); boxV(b, a, w, h, r); return fromPre(a, w, h); };
  // bilinear sample with clamped edges (or transparent outside)
  const sampler = (im, transparent) => {
    const { width: w, height: h, data: d } = im;
    return (x, y, out, o) => {
      if (transparent && (x < -0.5 || y < -0.5 || x > w - 0.5 || y > h - 0.5)) { out[o] = out[o + 1] = out[o + 2] = out[o + 3] = 0; return; }
      x = x < 0 ? 0 : x > w - 1 ? w - 1 : x; y = y < 0 ? 0 : y > h - 1 ? h - 1 : y;
      const x0 = x | 0, y0 = y | 0, x1 = x0 + 1 < w ? x0 + 1 : x0, y1 = y0 + 1 < h ? y0 + 1 : y0, fx = x - x0, fy = y - y0;
      const i00 = (y0 * w + x0) * 4, i10 = (y0 * w + x1) * 4, i01 = (y1 * w + x0) * 4, i11 = (y1 * w + x1) * 4;
      for (let c = 0; c < 4; c++) { const a = d[i00 + c] + (d[i10 + c] - d[i00 + c]) * fx, b = d[i01 + c] + (d[i11 + c] - d[i01 + c]) * fx; out[o + c] = a + (b - a) * fy; }
    };
  };
  // out(x, y) = in(map(x, y))
  const warp = (im, map, transparent) => {
    const { width: w, height: h } = im, out = blank(w, h), d = out.data, smp = sampler(im, transparent), p = [0, 0];
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { map(x, y, p); smp(p[0], p[1], d, (y * w + x) * 4); }
    return out;
  };
  const perPixel = (im, fn) => { const out = copy(im), d = out.data; for (let i = 0; i < d.length; i += 4) fn(d, i); return out; };
  const conv = (im, k, size, div = 1, off = 0, alpha = false) => {
    const { width: w, height: h, data: s } = im, out = blank(w, h), d = out.data, r = size >> 1;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let R = 0, G = 0, B = 0, A = 0;
      for (let j = -r; j <= r; j++) { const yy = Math.min(h - 1, Math.max(0, y + j)); for (let i = -r; i <= r; i++) { const xx = Math.min(w - 1, Math.max(0, x + i)); const kk = k[(j + r) * size + i + r]; if (!kk) continue; const q = (yy * w + xx) * 4; R += s[q] * kk; G += s[q + 1] * kk; B += s[q + 2] * kk; A += s[q + 3] * kk; } }
      const o = (y * w + x) * 4;
      d[o] = R / div + off; d[o + 1] = G / div + off; d[o + 2] = B / div + off; d[o + 3] = alpha ? A / div : s[o + 3];
    }
    return out;
  };
  const lumMap = im => { const d = im.data, L = new Float32Array(im.width * im.height); for (let i = 0, j = 0; i < d.length; i += 4, j++) L[j] = lum(d, i); return L; };
  const sobel = im => {
    const { width: w, height: h } = im, L = lumMap(im), M = new Float32Array(w * h);
    const at = (x, y) => L[Math.min(h - 1, Math.max(0, y)) * w + Math.min(w - 1, Math.max(0, x))];
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const gx = -at(x - 1, y - 1) - 2 * at(x - 1, y) - at(x - 1, y + 1) + at(x + 1, y - 1) + 2 * at(x + 1, y) + at(x + 1, y + 1);
      const gy = -at(x - 1, y - 1) - 2 * at(x, y - 1) - at(x + 1, y - 1) + at(x - 1, y + 1) + 2 * at(x, y + 1) + at(x + 1, y + 1);
      M[y * w + x] = Math.min(255, Math.hypot(gx, gy) / 4);
    }
    return M;
  };
  // per-channel median (histogram per row window)
  const median = (im, r, thr = 0) => {
    r = Math.max(1, Math.round(r));
    const { width: w, height: h, data: s } = im, out = copy(im), d = out.data, half = ((2 * r + 1) * (2 * r + 1)) >> 1;
    for (let c = 0; c < 3; c++) {
      const hist = new Int32Array(256);
      for (let y = 0; y < h; y++) {
        hist.fill(0);
        for (let j = -r; j <= r; j++) { const yy = Math.min(h - 1, Math.max(0, y + j)); for (let i = -r; i <= r; i++) { const xx = Math.min(w - 1, Math.max(0, i)); hist[s[(yy * w + xx) * 4 + c]]++; } }
        for (let x = 0; x < w; x++) {
          if (x > 0) {
            const xo = Math.max(0, x - r - 1), xn = Math.min(w - 1, x + r);
            for (let j = -r; j <= r; j++) { const yy = Math.min(h - 1, Math.max(0, y + j)); hist[s[(yy * w + xo) * 4 + c]]--; hist[s[(yy * w + xn) * 4 + c]]++; }
          }
          let acc = 0, m = 0;
          for (; m < 256; m++) { acc += hist[m]; if (acc > half) break; }
          const o = (y * w + x) * 4 + c;
          if (!thr || Math.abs(s[o] - m) > thr) d[o] = m;
        }
      }
    }
    return out;
  };
  // separable max / min (dilate / erode) per channel
  const morph = (im, r, isMax) => {
    r = Math.max(1, Math.round(r));
    const { width: w, height: h } = im, a = copy(im), b = copy(im), A = a.data, B = b.data;
    const pick = isMax ? Math.max : Math.min;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) for (let c = 0; c < 3; c++) { let v = A[(y * w + x) * 4 + c]; for (let i = -r; i <= r; i++) { const xx = Math.min(w - 1, Math.max(0, x + i)); v = pick(v, A[(y * w + xx) * 4 + c]); } B[(y * w + x) * 4 + c] = v; }
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) for (let c = 0; c < 3; c++) { let v = B[(y * w + x) * 4 + c]; for (let j = -r; j <= r; j++) { const yy = Math.min(h - 1, Math.max(0, y + j)); v = pick(v, B[(yy * w + x) * 4 + c]); } A[(y * w + x) * 4 + c] = v; }
    return a;
  };
  // Kuwahara (oil paint, watercolour): the calmest of four quadrants, via integral images
  const kuwahara = (im, r) => {
    r = Math.max(1, Math.round(r));
    const { width: w, height: h, data: s } = im, W = w + 1;
    const IR = new Float64Array(W * (h + 1)), IG = new Float64Array(W * (h + 1)), IB = new Float64Array(W * (h + 1)), IL = new Float64Array(W * (h + 1)), IL2 = new Float64Array(W * (h + 1));
    for (let y = 0; y < h; y++) {
      let r0 = 0, g0 = 0, b0 = 0, l0 = 0, l2 = 0;
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4, L = lum(s, i);
        r0 += s[i]; g0 += s[i + 1]; b0 += s[i + 2]; l0 += L; l2 += L * L;
        const q = (y + 1) * W + x + 1, p = y * W + x + 1;
        IR[q] = IR[p] + r0; IG[q] = IG[p] + g0; IB[q] = IB[p] + b0; IL[q] = IL[p] + l0; IL2[q] = IL2[p] + l2;
      }
    }
    const sum = (I, x0, y0, x1, y1) => I[y1 * W + x1] - I[y0 * W + x1] - I[y1 * W + x0] + I[y0 * W + x0];
    const out = copy(im), d = out.data;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let best = Infinity, br = 0, bg = 0, bb = 0;
      for (const [qx, qy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
        const x0 = Math.max(0, qx < 0 ? x - r : x), x1 = Math.min(w, (qx < 0 ? x : x + r) + 1);
        const y0 = Math.max(0, qy < 0 ? y - r : y), y1 = Math.min(h, (qy < 0 ? y : y + r) + 1);
        const n = (x1 - x0) * (y1 - y0);
        const m = sum(IL, x0, y0, x1, y1) / n, v = sum(IL2, x0, y0, x1, y1) / n - m * m;
        if (v < best) { best = v; br = sum(IR, x0, y0, x1, y1) / n; bg = sum(IG, x0, y0, x1, y1) / n; bb = sum(IB, x0, y0, x1, y1) / n; }
      }
      const o = (y * w + x) * 4; d[o] = br; d[o + 1] = bg; d[o + 2] = bb;
    }
    return out;
  };
  const mix = (a, b, k) => { const out = copy(a), d = out.data, e = b.data; for (let i = 0; i < d.length; i++) d[i] = d[i] + (e[i] - d[i]) * k; return out; };
  // per-pixel mix by a mask 0…1
  const mixMask = (a, b, mask) => { const out = copy(a), d = out.data, e = b.data; for (let j = 0, i = 0; j < mask.length; j++, i += 4) { const k = mask[j]; if (!k) continue; for (let c = 0; c < 4; c++) d[i + c] = d[i + c] + (e[i + c] - d[i + c]) * k; } return out; };
  const unsharp = (im, amount, radius, thr = 0) => { const b = gauss(im, radius), out = copy(im), d = out.data, e = b.data, s = im.data; for (let i = 0; i < d.length; i += 4) for (let c = 0; c < 3; c++) { const diff = s[i + c] - e[i + c]; if (Math.abs(diff) >= thr) d[i + c] = s[i + c] + diff * amount; } return out; };
  const gray = (d, i, v) => { d[i] = d[i + 1] = d[i + 2] = v; };
  const rgb2hsl = (r, g, b) => { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let h = 0, s = 0; if (mx !== mn) { const dd = mx - mn; s = l > 0.5 ? dd / (2 - mx - mn) : dd / (mx + mn); h = mx === r ? (g - b) / dd + (g < b ? 6 : 0) : mx === g ? (b - r) / dd + 2 : (r - g) / dd + 4; h /= 6; } return [h, s, l]; };
  // smooth noise for clouds / fibres
  const vnoise = (seed, scale) => {
    const R = rng(seed), P = new Float32Array(256 * 256);
    for (let i = 0; i < P.length; i++) P[i] = R();
    const at = (x, y) => P[((y & 255) << 8) | (x & 255)];
    const sm = v => v * v * (3 - 2 * v);
    const n = (x, y) => { const x0 = Math.floor(x), y0 = Math.floor(y), fx = sm(x - x0), fy = sm(y - y0); const a = at(x0, y0) + (at(x0 + 1, y0) - at(x0, y0)) * fx, b = at(x0, y0 + 1) + (at(x0 + 1, y0 + 1) - at(x0, y0 + 1)) * fx; return a + (b - a) * fy; };
    return (x, y) => { let v = 0, a = 0.5, f = 1 / scale; for (let o = 0; o < 6; o++) { v += n(x * f, y * f) * a; a *= 0.5; f *= 2; } return v; };
  };
  // perspective: the 3×3 matrix that sends the unit square to four points
  const sq2quad = q => {
    const [[x0, y0], [x1, y1], [x2, y2], [x3, y3]] = q;
    const dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3, dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3;
    const den = dx1 * dy2 - dx2 * dy1 || 1e-9;
    const g = (dx3 * dy2 - dx2 * dy3) / den, h = (dx1 * dy3 - dx3 * dy1) / den;
    return [x1 - x0 + g * x1, x3 - x0 + h * x3, x0, y1 - y0 + g * y1, y3 - y0 + h * y3, y0, g, h, 1];
  };

  // ======================================================================
  // FILTERS: { id, name, group, params, run(im, p) }  (p.px params are already scaled for previews)
  // ======================================================================
  const F = FL.defs = {};
  const def = (id, name, group, params, run, extra = {}) => { F[id] = Object.assign({ id, name, group, params, run }, extra); };
  const num = (k, l, min, max, v, o = {}) => Object.assign({ k, l, min, max, v, step: o.step || 1 }, o);
  const sel = (k, l, opts, v) => ({ k, l, o: opts, v });
  const col = (k, l, v) => ({ k, l, c: true, v });
  const chk = (k, l, v) => ({ k, l, b: true, v });

  // ---------- Noise ----------
  def('addNoise', 'Додати шум…', 'Шум', [num('amount', 'Сила', 0, 100, 12, { u: '%' }), sel('dist', 'Тип розподілу', [['uniform', 'Рівномірний'], ['gauss', 'За Гаусом']], 'gauss'), chk('mono', 'Монохромний', false)], (im, p) => {
    const R = rng(7), a = p.amount * 2.55;
    const n = () => (p.dist === 'gauss' ? (R() + R() + R() - 1.5) / 1.5 : R() * 2 - 1) * a;
    return perPixel(im, (d, i) => { if (p.mono) { const v = n(); d[i] = cl(d[i] + v); d[i + 1] = cl(d[i + 1] + v); d[i + 2] = cl(d[i + 2] + v); } else { d[i] = cl(d[i] + n()); d[i + 1] = cl(d[i + 1] + n()); d[i + 2] = cl(d[i + 2] + n()); } });
  });
  def('dust', 'Пил і подряпини…', 'Шум', [num('radius', 'Радіус', 1, 16, 2, { u: 'px', px: true }), num('thr', 'Поріг', 0, 255, 10)], (im, p) => median(im, p.radius, p.thr));
  def('despeckle', 'Ретуш', 'Шум', [], im => median(im, 1, 6));
  def('median', 'Медіана…', 'Шум', [num('radius', 'Радіус', 1, 16, 2, { u: 'px', px: true })], (im, p) => median(im, p.radius));
  def('reduceNoise', 'Зменшити шум…', 'Шум', [num('strength', 'Сила', 0, 10, 6), num('detail', 'Зберегти деталі', 0, 100, 60, { u: '%' })], (im, p) => denoise(im, p.strength, p.detail / 100));

  // ---------- Render ----------
  def('clouds', 'Хмари', 'Рендеринг', [col('c1', 'Колір 1', '#000000'), col('c2', 'Колір 2', '#FFFFFF'), num('scale', 'Масштаб', 4, 400, 90, { px: true }), num('seed', 'Варіант', 1, 999, 1)], (im, p) => {
    const N = vnoise(p.seed, Math.max(2, p.scale)), a = hex(p.c1), b = hex(p.c2), w = im.width;
    return perPixel(im, (d, i) => { const j = i >> 2, v = N(j % w, (j / w) | 0); d[i] = a[0] + (b[0] - a[0]) * v; d[i + 1] = a[1] + (b[1] - a[1]) * v; d[i + 2] = a[2] + (b[2] - a[2]) * v; d[i + 3] = 255; });
  });
  def('diffClouds', 'Різницеві хмари', 'Рендеринг', [num('scale', 'Масштаб', 4, 400, 90, { px: true }), num('seed', 'Варіант', 1, 999, 3)], (im, p) => {
    const N = vnoise(p.seed, Math.max(2, p.scale)), w = im.width;
    return perPixel(im, (d, i) => { const j = i >> 2, v = N(j % w, (j / w) | 0) * 255; d[i] = Math.abs(d[i] - v); d[i + 1] = Math.abs(d[i + 1] - v); d[i + 2] = Math.abs(d[i + 2] - v); });
  });
  def('fibers', 'Волокна…', 'Рендеринг', [num('variance', 'Різноманітність', 1, 64, 16), num('strength', 'Сила', 1, 64, 4), col('c1', 'Колір 1', '#3B2A1A'), col('c2', 'Колір 2', '#E8D2A8'), num('seed', 'Варіант', 1, 999, 5)], (im, p) => {
    const { width: w, height: h } = im, R = rng(p.seed), out = copy(im), d = out.data, a = hex(p.c1), b = hex(p.c2);
    const cols = new Float32Array(w);
    for (let x = 0; x < w; x++) cols[x] = R();
    for (let pass = 0; pass < 3; pass++) for (let x = 1; x < w - 1; x++) cols[x] = (cols[x - 1] + cols[x] * 2 + cols[x + 1]) / 4;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const streak = Math.sin((y / Math.max(1, 64 / p.strength)) + cols[x] * p.variance) * 0.5 + 0.5;
      const v = O.clamp(cols[x] * 0.7 + streak * 0.3, 0, 1), o = (y * w + x) * 4;
      d[o] = a[0] + (b[0] - a[0]) * v; d[o + 1] = a[1] + (b[1] - a[1]) * v; d[o + 2] = a[2] + (b[2] - a[2]) * v; d[o + 3] = 255;
    }
    return out;
  });
  def('flare', 'Відблиск об’єктива…', 'Рендеринг', [num('x', 'Центр X', 0, 100, 30, { u: '%' }), num('y', 'Центр Y', 0, 100, 28, { u: '%' }), num('bright', 'Яскравість', 10, 300, 100, { u: '%' }), sel('lens', 'Об’єктив', [['zoom', '50–300 мм'], ['prime', '35 мм'], ['movie', 'Кіно']], 'zoom')], (im, p) => {
    const { width: w, height: h } = im, cx = w * p.x / 100, cy = h * p.y / 100, k = p.bright / 100, R0 = Math.hypot(w, h);
    const rings = p.lens === 'movie' ? [] : [[0.35, 0.03, [120, 255, 160]], [0.55, 0.06, [255, 170, 90]], [0.8, 0.02, [140, 160, 255]], [1.2, 0.08, [255, 120, 200]]];
    return perPixel(im, (d, i) => {
      const j = i >> 2, x = j % w, y = (j / w) | 0, dist = Math.hypot(x - cx, y - cy) / R0;
      let add = Math.exp(-dist * 22) * 255 * k + Math.exp(-dist * 6) * 70 * k;
      let r = add, g = add * 0.95, b = add * 0.85;
      if (p.lens === 'movie') { const dy = Math.abs(y - cy) / R0; const st = Math.exp(-dy * 260) * Math.exp(-Math.abs(x - cx) / R0 * 1.4) * 200 * k; r += st * 0.5; g += st * 0.7; b += st; }
      for (const [pos, size, c] of rings) { const rx = cx + (w / 2 - cx) * pos * 2, ry = cy + (h / 2 - cy) * pos * 2; const dd = Math.hypot(x - rx, y - ry) / R0; const v = Math.max(0, 1 - Math.abs(dd - size) / (size * 0.35 + 0.004)) * 0.35 * k; r += c[0] * v; g += c[1] * v; b += c[2] * v; }
      d[i] = cl(d[i] + r); d[i + 1] = cl(d[i + 1] + g); d[i + 2] = cl(d[i + 2] + b);
    });
  });
  def('lighting', 'Ефекти освітлення…', 'Рендеринг', [sel('type', 'Тип світла', [['spot', 'Прожектор'], ['omni', 'Точкове'], ['dir', 'Спрямоване']], 'spot'), num('x', 'Світло X', 0, 100, 35, { u: '%' }), num('y', 'Світло Y', 0, 100, 30, { u: '%' }), num('radius', 'Радіус', 5, 150, 60, { u: '%' }), num('intensity', 'Інтенсивність', 0, 200, 90, { u: '%' }), num('ambient', 'Навколишнє світло', 0, 100, 25, { u: '%' }), col('color', 'Колір світла', '#FFF4DC'), num('relief', 'Рельєф', 0, 100, 0, { u: '%' })], (im, p) => {
    const { width: w, height: h } = im, cx = w * p.x / 100, cy = h * p.y / 100, R0 = Math.max(w, h) * p.radius / 100, lc = hex(p.color), L = p.relief ? lumMap(im) : null;
    return perPixel(im, (d, i) => {
      const j = i >> 2, x = j % w, y = (j / w) | 0;
      let f = p.type === 'dir' ? O.clamp(1 - ((x - cx) * 0.3 + (y - cy)) / (h * 1.2), 0, 1.4) : Math.max(0, 1 - (Math.hypot(x - cx, (y - cy) * (p.type === 'spot' ? 1.35 : 1)) / R0) ** 2);
      if (L) { const gx = (L[j + (x < w - 1 ? 1 : 0)] - L[j - (x > 0 ? 1 : 0)]), gy = (L[j + (y < h - 1 ? w : 0)] - L[j - (y > 0 ? w : 0)]); f += (-(gx * (x - cx) + gy * (y - cy)) / (Math.hypot(x - cx, y - cy) + 1)) * p.relief / 100 / 40; }
      const k = p.ambient / 100 + f * p.intensity / 100;
      d[i] = cl(d[i] * k * lc[0] / 255); d[i + 1] = cl(d[i + 1] * k * lc[1] / 255); d[i + 2] = cl(d[i + 2] * k * lc[2] / 255);
    });
  });

  // ---------- Sharpen ----------
  def('sharpen', 'Різкість', 'Різкість', [], im => unsharp(im, 0.6, 0.8));
  def('sharpenMore', 'Посилена різкість', 'Різкість', [], im => unsharp(im, 1.4, 0.8));
  def('sharpenEdges', 'Різкість країв', 'Різкість', [], im => unsharp(im, 1, 1, 12));
  def('unsharp', 'Контурна різкість…', 'Різкість', [num('amount', 'Ефект', 1, 500, 100, { u: '%' }), num('radius', 'Радіус', 0.1, 50, 1.5, { step: 0.1, u: 'px', px: true }), num('thr', 'Поріг', 0, 255, 0)], (im, p) => unsharp(im, p.amount / 100, p.radius, p.thr));
  def('smartSharpen', '«Розумна» різкість…', 'Різкість', [num('amount', 'Ефект', 1, 500, 150, { u: '%' }), num('radius', 'Радіус', 0.1, 20, 1, { step: 0.1, u: 'px', px: true }), num('noise', 'Зменшити шум', 0, 100, 10, { u: '%' })], (im, p) => smartSharp(im, p.amount / 100, p.radius, p.noise / 100));

  // ---------- Stylize ----------
  def('emboss', 'Тиснення…', 'Стилізація', [num('angle', 'Кут', -180, 180, 135, { u: '°' }), num('height', 'Висота', 1, 10, 3, { u: 'px', px: true }), num('amount', 'Ефект', 1, 500, 100, { u: '%' }), chk('color', 'Зберегти колір', false)], (im, p) => {
    const { width: w, height: h } = im, L = lumMap(im), a = p.angle * Math.PI / 180, dx = Math.cos(a) * p.height, dy = -Math.sin(a) * p.height, k = p.amount / 100;
    const at = (x, y) => L[Math.min(h - 1, Math.max(0, Math.round(y))) * w + Math.min(w - 1, Math.max(0, Math.round(x)))];
    return perPixel(im, (d, i) => {
      const j = i >> 2, x = j % w, y = (j / w) | 0, v = (at(x + dx, y + dy) - at(x - dx, y - dy)) * k;
      if (p.color) { d[i] = cl(d[i] + v); d[i + 1] = cl(d[i + 1] + v); d[i + 2] = cl(d[i + 2] + v); } else gray(d, i, cl(128 + v));
    });
  });
  def('findEdges', 'Виділення країв', 'Стилізація', [], im => {
    const { width: w, height: h, data: s } = im, out = copy(im), d = out.data;
    const at = (x, y, c) => s[(Math.min(h - 1, Math.max(0, y)) * w + Math.min(w - 1, Math.max(0, x))) * 4 + c];
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) for (let c = 0; c < 3; c++) {
      const gx = at(x + 1, y, c) - at(x - 1, y, c), gy = at(x, y + 1, c) - at(x, y - 1, c);
      d[(y * w + x) * 4 + c] = 255 - Math.min(255, Math.hypot(gx, gy) * 1.4);
    }
    return out;
  });
  def('glowEdges', 'Неонове світіння країв…', 'Стилізація', [num('width', 'Ширина країв', 1, 14, 2, { px: true }), num('bright', 'Яскравість', 0, 20, 8), num('smooth', 'Пом’якшення', 1, 15, 5)], (im, p) => {
    const sm = gauss(im, p.smooth / 3), M = sobel(sm), { width: w } = im;
    let e = perPixel(im, (d, i) => { const v = Math.min(255, M[i >> 2] * (p.bright / 4 + 0.5)); const k = v / 255; d[i] = d[i] * k; d[i + 1] = d[i + 1] * k; d[i + 2] = d[i + 2] * k; });
    if (p.width > 1) e = morph(e, p.width / 2, true);
    void w; return e;
  });
  def('solarize', 'Соляризація', 'Стилізація', [], im => perPixel(im, (d, i) => { for (let c = 0; c < 3; c++) if (d[i + c] > 127) d[i + c] = 255 - d[i + c]; }));
  def('traceContour', 'Трасування контуру…', 'Стилізація', [num('level', 'Рівень', 0, 255, 128), sel('edge', 'Край', [['lower', 'Нижній'], ['upper', 'Верхній']], 'upper')], (im, p) => {
    const { width: w, height: h } = im, L = lumMap(im), out = copy(im), d = out.data;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const j = y * w + x, a = L[j] >= p.level, r = x < w - 1 ? L[j + 1] >= p.level : a, b = y < h - 1 ? L[j + w] >= p.level : a;
      const edge = (a !== r || a !== b) && (p.edge === 'upper' ? a : !a);
      const o = j * 4; if (edge) gray(d, o, 0); else gray(d, o, 255);
    }
    return out;
  });
  def('wind', 'Вітер…', 'Стилізація', [sel('method', 'Метод', [['wind', 'Вітер'], ['blast', 'Ураган'], ['stagger', 'Хвилясто']], 'wind'), sel('dir', 'Напрямок', [['right', 'Праворуч'], ['left', 'Ліворуч']], 'right'), num('seed', 'Варіант', 1, 999, 2)], (im, p) => {
    const { width: w, height: h, data: s } = im, out = copy(im), d = out.data, R = rng(p.seed), L = lumMap(im);
    const maxLen = (p.method === 'blast' ? 0.12 : 0.05) * w, step = p.dir === 'right' ? 1 : -1;
    for (let y = 0; y < h; y++) {
      const off = p.method === 'stagger' ? Math.round(Math.sin(y / 7) * 3) : 0;
      for (let k = 0; k < w; k++) {
        const x = step > 0 ? k : w - 1 - k, j = y * w + x;
        if (L[j] < 140 || R() > 0.35) continue;
        const len = Math.round(R() * maxLen);
        for (let q = 1; q <= len; q++) {
          const xx = x + step * q + off; if (xx < 0 || xx >= w) break;
          const f = 1 - q / (len + 1), o = (y * w + xx) * 4, si = j * 4;
          for (let c = 0; c < 3; c++) d[o + c] = Math.max(d[o + c], s[si + c] * f + d[o + c] * (1 - f));
        }
      }
    }
    return out;
  });
  def('diffuse', 'Дифузія…', 'Стилізація', [sel('mode', 'Режим', [['normal', 'Звичайний'], ['dark', 'Лише темніші'], ['light', 'Лише світліші']], 'normal'), num('seed', 'Варіант', 1, 999, 4)], (im, p) => {
    const { width: w, height: h, data: s } = im, out = copy(im), d = out.data, R = rng(p.seed);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const xx = Math.min(w - 1, Math.max(0, x + Math.round(R() * 4 - 2))), yy = Math.min(h - 1, Math.max(0, y + Math.round(R() * 4 - 2)));
      const o = (y * w + x) * 4, q = (yy * w + xx) * 4;
      const ok = p.mode === 'normal' || (p.mode === 'dark' ? lum(s, q) < lum(s, o) : lum(s, q) > lum(s, o));
      if (ok) for (let c = 0; c < 4; c++) d[o + c] = s[q + c];
    }
    return out;
  });
  def('oil', 'Олійна фарба…', 'Стилізація', [num('style', 'Стилізація', 1, 12, 4, { px: true }), num('clean', 'Чистота', 0, 10, 4), num('shine', 'Блиск', 0, 10, 2)], (im, p) => {
    let k = kuwahara(im, p.style);
    if (p.clean) k = kuwahara(k, Math.max(1, p.style / 2 * p.clean / 10));
    if (p.shine) { const L = lumMap(gauss(k, 1.2)), { width: w, height: h } = k; k = perPixel(k, (d, i) => { const j = i >> 2, x = j % w, y = (j / w) | 0; const v = ((L[j - (x > 0 ? 1 : 0)] - L[j]) + (L[j - (y > 0 ? w : 0)] - L[j])) * p.shine * 0.6; d[i] = cl(d[i] + v); d[i + 1] = cl(d[i + 1] + v); d[i + 2] = cl(d[i + 2] + v); }); void h; }
    return k;
  });
  def('tiles', 'Плитки…', 'Стилізація', [num('count', 'Плиток у рядку', 2, 99, 10), num('offset', 'Максимальний зсув', 1, 99, 10, { u: '%' }), sel('fill', 'Проміжки', [['bg', 'Білим'], ['inverse', 'Інверсія зображення'], ['orig', 'Зображенням']], 'bg'), num('seed', 'Варіант', 1, 999, 6)], (im, p) => {
    const { width: w, height: h, data: s } = im, R = rng(p.seed), size = w / p.count, out = blank(w, h), d = out.data;
    for (let i = 0; i < d.length; i += 4) { if (p.fill === 'bg') { d[i] = d[i + 1] = d[i + 2] = d[i + 3] = 255; } else if (p.fill === 'inverse') { d[i] = 255 - s[i]; d[i + 1] = 255 - s[i + 1]; d[i + 2] = 255 - s[i + 2]; d[i + 3] = s[i + 3]; } else for (let c = 0; c < 4; c++) d[i + c] = s[i + c]; }
    for (let ty = 0; ty < h; ty += size) for (let tx = 0; tx < w; tx += size) {
      const ox = Math.round((R() * 2 - 1) * size * p.offset / 100), oy = Math.round((R() * 2 - 1) * size * p.offset / 100);
      for (let y = Math.floor(ty); y < Math.min(h, ty + size); y++) for (let x = Math.floor(tx); x < Math.min(w, tx + size); x++) {
        const X = x + ox, Y = y + oy; if (X < 0 || Y < 0 || X >= w || Y >= h) continue;
        const o = (Y * w + X) * 4, q = (y * w + x) * 4; for (let c = 0; c < 4; c++) d[o + c] = s[q + c];
      }
    }
    return out;
  });
  def('extrude', 'Видавлювання…', 'Стилізація', [num('size', 'Розмір', 2, 255, 24, { px: true }), num('depth', 'Глибина', 1, 255, 30), num('seed', 'Варіант', 1, 999, 8)], (im, p) => {
    const { width: w, height: h, data: s } = im, out = copy(im), d = out.data, R = rng(p.seed), sz = Math.max(2, Math.round(p.size));
    const blocks = [];
    for (let y = 0; y < h; y += sz) for (let x = 0; x < w; x += sz) blocks.push([x, y, R()]);
    blocks.sort((a, b) => a[2] - b[2]);
    for (const [bx, by, z] of blocks) {
      let r = 0, g = 0, b = 0, n = 0;
      for (let y = by; y < Math.min(h, by + sz); y++) for (let x = bx; x < Math.min(w, bx + sz); x++) { const q = (y * w + x) * 4; r += s[q]; g += s[q + 1]; b += s[q + 2]; n++; }
      r /= n; g /= n; b /= n;
      const lift = Math.round(z * p.depth / 255 * sz * 0.6);
      for (let y = by - lift; y < Math.min(h, by + sz - lift); y++) for (let x = bx - lift; x < Math.min(w, bx + sz - lift); x++) {
        if (x < 0 || y < 0) continue;
        const o = (y * w + x) * 4, edge = (x - (bx - lift) < 2 || y - (by - lift) < 2) ? 1.25 : (bx + sz - lift - x <= 2 || by + sz - lift - y <= 2) ? 0.7 : 1;
        d[o] = cl(r * edge); d[o + 1] = cl(g * edge); d[o + 2] = cl(b * edge); d[o + 3] = 255;
      }
    }
    return out;
  });

  // ---------- Pixelate ----------
  def('mosaic', 'Мозаїка…', 'Оформлення', [num('cell', 'Розмір клітинки', 2, 200, 14, { u: 'px', px: true })], (im, p) => {
    const { width: w, height: h, data: s } = im, out = copy(im), d = out.data, c = Math.max(1, Math.round(p.cell));
    for (let by = 0; by < h; by += c) for (let bx = 0; bx < w; bx += c) {
      const acc = [0, 0, 0, 0]; let n = 0;
      for (let y = by; y < Math.min(h, by + c); y++) for (let x = bx; x < Math.min(w, bx + c); x++) { const q = (y * w + x) * 4; for (let k = 0; k < 4; k++) acc[k] += s[q + k]; n++; }
      for (let y = by; y < Math.min(h, by + c); y++) for (let x = bx; x < Math.min(w, bx + c); x++) { const q = (y * w + x) * 4; for (let k = 0; k < 4; k++) d[q + k] = acc[k] / n; }
    }
    return out;
  });
  // Voronoi cells on a jittered grid
  const cells = (w, h, size, seed) => {
    const R = rng(seed), gw = Math.ceil(w / size) + 1, gh = Math.ceil(h / size) + 1, pts = new Float32Array(gw * gh * 2);
    for (let j = 0; j < gh; j++) for (let i = 0; i < gw; i++) { const k = (j * gw + i) * 2; pts[k] = (i + R()) * size; pts[k + 1] = (j + R()) * size; }
    const nearest = (x, y) => { const ci = Math.floor(x / size), cj = Math.floor(y / size); let best = Infinity, bk = 0; for (let j = cj - 1; j <= cj + 1; j++) for (let i = ci - 1; i <= ci + 1; i++) { if (i < 0 || j < 0 || i >= gw || j >= gh) continue; const k = (j * gw + i) * 2, dd = (pts[k] - x) ** 2 + (pts[k + 1] - y) ** 2; if (dd < best) { best = dd; bk = k; } } return bk; };
    return { pts, nearest };
  };
  def('crystallize', 'Кристалізація…', 'Оформлення', [num('cell', 'Розмір клітинки', 3, 300, 18, { u: 'px', px: true }), num('seed', 'Варіант', 1, 999, 9)], (im, p) => {
    const { width: w, height: h, data: s } = im, { pts, nearest } = cells(w, h, Math.max(2, p.cell), p.seed), out = copy(im), d = out.data;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const k = nearest(x, y); const sx = Math.min(w - 1, Math.max(0, Math.round(pts[k]))), sy = Math.min(h - 1, Math.max(0, Math.round(pts[k + 1]))); const q = (sy * w + sx) * 4, o = (y * w + x) * 4; for (let c = 0; c < 4; c++) d[o + c] = s[q + c]; }
    return out;
  });
  def('pointillize', 'Пуантилізм…', 'Оформлення', [num('cell', 'Розмір клітинки', 3, 300, 10, { u: 'px', px: true }), col('bg', 'Тло', '#FFFFFF'), num('seed', 'Варіант', 1, 999, 10)], (im, p) => {
    const { width: w, height: h, data: s } = im, size = Math.max(2, p.cell), { pts, nearest } = cells(w, h, size, p.seed), out = copy(im), d = out.data, bg = hex(p.bg), r = size * 0.48;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const k = nearest(x, y), o = (y * w + x) * 4, dist = Math.hypot(pts[k] - x, pts[k + 1] - y);
      if (dist > r) { d[o] = bg[0]; d[o + 1] = bg[1]; d[o + 2] = bg[2]; d[o + 3] = 255; continue; }
      const sx = Math.min(w - 1, Math.max(0, Math.round(pts[k]))), sy = Math.min(h - 1, Math.max(0, Math.round(pts[k + 1]))), q = (sy * w + sx) * 4;
      d[o] = s[q]; d[o + 1] = s[q + 1]; d[o + 2] = s[q + 2]; d[o + 3] = 255;
    }
    return out;
  });
  def('halftone', 'Кольоровий півтон…', 'Оформлення', [num('radius', 'Макс. радіус', 2, 60, 6, { u: 'px', px: true }), num('a1', 'Кут каналу 1', -360, 360, 108, { u: '°' }), num('a2', 'Кут каналу 2', -360, 360, 162, { u: '°' }), num('a3', 'Кут каналу 3', -360, 360, 90, { u: '°' })], (im, p) => {
    const { width: w, height: h, data: s } = im, out = copy(im), d = out.data, cell = Math.max(2, p.radius * 2), ang = [p.a1, p.a2, p.a3].map(a => a * Math.PI / 180);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const o = (y * w + x) * 4;
      for (let c = 0; c < 3; c++) {
        const ca = Math.cos(ang[c]), sa = Math.sin(ang[c]);
        const u = x * ca + y * sa, v = -x * sa + y * ca;
        const cu = (Math.floor(u / cell) + 0.5) * cell, cv = (Math.floor(v / cell) + 0.5) * cell;
        const sx = Math.min(w - 1, Math.max(0, Math.round(cu * ca - cv * sa))), sy = Math.min(h - 1, Math.max(0, Math.round(cu * sa + cv * ca)));
        const ink = 1 - s[(sy * w + sx) * 4 + c] / 255, rr = Math.sqrt(ink) * cell * 0.62;
        d[o + c] = Math.hypot(u - cu, v - cv) < rr ? 0 : 255;
      }
    }
    return out;
  });
  def('mezzotint', 'Меццо-тинто…', 'Оформлення', [sel('type', 'Тип', [['fine', 'Дрібні точки'], ['coarse', 'Великі точки'], ['lines', 'Короткі лінії'], ['strokes', 'Довгі штрихи']], 'fine'), num('seed', 'Варіант', 1, 999, 11)], (im, p) => {
    const { width: w, height: h } = im, R = rng(p.seed), thr = new Float32Array(w * h);
    if (p.type === 'fine') for (let i = 0; i < thr.length; i++) thr[i] = R() * 255;
    else if (p.type === 'coarse') { for (let y = 0; y < h; y += 3) for (let x = 0; x < w; x += 3) { const v = R() * 255; for (let j = 0; j < 3 && y + j < h; j++) for (let i = 0; i < 3 && x + i < w; i++) thr[(y + j) * w + x + i] = v; } }
    else { const len = p.type === 'lines' ? 6 : 18; for (let y = 0; y < h; y++) for (let x = 0; x < w; x += len) { const v = R() * 255; for (let i = 0; i < len && x + i < w; i++) thr[y * w + x + i] = v; } }
    return perPixel(im, (d, i) => { const tv = thr[i >> 2]; for (let c = 0; c < 3; c++) d[i + c] = d[i + c] > tv ? 255 : 0; });
  });
  def('facet', 'Фасет', 'Оформлення', [], im => kuwahara(kuwahara(im, 2), 2));
  def('fragment', 'Фрагмент', 'Оформлення', [], im => {
    const { width: w, height: h, data: s } = im, out = copy(im), d = out.data, off = [[-4, -4], [4, -4], [-4, 4], [4, 4]];
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const o = (y * w + x) * 4; for (let c = 0; c < 4; c++) { let v = 0; for (const [ox, oy] of off) v += s[(Math.min(h - 1, Math.max(0, y + oy)) * w + Math.min(w - 1, Math.max(0, x + ox))) * 4 + c]; d[o + c] = v / 4; } }
    return out;
  });

  // ---------- Distort ----------
  const center = im => [im.width / 2, im.height / 2, Math.min(im.width, im.height) / 2];
  def('twirl', 'Скручування…', 'Спотворення', [num('angle', 'Кут', -999, 999, 200, { u: '°' })], (im, p) => { const [cx, cy, R] = center(im), A = p.angle * Math.PI / 180; return warp(im, (x, y, o) => { const dx = x - cx, dy = y - cy, r = Math.hypot(dx, dy); if (r >= R) { o[0] = x; o[1] = y; return; } const a = Math.atan2(dy, dx) + A * (1 - r / R) ** 2; o[0] = cx + r * Math.cos(a); o[1] = cy + r * Math.sin(a); }); });
  // positive: the middle is squeezed inwards; negative: it bulges out
  def('pinch', 'Щипок…', 'Спотворення', [num('amount', 'Ефект', -100, 100, 50, { u: '%' })], (im, p) => { const [cx, cy, R] = center(im), k = p.amount / 100; return warp(im, (x, y, o) => { const dx = x - cx, dy = y - cy, r = Math.hypot(dx, dy) / R; if (r >= 1 || !r) { o[0] = x; o[1] = y; return; } const rr = Math.pow(r, 1 - k * 0.6) / r; o[0] = cx + dx * rr; o[1] = cy + dy * rr; }); });
  def('spherize', 'Сферизація…', 'Спотворення', [num('amount', 'Ефект', -100, 100, 100, { u: '%' }), sel('mode', 'Режим', [['normal', 'Звичайний'], ['h', 'Лише по горизонталі'], ['v', 'Лише по вертикалі']], 'normal')], (im, p) => {
    const [cx, cy] = center(im), rx = im.width / 2, ry = im.height / 2, k = p.amount / 100;
    return warp(im, (x, y, o) => {
      let nx = (x - cx) / rx, ny = (y - cy) / ry; if (p.mode === 'h') ny = 0; if (p.mode === 'v') nx = 0;
      const r = Math.hypot(nx, ny); if (r >= 1 || !r) { o[0] = x; o[1] = y; return; }
      const sph = Math.asin(r) / (Math.PI / 2) / r, f = k >= 0 ? 1 + (sph - 1) * k : 1 + (1 / sph - 1) * -k;
      o[0] = p.mode === 'v' ? x : cx + (x - cx) * f; o[1] = p.mode === 'h' ? y : cy + (y - cy) * f;
    });
  });
  def('ripple', 'Брижі…', 'Спотворення', [num('amount', 'Сила', -999, 999, 100, { u: '%' }), sel('size', 'Розмір', [['small', 'Дрібні'], ['medium', 'Середні'], ['large', 'Крупні']], 'medium')], (im, p) => { const len = { small: 8, medium: 18, large: 36 }[p.size] * Math.max(1, im.width / 1200), a = p.amount / 100 * len * 0.35; return warp(im, (x, y, o) => { o[0] = x + Math.sin(y / len * Math.PI * 2) * a; o[1] = y + Math.sin(x / len * Math.PI * 2) * a; }); });
  def('wave', 'Хвиля…', 'Спотворення', [num('wl', 'Довжина хвилі', 2, 999, 120, { px: true }), num('amp', 'Амплітуда', 1, 999, 18, { px: true }), sel('type', 'Тип', [['sine', 'Синусоїда'], ['tri', 'Трикутник'], ['square', 'Прямокутник']], 'sine'), sel('undef', 'Краї', [['wrap', 'Обгорнути'], ['repeat', 'Повторити крайові пікселі']], 'repeat')], (im, p) => {
    const f = v => p.type === 'sine' ? Math.sin(v) : p.type === 'tri' ? 2 / Math.PI * Math.asin(Math.sin(v)) : Math.sign(Math.sin(v));
    const { width: w, height: h } = im;
    return warp(im, (x, y, o) => { let X = x + f(y / p.wl * Math.PI * 2) * p.amp, Y = y + f(x / p.wl * Math.PI * 2 + 1.3) * p.amp * 0.6; if (p.undef === 'wrap') { X = ((X % w) + w) % w; Y = ((Y % h) + h) % h; } o[0] = X; o[1] = Y; });
  });
  def('zigzag', 'Зигзаг…', 'Спотворення', [num('amount', 'Сила', -100, 100, 30), num('ridges', 'Гребені', 1, 20, 6), sel('style', 'Стиль', [['pond', 'Брижі на воді'], ['out', 'Від центру'], ['around', 'Навколо центру']], 'pond')], (im, p) => {
    const [cx, cy, R] = center(im);
    return warp(im, (x, y, o) => { const dx = x - cx, dy = y - cy, r = Math.hypot(dx, dy); if (r >= R || !r) { o[0] = x; o[1] = y; return; } const wv = Math.sin(r / R * p.ridges * Math.PI * 2) * p.amount / 100 * R * 0.06 * (1 - r / R); if (p.style === 'around') { const a = Math.atan2(dy, dx) + wv / R * 4; o[0] = cx + r * Math.cos(a); o[1] = cy + r * Math.sin(a); } else { const f = (r + wv * (p.style === 'out' ? 1.5 : 1)) / r; o[0] = cx + dx * f; o[1] = cy + dy * f; } });
  });
  def('polar', 'Полярні координати…', 'Спотворення', [sel('mode', 'Перетворення', [['r2p', 'Прямокутні → полярні'], ['p2r', 'Полярні → прямокутні']], 'r2p')], (im, p) => {
    const { width: w, height: h } = im, cx = w / 2, cy = h / 2, R = Math.min(w, h) / 2;
    return warp(im, (x, y, o) => {
      if (p.mode === 'r2p') { const dx = x - cx, dy = y - cy, r = Math.hypot(dx, dy) / R, a = (Math.atan2(dx, -dy) + Math.PI) / (Math.PI * 2); o[0] = a * w; o[1] = r * h; }
      else { const a = x / w * Math.PI * 2 - Math.PI, r = y / h * R; o[0] = cx + Math.sin(a) * r; o[1] = cy - Math.cos(a) * r; }
    });
  });
  def('shear', 'Деформація по кривій…', 'Спотворення', [num('amount', 'Вигин', -100, 100, 40, { u: '%' }), sel('undef', 'Краї', [['wrap', 'Обгорнути'], ['repeat', 'Повторити крайові пікселі']], 'wrap')], (im, p) => { const { width: w, height: h } = im; return warp(im, (x, y, o) => { let X = x + Math.sin(y / h * Math.PI) * p.amount / 100 * w * 0.25; if (p.undef === 'wrap') X = ((X % w) + w) % w; o[0] = X; o[1] = y; }); });
  def('glassDistort', 'Скло…', 'Спотворення', [num('dist', 'Сила спотворення', 0, 20, 5, { px: true }), num('smooth', 'Пом’якшення', 1, 15, 3), sel('tex', 'Текстура', [['frost', 'Матове'], ['blocks', 'Блоки'], ['tiny', 'Дрібна лінза']], 'frost'), num('seed', 'Варіант', 1, 999, 12)], (im, p) => {
    const { width: w } = im, N = vnoise(p.seed, p.tex === 'tiny' ? 4 : 10 + p.smooth * 2), N2 = vnoise(p.seed + 1, p.tex === 'tiny' ? 4 : 10 + p.smooth * 2);
    return warp(im, (x, y, o) => { let a = N(x, y) - 0.5, b = N2(x, y) - 0.5; if (p.tex === 'blocks') { const bx = Math.floor(x / 14), by = Math.floor(y / 14); a = N(bx * 37, by * 37) - 0.5; b = N2(bx * 37, by * 37) - 0.5; } o[0] = x + a * p.dist * 6; o[1] = y + b * p.dist * 6; });
    void w;
  });
  def('ocean', 'Океанські брижі…', 'Спотворення', [num('size', 'Розмір брижів', 1, 15, 8), num('mag', 'Сила', 0, 20, 8, { px: true }), num('seed', 'Варіант', 1, 999, 13)], (im, p) => { const N = vnoise(p.seed, p.size * 2 + 2), N2 = vnoise(p.seed + 7, p.size * 2 + 2); return warp(im, (x, y, o) => { o[0] = x + (N(x, y) - 0.5) * p.mag * 4; o[1] = y + (N2(x, y) - 0.5) * p.mag * 4; }); });

  // ---------- Video ----------
  def('deinterlace', 'Видалення черезрядковості…', 'Відео', [sel('field', 'Прибрати', [['odd', 'Непарні рядки'], ['even', 'Парні рядки']], 'odd'), sel('how', 'Заповнити', [['dup', 'Дублюванням'], ['interp', 'Інтерполяцією']], 'interp')], (im, p) => {
    const { width: w, height: h, data: s } = im, out = copy(im), d = out.data, start = p.field === 'odd' ? 1 : 0;
    for (let y = start; y < h; y += 2) for (let x = 0; x < w; x++) { const o = (y * w + x) * 4, a = (Math.max(0, y - 1) * w + x) * 4, b = (Math.min(h - 1, y + 1) * w + x) * 4; for (let c = 0; c < 4; c++) d[o + c] = p.how === 'dup' ? s[a + c] : (s[a + c] + s[b + c]) / 2; }
    return out;
  });
  def('ntsc', 'Кольори NTSC', 'Відео', [], im => perPixel(im, (d, i) => { const y = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; const sat = Math.max(d[i], d[i + 1], d[i + 2]) - Math.min(d[i], d[i + 1], d[i + 2]); const k = sat > 190 ? 190 / sat : 1; for (let c = 0; c < 3; c++) d[i + c] = cl(y + (d[i + c] - y) * k); d[i] = Math.min(d[i], 235); d[i + 1] = Math.min(d[i + 1], 235); d[i + 2] = Math.min(d[i + 2], 235); }));

  // ---------- Blur Gallery ----------
  def('fieldBlur', 'Розмиття поля…', 'Галерея розмиття', [num('blur', 'Розмиття', 0, 200, 15, { u: 'px', px: true }), num('from', 'Різке місце Y', 0, 100, 70, { u: '%' }), num('to', 'Розмите місце Y', 0, 100, 0, { u: '%' })], (im, p) => {
    const b = gauss(im, p.blur), { width: w, height: h } = im, m = new Float32Array(w * h), a = p.from / 100 * h, z = p.to / 100 * h;
    for (let y = 0; y < h; y++) { const k = a === z ? 1 : O.clamp((y - a) / (z - a), 0, 1); for (let x = 0; x < w; x++) m[y * w + x] = k; }
    return mixMask(im, b, m);
  });
  def('irisBlur', 'Розмиття діафрагми…', 'Галерея розмиття', [num('blur', 'Розмиття', 0, 200, 18, { u: 'px', px: true }), num('x', 'Центр X', 0, 100, 50, { u: '%' }), num('y', 'Центр Y', 0, 100, 50, { u: '%' }), num('rx', 'Ширина еліпса', 5, 100, 35, { u: '%' }), num('ry', 'Висота еліпса', 5, 100, 35, { u: '%' }), num('feather', 'Плавний перехід', 1, 100, 40, { u: '%' })], (im, p) => {
    const b = gauss(im, p.blur), { width: w, height: h } = im, m = new Float32Array(w * h), cx = w * p.x / 100, cy = h * p.y / 100, rx = w * p.rx / 100, ry = h * p.ry / 100, f = p.feather / 100;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const r = Math.hypot((x - cx) / rx, (y - cy) / ry); m[y * w + x] = O.clamp((r - (1 - f)) / f, 0, 1); }
    return mixMask(im, b, m);
  });
  def('tiltShift', 'Нахил-зсув…', 'Галерея розмиття', [num('blur', 'Розмиття', 0, 200, 16, { u: 'px', px: true }), num('y', 'Центр різкості', 0, 100, 55, { u: '%' }), num('band', 'Різка смуга', 0, 100, 18, { u: '%' }), num('trans', 'Перехід', 1, 100, 22, { u: '%' }), num('angle', 'Кут', -90, 90, 0, { u: '°' }), num('sat', 'Насиченість', 0, 100, 25, { u: '%' })], (im, p) => {
    let b = gauss(im, p.blur); const { width: w, height: h } = im, m = new Float32Array(w * h), a = p.angle * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a), cy = h * p.y / 100, band = h * p.band / 200, tr = Math.max(1, h * p.trans / 100);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const dist = Math.abs(-(x - w / 2) * sa + (y - cy) * ca); m[y * w + x] = O.clamp((dist - band) / tr, 0, 1); }
    let out = mixMask(im, b, m);
    if (p.sat) out = perPixel(out, (d, i) => { const y = lum(d, i), k = 1 + p.sat / 100; for (let c = 0; c < 3; c++) d[i + c] = cl(y + (d[i + c] - y) * k); });
    b = null; return out;
  });
  def('pathBlur', 'Розмиття контуру…', 'Галерея розмиття', [num('angle', 'Напрямок', -180, 180, 20, { u: '°' }), num('dist', 'Швидкість', 1, 400, 40, { u: 'px', px: true }), num('taper', 'Звуження', 0, 100, 30, { u: '%' })], (im, p) => motion(im, p.angle, p.dist, p.taper / 100, true));
  def('spinBlur', 'Розмиття обертанням…', 'Галерея розмиття', [num('angle', 'Кут розмиття', 1, 360, 15, { u: '°' }), num('x', 'Центр X', 0, 100, 50, { u: '%' }), num('y', 'Центр Y', 0, 100, 50, { u: '%' }), num('r', 'Радіус', 5, 150, 45, { u: '%' })], (im, p) => {
    const { width: w, height: h } = im, cx = w * p.x / 100, cy = h * p.y / 100, R = Math.min(w, h) * p.r / 100, A = p.angle * Math.PI / 180, out = blank(w, h), d = out.data, smp = sampler(im), tmp = [0, 0, 0, 0], n = Math.max(4, Math.min(48, Math.ceil(A * 12)));
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const dx = x - cx, dy = y - cy, r = Math.hypot(dx, dy), o = (y * w + x) * 4, k = O.clamp(1 - (r - R) / (R * 0.25), 0, 1), a0 = Math.atan2(dy, dx);
      let sr = 0, sg = 0, sb = 0, sa = 0;
      for (let i = 0; i < n; i++) { const a = a0 + (i / (n - 1) - 0.5) * A * k; smp(cx + r * Math.cos(a), cy + r * Math.sin(a), tmp, 0); sr += tmp[0]; sg += tmp[1]; sb += tmp[2]; sa += tmp[3]; }
      d[o] = sr / n; d[o + 1] = sg / n; d[o + 2] = sb / n; d[o + 3] = sa / n;
    }
    return out;
  });

  // ---------- Blur ----------
  const motion = (im, angle, dist, taper = 0, path = false) => {
    const { width: w, height: h } = im, out = blank(w, h), d = out.data, smp = sampler(im), tmp = [0, 0, 0, 0];
    const a = angle * Math.PI / 180, ux = Math.cos(a), uy = -Math.sin(a), n = Math.max(2, Math.min(64, Math.ceil(dist)));
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const o = (y * w + x) * 4, L = path ? dist * (1 - taper * (x / w)) : dist;
      let sr = 0, sg = 0, sb = 0, sa = 0;
      for (let i = 0; i < n; i++) { const s = (i / (n - 1) - (path ? 1 : 0.5)) * L; smp(x + ux * s, y + uy * s, tmp, 0); sr += tmp[0]; sg += tmp[1]; sb += tmp[2]; sa += tmp[3]; }
      d[o] = sr / n; d[o + 1] = sg / n; d[o + 2] = sb / n; d[o + 3] = sa / n;
    }
    return out;
  };
  def('gaussBlur', 'Розмиття за Гаусом…', 'Розмиття', [num('radius', 'Радіус', 0.1, 250, 4, { step: 0.1, u: 'px', px: true })], (im, p) => gauss(im, p.radius));
  def('motionBlur', 'Розмиття в русі…', 'Розмиття', [num('angle', 'Кут', -90, 90, 0, { u: '°' }), num('dist', 'Відстань', 1, 2000, 30, { u: 'px', px: true })], (im, p) => motion(im, p.angle, p.dist));
  def('radialBlur', 'Радіальне розмиття…', 'Розмиття', [num('amount', 'Сила', 1, 100, 12), sel('method', 'Метод', [['spin', 'Кільцевий'], ['zoom', 'Лінійний (наїзд)']], 'zoom'), num('x', 'Центр X', 0, 100, 50, { u: '%' }), num('y', 'Центр Y', 0, 100, 50, { u: '%' })], (im, p) => {
    const { width: w, height: h } = im, cx = w * p.x / 100, cy = h * p.y / 100, out = blank(w, h), d = out.data, smp = sampler(im), tmp = [0, 0, 0, 0], n = 24;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const dx = x - cx, dy = y - cy, o = (y * w + x) * 4; let sr = 0, sg = 0, sb = 0, sa = 0;
      for (let i = 0; i < n; i++) {
        const k = (i / (n - 1) - 0.5) * p.amount / 100;
        if (p.method === 'zoom') smp(cx + dx * (1 + k * 0.5), cy + dy * (1 + k * 0.5), tmp, 0);
        else { const a = k * 0.6, c = Math.cos(a), s = Math.sin(a); smp(cx + dx * c - dy * s, cy + dx * s + dy * c, tmp, 0); }
        sr += tmp[0]; sg += tmp[1]; sb += tmp[2]; sa += tmp[3];
      }
      d[o] = sr / n; d[o + 1] = sg / n; d[o + 2] = sb / n; d[o + 3] = sa / n;
    }
    return out;
  });
  def('boxBlur', 'Розмиття «Рамка»…', 'Розмиття', [num('radius', 'Радіус', 1, 999, 6, { u: 'px', px: true })], (im, p) => box(im, p.radius));
  def('surfaceBlur', 'Розмиття поверхні…', 'Розмиття', [num('radius', 'Радіус', 1, 30, 5, { u: 'px', px: true }), num('thr', 'Поріг', 2, 255, 15)], (im, p) => bilateral(im, p.radius, p.thr));
  def('smartBlur', '«Розумне» розмиття…', 'Розмиття', [num('radius', 'Радіус', 0.1, 30, 3, { step: 0.1, u: 'px', px: true }), num('thr', 'Поріг', 0.1, 100, 25, { step: 0.1 })], (im, p) => bilateral(im, p.radius, p.thr));
  def('blur', 'Розмиття', 'Розмиття', [], im => gauss(im, 0.8));
  def('blurMore', 'Посилене розмиття', 'Розмиття', [], im => gauss(im, 1.8));
  def('average', 'Усереднення', 'Розмиття', [], im => { const s = im.data; let r = 0, g = 0, b = 0, a = 0; for (let i = 0; i < s.length; i += 4) { const al = s[i + 3]; r += s[i] * al; g += s[i + 1] * al; b += s[i + 2] * al; a += al; } a = a || 1; return perPixel(im, (d, i) => { d[i] = r / a; d[i + 1] = g / a; d[i + 2] = b / a; }); });
  def('lensBlur', 'Розмиття об’єктива…', 'Розмиття', [num('radius', 'Радіус', 1, 100, 10, { u: 'px', px: true }), num('bright', 'Яскравість відблисків', 0, 100, 40), num('thr', 'Поріг відблисків', 150, 255, 220)], (im, p) => {
    const boost = perPixel(im, (d, i) => { const l = lum(d, i); if (l > p.thr) { const k = 1 + p.bright / 25 * (l - p.thr) / (255 - p.thr + 1); for (let c = 0; c < 3; c++) d[i + c] = cl(d[i + c] * k); } });
    // disc ≈ several box passes of different sizes
    return gauss(box(boost, p.radius * 0.6), p.radius * 0.45);
  });
  def('shapeBlur', 'Розмиття за формою…', 'Розмиття', [num('radius', 'Радіус', 1, 200, 12, { u: 'px', px: true })], (im, p) => box(box(im, p.radius / 2), p.radius / 2));

  // ---------- Other ----------
  def('highPass', 'Кольоровий контраст…', 'Інше', [num('radius', 'Радіус', 0.1, 250, 10, { step: 0.1, u: 'px', px: true })], (im, p) => { const b = gauss(im, p.radius), e = b.data; return perPixel(im, (d, i) => { for (let c = 0; c < 3; c++) d[i + c] = cl(d[i + c] - e[i + c] + 128); }); });
  def('maximum', 'Максимум…', 'Інше', [num('radius', 'Радіус', 1, 100, 2, { u: 'px', px: true })], (im, p) => morph(im, p.radius, true));
  def('minimum', 'Мінімум…', 'Інше', [num('radius', 'Радіус', 1, 100, 2, { u: 'px', px: true })], (im, p) => morph(im, p.radius, false));
  def('offset', 'Зсув…', 'Інше', [num('dx', 'По горизонталі', -9999, 9999, 100, { u: 'px', px: true }), num('dy', 'По вертикалі', -9999, 9999, 50, { u: 'px', px: true }), sel('undef', 'Краї', [['wrap', 'Обгорнути'], ['repeat', 'Повторити крайові пікселі'], ['transparent', 'Прозорі']], 'wrap')], (im, p) => {
    const { width: w, height: h } = im;
    return warp(im, (x, y, o) => { let X = x - p.dx, Y = y - p.dy; if (p.undef === 'wrap') { X = ((X % w) + w) % w; Y = ((Y % h) + h) % h; } o[0] = X; o[1] = Y; }, p.undef === 'transparent');
  });
  def('custom', 'Власний…', 'Інше', [{ k: 'kernel', l: 'Матриця 5×5 (числа через пробіл)', txt: true, v: '0 0 0 0 0  0 0 -1 0 0  0 -1 5 -1 0  0 0 -1 0 0  0 0 0 0 0' }, num('scale', 'Масштаб', 1, 9999, 1), num('off', 'Зсув', -9999, 9999, 0)], (im, p) => {
    const k = String(p.kernel).trim().split(/[\s,;]+/).map(Number).filter(v => isFinite(v));
    while (k.length < 25) k.push(0);
    return conv(im, k.slice(0, 25), 5, p.scale || 1, p.off);
  });
  def('hsb', 'HSB/HSL…', 'Інше', [sel('mode', 'Вхід → вихід', [['rgb2hsb', 'RGB → HSB'], ['rgb2hsl', 'RGB → HSL'], ['hsb2rgb', 'HSB → RGB']], 'rgb2hsb')], (im, p) => perPixel(im, (d, i) => {
    const r = d[i], g = d[i + 1], b = d[i + 2];
    if (p.mode === 'rgb2hsl') { const [h, s, l] = rgb2hsl(r, g, b); d[i] = h * 255; d[i + 1] = s * 255; d[i + 2] = l * 255; return; }
    if (p.mode === 'rgb2hsb') { const mx = Math.max(r, g, b), mn = Math.min(r, g, b), [h] = rgb2hsl(r, g, b); d[i] = h * 255; d[i + 1] = mx ? (mx - mn) / mx * 255 : 0; d[i + 2] = mx; return; }
    const h = r / 255 * 6, s = g / 255, v = b; const c = v * s, x = c * (1 - Math.abs(h % 2 - 1)), m = v - c; const k = Math.floor(h) % 6;
    const rgb = [[c, x, 0], [x, c, 0], [0, c, x], [0, x, c], [x, 0, c], [c, 0, x]][k]; d[i] = rgb[0] + m; d[i + 1] = rgb[1] + m; d[i + 2] = rgb[2] + m;
  }));

  // ---------- shared by several filters ----------
  function bilateral(im, r, thr) {
    r = Math.max(1, Math.round(r));
    const { width: w, height: h, data: s } = im, out = copy(im), d = out.data, step = r > 6 ? 2 : 1, inv = 1 / (2 * thr * thr);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const o = (y * w + x) * 4; let R = 0, G = 0, B = 0, W = 0;
      for (let j = -r; j <= r; j += step) { const yy = Math.min(h - 1, Math.max(0, y + j)); for (let i = -r; i <= r; i += step) { const xx = Math.min(w - 1, Math.max(0, x + i)); const q = (yy * w + xx) * 4; const dr = s[q] - s[o], dg = s[q + 1] - s[o + 1], db = s[q + 2] - s[o + 2]; const wt = Math.exp(-(dr * dr + dg * dg + db * db) / 3 * inv); R += s[q] * wt; G += s[q + 1] * wt; B += s[q + 2] * wt; W += wt; } }
      d[o] = R / W; d[o + 1] = G / W; d[o + 2] = B / W;
    }
    return out;
  }
  function denoise(im, strength, detail) {
    if (!strength) return copy(im);
    // smooth flat areas strongly, edges less (edge map from Sobel)
    const sm = bilateral(im, Math.min(8, 1 + strength * 0.6), 6 + strength * 4), E = sobel(im), out = copy(im), d = out.data, e = sm.data;
    for (let i = 0, j = 0; i < d.length; i += 4, j++) { const k = O.clamp(1 - (E[j] / 60) * detail, 0, 1); for (let c = 0; c < 3; c++) d[i + c] = d[i + c] + (e[i + c] - d[i + c]) * k; }
    return out;
  }
  function smartSharp(im, amount, radius, noise) {
    const base = noise ? denoise(im, noise * 6, 0.8) : im;
    const E = sobel(base), sh = unsharp(base, amount, radius), out = copy(base), d = out.data, e = sh.data;
    // sharpen where there are edges, not in flat noise
    for (let i = 0, j = 0; i < d.length; i += 4, j++) { const k = O.clamp(E[j] / 25, 0.15, 1); for (let c = 0; c < 3; c++) d[i + c] = d[i + c] + (e[i + c] - d[i + c]) * k; }
    return out;
  }
  FL.helpers = { gauss, box, warp, kuwahara, median, sobel, bilateral, denoise, unsharp, perPixel, copy, blank, lumMap, mix, mixMask, morph, vnoise, rng, sampler, sq2quad, hex, cl, lum, motion };

  // ---------- filter gallery (artistic) ----------
  const paper = (im, seed, k) => { const N = vnoise(seed, 3); const w = im.width; return perPixel(im, (d, i) => { const j = i >> 2, v = (N(j % w, (j / w) | 0) - 0.5) * k; d[i] = cl(d[i] + v); d[i + 1] = cl(d[i + 1] + v); d[i + 2] = cl(d[i + 2] + v); }); };
  const edgesDark = (im, k, thr = 18) => { const E = sobel(gauss(im, 1)); return perPixel(im, (d, i) => { const e = E[i >> 2]; if (e > thr) { const f = Math.max(0, 1 - (e - thr) / 120 * k); d[i] *= f; d[i + 1] *= f; d[i + 2] *= f; } }); };
  const posterize = (im, n) => { const st = 255 / (n - 1); return perPixel(im, (d, i) => { for (let c = 0; c < 3; c++) d[i + c] = Math.round(d[i + c] / st) * st; }); };
  FL.GALLERY = [
    ['gOil', 'Олійна фарба', [num('size', 'Розмір пензля', 1, 12, 5, { px: true })], (im, p) => kuwahara(im, p.size)],
    ['gWatercolor', 'Акварель', [num('detail', 'Деталізація', 1, 14, 6), num('shadow', 'Тіні', 0, 10, 3)], (im, p) => paper(edgesDark(kuwahara(gauss(im, 0.6), Math.max(1, 8 - p.detail / 2)), p.shadow / 6), 21, 14)],
    ['gCutout', 'Аплікація', [num('levels', 'Рівні', 2, 8, 4), num('simple', 'Спрощення країв', 0, 10, 4)], (im, p) => posterize(kuwahara(im, 1 + p.simple / 2), p.levels)],
    ['gDryBrush', 'Сухий пензель', [num('size', 'Розмір пензля', 0, 10, 3), num('texture', 'Текстура', 1, 3, 1)], (im, p) => paper(kuwahara(im, 1 + p.size / 2), 5, 18 * p.texture)],
    ['gGrain', 'Зернистість плівки', [num('grain', 'Зерно', 0, 20, 6), num('light', 'Світлі ділянки', 0, 20, 4)], (im, p) => { const R = rng(3); return perPixel(im, (d, i) => { const v = (R() - 0.5) * p.grain * 9, l = lum(d, i) / 255, b = l > 0.7 ? p.light * 2 * (l - 0.7) / 0.3 : 0; for (let c = 0; c < 3; c++) d[i + c] = cl(d[i + c] + v + b * 10); }); }],
    ['gNeon', 'Неонове сяйво', [col('color', 'Колір сяйва', '#29F0FF'), num('bright', 'Яскравість', 0, 50, 22)], (im, p) => { const c = hex(p.color), E = sobel(gauss(im, 1.2)); return perPixel(im, (d, i) => { const e = Math.min(1, E[i >> 2] / 50) * p.bright / 25, l = lum(d, i) * 0.35; d[i] = cl(l + c[0] * e); d[i + 1] = cl(l + c[1] * e); d[i + 2] = cl(l + c[2] * e); }); }],
    ['gPhotocopy', 'Ксерокопія', [num('detail', 'Деталізація', 1, 24, 7), num('dark', 'Затемненість', 1, 50, 20)], (im, p) => { const b = gauss(im, p.detail / 2), e = b.data; return perPixel(im, (d, i) => { const v = lum(d, i) - lum(e, i); gray(d, i, v < -p.dark / 10 ? 0 : 255); }); }],
    ['gPencil', 'Кольоровий олівець', [num('width', 'Ширина олівця', 1, 24, 4), num('paper', 'Яскравість паперу', 0, 50, 25)], (im, p) => { const E = sobel(gauss(im, p.width / 4)); const base = perPixel(im, (d, i) => { const k = 0.35 + p.paper / 100; for (let c = 0; c < 3; c++) d[i + c] = d[i + c] * (1 - k) + 255 * k; }); return perPixel(base, (d, i) => { const e = Math.min(1, E[i >> 2] / 40); for (let c = 0; c < 3; c++) d[i + c] = cl(d[i + c] * (1 - e * 0.7)); }); }],
    ['gCharcoal', 'Вугілля', [num('thick', 'Товщина', 1, 7, 2), num('detail', 'Деталізація', 0, 5, 3)], (im, p) => { const E = sobel(gauss(im, 2 - p.detail / 4)), L = lumMap(im); const out = perPixel(im, (d, i) => { const j = i >> 2, v = 255 - Math.min(255, E[j] * 2.2 + (255 - L[j]) * 0.35); gray(d, i, v); }); return p.thick > 1 ? morph(out, p.thick / 2, false) : out; }],
    ['gBasRelief', 'Барельєф', [num('detail', 'Деталізація', 1, 15, 10), num('smooth', 'Пом’якшення', 1, 15, 4), col('c1', 'Темний', '#2A2A2A'), col('c2', 'Світлий', '#F2EDE4')], (im, p) => { const L = lumMap(gauss(im, p.smooth / 3)), { width: w } = im, a = hex(p.c1), b = hex(p.c2); return perPixel(im, (d, i) => { const j = i >> 2, x = j % w; const v = O.clamp(0.5 + (L[j] - L[Math.max(0, j - w - (x > 0 ? 1 : 0))]) * p.detail / 60, 0, 1); for (let c = 0; c < 3; c++) d[i + c] = a[c] + (b[c] - a[c]) * v; }); }],
    ['gInk', 'Контури тушшю', [num('length', 'Довжина штриха', 1, 50, 4), num('dark', 'Темна інтенсивність', 0, 50, 20)], (im, p) => edgesDark(motion(im, 45, p.length), p.dark / 10, 10)],
    ['gMosaicTiles', 'Мозаїчні плитки', [num('size', 'Розмір плитки', 4, 100, 18, { px: true }), num('grout', 'Ширина шва', 1, 15, 3, { px: true })], (im, p) => { const { width: w } = im, s = Math.max(4, p.size); return perPixel(kuwahara(im, 2), (d, i) => { const j = i >> 2, x = j % w, y = (j / w) | 0; if (x % s < p.grout || y % s < p.grout) { d[i] *= 0.55; d[i + 1] *= 0.55; d[i + 2] *= 0.55; } }); }],
    ['gSponge', 'Губка', [num('size', 'Розмір', 0, 10, 4), num('def', 'Чіткість', 0, 25, 10)], (im, p) => { const N = vnoise(17, 2 + p.size); const w = im.width; return perPixel(kuwahara(im, 1 + p.size / 3), (d, i) => { const j = i >> 2, v = (N(j % w, (j / w) | 0) - 0.5) * p.def * 6; for (let c = 0; c < 3; c++) d[i + c] = cl(d[i + c] + v); }); }],
    ['gPosterEdges', 'Постеризація країв', [num('levels', 'Постеризація', 2, 8, 4), num('edge', 'Товщина країв', 0, 10, 4)], (im, p) => edgesDark(posterize(im, p.levels), p.edge / 3, 14)],
    ['gHalftone', 'Півтоновий візерунок', [num('size', 'Розмір', 2, 24, 6, { px: true }), sel('type', 'Тип', [['dot', 'Точки'], ['line', 'Лінії'], ['circle', 'Кола']], 'dot')], (im, p) => { const { width: w, height: h } = im, s = Math.max(2, p.size); return perPixel(im, (d, i) => { const j = i >> 2, x = j % w, y = (j / w) | 0, l = lum(d, i) / 255; let v; if (p.type === 'line') v = Math.abs(((y % s) / s) - 0.5) * 2; else if (p.type === 'circle') v = (Math.hypot(x - w / 2, y - h / 2) % s) / s; else v = Math.hypot((x % s) / s - 0.5, (y % s) / s - 0.5) * 1.42; gray(d, i, v < 1 - l ? 30 : 235); }); }],
    ['gTexturizer', 'Текстуризатор', [sel('tex', 'Текстура', [['canvas', 'Полотно'], ['brick', 'Цегла'], ['burlap', 'Мішковина']], 'canvas'), num('relief', 'Рельєф', 0, 50, 6)], (im, p) => { const w = im.width; return perPixel(im, (d, i) => { const j = i >> 2, x = j % w, y = (j / w) | 0; let v; if (p.tex === 'brick') { const row = Math.floor(y / 14), off = row % 2 ? 14 : 0; v = (y % 14 < 2 || (x + off) % 28 < 2) ? -1 : 0.2; } else if (p.tex === 'burlap') v = Math.sin(x * 0.9) * Math.sin(y * 0.9) + Math.sin((x + y) * 0.35) * 0.3; else v = Math.sin(x * 1.3) * 0.5 + Math.sin(y * 1.3) * 0.5; v *= p.relief * 2.5; for (let c = 0; c < 3; c++) d[i + c] = cl(d[i + c] + v); }); }],
    ['gGlass', 'Скло', [num('dist', 'Сила спотворення', 0, 20, 6, { px: true }), num('smooth', 'Пом’якшення', 1, 15, 4)], (im, p) => F.glassDistort.run(im, { dist: p.dist, smooth: p.smooth, tex: 'frost', seed: 12 })]
  ];
  FL.GALLERY.forEach(([id, name, params, run]) => def(id, name, 'Галерея', params, run, { gallery: true }));

  // ---------- Camera Raw ----------
  const CR_PARAMS = [
    ['Основні', [num('temp', 'Температура', -100, 100, 0), num('tint', 'Відтінок', -100, 100, 0), num('exposure', 'Експозиція', -5, 5, 0, { step: 0.05 }), num('contrast', 'Контраст', -100, 100, 0), num('highlights', 'Світлі ділянки', -100, 100, 0), num('shadows', 'Тіні', -100, 100, 0), num('whites', 'Білі', -100, 100, 0), num('blacks', 'Чорні', -100, 100, 0)]],
    ['Присутність', [num('texture', 'Текстура', -100, 100, 0), num('clarity', 'Чіткість', -100, 100, 0), num('dehaze', 'Видалення серпанку', -100, 100, 0), num('vibrance', 'Соковитість', -100, 100, 0), num('saturation', 'Насиченість', -100, 100, 0)]],
    ['Деталі', [num('sharp', 'Різкість', 0, 150, 0), num('nr', 'Зменшення шуму', 0, 100, 0)]],
    ['Ефекти', [num('vignette', 'Віньєтка', -100, 100, 0), num('grain', 'Зерно', 0, 100, 0)]]
  ];
  FL.cameraRaw = (im, p) => {
    const { width: w, height: h } = im;
    let src = im;
    if (p.nr) src = denoise(src, p.nr / 12, 0.7);
    const big = p.clarity || p.dehaze ? lumMap(gauss(src, Math.max(4, Math.min(w, h) / 40))) : null;
    const small = p.texture ? gauss(src, Math.max(1, Math.min(w, h) / 400)) : null;
    const ev = Math.pow(2, p.exposure || 0), con = 1 + (p.contrast || 0) / 100, R = rng(29), cx = w / 2, cy = h / 2, maxd = Math.hypot(cx, cy);
    let out = perPixel(src, (d, i) => {
      const j = i >> 2;
      let r = d[i] * ev, g = d[i + 1] * ev, b = d[i + 2] * ev;
      r += p.temp * 0.55; b -= p.temp * 0.55; g -= p.tint * 0.45; r += p.tint * 0.15; b += p.tint * 0.15;
      let L = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
      const adj = (p.shadows / 100) * Math.pow(1 - O.clamp(L, 0, 1), 2) * 70 + (p.highlights / 100) * Math.pow(O.clamp(L, 0, 1), 2) * 70 + (p.whites / 100) * Math.pow(O.clamp(L, 0, 1), 4) * 60 + (p.blacks / 100) * Math.pow(1 - O.clamp(L, 0, 1), 4) * 60;
      r += adj; g += adj; b += adj;
      r = (r - 128) * con + 128; g = (g - 128) * con + 128; b = (b - 128) * con + 128;
      if (big) {
        L = (0.299 * r + 0.587 * g + 0.114 * b);
        if (p.clarity) { const mid = 1 - Math.abs(L / 255 - 0.5) * 2; const v = (L - big[j]) * p.clarity / 100 * 1.2 * Math.max(0.2, mid); r += v; g += v; b += v; }
        if (p.dehaze > 0) { const m = Math.min(r, g, b) / 255, tt = Math.max(0.15, 1 - p.dehaze / 100 * 0.55 * m); r = (r / 255 - (1 - tt) * 0.9) / tt * 255; g = (g / 255 - (1 - tt) * 0.9) / tt * 255; b = (b / 255 - (1 - tt) * 0.9) / tt * 255; }
        if (p.dehaze < 0) { const k = -p.dehaze / 100 * 0.5; r += (210 - r) * k; g += (210 - g) * k; b += (215 - b) * k; }
      }
      if (small) { const e = small.data; r += (d[i] - e[i]) * p.texture / 50; g += (d[i + 1] - e[i + 1]) * p.texture / 50; b += (d[i + 2] - e[i + 2]) * p.texture / 50; }
      const y = 0.299 * r + 0.587 * g + 0.114 * b;
      if (p.vibrance || p.saturation) { const sat = (Math.max(r, g, b) - Math.min(r, g, b)) / 255; const k = 1 + p.saturation / 100 + (p.vibrance / 100) * (1 - sat) * 1.2; r = y + (r - y) * k; g = y + (g - y) * k; b = y + (b - y) * k; }
      if (p.vignette) { const x = j % w, yy = (j / w) | 0, dd = Math.hypot(x - cx, yy - cy) / maxd, v = Math.pow(dd, 2.2) * p.vignette / 100 * 160; r += v; g += v; b += v; }
      if (p.grain) { const n = (R() + R() - 1) * p.grain * 0.6; r += n; g += n; b += n; }
      d[i] = cl(r); d[i + 1] = cl(g); d[i + 2] = cl(b);
    });
    if (p.sharp) out = smartSharp(out, p.sharp / 60, 1, 0);
    return out;
  };
  def('cameraRaw', 'Фільтр Camera Raw…', 'top', CR_PARAMS.flatMap(g => g[1]), (im, p) => FL.cameraRaw(im, p), { groups: CR_PARAMS });

  // ---------- AI denoise / sharpen, lens & wide angle, neural ----------
  def('aiDenoise', 'ШІ-зменшення шуму…', 'top', [num('amount', 'Сила', 0, 100, 50, { u: '%' }), num('detail', 'Зберегти деталі', 0, 100, 60, { u: '%' }), num('color', 'Колірний шум', 0, 100, 50, { u: '%' })], (im, p) => {
    let out = denoise(im, p.amount / 10, p.detail / 100);
    if (p.color) { const b = gauss(out, 2.5), e = b.data; out = perPixel(out, (d, i) => { const y = lum(d, i), yb = lum(e, i), k = p.color / 100; for (let c = 0; c < 3; c++) d[i + c] = cl(d[i + c] + ((e[i + c] - yb + y) - d[i + c]) * k); }); }
    return out;
  }, { note: 'Обробка в браузері: розумне згладжування, що зберігає краї.' });
  def('aiSharpen', 'ШІ-різкість…', 'top', [num('amount', 'Сила', 0, 300, 120, { u: '%' }), num('radius', 'Радіус', 0.3, 6, 1.2, { step: 0.1, u: 'px', px: true }), num('noise', 'Пригнічення шуму', 0, 100, 25, { u: '%' })], (im, p) => smartSharp(im, p.amount / 100, p.radius, p.noise / 100), { note: 'Обробка в браузері: різкість лише на краях, без підсилення шуму.' });
  def('lensCorrection', 'Корекція дисторсії…', 'top', [num('dist', 'Дисторсія', -100, 100, 0), num('ca', 'Хроматична аберація', -100, 100, 0), num('vign', 'Віньєтка', -100, 100, 0), num('vmid', 'Середина віньєтки', 0, 100, 50), num('vp', 'Вертикальна перспектива', -100, 100, 0), num('hp', 'Горизонтальна перспектива', -100, 100, 0), num('angle', 'Кут', -45, 45, 0, { step: 0.1, u: '°' }), num('scale', 'Масштаб', 50, 150, 100, { u: '%' })], (im, p) => {
    const { width: w, height: h } = im, cx = w / 2, cy = h / 2, R = Math.hypot(cx, cy), k = -p.dist / 100 * 0.45, a = p.angle * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a), sc = 100 / p.scale;
    const smp = sampler(im, true), out = blank(w, h), d = out.data, tmp = [0, 0, 0, 0];
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let nx = (x - cx) * sc, ny = (y - cy) * sc;
      const rx = nx * ca - ny * sa, ry = nx * sa + ny * ca; nx = rx; ny = ry;
      // perspective: rows / columns scaled by their distance
      const pv = 1 + p.vp / 100 * 0.35 * (ny / cy), ph = 1 + p.hp / 100 * 0.35 * (nx / cx);
      nx *= pv; ny *= ph;
      const r2 = (nx * nx + ny * ny) / (R * R), f = 1 + k * r2, o = (y * w + x) * 4;
      for (let c = 0; c < 3; c++) { const cf = f * (1 + (c - 1) * p.ca / 100 * 0.004); smp(cx + nx * cf, cy + ny * cf, tmp, 0); d[o + c] = tmp[c]; }
      smp(cx + nx * f, cy + ny * f, tmp, 0); d[o + 3] = tmp[3];
      if (p.vign) { const dd = Math.sqrt(r2), m = p.vmid / 100, v = O.clamp((dd - m * 0.6) / (1.1 - m * 0.6), 0, 1) ** 2 * p.vign / 100 * 140; for (let c = 0; c < 3; c++) d[o + c] = cl(d[o + c] + v); }
    }
    return out;
  });
  def('wideAngle', 'Адаптивна ширококутна корекція…', 'top', [sel('proj', 'Проєкція', [['fisheye', '«Риб’яче око»'], ['persp', 'Перспектива'], ['full', 'Повна сферична']], 'fisheye'), num('amount', 'Сила корекції', 0, 100, 50, { u: '%' }), num('scale', 'Масштаб', 50, 200, 100, { u: '%' })], (im, p) => {
    const { width: w, height: h } = im, cx = w / 2, cy = h / 2, R = Math.hypot(cx, cy), k = p.amount / 100 * (p.proj === 'full' ? 1.4 : p.proj === 'persp' ? 0.6 : 1), sc = 100 / p.scale;
    return warp(im, (x, y, o) => {
      const nx = (x - cx) * sc, ny = (y - cy) * sc, r = Math.hypot(nx, ny) / R;
      if (!r) { o[0] = cx; o[1] = cy; return; }
      // undo a fisheye: a rectilinear radius maps back to the shorter fisheye radius
      const theta = Math.atan(r * (1 + k * 1.5)), rf = theta / Math.atan(1 + k * 1.5);
      const f = 1 + (rf / r - 1) * k;
      o[0] = cx + nx * f; o[1] = cy + ny * f;
    }, true);
  });
  FL.NEURAL = [
    ['skin', 'Згладжування шкіри', [num('blur', 'Розмиття', 0, 100, 40), num('smooth', 'Гладкість', 0, 100, 50)], (im, p) => {
      const sm = bilateral(im, 4 + p.blur / 12, 18 + p.smooth / 2), out = copy(im), d = out.data, e = sm.data;
      for (let i = 0; i < d.length; i += 4) { const [hh, ss, ll] = rgb2hsl(d[i], d[i + 1], d[i + 2]); const skin = (hh < 0.14 || hh > 0.95) && ss > 0.12 && ss < 0.75 && ll > 0.2 && ll < 0.9 ? 1 : 0; if (!skin) continue; const k = p.smooth / 100; for (let c = 0; c < 3; c++) d[i + c] = d[i + c] + (e[i + c] - d[i + c]) * k; }
      return out;
    }],
    ['jpeg', 'Видалення артефактів JPEG', [num('strength', 'Сила', 0, 100, 50)], (im, p) => bilateral(im, 2, 8 + p.strength / 3)],
    ['harmonize', 'Гармонізація (автоколір)', [num('amount', 'Сила', 0, 100, 80)], (im, p) => {
      const s = im.data, hs = [new Int32Array(256), new Int32Array(256), new Int32Array(256)];
      for (let i = 0; i < s.length; i += 4) for (let c = 0; c < 3; c++) hs[c][s[i + c]]++;
      const n = s.length / 4, lo = [], hi = [];
      for (let c = 0; c < 3; c++) { let a = 0, l = 0, hgh = 255; for (let v = 0; v < 256; v++) { a += hs[c][v]; if (a > n * 0.005) { l = v; break; } } a = 0; for (let v = 255; v >= 0; v--) { a += hs[c][v]; if (a > n * 0.005) { hgh = v; break; } } lo.push(l); hi.push(Math.max(l + 1, hgh)); }
      return perPixel(im, (d, i) => { for (let c = 0; c < 3; c++) { const v = (d[i + c] - lo[c]) / (hi[c] - lo[c]) * 255; d[i + c] = cl(d[i + c] + (v - d[i + c]) * p.amount / 100); } });
    }],
    ['colorize', 'Розфарбування', [sel('mood', 'Настрій', [['warm', 'Теплий'], ['natural', 'Природний'], ['cool', 'Холодний'], ['sepia', 'Сепія']], 'natural'), num('amount', 'Сила', 0, 100, 70)], (im, p) => {
      const maps = { warm: [[40, 20, 30], [200, 120, 80], [255, 235, 200]], natural: [[30, 35, 50], [150, 130, 110], [250, 240, 225]], cool: [[15, 25, 50], [90, 140, 180], [230, 245, 255]], sepia: [[40, 25, 15], [160, 120, 80], [250, 235, 210]] }[p.mood];
      return perPixel(im, (d, i) => { const l = lum(d, i) / 255, a = l < 0.5 ? maps[0] : maps[1], b = l < 0.5 ? maps[1] : maps[2], k = l < 0.5 ? l * 2 : (l - 0.5) * 2; for (let c = 0; c < 3; c++) { const v = a[c] + (b[c] - a[c]) * k; d[i + c] = d[i + c] + (v - d[i + c]) * p.amount / 100; } });
    }],
    ['depth', 'Розмиття фону (глибина)', [num('blur', 'Розмиття', 0, 100, 40, { px: true }), num('x', 'Фокус X', 0, 100, 50, { u: '%' }), num('y', 'Фокус Y', 0, 100, 45, { u: '%' }), num('size', 'Зона різкості', 5, 100, 35, { u: '%' })], (im, p) => F.irisBlur.run(im, { blur: p.blur / 3, x: p.x, y: p.y, rx: p.size, ry: p.size * 1.2, feather: 60 })],
    ['restore', 'Відновлення старого фото', [num('scratch', 'Подряпини', 0, 100, 50), num('contrast', 'Контраст', 0, 100, 40)], (im, p) => { let out = median(im, 1, 40 - p.scratch / 3); out = F.cameraRaw.run(out, { temp: 0, tint: 0, exposure: 0, contrast: p.contrast / 2, highlights: -10, shadows: 15, whites: 0, blacks: -10, texture: 0, clarity: p.contrast / 3, dehaze: 10, vibrance: 0, saturation: 0, sharp: 30, nr: 20, vignette: 0, grain: 0 }); return out; }],
    ['superzoom', 'Супермасштаб 2×', [num('sharp', 'Підсилити деталі', 0, 100, 50)], (im, p) => {
      const cv = document.createElement('canvas'); cv.width = im.width; cv.height = im.height; cv.getContext('2d').putImageData(im, 0, 0);
      const w2 = Math.min(MAX_SIDE * 2, im.width * 2), h2 = Math.round(im.height * w2 / im.width);
      const c2 = document.createElement('canvas'); c2.width = w2; c2.height = h2; const g = c2.getContext('2d', { willReadFrequently: true }); g.imageSmoothingQuality = 'high'; g.drawImage(cv, 0, 0, w2, h2);
      return smartSharp(g.getImageData(0, 0, w2, h2), p.sharp / 70, 1.2, 0.1);
    }]
  ];
  def('neural', 'Neural Filters…', 'top', [], (im, p) => { let out = im; for (const [id, , , run] of FL.NEURAL) if (p[id + '_on']) { const q = {}; for (const [k, v] of Object.entries(p)) if (k.startsWith(id + '_')) q[k.slice(id.length + 1)] = v; out = run(out, q); } return out; }, { special: 'neural' });

  // ======================================================================
  // TARGETS: the photos of the selection
  // ======================================================================
  FL.targets = () => {
    const out = [], seen = new Set();
    for (const n0 of O.sel()) {
      const gf = O.photo && O.photo.frameOf && O.photo.frameOf(n0);
      const n = gf ? (O.photo.contentOf(gf) || n0) : n0;
      if (n.type === 'raster' && n.asset) { if (!seen.has(n)) { seen.add(n); out.push({ n, holder: n, get: () => n.asset, set: (id, a) => { n.asset = id; if (a) { n.pw = a.w; n.ph = a.h; } } }); } continue; }
      const p = (n.fills || []).find(f => f.type === 'image' && f.asset && f.visible !== false);
      if (p && !seen.has(p)) { seen.add(p); out.push({ n, holder: p, get: () => p.asset, set: id => { p.asset = id; } }); }
    }
    return out;
  };
  const ensureTargets = async () => {
    let tg = FL.targets();
    if (tg.length) return tg;
    if (!O.topSel().length) { O.toast('Виділіть фото або об’єкт для фільтра'); return []; }
    const ok = await new Promise(res => ui.dialog({ title: 'Растеризувати?', body: `<div class="dlg-text">${esc(t('Фільтри працюють з пікселями. Перетворити виділене на зображення, щоб застосувати фільтр?'))}</div>`, buttons: [{ id: 'ok', label: 'Растеризувати', primary: true }], onOk: () => res(true), onCancel: () => res(false) }));
    if (!ok) return [];
    await O.ops.rasterize(2);
    tg = FL.targets();
    return tg;
  };
  // pixels of an asset (limited to MAX_SIDE)
  const imgCache = new Map();
  FL.load = async (assetId, maxSide = MAX_SIDE) => {
    const key = assetId + '|' + maxSide;
    if (imgCache.has(key)) return copy(imgCache.get(key));
    const a = S.doc.assets[assetId];
    if (!a) throw new Error(t('Зображення не знайдено'));
    const img = await io.loadImage(O.assetURL(assetId));
    const k = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.max(1, Math.round(img.naturalWidth * k)), h = Math.max(1, Math.round(img.naturalHeight * k));
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    const g = cv.getContext('2d', { willReadFrequently: true }); g.drawImage(img, 0, 0, w, h);
    const im = g.getImageData(0, 0, w, h);
    imgCache.set(key, im);
    if (imgCache.size > 8) imgCache.delete(imgCache.keys().next().value);
    return copy(im);
  };
  const webp = (() => { try { const c = document.createElement('canvas'); c.width = c.height = 1; return c.toDataURL('image/webp').startsWith('data:image/webp'); } catch (e) { return false; } })();
  FL.toAsset = async (im, name) => {
    const cv = document.createElement('canvas'); cv.width = im.width; cv.height = im.height;
    cv.getContext('2d').putImageData(im, 0, 0);
    let alpha = false; const d = im.data; for (let i = 3; i < d.length; i += 4 * 7) if (d[i] < 250) { alpha = true; break; }
    const data = cv.toDataURL(webp ? 'image/webp' : alpha ? 'image/png' : 'image/jpeg', 0.94);
    const id = O.uid();
    S.doc.assets[id] = { data, w: im.width, h: im.height, name: name || t('Зображення') };
    return { id, w: im.width, h: im.height };
  };
  const scaleParams = (f, p, k) => { const q = Object.assign({}, p); for (const pr of f.params) if (pr.px && typeof q[pr.k] === 'number') q[pr.k] = q[pr.k] * k; return q; };
  const defaults = f => { const p = {}; for (const pr of f.params) p[pr.k] = pr.v; return p; };
  FL.runDef = (f, im, p) => f.run(im, p);

  // apply to every target: smart photos get a filter entry, others are replaced (the original kept for «restore»)
  FL.apply = async (id, p, opts = {}) => {
    const f = F[id];
    const tg = opts.targets || await ensureTargets();
    if (!tg.length) return;
    busy(true, t(f.name).replace('…', ''));
    try {
      for (const x of tg) {
        const h = x.holder;
        if (h.sfSrc && !opts.destructive) {
          h.sf = (h.sf || []).concat([{ id: O.uid(), type: id, p: O.clone(p), on: true }]);
          await FL.rerun(x);
        } else {
          const src = x.get();
          const im = await FL.load(src);
          const k = im.width / (S.doc.assets[src].w || im.width);
          await nextFrame();
          const out = f.run(im, scaleParams(f, p, k));
          const a = await FL.toAsset(out, (S.doc.assets[src].name || t('Зображення')) + ' · ' + t(f.name).replace('…', ''));
          if (!h.origAsset) h.origAsset = src;
          x.set(a.id, a);
        }
      }
      FL.last = { id, p: O.clone(p) };
      O.history.commit(t(f.name).replace('…', ''));
    } catch (e) { console.error(e); O.toast('Помилка фільтра: {msg}', { msg: e.message }); } finally { busy(false); }
  };
  // a smart photo: the original + every filter that is switched on
  FL.rerun = async x => {
    const h = x.holder;
    let im = await FL.load(h.sfSrc);
    const k = im.width / (S.doc.assets[h.sfSrc].w || im.width);
    for (const e of h.sf || []) { if (e.on === false || !F[e.type]) continue; await nextFrame(); im = F[e.type].run(im, scaleParams(F[e.type], e.p, k)); }
    if (!(h.sf || []).some(e => e.on !== false)) { x.set(h.sfSrc, S.doc.assets[h.sfSrc]); return; }
    const a = await FL.toAsset(im, (S.doc.assets[h.sfSrc].name || t('Зображення')) + ' · ' + t('смарт-фільтри'));
    x.set(a.id, a);
  };
  const nextFrame = () => new Promise(r => setTimeout(r, 16));
  let busyEl = null;
  const busy = (on, label) => {
    if (on) { if (!busyEl) { busyEl = O.h(`<div class="fl-busy" role="status"><span class="fl-spin"></span><span class="fl-busy-t"></span></div>`); document.body.appendChild(busyEl); } busyEl.querySelector('.fl-busy-t').textContent = t('Фільтр «{name}»…', { name: label }); }
    else if (busyEl) { busyEl.remove(); busyEl = null; }
  };
  FL.convertSmart = () => {
    const tg = FL.targets();
    if (!tg.length) return O.toast('Виділіть фото');
    tg.forEach(x => { const h = x.holder; if (!h.sfSrc) { h.sfSrc = h.origAsset || x.get(); h.sf = h.sf || []; if (h.origAsset) x.set(h.sfSrc, S.doc.assets[h.sfSrc]); } });
    O.history.commit('Смарт-об’єкт');
    O.toast('Фото перетворено для смарт-фільтрів: фільтри можна вимикати й змінювати в панелі «Дизайн»');
  };
  FL.restore = () => {
    const tg = FL.targets().filter(x => x.holder.origAsset || x.holder.sfSrc);
    if (!tg.length) return O.toast('Немає змінених зображень');
    tg.forEach(x => { const h = x.holder, src = h.sfSrc || h.origAsset; x.set(src, S.doc.assets[src]); delete h.origAsset; delete h.sfSrc; delete h.sf; });
    O.history.commit('Повернути оригінал');
  };

  // ======================================================================
  // DIALOG with a live preview
  // ======================================================================
  const fieldHTML = (pr, val) => {
    const id = 'fl-' + pr.k;
    if (pr.o) return `<label class="fl-row"><span>${esc(t(pr.l))}</span><select data-p="${pr.k}" id="${id}">${pr.o.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(val) ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select></label>`;
    if (pr.c) return `<label class="fl-row"><span>${esc(t(pr.l))}</span><input type="color" data-p="${pr.k}" id="${id}" value="${esc(val)}"></label>`;
    if (pr.b) return `<label class="fl-row chk"><input type="checkbox" data-p="${pr.k}" id="${id}"${val ? ' checked' : ''}><span>${esc(t(pr.l))}</span></label>`;
    if (pr.txt) return `<label class="fl-row col"><span>${esc(t(pr.l))}</span><textarea data-p="${pr.k}" id="${id}" rows="3" spellcheck="false">${esc(val)}</textarea></label>`;
    return `<label class="fl-row"><span>${esc(t(pr.l))}</span><input type="range" data-p="${pr.k}" min="${pr.min}" max="${pr.max}" step="${pr.step}" value="${val}"><input type="number" class="fl-num" data-pn="${pr.k}" min="${pr.min}" max="${pr.max}" step="${pr.step}" value="${val}">${pr.u ? `<em>${esc(t(pr.u))}</em>` : ''}</label>`;
  };
  const readParams = (root, params) => { const p = {}; for (const pr of params) { const el = root.querySelector(`[data-p="${pr.k}"]`); if (!el) { p[pr.k] = pr.v; continue; } p[pr.k] = pr.b ? el.checked : pr.o || pr.c || pr.txt ? el.value : parseFloat(el.value); } return p; };
  const PREV = 520;
  FL.dialog = async (id, opts = {}) => {
    const f = F[id];
    if (!f) return;
    if (f.special === 'neural') return FL.neuralDialog(opts);
    if (!f.params.length && !opts.edit) return FL.apply(id, {});
    const tg = opts.targets || await ensureTargets();
    if (!tg.length) return;
    const src = opts.edit ? opts.edit.src : tg[0].get();
    const prevIm = await FL.load(src, PREV);
    const k = prevIm.width / (S.doc.assets[src].w || prevIm.width);
    const start = Object.assign(defaults(f), (FL.memory[id] || {}), opts.p || {});
    const groups = f.groups ? f.groups.map(([g, ps]) => `<div class="fl-grp"><h5>${esc(t(g))}</h5>${ps.map(pr => fieldHTML(pr, start[pr.k])).join('')}</div>`).join('') : f.params.map(pr => fieldHTML(pr, start[pr.k])).join('');
    const d = ui.dialog({
      title: t(f.name).replace('…', ''),
      body: `<div class="fl-dlg"><div class="fl-prev"><canvas></canvas><div class="fl-prev-bar"><label class="chk"><input type="checkbox" class="fl-before"><span>${esc(t('Показати оригінал'))}</span></label><span class="fl-stat"></span></div></div><div class="fl-params">${f.note ? `<div class="dlg-text small">${esc(t(f.note))}</div>` : ''}${groups}<button type="button" class="link fl-reset">${esc(t('Скинути'))}</button></div></div>`,
      buttons: [{ id: 'ok', label: opts.edit ? 'Оновити' : 'Застосувати', primary: true }],
      keepOpen: true,
      onOk: async () => {
        const p = readParams(d.el, f.params);
        FL.memory[id] = p;
        d.close();
        if (opts.onApply) return opts.onApply(p);
        await FL.apply(id, p, { targets: tg });
      }
    });
    d.el.querySelector('.dlg').classList.add('wide', 'fl-wide');
    const cv = d.el.querySelector('.fl-prev canvas'), g = cv.getContext('2d');
    cv.width = prevIm.width; cv.height = prevIm.height;
    const stat = d.el.querySelector('.fl-stat');
    let seq = 0;
    const render = O.debounce(() => {
      const my = ++seq;
      if (d.el.querySelector('.fl-before').checked) { g.putImageData(prevIm, 0, 0); return; }
      stat.textContent = t('Обробка…');
      setTimeout(() => {
        if (my !== seq || !cv.isConnected) return;
        const t0 = performance.now();
        try { const out = f.run(copy(prevIm), scaleParams(f, readParams(d.el, f.params), k)); if (out.width !== cv.width || out.height !== cv.height) { const tmp = document.createElement('canvas'); tmp.width = out.width; tmp.height = out.height; tmp.getContext('2d').putImageData(out, 0, 0); g.clearRect(0, 0, cv.width, cv.height); g.drawImage(tmp, 0, 0, cv.width, cv.height); } else g.putImageData(out, 0, 0); stat.textContent = Math.round(performance.now() - t0) + ' ms'; }
        catch (e) { console.error(e); stat.textContent = e.message; }
      }, 0);
    }, 90);
    d.el.addEventListener('input', e => {
      const el = e.target;
      if (el.dataset.p && el.type === 'range') { const n = d.el.querySelector(`[data-pn="${el.dataset.p}"]`); if (n) n.value = el.value; }
      if (el.dataset.pn) { const r = d.el.querySelector(`[data-p="${el.dataset.pn}"]`); if (r) r.value = el.value; }
      render();
    });
    d.el.addEventListener('change', render);
    d.el.querySelector('.fl-reset').addEventListener('click', e => { e.preventDefault(); const p = defaults(f); for (const pr of f.params) { const el = d.el.querySelector(`[data-p="${pr.k}"]`); if (!el) continue; if (pr.b) el.checked = !!p[pr.k]; else el.value = p[pr.k]; const n = d.el.querySelector(`[data-pn="${pr.k}"]`); if (n) n.value = p[pr.k]; } render(); });
    render();
  };
  FL.memory = {};

  // ---------- Neural Filters ----------
  FL.neuralDialog = async () => {
    const tg = await ensureTargets();
    if (!tg.length) return;
    const params = [];
    const body = FL.NEURAL.map(([id, name, ps]) => {
      params.push({ k: id + '_on', b: true, v: false });
      ps.forEach(pr => params.push(Object.assign({}, pr, { k: id + '_' + pr.k })));
      return `<details class="fl-nf"><summary><label class="chk"><input type="checkbox" data-p="${id}_on"><span>${esc(t(name))}</span></label></summary>${ps.map(pr => fieldHTML(Object.assign({}, pr, { k: id + '_' + pr.k }), pr.v)).join('')}</details>`;
    }).join('');
    F.neural.params = params;
    const prevIm = await FL.load(tg[0].get(), PREV);
    const d = ui.dialog({
      title: 'Neural Filters',
      body: `<div class="fl-dlg"><div class="fl-prev"><canvas></canvas><div class="fl-prev-bar"><span class="fl-stat"></span></div></div><div class="fl-params"><div class="dlg-text small">${esc(t('Увімкніть один або кілька фільтрів. Обробка відбувається в браузері — фото нікуди не надсилається.'))}</div>${body}</div></div>`,
      buttons: [{ id: 'ok', label: 'Застосувати', primary: true }],
      onOk: async () => { const p = readParams(d.el, params); if (!FL.NEURAL.some(n => p[n[0] + '_on'])) return; await FL.apply('neural', p, { targets: tg }); }
    });
    d.el.querySelector('.dlg').classList.add('wide', 'fl-wide');
    const cv = d.el.querySelector('canvas'), g = cv.getContext('2d'), stat = d.el.querySelector('.fl-stat');
    cv.width = prevIm.width; cv.height = prevIm.height; g.putImageData(prevIm, 0, 0);
    const render = O.debounce(() => { stat.textContent = t('Обробка…'); setTimeout(() => { if (!cv.isConnected) return; const out = F.neural.run(copy(prevIm), readParams(d.el, params)); const tmp = document.createElement('canvas'); tmp.width = out.width; tmp.height = out.height; tmp.getContext('2d').putImageData(out, 0, 0); g.clearRect(0, 0, cv.width, cv.height); g.drawImage(tmp, 0, 0, cv.width, cv.height); stat.textContent = ''; }, 0); }, 120);
    d.el.addEventListener('input', e => { const el = e.target; if (el.dataset.p && el.type === 'range') { const n = d.el.querySelector(`[data-pn="${el.dataset.p}"]`); if (n) n.value = el.value; } if (el.dataset.pn) { const r = d.el.querySelector(`[data-p="${el.dataset.pn}"]`); if (r) r.value = el.value; } render(); });
    d.el.addEventListener('change', render);
  };

  // ---------- Filter Gallery: thumbnails of every look ----------
  FL.galleryDialog = async () => {
    const tg = await ensureTargets();
    if (!tg.length) return;
    const src = tg[0].get(), prevIm = await FL.load(src, PREV), thumbIm = await FL.load(src, 110);
    const k = prevIm.width / (S.doc.assets[src].w || prevIm.width), kt = thumbIm.width / (S.doc.assets[src].w || thumbIm.width);
    let cur = FL.memory.galleryPick || 'gOil';
    const d = ui.dialog({
      title: 'Галерея фільтрів',
      body: `<div class="fl-gal"><div class="fl-prev"><canvas class="fl-main"></canvas><div class="fl-prev-bar"><span class="fl-stat"></span></div></div><div class="fl-gal-grid">${FL.GALLERY.map(([id, name]) => `<button type="button" class="fl-th" data-g="${id}"><canvas width="${thumbIm.width}" height="${thumbIm.height}"></canvas><span>${esc(t(name))}</span></button>`).join('')}</div><div class="fl-params fl-gal-p"></div></div>`,
      buttons: [{ id: 'ok', label: 'Застосувати', primary: true }],
      onOk: async () => { const f = F[cur]; const p = readParams(d.el.querySelector('.fl-gal-p'), f.params); FL.memory[cur] = p; FL.memory.galleryPick = cur; await FL.apply(cur, p, { targets: tg }); }
    });
    d.el.querySelector('.dlg').classList.add('wide', 'fl-wide');
    const main = d.el.querySelector('.fl-main'), g = main.getContext('2d'), stat = d.el.querySelector('.fl-stat');
    main.width = prevIm.width; main.height = prevIm.height;
    const pane = d.el.querySelector('.fl-gal-p');
    const showParams = () => { const f = F[cur]; const st = Object.assign(defaults(f), FL.memory[cur] || {}); pane.innerHTML = `<h5>${esc(t(f.name))}</h5>` + f.params.map(pr => fieldHTML(pr, st[pr.k])).join(''); d.el.querySelectorAll('.fl-th').forEach(b => b.classList.toggle('on', b.dataset.g === cur)); };
    const render = O.debounce(() => { stat.textContent = t('Обробка…'); setTimeout(() => { if (!main.isConnected) return; const f = F[cur]; const out = f.run(copy(prevIm), scaleParams(f, readParams(pane, f.params), k)); g.putImageData(out, 0, 0); stat.textContent = ''; }, 0); }, 100);
    showParams(); render();
    // thumbnails one by one, so the dialog opens at once
    const thumbs = Array.from(d.el.querySelectorAll('.fl-th'));
    (async () => { for (const b of thumbs) { await nextFrame(); if (!b.isConnected) return; const f = F[b.dataset.g]; try { b.querySelector('canvas').getContext('2d').putImageData(f.run(copy(thumbIm), scaleParams(f, defaults(f), kt)), 0, 0); } catch (e) { /* skip */ } } })();
    d.el.addEventListener('click', e => { const b = e.target.closest('[data-g]'); if (!b) return; e.preventDefault(); cur = b.dataset.g; showParams(); render(); });
    pane.addEventListener('input', e => { const el = e.target; if (el.dataset.p && el.type === 'range') { const n = pane.querySelector(`[data-pn="${el.dataset.p}"]`); if (n) n.value = el.value; } if (el.dataset.pn) { const r = pane.querySelector(`[data-p="${el.dataset.pn}"]`); if (r) r.value = el.value; } render(); });
    pane.addEventListener('change', render);
  };

  // ======================================================================
  // LIQUIFY (interactive): forward warp, reconstruct, twirl, pucker, bloat, push left
  // ======================================================================
  FL.liquify = async () => {
    const tg = await ensureTargets();
    if (!tg.length) return;
    const x0 = tg[0], src = x0.get();
    const work = await FL.load(src, 1100), W = work.width, H = work.height;
    const FX = new Float32Array(W * H), FY = new Float32Array(W * H);
    const TOOLS = [['warp', 'Деформація', 'W'], ['recon', 'Реконструкція', 'R'], ['twirl', 'Скручування', 'C'], ['pucker', 'Стиснення', 'S'], ['bloat', 'Роздуття', 'B'], ['push', 'Зсув пікселів', 'O']];
    let tool = 'warp', size = Math.round(Math.min(W, H) / 8), pressure = 50, down = null;
    const root = O.h(`<div class="lq-root" role="dialog" aria-label="${esc(t('Пластика'))}"><div class="lq-top"><b>${esc(t('Пластика'))}</b><span class="sp"></span><button type="button" class="btn" data-lq="reset">${esc(t('Відновити все'))}</button><button type="button" class="btn" data-lq="cancel">${esc(t('Скасувати'))}</button><button type="button" class="btn primary" data-lq="ok">OK</button></div>
      <div class="lq-body"><div class="lq-tools">${TOOLS.map(([id, l, k]) => `<button type="button" class="lq-t${id === tool ? ' on' : ''}" data-tool="lq-${id}" title="${esc(t(l))} (${k})">${esc(t(l))}<kbd>${k}</kbd></button>`).join('')}</div><div class="lq-stage"><canvas></canvas><div class="lq-brush"></div></div>
      <div class="lq-side"><label class="fl-row"><span>${esc(t('Розмір пензля'))}</span><input type="range" data-lqp="size" min="4" max="${Math.round(Math.min(W, H) / 1.5)}" value="${size}"></label><label class="fl-row"><span>${esc(t('Натиск'))}</span><input type="range" data-lqp="pressure" min="1" max="100" value="${pressure}"></label><p class="dlg-text small">${esc(t('[ і ] — розмір пензля. Тягніть по фото, щоб деформувати.'))}</p></div></div></div>`);
    document.body.appendChild(root);
    const cv = root.querySelector('canvas'), g = cv.getContext('2d'), brush = root.querySelector('.lq-brush'), stage = root.querySelector('.lq-stage');
    cv.width = W; cv.height = H;
    const out = new ImageData(W, H), smp = sampler(work);
    const field = (A, x, y) => { x = x < 0 ? 0 : x > W - 1 ? W - 1 : x; y = y < 0 ? 0 : y > H - 1 ? H - 1 : y; const x1 = x | 0, y1 = y | 0, x2 = Math.min(W - 1, x1 + 1), y2 = Math.min(H - 1, y1 + 1), fx = x - x1, fy = y - y1; const a = A[y1 * W + x1] + (A[y1 * W + x2] - A[y1 * W + x1]) * fx, b = A[y2 * W + x1] + (A[y2 * W + x2] - A[y2 * W + x1]) * fx; return a + (b - a) * fy; };
    const draw = (bx0 = 0, by0 = 0, bx1 = W, by1 = H) => {
      const d = out.data;
      for (let y = Math.max(0, by0); y < Math.min(H, by1); y++) for (let x = Math.max(0, bx0); x < Math.min(W, bx1); x++) { const j = y * W + x; smp(x + FX[j], y + FY[j], d, j * 4); }
      g.putImageData(out, 0, 0, Math.max(0, bx0), Math.max(0, by0), Math.min(W, bx1) - Math.max(0, bx0), Math.min(H, by1) - Math.max(0, by0));
    };
    draw();
    const toImg = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * W, (e.clientY - r.top) / r.height * H, r.width / W]; };
    const stroke = (cx, cy, dx, dy) => {
      const R = size / 2, pr = pressure / 100, x0b = Math.floor(cx - R), y0b = Math.floor(cy - R), x1b = Math.ceil(cx + R), y1b = Math.ceil(cy + R);
      const bw = x1b - x0b + 1, bh = y1b - y0b + 1, OX = new Float32Array(bw * bh), OY = new Float32Array(bw * bh);
      for (let y = 0; y < bh; y++) for (let x = 0; x < bw; x++) { const X = x0b + x, Y = y0b + y; if (X < 0 || Y < 0 || X >= W || Y >= H) continue; OX[y * bw + x] = FX[Y * W + X]; OY[y * bw + x] = FY[Y * W + X]; }
      const old = (A, X, Y) => (X >= x0b && Y >= y0b && X <= x1b && Y <= y1b ? (() => { const lx = X - x0b, ly = Y - y0b, xi = Math.max(0, Math.min(bw - 1, Math.round(lx))), yi = Math.max(0, Math.min(bh - 1, Math.round(ly))); return A[yi * bw + xi]; })() : field(A === OX ? FX : FY, X, Y));
      for (let Y = Math.max(0, y0b); Y <= Math.min(H - 1, y1b); Y++) for (let X = Math.max(0, x0b); X <= Math.min(W - 1, x1b); X++) {
        const ddx = X - cx, ddy = Y - cy, dist = Math.hypot(ddx, ddy) / R;
        if (dist >= 1) continue;
        const wgt = (1 - dist * dist) ** 2 * pr, j = Y * W + X;
        let qx = X, qy = Y;
        if (tool === 'warp') { qx = X - dx * wgt; qy = Y - dy * wgt; }
        else if (tool === 'push') { qx = X + dy * wgt; qy = Y - dx * wgt; }
        else if (tool === 'twirl') { const a = -0.06 * wgt * (down && down.alt ? -1 : 1), c = Math.cos(a), s = Math.sin(a); qx = cx + ddx * c - ddy * s; qy = cy + ddx * s + ddy * c; }
        else if (tool === 'pucker') { const f = 1 + 0.05 * wgt; qx = cx + ddx * f; qy = cy + ddy * f; }
        else if (tool === 'bloat') { const f = 1 - 0.05 * wgt; qx = cx + ddx * f; qy = cy + ddy * f; }
        if (tool === 'recon') { FX[j] *= 1 - 0.25 * wgt; FY[j] *= 1 - 0.25 * wgt; continue; }
        FX[j] = old(OX, qx, qy) + (qx - X);
        FY[j] = old(OY, qx, qy) + (qy - Y);
      }
      draw(x0b - 1, y0b - 1, x1b + 2, y1b + 2);
    };
    const showBrush = e => { const r = cv.getBoundingClientRect(), sr = stage.getBoundingClientRect(), k = r.width / W, s = size * k; brush.style.width = brush.style.height = s + 'px'; brush.style.left = (e.clientX - sr.left - s / 2) + 'px'; brush.style.top = (e.clientY - sr.top - s / 2) + 'px'; };
    let raf = 0;
    cv.addEventListener('pointerdown', e => { cv.setPointerCapture(e.pointerId); const [x, y] = toImg(e); down = { x, y, alt: e.altKey }; const tick = () => { if (!down) return; if (['twirl', 'pucker', 'bloat', 'recon'].includes(tool)) stroke(down.x, down.y, 0, 0); raf = requestAnimationFrame(tick); }; tick(); });
    cv.addEventListener('pointermove', e => { showBrush(e); if (!down) return; const [x, y] = toImg(e); if (tool === 'warp' || tool === 'push') stroke(x, y, x - down.x, y - down.y); down.x = x; down.y = y; });
    const up = () => { down = null; cancelAnimationFrame(raf); };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    cv.addEventListener('pointerleave', () => { brush.style.width = '0'; });
    const close = () => { root.remove(); document.removeEventListener('keydown', keys, true); };
    const finish = async () => {
      close();
      const full = await FL.load(src), fw = full.width, fh = full.height, sx = W / fw, sy = H / fh;
      busy(true, t('Пластика'));
      await nextFrame();
      try {
        const res = warp(full, (x, y, o) => { const gx = x * sx, gy = y * sy; o[0] = x + field(FX, gx, gy) / sx; o[1] = y + field(FY, gx, gy) / sy; });
        const a = await FL.toAsset(res, (S.doc.assets[src].name || t('Зображення')) + ' · ' + t('Пластика'));
        tg.forEach(x => { if (!x.holder.origAsset) x.holder.origAsset = x.get(); x.set(a.id, a); });
        FL.last = null;
        O.history.commit('Пластика');
      } finally { busy(false); }
    };
    const keys = e => {
      e.stopPropagation();
      if (e.key === 'Escape') { e.preventDefault(); close(); return; }
      if (e.key === 'Enter') { e.preventDefault(); finish(); return; }
      if (e.key === '[') { size = Math.max(4, Math.round(size / 1.15)); root.querySelector('[data-lqp="size"]').value = size; }
      if (e.key === ']') { size = Math.round(size * 1.15); root.querySelector('[data-lqp="size"]').value = size; }
      const tl = TOOLS.find(x => 'Key' + x[2] === e.code); if (tl && !e.ctrlKey && !e.metaKey) { tool = tl[0]; root.querySelectorAll('.lq-t').forEach(b => b.classList.toggle('on', b.dataset.tool === 'lq-' + tool)); }
    };
    document.addEventListener('keydown', keys, true);
    root.addEventListener('input', e => { if (e.target.dataset.lqp === 'size') size = +e.target.value; if (e.target.dataset.lqp === 'pressure') pressure = +e.target.value; });
    root.addEventListener('click', e => {
      const b = e.target.closest('[data-lq],[data-tool]');
      if (!b) return;
      e.stopPropagation();
      if (b.dataset.tool) { tool = b.dataset.tool.slice(3); root.querySelectorAll('.lq-t').forEach(x => x.classList.toggle('on', x === b)); return; }
      if (b.dataset.lq === 'reset') { FX.fill(0); FY.fill(0); draw(); }
      if (b.dataset.lq === 'cancel') close();
      if (b.dataset.lq === 'ok') finish();
    });
  };

  // ======================================================================
  // VANISHING POINT: drag the four corners onto a plane; the plane is straightened to the whole picture
  // ======================================================================
  FL.vanishing = async () => {
    const tg = await ensureTargets();
    if (!tg.length) return;
    const src = tg[0].get(), prev = await FL.load(src, 1000), W = prev.width, H = prev.height;
    let q = [[W * 0.18, H * 0.2], [W * 0.82, H * 0.14], [W * 0.88, H * 0.86], [W * 0.12, H * 0.8]];
    const root = O.h(`<div class="lq-root" role="dialog" aria-label="${esc(t('Точка сходу'))}"><div class="lq-top"><b>${esc(t('Точка сходу'))}</b><span class="dlg-text small">${esc(t('Перетягніть чотири кути на площину (стіну, документ, вивіску). Вона стане рівним прямокутником на все зображення.'))}</span><span class="sp"></span><label class="chk"><input type="checkbox" class="vp-prev"><span>${esc(t('Попередній перегляд'))}</span></label><button type="button" class="btn" data-lq="cancel">${esc(t('Скасувати'))}</button><button type="button" class="btn primary" data-lq="ok">OK</button></div><div class="lq-body"><div class="lq-stage"><canvas></canvas><svg class="vp-svg"></svg></div></div></div>`);
    document.body.appendChild(root);
    const cv = root.querySelector('canvas'), g = cv.getContext('2d'), svg = root.querySelector('.vp-svg'), pv = root.querySelector('.vp-prev');
    cv.width = W; cv.height = H;
    const straight = (im, quad) => {
      const k = im.width / W, Q = quad.map(([x, y]) => [x * k, y * k]), m = sq2quad(Q), w = im.width, h = im.height;
      return warp(im, (x, y, o) => { const u = x / w, v = y / h, den = m[6] * u + m[7] * v + 1; o[0] = (m[0] * u + m[1] * v + m[2]) / den; o[1] = (m[3] * u + m[4] * v + m[5]) / den; });
    };
    const draw = () => {
      if (pv.checked) g.putImageData(straight(prev, q), 0, 0); else g.putImageData(prev, 0, 0);
      const r = cv.getBoundingClientRect(), s = root.querySelector('.lq-stage').getBoundingClientRect(), k = r.width / W;
      svg.setAttribute('width', s.width); svg.setAttribute('height', s.height);
      const P = q.map(([x, y]) => [r.left - s.left + x * k, r.top - s.top + y * k]);
      svg.innerHTML = pv.checked ? '' : `<polygon points="${P.map(p => p.join(',')).join(' ')}" fill="rgba(13,153,255,.12)" stroke="#0D99FF" stroke-width="2"/>${[0.25, 0.5, 0.75].map(f => { const a = [P[0][0] + (P[1][0] - P[0][0]) * f, P[0][1] + (P[1][1] - P[0][1]) * f], b = [P[3][0] + (P[2][0] - P[3][0]) * f, P[3][1] + (P[2][1] - P[3][1]) * f], c = [P[0][0] + (P[3][0] - P[0][0]) * f, P[0][1] + (P[3][1] - P[0][1]) * f], e = [P[1][0] + (P[2][0] - P[1][0]) * f, P[1][1] + (P[2][1] - P[1][1]) * f]; return `<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#0D99FF" stroke-opacity=".5"/><line x1="${c[0]}" y1="${c[1]}" x2="${e[0]}" y2="${e[1]}" stroke="#0D99FF" stroke-opacity=".5"/>`; }).join('')}${P.map((p, i) => `<rect data-c="${i}" x="${p[0] - 7}" y="${p[1] - 7}" width="14" height="14" fill="#fff" stroke="#0D99FF" stroke-width="2" style="cursor:move"/>`).join('')}`;
    };
    requestAnimationFrame(draw);
    let drag = -1;
    svg.addEventListener('pointerdown', e => { const c = e.target.closest('[data-c]'); if (!c) return; drag = +c.dataset.c; svg.setPointerCapture(e.pointerId); });
    svg.addEventListener('pointermove', e => { if (drag < 0) return; const r = cv.getBoundingClientRect(); q[drag] = [O.clamp((e.clientX - r.left) / r.width * W, 0, W), O.clamp((e.clientY - r.top) / r.height * H, 0, H)]; draw(); });
    svg.addEventListener('pointerup', () => { drag = -1; });
    pv.addEventListener('change', draw);
    window.addEventListener('resize', draw);
    const close = () => { root.remove(); window.removeEventListener('resize', draw); document.removeEventListener('keydown', keys, true); };
    const keys = e => { e.stopPropagation(); if (e.key === 'Escape') { e.preventDefault(); close(); } };
    document.addEventListener('keydown', keys, true);
    root.addEventListener('click', async e => {
      const b = e.target.closest('[data-lq]');
      if (!b) return;
      if (b.dataset.lq === 'cancel') return close();
      close();
      busy(true, t('Точка сходу'));
      try {
        const full = await FL.load(src), res = straight(full, q);
        const a = await FL.toAsset(res, (S.doc.assets[src].name || t('Зображення')) + ' · ' + t('Точка сходу'));
        tg.forEach(x => { if (!x.holder.origAsset) x.holder.origAsset = x.get(); x.set(a.id, a); });
        O.history.commit('Точка сходу');
      } finally { busy(false); }
    });
  };

  // ======================================================================
  // SMART FILTERS in the Design panel
  // ======================================================================
  O.panels.extraSections.push(nodes => {
    if (nodes.length !== 1) return '';
    const tg = FL.targets()[0];
    if (!tg) return '';
    const h = tg.holder;
    const rows = (h.sf || []).map((e, i) => `<div class="sf-row${e.on === false ? ' off' : ''}"><button type="button" class="ib" data-sfa="eye" data-i="${i}" title="${esc(t('Показати/приховати'))}" aria-label="${esc(t('Показати/приховати'))}">${O.icon(e.on === false ? 'eyeoff' : 'eye', 14)}</button><button type="button" class="sf-name" data-sfa="edit" data-i="${i}" title="${esc(t('Змінити параметри'))}">${esc(t((F[e.type] || { name: e.type }).name).replace('…', ''))}</button><button type="button" class="ib" data-sfa="del" data-i="${i}" title="${esc(t('Видалити'))}" aria-label="${esc(t('Видалити'))}">${O.icon('minus', 14)}</button></div>`).join('');
    const body = h.sfSrc
      ? `<div class="sf-list">${rows || `<div class="as-empty small">${esc(t('Фільтрів ще немає: оберіть будь-який у меню «Фільтр».'))}</div>`}</div><div class="row"><button type="button" class="btn" data-sfa="menu">${esc(t('Додати фільтр'))}</button><button type="button" class="btn" data-sfa="restore">${esc(t('Повернути оригінал'))}</button></div>`
      : `<div class="row"><button type="button" class="btn" data-sfa="menu">${esc(t('Фільтр…'))}</button><button type="button" class="btn" data-sfa="smart" title="${esc(t('Фільтри можна буде вимикати й змінювати'))}">${esc(t('Смарт-об’єкт'))}</button>${h.origAsset ? `<button type="button" class="btn" data-sfa="restore">${esc(t('Оригінал'))}</button>` : ''}</div>`;
    return O.ph.sec(h.sfSrc ? 'Смарт-фільтри' : 'Фільтри', body);
  });
  document.addEventListener('click', async e => {
    const b = e.target.closest && e.target.closest('[data-sfa]');
    if (!b) return;
    e.stopPropagation();
    const x = FL.targets()[0];
    if (!x) return;
    const h = x.holder, i = +b.dataset.i, a = b.dataset.sfa;
    if (a === 'menu') { const r = b.getBoundingClientRect(); ui.menu(O.MENUS.find(m => m[0] === 'Фільтр')[1], r.left, r.bottom + 4); return; }
    if (a === 'smart') return FL.convertSmart();
    if (a === 'restore') return FL.restore();
    const entry = (h.sf || [])[i];
    if (!entry) return;
    if (a === 'eye') { entry.on = entry.on === false; busy(true, t('смарт-фільтри')); try { await FL.rerun(x); } finally { busy(false); } O.history.commit('Смарт-фільтр'); }
    if (a === 'del') { h.sf.splice(i, 1); busy(true, t('смарт-фільтри')); try { await FL.rerun(x); } finally { busy(false); } O.history.commit('Видалити смарт-фільтр'); }
    if (a === 'edit') {
      const f = F[entry.type];
      if (!f || !f.params.length) return;
      FL.dialog(entry.type, { targets: [x], p: entry.p, edit: { src: h.sfSrc }, onApply: async p => { entry.p = p; busy(true, t(f.name)); try { await FL.rerun(x); } finally { busy(false); } O.history.commit('Смарт-фільтр'); } });
    }
  }, true);

  // ======================================================================
  // MENU (as in Photoshop)
  // ======================================================================
  const cmd = (id, label, run, keys) => O.cmd(id, label, run, { group: 'Фільтр', keys: keys || [] });
  cmd('flLast', 'Останній фільтр', () => (FL.last ? FL.apply(FL.last.id, FL.last.p) : O.toast('Фільтрів ще не застосовували')), ['Ctrl+Alt+F']);
  O.cmds.get('flLast').enabled = () => !!FL.last;
  cmd('flSmart', 'Перетворити для смарт-фільтрів', () => FL.convertSmart());
  cmd('flNeural', 'Neural Filters…', () => FL.neuralDialog());
  cmd('flGallery', 'Галерея фільтрів…', () => FL.galleryDialog());
  // Photoshop's own shortcuts are taken here (Ctrl+Shift+A — deselect, Ctrl+Alt+V — paste properties…)
  cmd('flWide', 'Адаптивна ширококутна корекція…', () => FL.dialog('wideAngle'));
  cmd('flRaw', 'Фільтр Camera Raw…', () => FL.dialog('cameraRaw'), ['Ctrl+Alt+Shift+R']);
  cmd('flDenoise', 'ШІ-зменшення шуму…', () => FL.dialog('aiDenoise'));
  cmd('flSharpenAI', 'ШІ-різкість…', () => FL.dialog('aiSharpen'));
  cmd('flLens', 'Корекція дисторсії…', () => FL.dialog('lensCorrection'));
  cmd('flLiquify', 'Пластика…', () => FL.liquify(), ['Ctrl+Shift+X']);
  cmd('flVanish', 'Точка сходу…', () => FL.vanishing());
  cmd('flRestore', 'Повернути оригінал зображення', () => FL.restore());
  const groups = ['Шум', 'Рендеринг', 'Різкість', 'Стилізація', 'Оформлення', 'Спотворення', 'Відео', 'Галерея розмиття', 'Розмиття', 'Інше'];
  // submenu labels have keys of their own («Розмиття» is also the layer-blur effect, «Різкість» a filter)
  const GROUP_LABEL = { 'Шум': 'Фільтри шуму', 'Рендеринг': 'Фільтри рендерингу', 'Різкість': 'Фільтри різкості', 'Стилізація': 'Фільтри стилізації', 'Оформлення': 'Фільтри оформлення', 'Спотворення': 'Фільтри спотворення', 'Відео': 'Відеофільтри', 'Галерея розмиття': 'Галерея розмиття', 'Розмиття': 'Фільтри розмиття', 'Інше': 'Інші фільтри' };
  const subs = groups.map(g => ({ label: GROUP_LABEL[g], items: Object.values(F).filter(f => f.group === g).map(f => { cmd('fl:' + f.id, f.name, () => FL.dialog(f.id)); return 'fl:' + f.id; }) }));
  const menu = ['flLast', '-', 'flSmart', '-', 'flNeural', '-', 'flGallery', 'flWide', 'flRaw', 'flDenoise', 'flSharpenAI', 'flLens', 'flLiquify', 'flVanish', '-'].concat(subs, ['-', 'flRestore']);
  // «Фільтр» goes right after «Ефект», as in Illustrator / Photoshop
  const fxIdx = O.MENUS.findIndex(m => m[0] === 'Ефект');
  O.MENUS.splice(fxIdx >= 0 ? fxIdx + 1 : O.MENUS.length - 2, 0, ['Фільтр', menu]);
})();
