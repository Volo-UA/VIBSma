'use strict';
/* VIBSma — typesetting engine (InDesign-style text).
   · character formatting of ranges (n.runs) and paragraph formatting of paragraphs (n.pars) on top of the frame defaults,
     paragraph / character styles (S.doc.pstyles, S.doc.cstyles)
   · text frame columns (n.cols, n.colGap, n.colBal), inset spacing, vertical justification
   · alignment incl. justify last line left / centre / right / all, towards / away from spine; indents, space before / after,
     baseline grid, drop caps, bullets & numbering, tab stops with leaders, right indent tab, indent to here
   · single-line and paragraph composer (Knuth–Plass style), hyphenation, optical margin alignment
   · scale, baseline shift, skew, small caps, superscript / subscript, underline / strikethrough, OpenType features
   · special characters (breaks, markers, variables), footnotes, endnotes, editorial notes, tracked changes
   Layout results are cached per node; O.text.layout keeps its old shape (lines with t / y / w) for other modules. */
(function () {
  const O = window.O, M = O.M, model = O.model, S = O.state;
  const n_ = O.n, esc = O.esc;
  const T = O.text;
  const TS = O.typeset = {};
  const t = (s, v) => O.t(s, v);

  // ---------- special characters ----------
  const CH = TS.CH = {
    colBreak: '\uE001', frameBreak: '\uE002', pageBreak: '\uE003', oddPage: '\uE004', evenPage: '\uE005',
    lineBreak: '\u2028', discLine: '\u200B', softHyphen: '\u00AD', nbHyphen: '\u2011',
    pageNum: '\uE010', indentHere: '\uE011', rightTab: '\uE012', nextPage: '\uE013', prevPage: '\uE014', section: '\uE015', endNested: '\uE016',
    footnote: '\uE030', note: '\uE031', endnote: '\uE032', xref: '\uE040'
  };
  const VAR0 = 0xE100, VAR_CUSTOM = 16;
  const BREAKS = new Set([CH.colBreak, CH.frameBreak, CH.pageBreak, CH.oddPage, CH.evenPage]);
  TS.BUILTIN_VARS = [
    { k: 'created', name: 'Дата створення' }, { k: 'modified', name: 'Дата зміни' }, { k: 'output', name: 'Дата виведення' },
    { k: 'file', name: 'Ім’я файлу' }, { k: 'lastpage', name: 'Номер останньої сторінки' }, { k: 'chapter', name: 'Номер розділу' },
    { k: 'header', name: 'Колонтитул (стиль абзацу)' }
  ];
  TS.varChar = idx => String.fromCharCode(VAR0 + idx);
  TS.customVars = () => (S.doc.tvars = S.doc.tvars || []);
  TS.allVars = () => TS.BUILTIN_VARS.map((v, i) => Object.assign({ idx: i, builtin: true }, v)).concat(TS.customVars().map((v, j) => Object.assign({ idx: VAR_CUSTOM + j }, v)).filter(v => !v.deleted));
  const fmtDate = ms => { try { return new Date(ms).toLocaleDateString(O.lang === 'en' ? 'en-GB' : O.lang); } catch (e) { return new Date(ms).toISOString().slice(0, 10); } };
  const pageFrameOf = n => model.ancestors(n).find(a => a.print) || null;
  TS.varValue = (idx, n) => {
    if (idx < VAR_CUSTOM) {
      const v = TS.BUILTIN_VARS[idx];
      if (!v) return '';
      switch (v.k) {
        case 'created': return fmtDate(S.doc.created || S.doc.createdAt || Date.now());
        case 'modified': return fmtDate(S.doc.modified || S.doc.updatedAt || Date.now());
        case 'output': return fmtDate(Date.now());
        case 'file': return S.doc.name || t('Без назви');
        case 'lastpage': {
          const pg = n && model.pageOf(n);
          if (pg && pg.pub && O.print && O.print.pages) { const ps = O.print.pages(pg); const last = ps[ps.length - 1]; return String(last && last.print && last.print.num !== undefined ? last.print.num : ps.length); }
          return String(S.doc.pages.length);
        }
        case 'chapter': return String(S.doc.chapter || 1);
        case 'header': {
          const sid = S.doc.headerStyle;
          const page = n && pageFrameOf(n);
          if (!sid || !page) return '';
          let found = '';
          model.walk(page.children, x => { if (found) return false; if (x.type === 'text' && x !== n) { if (x.pstyle === sid) found = (x.text || '').split('\n')[0]; else for (const p of x.pars || []) if (p.ps === sid) { found = (x.text || '').slice(p.s).split('\n')[0]; break; } } });
          return found.replace(/[\uE000-\uF8FF]/g, '');
        }
      }
      return '';
    }
    const c = TS.customVars()[idx - VAR_CUSTOM];
    return c && !c.deleted ? String(c.text || '') : '';
  };

  // ---------- attribute sets ----------
  const CHAR_KEYS = TS.CHAR_KEYS = ['font', 'weight', 'italic', 'size', 'ls', 'kern', 'hs', 'vs', 'bs', 'skew', 'tcase', 'smcaps', 'pos', 'under', 'strike', 'color', 'ot', 'lang', 'lh', 'nobreak', 'link'];
  const PARA_KEYS = TS.PARA_KEYS = ['align', 'li', 'ri', 'fi', 'lri', 'spb', 'spa', 'grid', 'dcl', 'dcc', 'shade', 'border', 'hyph', 'composer', 'list', 'tabs'];
  const DEF_PARA = TS.DEF_PARA = { align: 'left', li: 0, ri: 0, fi: 0, lri: 0, spb: 0, spa: 0, grid: 'none', dcl: 0, dcc: 1, shade: null, border: null, hyph: false, composer: 'single', list: null, tabs: null };
  const isSet = v => v !== undefined && v !== null;
  const frameChar = n => ({
    font: n.font || 'Arial', weight: n.weight || 400, italic: !!n.italic, size: n.size || 12, ls: n.ls || 0, kern: n.kern || 'metrics',
    hs: n.hs || 100, vs: n.vs || 100, bs: n.bs || 0, skew: n.skew || 0, tcase: n.tcase || 'none', smcaps: !!n.smcaps, pos: n.pos || 'normal',
    under: /underline/.test(n.deco || ''), strike: /line-through/.test(n.deco || ''), color: null, ot: n.ot || null, lang: n.lang || null,
    lh: n.lh || null, nobreak: !!n.nobreak, link: n.link || null, ins: false, del: false
  });
  TS.frameChar = frameChar;
  const framePara = n => { const p = {}; for (const k of PARA_KEYS) p[k] = isSet(n[k]) ? n[k] : DEF_PARA[k]; return p; };
  TS.framePara = framePara;
  // style props (paragraph / character styles) → partial char / para attributes
  const splitProps = props => {
    const c = {}, p = {};
    for (const k of Object.keys(props || {})) {
      const v = props[k];
      if (k === 'deco') { c.under = /underline/.test(v || ''); c.strike = /line-through/.test(v || ''); }
      else if (k === 'color') { if (v) c.color = v; }
      else if (CHAR_KEYS.includes(k)) { if (v !== undefined) c[k] = v; }
      else if (PARA_KEYS.includes(k)) { if (v !== undefined) p[k] = v; }
    }
    return { c, p };
  };
  TS.splitProps = splitProps;
  const pstyle = id => (S.doc.pstyles || []).find(s => s.id === id);
  const cstyle = id => (S.doc.cstyles || []).find(s => s.id === id);
  TS.pstyle = pstyle; TS.cstyle = cstyle;

  // interned resolved character styles: id = every attribute, key = what changes glyph widths
  const stCache = new Map();
  const intern = o => {
    const id = JSON.stringify(o);
    let st = stCache.get(id);
    if (!st) {
      st = Object.assign({ id, key: JSON.stringify([o.font, o.weight, o.italic, o.size, o.ls, o.kern, o.hs, o.smcaps, o.pos]) }, o);
      if (stCache.size > 8000) stCache.clear();
      stCache.set(id, st);
    }
    return st;
  };
  const ORDER = CHAR_KEYS.concat(['ins', 'del']);
  const mkStyle = (...parts) => {
    const o = {};
    for (const p of parts) if (p) for (const k of ORDER) if (p[k] !== undefined) o[k] = p[k];
    const r = {};
    for (const k of ORDER) r[k] = o[k] === undefined ? null : o[k];
    r.size = Math.max(0.5, +r.size || 12); r.hs = r.hs || 100; r.vs = r.vs || 100; r.ls = r.ls || 0; r.bs = r.bs || 0; r.skew = r.skew || 0; r.weight = r.weight || 400;
    r.italic = !!r.italic; r.smcaps = !!r.smcaps; r.under = !!r.under; r.strike = !!r.strike; r.nobreak = !!r.nobreak; r.ins = !!r.ins; r.del = !!r.del;
    r.pos = r.pos || 'normal'; r.tcase = r.tcase || 'none'; r.kern = r.kern || 'metrics';
    return intern(r);
  };
  TS.mkStyle = mkStyle;
  // own attributes of a run (without range / style reference)
  const runOwn = r => { const o = {}; for (const k of Object.keys(r)) if (k !== 's' && k !== 'e' && k !== 'cs' && k !== 'ps') o[k] = k === 'ins' || k === 'del' ? !!r[k] : r[k]; return o; };

  // ---------- measuring ----------
  const mctx = document.createElement('canvas').getContext('2d');
  const effSize = st => (st.pos === 'sup' || st.pos === 'sub') ? st.size * 0.583 : st.size;
  TS.effSize = effSize;
  const fontCSS = (st, size) => `${st.italic ? 'italic ' : ''}${st.weight || 400} ${n_(size)}px ${T.family(st.font)}`;
  const setFont = st => {
    mctx.font = fontCSS(st, effSize(st));
    if ('fontKerning' in mctx) mctx.fontKerning = st.kern === 'none' ? 'none' : 'normal';
    if ('fontVariantCaps' in mctx) mctx.fontVariantCaps = st.smcaps ? 'small-caps' : 'normal';
  };
  const wcache = new Map();
  const rawW = (st, s) => {
    const k = st.key + '\u0001' + s;
    let w = wcache.get(k);
    if (w === undefined) { setFont(st); w = mctx.measureText(s).width; if (wcache.size > 80000) wcache.clear(); wcache.set(k, w); }
    return w;
  };
  const width = (st, s) => (s ? rawW(st, s) * st.hs / 100 + st.ls * s.length : 0);
  TS.width = width;
  const mcache = new Map();
  const metrics = st => {
    let m = mcache.get(st.key);
    if (!m) {
      setFont(st);
      const mt = mctx.measureText('Hgjy'), sz = effSize(st);
      const cap = mctx.measureText('H').actualBoundingBoxAscent;
      m = { asc: mt.fontBoundingBoxAscent || mt.actualBoundingBoxAscent || sz * 0.8, desc: mt.fontBoundingBoxDescent || mt.actualBoundingBoxDescent || sz * 0.2, cap: cap || sz * 0.7 };
      mcache.set(st.key, m);
    }
    return m;
  };
  const leadOf = st => (st.lh ? st.size * st.lh : st.size * 1.2);

  // ---------- hyphenation (rule based: syllable boundaries, works for Cyrillic and Latin scripts) ----------
  const VOW = /[aeiouyäöüàâæéèêëîïôœùûáíóúýąęěůőűåøаеєиіїоуюяыэё]/i;
  const LET = /\p{L}/u;
  const NO_BEFORE = new Set(['ь', 'ъ', 'Ь', 'Ъ', '\'', '’', 'ʼ']);
  const DIGRAPHS = { uk: ['дж', 'дз'], ru: [], en: ['ch', 'sh', 'th', 'ph', 'ck', 'wh', 'gh', 'ng'], de: ['ch', 'ck', 'sch', 'ph', 'th', 'qu'], pl: ['ch', 'cz', 'dz', 'dż', 'dź', 'rz', 'sz'], fr: ['ch', 'ph', 'gn', 'th'], cs: ['ch'] };
  const hcache = new Map();
  TS.hyphenate = (word, lang) => {
    const key = (lang || '') + '|' + word;
    if (hcache.has(key)) return hcache.get(key);
    const w = Array.from(word), n = w.length, pts = [];
    const lg = String(lang || O.lang || 'uk').slice(0, 2).toLowerCase();
    if (lang !== 'none' && n >= 5) {
      const v = i => i >= 0 && i < n && VOW.test(w[i]);
      const c = i => i >= 0 && i < n && LET.test(w[i]) && !VOW.test(w[i]);
      const dig = (DIGRAPHS[lg] || []).concat(lg === 'uk' || lg === 'ru' ? [] : ['ch']);
      const lower = word.toLowerCase();
      for (let k = 2; k <= n - 2; k++) {
        if (!LET.test(w[k - 1]) || !LET.test(w[k])) continue;
        if (NO_BEFORE.has(w[k])) continue;
        if ((w[k] === 'й' || w[k] === 'Й') && v(k - 1)) continue;
        let left = false, right = false;
        for (let i = 0; i < k; i++) if (v(i)) { left = true; break; }
        for (let i = k; i < n; i++) if (v(i)) { right = true; break; }
        if (!left || !right) continue;
        // keep digraphs together
        const pos = Array.from(lower).slice(0, k).join('').length;
        if (dig.some(d => { for (let s = 1; s < d.length; s++) if (lower.substr(pos - s, d.length) === d) return true; return false; })) continue;
        let ok = false;
        if (v(k - 1) && c(k) && v(k + 1)) ok = true;                         // V-CV
        else if (c(k - 1) && c(k) && (v(k - 2) || (c(k - 2) && v(k - 3)))) ok = true; // VC-CV, VCC-CV
        else if (v(k - 1) && v(k) && lg !== 'en' && lg !== 'de' && lg !== 'fr') ok = true; // V-V (Slavic)
        if (ok) pts.push(k);
      }
    }
    // UTF-16 offsets
    const res = pts.map(k => w.slice(0, k).join('').length);
    if (hcache.size > 20000) hcache.clear();
    hcache.set(key, res);
    return res;
  };

  // ---------- numbering ----------
  const roman = k => { if (k <= 0 || k >= 4000) return String(k); const r = [[1000, 'm'], [900, 'cm'], [500, 'd'], [400, 'cd'], [100, 'c'], [90, 'xc'], [50, 'l'], [40, 'xl'], [10, 'x'], [9, 'ix'], [5, 'v'], [4, 'iv'], [1, 'i']]; let s = ''; for (const [v, l] of r) while (k >= v) { s += l; k -= v; } return s; };
  const alpha = k => { let s = ''; k = Math.max(1, k); while (k > 0) { k--; s = String.fromCharCode(97 + (k % 26)) + s; k = Math.floor(k / 26); } return s; };
  const SYMBOLS = ['*', '†', '‡', '§', '¶', '#'];
  TS.fmtNum = (k, style) => {
    switch (style) {
      case 'roman': return roman(k);
      case 'ROMAN': return roman(k).toUpperCase();
      case 'alpha': return alpha(k);
      case 'ALPHA': return alpha(k).toUpperCase();
      case 'zero': return (k < 10 ? '0' : '') + k;
      case 'symbol': { const s = SYMBOLS[(k - 1) % SYMBOLS.length]; return s.repeat(Math.floor((k - 1) / SYMBOLS.length) + 1); }
      case 'cyr': { const a = 'абвгдежзиклмнопрстуфхцчшщюя'; return a[(k - 1) % a.length]; }
      default: return String(k);
    }
  };
  TS.fnOpts = () => Object.assign({ style: 'arabic', start: 1, size: 80, rule: true, prefix: '', suffix: '', sep: ' ', space: 6 }, S.doc.fnOpts || {});
  TS.enOpts = () => Object.assign({ style: 'arabic', start: 1, title: t('Кінцеві виноски'), size: 90, prefix: '', suffix: '.', sep: ' ' }, S.doc.enOpts || {});
  const countChar = (s, ch, upto) => { let k = 0; const e = upto === undefined ? s.length : upto; for (let i = 0; i < e; i++) if (s[i] === ch) k++; return k; };
  TS.countChar = countChar;
  // footnote / endnote numbers continue through the frames of a threaded story
  const chainBase = (n, ch) => {
    if (!O.print || !O.print.chainOf || !n.next && !TS.isPointed(n)) return 0;
    const chain = O.print.chainOf(n);
    if (!chain) return 0;
    let k = 0;
    for (const x of chain) { if (x === n) break; k += countChar(x.text || '', ch); }
    return k;
  };
  let pointedCache = { v: -1, set: null };
  TS.isPointed = n => {
    const ver = O.history ? O.history.idx + ':' + O.history.stack.length : 0;
    if (pointedCache.v !== ver || !pointedCache.set) {
      const set = new Set();
      for (const pg of S.doc.pages) model.walk(pg.children, x => { if (x.type === 'text' && x.next) set.add(x.next); });
      pointedCache = { v: ver, set };
    }
    return pointedCache.set.has(n.id);
  };

  // ---------- atoms: one per source character (display string, kind, style) ----------
  const isGlue = c => c === ' ' || c === '\u3000' || c === '\u205F' || (c >= '\u2000' && c <= '\u200A' && c !== '\u2007');
  const HANG = { '"': 1, '\'': 1, '“': 1, '”': 1, '„': 1, '«': 1, '»': 1, '‘': 1, '’': 1, '‹': 0.8, '›': 0.8, '.': 1, ',': 1, '-': 0.75, '–': 0.6, '—': 0.4, ':': 0.5, ';': 0.5, '!': 0.2, '?': 0.2, '(': 0.3, ')': 0.3 };
  const caseOf = (st, c, prev) => {
    if (st.tcase === 'upper') { const u = c.toUpperCase(); return u.length === 1 ? u : c; }
    if (st.tcase === 'lower') { const u = c.toLowerCase(); return u.length === 1 ? u : c; }
    if (st.tcase === 'title' && (!prev || /\s/.test(prev))) { const u = c.toUpperCase(); return u.length === 1 ? u : c; }
    return c;
  };

  // ---------- run helpers ----------
  const sortRuns = list => (list || []).filter(r => r && r.e > r.s).slice().sort((a, b) => a.s - b.s);
  const propsEqual = (a, b) => { const ka = Object.keys(a).filter(k => k !== 's' && k !== 'e'), kb = Object.keys(b).filter(k => k !== 's' && k !== 'e'); if (ka.length !== kb.length) return false; return ka.every(k => JSON.stringify(a[k]) === JSON.stringify(b[k])); };
  TS.normRuns = list => {
    const out = [];
    for (const r of sortRuns(list)) {
      if (!Object.keys(r).some(k => k !== 's' && k !== 'e')) continue;
      const last = out[out.length - 1];
      if (last && last.e >= r.s && propsEqual(last, r)) { last.e = Math.max(last.e, r.e); continue; }
      out.push(Object.assign({}, r));
    }
    return out;
  };
  // set props on [a, b) (null removes an override); removeKeys are dropped inside the range
  TS.applyRange = (n, field, a, b, props, removeKeys) => {
    if (b <= a) return;
    const runs = sortRuns(n[field]);
    const out = [];
    let cur = a;
    const mids = [];
    for (const r of runs) {
      if (r.e <= a || r.s >= b) { out.push(Object.assign({}, r)); continue; }
      if (r.s < a) out.push(Object.assign({}, r, { e: a }));
      if (r.e > b) out.push(Object.assign({}, r, { s: b }));
      const s = Math.max(r.s, a), e = Math.min(r.e, b);
      if (s > cur) mids.push({ s: cur, e: s });
      mids.push(Object.assign({}, r, { s, e }));
      cur = Math.max(cur, e);
    }
    if (cur < b) mids.push({ s: cur, e: b });
    for (const m of mids) {
      for (const k of Object.keys(props || {})) { if (props[k] === null || props[k] === undefined) delete m[k]; else m[k] = props[k]; }
      for (const k of removeKeys || []) delete m[k];
      out.push(m);
    }
    const res = TS.normRuns(out);
    if (res.length) n[field] = res; else delete n[field];
  };
  TS.stripKey = (n, field, keys) => {
    if (!n[field]) return;
    for (const r of n[field]) for (const k of keys) delete r[k];
    const res = TS.normRuns(n[field]);
    if (res.length) n[field] = res; else delete n[field];
  };
  // delete [p, p + del) and insert ins characters at p
  const shiftRuns = (list, p, del, ins) => {
    if (!list) return list;
    const out = [];
    for (const r0 of list) {
      const r = Object.assign({}, r0);
      if (del) { const f = x => (x <= p ? x : x >= p + del ? x - del : p); r.s = f(r.s); r.e = f(r.e); }
      if (ins) {
        if (r.s > p || (r.s === p && p > 0)) { r.s += ins; r.e += ins; }
        else if (r.s < p && r.e >= p) r.e += ins;
        else if (r.s === 0 && p === 0) r.e += ins;
      }
      if (r.e > r.s) out.push(r);
    }
    return out;
  };
  TS.sliceRuns = (list, a, b) => sortRuns(list).filter(r => r.e > a && r.s < b).map(r => Object.assign({}, r, { s: Math.max(r.s, a) - a, e: Math.min(r.e, b) - a }));
  TS.offsetRuns = (list, d) => (list || []).map(r => Object.assign({}, r, { s: r.s + d, e: r.e + d }));
  const runAt = (list, i) => { if (!list) return null; for (const r of list) if (r.s <= i && i < r.e) return r; return null; };
  TS.runAt = runAt;

  // keeps runs, paragraph overrides, notes and tracked changes consistent with a text edit
  // returns { text, caret } when tracked changes rewrote the text
  TS.textChanged = (n, oldT, newT, info = {}) => {
    if (oldT === newT) return null;
    let p = 0;
    const lim = Math.min(oldT.length, newT.length);
    while (p < lim && oldT[p] === newT[p]) p++;
    let q = 0;
    while (q < lim - p && oldT[oldT.length - 1 - q] === newT[newT.length - 1 - q]) q++;
    let del = oldT.length - q - p, insStr = newT.slice(p, newT.length - q);
    // repeated characters make the diff ambiguous: a typed / deleted run ends (starts) at the caret
    const d = newT.length - oldT.length;
    if (info.caret !== undefined && info.caret !== null) {
      const c = info.caret;
      if (d > 0 && del === 0 && c - d >= 0 && c - d < p && newT.slice(0, c - d) === oldT.slice(0, c - d) && newT.slice(c) === oldT.slice(c - d)) { p = c - d; del = 0; insStr = newT.slice(p, c); }
      else if (d < 0 && !insStr && c < p && newT.slice(0, c) === oldT.slice(0, c) && oldT.slice(c - d) === newT.slice(c)) { p = c; del = -d; insStr = ''; }
    }
    const removed = oldT.slice(p, p + del);
    // notes: drop entries whose markers were removed, add empty ones for pasted markers
    for (const [ch, field] of [[CH.footnote, 'fnotes'], [CH.endnote, 'enotes'], [CH.note, 'notes']]) {
      const kd = countChar(removed, ch), ki = countChar(insStr, ch);
      if (!kd && !ki) continue;
      const arr = n[field] = n[field] || [];
      const k0 = countChar(oldT, ch, p);
      const add = [];
      for (let i = 0; i < ki; i++) add.push(info.notes && info.notes[i] ? info.notes[i] : { text: '' });
      arr.splice(k0, kd, ...add);
      if (!arr.length) delete n[field];
    }
    const tracking = (n.track || S.doc.trackAll) && !info.noTrack;
    let keep = '', keepIdx = [];
    if (tracking && del) {
      for (let i = 0; i < removed.length; i++) { const r = runAt(n.runs, p + i); if (!(r && r.ins)) { keep += removed[i]; keepIdx.push(p + i); } }
    }
    const keepRuns = keepIdx.map(i => { const r = runAt(n.runs, i); return r ? runOwn(r) : {}; });
    if (n.runs) n.runs = shiftRuns(n.runs, p, del, insStr.length + keep.length);
    if (n.pars) n.pars = shiftRuns(n.pars, p, del, insStr.length + keep.length);
    if (n.runs && !n.runs.length) delete n.runs;
    if (n.pars && !n.pars.length) delete n.pars;
    // typing with a pending caret format (format chosen with no selection)
    if (insStr.length && S.textEdit && S.textEdit.pending && S.textEdit.id === n.id) TS.applyRange(n, 'runs', p, p + insStr.length, S.textEdit.pending);
    if (tracking) {
      const stamp = { a: S.doc.author || O.ls.get('collabName', '') || t('Я'), t: Date.now() };
      if (insStr.length) TS.applyRange(n, 'runs', p, p + insStr.length, { ins: stamp }, ['del']);
      keepRuns.forEach((r, i) => { const at = p + insStr.length + i; TS.applyRange(n, 'runs', at, at + 1, Object.assign({}, r, { del: stamp }), ['ins']); });
      if (keep) {
        const text = oldT.slice(0, p) + insStr + keep + oldT.slice(p + del);
        const caret = p + insStr.length + (info.inputType === 'deleteContentForward' ? keep.length : 0);
        return { text, caret };
      }
    }
    return null;
  };
  TS.acceptChanges = (n, accept) => {
    const runs = sortRuns(n.runs);
    const drop = [];
    for (const r of runs) if ((accept && r.del) || (!accept && r.ins)) drop.push([r.s, r.e]);
    drop.sort((a, b) => b[0] - a[0]);
    for (const [a, b] of drop) {
      const old = n.text;
      n.text = old.slice(0, a) + old.slice(b);
      TS.textChanged(n, old, n.text, { noTrack: true });
    }
    TS.stripKey(n, 'runs', ['ins', 'del']);
    return drop.length;
  };
  TS.hasChanges = n => (n.runs || []).some(r => r.ins || r.del);

  // ---------- paragraph source ----------
  const paragraphsOf = text => {
    const out = [];
    let s = 0;
    for (;;) { const e = text.indexOf('\n', s); if (e < 0) { out.push([s, text.length]); break; } out.push([s, e]); s = e + 1; }
    return out;
  };
  TS.paragraphsOf = paragraphsOf;
  TS.paraRange = (text, a, b) => {
    const ps = text.lastIndexOf('\n', a - 1) + 1;
    let pe = text.indexOf('\n', Math.max(a, b - (b > a ? 1 : 0)));
    if (pe < 0) pe = text.length;
    return [ps, pe];
  };

  // resolved paragraph attributes + paragraph-level character base for the paragraph starting at ps
  const resolvePara = (n, ps, base) => {
    const P = framePara(n);
    let cbase = base;
    const pr = runAt(n.pars, ps) || (ps === (n.text || '').length ? (n.pars || []).find(r => r.s === ps) : null);
    let psId = null;
    if (pr) {
      if (pr.ps) { const st = pstyle(pr.ps); psId = pr.ps; if (st) { const sp = splitProps(st.props); Object.assign(P, sp.p); cbase = Object.assign({}, base, sp.c); } }
      for (const k of PARA_KEYS) if (pr[k] !== undefined) P[k] = pr[k];
    }
    P.ps = psId;
    return { P, cbase };
  };
  TS.resolvePara = resolvePara;
  // resolved character style at index i (for the panel)
  // preferPrev: a caret takes the format of the character before it (that is what typing continues)
  TS.charAt = (n, i, preferPrev) => {
    const text = n.text || '';
    i = Math.max(0, Math.min(i, text.length));
    const [ps] = TS.paraRange(text, i, i);
    const { cbase } = resolvePara(n, ps, frameChar(n));
    const r = preferPrev && i > ps ? runAt(n.runs, i - 1) : (runAt(n.runs, i) || (i > 0 && i >= text.length ? runAt(n.runs, i - 1) : null));
    let st = cbase;
    if (r) { const cs = r.cs && cstyle(r.cs); st = Object.assign({}, cbase, cs ? splitProps(cs.props).c : {}, runOwn(r)); }
    return mkStyle(st);
  };

  // atoms of a paragraph [ps, pe) of node n
  const buildAtoms = (n, ps, pe, cbase, env) => {
    const text = n.text || '';
    const runs = env.runs;
    const atoms = [];
    let ri = 0;
    while (ri < runs.length && runs[ri].e <= ps) ri++;
    let lastRun = undefined, lastSt = null;
    for (let i = ps; i < pe; i++) {
      while (ri < runs.length && runs[ri].e <= i) ri++;
      const r = ri < runs.length && runs[ri].s <= i ? runs[ri] : null;
      let st;
      if (r === lastRun && lastSt) st = lastSt;
      else {
        if (r) { const cs = r.cs && cstyle(r.cs); st = mkStyle(cbase, cs ? splitProps(cs.props).c : null, runOwn(r)); }
        else st = mkStyle(cbase);
        lastRun = r; lastSt = st;
      }
      const c = text[i];
      const a = { i, d: '', k: 'ch', st };
      if (st.del && !env.showChanges) { a.k = 'zw'; atoms.push(a); continue; }
      if (c === '\t') a.k = 'tab';
      else if (isGlue(c)) { a.k = st.nobreak ? 'ch' : 'g'; a.d = c; }
      else if (c === CH.softHyphen) a.k = 'soft';
      else if (c === CH.discLine) a.k = 'zwb';
      else if (c === CH.lineBreak) a.k = 'lb';
      else if (c === CH.colBreak) a.k = 'col';
      else if (BREAKS.has(c)) a.k = 'frame';
      else if (c === CH.indentHere) a.k = 'ith';
      else if (c === CH.rightTab) a.k = 'rtab';
      else if (c === CH.endNested) a.k = 'zw';
      else if (c === CH.pageNum || (c === '#' && n.autoNum)) { a.d = '#'; a.pn = 'cur'; }
      else if (c === CH.nextPage || c === CH.prevPage) { a.d = '#'; a.pn = c === CH.nextPage ? 'next' : 'prev'; }
      else if (c === CH.section) a.d = String(S.doc.section || '');
      else if (c === CH.footnote) { env.fn++; a.d = TS.fmtNum(env.fnBase + env.fn, env.fno.style); a.st = mkStyle(st, { pos: 'sup' }); a.fn = env.fn - 1; }
      else if (c === CH.endnote) { env.en++; a.d = TS.fmtNum(env.enBase + env.en, env.eno.style); a.st = mkStyle(st, { pos: 'sup' }); a.en = env.en - 1; }
      else if (c === CH.note) { a.k = 'zw'; a.note = env.note++; }
      else if (c === CH.xref) a.d = TS.xrefText(r && r.xref);
      else if (c >= '\uE100' && c <= '\uE1FF') a.d = TS.varValue(c.charCodeAt(0) - VAR0, n);
      else if (c >= '\uE000' && c <= '\uF8FF') a.k = 'zw';
      else a.d = caseOf(st, c, i > ps ? text[i - 1] : null);
      atoms.push(a);
    }
    return atoms;
  };
  // atoms of generated (virtual) text: footnotes, endnotes, labels
  const virtualAtoms = (str, st) => Array.from(str).map(c => ({ i: -1, d: isGlue(c) ? c : c, k: c === '\t' ? 'tab' : isGlue(c) ? 'g' : 'ch', st }));

  // cross reference text
  TS.xrefText = x => {
    if (!x) return '[?]';
    const tg = model.get(x.id);
    if (!tg) return t('[джерело відсутнє]');
    if (x.fmt === 'page') {
      const pf = pageFrameOf(tg);
      return pf && pf.print && pf.print.num !== undefined ? String(pf.print.num) : (model.pageOf(tg) ? model.pageOf(tg).name : '?');
    }
    const para = (tg.text || '').split('\n')[x.para || 0] || '';
    const txt = para.replace(/[\uE000-\uF8FF\u00AD\u200B]/g, '').trim();
    if (x.fmt === 'both') { const pf = pageFrameOf(tg); return `«${txt}»${pf && pf.print ? ', ' + t('с.') + ' ' + pf.print.num : ''}`; }
    return txt;
  };

  // ---------- boxes (unbreakable units) ----------
  const groupW = atoms => {
    let w = 0, s = '', st = null;
    for (const a of atoms) {
      if (a.st !== st) { if (s) w += width(st, s); s = ''; st = a.st; }
      s += a.d;
    }
    if (s) w += width(st, s);
    return w;
  };
  TS.groupW = groupW;
  const FORCED = new Set(['lb', 'col', 'frame']);
  const makeBoxes = (atoms, P) => {
    const boxes = [];
    let cur = null;
    const flush = () => { if (cur && cur.atoms.length) { cur.w = groupW(cur.atoms); boxes.push(cur); } cur = null; };
    const word = () => { if (!cur) cur = { k: 'w', atoms: [], brk: null }; return cur; };
    for (let j = 0; j < atoms.length; j++) {
      const a = atoms[j];
      if (a.k === 'g') { flush(); boxes.push({ k: 'g', atoms: [a], w: width(a.st, a.d), nb: false }); continue; }
      if (a.k === 'tab' || a.k === 'rtab' || a.k === 'ith' || FORCED.has(a.k)) { flush(); boxes.push({ k: a.k, atoms: [a], w: 0 }); continue; }
      const b = word();
      b.atoms.push(a);
      if (a.k === 'soft') { b.brk = 'hy'; b.hyW = width(a.st, '-'); flush(); continue; }
      if (a.k === 'zwb') { b.brk = 'zw'; flush(); continue; }
      if ((a.d === '-' || a.d === '–' || a.d === '—' || a.d === '/') && b.atoms.length > 1 && !a.st.nobreak) {
        const nx = atoms[j + 1];
        if (nx && nx.k === 'ch' && nx.d && LET.test(nx.d)) { b.brk = 'dash'; flush(); continue; }
      }
    }
    flush();
    // hyphenation points inside words
    if (P.hyph) {
      const out = [];
      for (const b of boxes) {
        if (b.k !== 'w' || b.atoms.length < 5 || b.atoms.some(a => a.st.nobreak || a.i < 0)) { out.push(b); continue; }
        const str = b.atoms.map(a => a.d).join('');
        const lead = (/^[^\p{L}]*/u.exec(str) || [''])[0].length, trail = (/[^\p{L}]*$/u.exec(str) || [''])[0].length;
        const core = str.slice(lead, str.length - trail);
        if (core.length < 5 || !/^\p{L}+$/u.test(core) || b.atoms.length !== str.length) { out.push(b); continue; }
        const pts = TS.hyphenate(core, b.atoms[0].st.lang || P.lang);
        if (!pts.length) { out.push(b); continue; }
        let from = 0;
        for (const p of pts) {
          const cut = lead + p;
          const atomsPart = b.atoms.slice(from, cut);
          out.push({ k: 'w', atoms: atomsPart, w: groupW(atomsPart), brk: 'hy', hyW: width(atomsPart[atomsPart.length - 1].st, '-'), auto: true });
          from = cut;
        }
        const rest = b.atoms.slice(from);
        out.push({ k: 'w', atoms: rest, w: groupW(rest), brk: b.brk, hyW: b.hyW });
      }
      return out;
    }
    return boxes;
  };
  const splitBox = (b, room) => {
    if (b.atoms.length < 2) return null;
    let k = 1;
    for (let m = 2; m < b.atoms.length; m++) { if (groupW(b.atoms.slice(0, m)) <= room) k = m; else break; }
    const a1 = b.atoms.slice(0, k), a2 = b.atoms.slice(k);
    return [{ k: 'w', atoms: a1, w: groupW(a1), brk: null }, { k: 'w', atoms: a2, w: groupW(a2), brk: b.brk, hyW: b.hyW }];
  };

  // ---------- line breaking ----------
  const DEF_TAB = 36;
  const tabWidth = (b, absX, boxes, j, C) => {
    // width of the text that follows the tab (up to the next tab / break)
    let segW = 0, before = -1;
    for (let k = j + 1; k < boxes.length; k++) {
      const x = boxes[k];
      if (x.k === 'tab' || x.k === 'rtab' || FORCED.has(x.k)) break;
      if (before < 0 && x.atoms) { for (const a of x.atoms) { if (a.d === '.' || a.d === ',') { before = segW + groupW(x.atoms.slice(0, x.atoms.indexOf(a))); break; } } }
      segW += x.w || 0;
    }
    if (b.k === 'rtab') return Math.max(0, C.lineEnd - absX - segW);
    const stops = (C.P.tabs || []).filter(s => s.x > absX + 0.01).sort((a, c) => a.x - c.x);
    const st = stops[0];
    if (!st) { const nx = Math.floor(absX / DEF_TAB + 1e-6) * DEF_TAB + DEF_TAB; b.leader = null; return Math.max(0, nx - absX); }
    b.leader = st.l || null;
    if (st.a === 'right') return Math.max(0, st.x - absX - segW);
    if (st.a === 'center') return Math.max(0, st.x - absX - segW / 2);
    if (st.a === 'dec') return Math.max(0, st.x - absX - (before >= 0 ? before : segW));
    return st.x - absX;
  };
  const greedy = (boxes, C) => {
    const lines = [];
    let i = 0, ln = 0, ith = 0, afterForced = true;
    for (;;) {
      const lead = [];
      if (!afterForced) while (i < boxes.length && boxes[i].k === 'g') { lead.push(boxes[i]); i++; }
      if (lead.length && lines.length) lines[lines.length - 1].tail = (lines[lines.length - 1].tail || []).concat(lead);
      const A = C.avail(ln, ith), x0 = C.start(ln, ith);
      let x = 0, cand = null, end = null, newIth = null;
      for (let j = i; j < boxes.length; j++) {
        const b = boxes[j];
        if (FORCED.has(b.k)) { end = { end: j, next: j + 1, forced: b.k, fb: b }; break; }
        if (b.k === 'g') { cand = { end: j, next: j + 1 }; x += b.w; continue; }
        let w = b.w;
        if (b.k === 'tab' || b.k === 'rtab') { w = b.tw = tabWidth(b, x0 + x, boxes, j, Object.assign({ lineEnd: x0 + A }, C)); }
        if (b.k === 'ith') newIth = (x0 + x) - C.start(1, 0);
        if (x + w > A + 0.01) {
          if (cand) { end = cand; break; }
          if (j === i) {
            const parts = b.k === 'w' ? splitBox(b, A - x) : null;
            if (parts) boxes.splice(j, 1, parts[0], parts[1]);
            end = { end: j + 1, next: j + 1 };
            break;
          }
          end = { end: j, next: j }; break;
        }
        x += w;
        if (b.brk) { const hw = b.brk === 'hy' ? b.hyW : 0; if (x + hw <= A + 0.01) cand = { end: j + 1, next: j + 1, hy: b.brk === 'hy' }; }
        if (b.k === 'tab' || b.k === 'rtab') cand = { end: j + 1, next: j + 1 };
      }
      if (!end) end = { end: boxes.length, next: boxes.length, last: true };
      if (!end.forced && end.next >= boxes.length) end.last = true;
      const line = { from: i, to: end.end, hy: !!end.hy, forced: end.forced || null, fb: end.fb || null, ln, ith, last: !!end.last };
      const gl = boxes.slice(end.end, end.next).filter(b => b.k === 'g');
      if (gl.length) line.tail = gl;
      lines.push(line);
      if (end.last) break;
      i = end.next; ln++;
      if (newIth !== null) ith = Math.max(0, newIth);
      afterForced = !!end.forced;
      if (lines.length > 20000) break;
    }
    return lines;
  };
  // paragraph composer: minimise the total badness of all lines of a paragraph (no tabs / indent to here)
  const compose = (boxes, C, justified) => {
    if (boxes.some(b => b.k === 'tab' || b.k === 'rtab' || b.k === 'ith')) return null;
    const lines = [];
    let start = 0, ln = 0;
    const K = Math.max(1, C.P.dcl || 0) + 1;
    for (;;) {
      let segEnd = start;
      while (segEnd < boxes.length && !FORCED.has(boxes[segEnd].k)) segEnd++;
      // candidates
      const cands = [];
      for (let j = start; j < segEnd; j++) {
        const b = boxes[j];
        if (b.k === 'g') cands.push({ end: j, next: j + 1 });
        else if (b.brk) cands.push({ end: j + 1, next: j + 1, hy: b.brk === 'hy', hyW: b.hyW || 0 });
      }
      cands.push({ end: segEnd, next: segEnd, fin: true });
      if (cands.length > 4000) return null;
      const pw = [0];
      for (let j = start; j < segEnd; j++) pw.push(pw[pw.length - 1] + boxes[j].w);
      const W = (s, e) => pw[e - start] - pw[s - start];
      const glueIn = (s, e) => { let k = 0, sw = 0; for (let j = s; j < e; j++) if (boxes[j].k === 'g') { k++; sw += boxes[j].w; } return { k, sw }; };
      // dp over (candidate, capped line number)
      const best = new Map();
      const keyOf = (ci, l) => ci * 16 + Math.min(l, K);
      const startState = { ci: -1, l: ln, dem: 0, prev: null, next: start };
      for (let ci = -1; ci < cands.length; ci++) {
        const here = ci < 0 ? [startState] : [];
        if (ci >= 0) for (let l = 0; l <= K; l++) { const s = best.get(keyOf(ci, l)); if (s && !here.includes(s)) here.push(s); }
        for (const st of here) {
          if (ci >= 0 && cands[ci].fin) continue;
          let s = st.next;
          if (st.ci >= 0) while (s < segEnd && boxes[s].k === 'g') s++;
          let any = false;
          for (let cj = ci + 1; cj < cands.length; cj++) {
            const c = cands[cj];
            if (c.end <= s && !c.fin) continue;
            const lineNo = st.l;
            const A = C.avail(lineNo, 0);
            const w = W(s, Math.max(s, c.end)) + (c.hy ? c.hyW : 0);
            if (w > A + 0.01 && any) break;
            let bad;
            if (w > A + 0.01) bad = 1e6;
            else if (c.fin) bad = 0;
            else if (justified) { const g = glueIn(s, c.end); const stretch = Math.max(g.sw * 0.6, 0.5); const r = (A - w) / stretch; bad = Math.min(1e4, 100 * r * r * r); }
            else { const em = Math.max(1, (C.P.em || 12)); const r = (A - w) / (em * 3); bad = Math.min(1e4, 50 * r * r); }
            const dem = st.dem + (1 + bad) * (1 + bad) + (c.hy ? 2500 : 0) + (c.hy && st.hy ? 3000 : 0);
            const k = keyOf(cj, lineNo + 1);
            const old = best.get(k);
            if (!old || dem < old.dem) best.set(k, { ci: cj, l: lineNo + 1, dem, prev: st, c, from: s, hy: !!c.hy, next: c.next });
            any = true;
            if (w > A + 0.01) break;
          }
        }
      }
      let fin = null;
      for (const [, s] of best) if (cands[s.ci].fin && (!fin || s.dem < fin.dem)) fin = s;
      if (!fin) return null;
      const seg = [];
      for (let s = fin; s && s.prev; s = s.prev) seg.unshift({ from: s.from, to: s.c.end, hy: s.hy, forced: null, ln: 0, ith: 0, last: false });
      seg.forEach((l, k) => { l.ln = ln + k; });
      // glue skipped at line starts belongs to the previous line (caret positions)
      for (let k = 1; k < seg.length; k++) { const prevEnd = seg[k - 1].to; const tail = boxes.slice(prevEnd, seg[k].from).filter(b => b.k === 'g'); if (tail.length) seg[k - 1].tail = tail; }
      lines.push(...seg);
      ln += seg.length;
      if (segEnd >= boxes.length) { if (lines.length) lines[lines.length - 1].last = true; break; }
      lines[lines.length - 1].forced = boxes[segEnd].k;
      lines[lines.length - 1].fb = boxes[segEnd];
      start = segEnd + 1;
      if (start >= boxes.length) { lines.push({ from: start, to: start, hy: false, forced: null, ln, ith: 0, last: true }); break; }
    }
    return lines;
  };

  // ---------- main layout ----------
  const lcache = new Map();
  const FRAME_KEYS = ['font', 'weight', 'italic', 'size', 'ls', 'kern', 'hs', 'vs', 'bs', 'skew', 'tcase', 'smcaps', 'pos', 'deco', 'ot', 'lang', 'lh', 'nobreak', 'link',
    'align', 'li', 'ri', 'fi', 'lri', 'spb', 'spa', 'grid', 'dcl', 'dcc', 'shade', 'border', 'hyph', 'composer', 'list', 'tabs',
    'width', 'boxH', 'cols', 'colGap', 'colBal', 'inset', 'valign', 'optical', 'autoNum', 'fnotes', 'enotes', 'notes'];
  const signature = n => {
    const parts = [n.text || '', n.runs || null, n.pars || null];
    for (const k of FRAME_KEYS) parts.push(n[k] === undefined ? null : n[k]);
    const text = n.text || '';
    if (n.runs || n.pars) parts.push(S.doc.pstyles || null, S.doc.cstyles || null);
    if (/[\uE000-\uF8FF]/.test(text)) {
      parts.push(S.doc.fnOpts || null, S.doc.enOpts || null, S.doc.tvars || null, S.doc.name || '', S.doc.headerStyle || null, fmtDate(Date.now()), !!n.next, TS.isPointed(n));
      if (text.indexOf(CH.xref) >= 0) for (const r of n.runs || []) if (r.xref) { const tg = model.get(r.xref.id); parts.push(tg ? (tg.text || '').slice(0, 400) : null); }
      if (/[\uE100-\uE1FF]/.test(text)) for (let c = 0; c < 24; c++) if (text.indexOf(String.fromCharCode(VAR0 + c)) >= 0) parts.push(TS.varValue(c, n));
      if (TS.isPointed(n) || n.next) parts.push(chainBase(n, CH.footnote), chainBase(n, CH.endnote));
    }
    if (S.settings.showChanges && n.runs) parts.push('chg');
    if (gridUsed(n)) parts.push(gridEnv(n));
    if (isSpine(n)) parts.push(sideOf(n));
    return JSON.stringify(parts);
  };
  const gridUsed = n => (isSet(n.grid) && n.grid !== 'none') || (n.pars || []).some(p => p.grid && p.grid !== 'none') || (n.pars || []).some(p => p.ps && (pstyle(p.ps) || { props: {} }).props.grid && pstyle(p.ps).props.grid !== 'none');
  const gridEnv = n => {
    const pg = model.pageOf(n);
    const bl = (pg && pg.pub && pg.pub.baseline) || S.doc.baseline || { step: 12, start: 0 };
    const page = pageFrameOf(n);
    const Pm = page ? M.inv(model.worldMatrix(page)) : M.id();
    const o = M.apply(M.mul(Pm, model.worldMatrix(n)), { x: 0, y: 0 });
    return { step: bl.step, start: bl.start, oy: Math.round(o.y * 1000) / 1000 };
  };
  const isSpine = n => n.align === 'spine' || n.align === 'away' || (n.pars || []).some(p => p.align === 'spine' || p.align === 'away');
  const sideOf = n => { const pf = pageFrameOf(n); return pf && pf.print && pf.print.side === 'left' ? 'left' : 'right'; };

  TS.layout = n => {
    const key = signature(n);
    const hit = lcache.get(n.id);
    if (hit && hit.key === key) return hit.L;
    let L;
    try { L = compute(n); } catch (e) { console.error(e); L = { lines: [], all: [], frags: [], w: 1, h: 1, lh: n.size * 1.2, asc: n.size * 0.8, shades: [], decos: [], overset: false, fitEnd: (n.text || '').length }; }
    lcache.set(n.id, { key, L });
    if (lcache.size > 3000) lcache.delete(lcache.keys().next().value);
    return L;
  };
  // layout of other text in the same frame (threading: what fits)
  TS.layoutWith = (n, text, runs, pars) => compute(Object.assign({}, n, { text, runs: runs && runs.length ? runs : undefined, pars: pars && pars.length ? pars : undefined }), true);

  function compute(n, temp) {
    const text = n.text || '';
    const auto = n.width === null || n.width === undefined;
    const ins = Array.isArray(n.inset) ? n.inset : [0, 0, 0, 0];
    const [it, ir, ib, il] = ins.map(v => +v || 0);
    const cols = auto ? 1 : Math.max(1, Math.min(99, Math.round(n.cols || 1)));
    const gap = cols > 1 ? (isSet(n.colGap) ? +n.colGap : 12) : 0;
    const innerW = auto ? Infinity : Math.max(1, n.width - il - ir);
    let colW = auto ? Infinity : Math.max(1, (innerW - gap * (cols - 1)) / cols);
    const base = frameChar(n);
    const st0 = mkStyle(base);
    const env = {
      runs: sortRuns(n.runs), showChanges: !!S.settings.showChanges, fn: 0, en: 0, note: 0,
      fno: TS.fnOpts(), eno: TS.enOpts(), fnBase: 0, enBase: 0
    };
    if (!temp && (text.indexOf(CH.footnote) >= 0 || text.indexOf(CH.endnote) >= 0)) { env.fnBase = chainBase(n, CH.footnote) + env.fno.start - 1; env.enBase = chainBase(n, CH.endnote) + env.eno.start - 1; }
    else { env.fnBase = env.fno.start - 1; env.enBase = env.eno.start - 1; }
    const side = isSpine(n) ? sideOf(n) : 'right';
    // ---- paragraphs → lines ----
    const paras = paragraphsOf(text).map(([ps, pe]) => ({ ps, pe, virtual: false }));
    // endnotes at the end of the story (last frame of a chain)
    const enList = n.enotes || [];
    const enCount = countChar(text, CH.endnote);
    if (enCount && !n.next && !temp) {
      const total = enCount + (TS.isPointed(n) ? chainBase(n, CH.endnote) : 0);
      void total;
      paras.push({ virtual: true, str: env.eno.title, st: mkStyle(base, { weight: 700, size: base.size * 1.1 }), P: Object.assign(framePara(n), { align: 'left', spb: base.size, fi: 0, list: null, dcl: 0 }) });
      for (let k = 0; k < enCount; k++) {
        const e = enList[k] || { text: '' };
        paras.push({ virtual: true, str: env.eno.prefix + TS.fmtNum(env.enBase + k + 1, env.eno.style) + env.eno.suffix + '\t' + (e.text || ''), st: mkStyle(base, { size: base.size * env.eno.size / 100 }), P: Object.assign(framePara(n), { align: 'left', fi: -base.size * 1.6, li: base.size * 1.6, tabs: [{ x: base.size * 1.6, a: 'left' }], list: null, dcl: 0, spb: base.size * 0.3 }) });
      }
    }
    const raw = [];   // all lines, in story order
    let numCounter = 0, prevList = null;
    const paraInfo = [];
    paras.forEach((pa, pIdx) => {
      let P, cbase, atoms;
      if (pa.virtual) { P = pa.P; cbase = pa.st; atoms = virtualAtoms(pa.str, pa.st); }
      else {
        const r = resolvePara(n, pa.ps, base);
        P = r.P; cbase = r.cbase;
        atoms = buildAtoms(n, pa.ps, pa.pe, cbase, env);
      }
      const pst = mkStyle(cbase);
      P.em = pst.size;
      const info = { P, pst, ps: pa.ps, pe: pa.pe, virtual: pa.virtual, idx: pIdx };
      paraInfo.push(info);
      // bullets & numbering
      let label = null, labelSt = pst, listIndent = 0;
      if (P.list && (P.list.t === 'bullet' || P.list.t === 'num')) {
        const L0 = P.list;
        if (L0.t === 'num') {
          if (!prevList || prevList.t !== 'num' || L0.restart) numCounter = (isSet(L0.start) ? +L0.start : 1) - 1;
          numCounter++;
          label = (L0.pre || '') + TS.fmtNum(numCounter, L0.style || 'arabic') + (isSet(L0.suf) ? L0.suf : '.');
        } else label = L0.ch || '•';
        if (L0.color) labelSt = mkStyle(cbase, { color: L0.color });
        const lw = width(labelSt, label);
        listIndent = Math.max(isSet(L0.indent) ? +L0.indent : pst.size * 1.5, lw + pst.size * 0.4);
      } else if (!P.list) numCounter = 0;
      prevList = P.list;
      // drop cap
      let dc = null;
      const dcl = Math.max(0, Math.round(P.dcl || 0)), dcc = Math.max(1, Math.round(P.dcc || 1));
      if (dcl >= 2 && !pa.virtual) {
        const take = [];
        let k = 0;
        while (k < atoms.length && take.filter(a => a.k === 'ch').length < dcc && (atoms[k].k === 'ch' || atoms[k].k === 'zw')) { take.push(atoms[k]); k++; }
        if (take.some(a => a.k === 'ch')) {
          const fst = take.find(a => a.k === 'ch').st;
          const lead1 = leadOf(fst);
          const cap1 = metrics(fst).cap;
          const ratio = cap1 / fst.size || 0.7;
          const size = (lead1 * (dcl - 1) + cap1) / ratio;
          const dst = mkStyle(fst, { size, pos: 'normal', bs: 0, lh: null });
          const str = take.map(a => a.d).join('');
          dc = { atoms: take.map(a => Object.assign({}, a, { st: dst })), st: dst, str, w: width(dst, str) + fst.size * 0.2, lines: dcl };
          atoms = atoms.slice(k);
        }
      }
      info.dc = dc;
      info.label = label; info.labelSt = labelSt; info.listIndent = listIndent;
      const boxes = makeBoxes(atoms, P);
      const startOf = (ln, ith) => P.li + listIndent + (ith ? ith : ((ln === 0 ? P.fi : 0) + (dc && ln < dc.lines ? dc.w : 0)));
      const C = {
        P,
        start: startOf,
        avail: (ln, ith) => Math.max(1, colW - startOf(ln, ith) - P.ri),
        tab: null
      };
      const justified = /^justify/.test(P.align);
      let lines = null;
      if (P.composer === 'para' && !auto) lines = compose(boxes, C, justified);
      if (!lines) lines = greedy(boxes, C);
      if (!lines.length) lines = [{ from: 0, to: 0, hy: false, ln: 0, ith: 0, last: true }];
      lines.forEach((l, k) => {
        raw.push({ para: info, boxes, l, first: k === 0, lastOfPara: k === lines.length - 1, C });
      });
    });
    // ---- measure lines (natural width, leading) ----
    for (const R of raw) {
      const { boxes, l, para } = R;
      let w = 0, maxLead = 0, metSt = null;
      const x0 = R.C.start(l.ln, l.ith);
      for (let j = l.from; j < l.to; j++) {
        const b = boxes[j];
        if (b.k === 'tab' || b.k === 'rtab') { if (b.tw === undefined) b.tw = tabWidth(b, x0 + w, boxes, j, Object.assign({ lineEnd: x0 + (auto ? 1e6 : R.C.avail(l.ln, l.ith)) }, R.C)); w += b.tw; }
        else w += b.w;
        for (const a of b.atoms || []) { if (a.k === 'zw' || a.k === 'g' && !a.d) continue; const ld = leadOf(a.st); if (ld > maxLead) { maxLead = ld; } if (!metSt || (a.st.pos === 'normal' && effSize(a.st) > effSize(metSt))) metSt = a.st; }
      }
      if (l.hy) { const lastB = boxes[l.to - 1]; w += lastB && lastB.hyW ? lastB.hyW : 0; }
      if (!maxLead) { maxLead = leadOf(para.pst); metSt = para.pst; }
      if (!metSt) metSt = para.pst;
      R.nat = w; R.x0 = x0; R.lead = maxLead; R.met = metrics(metSt);
    }
    if (auto) {
      let mw = 1;
      for (const R of raw) mw = Math.max(mw, R.x0 + R.nat + R.para.P.ri + (R.para.label && R.first ? 0 : 0));
      colW = mw;
    }
    // ---- footnotes (area at the bottom of the frame) ----
    const fnCount = countChar(text, CH.footnote);
    const fnLines = [];
    let fnH = 0;
    if (fnCount && !temp) {
      const fst = mkStyle(base, { size: base.size * env.fno.size / 100, lh: null });
      const fW = auto ? colW : Math.max(10, innerW);
      const P = Object.assign({}, DEF_PARA, { li: fst.size * 1.6, fi: -fst.size * 1.6, tabs: [{ x: fst.size * 1.6, a: 'left' }] });
      for (let k = 0; k < fnCount; k++) {
        const fn = (n.fnotes || [])[k] || { text: '' };
        const str = env.fno.prefix + TS.fmtNum(env.fnBase + k + 1, env.fno.style) + (env.fno.suffix || '') + '\t' + (fn.text || '');
        const atoms = virtualAtoms(str, fst);
        const boxes = makeBoxes(atoms, P);
        const C = { P, start: (ln) => P.li + (ln === 0 ? P.fi : 0), avail: ln => Math.max(1, fW - (P.li + (ln === 0 ? P.fi : 0))) };
        const lines = greedy(boxes, C);
        lines.forEach((l, j) => { const x0 = C.start(l.ln, 0); let w = 0; for (let q = l.from; q < l.to; q++) { const b = boxes[q]; if (b.k === 'tab') { if (b.tw === undefined) b.tw = tabWidth(b, x0 + w, boxes, q, Object.assign({ lineEnd: x0 + 1e6 }, C)); w += b.tw; } else w += b.w; } fnLines.push({ para: { P, pst: fst, virtual: true, fnote: k }, boxes, l, first: j === 0, lastOfPara: j === lines.length - 1, C, nat: w, x0, lead: leadOf(fst), met: metrics(fst) }); });
      }
      fnH = fnLines.reduce((s, R) => s + R.lead, 0) + (env.fno.space || 6) + fst.size * 0.5;
    }
    // ---- flow into columns ----
    const colH0 = n.boxH ? Math.max(1, n.boxH - it - ib - fnH) : Infinity;
    const grid = gridUsed(n) ? gridEnv(n) : null;
    const flow = (colH, dry) => {
      let col = 0, y = 0, over = -1;
      const pos = [];
      for (let k = 0; k < raw.length; k++) {
        const R = raw[k];
        const spb = R.first && y > 0 ? (R.para.P.spb || 0) : 0;
        let top = y + spb;
        if (grid && R.para.P.grid && R.para.P.grid !== 'none' && (R.para.P.grid === 'all' || R.first)) {
          const base0 = grid.oy + it + top + (R.lead - (R.met.asc + R.met.desc)) / 2 + R.met.asc;
          const kk = Math.ceil((base0 - grid.start) / grid.step - 1e-6);
          top += grid.start + kk * grid.step - base0;
        }
        if (top + R.lead > colH + 0.01 && (y > 0 || col > 0)) {
          col++; y = 0;
          if (col >= cols) { over = k; break; }
          top = 0;
          if (grid && R.para.P.grid && R.para.P.grid !== 'none') { const base0 = grid.oy + it + (R.lead - (R.met.asc + R.met.desc)) / 2 + R.met.asc; const kk = Math.ceil((base0 - grid.start) / grid.step - 1e-6); top += grid.start + kk * grid.step - base0; }
        }
        pos.push({ col, top });
        y = top + R.lead;
        if (R.lastOfPara) { y += R.para.P.spa || 0; if (R.para.dc && R.l.ln < R.para.dc.lines - 1) y = Math.max(y, top + R.lead * (R.para.dc.lines - R.l.ln)); }
        if (R.l.forced === 'col') { col++; y = 0; if (col >= cols) { over = k + 1; break; } }
        if (R.l.forced === 'frame') { over = k + 1 < raw.length ? k + 1 : -1; if (over >= 0) break; }
      }
      if (dry) return { over, pos };
      return { over, pos };
    };
    let colH = colH0;
    let res;
    if (cols > 1 && (!n.boxH || n.colBal)) {
      // balance: smallest column height that still fits every line into the columns
      const total = raw.reduce((s, R) => s + R.lead + (R.lastOfPara ? (R.para.P.spa || 0) : 0) + (R.first ? (R.para.P.spb || 0) : 0), 0);
      let lo = Math.max(...raw.map(R => R.lead)), hi = Math.min(colH0, Math.max(lo, total));
      if (raw.some(R => R.l.forced === 'col' || R.l.forced === 'frame')) lo = hi;
      for (let it2 = 0; it2 < 30 && hi - lo > 0.5; it2++) { const mid = (lo + hi) / 2; if (flow(mid, true).over >= 0) lo = mid; else hi = mid; }
      colH = hi;
      res = flow(colH);
      if (res.over >= 0 && colH < colH0) { colH = colH0; res = flow(colH); }
    } else res = flow(colH);
    // ---- place lines ----
    const all = [];
    const frags = [];
    const shades = [], decos = [];
    let contentH = 0;
    const colX = c => il + c * (colW + gap);
    raw.forEach((R, k) => {
      const hidden = res.over >= 0 && k >= res.over;
      const p = res.pos[k];
      const line = placeLine(R, colW, side, n);
      line.hidden = hidden;
      line.para = R.para;
      line.first = R.first; line.lastOfPara = R.lastOfPara;
      if (!hidden) {
        line.col = p.col; line.top = it + p.top; line.h = R.lead;
        line.cx = colX(p.col);
        line.base = line.top + (R.lead - (R.met.asc + R.met.desc)) / 2 + R.met.asc;
        contentH = Math.max(contentH, p.top + R.lead);
      }
      all.push(line);
    });
    // vertical justification of every column
    if (n.boxH && n.valign && n.valign !== 'top') {
      const H = colH0;
      for (let c = 0; c < cols; c++) {
        const ls = all.filter(l => !l.hidden && l.col === c);
        if (!ls.length) continue;
        const bottom = Math.max(...ls.map(l => l.top + l.h)) - it;
        const extra = H - bottom;
        if (extra <= 0) continue;
        if (n.valign === 'justify' && ls.length > 1) ls.forEach((l, i) => { const d = extra * i / (ls.length - 1); l.top += d; l.base += d; });
        else { const d = n.valign === 'center' ? extra / 2 : n.valign === 'bottom' ? extra : 0; ls.forEach(l => { l.top += d; l.base += d; }); }
      }
    }
    // absolute positions of fragments
    for (const line of all) {
      if (line.hidden) continue;
      for (const fr of line.frags) {
        fr.ax = line.cx + fr.x;
        fr.ay = line.base + shiftY(fr.st);
        frags.push(fr);
      }
      if (line.label) { line.label.ax = line.cx + line.label.x; line.label.ay = line.base; frags.push(line.label); }
    }
    // drop caps: baseline of the paragraph's last drop-cap line
    for (const info of paraInfo) {
      if (!info.dc) continue;
      const ls = all.filter(l => l.para === info && !l.hidden);
      if (!ls.length) continue;
      const first = ls[0];
      const target = ls[info.dc.lines - 1];
      const base = target && target.col === first.col ? target.base : first.base + first.h * (info.dc.lines - 1);
      const x = first.cx + info.P.li + info.listIndent;
      const fr = { x: x - first.cx, ax: x, ay: base, str: info.dc.str, st: info.dc.st, atoms: info.dc.atoms, w: info.dc.w, dc: true, line: first };
      first.frags.unshift(fr);
      frags.push(fr);
    }
    // paragraph shading / border (per column piece)
    for (const info of paraInfo) {
      const P = info.P;
      const sh = P.shade && P.shade.on !== false ? P.shade : null, bd = P.border && P.border.on !== false ? P.border : null;
      if (!sh && !bd) continue;
      const ls = all.filter(l => l.para === info && !l.hidden);
      const byCol = new Map();
      for (const l of ls) { const g = byCol.get(l.col) || []; g.push(l); byCol.set(l.col, g); }
      for (const [c, g] of byCol) {
        const pad = info.pst.size * 0.25;
        const y0 = g[0].top - pad, y1 = g[g.length - 1].top + g[g.length - 1].h + pad;
        const r = { x: colX(c) - (sh && sh.ox || 0), y: y0, w: colW + 2 * (sh && sh.ox || 0), h: y1 - y0 };
        if (sh) shades.push(Object.assign({ c: sh.c || '#E8E8E8', op: isSet(sh.tint) ? sh.tint / 100 : 1 }, r));
        if (bd) decos.push(Object.assign({ border: true, c: bd.c || '#1E1E24', sw: bd.w || 1 }, r));
      }
    }
    // underline / strikethrough
    for (const fr of frags) {
      if (!fr.str || fr.leader) continue;
      const st = fr.st;
      const chg = env.showChanges && (st.ins || st.del);
      if (st.under || (chg && st.ins)) decos.push({ x: fr.ax, y: fr.line ? fr.line.base + effSize(st) * 0.12 - st.bs : fr.ay + st.size * 0.12, w: fr.w + (fr.gx || 0), h: Math.max(0.5, st.size * 0.065), c: chg ? '#1C7ED6' : st.color });
      if (st.strike || (chg && st.del)) decos.push({ x: fr.ax, y: fr.ay - effSize(st) * 0.3, w: fr.w, h: Math.max(0.5, st.size * 0.065), c: chg ? '#E03131' : st.color });
    }
    // footnotes
    let fnTop = 0;
    const fnFrags = [];
    let rule = null;
    if (fnLines.length) {
      const bottom = n.boxH ? n.boxH - ib - fnH : it + contentH;
      fnTop = bottom;
      if (env.fno.rule) rule = { x: il, y: fnTop + base.size * 0.2, w: Math.min(auto ? colW : innerW, 72), h: 0.6 };
      let y = fnTop + (env.fno.space || 6) + base.size * 0.5;
      for (const R of fnLines) {
        const line = placeLine(R, auto ? colW : innerW, side, n);
        line.top = y; line.h = R.lead; line.cx = il; line.col = 0;
        line.base = y + (R.lead - (R.met.asc + R.met.desc)) / 2 + R.met.asc;
        line.fn = true; line.para = R.para;
        for (const fr of line.frags) { fr.ax = line.cx + fr.x; fr.ay = line.base + shiftY(fr.st); fnFrags.push(fr); }
        y += R.lead;
        all.push(line);
      }
      frags.push(...fnFrags);
    }
    // ---- frame size ----
    const fullW = auto ? il + colW + ir : n.width;
    let h = it + contentH + ib;
    if (fnLines.length) h = Math.max(h, fnTop + fnH + ib);
    if (!raw.length) h = it + leadOf(st0) + ib;
    // compatibility lines (visible): text, baseline, width
    const vis = all.filter(l => !l.hidden && !l.fn);
    const lines = vis.map(l => ({ t: l.frags.filter(f => !f.dc).map(f => f.str).join(''), y: l.base, w: l.nat, last: l.lastOfPara, x: l.cx + l.x0, col: l.col }));
    let fitEnd = text.length, overset = false;
    if (res.over >= 0) {
      overset = true;
      const R = raw[res.over];
      const firstAtom = firstSrc(R);
      fitEnd = firstAtom >= 0 ? firstAtom : (R.para.virtual ? text.length : R.para.ps);
      // only virtual (endnote) lines are hidden → not real overset text
      if (raw.slice(res.over).every(x => x.para.virtual)) { overset = false; fitEnd = text.length; }
    }
    const lh0 = vis[0] ? vis[0].h : leadOf(st0);
    return {
      lines, all, frags, w: fullW, h: Math.max(h, 1), lh: lh0, asc: metrics(st0).asc,
      cols, colW, gap, inset: [it, ir, ib, il], colH, shades, decos, rule, overset, fitEnd, paras: paraInfo, st0
    };
  }
  const shiftY = st => -(st.bs || 0) + (st.pos === 'sup' ? -st.size * 0.333 : st.pos === 'sub' ? st.size * 0.15 : 0);
  // first source index of a raw line
  const firstSrc = R => {
    if (R.para.virtual) return -1;
    if (R.first && R.para.dc) return R.para.ps;
    if (R.first) return R.para.ps;
    for (let j = R.l.from; j < R.boxes.length; j++) for (const a of R.boxes[j].atoms || []) if (a.i >= 0) return a.i;
    return R.para.pe;
  };

  // horizontal placement of one line: alignment, justification, optical margins, fragments
  function placeLine(R, colW, side, n) {
    const { boxes, l, para } = R;
    const P = para.P;
    const x0 = R.C.start(l.ln, l.ith);
    let A = Math.max(1, colW - x0 - P.ri);
    const lastLike = l.last || l.forced === 'col' || l.forced === 'frame';
    if (lastLike) A = Math.max(1, A - (P.lri || 0));
    let align = P.align || 'left';
    if (align === 'spine') align = side === 'left' ? 'right' : 'left';
    if (align === 'away') align = side === 'left' ? 'left' : 'right';
    let mode = align, justify = false;
    if (/^justify/.test(align)) {
      if (!lastLike || align === 'justify-all') justify = true;
      mode = align === 'justify-center' ? 'center' : align === 'justify-right' ? 'right' : 'left';
      if (justify) mode = 'left';
    }
    // optical margin alignment
    let hangL = 0, hangR = 0;
    if (n.optical) {
      const atomsIn = [];
      for (let j = l.from; j < l.to; j++) for (const a of boxes[j].atoms || []) if (a.d) atomsIn.push(a);
      const fa = atomsIn[0], la = atomsIn[atomsIn.length - 1];
      if (fa && HANG[fa.d[0]]) hangL = width(fa.st, fa.d[0]) * HANG[fa.d[0]];
      if (l.hy) { const lb = boxes[l.to - 1]; hangR = (lb && lb.hyW || 0) * 0.75; }
      else if (la && HANG[la.d[la.d.length - 1]]) hangR = width(la.st, la.d[la.d.length - 1]) * HANG[la.d[la.d.length - 1]];
    }
    const glue = [];
    for (let j = l.from; j < l.to; j++) if (boxes[j].k === 'g') glue.push(j);
    const nat = R.nat;
    let extraPer = 0, off = 0, tl = null;
    if (justify) {
      const free = A + hangL + hangR - nat;
      if (glue.length) extraPer = free / glue.length;
      else if (align === 'justify-all' && nat > 0 && free > 0) tl = A + hangL + hangR;
      off = -hangL;
    } else if (mode === 'right') off = A - nat + hangR;
    else if (mode === 'center') off = (A - nat) / 2 + (hangR - hangL) / 2;
    else off = -hangL;
    if (!isFinite(off)) off = 0;
    // fragments
    const frags = [];
    let x = x0 + off, cur = null;
    const lineRef = {};
    const start = (st, extra) => { cur = Object.assign({ x, str: '', st, atoms: [], w: 0, line: lineRef }, extra || {}); frags.push(cur); };
    const end = () => { if (cur) cur.w = groupW(cur.atoms.filter(a => a.i >= -1)); cur = null; };
    for (let j = l.from; j < l.to; j++) {
      const b = boxes[j];
      if (b.k === 'tab' || b.k === 'rtab') {
        end();
        const tw = b.tw || 0;
        const tf = { x, str: '', st: b.atoms[0].st, atoms: b.atoms, w: tw, tab: true, line: lineRef };
        frags.push(tf);
        if (b.leader && tw > 0) {
          const lst = b.atoms[0].st, lw = width(lst, b.leader);
          if (lw > 0.5) { const k = Math.floor((tw - lw * 0.5) / lw); if (k > 0) frags.push({ x, str: b.leader.repeat(k), st: lst, atoms: [], w: k * lw, leader: true, of: tf, pad: lw * 0.25, line: lineRef }); }
        }
        x += tw;
        continue;
      }
      if (b.k === 'ith' || FORCED.has(b.k)) { end(); frags.push({ x, str: '', st: b.atoms[0].st, atoms: b.atoms, w: 0, zw: true, line: lineRef }); continue; }
      for (const a of b.atoms) {
        if (a.pn || a.fn !== undefined || a.en !== undefined) {
          end();
          start(a.st, a.pn ? { pn: a.pn } : null);
          cur.str = a.d; cur.atoms.push(a);
          const w = width(a.st, a.d); cur.w = w; x += w;
          if (a.fn !== undefined) cur.fnRef = a.fn;
          cur = null;
          continue;
        }
        if (!cur || cur.st !== a.st) { end(); start(a.st); }
        cur.str += a.d; cur.atoms.push(a);
        x += a.d ? width(a.st, a.d) : 0;
      }
      if (b.k === 'g' && justify) { if (cur) { cur.gx = extraPer; } x += extraPer; end(); }
      else if (b.k === 'w' && justify && j + 1 < l.to && boxes[j + 1].k !== 'g') { /* word pieces stay in one fragment */ }
    }
    end();
    // exact x after each fragment (widths of runs measured as a whole)
    let cx = x0 + off;
    for (const fr of frags) {
      if (fr.leader) { fr.x = fr.of.x + fr.of.w - fr.w - fr.pad; continue; }
      fr.x = cx;
      if (fr.tab || fr.zw) { cx += fr.w; continue; }
      fr.w = fr.str ? width(fr.st, fr.str) : 0;
      cx += fr.w + (fr.gx || 0);
    }
    // hyphen at a hyphenated line end
    if (l.hy) {
      const lastFr = [...frags].reverse().find(f => f.str !== undefined && !f.tab && !f.leader && !f.zw);
      if (lastFr) { lastFr.str += '-'; lastFr.atoms = lastFr.atoms.concat([{ i: -2, d: '-', k: 'ch', st: lastFr.st }]); lastFr.w = width(lastFr.st, lastFr.str); cx = lastFr.x + lastFr.w; }
    }
    if (tl && frags.length === 1) frags[0].tl = tl;
    // the forced break character itself (caret position at the line end)
    if (l.fb) frags.push({ x: cx, str: '', st: l.fb.atoms[0].st, atoms: l.fb.atoms, w: 0, zw: true, line: lineRef });
    // list label on the first line
    let label = null;
    if (R.first && para.label) {
      const lx = P.li + (P.fi || 0);
      label = { x: lx, str: para.label, st: para.labelSt, atoms: [], w: width(para.labelSt, para.label), label: true, line: lineRef };
    }
    const tail = [];
    for (const b of l.tail || []) for (const a of b.atoms || []) tail.push(a);
    const line = Object.assign(lineRef, { frags, x0: x0 + off, x1: cx, nat, tail, label, l, A, srcEnd: null });
    // source index after the line (paragraph end for the last line)
    line.pe = R.lastOfPara && !para.virtual ? para.pe : null;
    return line;
  }

  // ---------- caret / selection geometry (frame-local coordinates) ----------
  // marks: [index, x] for every source index on the line (incl. line end)
  TS.marks = line => {
    if (line._marks) return line._marks;
    const out = [];
    for (const fr of line.frags) {
      if (fr.leader || fr.label) continue;
      let acc = '';
      for (const a of fr.atoms) {
        if (a.i >= 0) {
          let x;
          if (fr.tab || fr.zw) x = fr.x;
          else if (fr.dc) x = fr.x + width(fr.st, acc);
          else x = fr.x + width(fr.st, acc);
          out.push([a.i, x]);
        }
        acc += a.d || '';
      }
      if (fr.tab && fr.atoms[0] && fr.atoms[0].i >= 0) out.push([fr.atoms[0].i + 0.5, fr.x + fr.w]);
    }
    const endX = line.x1;
    for (const a of line.tail || []) if (a.i >= 0) out.push([a.i, endX]);
    if (line.pe !== null && line.pe !== undefined) out.push([line.pe, endX]);
    out.sort((a, b) => a[0] - b[0]);
    // a position right after the last atom of the line
    const lastI = out.length ? out[out.length - 1][0] : -1;
    if (lastI >= 0 && Number.isInteger(lastI) && !(line.pe !== null && line.pe !== undefined)) { line.after = lastI + 1; }
    line._marks = out.filter(m => Number.isInteger(m[0]));
    line._endX = endX;
    return line._marks;
  };
  TS.visibleLines = L => L.all.filter(l => !l.hidden && !l.fn);
  TS.caret = (n, idx) => {
    const L = TS.layout(n);
    const ls = TS.visibleLines(L);
    let best = null;
    for (const line of ls) {
      const mk = TS.marks(line);
      const m = mk.find(q => q[0] === idx);
      if (m) { best = { x: line.cx + m[1], y: line.top, h: line.h, line }; break; }
    }
    if (!best) {
      // right after the last atom of a line (soft wrap end / end of text)
      for (const line of ls) { TS.marks(line); if (line.after === idx) { best = { x: line.cx + line._endX, y: line.top, h: line.h, line }; } }
    }
    if (!best && ls.length && idx >= (n.text || '').length) { const line = ls[ls.length - 1]; best = { x: line.cx + line.x1, y: line.top, h: line.h, line }; }
    if (!best && !ls.length) { const st = mkStyle(frameChar(n)); const P = framePara(n); const ins = L.inset; best = { x: ins[3] + (P.align === 'center' ? (L.w - ins[1] - ins[3]) / 2 : P.align === 'right' ? L.w - ins[1] - ins[3] : 0), y: ins[0], h: leadOf(st), line: null }; }
    return best;
  };
  TS.hitIndex = (n, p) => {
    const L = TS.layout(n);
    const ls = TS.visibleLines(L);
    if (!ls.length) return 0;
    let bestLine = null, bd = Infinity;
    for (const line of ls) {
      const dx = p.x < line.cx - 2 ? line.cx - p.x : p.x > line.cx + L.colW + 2 ? p.x - (line.cx + L.colW) : 0;
      const dy = p.y < line.top ? line.top - p.y : p.y > line.top + line.h ? p.y - line.top - line.h : 0;
      const d = dx * 4 + dy;
      if (d < bd) { bd = d; bestLine = line; }
    }
    const mk = TS.marks(bestLine).slice();
    if (bestLine.after !== undefined && !mk.some(m => m[0] === bestLine.after)) mk.push([bestLine.after, bestLine._endX]);
    if (!mk.length) return 0;
    let bi = mk[0][0], bx = Infinity;
    for (const [i, x] of mk) { const d = Math.abs(bestLine.cx + x - p.x); if (d < bx || (d === bx && i > bi && false)) { bx = d; bi = i; } }
    return bi;
  };
  TS.rangeRects = (n, a, b) => {
    if (b <= a) return [];
    const L = TS.layout(n);
    const out = [];
    for (const line of TS.visibleLines(L)) {
      const mk = TS.marks(line);
      if (!mk.length) continue;
      const lo = mk[0][0], hi = mk[mk.length - 1][0];
      const endIdx = line.after !== undefined ? line.after : hi;
      if (b <= lo || a > Math.max(hi, endIdx)) continue;
      const xa = a <= lo ? mk[0][1] : (mk.find(m => m[0] >= a) || [0, line._endX])[1];
      const xb = b > hi ? line._endX + (line.pe !== null && line.pe !== undefined && b > line.pe ? 4 : 0) : (mk.find(m => m[0] >= b) || [0, line._endX])[1];
      if (xb > xa) out.push({ x: line.cx + xa, y: line.top, w: xb - xa, h: line.h });
    }
    return out;
  };
  // caret one line up / down (dir -1 / 1), keeping the x position
  TS.lineMove = (n, idx, dir, wantX) => {
    const c = TS.caret(n, idx);
    if (!c || !c.line) return idx;
    const ls = TS.visibleLines(TS.layout(n));
    const k = ls.indexOf(c.line);
    const tg = ls[k + dir];
    if (!tg) return dir < 0 ? 0 : (n.text || '').length;
    return TS.hitIndex(n, { x: wantX !== undefined ? wantX : c.x, y: tg.top + tg.h / 2 });
  };
  TS.lineEdge = (n, idx, toEnd) => {
    const c = TS.caret(n, idx);
    if (!c || !c.line) return idx;
    const mk = TS.marks(c.line);
    if (!mk.length) return idx;
    if (!toEnd) return mk[0][0];
    if (c.line.pe !== null && c.line.pe !== undefined) return c.line.pe;
    const tl = (c.line.tail || []).find(a => a.i >= 0);
    if (tl) return tl.i;
    return c.line.after !== undefined ? c.line.after : mk[mk.length - 1][0];
  };

  // ---------- SVG markup ----------
  const featureCSS = st => {
    const f = [];
    const ot = st.ot || {};
    for (const k of Object.keys(ot)) if (k !== 'figs' && ot[k] !== undefined && ot[k] !== null) f.push(`"${k}" ${ot[k] ? 1 : 0}`);
    if (ot.figs) for (const k of ot.figs.split(',')) if (k) f.push(`"${k}" 1`);
    let css = f.length ? `font-feature-settings:${f.join(',')};` : '';
    if (st.kern === 'none') css += 'font-kerning:none;';
    return css;
  };
  const attrsFor = (st, st0, withColor, ctx) => {
    let a = '';
    if (st.font !== st0.font) a += ` font-family="${esc(T.family(st.font))}"`;
    const es = effSize(st);
    if (es !== st0.size) a += ` font-size="${n_(es)}"`;
    if (st.weight !== st0.weight) a += ` font-weight="${st.weight}"`;
    if (st.italic !== st0.italic) a += ` font-style="${st.italic ? 'italic' : 'normal'}"`;
    const lsA = st.ls / (st.hs / 100);
    if (lsA !== (st0.ls / (st0.hs / 100))) a += ` letter-spacing="${n_(lsA)}"`;
    if (st.smcaps) a += ' font-variant="small-caps"';
    const css = featureCSS(st);
    if (css) a += ` style="${css}"`;
    if (withColor) {
      const chg = !ctx.exp && S.settings.showChanges && (st.ins || st.del);
      if (chg) a += ` fill="${st.ins ? '#1C7ED6' : '#E03131'}"`;
      else if (st.color) a += ` fill="${st.color}"`;
    }
    return a;
  };
  const needsTf = st => st.hs !== 100 || st.vs !== 100 || st.skew;
  TS.markup = (n, ctx, H) => {
    const L = TS.layout(n);
    const st0 = L.st0;
    const fills = (n.fills || []).filter(p => p.visible !== false);
    const strokes = n.sw > 0 ? (n.strokes || []).filter(p => p.visible !== false) : [];
    let base = `font-family="${esc(T.family(n.font))}" font-size="${n_(n.size)}"`;
    if (n.weight && n.weight !== 400) base += ` font-weight="${n.weight}"`;
    if (n.italic) base += ' font-style="italic"';
    if (st0.ls) base += ` letter-spacing="${n_(st0.ls / (st0.hs / 100))}"`;
    base += ' xml:space="preserve"';
    let out = '';
    if (ctx.hit) out += `<rect width="${n_(L.w)}" height="${n_(n.boxH || L.h)}" fill="none" pointer-events="all"/>`;
    for (const r of L.shades) out += `<rect x="${n_(r.x)}" y="${n_(r.y)}" width="${n_(r.w)}" height="${n_(r.h)}" fill="${r.c}"${r.op < 1 ? ` fill-opacity="${n_(r.op)}"` : ''}/>`;
    // tracked changes: inserted text gets a light background on the canvas
    if (!ctx.exp && S.settings.showChanges) for (const fr of L.frags) if (fr.st.ins && fr.str) out += `<rect x="${n_(fr.ax)}" y="${n_(fr.line.top)}" width="${n_(fr.w)}" height="${n_(fr.line.h)}" fill="#1C7ED6" fill-opacity=".12"/>`;
    const pageNum = ctx.pageNum === undefined || ctx.pageNum === null ? null : ctx.pageNum;
    const fragText = fr => {
      if (fr.pn) { if (pageNum === null) return '#'; if (fr.pn === 'cur' || isNaN(+pageNum)) return String(pageNum); return String(+pageNum + (fr.pn === 'next' ? 1 : -1)); }
      return fr.str;
    };
    const glyphs = withColor => {
      let simple = '', extra = '';
      for (const fr of L.frags) {
        const s = fragText(fr);
        if (!s) continue;
        const st = fr.st;
        const a = attrsFor(st, st0, withColor, ctx);
        let el;
        if (needsTf(st)) {
          const k = Math.tan((st.skew || 0) * Math.PI / 180);
          const tf = `matrix(${n_(st.hs / 100)} 0 ${n_(-k * st.vs / 100)} ${n_(st.vs / 100)} ${n_(fr.ax)} ${n_(fr.ay)})`;
          el = `<text ${base} transform="${tf}"${a}><tspan x="0" y="0"${fr.tl ? ` textLength="${n_(fr.tl / (st.hs / 100))}" lengthAdjust="spacing"` : ''}>${esc(s)}</tspan></text>`;
          if (ctx.exp && st.link) el = `<a href="${esc(st.link)}">${el}</a>`;
          extra += el;
        } else {
          el = `<tspan x="${n_(fr.ax)}" y="${n_(fr.ay)}"${a}${fr.tl ? ` textLength="${n_(fr.tl)}" lengthAdjust="spacing"` : ''}>${esc(s)}</tspan>`;
          if (ctx.exp && st.link) el = `<a href="${esc(st.link)}">${el}</a>`;
          simple += el;
        }
      }
      return (simple ? `<text ${base}>${simple}</text>` : '') + extra;
    };
    if (fills.length <= 1 && strokes.length <= 1) {
      const f = fills[0] ? H.paintRef(fills[0], n, ctx, 'f0') : null;
      const s = strokes[0] ? H.paintRef(strokes[0], n, ctx, 's0') : null;
      if (s) out += `<g fill="none" stroke="${s.paint}"${s.op < 1 ? ` stroke-opacity="${n_(s.op)}"` : ''}${H.strokeCommon(n, n.sw)}>${glyphs(false)}</g>`;
      out += `<g fill="${f ? f.paint : 'none'}"${f && f.op < 1 ? ` fill-opacity="${n_(f.op)}"` : ''}>${glyphs(true)}</g>`;
    } else {
      strokes.forEach((p, i) => { const s = H.paintRef(p, n, ctx, 's' + i); out += `<g fill="none" stroke="${s.paint}"${s.op < 1 ? ` stroke-opacity="${n_(s.op)}"` : ''}${H.strokeCommon(n, n.sw)}>${glyphs(false)}</g>`; });
      fills.forEach((p, i) => { const f = H.paintRef(p, n, ctx, 'f' + i); out += `<g fill="${f.paint}"${f.op < 1 ? ` fill-opacity="${n_(f.op)}"` : ''}>${glyphs(true)}</g>`; });
    }
    // underline, strikethrough, paragraph borders, footnote rule
    const f0 = fills[0] ? H.paintRef(fills[0], n, ctx, 'f0') : { paint: '#000000', op: 1 };
    let deco = '';
    for (const d of L.decos) {
      if (d.border) deco += `<rect x="${n_(d.x)}" y="${n_(d.y)}" width="${n_(d.w)}" height="${n_(d.h)}" fill="none" stroke="${d.c}" stroke-width="${n_(d.sw)}"/>`;
      else deco += `<rect x="${n_(d.x)}" y="${n_(d.y)}" width="${n_(Math.max(0, d.w))}" height="${n_(d.h)}"${d.c ? ` fill="${d.c}"` : ''}/>`;
    }
    if (L.rule) deco += `<rect x="${n_(L.rule.x)}" y="${n_(L.rule.y)}" width="${n_(L.rule.w)}" height="${n_(L.rule.h)}"/>`;
    if (deco) out += `<g fill="${f0.paint}"${f0.op < 1 ? ` fill-opacity="${n_(f0.op)}"` : ''}>${deco}</g>`;
    // hidden characters (canvas only)
    if (!ctx.exp && S.settings.hiddenChars) out += hiddenMarks(n, L);
    return out;
  };
  const hiddenMarks = (n, L) => {
    let s = '';
    const col = '#4D9DFF';
    const mark = (x, y, ch, size) => { s += `<text x="${n_(x)}" y="${n_(y)}" font-size="${n_(size)}" font-family="Arial, sans-serif" fill="${col}" pointer-events="none">${esc(ch)}</text>`; };
    const text = n.text || '';
    for (const line of TS.visibleLines(L)) {
      const mk = TS.marks(line);
      const size = line.para.pst ? line.para.pst.size : n.size;
      for (const [i, x] of mk) {
        const c = text[i];
        if (c === ' ' || c === '\u00A0') { const nx = (mk.find(m => m[0] > i) || [0, line._endX])[1]; s += `<circle cx="${n_(line.cx + (x + nx) / 2)}" cy="${n_(line.base - size * 0.28)}" r="${n_(Math.max(0.6, size * 0.06))}" fill="${col}" pointer-events="none"/>`; }
        else if (c === '\t') mark(line.cx + x + 1, line.base, '»', size * 0.8);
        else if (c === CH.lineBreak) mark(line.cx + x + 1, line.base, '¬', size * 0.8);
        else if (c === CH.colBreak || BREAKS.has(c)) mark(line.cx + x + 1, line.base, c === CH.colBreak ? '▼' : '⇣', size * 0.7);
        else if (c === CH.note) mark(line.cx + x - size * 0.2, line.top + size * 0.5, '⚑', size * 0.6);
      }
      if (line.pe !== null && line.pe !== undefined) mark(line.cx + line._endX + 1, line.base, line.pe >= text.length ? '#' : '¶', size * 0.8);
    }
    return s;
  };

  // ---------- glyph outlines (PDF, «Create outlines») ----------
  TS.outlineJobs = n => {
    const L = TS.layout(n);
    const jobs = [];
    for (const fr of L.frags) { if (!fr.str) continue; jobs.push({ st: fr.st, str: fr.pn ? '#' : fr.str, x: fr.ax, y: fr.ay, tl: fr.tl }); }
    return { jobs, decos: L.decos.filter(d => !d.border), rule: L.rule, shades: L.shades };
  };

  // ---------- rich text detection (editing mode) ----------
  TS.rich = n => {
    if (!n || n.type !== 'text' || n.path) return false;
    if ((n.runs && n.runs.length) || (n.pars && n.pars.length)) return true;
    if ((n.cols || 1) > 1 || Array.isArray(n.inset) && n.inset.some(v => v)) return true;
    for (const k of PARA_KEYS) if (k !== 'align' && isSet(n[k]) && JSON.stringify(n[k]) !== JSON.stringify(DEF_PARA[k])) return true;
    if (n.align && !['left', 'center', 'right', 'justify'].includes(n.align)) return true;
    if ((n.hs && n.hs !== 100) || (n.vs && n.vs !== 100) || n.bs || n.skew || n.smcaps || (n.pos && n.pos !== 'normal') || n.kern === 'none' || n.ot || n.optical || (n.valign && n.valign !== 'top')) return true;
    if (/[\t\u00AD\u2028\u200B\uE000-\uF8FF]/.test(n.text || '')) return true;
    if (n.boxH && O.print && O.print.overset && O.print.overset(n)) return true;
    return false;
  };

  // ---------- hook into the model / renderer ----------
  T.layout = n => TS.layout(n);
  const oldReset = T.reset;
  T.reset = () => { if (oldReset) oldReset(); wcache.clear(); mcache.clear(); lcache.clear(); };
  T.metrics = n => metrics(mkStyle(frameChar(n)));
  O.on && O.on('fonts', () => { wcache.clear(); mcache.clear(); lcache.clear(); });
  O.on && O.on('lang', () => lcache.clear());
})();
