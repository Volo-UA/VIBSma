'use strict';
/* VIBSma — the «Image» menu of Adobe Photoshop for the photos of a design:
   Mode (bitmap, greyscale, duotone, indexed, RGB, CMYK, Lab), Adjustments (live previews through filters.js),
   Auto Tone / Contrast / Color, Image Size, Generative Upscale, Canvas Size, Image Rotation, Crop, Trim,
   Reveal All, Duplicate, Apply Image, Calculations, Variables & data sets, Trap, Analysis.
   Print documents keep their photos as TIFF at 300 dpi: imported photos are resampled to 300 ppi at their placed
   size and exported as real .tif files (browsers cannot display TIFF, the editor shows a lossless copy). */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui, io = O.io, M = O.M, R = O.R, G = O.G;
  const FL = O.filters, F = FL.defs, H = FL.helpers;
  const OM = O.objmenu;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const toast = (m, v) => O.toast(m, v);
  const IM = O.imagemenu = {};
  const clamp = O.clamp, round = Math.round;
  const cl = v => (v < 0 ? 0 : v > 255 ? 255 : v);
  const lum = (d, i) => 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
  const perPixel = H.perPixel, copy = H.copy;
  const hexRGB = h => { const c = O.color.parse(h) || { r: 0, g: 0, b: 0 }; return [c.r, c.g, c.b]; };
  const num = (k, l, min, max, v, o = {}) => Object.assign({ k, l, min, max, v, step: o.step || 1 }, o);
  const sel = (k, l, opts, v) => ({ k, l, o: opts, v });
  const col = (k, l, v) => ({ k, l, c: true, v });
  const chk = (k, l, v) => ({ k, l, b: true, v });
  const def = (id, name, params, run, extra = {}) => { F[id] = Object.assign({ id, name, group: 'Коригування', params, run }, extra); };
  const imageSel = () => !S.textEdit && FL.targets().length > 0;
  const lut = fn => { const L = new Uint8ClampedArray(256); for (let i = 0; i < 256; i++) L[i] = cl(fn(i)); return L; };
  const applyLut = (im, L, Lr, Lg, Lb) => perPixel(im, (d, i) => { d[i] = (Lr || L)[d[i]]; d[i + 1] = (Lg || L)[d[i + 1]]; d[i + 2] = (Lb || L)[d[i + 2]]; });
  const rgb2hsl = (r, g, b) => { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let h = 0, s = 0; if (mx !== mn) { const dd = mx - mn; s = l > 0.5 ? dd / (2 - mx - mn) : dd / (mx + mn); h = mx === r ? (g - b) / dd + (g < b ? 6 : 0) : mx === g ? (b - r) / dd + 2 : (r - g) / dd + 4; h /= 6; } return [h, s, l]; };
  const hue2 = (p, q, x) => { if (x < 0) x += 1; if (x > 1) x -= 1; return x < 1 / 6 ? p + (q - p) * 6 * x : x < 1 / 2 ? q : x < 2 / 3 ? p + (q - p) * (2 / 3 - x) * 6 : p; };
  const hsl2rgb = (h, s, l) => { if (!s) return [l * 255, l * 255, l * 255]; const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q; return [hue2(p, q, h + 1 / 3) * 255, hue2(p, q, h) * 255, hue2(p, q, h - 1 / 3) * 255]; };

  // ======================================================================
  // ADJUSTMENTS (Image › Adjustments) — each one is a filter with a live preview
  // ======================================================================
  def('adjBC', 'Яскравість/Контраст…', [num('b', 'Яскравість фото', -150, 150, 0), num('c', 'Контраст', -50, 100, 0), chk('legacy', 'Використовувати застарілий', false)], (im, p) => {
    const k = 1 + p.c / 100;
    if (p.legacy) return applyLut(im, lut(v => (v - 128) * k + 128 + p.b));
    // modern: brightness bends the curve (keeps highlights), contrast pivots around the mean
    const g = p.b >= 0 ? 1 / (1 + p.b / 100) : 1 - p.b / 150;
    return applyLut(im, lut(v => (255 * Math.pow(v / 255, g) - 128) * k + 128));
  });
  def('adjLevels', 'Рівні…', [sel('ch', 'Канал', [['rgb', 'RGB'], ['r', 'Червоний'], ['g', 'Зелений'], ['b', 'Синій']], 'rgb'), num('inB', 'Вхідні: чорна точка', 0, 253, 0), num('gamma', 'Вхідні: середні тони', 0.1, 9.99, 1, { step: 0.01 }), num('inW', 'Вхідні: біла точка', 2, 255, 255), num('outB', 'Вихідні: чорна', 0, 255, 0), num('outW', 'Вихідні: біла', 0, 255, 255)], (im, p) => {
    const L = lut(v => { let x = clamp((v - p.inB) / Math.max(1, p.inW - p.inB), 0, 1); x = Math.pow(x, 1 / Math.max(0.01, p.gamma)); return p.outB + x * (p.outW - p.outB); });
    const id = lut(v => v);
    return p.ch === 'rgb' ? applyLut(im, L) : applyLut(im, id, p.ch === 'r' ? L : id, p.ch === 'g' ? L : id, p.ch === 'b' ? L : id);
  });
  // a smooth curve through five points (monotone cubic)
  const curve = pts => {
    const n = pts.length, dx = [], dy = [], m = [];
    for (let i = 0; i < n - 1; i++) { dx[i] = pts[i + 1][0] - pts[i][0]; dy[i] = (pts[i + 1][1] - pts[i][1]) / (dx[i] || 1); }
    m[0] = dy[0]; m[n - 1] = dy[n - 2];
    for (let i = 1; i < n - 1; i++) m[i] = dy[i - 1] * dy[i] <= 0 ? 0 : (dy[i - 1] + dy[i]) / 2;
    return lut(x => {
      let i = 0; while (i < n - 2 && x > pts[i + 1][0]) i++;
      const h = dx[i] || 1, s = (x - pts[i][0]) / h, s2 = s * s, s3 = s2 * s;
      return (2 * s3 - 3 * s2 + 1) * pts[i][1] + (s3 - 2 * s2 + s) * h * m[i] + (-2 * s3 + 3 * s2) * pts[i + 1][1] + (s3 - s2) * h * m[i + 1];
    });
  };
  def('adjCurves', 'Криві…', [sel('ch', 'Канал', [['rgb', 'RGB'], ['r', 'Червоний'], ['g', 'Зелений'], ['b', 'Синій']], 'rgb'), sel('preset', 'Набір', [['custom', 'Власний'], ['contrast', 'Більший контраст (RGB)'], ['soft', 'Менший контраст'], ['bright', 'Світліше'], ['dark', 'Темніше'], ['negative', 'Негатив'], ['cross', 'Кросс-процес']], 'custom'), num('sh', 'Тіні', -100, 100, 0), num('mid', 'Середні тони', -100, 100, 0), num('hi', 'Світлі ділянки', -100, 100, 0)], (im, p) => {
    const PR = { contrast: [-20, 0, 20], soft: [20, 0, -20], bright: [15, 30, 15], dark: [-15, -30, -15] };
    if (p.preset === 'negative') return applyLut(im, lut(v => 255 - v));
    if (p.preset === 'cross') { const id = lut(v => v); return applyLut(im, id, curve([[0, 0], [64, 50], [128, 140], [192, 215], [255, 255]]), curve([[0, 0], [64, 70], [128, 135], [192, 200], [255, 245]]), curve([[0, 30], [64, 75], [128, 120], [192, 170], [255, 220]])); }
    const [s, m, h] = PR[p.preset] || [p.sh, p.mid, p.hi];
    const L = curve([[0, 0], [64, 64 + s * 0.6], [128, 128 + m * 0.6], [192, 192 + h * 0.6], [255, 255]]);
    const id = lut(v => v);
    return p.ch === 'rgb' ? applyLut(im, L) : applyLut(im, id, p.ch === 'r' ? L : id, p.ch === 'g' ? L : id, p.ch === 'b' ? L : id);
  });
  def('adjExposure', 'Експозиція…', [num('e', 'Експозиція', -5, 5, 0, { step: 0.05 }), num('off', 'Зсув', -0.5, 0.5, 0, { step: 0.005 }), num('gamma', 'Гамма-корекція', 0.1, 9.99, 1, { step: 0.01 })], (im, p) => applyLut(im, lut(v => 255 * Math.pow(Math.max(0, v / 255 * Math.pow(2, p.e) + p.off), 1 / p.gamma))));
  def('adjVibrance', 'Вібрація…', [num('vib', 'Вібрація', -100, 100, 30), num('sat', 'Насиченість', -100, 100, 0)], (im, p) => perPixel(im, (d, i) => {
    const r = d[i], g = d[i + 1], b = d[i + 2], mx = Math.max(r, g, b), avg = (r + g + b) / 3;
    const sat = mx ? (mx - Math.min(r, g, b)) / mx : 0;
    const k = 1 + p.sat / 100 + (p.vib / 100) * (1 - sat) * (p.vib > 0 && r > g && g > b ? 0.6 : 1);
    d[i] = cl(avg + (r - avg) * k); d[i + 1] = cl(avg + (g - avg) * k); d[i + 2] = cl(avg + (b - avg) * k);
  }));
  def('adjHueSat', 'Тон/Насиченість…', [num('h', 'Колірний тон', -180, 180, 0), num('s', 'Насиченість', -100, 100, 0), num('l', 'Освітленість', -100, 100, 0), chk('colorize', 'Тонування', false)], (im, p) => perPixel(im, (d, i) => {
    let [h, s, l] = rgb2hsl(d[i], d[i + 1], d[i + 2]);
    if (p.colorize) { h = ((p.h + 360) % 360) / 360; s = clamp(0.25 + p.s / 200, 0, 1); }
    else { h = (h + p.h / 360 + 1) % 1; s = clamp(s * (1 + p.s / 100), 0, 1); }
    l = p.l >= 0 ? l + (1 - l) * p.l / 100 : l * (1 + p.l / 100);
    const c = hsl2rgb(h, s, l); d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2];
  }));
  def('adjBalance', 'Колірний баланс…', [sel('tone', 'Тоновий баланс', [['sh', 'Тіні'], ['mid', 'Середні тони'], ['hi', 'Світлі ділянки']], 'mid'), num('cr', 'Блакитний — Червоний', -100, 100, 0), num('mg', 'Пурпуровий — Зелений', -100, 100, 0), num('yb', 'Жовтий — Синій', -100, 100, 0), chk('keep', 'Зберегти світність', true)], (im, p) => perPixel(im, (d, i) => {
    const l = lum(d, i) / 255;
    const w = p.tone === 'sh' ? Math.pow(1 - l, 2) : p.tone === 'hi' ? l * l : 1 - Math.abs(2 * l - 1);
    const k = 0.75 * w;
    const r = d[i] + p.cr * k, g = d[i + 1] + p.mg * k, b = d[i + 2] + p.yb * k;
    if (p.keep) { const l2 = 0.299 * r + 0.587 * g + 0.114 * b, dl = l * 255 - l2; d[i] = cl(r + dl); d[i + 1] = cl(g + dl); d[i + 2] = cl(b + dl); }
    else { d[i] = cl(r); d[i + 1] = cl(g); d[i + 2] = cl(b); }
  }));
  // Photoshop's Black & White: the grey of a pixel mixes the weights of its primary and secondary colours
  def('adjBW', 'Чорно-біле…', [num('r', 'Червоні', -200, 300, 40), num('y', 'Жовті', -200, 300, 60), num('g', 'Зелені', -200, 300, 40), num('c', 'Блакитні', -200, 300, 60), num('b', 'Сині', -200, 300, 20), num('m', 'Пурпурові', -200, 300, 80), chk('tint', 'Відтінок', false), col('tc', 'Колір відтінку', '#E1C38E')], (im, p) => {
    const tc = hexRGB(p.tc);
    return perPixel(im, (d, i) => {
      const r = d[i], g = d[i + 1], b = d[i + 2];
      const ch = [[r, 'r'], [g, 'g'], [b, 'b']].sort((a, b2) => b2[0] - a[0]);
      const [mx, md, mn] = ch;
      const sec = (mx[1] + md[1]).split('').sort().join('');
      const ws = { bg: p.c, br: p.m, gr: p.y }[sec];
      const v = cl((mx[0] - md[0]) * p[mx[1]] / 100 + (md[0] - mn[0]) * ws / 100 + mn[0]);
      if (p.tint) { const k = v / 255; d[i] = cl(tc[0] * k + (255 - tc[0]) * k * k); d[i + 1] = cl(tc[1] * k + (255 - tc[1]) * k * k); d[i + 2] = cl(tc[2] * k + (255 - tc[2]) * k * k); }
      else d[i] = d[i + 1] = d[i + 2] = v;
    });
  });
  def('adjPhotoFilter', 'Фотофільтр…', [sel('preset', 'Фільтр', [['#EC8A00', 'Теплий фільтр (85)'], ['#FAA000', 'Теплий фільтр (LBA)'], ['#006DFF', 'Холодний фільтр (80)'], ['#00B5FF', 'Холодний фільтр (LBB)'], ['#EA1A1A', 'Червоний'], ['#19C900', 'Зелений'], ['#ACBF00', 'Сепія'], ['custom', 'Колір…']], '#EC8A00'), col('color', 'Колір', '#EC8A00'), num('dens', 'Щільність', 1, 100, 25, { u: '%' }), chk('keep', 'Зберегти світність', true)], (im, p) => {
    const c = hexRGB(p.preset === 'custom' ? p.color : p.preset), k = p.dens / 100;
    return perPixel(im, (d, i) => {
      const l0 = lum(d, i);
      let r = d[i] * (1 - k) + d[i] * c[0] / 255 * k * 1.6, g = d[i + 1] * (1 - k) + d[i + 1] * c[1] / 255 * k * 1.6, b = d[i + 2] * (1 - k) + d[i + 2] * c[2] / 255 * k * 1.6;
      if (p.keep) { const dl = l0 - (0.299 * r + 0.587 * g + 0.114 * b); r += dl; g += dl; b += dl; }
      d[i] = cl(r); d[i + 1] = cl(g); d[i + 2] = cl(b);
    });
  });
  def('adjMixer', 'Змішування каналів…', [num('rr', 'Червоний ← червоний', -200, 200, 100, { u: '%' }), num('rg', 'Червоний ← зелений', -200, 200, 0, { u: '%' }), num('rb', 'Червоний ← синій', -200, 200, 0, { u: '%' }), num('gr', 'Зелений ← червоний', -200, 200, 0, { u: '%' }), num('gg', 'Зелений ← зелений', -200, 200, 100, { u: '%' }), num('gb', 'Зелений ← синій', -200, 200, 0, { u: '%' }), num('br', 'Синій ← червоний', -200, 200, 0, { u: '%' }), num('bg', 'Синій ← зелений', -200, 200, 0, { u: '%' }), num('bb', 'Синій ← синій', -200, 200, 100, { u: '%' }), chk('mono', 'Монохромний', false)], (im, p) => perPixel(im, (d, i) => {
    const r = d[i], g = d[i + 1], b = d[i + 2];
    const R0 = (r * p.rr + g * p.rg + b * p.rb) / 100;
    if (p.mono) { d[i] = d[i + 1] = d[i + 2] = cl(R0); return; }
    d[i] = cl(R0); d[i + 1] = cl((r * p.gr + g * p.gg + b * p.gb) / 100); d[i + 2] = cl((r * p.br + g * p.bg + b * p.bb) / 100);
  }));
  const LOOKS = {
    warm: [v => v * 1.06 + 6, v => v * 1.0 + 2, v => v * 0.9],
    cold: [v => v * 0.92, v => v * 1.0 + 2, v => v * 1.08 + 8],
    faded: [v => 30 + v * 0.82, v => 28 + v * 0.8, v => 34 + v * 0.78],
    night: [v => v * 0.55, v => v * 0.7, v => v * 0.95 + 18],
    teal: [v => (v < 128 ? v * 0.85 : v * 1.08), v => v * 1.0, v => (v < 128 ? v * 1.15 + 10 : v * 0.9)],
    film: [v => 255 * Math.pow(v / 255, 0.95) * 0.95 + 10, v => 255 * Math.pow(v / 255, 1.0) * 0.93 + 8, v => 255 * Math.pow(v / 255, 1.1) * 0.9 + 14]
  };
  def('adjLookup', 'Пошук кольору…', [sel('look', 'Таблиця', [['warm', 'Теплий'], ['cold', 'Холодний'], ['faded', 'Вицвілий'], ['night', 'Нічний'], ['teal', 'Бірюза й помаранч'], ['film', 'Плівка']], 'warm'), num('amount', 'Сила', 0, 100, 100, { u: '%' })], (im, p) => {
    const f = LOOKS[p.look] || LOOKS.warm, k = p.amount / 100;
    const ls = f.map(fn => lut(v => v + (fn(v) - v) * k));
    return applyLut(im, ls[0], ls[0], ls[1], ls[2]);
  });
  def('adjInvert', 'Інверсія', [], im => applyLut(im, lut(v => 255 - v)), { keys: ['Ctrl+I'] });
  def('adjPosterize', 'Постеризація…', [num('levels', 'Рівні', 2, 255, 4)], (im, p) => { const n = Math.max(2, round(p.levels)); return applyLut(im, lut(v => round(round(v / 255 * (n - 1)) * 255 / (n - 1)))); });
  def('adjThreshold', 'Поріг…', [num('level', 'Рівень порогу', 1, 255, 128)], (im, p) => perPixel(im, (d, i) => { const v = lum(d, i) >= p.level ? 255 : 0; d[i] = d[i + 1] = d[i + 2] = v; }));
  def('adjGradMap', 'Карта градієнта…', [col('c1', 'Тіні', '#1B1446'), col('c2', 'Світлі ділянки', '#FFB36B'), chk('rev', 'Інверсія', false), chk('dither', 'Дизеринг', false)], (im, p) => {
    const a = hexRGB(p.rev ? p.c2 : p.c1), b = hexRGB(p.rev ? p.c1 : p.c2);
    return perPixel(im, (d, i) => { let k = lum(d, i) / 255; if (p.dither) k = clamp(k + (Math.random() - 0.5) / 128, 0, 1); d[i] = a[0] + (b[0] - a[0]) * k; d[i + 1] = a[1] + (b[1] - a[1]) * k; d[i + 2] = a[2] + (b[2] - a[2]) * k; });
  });
  const RANGES = [['r', 'Червоні', 0], ['y', 'Жовті', 60], ['g', 'Зелені', 120], ['c', 'Блакитні', 180], ['b', 'Сині', 240], ['m', 'Пурпурові', 300], ['w', 'Білі'], ['n', 'Нейтральні'], ['k', 'Чорні']];
  def('adjSelective', 'Вибірковий колір…', [sel('range', 'Кольори', RANGES.map(r => [r[0], r[1]]), 'r'), num('c', 'Блакитний', -100, 100, 0, { u: '%' }), num('m', 'Пурпуровий', -100, 100, 0, { u: '%' }), num('y', 'Жовтий', -100, 100, 0, { u: '%' }), num('k', 'Чорний', -100, 100, 0, { u: '%' }), sel('method', 'Метод', [['rel', 'Відносний'], ['abs', 'Абсолютний']], 'rel')], (im, p) => {
    const rg = RANGES.find(r => r[0] === p.range) || RANGES[0];
    return perPixel(im, (d, i) => {
      const [h, s, l] = rgb2hsl(d[i], d[i + 1], d[i + 2]);
      let w;
      if (rg[2] !== undefined) { const dh = Math.abs(((h * 360 - rg[2] + 540) % 360) - 180); w = Math.max(0, 1 - dh / 60) * Math.min(1, s * 2); }
      else w = rg[0] === 'w' ? Math.max(0, (l - 0.6) / 0.4) * (1 - s) : rg[0] === 'k' ? Math.max(0, (0.4 - l) / 0.4) * (1 - s) : (1 - s) * (1 - Math.abs(2 * l - 1));
      if (w <= 0) return;
      const base = p.method === 'abs' ? 255 : null;
      const adj = (v, amt) => { const a = amt / 100 * w; return cl(v - (base !== null ? base : v) * a * (a > 0 ? 1 : 1)); };
      d[i] = adj(d[i], p.c + p.k); d[i + 1] = adj(d[i + 1], p.m + p.k); d[i + 2] = adj(d[i + 2], p.y + p.k);
    });
  });
  def('adjShadowsHi', 'Тіні/Світлі ділянки…', [num('sh', 'Тіні: ефект', 0, 100, 35, { u: '%' }), num('hi', 'Світлі ділянки: ефект', 0, 100, 0, { u: '%' }), num('radius', 'Радіус', 1, 200, 30, { u: 'px', px: true })], (im, p) => {
    const blur = H.gauss(im, Math.max(1, p.radius / 3)), b = blur.data;
    return perPixel(im, (d, i) => {
      const L = (0.299 * b[i] + 0.587 * b[i + 1] + 0.114 * b[i + 2]) / 255;
      const up = p.sh / 100 * Math.pow(1 - L, 2) * 1.6, down = p.hi / 100 * Math.pow(L, 2) * 0.9;
      for (let c = 0; c < 3; c++) { let v = d[i + c] / 255; v = v + (1 - v) * up * (1 - v * 0.3); v = v - v * down; d[i + c] = cl(v * 255); }
    });
  });
  def('adjHDR', 'HDR-тонування…', [num('strength', 'Сила', 0, 100, 50, { u: '%' }), num('radius', 'Радіус', 2, 120, 40, { u: 'px', px: true }), num('detail', 'Деталізація', 0, 300, 100, { u: '%' }), num('vib', 'Вібрація', -100, 100, 20)], (im, p) => {
    let out = H.unsharp(im, p.strength / 60, Math.max(1, p.radius / 3), 0);
    out = H.unsharp(out, p.detail / 300, 1.2, 0);
    return F.adjVibrance.run(out, { vib: p.vib, sat: 0 });
  });
  def('adjDesat', 'Знебарвити', [], im => perPixel(im, (d, i) => { const v = lum(d, i); d[i] = d[i + 1] = d[i + 2] = v; }), { keys: ['Ctrl+Shift+U'] });
  def('adjReplace', 'Замінити колір…', [col('from', 'Колір для заміни', '#D23C3C'), num('fuzz', 'Розкид', 0, 200, 40), num('h', 'Колірний тон', -180, 180, 120), num('s', 'Насиченість', -100, 100, 0), num('l', 'Освітленість', -100, 100, 0)], (im, p) => {
    const f = hexRGB(p.from);
    return perPixel(im, (d, i) => {
      const dist = Math.hypot(d[i] - f[0], d[i + 1] - f[1], d[i + 2] - f[2]);
      const w = clamp(1 - dist / Math.max(1, p.fuzz * 1.6), 0, 1);
      if (w <= 0) return;
      let [h, s, l] = rgb2hsl(d[i], d[i + 1], d[i + 2]);
      h = (h + p.h / 360 + 1) % 1; s = clamp(s * (1 + p.s / 100), 0, 1); l = clamp(l + p.l / 200, 0, 1);
      const c = hsl2rgb(h, s, l);
      d[i] += (c[0] - d[i]) * w; d[i + 1] += (c[1] - d[i + 1]) * w; d[i + 2] += (c[2] - d[i + 2]) * w;
    });
  });
  def('adjEqualize', 'Вирівняти яскравість', [], im => {
    const d = im.data, hist = new Float64Array(256);
    for (let i = 0; i < d.length; i += 4) if (d[i + 3]) hist[round(lum(d, i))]++;
    const total = hist.reduce((a, b) => a + b, 0) || 1;
    const cdf = new Float64Array(256); let acc = 0; for (let v = 0; v < 256; v++) { acc += hist[v]; cdf[v] = acc / total; }
    return perPixel(im, (dd, i) => { const l = lum(dd, i), nl = cdf[round(l)] * 255, k = l > 0 ? nl / l : 1; dd[i] = cl(dd[i] * k); dd[i + 1] = cl(dd[i + 1] * k); dd[i + 2] = cl(dd[i + 2] * k); });
  });
  def('adjMatch', 'Підібрати колір…', [num('lum', 'Світність', 1, 200, 100), num('int', 'Інтенсивність кольору', 0, 200, 100), num('fade', 'Ослаблення', 0, 100, 0), chk('neutral', 'Нейтралізувати', true)], (im, p) => {
    // neutralises the colour cast (grey world), then scales brightness and colourfulness
    const d0 = im.data; let sr = 0, sg = 0, sb = 0, n = 0;
    for (let i = 0; i < d0.length; i += 16) { sr += d0[i]; sg += d0[i + 1]; sb += d0[i + 2]; n++; }
    const m = (sr + sg + sb) / 3 / n, kr = p.neutral ? m / (sr / n || 1) : 1, kg = p.neutral ? m / (sg / n || 1) : 1, kb = p.neutral ? m / (sb / n || 1) : 1;
    return perPixel(im, (d, i) => {
      let r = d[i] * kr, g = d[i + 1] * kg, b = d[i + 2] * kb;
      const a = (r + g + b) / 3, ci = p.int / 100, li = p.lum / 100;
      r = (a + (r - a) * ci) * li; g = (a + (g - a) * ci) * li; b = (a + (b - a) * ci) * li;
      const f = p.fade / 100;
      d[i] = cl(r + (d[i] - r) * f); d[i + 1] = cl(g + (d[i + 1] - g) * f); d[i + 2] = cl(b + (d[i + 2] - b) * f);
    });
  });
  // auto corrections (no dialog)
  const stretch = (im, perChannel, clip = 0.001) => {
    const d = im.data, hs = [new Float64Array(256), new Float64Array(256), new Float64Array(256)], hl = new Float64Array(256);
    let n = 0;
    for (let i = 0; i < d.length; i += 4) { if (!d[i + 3]) continue; hs[0][d[i]]++; hs[1][d[i + 1]]++; hs[2][d[i + 2]]++; hl[round(lum(d, i))]++; n++; }
    const ends = h => { let a = 0, lo = 0, hi = 255; for (let v = 0; v < 256; v++) { a += h[v]; if (a > n * clip) { lo = v; break; } } a = 0; for (let v = 255; v >= 0; v--) { a += h[v]; if (a > n * clip) { hi = v; break; } } return [lo, Math.max(lo + 1, hi)]; };
    const L = h => { const [lo, hi] = ends(h); return lut(v => (v - lo) * 255 / (hi - lo)); };
    if (perChannel) return applyLut(im, null, L(hs[0]), L(hs[1]), L(hs[2]));
    const l = L(hl);
    return applyLut(im, l);
  };
  def('adjAutoTone', 'Автоматичний тон', [], im => stretch(im, true, 0.001));
  def('adjAutoContrast', 'Автоматичний контраст', [], im => stretch(im, false, 0.001));
  def('adjAutoColor', 'Автоматичний колір', [], im => F.adjMatch.run(stretch(im, false, 0.002), { lum: 100, int: 100, fade: 0, neutral: true }));

  // ======================================================================
  // MODE (bitmap, greyscale, duotone, indexed, RGB, CMYK, Lab)
  // ======================================================================
  const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
  const fsDither = (im, levelsFn) => {
    const { width: w, height: h } = im, out = copy(im), d = out.data;
    const e = new Float32Array(w * h * 3);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const j = y * w + x, i = j * 4;
      const v = [0, 1, 2].map(c => d[i + c] + e[j * 3 + c]);
      const q = levelsFn(v);
      for (let c = 0; c < 3; c++) {
        d[i + c] = q[c];
        const err = v[c] - q[c];
        if (x + 1 < w) e[(j + 1) * 3 + c] += err * 7 / 16;
        if (y + 1 < h) { if (x) e[(j + w - 1) * 3 + c] += err * 3 / 16; e[(j + w) * 3 + c] += err * 5 / 16; if (x + 1 < w) e[(j + w + 1) * 3 + c] += err / 16; }
      }
    }
    return out;
  };
  def('modeGray', 'Відтінки сірого', [], im => F.adjDesat.run(im, {}), { group: 'Режим', mode: 'gray' });
  def('modeBitmap', 'Бітовий формат…', [sel('method', 'Метод', [['50', 'Поріг 50%'], ['diffusion', 'Дифузійний дизеринг'], ['pattern', 'Регулярний візерунок'], ['halftone', 'Напівтоновий растр']], 'diffusion'), num('cell', 'Розмір растру', 2, 40, 6, { u: 'px', px: true })], (im, p) => {
    const g = F.adjDesat.run(im, {});
    if (p.method === '50') return F.adjThreshold.run(g, { level: 128 });
    if (p.method === 'diffusion') return fsDither(g, v => { const q = v[0] < 128 ? 0 : 255; return [q, q, q]; });
    const w = g.width;
    if (p.method === 'pattern') return perPixel(g, (d, i) => { const j = i >> 2, x = j % w, y = (j / w) | 0; const q = d[i] > (BAYER[(y & 3) * 4 + (x & 3)] + 0.5) * 16 ? 255 : 0; d[i] = d[i + 1] = d[i + 2] = q; });
    const cs = Math.max(2, p.cell), a = Math.PI / 4, ca = Math.cos(a), sa = Math.sin(a);
    return perPixel(g, (d, i) => { const j = i >> 2, x = j % w, y = (j / w) | 0; const u = (x * ca - y * sa) / cs, v = (x * sa + y * ca) / cs; const fu = u - Math.floor(u) - 0.5, fv = v - Math.floor(v) - 0.5; const r = Math.sqrt(1 - d[i] / 255) * 0.62; const q = Math.hypot(fu, fv) < r ? 0 : 255; d[i] = d[i + 1] = d[i + 2] = q; });
  }, { group: 'Режим', mode: 'bitmap' });
  def('modeDuotone', 'Дуотон…', [sel('kind', 'Тип', [['mono', 'Монотон'], ['duo', 'Дуотон'], ['tri', 'Тритон']], 'duo'), col('ink1', 'Фарба 1', '#1A1A1A'), col('ink2', 'Фарба 2', '#C2410C'), col('ink3', 'Фарба 3', '#F2C14E')], (im, p) => {
    const inks = (p.kind === 'mono' ? [p.ink1] : p.kind === 'duo' ? [p.ink1, p.ink2] : [p.ink1, p.ink2, p.ink3]).map(hexRGB);
    // each ink covers the paper according to its curve: ink 1 the shadows, the next ones further into the light
    return perPixel(F.adjDesat.run(im, {}), (d, i) => {
      const k = 1 - d[i] / 255;
      let r = 255, g = 255, b = 255;
      inks.forEach((c, n) => { const cov = clamp(n === 0 ? Math.pow(k, inks.length > 1 ? 1.6 : 1) : Math.sin(Math.min(1, k * (1.3 - n * 0.2)) * Math.PI / 2) * (0.85 - n * 0.15), 0, 1); r *= 1 - cov * (1 - c[0] / 255); g *= 1 - cov * (1 - c[1] / 255); b *= 1 - cov * (1 - c[2] / 255); });
      d[i] = r; d[i + 1] = g; d[i + 2] = b;
    });
  }, { group: 'Режим', mode: 'duotone' });
  // median cut palette
  const palette = (im, n) => {
    const d = im.data, px = [];
    const step = Math.max(1, Math.floor(d.length / 4 / 60000));
    for (let i = 0; i < d.length; i += 4 * step) if (d[i + 3] > 8) px.push([d[i], d[i + 1], d[i + 2]]);
    let boxes = [px];
    while (boxes.length < n) {
      boxes.sort((a, b) => b.length - a.length);
      const bx = boxes.shift();
      if (!bx || bx.length < 2) { if (bx) boxes.push(bx); break; }
      const rng = [0, 1, 2].map(c => { let mn = 255, mx = 0; bx.forEach(p => { if (p[c] < mn) mn = p[c]; if (p[c] > mx) mx = p[c]; }); return mx - mn; });
      const c = rng.indexOf(Math.max(...rng));
      bx.sort((a, b) => a[c] - b[c]);
      const mid = bx.length >> 1;
      boxes.push(bx.slice(0, mid), bx.slice(mid));
    }
    return boxes.filter(b => b.length).map(b => [0, 1, 2].map(c => b.reduce((s, p) => s + p[c], 0) / b.length));
  };
  const nearest = (pal, v) => { let best = pal[0], bd = Infinity; for (const p of pal) { const dd = (p[0] - v[0]) ** 2 + (p[1] - v[1]) ** 2 + (p[2] - v[2]) ** 2; if (dd < bd) { bd = dd; best = p; } } return best; };
  def('modeIndexed', 'Індексовані кольори…', [num('colors', 'Кольори', 2, 256, 16), chk('dither', 'Дизеринг', true)], (im, p) => {
    const pal = palette(im, clamp(round(p.colors), 2, 256));
    if (p.dither) return fsDither(im, v => nearest(pal, v));
    return perPixel(im, (d, i) => { const q = nearest(pal, [d[i], d[i + 1], d[i + 2]]); d[i] = q[0]; d[i + 1] = q[1]; d[i + 2] = q[2]; });
  }, { group: 'Режим', mode: 'indexed' });
  // RGB → CMYK (ink limit 300 %) → RGB: what a press can print
  IM.toCMYK = (r, g, b) => { const R0 = r / 255, G0 = g / 255, B0 = b / 255, k = 1 - Math.max(R0, G0, B0); if (k >= 1) return [0, 0, 0, 1]; const c = (1 - R0 - k) / (1 - k), m = (1 - G0 - k) / (1 - k), y = (1 - B0 - k) / (1 - k); return [c, m, y, k]; };
  def('modeCMYK', 'Колір CMYK', [], im => perPixel(im, (d, i) => {
    let [c, m, y, k] = IM.toCMYK(d[i], d[i + 1], d[i + 2]);
    // neon colours lie outside the press gamut: compress the most saturated ones
    const sat = Math.max(c, m, y) - Math.min(c, m, y);
    if (sat > 0.75) { const f = 0.75 / sat; const mn = Math.min(c, m, y); c = mn + (c - mn) * f; m = mn + (m - mn) * f; y = mn + (y - mn) * f; }
    const tac = c + m + y + k; if (tac > 3) { const f = (3 - k) / (c + m + y); c *= f; m *= f; y *= f; }
    d[i] = 255 * (1 - c) * (1 - k); d[i + 1] = 255 * (1 - m) * (1 - k) * 0.985 + 2; d[i + 2] = 255 * (1 - y) * (1 - k) * 0.97 + 4;
  }), { group: 'Режим', mode: 'cmyk' });
  const MODES = [['modeBitmap', 'bitmap'], ['modeGray', 'gray'], ['modeDuotone', 'duotone'], ['modeIndexed', 'indexed'], ['modeRGB', 'rgb'], ['modeCMYK', 'cmyk'], ['modeLab', 'lab']];
  const curMode = () => { const x = FL.targets()[0]; return x ? (x.holder.imgMode || 'rgb') : null; };
  const setMode = async (id, mode) => {
    const tg = FL.targets();
    if (!tg.length) return toast('Виділіть фото');
    const mark = () => { FL.targets().forEach(x => { x.holder.imgMode = mode; }); O.history.commit(t('Режим') + ': ' + mode.toUpperCase()); };
    if (F[id] && F[id].params.length) return FL.dialog(id, { targets: tg, onApply: async p => { await FL.apply(id, p, { targets: tg }); mark(); } });
    if (F[id]) await FL.apply(id, {}, { targets: tg });
    mark();
  };

  // ======================================================================
  // PIXEL HELPERS on a photo object: read / write the full image
  // ======================================================================
  const loadFull = async assetId => {
    const img = await io.loadImage(O.assetURL(assetId));
    const cv = document.createElement('canvas'); cv.width = img.naturalWidth; cv.height = img.naturalHeight;
    cv.getContext('2d').drawImage(img, 0, 0);
    return cv;
  };
  const canvasAsset = (cv, name, extra) => {
    const g = cv.getContext('2d', { willReadFrequently: true });
    let alpha = false; const d = g.getImageData(0, 0, cv.width, cv.height).data; for (let i = 3; i < d.length; i += 4 * 9) if (d[i] < 250) { alpha = true; break; }
    const data = cv.toDataURL(alpha || (S.doc.printImages) ? 'image/png' : 'image/jpeg', 0.95);
    const id = O.uid();
    S.doc.assets[id] = Object.assign({ data, w: cv.width, h: cv.height, name: name || t('Зображення') }, extra || {});
    return id;
  };
  // make the photo's pixels map exactly onto its box (stretch), cropping what was hidden
  const normalized = async n => {
    const f = n.type === 'raster' ? null : (n.fills || []).find(x => x.type === 'image' && x.asset && x.visible !== false);
    const gf = O.photo && O.photo.frameOf && O.photo.frameOf(n);
    if (gf || (f && f.mode !== 'stretch' && !(f.mode === 'fill' && Math.abs(n.w / n.h - S.doc.assets[f.asset].w / S.doc.assets[f.asset].h) < 0.01))) {
      O.suspendCommit = true;
      try { await OM.cropImage([gf || n]); } finally { O.suspendCommit = false; }
      return O.sel()[0];
    }
    return n;
  };
  const holderAsset = n => (n.type === 'raster' ? n.asset : ((n.fills || []).find(x => x.type === 'image' && x.asset) || {}).asset);
  const setHolderAsset = (n, id) => { const a = S.doc.assets[id]; if (n.type === 'raster') { n.asset = id; n.pw = a.w; n.ph = a.h; } else { const f = (n.fills || []).find(x => x.type === 'image'); f.asset = id; if (f.mode !== 'tile') f.mode = 'stretch'; } };
  const photoNodes = () => O.topSel().filter(n => n.type === 'raster' ? !!n.asset : (n.fills || []).some(f => f.type === 'image' && f.asset) || (O.photo && O.photo.frameOf && O.photo.frameOf(n)));
  const each = async (label, fn) => {
    const ns = photoNodes();
    if (!ns.length) return toast('Виділіть фото');
    const out = [];
    for (const n0 of ns) { O.select([n0.id]); const n = await normalized(n0); if (n) { await fn(n); out.push(n.id); } }
    O.select(out.filter(id => model.exists(id)));
    O.history.commit(label);
  };
  // the effective resolution of a photo, pixels per inch of the printed size
  IM.ppiOf = n => OM.density(n) * O.ppiOf(n);

  // ======================================================================
  // IMAGE SIZE, UPSCALE, CANVAS SIZE, ROTATION, TRIM, REVEAL ALL
  // ======================================================================
  const resample = (src, w, h, method) => {
    const cv = document.createElement('canvas'); cv.width = Math.max(1, round(w)); cv.height = Math.max(1, round(h));
    const g = cv.getContext('2d');
    g.imageSmoothingEnabled = method !== 'nearest';
    g.imageSmoothingQuality = method === 'bilinear' ? 'low' : 'high';
    // big reductions in halves keep detail (bicubic-like)
    let cur = src;
    if (method !== 'nearest') while (cur.width / 2 > cv.width && cur.height / 2 > cv.height) { const c2 = document.createElement('canvas'); c2.width = round(cur.width / 2); c2.height = round(cur.height / 2); const g2 = c2.getContext('2d'); g2.imageSmoothingQuality = 'high'; g2.drawImage(cur, 0, 0, c2.width, c2.height); cur = c2; }
    g.drawImage(cur, 0, 0, cv.width, cv.height);
    return cv;
  };
  IM.imageSize = async () => {
    const n0 = photoNodes()[0];
    if (!n0) return toast('Виділіть фото');
    O.select([n0.id]);
    const n = await normalized(n0);
    const a = S.doc.assets[holderAsset(n)];
    if (!a) return;
    const ppi0 = round(IM.ppiOf(n));
    const unitPPI = O.ppiOf(n);
    ui.dialog({
      title: 'Розмір зображення',
      body: `<div class="dlg-text small">${esc(t('Зараз: {w} × {h} пікс., {ppi} ppi у документі. Розмір друку: {mw} × {mh} мм.', { w: a.w, h: a.h, ppi: ppi0, mw: O.fmt(a.w / ppi0 * 25.4, 1), mh: O.fmt(a.h / ppi0 * 25.4, 1) }))}</div>`,
      fields: [
        { key: 'w', label: 'Ширина', type: 'number', value: a.w, unit: 'пікс.', min: 1 },
        { key: 'h', label: 'Висота', type: 'number', value: a.h, unit: 'пікс.', min: 1 },
        { key: 'ppi', label: 'Роздільна здатність', type: 'number', value: ppi0, unit: 'ppi', min: 1 },
        { key: 'keep', label: 'Зберігати пропорції', type: 'checkbox', value: true },
        { key: 'res', label: 'Інтерполяція', type: 'select', value: 'auto', options: [['auto', 'Автоматично'], ['bicubic', 'Бікубічна (плавні градієнти)'], ['bilinear', 'Білінійна'], ['nearest', 'Найближчий сусід (чіткі краї)'], ['none', 'Без інтерполяції (змінити лише ppi)']] }
      ],
      onOpen: el => {
        const W = el.querySelector('[data-k="w"]'), Hh = el.querySelector('[data-k="h"]'), K = el.querySelector('[data-k="keep"]');
        W.addEventListener('input', () => { if (K.checked) Hh.value = round(+W.value * a.h / a.w); });
        Hh.addEventListener('input', () => { if (K.checked) W.value = round(+Hh.value * a.w / a.h); });
      },
      onOk: async v => {
        const ppi = Math.max(1, v.ppi);
        let w = Math.max(1, round(v.w)), h = Math.max(1, round(v.h));
        if (v.res === 'none') { w = a.w; h = a.h; }
        else if (w !== a.w || h !== a.h) {
          const src = await loadFull(holderAsset(n));
          setHolderAsset(n, canvasAsset(resample(src, w, h, v.res), a.name, { fmt: a.fmt, dpi: ppi }));
        }
        // the printed size follows pixels ÷ ppi
        const b = model.worldBounds(n), kx = (w / ppi * unitPPI) / b.w, ky = (h / ppi * unitPPI) / b.h;
        model.applyWorld(n, M.about(M.scale(kx, ky), { x: b.x, y: b.y }), 'resize');
        O.history.commit('Розмір зображення');
      }
    });
  };
  IM.upscale = () => {
    if (!photoNodes().length) return toast('Виділіть фото');
    ui.dialog({
      title: 'Генеративне масштабування',
      body: `<div class="dlg-text small">${esc(t('Збільшує кількість пікселів і відновлює різкість країв. Розмір фото на макеті не змінюється — зростає роздільна здатність.'))}</div>`,
      fields: [{ key: 'k', label: 'Збільшити в', type: 'select', value: '2', options: [['2', '2×'], ['4', '4×']] }, { key: 'sharp', label: 'Підсилити деталі', type: 'number', value: 50, unit: '%', min: 0, max: 100 }],
      buttons: [{ id: 'ok', label: 'Збільшити фото', primary: true }],
      onOk: v => each('Генеративне масштабування', async n => {
        const a = S.doc.assets[holderAsset(n)];
        let cv = await loadFull(holderAsset(n));
        const k = +v.k;
        if (Math.max(cv.width, cv.height) * k > 12000) return toast('Зображення занадто велике для збільшення');
        for (let s = 1; s < k; s *= 2) cv = resample(cv, cv.width * 2, cv.height * 2, 'bicubic');
        const g = cv.getContext('2d', { willReadFrequently: true });
        const im = H.unsharp(g.getImageData(0, 0, cv.width, cv.height), v.sharp / 70, 1.2 * k / 2, 2);
        g.putImageData(im, 0, 0);
        setHolderAsset(n, canvasAsset(cv, (a.name || t('Зображення')) + ' · ' + k + '×', { fmt: a.fmt }));
      })
    });
  };
  const ANCHORS = [['tl', '↖'], ['t', '↑'], ['tr', '↗'], ['l', '←'], ['c', '•'], ['r', '→'], ['bl', '↙'], ['b', '↓'], ['br', '↘']];
  IM.canvasSize = async () => {
    const n0 = photoNodes()[0];
    if (!n0) return toast('Виділіть фото');
    O.select([n0.id]);
    const n = await normalized(n0);
    const a = S.doc.assets[holderAsset(n)];
    const grid = `<div class="dlg-row"><span>${esc(t('Розташування'))}</span><span class="im-anchor">${ANCHORS.map(([k, s]) => `<button type="button" data-anc="${k}" class="${k === 'c' ? 'on' : ''}">${s}</button>`).join('')}</span><input type="hidden" data-k="anc" value="c"></div>`;
    ui.dialog({
      title: 'Розмір полотна',
      body: `<div class="dlg-text small">${esc(t('Поточний розмір: {w} × {h} пікс.', { w: a.w, h: a.h }))}</div>`,
      fields: [
        { key: 'w', label: 'Ширина', type: 'number', value: a.w, unit: 'пікс.' },
        { key: 'h', label: 'Висота', type: 'number', value: a.h, unit: 'пікс.' },
        { key: 'rel', label: 'Відносно', type: 'checkbox', value: false },
        { key: 'anc', type: 'html', html: grid },
        { key: 'bg', type: 'html', html: `<label class="dlg-row"><span>${esc(t('Колір розширення полотна'))}</span><select data-k="bgk"><option value="transparent">${esc(t('Прозорий'))}</option><option value="#FFFFFF">${esc(t('Білий'))}</option><option value="#000000">${esc(t('Чорний'))}</option><option value="custom">${esc(t('Інший…'))}</option></select><input type="color" data-k="bgc" value="#808080"></label>` }
      ],
      onOpen: el => el.addEventListener('click', e => { const b = e.target.closest('[data-anc]'); if (!b) return; e.preventDefault(); el.querySelectorAll('[data-anc]').forEach(x => x.classList.toggle('on', x === b)); el.querySelector('[data-k="anc"]').value = b.dataset.anc; }),
      onOk: async () => {
        const el = O.$$('.dlg-back').slice(-1)[0];
        const val = k => el.querySelector(`[data-k="${k}"]`);
        let w = +val('w').value || a.w, h = +val('h').value || a.h;
        if (val('rel').checked) { w += a.w; h += a.h; }
        w = Math.max(1, round(w)); h = Math.max(1, round(h));
        const anc = val('anc').value, bgk = val('bgk').value, bg = bgk === 'custom' ? val('bgc').value : bgk;
        const fx = anc.includes('l') ? 0 : anc.includes('r') ? 1 : 0.5, fy = anc.includes('t') ? 0 : anc.includes('b') ? 1 : 0.5;
        const src = await loadFull(holderAsset(n));
        const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
        const g = cv.getContext('2d');
        if (bg !== 'transparent') { g.fillStyle = bg; g.fillRect(0, 0, w, h); }
        const dx = round((w - a.w) * fx), dy = round((h - a.h) * fy);
        g.drawImage(src, dx, dy);
        const wb = model.worldBounds(n), k = wb.w / a.w;
        setHolderAsset(n, canvasAsset(cv, a.name, { fmt: a.fmt, dpi: a.dpi }));
        // the box grows (or shrinks) around the anchor at the same pixel density
        const nb = { x: wb.x - dx * k, y: wb.y - dy * k, w: w * k, h: h * k };
        model.applyWorld(n, M.chain(M.translate(nb.x, nb.y), M.scale(nb.w / wb.w, nb.h / wb.h), M.translate(-wb.x, -wb.y)), 'resize');
        O.history.commit('Розмір полотна');
      }
    });
  };
  IM.rotate = (kind, angle) => each('Обертання зображення', async n => {
    const a = S.doc.assets[holderAsset(n)];
    const src = await loadFull(holderAsset(n));
    const deg = kind === 'cw' ? 90 : kind === 'ccw' ? -90 : kind === '180' ? 180 : kind === 'any' ? angle : 0;
    const rad = deg * Math.PI / 180, cs = Math.abs(Math.cos(rad)), sn = Math.abs(Math.sin(rad));
    const W = kind === 'fh' || kind === 'fv' ? a.w : round(a.w * cs + a.h * sn), Hh = kind === 'fh' || kind === 'fv' ? a.h : round(a.w * sn + a.h * cs);
    const cv = document.createElement('canvas'); cv.width = W; cv.height = Hh;
    const g = cv.getContext('2d');
    g.translate(W / 2, Hh / 2);
    if (kind === 'fh') g.scale(-1, 1); else if (kind === 'fv') g.scale(1, -1); else g.rotate(rad);
    g.drawImage(src, -a.w / 2, -a.h / 2);
    const wb = model.worldBounds(n), k = wb.w / a.w, c = R.center(wb);
    setHolderAsset(n, canvasAsset(cv, a.name, { fmt: a.fmt, dpi: a.dpi }));
    model.applyWorld(n, M.chain(M.translate(c.x - W * k / 2, c.y - Hh * k / 2), M.scale(W * k / wb.w, Hh * k / wb.h), M.translate(-wb.x, -wb.y)), 'resize');
  });
  IM.rotateDialog = () => ui.dialog({ title: 'Повернути полотно', fields: [{ key: 'a', label: 'Кут', type: 'number', value: 15, unit: '°' }, { key: 'dir', label: 'Напрямок', type: 'select', value: 'cw', options: [['cw', 'За годинниковою стрілкою'], ['ccw', 'Проти годинникової стрілки']] }], onOk: v => IM.rotate('any', v.dir === 'ccw' ? -v.a : v.a) });
  IM.trim = () => {
    if (!photoNodes().length) return toast('Виділіть фото');
    ui.dialog({
      title: 'Обрізка',
      fields: [
        { key: 'by', label: 'На основі', type: 'select', value: 'transparent', options: [['transparent', 'Прозорих пікселів'], ['tl', 'Кольору лівого верхнього пікселя'], ['br', 'Кольору правого нижнього пікселя']] },
        { key: 'top', label: 'Згори', type: 'checkbox', value: true }, { key: 'bottom', label: 'Знизу', type: 'checkbox', value: true },
        { key: 'left', label: 'Ліворуч', type: 'checkbox', value: true }, { key: 'right', label: 'Праворуч', type: 'checkbox', value: true }
      ],
      onOk: v => each('Обрізка', async n => {
        const a = S.doc.assets[holderAsset(n)];
        const src = await loadFull(holderAsset(n));
        const W = src.width, Hh = src.height, d = src.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, W, Hh).data;
        const ref = v.by === 'tl' ? 0 : (W * Hh - 1) * 4;
        const empty = i => v.by === 'transparent' ? d[i + 3] < 8 : Math.abs(d[i] - d[ref]) + Math.abs(d[i + 1] - d[ref + 1]) + Math.abs(d[i + 2] - d[ref + 2]) + Math.abs(d[i + 3] - d[ref + 3]) < 12;
        const rowEmpty = y => { for (let x = 0; x < W; x++) if (!empty((y * W + x) * 4)) return false; return true; };
        const colEmpty = (x, y0, y1) => { for (let y = y0; y <= y1; y++) if (!empty((y * W + x) * 4)) return false; return true; };
        let y0 = 0, y1 = Hh - 1, x0 = 0, x1 = W - 1;
        if (v.top) while (y0 < y1 && rowEmpty(y0)) y0++;
        if (v.bottom) while (y1 > y0 && rowEmpty(y1)) y1--;
        if (v.left) while (x0 < x1 && colEmpty(x0, y0, y1)) x0++;
        if (v.right) while (x1 > x0 && colEmpty(x1, y0, y1)) x1--;
        if (!x0 && !y0 && x1 === W - 1 && y1 === Hh - 1) return toast('Обрізати нічого');
        const w = x1 - x0 + 1, h = y1 - y0 + 1;
        const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
        cv.getContext('2d').drawImage(src, -x0, -y0);
        const wb = model.worldBounds(n), k = wb.w / a.w;
        setHolderAsset(n, canvasAsset(cv, a.name, { fmt: a.fmt, dpi: a.dpi }));
        model.applyWorld(n, M.chain(M.translate(wb.x + x0 * k, wb.y + y0 * k), M.scale(w * k / wb.w, h * k / wb.h), M.translate(-wb.x, -wb.y)), 'resize');
      })
    });
  };
  IM.revealAll = () => {
    const ns = photoNodes();
    if (!ns.length) return toast('Виділіть фото');
    let k = 0;
    ns.forEach(n => {
      const gf = O.photo && O.photo.frameOf && O.photo.frameOf(n);
      if (gf) { O.select([gf.id]); O.run('photoFrameToContent'); k++; return; }
      const f = (n.fills || []).find(x => x.type === 'image' && x.asset);
      if (!f || f.mode === 'tile' || f.mode === 'stretch') return;
      const a = S.doc.assets[f.asset], wb = model.worldBounds(n), dens = OM.density(n), c = R.center(wb);
      const w = a.w / dens, h = a.h / dens;
      model.applyWorld(n, M.chain(M.translate(c.x - w / 2, c.y - h / 2), M.scale(w / wb.w, h / wb.h), M.translate(-wb.x, -wb.y)), 'resize');
      f.mode = 'stretch'; delete f.crop;
      k++;
    });
    if (!k) return toast('Фото вже показано повністю');
    O.history.commit('Показати все');
  };
  IM.crop = () => {
    const ns = O.topSel();
    const photo = ns.find(n => n.type === 'raster' || (n.fills || []).some(f => f.type === 'image'));
    const shape = ns.find(n => n !== photo);
    if (photo && shape) {
      // crop the photo to the area of the shape on top of it (Photoshop: crop to selection)
      const b = model.worldBounds(shape), pb = model.worldBounds(photo);
      const x0 = Math.max(b.x, pb.x), y0 = Math.max(b.y, pb.y), x1 = Math.min(b.x + b.w, pb.x + pb.w), y1 = Math.min(b.y + b.h, pb.y + pb.h);
      if (x1 - x0 < 1 || y1 - y0 < 1) return toast('Фігура не перекриває фото');
      model.remove(shape);
      model.reindex();
      return OM.cropImage([photo], { x: x0, y: y0, w: x1 - x0, h: y1 - y0 });
    }
    return OM.cropImage();
  };
  IM.duplicate = () => {
    const ns = O.topSel();
    ui.dialog({
      title: 'Дублювати зображення',
      fields: [{ key: 'name', label: 'Як', type: 'text', value: (ns[0] ? ns[0].name : model.page().name) + ' ' + t('копія') }, { key: 'only', label: 'Лише виділене', type: 'checkbox', value: !!ns.length }],
      onOk: v => {
        const src = v.only && ns.length ? ns : model.page().children;
        const pg = model.newPage(v.name || t('Копія'));
        src.forEach(n => { const c = model.cloneNode(n); c.m = model.worldMatrix(n); pg.children.push(c); });
        S.doc.pages.push(pg);
        S.pageId = pg.id;
        model.reindex();
        O.emit('page');
        O.history.commit('Дублювати зображення');
        toast('Створено сторінку «{name}»', { name: pg.name });
      }
    });
  };
  // ======================================================================
  // APPLY IMAGE / CALCULATIONS (two photos blended pixel by pixel)
  // ======================================================================
  const BLENDS = [['source-over', 'Звичайний'], ['multiply', 'Множення'], ['screen', 'Екран'], ['overlay', 'Перекриття'], ['darken', 'Затемнення'], ['lighten', 'Освітлення'], ['color-dodge', 'Освітлення основи'], ['color-burn', 'Затемнення основи'], ['hard-light', 'Жорстке світло'], ['soft-light', 'М’яке світло'], ['difference', 'Різниця'], ['exclusion', 'Виключення'], ['lighter', 'Додавання']];
  const sourceCanvas = async (src, tb, tw, th) => {
    // the source as it lies over the target box, at the target's pixel size
    const k = tw / tb.w;
    const r = await io.renderImage([src], { scale: k, type: 'image/png' });
    const cv = document.createElement('canvas'); cv.width = tw; cv.height = th;
    cv.getContext('2d').drawImage(r.canvas, round((r.bounds.x - tb.x) * k), round((r.bounds.y - tb.y) * k));
    return cv;
  };
  const channelGray = (cv, ch, inv) => {
    const g = cv.getContext('2d', { willReadFrequently: true }), im = g.getImageData(0, 0, cv.width, cv.height);
    const d = im.data;
    for (let i = 0; i < d.length; i += 4) { let v = ch === 'r' ? d[i] : ch === 'g' ? d[i + 1] : ch === 'b' ? d[i + 2] : ch === 'a' ? d[i + 3] : lum(d, i); if (inv) v = 255 - v; d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = 255; }
    g.putImageData(im, 0, 0);
    return cv;
  };
  const twoPhotos = () => { const ns = O.topSel().filter(n => n.type === 'raster' || (n.fills || []).some(f => f.type === 'image')); return ns.length >= 2 ? ns.slice(0, 2) : null; };
  IM.applyImage = () => {
    const two = twoPhotos();
    if (!two) return toast('Виділіть 2 фото: перше змінюється, друге — джерело');
    ui.dialog({
      title: 'Застосувати зображення',
      fields: [
        { key: 'src', label: 'Джерело', type: 'select', value: '1', options: [['1', two[1].name], ['0', two[0].name]] },
        { key: 'ch', label: 'Канал', type: 'select', value: 'rgb', options: [['rgb', 'RGB'], ['r', 'Червоний'], ['g', 'Зелений'], ['b', 'Синій'], ['gray', 'Сірий']] },
        { key: 'inv', label: 'Інвертувати', type: 'checkbox', value: false },
        { key: 'mode', label: 'Накладання', type: 'select', value: 'multiply', options: BLENDS },
        { key: 'op', label: 'Непрозорість', type: 'number', value: 100, unit: '%', min: 0, max: 100 }
      ],
      onOk: async v => {
        const src = two[+v.src], tgt0 = two[1 - v.src];
        O.select([tgt0.id]);
        const tgt = await normalized(tgt0);
        const a = S.doc.assets[holderAsset(tgt)], tb = model.worldBounds(tgt);
        const base = await loadFull(holderAsset(tgt));
        let sc = await sourceCanvas(src, tb, base.width, base.height);
        if (v.ch !== 'rgb') sc = channelGray(sc, v.ch === 'gray' ? 'gray' : v.ch, v.inv);
        else if (v.inv) { const g = sc.getContext('2d'); g.globalCompositeOperation = 'difference'; g.fillStyle = '#FFFFFF'; g.fillRect(0, 0, sc.width, sc.height); }
        const g = base.getContext('2d');
        g.globalAlpha = clamp(v.op, 0, 100) / 100; g.globalCompositeOperation = v.mode; g.drawImage(sc, 0, 0);
        setHolderAsset(tgt, canvasAsset(base, (a.name || '') + ' · ' + t('Застосувати зображення'), { fmt: a.fmt, dpi: a.dpi }));
        O.select([tgt.id]);
        O.history.commit('Застосувати зображення');
      }
    });
  };
  IM.calculations = () => {
    const two = twoPhotos();
    if (!two) return toast('Виділіть 2 фото для підрахунків');
    const chs = [['gray', 'Сірий'], ['r', 'Червоний'], ['g', 'Зелений'], ['b', 'Синій'], ['a', 'Прозорість']];
    ui.dialog({
      title: 'Підрахунки',
      fields: [
        { key: 'c1', label: 'Джерело 1: канал', type: 'select', value: 'gray', options: chs }, { key: 'i1', label: 'Інвертувати джерело 1', type: 'checkbox', value: false },
        { key: 'c2', label: 'Джерело 2: канал', type: 'select', value: 'gray', options: chs }, { key: 'i2', label: 'Інвертувати джерело 2', type: 'checkbox', value: false },
        { key: 'mode', label: 'Накладання', type: 'select', value: 'multiply', options: BLENDS }, { key: 'op', label: 'Непрозорість', type: 'number', value: 100, unit: '%', min: 0, max: 100 }
      ],
      onOk: async v => {
        const [A, B] = two, tb = model.worldBounds(A);
        const k = Math.min(4, OM.density(A));
        const w = Math.max(1, round(tb.w * k)), h = Math.max(1, round(tb.h * k));
        const c1 = channelGray(await sourceCanvas(A, tb, w, h), v.c1, v.i1), c2 = channelGray(await sourceCanvas(B, tb, w, h), v.c2, v.i2);
        const g = c1.getContext('2d');
        g.globalAlpha = clamp(v.op, 0, 100) / 100; g.globalCompositeOperation = v.mode; g.drawImage(c2, 0, 0);
        const par = model.parent(A);
        const id = canvasAsset(c1, t('Підрахунки'));
        const lb = R.transform(tb, M.inv(model.containerMatrix(par)));
        const r = model.create('rect', { name: t('Підрахунки'), w: lb.w, h: lb.h, m: M.translate(lb.x, lb.y), fills: [Object.assign(O.paint.image(id), { mode: 'stretch' })] });
        model.insert(r, par, par.children.indexOf(A) + 1);
        O.select([r.id]);
        O.history.commit('Підрахунки');
      }
    });
  };

  // ======================================================================
  // VARIABLES & DATA SETS (one design → many personalised copies)
  // ======================================================================
  IM.varDefine = () => {
    const n = O.sel()[0];
    if (!n) return toast('Виділіть текст, фото або об’єкт');
    const kinds = [['vis', 'Видимість']].concat(n.type === 'text' ? [['text', 'Заміна тексту']] : [], (n.type === 'raster' || (n.fills || []).some(f => f.type === 'image')) || n.type === 'rect' ? [['image', 'Заміна зображення (посилання)']] : []);
    const cur = n.variable || {};
    ui.dialog({
      title: 'Визначити змінну',
      fields: [{ key: 'kind', label: 'Тип', type: 'select', value: cur.kind || kinds[kinds.length - 1][0], options: kinds.concat([['none', 'Без змінної']]) }, { key: 'name', label: 'Назва', type: 'text', value: cur.name || ('var' + (Object.keys(IM.varNodes()).length + 1)) }],
      onOk: v => { if (v.kind === 'none') delete n.variable; else n.variable = { kind: v.kind, name: v.name.trim().replace(/[\s,;]+/g, '_') || 'var' }; O.history.commit('Змінна'); }
    });
  };
  IM.varNodes = () => { const out = {}; model.walk(model.page().children, n => { if (n.variable) out[n.variable.name] = n; }); return out; };
  const parseCSV = s => {
    const rows = []; let row = [], cell = '', q = false;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (q) { if (c === '"') { if (s[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; continue; }
      if (c === '"') q = true; else if (c === ',' || c === ';' || c === '\t') { row.push(cell); cell = ''; } else if (c === '\n' || c === '\r') { if (c === '\r' && s[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; } else cell += c;
    }
    if (cell || row.length) { row.push(cell); rows.push(row); }
    return rows.filter(r => r.some(x => x.trim()));
  };
  const setVar = async (n, val) => {
    if (n.variable.kind === 'vis') { n.visible = !/^(0|false|ні|нет|no|hide|сховати)$/i.test(String(val).trim()); return; }
    if (n.variable.kind === 'text') { n.text = String(val); delete n.runs; return; }
    if (n.variable.kind === 'image' && /^(https?:|data:image)/.test(String(val).trim())) {
      try { const r = await fetch(String(val).trim()); const a = await io.addAsset(await io.blobToData(await r.blob()), n.name); if (n.type === 'raster') { n.asset = a.id; } else n.fills = [Object.assign(O.paint.image(a.id), { mode: 'fill' })]; } catch (e) { console.warn(e); }
    }
  };
  IM.dataSets = () => {
    const vars = IM.varNodes();
    const names = Object.keys(vars);
    if (!names.length) return toast('Спершу визначте змінні: виділіть текст або фото → Зображення → Змінні → Визначити');
    const cur = names.map(k => { const n = vars[k]; return n.variable.kind === 'text' ? n.text.replace(/\n/g, ' ') : n.variable.kind === 'vis' ? 'true' : ''; });
    const sample = [names.join(','), cur.map(x => /[",]/.test(x) ? '"' + x.replace(/"/g, '""') + '"' : x).join(',')].join('\n');
    ui.dialog({
      title: 'Застосувати набори даних',
      body: `<div class="dlg-text small">${esc(t('Перший рядок — назви змінних, далі по рядку на кожну копію. Можна вставити таблицю з Excel або Google Таблиць.'))}</div>`,
      fields: [
        { key: 'csv', type: 'html', html: `<label class="dlg-row col"><span>${esc(t('Дані (CSV)'))}</span><textarea data-k="csv" rows="8" spellcheck="false">${esc(sample)}</textarea></label>` },
        { key: 'how', label: 'Як застосувати', type: 'select', value: 'copies', options: [['copies', 'Створити копію макета для кожного рядка'], ['first', 'Застосувати перший рядок до макета']] }
      ],
      buttons: [{ id: 'ok', label: 'Застосувати', primary: true }],
      onOk: async v => {
        const rows = parseCSV(v.csv);
        if (rows.length < 2) return toast('Потрібен рядок із назвами й хоча б один рядок даних');
        const head = rows[0].map(h => h.trim());
        const data = rows.slice(1);
        const first = vars[names[0]];
        const tpl = model.topLevel(first);
        if (v.how === 'first') { for (const [k, n] of Object.entries(vars)) { const j = head.indexOf(k); if (j >= 0) await setVar(n, data[0][j] || ''); } O.history.commit('Набір даних'); return; }
        const b = model.worldBounds(tpl), per = Math.max(1, Math.min(6, Math.floor(4000 / (b.w + 80))));
        const flatOf = n => { const out = []; model.walk([n], x => { out.push(x); }); return out; };
        const src = flatOf(tpl);
        const made = [];
        for (let r = 0; r < data.length; r++) {
          const c = model.cloneNode(tpl);
          const col2 = (r + 1) % per, row = Math.floor((r + 1) / per);
          c.m = M.mul(M.translate(col2 * (b.w + 80), row * (b.h + 80)), tpl.m);
          c.name = tpl.name + ' · ' + (r + 1);
          model.insert(c, model.parent(tpl));
          const dst = flatOf(c);
          for (let i = 0; i < src.length; i++) if (src[i].variable) { const j = head.indexOf(src[i].variable.name); if (j >= 0) await setVar(dst[i], data[r][j] || ''); }
          made.push(c.id);
        }
        model.reindex();
        O.select(made);
        O.history.commit('Набори даних');
        toast('Створено копій: {n}', { n: made.length });
        setTimeout(() => O.view.fit(model.selBounds(O.sel()), 80, 1), 0);
      }
    });
  };

  // ======================================================================
  // TRAP, ANALYSIS
  // ======================================================================
  IM.trap = () => {
    const ns = O.topSel().filter(n => (n.fills || []).some(f => f.visible !== false && f.type === 'solid'));
    if (!ns.length) return toast('Виділіть об’єкти із заливкою');
    ui.dialog({
      title: 'Трепінг',
      body: `<div class="dlg-text small">${esc(t('Трепінг додає тонку смугу кольору об’єкта поверх межі з фоном — так між фарбами не з’являться білі щілини, якщо друкарня трохи змістить форми.'))}</div>`,
      fields: [{ key: 'w', label: 'Ширина', type: 'number', value: 0.25, unit: 'pt', step: 0.05, min: 0.05 }, { key: 'op', label: 'Надрук (overprint)', type: 'checkbox', value: true }],
      onOk: v => {
        ns.forEach(n => { const f = n.fills.find(x => x.visible !== false && x.type === 'solid'); n.trap = { w: v.w, overprint: !!v.op, prev: { strokes: n.strokes, sw: n.sw, sa: n.sa } }; n.strokes = [O.paint.solid(f.color)]; n.sw = v.w * 2 * O.ppiOf(n) / 72; n.sa = 'center'; });
        O.history.commit('Трепінг');
        toast('Трепінг додано до {n} об’єктів', { n: ns.length });
      }
    });
  };
  const scaleOf = () => S.doc.measureScale || { px: 1, len: 1, unit: 'px' };
  IM.measureScale = () => {
    const s = scaleOf();
    ui.dialog({
      title: 'Масштаб вимірювання',
      fields: [{ key: 'px', label: 'Довжина в пікселях', type: 'number', value: s.px, min: 0.001 }, { key: 'len', label: 'Логічна довжина', type: 'number', value: s.len, min: 0.001 }, { key: 'unit', label: 'Одиниці', type: 'text', value: s.unit }],
      onOk: v => { S.doc.measureScale = { px: Math.max(0.001, v.px), len: Math.max(0.001, v.len), unit: v.unit.trim() || 'px' }; O.history.commit('Масштаб вимірювання'); }
    });
  };
  IM.measure = () => {
    const ns = O.topSel();
    if (!ns.length) return toast('Виділіть об’єкти для вимірювання');
    const s = scaleOf(), k = s.len / s.px;
    const list = S.doc.measurements || (S.doc.measurements = []);
    ns.forEach(n => {
      const b = model.worldBounds(n);
      let area = 0, per = 0;
      try { const subs = model.subsIn(n, model.worldMatrix(n)); G.flatten(subs, 1).forEach(f => { if (f.closed) area += G.area(f.pts); per += G.polyLength(f.pts, f.closed); }); } catch (e) { /* not geometric */ }
      list.push({ n: list.length + 1, name: n.name, w: +(b.w * k).toFixed(2), h: +(b.h * k).toFixed(2), area: +(Math.abs(area) * k * k).toFixed(2), per: +(per * k).toFixed(2), unit: s.unit, at: new Date().toISOString().slice(0, 16).replace('T', ' ') });
    });
    O.history.commit('Записати вимірювання');
    IM.measureLog();
  };
  IM.measureLog = () => {
    const list = S.doc.measurements || [];
    if (!list.length) return toast('Вимірювань ще немає: виділіть об’єкт → Зображення → Аналіз → Записати вимірювання');
    const rows = list.map(m => `<tr><td>${m.n}</td><td>${esc(m.name)}</td><td>${m.w}</td><td>${m.h}</td><td>${m.area}</td><td>${m.per}</td><td>${esc(m.unit)}</td></tr>`).join('');
    ui.dialog({
      title: 'Журнал вимірювань',
      body: `<div class="im-tbl"><table><thead><tr><th>№</th><th>${esc(t('Об’єкт'))}</th><th>${esc(t('Ширина'))}</th><th>${esc(t('Висота'))}</th><th>${esc(t('Площа'))}</th><th>${esc(t('Периметр'))}</th><th>${esc(t('Одиниці'))}</th></tr></thead><tbody>${rows}</tbody></table></div>`,
      buttons: [{ id: 'clear', label: 'Очистити' }, { id: 'csv', label: 'Експорт CSV' }, { id: 'ok', label: 'Закрити', primary: true }],
      onOk: (v, btn) => {
        if (btn === 'clear') { S.doc.measurements = []; O.history.commit('Очистити вимірювання'); }
        if (btn === 'csv') { const csv = ['n,name,width,height,area,perimeter,unit'].concat(list.map(m => [m.n, '"' + String(m.name).replace(/"/g, '""') + '"', m.w, m.h, m.area, m.per, m.unit].join(','))).join('\n'); O.download(new Blob(['﻿' + csv], { type: 'text/csv' }), (S.doc.name || 'VIBSma') + ' — ' + t('вимірювання') + '.csv'); }
      }
    });
  };

  // ======================================================================
  // PRINT PHOTOS: TIFF at 300 dpi
  // ======================================================================
  const PI = IM.print = {};
  PI.on = () => !!(S.doc && S.doc.printImages);
  // baseline TIFF (uncompressed): RGB / RGBA or CMYK, with the resolution tags
  IM.tiff = (im, dpi = 300, cmyk = false) => {
    const W = im.width, Hh = im.height, src = im.data;
    let alpha = false;
    if (!cmyk) for (let i = 3; i < src.length; i += 4) if (src[i] < 255) { alpha = true; break; }
    const spp = cmyk ? 4 : alpha ? 4 : 3;
    const tags = [];
    const tag = (id, type, count, value) => tags.push({ id, type, count, value });
    const entries = 12 + (alpha ? 1 : 0) + (cmyk ? 1 : 0);
    const ifd = 8, ifdSize = 2 + entries * 12 + 4;
    const extra = ifd + ifdSize, bps = extra, xres = bps + spp * 2, yres = xres + 8, data = yres + 8;
    const size = W * Hh * spp;
    tag(256, 4, 1, W); tag(257, 4, 1, Hh); tag(258, 3, spp, spp <= 2 ? 8 : bps); tag(259, 3, 1, 1); tag(262, 3, 1, cmyk ? 5 : 2);
    tag(273, 4, 1, data); tag(277, 3, 1, spp); tag(278, 4, 1, Hh); tag(279, 4, 1, size); tag(282, 5, 1, xres); tag(283, 5, 1, yres); tag(296, 3, 1, 2);
    if (cmyk) tag(332, 3, 1, 1);
    if (alpha) tag(338, 3, 1, 2);
    tags.sort((a, b) => a.id - b.id);
    const buf = new ArrayBuffer(data + size), v = new DataView(buf), u8 = new Uint8Array(buf);
    v.setUint16(0, 0x4949, true); v.setUint16(2, 42, true); v.setUint32(4, ifd, true);
    v.setUint16(ifd, entries, true);
    tags.forEach((e, i) => { const p = ifd + 2 + i * 12; v.setUint16(p, e.id, true); v.setUint16(p + 2, e.type, true); v.setUint32(p + 4, e.count, true); if (e.type === 3 && e.count === 1) v.setUint16(p + 8, e.value, true); else v.setUint32(p + 8, e.value, true); });
    v.setUint32(ifd + 2 + entries * 12, 0, true);
    for (let i = 0; i < spp; i++) v.setUint16(bps + i * 2, 8, true);
    v.setUint32(xres, round(dpi), true); v.setUint32(xres + 4, 1, true); v.setUint32(yres, round(dpi), true); v.setUint32(yres + 4, 1, true);
    let o = data;
    for (let i = 0; i < src.length; i += 4) {
      if (cmyk) { const [c, m, y, k] = IM.toCMYK(src[i], src[i + 1], src[i + 2]); u8[o++] = round(c * 255); u8[o++] = round(m * 255); u8[o++] = round(y * 255); u8[o++] = round(k * 255); }
      else { u8[o++] = src[i]; u8[o++] = src[i + 1]; u8[o++] = src[i + 2]; if (alpha) u8[o++] = src[i + 3]; }
    }
    return new Blob([buf], { type: 'image/tiff' });
  };
  // every photo asset of the document and the objects that show it
  const assetUse = () => {
    const use = new Map();
    const add = (id, n) => { if (!id || !S.doc.assets[id]) return; if (!use.has(id)) use.set(id, []); use.get(id).push(n); };
    for (const pg of S.doc.pages) model.walk(pg.children, n => { if (n.type === 'raster') add(n.asset, n); (n.fills || []).forEach(f => { if (f.type === 'image') add(f.asset, n); }); });
    return use;
  };
  const isPhotoData = d => /^data:image\/(png|jpe?g|webp|gif|bmp|avif)/i.test(d || '');
  const tifName = s => String(s || t('Фото')).replace(/\.(png|jpe?g|webp|gif|bmp|avif|tiff?)$/i, '') + '.tif';
  // imported photos: lossless master, named .tif, 300 dpi resolution
  const origAdd = io.addAsset;
  io.addAsset = async (data, name) => {
    if (!PI.on() || !isPhotoData(data) || (O.mode && O.mode() !== 'design')) return origAdd(data, name);
    const img = await io.loadImage(data);
    let w = img.naturalWidth, h = img.naturalHeight;
    const cap = 10000 / Math.max(w, h);
    if (cap < 1) { w = round(w * cap); h = round(h * cap); }
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    cv.getContext('2d').drawImage(img, 0, 0, w, h);
    const a = await origAdd(cv.toDataURL('image/png'), tifName(name));
    Object.assign(S.doc.assets[a.id], { fmt: 'tiff', dpi: 300, master: true });
    return a;
  };
  // placing a photo in a print document: its size on the page is the 300 dpi size
  const origImport = io.importImage;
  io.importImage = async (file, at) => {
    const n = await origImport(file, at);
    if (!n || !PI.on()) return n;
    const f = (n.fills || []).find(x => x.type === 'image'), a = f && S.doc.assets[f.asset];
    if (!a) return n;
    const ppi = O.ppiOf(n);
    let w = a.w * ppi / 300, h = a.h * ppi / 300;
    const par = model.parent(n);
    const lim = par && par.type === 'frame' ? { w: par.w, h: par.h } : null;
    if (lim && (w > lim.w || h > lim.h)) { const k = Math.min(lim.w / w, lim.h / h); w *= k; h *= k; }
    const c = R.center(model.worldBounds(n));
    n.w = round(w * 100) / 100; n.h = round(h * 100) / 100;
    const P0 = M.apply(M.inv(model.containerMatrix(par)), c);
    n.m = M.translate(P0.x - n.w / 2, P0.y - n.h / 2);
    O.history.commit('Фото для друку');
    setTimeout(() => toast('Фото збережено як TIFF 300 dpi для друку'), 50);
    return n;
  };
  // after every change: photos richer than 300 ppi at their placed size are resampled to exactly 300 ppi
  let busy = false;
  PI.normalize = async () => {
    if (!PI.on() || busy) return;
    busy = true;
    let changed = 0;
    try {
      const target = S.doc.printImages.dpi || 300;
      for (const [id, nodes] of assetUse()) {
        const a = S.doc.assets[id];
        if (!a || !isPhotoData(a.data) || a.dpiDone === a.w + 'x' + a.h) continue;
        const eff = Math.max(...nodes.map(n => IM.ppiOf(n)));
        if (!isFinite(eff) || eff <= 0) continue;
        if (eff > target * 1.08) {
          const k = target / eff;
          const src = await io.loadImage(O.assetURL(id));
          const cv = resample(src, a.w * k, a.h * k, 'bicubic');
          const nid = O.uid();
          S.doc.assets[nid] = { data: cv.toDataURL('image/png'), w: cv.width, h: cv.height, name: tifName(a.name), fmt: 'tiff', dpi: target, dpiDone: cv.width + 'x' + cv.height };
          nodes.forEach(n => { if (n.type === 'raster' && n.asset === id) { n.asset = nid; n.pw = cv.width; n.ph = cv.height; } (n.fills || []).forEach(f => { if (f.type === 'image' && f.asset === id) f.asset = nid; }); });
          changed++;
        } else Object.assign(a, { fmt: 'tiff', dpi: round(eff), name: tifName(a.name), dpiDone: a.w + 'x' + a.h });
      }
    } catch (e) { console.warn(e); } finally { busy = false; }
    if (changed) { O.requestRender(); O.history.commit('Фото для друку: 300 dpi'); }
  };
  const later = O.debounce(() => PI.normalize(), 700);
  O.on('commit', label => { if (PI.on() && label !== 'Фото для друку: 300 dpi') later(); });
  PI.lowRes = () => { const out = []; for (const [id, nodes] of assetUse()) { const eff = Math.max(...nodes.map(n => IM.ppiOf(n))); if (isPhotoData(S.doc.assets[id].data) && eff < 240) out.push({ id, name: S.doc.assets[id].name, ppi: round(eff) }); } return out; };
  PI.toggle = () => {
    if (PI.on()) { delete S.doc.printImages; O.history.commit('Фото для друку'); return toast('Фото більше не перетворюються на TIFF'); }
    ui.dialog({
      title: 'Фото для друку',
      body: `<div class="dlg-text small">${esc(t('Усі фото документа зберігатимуться як TIFF із роздільною здатністю 300 dpi: нові — під час імпорту, наявні — зараз. Під час експорту фото виходять справжніми файлами .tif.'))}</div>`,
      fields: [{ key: 'dpi', label: 'Роздільна здатність', type: 'select', value: '300', options: [['300', '300 dpi'], ['350', '350 dpi'], ['600', '600 dpi']] }, { key: 'color', label: 'Колірна модель TIFF', type: 'select', value: 'rgb', options: [['rgb', 'RGB'], ['cmyk', 'CMYK (для друкарні)']] }],
      buttons: [{ id: 'ok', label: 'Увімкнути', primary: true }],
      onOk: v => {
        const fr = model.page().children.find(n => n.type === 'frame' && n.print && n.print.ppi);
        S.doc.printImages = { fmt: 'tiff', dpi: +v.dpi, ppi: fr ? fr.print.ppi : 72, color: v.color };
        Object.values(S.doc.assets).forEach(a => { if (isPhotoData(a.data)) { a.fmt = 'tiff'; a.name = tifName(a.name); delete a.dpiDone; } });
        O.history.commit('Фото для друку');
        PI.normalize();
      }
    });
  };
  PI.export = async () => {
    const use = assetUse();
    const ids = Array.from(use.keys()).filter(id => isPhotoData(S.doc.assets[id].data));
    if (!ids.length) return toast('У документі немає фото');
    const cmyk = !!(S.doc.printImages && S.doc.printImages.color === 'cmyk');
    toast('Готуємо TIFF…');
    const files = [];
    for (const id of ids) {
      const a = S.doc.assets[id];
      const cv = await loadFull(id);
      const im = cv.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, cv.width, cv.height);
      const dpi = a.dpi || round(Math.min(...use.get(id).map(n => IM.ppiOf(n)))) || 300;
      files.push({ name: tifName(a.name).replace(/[\\/:*?"<>|]+/g, '_'), blob: IM.tiff(im, Math.min(dpi, (S.doc.printImages && S.doc.printImages.dpi) || 300), cmyk) });
    }
    if (files.length === 1) O.download(files[0].blob, files[0].name);
    else O.download(await io.zip(files), (S.doc.name || 'VIBSma') + ' — TIFF.zip');
    const low = PI.lowRes();
    toast(low.length ? 'Експортовано {n} TIFF. Увага: {k} фото мають менше 240 ppi' : 'Експортовано фото у TIFF: {n}', { n: files.length, k: low.length });
  };

  // ======================================================================
  // COMMANDS & MENU
  // ======================================================================
  const C = (id, label, run, opts) => O.cmd(id, label, run, Object.assign({ group: 'Зображення', enabled: imageSel }, opts || {}));
  const adj = (id, keys) => C(id, F[id].name, () => FL.dialog(id), keys ? { keys, when: imageSel } : {});
  MODES.forEach(([id, mode]) => {
    const label = { modeRGB: 'Колір RGB', modeLab: 'Колір Lab' }[id] || F[id].name;
    C(id, label, () => (F[id] ? setMode(id, mode) : (FL.targets().forEach(x => { x.holder.imgMode = mode; }), O.history.commit(t('Режим') + ': ' + mode.toUpperCase()))), { check: () => curMode() === mode });
  });
  C('mode8', '8 біт/канал', () => {}, { check: () => true });
  C('mode16', '16 біт/канал', () => toast('Браузер обробляє фото з 8 бітами на канал; 16 біт недоступні'));
  ['adjBC', 'adjLevels', 'adjCurves', 'adjExposure', '-', 'adjVibrance', 'adjHueSat', 'adjBalance', 'adjBW', 'adjPhotoFilter', 'adjMixer', 'adjLookup', '-', 'adjPosterize', 'adjThreshold', 'adjGradMap', 'adjSelective', '-', 'adjShadowsHi', 'adjHDR', '-', 'adjMatch', 'adjReplace', 'adjEqualize']
    .forEach(id => { if (id !== '-') adj(id, { adjLevels: ['Ctrl+L'], adjCurves: ['Ctrl+M'], adjHueSat: ['Ctrl+U'], adjBalance: ['Ctrl+B'], adjBW: ['Ctrl+Alt+Shift+B'] }[id]); });
  C('adjInvert', F.adjInvert.name, () => FL.apply('adjInvert', {}), { keys: ['Ctrl+I'], when: imageSel });
  C('adjDesat', F.adjDesat.name, () => FL.apply('adjDesat', {}), { keys: ['Ctrl+Shift+U'], when: imageSel });
  C('autoTone', 'Автоматичний тон', () => FL.apply('adjAutoTone', {}), { keys: ['Ctrl+Shift+L'], when: imageSel });
  C('autoContrast', 'Автоматичний контраст', () => FL.apply('adjAutoContrast', {}), { keys: ['Ctrl+Alt+Shift+L'], when: imageSel });
  C('autoColor', 'Автоматичний колір', () => FL.apply('adjAutoColor', {}), { keys: ['Ctrl+Shift+B'], when: imageSel });
  C('imageSize', 'Розмір зображення…', () => IM.imageSize(), { keys: ['Ctrl+Alt+I'], when: imageSel });
  C('genUpscale', 'Генеративне масштабування…', () => IM.upscale(), { keys: ['Ctrl+Alt+Shift+U'], when: imageSel });
  C('canvasSize', 'Розмір полотна…', () => IM.canvasSize(), { keys: ['Ctrl+Alt+C'], when: imageSel });
  C('rot180', '180°', () => IM.rotate('180'));
  C('rot90cw', '90° за годинниковою стрілкою', () => IM.rotate('cw'));
  C('rot90ccw', '90° проти годинникової стрілки', () => IM.rotate('ccw'));
  C('rotAny', 'Довільно…', () => IM.rotateDialog());
  C('flipCanvasH', 'Відобразити полотно по горизонталі', () => IM.rotate('fh'));
  C('flipCanvasV', 'Відобразити полотно по вертикалі', () => IM.rotate('fv'));
  C('imgCrop', 'Кадрування', () => IM.crop());
  C('imgTrim', 'Обрізка…', () => IM.trim());
  C('imgReveal', 'Показати все', () => IM.revealAll());
  C('imgDuplicate', 'Дублювати…', () => IM.duplicate(), { enabled: () => true });
  C('applyImage', 'Застосувати зображення…', () => IM.applyImage(), { enabled: () => !!twoPhotos() });
  C('calculations', 'Підрахунки…', () => IM.calculations(), { enabled: () => !!twoPhotos() });
  C('varDefine', 'Визначити…', () => IM.varDefine(), { enabled: () => O.sel().length > 0 });
  C('varDataSets', 'Застосувати набори даних…', () => IM.dataSets(), { enabled: () => true });
  C('trap', 'Трепінг…', () => IM.trap(), { enabled: () => O.topSel().length > 0 });
  C('measScale', 'Встановити масштаб вимірювання…', () => IM.measureScale(), { enabled: () => true });
  C('measRecord', 'Записати вимірювання', () => IM.measure(), { enabled: () => O.topSel().length > 0 });
  C('measLog', 'Журнал вимірювань…', () => IM.measureLog(), { enabled: () => true });
  C('printImages', 'Фото для друку: TIFF 300 dpi', () => PI.toggle(), { group: 'Файл', enabled: () => true, check: () => PI.on() });
  C('printTiffExport', 'Експорт фото для друку (TIFF)…', () => PI.export(), { group: 'Файл', enabled: () => true });

  const sub = (label, items) => ({ label, items });
  const imageMenu = [
    sub('Режим', ['modeBitmap', 'modeGray', 'modeDuotone', 'modeIndexed', 'modeRGB', 'modeCMYK', 'modeLab', '-', 'mode8', 'mode16']),
    '-',
    sub('Коригування', ['adjBC', 'adjLevels', 'adjCurves', 'adjExposure', '-', 'adjVibrance', 'adjHueSat', 'adjBalance', 'adjBW', 'adjPhotoFilter', 'adjMixer', 'adjLookup', '-', 'adjInvert', 'adjPosterize', 'adjThreshold', 'adjGradMap', 'adjSelective', '-', 'adjShadowsHi', 'adjHDR', 'adjDesat', 'adjMatch', 'adjReplace', 'adjEqualize']),
    '-',
    'autoTone', 'autoContrast', 'autoColor',
    '-',
    'imageSize', 'genUpscale', 'canvasSize',
    sub('Обертання зображення', ['rot180', 'rot90cw', 'rot90ccw', 'rotAny', '-', 'flipCanvasH', 'flipCanvasV']),
    'imgCrop', 'imgTrim', 'imgReveal',
    '-',
    'imgDuplicate', 'applyImage', 'calculations',
    '-',
    sub('Змінні', ['varDefine']), 'varDataSets',
    '-',
    'trap',
    '-',
    sub('Аналіз', ['measScale', 'measRecord', 'measLog'])
  ];
  const at = O.MENUS.findIndex(m => m[0] === 'Об’єкт');
  O.MENUS.splice(at >= 0 ? at + 1 : 2, 0, ['Зображення', imageMenu]);
  const file = O.MENUS.find(m => m[0] === 'Файл');
  if (file) { const items = file[1], i = items.indexOf('exportDialog'); items.splice(i >= 0 ? i : items.length, 0, 'printImages', 'printTiffExport', '-'); }
})();
