'use strict';
/* VIBSma — InDesign-style text UI on top of typeset.js:
   · Design panel: text styles, Character, Paragraph, Bullets & numbering, Text frame (columns), Quick actions, notes
   · the «Text» menu as in InDesign: font / size, character & paragraph panels, tabs, glyphs, story, styles, find font,
     change case, type on a path, notes, track changes, footnotes / endnotes, hyperlinks & cross-references, text variables,
     lists, special characters, white space, break characters, placeholder text, hidden characters
   · rich editing on the canvas: caret, selection, mouse and arrow keys for columns / mixed formatting */
(function () {
  const O = window.O, M = O.M, model = O.model, S = O.state, V = O.view, ui = O.ui, TS = O.typeset;
  const esc = O.esc, fmt = O.fmt;
  const t = (s, v) => O.t(s, v);
  const TU = O.typeui = {};
  const CH = TS.CH;
  const isSet = v => v !== undefined && v !== null;
  const C = (id, label, run, opts) => O.cmd(id, label, run, Object.assign({ group: 'Текст' }, opts || {}));
  const sub = (label, items) => ({ label, items });

  // ---------- icons ----------
  Object.assign(O.ICONS, {
    aLeft: '<path d="M4 6h16M4 10h10M4 14h16M4 18h10"/>',
    aCenter: '<path d="M4 6h16M7 10h10M4 14h16M7 18h10"/>',
    aRight: '<path d="M4 6h16M10 10h10M4 14h16M10 18h10"/>',
    aJustL: '<path d="M4 6h16M4 10h16M4 14h16M4 18h9"/>',
    aJustC: '<path d="M4 6h16M4 10h16M4 14h16M7.5 18h9"/>',
    aJustR: '<path d="M4 6h16M4 10h16M4 14h16M11 18h9"/>',
    aJustAll: '<path d="M4 6h16M4 10h16M4 14h16M4 18h16"/>',
    aSpine: '<path d="M4 6h12M8 10h8M4 14h12M8 18h8M20 4v16"/>',
    aAway: '<path d="M8 6h12M8 10h8M8 14h12M8 18h8M4 4v16"/>',
    pLi: '<path d="M11 6h9M11 10h9M11 14h9M11 18h9M3 12h5M6 10l2 2-2 2"/>',
    pRi: '<path d="M4 6h9M4 10h9M4 14h9M4 18h9M21 12h-5M18 10l-2 2 2 2"/>',
    pFi: '<path d="M11 6h9M4 10h16M4 14h16M4 18h16M3 6h5M6 4l2 2-2 2"/>',
    pLri: '<path d="M4 6h16M4 10h16M4 14h16M4 18h9M21 18h-5M18 16l-2 2 2 2"/>',
    pSb: '<path d="M4 13h16M4 17h16M4 21h16M12 3v6M10 7l2 2 2-2"/>',
    pSa: '<path d="M4 3h16M4 7h16M4 11h16M12 15v6M10 19l2 2 2-2"/>',
    pDcl: '<path d="M4 5h6v8H4zM13 6h7M13 10h7M4 16h16M4 20h16"/>',
    pDcc: '<path d="M4 13l3-8 3 8M5.2 10h3.6M13 6h7M13 10h7M4 16h16M4 20h16"/>',
    pGrid: '<path d="M4 6h16M4 12h16M4 18h16" stroke-dasharray="2 2"/><path d="M7 9.5h10M7 15.5h10"/>',
    tLead: '<path d="M4 7h10M4 17h10M18 5v14M16 7l2-2 2 2M16 17l2 2 2-2"/>',
    tTrack: '<path d="M4 6l3 9 3-9M12 6l3 9 3-9M4 19h16M6 17l-2 2 2 2M18 17l2 2-2 2"/>',
    tKern: '<path d="M4 6l3 9 3-9M11 6l3 9 3-9M10 19h4"/>',
    tVs: '<path d="M7 18V6M4 6h6M14 18V9M11 9h6M20 5v14"/>',
    tHs: '<path d="M7 16V8M4 8h6M14 16V8M11 8h6M4 20h16"/>',
    tBs: '<path d="M5 18l3-9 3 9M6 15h4M15 12V6M13 8l2-2 2 2M4 20h16"/>',
    tSkew: '<path d="M9 18l4-12M7 18h6M11 6h6"/>',
    tBullet: '<circle cx="5.5" cy="7" r="1.3" fill="currentColor"/><circle cx="5.5" cy="12" r="1.3" fill="currentColor"/><circle cx="5.5" cy="17" r="1.3" fill="currentColor"/><path d="M10 7h10M10 12h10M10 17h10"/>',
    tNumber: '<path d="M4.5 5.5l1.5-1v5M4 13.5c0-1 2.6-1.4 2.6 0 0 1-2.6 2-2.6 3h2.8M10 7h10M10 12h10M10 17h10"/>',
    tCols: '<rect x="3.5" y="5" width="7" height="14" rx="1"/><rect x="13.5" y="5" width="7" height="14" rx="1"/>',
    tSingle: '<path d="M4 7h16M4 12h11M4 17h16"/>',
    tComposer: '<path d="M4 7h16M4 12h16M4 17h16"/><circle cx="18" cy="12" r="1.2" fill="currentColor"/>'
  });

  // ---------- targets ----------
  const taEl = () => O.$('#text-editor');
  const texts = () => O.sel().filter(n => n.type === 'text');
  const areaTexts = () => texts().filter(n => !n.path);
  const editNode = () => (S.textEdit ? model.get(S.textEdit.id) : null);
  // editing with a caret or a selection: { n, a, b }
  TU.target = () => {
    const n = editNode();
    if (!n || n.path) return null;
    const e = taEl();
    return { n, a: Math.min(e.selectionStart, e.selectionEnd), b: Math.max(e.selectionStart, e.selectionEnd) };
  };
  let lastCaret = null, lastUiDown = 0;
  const refocus = () => {
    if (!S.textEdit) return;
    const e = taEl();
    if (document.activeElement !== e) { try { e.focus({ preventScroll: true }); } catch (err) { e.focus(); } }
  };
  TU.refocus = refocus;
  // clicks in the Design panel, the menus and text dialogs keep the text in edit mode
  TU.keepEditing = () => {
    const ae = document.activeElement;
    if (ae && ae !== document.body && ae.closest && ae.closest('#props, .dlg-back, .menu, #menubar, #tool-options')) return true;
    if (Date.now() - lastUiDown < 1500) { setTimeout(refocus, 0); return true; }
    return false;
  };
  document.addEventListener('pointerdown', e => {
    const tg = e.target;
    if (!tg || !tg.closest) return;
    if (tg.closest('#props, .menu, #menubar, .dlg-back, .ui-picker, .picker, #toast')) { lastUiDown = Date.now(); return; }
    // anywhere else outside the canvas (layers, pages, top bar): leave the text
    if (S.textEdit && !tg.closest('#text-editor, #canvas')) O.textEdit.end(true);
  }, true);
  // a closed menu / dialog gives the keyboard back to the text
  new MutationObserver(muts => {
    if (!S.textEdit) return;
    for (const m of muts) for (const nd of m.removedNodes) if (nd.classList && (nd.classList.contains('menu') || nd.classList.contains('dlg-back'))) { setTimeout(() => { const ae = document.activeElement; if (!ae || ae === document.body) refocus(); }, 0); return; }
  }).observe(document.body, { childList: true });
  document.addEventListener('focusout', () => setTimeout(() => { if (S.textEdit && (!document.activeElement || document.activeElement === document.body)) refocus(); }, 40), true);

  const fontLoad = (fam, st) => { if (O.fonts && O.fonts.get(fam)) O.fonts.load(O.fonts.get(fam).family, st ? st.weight : 400, st ? st.italic : false).then(() => { O.text.reset(); O.requestRender(); O.emit('fonts'); }); };
  const afterEdit = () => { if (S.textEdit) { O.textEdit.sync(); O.requestRender(); O.requestOverlay(); setTimeout(refocus, 0); } };

  // ---------- applying attributes ----------
  const setFrameChar = (n, props) => {
    for (const k of Object.keys(props)) {
      const v = props[k];
      if (k === 'under' || k === 'strike') {
        const set = new Set(String(n.deco || 'none').split(/\s+/).filter(x => x && x !== 'none'));
        const tok = k === 'under' ? 'underline' : 'line-through';
        if (v) set.add(tok); else set.delete(tok);
        n.deco = set.size ? Array.from(set).join(' ') : 'none';
      } else if (k === 'color') { if (v) n.fills = [O.paint.solid(v)]; }
      else if (k === 'cs') continue;
      else if (v === null || v === undefined) delete n[k];
      else n[k] = O.clone(v);
    }
    TS.stripKey(n, 'runs', Object.keys(props));
  };
  TU.setChar = props => {
    const tg = TU.target();
    if (tg) {
      if (tg.a === tg.b) {
        S.textEdit.pending = Object.assign({}, S.textEdit.pending || {}, props);
        S.textEdit.pendingAt = tg.a;
      } else TS.applyRange(tg.n, 'runs', tg.a, tg.b, props);
      if (props.font) fontLoad(props.font, props);
      afterEdit();
      return;
    }
    for (const n of texts()) setFrameChar(n, props);
    if (props.font) fontLoad(props.font, props);
  };
  TU.setPara = props => {
    const tg = TU.target();
    if (tg) {
      const [ps, pe] = TS.paraRange(tg.n.text || '', tg.a, tg.b);
      TS.applyRange(tg.n, 'pars', ps, pe + 1, props);
      afterEdit();
      return;
    }
    for (const n of texts()) {
      for (const k of Object.keys(props)) { const v = props[k]; if (v === null || v === undefined) delete n[k]; else n[k] = O.clone(v); }
      TS.stripKey(n, 'pars', Object.keys(props));
    }
  };
  const forFrames = fn => { const set = new Set(texts()); const en = editNode(); if (en) set.add(en); for (const n of set) if (!n.path) fn(n); };
  const ensureWidth = n => { if (n.width === null || n.width === undefined) n.width = Math.max(120, Math.ceil(O.text.layout(n).w)); };
  // columns: point text gets a readable frame width (not its whole one-line length, which put every column
  // into one thin strip), and a column never gets narrower than a few characters — the frame widens instead
  const MAX_COLS = 99;
  const setCols = (n, cols) => {
    cols = O.clamp(Math.round(cols) || 1, 1, MAX_COLS);
    const gap = cols > 1 ? (isSet(n.colGap) ? +n.colGap : 12) : 0, size = n.size || 16;
    const ins = Array.isArray(n.inset) ? (+n.inset[1] || 0) + (+n.inset[3] || 0) : 0;
    if (n.width === null || n.width === undefined) n.width = Math.max(120, Math.ceil(Math.min(O.text.layout(n).w + ins, cols * O.clamp(size * 18, 160, 400) + gap * (cols - 1) + ins)));
    const minW = cols * Math.max(48, size * 4) + gap * (cols - 1) + ins;
    if (n.width < minW) n.width = Math.ceil(minW);
    if (cols > 1) n.cols = cols; else delete n.cols;
  };
  // values shown in the panel: at the caret / selection start while editing, else the frame defaults
  TU.cur = () => {
    const tg = TU.target();
    if (tg) {
      let st = TS.charAt(tg.n, tg.a, tg.a === tg.b);
      if (tg.a === tg.b && S.textEdit.pending) st = TS.mkStyle(st, S.textEdit.pending);
      const [ps] = TS.paraRange(tg.n.text || '', tg.a, tg.a);
      const r = TS.resolvePara(tg.n, ps, TS.frameChar(tg.n));
      return { n: tg.n, st, P: r.P, editing: true, a: tg.a, b: tg.b };
    }
    const n = texts()[0];
    if (!n) return null;
    const P = TS.framePara(n);
    P.ps = n.pstyle || null;
    return { n, st: TS.mkStyle(TS.frameChar(n)), P, editing: false };
  };

  // ---------- styles ----------
  const pstyles = () => (S.doc.pstyles = S.doc.pstyles || []);
  const cstyles = () => (S.doc.cstyles = S.doc.cstyles || []);
  TU.styleTab = 'p';
  const charPropsOf = st => {
    const p = { font: st.font, weight: st.weight, italic: st.italic, size: st.size, ls: st.ls, lh: st.lh, tcase: st.tcase };
    for (const k of ['kern', 'hs', 'vs', 'bs', 'skew', 'smcaps', 'pos', 'ot', 'lang', 'nobreak']) { const def = { kern: 'metrics', hs: 100, vs: 100, bs: 0, skew: 0, smcaps: false, pos: 'normal', ot: null, lang: null, nobreak: false }[k]; if (JSON.stringify(st[k]) !== JSON.stringify(def)) p[k] = st[k]; }
    p.deco = [st.under ? 'underline' : '', st.strike ? 'line-through' : ''].filter(Boolean).join(' ') || 'none';
    return p;
  };
  const paraPropsOf = P => { const o = {}; for (const k of TS.PARA_KEYS) if (isSet(P[k]) && JSON.stringify(P[k]) !== JSON.stringify(TS.DEF_PARA[k]) || k === 'align') o[k] = O.clone(P[k]); return o; };
  const currentStyleProps = () => {
    const c = TU.cur();
    if (!c) return null;
    if (!c.editing) return O.print.styleOf(c.n);
    const p = Object.assign(charPropsOf(c.st), paraPropsOf(c.P));
    p.color = c.st.color || (c.n.fills && c.n.fills[0] && c.n.fills[0].type === 'solid' ? c.n.fills[0].color : null);
    return p;
  };
  const styleOverridden = c => {
    if (!c || !c.P.ps) return false;
    const st = TS.pstyle(c.P.ps);
    if (!st) return false;
    if (c.editing) {
      const r = TS.runAt(c.n.pars, TS.paraRange(c.n.text || '', c.a, c.a)[0]);
      if (r && TS.PARA_KEYS.some(k => r[k] !== undefined)) return true;
      return (c.n.runs || []).some(x => x.s < c.b + 1 && x.e > c.a && TS.CHAR_KEYS.some(k => x[k] !== undefined));
    }
    const cur = O.print.styleOf(c.n);
    return Object.keys(st.props).some(k => k !== 'color' && JSON.stringify(isSet(st.props[k]) ? st.props[k] : null) !== JSON.stringify(isSet(cur[k]) ? cur[k] : (TS.DEF_PARA[k] !== undefined ? TS.DEF_PARA[k] : null))) || (c.n.runs || []).length > 0;
  };
  TU.applyPStyle = id => {
    const st = id ? TS.pstyle(id) : null;
    const tg = TU.target();
    if (tg) {
      const [ps, pe] = TS.paraRange(tg.n.text || '', tg.a, tg.b);
      TS.applyRange(tg.n, 'pars', ps, pe + 1, { ps: id || null }, st ? Object.keys(TS.splitProps(st.props).p) : []);
      afterEdit();
      return;
    }
    for (const n of texts()) { if (st) O.print.applyStyle(n, st); else delete n.pstyle; }
  };
  TU.applyCStyle = id => {
    const st = id ? TS.cstyle(id) : null;
    const rm = st ? Object.keys(TS.splitProps(st.props).c) : [];
    const tg = TU.target();
    if (tg) {
      if (tg.a === tg.b) { S.textEdit.pending = Object.assign({}, S.textEdit.pending || {}, { cs: id || null }); S.textEdit.pendingAt = tg.a; }
      else TS.applyRange(tg.n, 'runs', tg.a, tg.b, { cs: id || null }, rm);
      afterEdit();
      return;
    }
    for (const n of texts()) TS.applyRange(n, 'runs', 0, Math.max(1, (n.text || '').length), { cs: id || null }, rm);
  };
  TU.clearOverrides = () => {
    const tg = TU.target();
    if (tg) {
      const [ps, pe] = TS.paraRange(tg.n.text || '', tg.a, tg.b);
      TS.applyRange(tg.n, 'pars', ps, pe + 1, {}, TS.PARA_KEYS);
      if (tg.b > tg.a) TS.applyRange(tg.n, 'runs', tg.a, tg.b, {}, TS.CHAR_KEYS);
      else TS.applyRange(tg.n, 'runs', ps, pe, {}, TS.CHAR_KEYS);
      afterEdit();
    } else for (const n of texts()) {
      const st = n.pstyle && TS.pstyle(n.pstyle);
      if (st) O.print.applyStyle(n, st);
      TS.stripKey(n, 'runs', TS.CHAR_KEYS);
      TS.stripKey(n, 'pars', TS.PARA_KEYS);
    }
    O.history.commit('Очистити перевизначення');
  };

  // ---------- panel ----------
  const WEIGHTS = [[100, 'Thin'], [200, 'Extra Light'], [300, 'Light'], [400, 'Regular'], [500, 'Medium'], [600, 'Semi Bold'], [700, 'Bold'], [800, 'Extra Bold'], [900, 'Black']];
  const FONTS = ['Arial', 'Helvetica', 'Segoe UI', 'Roboto', 'Inter', 'Verdana', 'Tahoma', 'Trebuchet MS', 'Georgia', 'Times New Roman', 'Palatino Linotype', 'Garamond', 'Courier New', 'Consolas', 'Impact', 'Calibri', 'Cambria', 'serif', 'sans-serif', 'monospace'];
  TU.LANGS = [['', 'За замовчуванням'], ['uk', 'Українська'], ['en-US', 'Англійська: США'], ['en-GB', 'Англійська: Велика Британія'], ['de-2006', 'Німецька: реформа 2006'], ['de-CH', 'Німецька: Швейцарія'], ['ru', 'Російська'], ['pl', 'Польська'], ['fr', 'Французька'], ['es', 'Іспанська'], ['it', 'Італійська'], ['cs', 'Чеська'], ['none', '[Без мови]']];
  const ALIGNS = [['left', 'aLeft', 'Вирівняти ліворуч'], ['center', 'aCenter', 'Вирівняти по центру'], ['right', 'aRight', 'Вирівняти праворуч'], ['justify', 'aJustL', 'За шириною, останній рядок ліворуч'], ['justify-center', 'aJustC', 'За шириною, останній рядок по центру'], ['justify-right', 'aJustR', 'За шириною, останній рядок праворуч'], ['justify-all', 'aJustAll', 'За шириною всі рядки'], ['spine', 'aSpine', 'Вирівняти до корінця'], ['away', 'aAway', 'Вирівняти від корінця']];
  const ib = (attrs, icon, title, on) => { const tt = esc(t(title)); return `<button type="button" class="ib${on ? ' on' : ''}" ${attrs} title="${tt}" aria-label="${tt}">${O.icon(icon, 16)}</button>`; };
  const tb = (attrs, label, title, on) => { const tt = esc(t(title)); return `<button type="button" class="ib ty-tb${on ? ' on' : ''}" ${attrs} title="${tt}" aria-label="${tt}"><span class="ty-tbl">${label}</span></button>`; };
  const fld = (f, val, icon, title, opts = {}) => {
    const lab = icon && icon.startsWith('<') ? icon : esc(t(icon || ''));
    const tt = esc(t(title));
    return `<label class="fld${opts.cls ? ' ' + opts.cls : ''}" title="${tt}"><span class="fl scrub" data-scrub="${f}"${opts.step ? ` data-step="${opts.step}"` : ''}>${lab}</span><input type="text" inputmode="decimal" data-f="${f}"${opts.i !== undefined ? ` data-i="${opts.i}"` : ''} value="${esc(val)}" spellcheck="false" aria-label="${tt}"${opts.list ? ` list="${opts.list}"` : ''}>${opts.unit ? `<em>${esc(opts.unit)}</em>` : ''}</label>`;
  };
  const sel = (f, val, options, label, raw) => `<select class="sel" data-f="${f}" aria-label="${esc(t(label))}" title="${esc(t(label))}">${options.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(val) ? ' selected' : ''}>${esc(raw ? l : t(l))}</option>`).join('')}</select>`;
  const sec = (title, body, extra = '', key = '') => `<section class="ps"${key ? ` data-sec="${key}"` : ''}><div class="ps-h"><span>${esc(t(title))}</span><span class="ps-x">${extra}</span></div>${body}</section>`;
  const chk = (f, on, label) => `<label class="chk"><input type="checkbox" data-f="${f}"${on ? ' checked' : ''}><span>${esc(t(label))}</span></label>`;
  const btn = (cmd, label) => `<button type="button" class="btn ty-qa" data-cmd="${cmd}">${esc(t(label))}</button>`;

  TU.sections = (list) => {
    const c = TU.cur();
    if (!c) return '';
    const n = c.n, st = c.st, P = c.P;
    const area = list.filter(x => !x.path);
    let h = '';
    // text styles
    {
      const tab = TU.styleTab;
      let body = `<div class="ty-tabs" role="tablist"><button type="button" class="${tab === 'p' ? 'on' : ''}" data-f="ty-stab" data-v="p">${esc(t('Стилі абзацу'))}</button><button type="button" class="${tab === 'c' ? 'on' : ''}" data-f="ty-stab" data-v="c">${esc(t('Стилі символу'))}</button></div>`;
      if (tab === 'p') {
        const over = styleOverridden(c);
        body += `<div class="row ty-style-row"><span class="ty-ag">Ag</span>${sel('ty-pstyle', P.ps || '', [['', t('[Основний абзац]')]].concat(pstyles().map(s => [s.id, s.name + (s.id === P.ps && over ? '+' : '')])), 'Стиль абзацу', true)}</div>`;
        body += `<div class="row">${ib('data-cmd="tyClearOverrides"', 'close', 'Очистити перевизначення', false)}${ib('data-cmd="tyRedefineStyle"', 'check', 'Перевизначити стиль за виділеним', false)}<span class="sp"></span>${ib('data-cmd="tyNewPStyle"', 'plus', 'Новий стиль абзацу з виділеного', false)}${ib('data-cmd="tyParaStyles"', 'sliders', 'Стилі абзацу… (F11)', false)}</div>`;
      } else {
        const r = c.editing ? TS.runAt(n.runs, c.a) : null;
        const cur = r && r.cs ? r.cs : (!c.editing && (n.runs || []).length && n.runs.every(x => x.cs === n.runs[0].cs) ? n.runs[0].cs || '' : '');
        body += `<div class="row ty-style-row"><span class="ty-ag">a</span>${sel('ty-cstyle', cur || '', [['', t('[Без стилю]')]].concat(cstyles().map(s => [s.id, s.name])), 'Стиль символу', true)}</div>`;
        body += `<div class="row"><span class="sp"></span>${ib('data-cmd="tyNewCStyle"', 'plus', 'Новий стиль символу з виділеного', false)}${ib('data-cmd="tyCharStyles"', 'sliders', 'Стилі символів… (Shift+F11)', false)}</div>`;
      }
      h += sec('Стиль тексту', body, '', 'ty-styles');
    }
    // character
    {
      const fonts = Array.from(new Set(FONTS.concat((S.doc.fonts || []).map(f => f.family), O.io.localFonts || [], O.fonts && O.fonts.google ? O.fonts.google.map(g => g.family) : [])));
      const gf = O.fonts && O.fonts.get(st.font);
      let b = `<div class="row font-row"><input class="fontin" list="ty-font-list" data-f="font" value="${esc(st.font)}" aria-label="${esc(t('Шрифт'))}" spellcheck="false"${gf ? ` style="font-family:'${esc(gf.family)}', var(--font)"` : ''}><datalist id="ty-font-list">${fonts.map(f => `<option value="${esc(f)}">`).join('')}</datalist><button type="button" class="btn font-pick" data-cmd="tyFontPick" title="${esc(t('Усі шрифти, включно з Google Fonts'))}">${O.icon('search', 13)}</button></div>`;
      const styles = [];
      for (const [w, nm] of WEIGHTS) { styles.push([w + '|', nm]); styles.push([w + '|i', nm === 'Regular' ? 'Italic' : nm + ' Italic']); }
      b += `<div class="row">${sel('ty-style', st.weight + '|' + (st.italic ? 'i' : ''), styles, 'Накреслення', true)}</div>`;
      const sizes = [6, 7, 8, 9, 10, 11, 12, 14, 18, 24, 30, 36, 48, 60, 72];
      b += `<datalist id="ty-sizes">${sizes.map(s => `<option value="${s}">`).join('')}</datalist>`;
      b += `<div class="grid2">${fld('ty-size', fmt(st.size), O.icon('font', 12), 'Розмір шрифту', { list: 'ty-sizes' })}${fld('ty-lead', st.lh ? fmt(st.size * st.lh) : '(' + fmt(st.size * 1.2) + ')', O.icon('tLead', 13), 'Інтерліньяж (порожньо — авто)')}</div>`;
      b += `<div class="grid2"><label class="fld ty-selfld" title="${esc(t('Кернінг'))}"><span class="fl">${O.icon('tKern', 13)}</span>${sel('ty-kern', st.kern, [['metrics', 'Метрика'], ['optical', 'Оптичний'], ['none', '0']], 'Кернінг')}</label>${fld('ty-track', fmt(st.ls / st.size * 1000, 0), O.icon('tTrack', 13), 'Трекінг (1/1000 em)')}</div>`;
      b += `<div class="grid2">${fld('ty-vs', fmt(st.vs), O.icon('tVs', 13), 'Вертикальне масштабування', { unit: '%' })}${fld('ty-hs', fmt(st.hs), O.icon('tHs', 13), 'Горизонтальне масштабування', { unit: '%' })}</div>`;
      b += `<div class="grid2">${fld('ty-bs', fmt(st.bs), O.icon('tBs', 13), 'Зсув базової лінії', { unit: 'px' })}${fld('ty-skew', fmt(st.skew), O.icon('tSkew', 13), 'Нахил (фальшивий курсив)', { unit: '°' })}</div>`;
      b += `<div class="row">${sel('ty-lang', st.lang || '', TU.LANGS, 'Мова')}<button type="button" class="btn" data-cmd="tyOpenType">OpenType</button></div>`;
      b += `<div class="row ty-toggles">${tb('data-f="ty-caps" data-v="all"', 'TT', 'Усі великі (Ctrl+Shift+K)', st.tcase === 'upper')}${tb('data-f="ty-caps" data-v="small"', 'T<small>T</small>', 'Капітель (Ctrl+Shift+H)', st.smcaps)}${tb('data-f="ty-caps" data-v="lower"', 'tt', 'Усі малі', st.tcase === 'lower')}${tb('data-f="ty-pos" data-v="sup"', 'T<sup>1</sup>', 'Верхній індекс (Ctrl+Shift+=)', st.pos === 'sup')}${tb('data-f="ty-pos" data-v="sub"', 'T<sub>1</sub>', 'Нижній індекс (Ctrl+Alt+Shift+=)', st.pos === 'sub')}${tb('data-f="deco" data-v="underline"', '<u>T</u>', 'Підкреслення (Ctrl+U)', st.under)}${tb('data-f="deco" data-v="line-through"', '<s>T</s>', 'Закреслення', st.strike)}${tb('data-f="italic"', '<i>T</i>', 'Курсив (Ctrl+I)', st.italic)}</div>`;
      const col = st.color || (n.fills && n.fills[0] && n.fills[0].type === 'solid' ? n.fills[0].color : '#000000');
      b += `<div class="row"><label class="ty-color" title="${esc(t('Колір символів'))}"><input type="color" data-f="ty-color" value="${esc(col)}" aria-label="${esc(t('Колір символів'))}"><span>${esc(t('Колір символів'))}</span></label><span class="sp"></span>${ib('data-cmd="tyCharMore"', 'more', 'Інші параметри символів…', false)}</div>`;
      h += sec('Символ', b, '', 'ty-char');
    }
    // paragraph
    {
      let b = `<div class="row ty-align">${ALIGNS.map(([v, ic, tt]) => ib(`data-f="ty-align" data-v="${v}"`, ic, tt, (P.align || 'left') === v)).join('')}</div>`;
      b += `<div class="grid2">${fld('ty-li', fmt(P.li), O.icon('pLi', 13), 'Відступ ліворуч')}${fld('ty-ri', fmt(P.ri), O.icon('pRi', 13), 'Відступ праворуч')}</div>`;
      b += `<div class="grid2">${fld('ty-fi', fmt(P.fi), O.icon('pFi', 13), 'Відступ першого рядка')}${fld('ty-lri', fmt(P.lri), O.icon('pLri', 13), 'Відступ останнього рядка праворуч')}</div>`;
      b += `<div class="grid2">${fld('ty-spb', fmt(P.spb), O.icon('pSb', 13), 'Інтервал перед абзацом')}${fld('ty-spa', fmt(P.spa), O.icon('pSa', 13), 'Інтервал після абзацу')}</div>`;
      b += `<div class="grid2"><label class="fld ty-selfld" title="${esc(t('Вирівнювання за базовою сіткою'))}"><span class="fl">${O.icon('pGrid', 13)}</span>${sel('ty-grid', P.grid || 'none', [['none', 'Ігнорувати'], ['all', 'Усі рядки'], ['first', 'Лише перший рядок']], 'Вирівнювання за базовою сіткою')}</label><span></span></div>`;
      b += `<div class="grid2">${fld('ty-dcl', fmt(P.dcl || 0, 0), O.icon('pDcl', 13), 'Буквиця: кількість рядків')}${fld('ty-dcc', fmt(P.dcc || 1, 0), O.icon('pDcc', 13), 'Буквиця: кількість символів')}</div>`;
      const shOn = !!(P.shade && P.shade.on !== false), bdOn = !!(P.border && P.border.on !== false);
      b += `<div class="row ty-chkrow">${chk('ty-shade', shOn, 'Затінення')}<span class="sp"></span><input type="color" data-f="ty-shadec" value="${esc((P.shade && P.shade.c) || '#E8E8E8')}" aria-label="${esc(t('Колір затінення'))}" title="${esc(t('Колір затінення'))}"></div>`;
      b += `<div class="row ty-chkrow">${chk('ty-border', bdOn, 'Межа')}<span class="sp"></span><input type="color" data-f="ty-borderc" value="${esc((P.border && P.border.c) || '#1E1E24')}" aria-label="${esc(t('Колір межі'))}" title="${esc(t('Колір межі'))}"></div>`;
      b += `<div class="row ty-chkrow">${chk('ty-hyph', !!P.hyph, 'Переноси')}<span class="sp"></span>${ib('data-f="ty-composer" data-v="single"', 'tSingle', 'Однорядковий компонувальник', P.composer !== 'para')}${ib('data-f="ty-composer" data-v="para"', 'tComposer', 'Компонувальник абзацу', P.composer === 'para')}</div>`;
      b += `<div class="row"><button type="button" class="btn" data-cmd="tyTabs">${esc(t('Табулятори…'))}</button><span class="sp"></span>${ib('data-cmd="tyParaMore"', 'more', 'Інші параметри абзацу…', false)}</div>`;
      h += sec('Абзац', b, '', 'ty-para');
    }
    // bullets & numbering
    {
      const L0 = P.list;
      const b = `<div class="row">${ib('data-f="ty-list" data-v="bullet"', 'tBullet', 'Маркований список', !!(L0 && L0.t === 'bullet'))}${ib('data-f="ty-list" data-v="num"', 'tNumber', 'Нумерований список', !!(L0 && L0.t === 'num'))}<span class="sp"></span><button type="button" class="btn" data-cmd="tyListOptions">${esc(t('Параметри'))}</button></div>`;
      h += sec('Маркери та нумерація', b, '', 'ty-list');
    }
    // text frame: columns, inset, vertical justification, threads
    if (area.length) {
      const f = area.includes(n) ? n : area[0];
      const cols = f.cols || 1;
      let b = `<div class="row ty-cols">${O.icon('tCols', 16)}<span class="ty-lab">${esc(t('Колонки'))}</span>${ib('data-f="ty-colstep" data-v="-1"', 'minus', 'Менше колонок', false)}<label class="fld ty-num"><input type="text" inputmode="numeric" data-f="ty-cols" value="${cols}" aria-label="${esc(t('Кількість колонок'))}"></label>${ib('data-f="ty-colstep" data-v="1"', 'plus', 'Більше колонок', false)}</div>`;
      if (cols > 1) b += `<div class="grid2">${fld('ty-gap', fmt(isSet(f.colGap) ? f.colGap : 12), 'Проміжок', 'Проміжок між колонками', { unit: 'px' })}${chk('ty-bal', !!f.colBal, 'Балансувати')}</div>`;
      b += `<div class="row">${sel('tmode', f.width === null || f.width === undefined ? 'auto' : 'fixed', [['auto', 'Автоширина'], ['fixed', 'Фіксована ширина']], 'Ширина тексту')}</div>`;
      b += `<div class="row"><label class="chk"><input type="checkbox" data-pt="box"${f.boxH ? ' checked' : ''}><span>${esc(t('Фіксована висота фрейма'))}</span></label></div>`;
      if (f.boxH) b += `<div class="grid2"><label class="fld"><span class="fl">${esc(t('Висота'))}</span><input type="text" inputmode="decimal" data-pt="boxH" value="${fmt(f.boxH)}" aria-label="${esc(t('Висота фрейма'))}"></label>${sel('ty-valign', f.valign || 'top', [['top', 'Вгору'], ['center', 'По центру'], ['bottom', 'Вниз'], ['justify', 'Розподілити']], 'Вертикальне вирівнювання')}</div>`;
      b += `<div class="row">${fld('ty-inset', Array.isArray(f.inset) ? (f.inset.every(v => v === f.inset[0]) ? fmt(f.inset[0]) : f.inset.map(v => fmt(v)).join(', ')) : '0', 'Відступи', 'Внутрішні відступи: одне число або «верх, право, низ, ліво»')}</div>`;
      b += `<div class="row">${chk('ty-optical', !!f.optical, 'Оптичне вирівнювання полів')}</div>`;
      const ch = O.print && O.print.chainOf ? O.print.chainOf(f) : null;
      const over = ch ? O.print.overset(ch[ch.length - 1]) : O.print && O.print.overset(f);
      if (ch) b += `<div class="row note">${esc(t('Ланцюжок: фрейм {i} із {n}', { i: ch.indexOf(f) + 1, n: ch.length }))}${over ? ` · <b class="warn">${esc(t('текст не вміщається'))}</b>` : ''}</div>`;
      else if (over) b += `<div class="row note"><b class="warn">${esc(t('Текст не вміщається у фрейм'))}</b></div>`;
      b += `<div class="row ty-wrap"><button type="button" class="btn" data-cmd="pubThread">${esc(t('Зв’язати'))}</button>${ch ? `<button type="button" class="btn" data-cmd="pubUnthread">${esc(t('Розірвати'))}</button>` : ''}<button type="button" class="btn" data-cmd="pubPlaceText">${esc(t('Помістити текст…'))}</button></div>`;
      b += `<div class="row"><button type="button" class="btn wide" data-cmd="tyFrameOptions">${esc(t('Параметри текстового фрейма…'))}</button></div>`;
      h += sec('Текстовий фрейм', b, '', 'ty-frame');
    }
    // notes of the frame
    if (list.length === 1) {
      let b = '';
      (n.fnotes || []).forEach((x, i) => { b += `<div class="row ty-note"><span class="ty-nl">${esc(TS.fmtNum(i + TS.fnOpts().start, TS.fnOpts().style))}</span><input type="text" class="ty-nin" data-f="ty-fn" data-i="${i}" value="${esc(x.text || '')}" aria-label="${esc(t('Текст виноски'))}"></div>`; });
      if (b) h += sec('Виноски', b);
      b = '';
      (n.enotes || []).forEach((x, i) => { b += `<div class="row ty-note"><span class="ty-nl">${esc(TS.fmtNum(i + TS.enOpts().start, TS.enOpts().style))}</span><input type="text" class="ty-nin" data-f="ty-en" data-i="${i}" value="${esc(x.text || '')}" aria-label="${esc(t('Текст кінцевої виноски'))}"></div>`; });
      if (b) h += sec('Кінцеві виноски', b);
      b = '';
      (n.notes || []).forEach((x, i) => { b += `<div class="row ty-note"><span class="ty-nl" title="${esc((x.a || '') + ' ' + (x.t ? new Date(x.t).toLocaleString() : ''))}">⚑</span><input type="text" class="ty-nin" data-f="ty-note" data-i="${i}" value="${esc(x.text || '')}" aria-label="${esc(t('Текст примітки'))}">${ib(`data-f="ty-notedel" data-v="${i}"`, 'minus', 'Видалити примітку', false)}</div>`; });
      if (b) h += sec('Примітки', b);
      if (TS.hasChanges(n)) h += sec('Відстежені зміни', `<div class="row"><button type="button" class="btn" data-cmd="tyAcceptStory">${esc(t('Прийняти всі'))}</button><button type="button" class="btn" data-cmd="tyRejectStory">${esc(t('Відхилити всі'))}</button></div>`);
    }
    // quick actions
    h += sec('Швидкі дії', `<div class="ty-qas">${btn('tyCaseMenu', 'Змінити регістр')}${btn('tyLinkNew', 'Створити гіперпосилання')}${btn('tyInsertFootnote', 'Вставити виноску')}${btn('tyInsertEndnote', 'Вставити кінцеву виноску')}${btn('tyPlaceholder', 'Заповнити шаблонним текстом')}${btn('tyGenerate', 'Генерувати текст')}${btn('createOutlines', 'Перетворити на криві')}</div>`, '', 'ty-quick');
    return h;
  };

  // ---------- panel fields ----------
  const num = v => (typeof v === 'number' ? v : parseFloat(String(v).replace(',', '.')));
  O.panels.fieldHook = (f, raw, el, v, isNum) => {
    const c = TU.cur();
    if (!c) return false;
    const st = c.st, P = c.P;
    const vv = isNum ? v : num(String(raw).replace(/[()]/g, ''));
    const ok = isFinite(vv);
    switch (f) {
      case 'font': { const g = O.fonts && O.fonts.get(raw); TU.setChar({ font: g ? g.family : (String(raw).trim() || 'Arial') }); return 'Шрифт'; }
      case 'weight': TU.setChar({ weight: +raw || 400 }); return 'Накреслення';
      case 'ty-style': { const [w, i] = String(raw).split('|'); TU.setChar({ weight: +w || 400, italic: i === 'i' }); return 'Накреслення'; }
      case 'size': case 'ty-size': if (!ok || vv <= 0) return false; TU.setChar({ size: Math.min(4000, vv) }); return 'Розмір шрифту';
      case 'lh': TU.setChar({ lh: (!ok || /авто|auto/i.test(raw)) ? null : Math.max(0.1, vv / 100) }); return 'Інтерліньяж';
      case 'ty-lead': TU.setChar({ lh: (!ok || /\(|авто|auto/i.test(raw) || !String(raw).trim()) ? null : Math.max(0.1, vv / st.size) }); return 'Інтерліньяж';
      case 'ls': if (!ok) return false; TU.setChar({ ls: vv }); return 'Трекінг';
      case 'ty-track': if (!ok) return false; TU.setChar({ ls: vv * st.size / 1000 }); return 'Трекінг';
      case 'ty-kern': TU.setChar({ kern: raw }); return 'Кернінг';
      case 'ty-vs': if (!ok) return false; TU.setChar({ vs: O.clamp(vv, 1, 1000) }); return 'Вертикальне масштабування';
      case 'ty-hs': if (!ok) return false; TU.setChar({ hs: O.clamp(vv, 1, 1000) }); return 'Горизонтальне масштабування';
      case 'ty-bs': if (!ok) return false; TU.setChar({ bs: vv }); return 'Зсув базової лінії';
      case 'ty-skew': if (!ok) return false; TU.setChar({ skew: O.clamp(vv, -85, 85) }); return 'Нахил';
      case 'ty-lang': TU.setChar({ lang: raw || null }); return 'Мова';
      case 'italic': TU.setChar({ italic: !st.italic }); return 'Курсив';
      case 'deco': case 'ty-under': { const k = raw === 'line-through' ? 'strike' : 'under'; TU.setChar({ [k]: !st[k] }); return k === 'under' ? 'Підкреслення' : 'Закреслення'; }
      case 'tcase': TU.setChar({ tcase: raw }); return 'Регістр';
      case 'ty-caps':
        if (raw === 'small') TU.setChar({ smcaps: !st.smcaps });
        else { const want = raw === 'all' ? 'upper' : 'lower'; TU.setChar({ tcase: st.tcase === want ? 'none' : want }); }
        return 'Регістр';
      case 'ty-pos': TU.setChar({ pos: st.pos === raw ? 'normal' : raw }); return raw === 'sup' ? 'Верхній індекс' : 'Нижній індекс';
      case 'ty-nobreak': TU.setChar({ nobreak: !st.nobreak }); return 'Без розриву';
      case 'ty-color': { const col = O.color.norm(raw); if (!col) return false; TU.setChar({ color: col }); return 'Колір тексту'; }
      // paragraph
      case 'align': case 'ty-align': TU.setPara({ align: raw }); return 'Вирівнювання тексту';
      case 'ty-li': case 'ty-ri': case 'ty-fi': case 'ty-lri': case 'ty-spb': case 'ty-spa': {
        if (!ok) return false;
        const k = f.slice(3);
        TU.setPara({ [k]: k === 'fi' ? vv : Math.max(k === 'li' ? -10000 : 0, vv) });
        return k === 'spb' || k === 'spa' ? 'Інтервал між абзацами' : 'Відступи абзацу';
      }
      case 'ty-grid': TU.setPara({ grid: raw }); return 'Базова сітка';
      case 'ty-dcl': if (!ok) return false; TU.setPara({ dcl: O.clamp(Math.round(vv), 0, 25) }); return 'Буквиця';
      case 'ty-dcc': if (!ok) return false; TU.setPara({ dcc: O.clamp(Math.round(vv), 1, 150) }); return 'Буквиця';
      case 'ty-shade': TU.setPara({ shade: raw ? Object.assign({ c: '#E8E8E8', tint: 100 }, P.shade || {}, { on: true }) : null }); return 'Затінення';
      case 'ty-shadec': TU.setPara({ shade: Object.assign({ tint: 100 }, P.shade || {}, { c: O.color.norm(raw) || '#E8E8E8', on: true }) }); return 'Затінення';
      case 'ty-border': TU.setPara({ border: raw ? Object.assign({ c: '#1E1E24', w: 1 }, P.border || {}, { on: true }) : null }); return 'Межа абзацу';
      case 'ty-borderc': TU.setPara({ border: Object.assign({ w: 1 }, P.border || {}, { c: O.color.norm(raw) || '#1E1E24', on: true }) }); return 'Межа абзацу';
      case 'ty-hyph': TU.setPara({ hyph: !!raw }); return 'Переноси';
      case 'ty-composer': TU.setPara({ composer: raw }); return 'Компонувальник';
      case 'ty-list': TU.setPara({ list: P.list && P.list.t === raw ? null : (raw === 'num' ? Object.assign({ t: 'num', style: 'arabic', suf: '.', start: 1 }, TU.lastNum || {}) : Object.assign({ t: 'bullet', ch: '•' }, TU.lastBullet || {})) }); return 'Список';
      // frame
      case 'ty-cols': if (!ok) return false; forFrames(n => setCols(n, vv)); return 'Колонки';
      case 'ty-colstep': forFrames(n => setCols(n, (n.cols || 1) + (+raw || 0))); return 'Колонки';
      case 'ty-gap': if (!ok) return false; forFrames(n => { n.colGap = Math.max(0, vv); }); return 'Проміжок між колонками';
      case 'ty-bal': forFrames(n => { if (raw) n.colBal = true; else delete n.colBal; }); return 'Балансування колонок';
      case 'ty-inset': {
        const l = String(raw).split(/[,;\s]+/).map(num).filter(isFinite);
        const ins = l.length === 1 ? [l[0], l[0], l[0], l[0]] : l.length === 2 ? [l[0], l[1], l[0], l[1]] : l.length >= 4 ? l.slice(0, 4) : null;
        if (!ins) return false;
        forFrames(n => { if (ins.every(x => !x)) delete n.inset; else n.inset = ins.map(x => Math.max(0, x)); });
        return 'Внутрішні відступи';
      }
      case 'ty-valign': forFrames(n => { if (!n.boxH) { ensureWidth(n); n.boxH = Math.max(O.text.lineHeight(n), O.text.layout(n).h); } if (raw === 'top') delete n.valign; else n.valign = raw; }); return 'Вертикальне вирівнювання';
      case 'ty-optical': forFrames(n => { if (raw) n.optical = true; else delete n.optical; }); return 'Оптичне вирівнювання полів';
      // styles
      case 'ty-pstyle': TU.applyPStyle(raw); return 'Стиль абзацу';
      case 'ty-cstyle': TU.applyCStyle(raw); return 'Стиль символу';
      case 'ty-stab': TU.styleTab = raw; O.panels.refresh(true, true); return false;
      // notes
      case 'ty-fn': case 'ty-en': case 'ty-note': {
        const field = { 'ty-fn': 'fnotes', 'ty-en': 'enotes', 'ty-note': 'notes' }[f];
        const i = +el.dataset.i;
        const arr = c.n[field] || [];
        if (!arr[i]) return false;
        arr[i] = Object.assign({}, arr[i], { text: String(raw) });
        return f === 'ty-note' ? 'Примітка' : 'Виноска';
      }
      case 'ty-notedel': TU.deleteNote(c.n, +raw); return 'Видалити примітку';
    }
    return false;
  };

  // ---------- inserting text at the caret ----------
  TU.insert = (str, opts = {}) => {
    let n, a, b;
    const tg = TU.target();
    if (tg) ({ n, a, b } = tg);
    else {
      n = areaTexts()[0];
      if (!n) { O.toast('Поставте курсор у текст або виділіть текстовий фрейм'); return false; }
      const len = (n.text || '').length;
      if (lastCaret && lastCaret.id === n.id) { a = Math.min(lastCaret.a, len); b = Math.min(lastCaret.b, len); } else { a = len; b = len; }
    }
    const old = n.text || '';
    const nt = old.slice(0, a) + str + old.slice(b);
    const res = TS.textChanged(n, old, nt, { caret: a + str.length, notes: opts.notes });
    n.text = res ? res.text : nt;
    if (opts.runProps) TS.applyRange(n, 'runs', a, a + str.length, opts.runProps);
    const caret = res ? res.caret : a + str.length;
    if (S.textEdit && S.textEdit.id === n.id) { const e = taEl(); e.value = n.text; e.setSelectionRange(caret, caret); O.textEdit.sync(); setTimeout(refocus, 0); }
    lastCaret = { id: n.id, a: caret, b: caret };
    O.history.commit(opts.label || 'Вставлення символу');
    O.requestOverlay();
    return true;
  };
  // replace the selected text (or the whole text) through a function
  const transformText = (fn, label) => {
    const tg = TU.target();
    const list = tg ? [tg.n] : areaTexts();
    if (!list.length) return O.toast('Виділіть текст');
    for (const n of list) {
      const old = n.text || '';
      const a = tg && tg.b > tg.a ? tg.a : 0, b = tg && tg.b > tg.a ? tg.b : old.length;
      const part = fn(old.slice(a, b), old, a);
      const nt = old.slice(0, a) + part + old.slice(b);
      if (nt === old) continue;
      if (part.length === b - a) n.text = nt;
      else { TS.textChanged(n, old, nt, { noTrack: false }); n.text = nt; }
      if (tg) { const e = taEl(); e.value = n.text; e.setSelectionRange(a, a + part.length); O.textEdit.sync(); }
    }
    O.history.commit(label);
    afterEdit();
  };
  const mapChars = (s, f) => Array.from(s).map((c, i, arr) => { const r = f(c, i, arr); return r.length === c.length ? r : c; }).join('');
  TU.changeCase = mode => transformText((s, all, a) => {
    if (mode === 'upper') return mapChars(s, c => c.toUpperCase());
    if (mode === 'lower') return mapChars(s, c => c.toLowerCase());
    if (mode === 'title') return mapChars(s, (c, i, arr) => { const prev = i ? arr[i - 1] : all[a - 1]; return !prev || /[\s\-–—(«"„“]/.test(prev) ? c.toUpperCase() : c.toLowerCase(); });
    // sentence case
    let start = true;
    if (a > 0) start = /[.!?…]\s*$/.test(all.slice(Math.max(0, a - 4), a)) || /\n\s*$/.test(all.slice(Math.max(0, a - 2), a));
    return mapChars(s, c => { if (/\p{L}/u.test(c)) { const r = start ? c.toUpperCase() : c.toLowerCase(); start = false; return r; } if (/[.!?…\n]/.test(c)) start = true; return c; });
  }, 'Змінити регістр');

  // ---------- notes ----------
  TU.deleteNote = (n, k) => {
    const text = n.text || '';
    let seen = -1;
    for (let i = 0; i < text.length; i++) if (text[i] === CH.note && ++seen === k) { const old = text; n.text = text.slice(0, i) + text.slice(i + 1); TS.textChanged(n, old, n.text, { noTrack: true }); if (S.textEdit && S.textEdit.id === n.id) { taEl().value = n.text; O.textEdit.sync(); } return true; }
    return false;
  };
  const markerIndex = (n, ch, k) => { const text = n.text || ''; let seen = -1; for (let i = 0; i < text.length; i++) if (text[i] === ch && ++seen === k) return i; return -1; };
  const allTexts = () => { const out = []; for (const pg of S.doc.pages) model.walk(pg.children, n => { if (n.type === 'text') out.push({ n, pg }); }); return out; };
  const goToIndex = (n, pg, i) => {
    if (pg && pg.id !== S.pageId) { S.pageId = pg.id; S.sel = []; O.emit('page'); }
    O.select([n.id]);
    const b = model.worldBounds(n); if (b) V.fit(b, 120, Math.max(V.zoom, 1));
    O.textEdit.start(n, { selectAll: false });
    setTimeout(() => { taEl().setSelectionRange(i, i + 1); O.requestOverlay(); }, 20);
  };
  TU.gotoNote = dir => {
    const list = [];
    for (const { n, pg } of allTexts()) { const text = n.text || ''; for (let i = 0; i < text.length; i++) if (text[i] === CH.note) list.push({ n, pg, i }); }
    if (!list.length) return O.toast('У документі немає приміток');
    const tg = TU.target();
    let k = -1;
    if (tg) k = list.findIndex(x => x.n === tg.n && x.i >= tg.a + (dir > 0 ? 1 : 0));
    if (dir < 0) { const rev = list.filter(x => !tg || x.n !== tg.n || x.i < tg.a); const it = rev[rev.length - 1] || list[list.length - 1]; return goToIndex(it.n, it.pg, it.i); }
    const it = k >= 0 ? list[k] : list[0];
    goToIndex(it.n, it.pg, it.i);
  };

  // ---------- dialogs ----------
  const textDialog = (title, label, value, onOk, extraFields) => ui.dialog({
    title,
    body: `<label class="dlg-row ty-dlg-ta"><span>${esc(t(label))}</span><textarea id="ty-dlg-text" rows="4" spellcheck="true">${esc(value || '')}</textarea></label>`,
    fields: extraFields || [],
    onOpen: w => setTimeout(() => { const ta2 = w.querySelector('#ty-dlg-text'); if (ta2) ta2.focus(); }, 30),
    onOk: (v, btn) => { const el = document.getElementById('ty-dlg-text'); onOk(el ? el.value : '', v, btn); }
  });
  // generic attribute dialog: rows [key, label, kind, options]
  const attrDialog = (title, rows, cur, apply, opts = {}) => {
    const fields = rows.map(([k, label, kind, options]) => {
      const v = cur[k];
      if (kind === 'bool') return { key: k, label, type: 'checkbox', value: !!v };
      if (kind === 'tri') return { key: k, label, type: 'select', value: v === true ? 'yes' : v === false ? 'no' : '', options: [['', '(не задано)'], ['yes', 'Так'], ['no', 'Ні']] };
      if (kind === 'select') return { key: k, label, type: 'select', value: isSet(v) ? v : '', options };
      return { key: k, label, type: 'text', value: isSet(v) ? (typeof v === 'number' ? fmt(v) : v) : '' };
    });
    ui.dialog({
      title, fields, body: opts.body || '',
      onOk: v => {
        const out = {};
        for (const [k, , kind] of rows) {
          const x = v[k];
          if (kind === 'bool') out[k] = !!x;
          else if (kind === 'tri') out[k] = x === 'yes' ? true : x === 'no' ? false : undefined;
          else if (kind === 'num') { const q = num(x); out[k] = String(x).trim() === '' || !isFinite(q) ? undefined : q; }
          else if (kind === 'select') out[k] = x === '' ? undefined : (/^-?\d+(\.\d+)?$/.test(x) && opts.numeric && opts.numeric.includes(k) ? +x : x);
          else out[k] = String(x).trim() === '' ? undefined : String(x);
        }
        apply(out, v);
      }
    });
  };
  const KERNS = [['metrics', 'Метрика'], ['optical', 'Оптичний'], ['none', '0']];
  const POS = [['normal', 'Звичайна'], ['sup', 'Верхній індекс'], ['sub', 'Нижній індекс']];
  const CASES = [['none', 'Як є'], ['upper', 'ВЕЛИКІ'], ['lower', 'малі'], ['title', 'Кожне Слово']];
  const WOPTS = WEIGHTS.map(([w, l]) => [String(w), l]);
  const CHAR_ROWS = [['font', 'Шрифт', 'text'], ['weight', 'Накреслення', 'select', WOPTS], ['italic', 'Курсив', 'tri'], ['size', 'Розмір, px', 'num'], ['lhpx', 'Інтерліньяж, px (порожньо — авто)', 'num'], ['track', 'Трекінг, 1/1000 em', 'num'],
    ['kern', 'Кернінг', 'select', KERNS], ['hs', 'Горизонтальне масштабування, %', 'num'], ['vs', 'Вертикальне масштабування, %', 'num'], ['bs', 'Зсув базової лінії, px', 'num'], ['skew', 'Нахил, °', 'num'],
    ['tcase', 'Регістр', 'select', CASES], ['smcaps', 'Капітель', 'tri'], ['pos', 'Позиція', 'select', POS], ['under', 'Підкреслення', 'tri'], ['strike', 'Закреслення', 'tri'], ['nobreak', 'Без розриву', 'tri'],
    ['color', 'Колір (#RRGGBB)', 'text'], ['lang', 'Мова', 'select', TU.LANGS], ['link', 'Гіперпосилання (URL)', 'text']];
  const ALIGN_OPTS = ALIGNS.map(([v, , l]) => [v, l]);
  const PARA_ROWS = [['align', 'Вирівнювання', 'select', ALIGN_OPTS], ['li', 'Відступ ліворуч, px', 'num'], ['ri', 'Відступ праворуч, px', 'num'], ['fi', 'Відступ першого рядка, px', 'num'], ['lri', 'Відступ останнього рядка праворуч, px', 'num'],
    ['spb', 'Інтервал перед, px', 'num'], ['spa', 'Інтервал після, px', 'num'], ['grid', 'Базова сітка', 'select', [['none', 'Ігнорувати'], ['all', 'Усі рядки'], ['first', 'Лише перший рядок']]],
    ['dcl', 'Буквиця: рядків', 'num'], ['dcc', 'Буквиця: символів', 'num'], ['hyph', 'Переноси', 'tri'], ['composer', 'Компонувальник', 'select', [['single', 'Однорядковий'], ['para', 'Абзацу']]]];
  const charCur = st => ({ font: st.font, weight: String(st.weight), italic: st.italic, size: st.size, lhpx: st.lh ? st.size * st.lh : null, track: Math.round(st.ls / st.size * 1000), kern: st.kern, hs: st.hs, vs: st.vs, bs: st.bs, skew: st.skew, tcase: st.tcase, smcaps: st.smcaps, pos: st.pos, under: st.under, strike: st.strike, nobreak: st.nobreak, color: st.color || '', lang: st.lang || '', link: st.link || '' });
  const charFromDialog = (o, size0, all) => {
    const p = {};
    if (o.font) p.font = o.font;
    if (o.weight) p.weight = +o.weight;
    for (const k of ['italic', 'smcaps', 'under', 'strike', 'nobreak']) if (o[k] !== undefined) p[k] = o[k];
    if (o.size > 0) p.size = o.size;
    const size = p.size || size0;
    if (all || o.lhpx !== undefined) p.lh = o.lhpx > 0 ? o.lhpx / size : null;
    if (o.track !== undefined) p.ls = o.track * size / 1000;
    for (const k of ['kern', 'tcase', 'pos']) if (o[k]) p[k] = o[k];
    for (const k of ['hs', 'vs']) if (o[k] > 0) p[k] = o[k];
    for (const k of ['bs', 'skew']) if (o[k] !== undefined) p[k] = o[k];
    if (o.color !== undefined) { const c = O.color.norm(o.color); if (c) p.color = c; } else if (all) p.color = null;
    if (o.lang !== undefined) p.lang = o.lang; else if (all) p.lang = null;
    if (o.link !== undefined) p.link = o.link; else if (all) p.link = null;
    return p;
  };
  TU.charDialog = () => {
    const c = TU.cur();
    if (!c) return O.toast('Виділіть текст');
    attrDialog('Параметри символів', CHAR_ROWS, charCur(c.st), o => { TU.setChar(charFromDialog(o, c.st.size, true)); O.history.commit('Параметри символів'); });
  };
  TU.paraDialog = () => {
    const c = TU.cur();
    if (!c) return O.toast('Виділіть текст');
    attrDialog('Параметри абзацу', PARA_ROWS, Object.assign({}, c.P, { hyph: !!c.P.hyph }), o => {
      const p = {};
      for (const [k, , kind] of PARA_ROWS) if (o[k] !== undefined) p[k] = kind === 'num' ? (k === 'dcl' || k === 'dcc' ? Math.round(o[k]) : o[k]) : o[k];
      TU.setPara(p); O.history.commit('Параметри абзацу');
    });
  };
  // style editor (paragraph styles: character + paragraph attributes; character styles: only what is set)
  const editStyle = (kind, st, isNew) => {
    const rows = [['name', 'Назва', 'text']].concat(CHAR_ROWS.filter(r => r[0] !== 'link'), kind === 'p' ? PARA_ROWS : []);
    const p = st.props || {};
    const cur = { name: st.name };
    if (kind === 'p') {
      const sp = TS.splitProps(p);
      const base = TS.mkStyle(Object.assign(TS.frameChar({ font: 'Arial', size: 12 }), sp.c));
      Object.assign(cur, charCur(base), { color: p.color || '' }, Object.assign({}, TS.DEF_PARA, sp.p));
    } else {
      const sp = TS.splitProps(p).c;
      Object.assign(cur, { font: sp.font, weight: sp.weight ? String(sp.weight) : '', italic: sp.italic, size: sp.size, lhpx: sp.lh && sp.size ? sp.lh * sp.size : null, track: isSet(sp.ls) && sp.size ? Math.round(sp.ls / sp.size * 1000) : null, kern: sp.kern, hs: sp.hs, vs: sp.vs, bs: sp.bs, skew: sp.skew, tcase: sp.tcase, smcaps: sp.smcaps, pos: sp.pos, under: sp.under, strike: sp.strike, nobreak: sp.nobreak, color: sp.color || '', lang: sp.lang || '' });
    }
    const wopts = kind === 'c' ? [['', '(не задано)']].concat(WOPTS) : WOPTS;
    const rows2 = rows.map(r => (r[0] === 'weight' ? ['weight', r[1], 'select', wopts] : (kind === 'c' && r[2] === 'select' && r[0] !== 'lang') ? [r[0], r[1], 'select', [['', '(не задано)']].concat(r[3])] : r));
    attrDialog(isNew ? (kind === 'p' ? 'Новий стиль абзацу' : 'Новий стиль символу') : (kind === 'p' ? 'Параметри стилю абзацу' : 'Параметри стилю символу'), rows2, cur, o => {
      const props = {};
      const ch = charFromDialog(o, o.size || 12, kind === 'p');
      if (kind === 'p') {
        Object.assign(props, ch);
        delete props.link;
        props.deco = [ch.under ? 'underline' : '', ch.strike ? 'line-through' : ''].filter(Boolean).join(' ') || 'none';
        delete props.under; delete props.strike;
        if (!props.color) delete props.color;
        if (props.lang === null) delete props.lang;
        for (const [k, , kind2] of PARA_ROWS) if (o[k] !== undefined) props[k] = kind2 === 'num' && (k === 'dcl' || k === 'dcc') ? Math.round(o[k]) : o[k];
      } else {
        for (const k of Object.keys(ch)) if (ch[k] !== null && ch[k] !== undefined) props[k] = ch[k];
        if (o.lhpx === undefined) delete props.lh;
        if (o.track === undefined) delete props.ls;
      }
      st.name = o.name || st.name || t('Стиль');
      st.props = props;
      const list = kind === 'p' ? pstyles() : cstyles();
      if (isNew) list.push(st);
      if (kind === 'p') for (const pg of S.doc.pages) model.walk(pg.children, x => { if (x.type === 'text' && x.pstyle === st.id) O.print.applyStyle(x, st); });
      O.history.commit(kind === 'p' ? 'Стиль абзацу' : 'Стиль символу');
    }, { numeric: ['weight'] });
  };
  TU.stylesDialog = kind => {
    const list = () => (kind === 'p' ? pstyles() : cstyles());
    const body = () => `<div class="ty-slist">${list().map(s => `<div class="ty-srow" data-sid="${s.id}"><span class="ty-sname">${esc(s.name)}</span><button type="button" class="btn" data-sa="apply">${esc(t('Застосувати'))}</button><button type="button" class="ib" data-sa="edit" title="${esc(t('Редагувати'))}" aria-label="${esc(t('Редагувати'))}">${O.icon('sliders', 14)}</button><button type="button" class="ib" data-sa="dup" title="${esc(t('Дублювати'))}" aria-label="${esc(t('Дублювати'))}">${O.icon('copy', 14)}</button><button type="button" class="ib" data-sa="del" title="${esc(t('Видалити'))}" aria-label="${esc(t('Видалити'))}">${O.icon('trash', 14)}</button></div>`).join('') || `<div class="dlg-text">${esc(t('Стилів ще немає.'))}</div>`}</div><div class="row"><button type="button" class="btn" data-sa="new">${O.icon('plus', 14)} ${esc(t('Новий стиль'))}</button>${kind === 'p' ? `<button type="button" class="btn" data-sa="defaults">${esc(t('Додати стандартні стилі'))}</button>` : ''}</div>`;
    const d = ui.dialog({ title: kind === 'p' ? 'Стилі абзацу' : 'Стилі символів', body: `<div class="ty-sbody">${body()}</div>`, buttons: [{ id: 'ok', label: 'Готово', primary: true }] });
    const redraw = () => { const b = d.el.querySelector('.ty-sbody'); if (b) b.innerHTML = body(); };
    d.el.addEventListener('click', e => {
      const b = e.target.closest('[data-sa]');
      if (!b) return;
      e.preventDefault(); e.stopPropagation();
      const row = b.closest('[data-sid]');
      const st = row ? list().find(s => s.id === row.dataset.sid) : null;
      const act = b.dataset.sa;
      if (act === 'apply' && st) { if (kind === 'p') TU.applyPStyle(st.id); else TU.applyCStyle(st.id); O.history.commit(kind === 'p' ? 'Стиль абзацу' : 'Стиль символу'); }
      if (act === 'edit' && st) { d.close(); editStyle(kind, st, false); }
      if (act === 'dup' && st) { list().push({ id: O.uid(), name: st.name + ' ' + t('(копія)'), props: O.clone(st.props) }); O.history.commit('Дублювати стиль'); redraw(); }
      if (act === 'del' && st) {
        if (kind === 'p') { S.doc.pstyles = pstyles().filter(s => s !== st); for (const { n } of allTexts()) { if (n.pstyle === st.id) delete n.pstyle; if (n.pars) { n.pars.forEach(p => { if (p.ps === st.id) delete p.ps; }); n.pars = TS.normRuns(n.pars); if (!n.pars.length) delete n.pars; } } }
        else { S.doc.cstyles = cstyles().filter(s => s !== st); for (const { n } of allTexts()) if (n.runs) { n.runs.forEach(r => { if (r.cs === st.id) delete r.cs; }); n.runs = TS.normRuns(n.runs); if (!n.runs.length) delete n.runs; } }
        O.history.commit('Видалити стиль'); redraw();
      }
      if (act === 'new') { d.close(); TU.newStyle(kind, true); }
      if (act === 'defaults' && O.print.defaultStyles) { const had = pstyles().length; S.doc.pstyles = pstyles(); if (had) { const keep = S.doc.pstyles; S.doc.pstyles = []; O.print.defaultStyles(); S.doc.pstyles = keep.concat(S.doc.pstyles.filter(s => !keep.some(k => k.name === s.name))); } else O.print.defaultStyles(); O.history.commit('Стилі абзацу'); redraw(); }
    });
  };
  TU.newStyle = (kind, fromScratch) => {
    const props = fromScratch ? null : currentStyleProps();
    const st = { id: O.uid(), name: t(kind === 'p' ? 'Стиль абзацу {n}' : 'Стиль символу {n}', { n: (kind === 'p' ? pstyles() : cstyles()).length + 1 }), props: props || {} };
    if (kind === 'c' && props) { const c = TU.cur(); const o = charPropsOf(c.st); if (c.st.color) o.color = c.st.color; st.props = o; }
    if (!fromScratch && props) {
      ui.dialog({ title: kind === 'p' ? 'Новий стиль абзацу' : 'Новий стиль символу', fields: [{ key: 'n', label: 'Назва', type: 'text', value: st.name }], onOk: v => {
        st.name = v.n.trim() || st.name;
        (kind === 'p' ? pstyles() : cstyles()).push(st);
        if (kind === 'p') TU.applyPStyle(st.id); else TU.applyCStyle(st.id);
        O.history.commit(kind === 'p' ? 'Стиль абзацу' : 'Стиль символу');
      } });
      return;
    }
    editStyle(kind, st, true);
  };
  TU.redefineStyle = () => {
    const c = TU.cur();
    if (!c) return;
    if (TU.styleTab === 'c') {
      const r = c.editing ? TS.runAt(c.n.runs, c.a) : null;
      const st = r && r.cs ? TS.cstyle(r.cs) : null;
      if (!st) return O.toast('Курсор не в тексті зі стилем символу');
      const o = charPropsOf(c.st); if (c.st.color) o.color = c.st.color;
      st.props = o;
      TS.stripKey(c.n, 'runs', TS.CHAR_KEYS.filter(k => k !== 'link'));
      O.history.commit('Перевизначити стиль');
      return;
    }
    const st = c.P.ps && TS.pstyle(c.P.ps);
    if (!st) return O.toast('Спершу застосуйте стиль абзацу');
    st.props = currentStyleProps();
    let k = 0;
    for (const { n } of allTexts()) {
      if (n.pstyle === st.id) { O.print.applyStyle(n, st); k++; }
      if ((n.pars || []).some(p => p.ps === st.id)) { n.pars.forEach(p => { if (p.ps === st.id) for (const key of TS.PARA_KEYS) delete p[key]; }); k++; }
    }
    O.history.commit('Перевизначити стиль');
    O.toast('Оновлено текстів: {n}', { n: k });
  };

  // tabs
  TU.tabsDialog = () => {
    const c = TU.cur();
    if (!c) return O.toast('Виділіть текст');
    let stops = O.clone(c.P.tabs || []).sort((a, b) => a.x - b.x);
    const AL = [['left', 'Ліворуч'], ['center', 'По центру'], ['right', 'Праворуч'], ['dec', 'За десятковою комою']];
    const W = Math.max(200, Math.min(520, c.n.width || 400));
    const rowsHTML = () => stops.map((s, i) => `<div class="ty-tabrow" data-i="${i}"><input type="number" step="1" data-tk="x" value="${fmt(s.x)}" aria-label="${esc(t('Позиція'))}"><select data-tk="a" aria-label="${esc(t('Вирівнювання'))}">${AL.map(([v, l]) => `<option value="${v}"${s.a === v ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select><input type="text" data-tk="l" value="${esc(s.l || '')}" placeholder="${esc(t('Заповнювач'))}" maxlength="4" aria-label="${esc(t('Заповнювач'))}"><button type="button" class="ib" data-tk="del" aria-label="${esc(t('Видалити'))}">${O.icon('minus', 14)}</button></div>`).join('');
    const ruler = () => { let s = `<svg class="ty-ruler" viewBox="0 0 ${W} 24" width="100%" height="24"><rect width="${W}" height="24" fill="var(--panel-2)"/>`; for (let x = 0; x <= W; x += 12) s += `<line x1="${x}" x2="${x}" y1="${x % 36 === 0 ? 10 : 16}" y2="24" stroke="var(--fg-3)" stroke-width="0.6"/>`; for (const st of stops) s += `<path d="M${st.x} 4v14M${st.x - 4} 18h8" stroke="var(--acc)" stroke-width="1.6"/>`; return s + '</svg>'; };
    const body = () => `<div class="ty-tabs-dlg"><div class="ty-rul">${ruler()}</div><div class="dlg-text small">${esc(t('Клацніть на лінійці, щоб додати табулятор. Позиції — від лівого краю колонки, px. Без табуляторів діють стандартні кожні 36 px.'))}</div><div class="ty-tabrows">${rowsHTML()}</div><div class="row"><button type="button" class="btn" data-tk="add">${O.icon('plus', 14)} ${esc(t('Додати табулятор'))}</button><button type="button" class="btn" data-tk="clear">${esc(t('Очистити все'))}</button></div></div>`;
    const d = ui.dialog({ title: 'Табулятори', body: `<div class="ty-tbody">${body()}</div>`, onOk: () => { TU.setPara({ tabs: stops.length ? stops.map(s => ({ x: +s.x || 0, a: s.a || 'left', l: s.l || undefined })) : null }); O.history.commit('Табулятори'); } });
    const redraw = () => { d.el.querySelector('.ty-tbody').innerHTML = body(); };
    d.el.addEventListener('click', e => {
      const b = e.target.closest('[data-tk]');
      const rul = e.target.closest('.ty-ruler');
      if (rul) { const r = rul.getBoundingClientRect(); stops.push({ x: Math.round((e.clientX - r.left) / r.width * W), a: 'left' }); stops.sort((a, b2) => a.x - b2.x); redraw(); return; }
      if (!b || b.tagName !== 'BUTTON') return;
      e.preventDefault(); e.stopPropagation();
      if (b.dataset.tk === 'add') { const last = stops.length ? stops[stops.length - 1].x : 0; stops.push({ x: last + 72, a: 'left' }); redraw(); }
      if (b.dataset.tk === 'clear') { stops = []; redraw(); }
      if (b.dataset.tk === 'del') { stops.splice(+b.closest('[data-i]').dataset.i, 1); redraw(); }
    });
    d.el.addEventListener('change', e => {
      const r = e.target.closest('[data-i]');
      if (!r || !e.target.dataset.tk) return;
      const s = stops[+r.dataset.i];
      const k = e.target.dataset.tk;
      s[k] = k === 'x' ? Math.max(0, num(e.target.value) || 0) : e.target.value;
      stops.sort((a, b2) => a.x - b2.x);
      redraw();
    });
  };

  // glyphs
  const GLYPH_SETS = [
    ['Нещодавні', null], ['Латиниця', [0x20, 0x7E]], ['Латиниця-1', [0xA0, 0xFF]], ['Розширена латиниця', [0x100, 0x17F]], ['Кирилиця', [0x400, 0x45F, 0x490, 0x491]],
    ['Грецька', [0x391, 0x3C9]], ['Пунктуація', [0x2010, 0x205E]], ['Валюти', [0x20A0, 0x20C0]], ['Буквоподібні', [0x2100, 0x214F]], ['Числові форми', [0x2150, 0x218B]],
    ['Стрілки', [0x2190, 0x21FF]], ['Математичні', [0x2200, 0x22FF]], ['Геометричні фігури', [0x25A0, 0x25FF]], ['Різні символи', [0x2600, 0x26FF]], ['Дінгбати', [0x2700, 0x27BF]]
  ];
  TU.glyphsDialog = () => {
    const c = TU.cur();
    const font = c ? c.st.font : 'Arial';
    let set = O.ls.get('tyGlyphSet', 1);
    const recent = () => O.ls.get('tyGlyphRecent', ['«', '»', '—', '–', '…', '№', '©', '®', '™', '°', '×', '•']);
    const chars = () => {
      if (set === 0) return recent();
      const r = GLYPH_SETS[set][1], out = [];
      for (let k = 0; k < r.length; k += 2) for (let cp = r[k]; cp <= r[k + 1]; cp++) out.push(String.fromCodePoint(cp));
      return out;
    };
    const body = () => `<div class="row">${`<select class="sel" data-gk="set" aria-label="${esc(t('Показати'))}">${GLYPH_SETS.map(([l], i) => `<option value="${i}"${i === set ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select>`}<span class="dlg-text small">${esc(font)}</span></div><div class="ty-glyphs" style="font-family:${esc(O.text.family(font))}">${chars().map(ch => `<button type="button" data-g="${esc(ch)}" title="U+${ch.codePointAt(0).toString(16).toUpperCase().padStart(4, '0')}">${esc(ch === ' ' ? '␣' : ch)}</button>`).join('')}</div>`;
    const d = ui.dialog({ title: 'Гліфи', body: `<div class="ty-gbody">${body()}</div>`, buttons: [{ id: 'ok', label: 'Готово', primary: true }] });
    d.el.addEventListener('change', e => { if (e.target.dataset.gk === 'set') { set = +e.target.value; O.ls.set('tyGlyphSet', set); d.el.querySelector('.ty-gbody').innerHTML = body(); } });
    d.el.addEventListener('click', e => {
      const b = e.target.closest('[data-g]');
      if (!b) return;
      e.preventDefault(); e.stopPropagation();
      const ch = b.dataset.g;
      if (TU.insert(ch, { label: 'Вставлення гліфа' })) O.ls.set('tyGlyphRecent', [ch].concat(recent().filter(x => x !== ch)).slice(0, 40));
    });
  };

  // story: optical margin + story editor
  TU.storyDialog = () => {
    const list = areaTexts();
    if (!list.length) return O.toast('Виділіть текстовий фрейм');
    ui.dialog({
      title: 'Матеріал', fields: [{ key: 'opt', label: 'Оптичне вирівнювання полів', type: 'checkbox', value: !!list[0].optical }],
      body: `<div class="dlg-text small">${esc(t('Розділові знаки та краї літер трохи виносяться за межі колонки, щоб край тексту виглядав рівнішим (як в InDesign).'))}</div>`,
      buttons: [{ id: 'editor', label: 'Редактор матеріалу…' }, { id: 'ok', label: 'OK', primary: true }],
      onOk: (v, b) => {
        const ch = O.print.chainOf(list[0]) || [list[0]];
        for (const n of list) for (const x of (O.print.chainOf(n) || [n])) { if (v.opt) x.optical = true; else delete x.optical; }
        void ch;
        O.history.commit('Оптичне вирівнювання полів');
        if (b === 'editor') setTimeout(TU.storyEditor, 0);
      }
    });
  };
  TU.storyEditor = () => {
    const n0 = areaTexts()[0] || editNode();
    if (!n0) return O.toast('Виділіть текстовий фрейм');
    if (S.textEdit) O.textEdit.end(true);
    const ch = O.print.chainOf(n0) || [n0];
    const story = O.print.story(ch);
    const vis = s => s.replace(/\uE030/g, '⁽ⁿ⁾').replace(/\uE032/g, '⁽ᵉ⁾').replace(/\uE031/g, '⚑').replace(/\uE001/g, '⟨' + t('розрив колонки') + '⟩').replace(/[\uE002-\uE005]/g, '⟨' + t('розрив фрейма') + '⟩').replace(/\u2028/g, '↵').replace(/\u00AD/g, '¬');
    if (/[\uE000-\uF8FF\u2028\u00AD]/.test(story) && vis(story) !== story) {
      // the editor shows markers as symbols; they are read back unchanged
    }
    textDialog('Редактор матеріалу', ch.length > 1 ? t('Увесь текст ланцюжка ({n} фреймів)', { n: ch.length }) : 'Текст', vis(story), val => {
      const back = val.replace(/⁽ⁿ⁾/g, '\uE030').replace(/⁽ᵉ⁾/g, '\uE032').replace(/⚑/g, '\uE031').split('⟨' + t('розрив колонки') + '⟩').join('\uE001').split('⟨' + t('розрив фрейма') + '⟩').join('\uE002').replace(/↵/g, '\u2028').replace(/¬/g, '\u00AD');
      if (back === story) return;
      const first = ch[0];
      const runs = O.print.storyRuns(ch, 'runs'), pars = O.print.storyRuns(ch, 'pars');
      const notes = ['fnotes', 'enotes', 'notes'].map(f => [].concat(...ch.map(x => x[f] || [])));
      ch.forEach(x => { delete x.runs; delete x.pars; delete x.fnotes; delete x.enotes; delete x.notes; x.brk = false; if (x !== first) x.text = ''; });
      first.text = story;
      if (runs.length) first.runs = runs;
      if (pars.length) first.pars = pars;
      ['fnotes', 'enotes', 'notes'].forEach((f, k) => { if (notes[k].length) first[f] = notes[k]; });
      TS.textChanged(first, story, back, {});
      first.text = back;
      O.history.commit('Редактор матеріалу');
    });
    setTimeout(() => { const el = document.getElementById('ty-dlg-text'); if (el) { el.rows = 18; el.classList.add('ty-story'); } }, 0);
  };

  // find / replace font
  TU.findFontDialog = () => {
    const use = new Map();
    const add = f => { if (f) use.set(f, (use.get(f) || 0) + 1); };
    for (const { n } of allTexts()) { add(n.font); for (const r of n.runs || []) add(r.font); }
    for (const s of (S.doc.pstyles || []).concat(S.doc.cstyles || [])) add(s.props && s.props.font);
    const fonts = Array.from(use.entries()).sort((a, b) => b[1] - a[1]);
    if (!fonts.length) return O.toast('У документі немає тексту');
    ui.dialog({
      title: 'Знайти/замінити шрифт',
      body: `<div class="dlg-text small">${esc(t('Шрифтів у документі: {n}', { n: fonts.length }))}</div><datalist id="ty-ff-list">${FONTS.concat(O.fonts && O.fonts.google ? O.fonts.google.slice(0, 1500).map(g => g.family) : []).map(f => `<option value="${esc(f)}">`).join('')}</datalist>`,
      fields: [{ key: 'from', label: 'Знайти шрифт', type: 'select', value: fonts[0][0], options: fonts.map(([f, k]) => [f, f + ' (' + k + ')']) }, { key: 'to', label: 'Замінити на', type: 'text', value: '' }],
      onOpen: w => { const i = w.querySelector('[data-k="to"]'); if (i) i.setAttribute('list', 'ty-ff-list'); },
      onOk: v => {
        const to = String(v.to || '').trim();
        if (!to) return;
        const g = O.fonts && O.fonts.get(to);
        const fam = g ? g.family : to;
        let k = 0;
        for (const { n } of allTexts()) { if (n.font === v.from) { n.font = fam; k++; } for (const r of n.runs || []) if (r.font === v.from) { r.font = fam; k++; } }
        for (const s of (S.doc.pstyles || []).concat(S.doc.cstyles || [])) if (s.props && s.props.font === v.from) { s.props.font = fam; k++; }
        if (g) fontLoad(fam);
        O.history.commit('Замінити шрифт');
        O.toast('Замінено: {n}', { n: k });
      }
    });
  };

  // footnotes / endnotes
  TU.insertNote = kind => {
    const tg = TU.target();
    if (!tg && !areaTexts().length) return O.toast('Поставте курсор у текст або виділіть текстовий фрейм');
    const title = kind === 'fn' ? 'Нова виноска' : kind === 'en' ? 'Нова кінцева виноска' : 'Нова примітка';
    const label = kind === 'note' ? 'Текст примітки (не друкується)' : 'Текст виноски';
    textDialog(title, label, '', text => {
      const ch = kind === 'fn' ? CH.footnote : kind === 'en' ? CH.endnote : CH.note;
      const entry = kind === 'note' ? { text, a: S.doc.author || O.ls.get('collabName', '') || t('Я'), t: Date.now() } : { text };
      TU.insert(ch, { notes: [entry], label: title });
    });
  };
  TU.noteOptions = kind => {
    const o = kind === 'fn' ? TS.fnOpts() : TS.enOpts();
    const STY = [['arabic', '1, 2, 3, 4…'], ['roman', 'i, ii, iii, iv…'], ['ROMAN', 'I, II, III, IV…'], ['alpha', 'a, b, c, d…'], ['ALPHA', 'A, B, C, D…'], ['zero', '01, 02, 03…'], ['symbol', '*, †, ‡, §…']];
    const fields = [{ key: 'style', label: 'Стиль нумерації', type: 'select', value: o.style, options: STY }, { key: 'start', label: 'Почати з', type: 'number', value: o.start, min: 1 },
      { key: 'size', label: 'Розмір тексту, % від основного', type: 'number', value: o.size }, { key: 'prefix', label: 'Префікс', type: 'text', value: o.prefix }, { key: 'suffix', label: 'Суфікс', type: 'text', value: o.suffix }];
    if (kind === 'fn') fields.push({ key: 'rule', label: 'Лінія над виносками', type: 'checkbox', value: o.rule !== false }, { key: 'space', label: 'Відстань до тексту, px', type: 'number', value: o.space });
    else fields.unshift({ key: 'title', label: 'Заголовок', type: 'text', value: o.title });
    ui.dialog({ title: kind === 'fn' ? 'Параметри приміток документа' : 'Параметри кінцевих виносок документа', fields, onOk: v => {
      const r = Object.assign({}, v, { start: Math.max(1, Math.round(v.start || 1)), size: O.clamp(v.size || 80, 20, 200) });
      if (kind === 'fn') S.doc.fnOpts = r; else S.doc.enOpts = r;
      O.history.commit('Параметри виносок');
    } });
  };
  TU.convertNotes = () => {
    ui.dialog({
      title: 'Перетворення виносок і кінцевих виносок',
      fields: [{ key: 'dir', label: 'Перетворити', type: 'select', value: 'fn2en', options: [['fn2en', 'Виноски на кінцеві виноски'], ['en2fn', 'Кінцеві виноски на виноски']] }, { key: 'scope', label: 'Область', type: 'select', value: areaTexts().length ? 'sel' : 'doc', options: [['sel', 'Виділені фрейми'], ['doc', 'Документ']] }],
      onOk: v => {
        const list = v.scope === 'doc' ? allTexts().map(x => x.n) : areaTexts();
        const from = v.dir === 'fn2en' ? CH.footnote : CH.endnote, to = v.dir === 'fn2en' ? CH.endnote : CH.footnote;
        let k = 0;
        for (const n of list) {
          const text = n.text || '';
          if (text.indexOf(from) < 0) continue;
          // merged note list in text order
          const fl = (n.fnotes || []).slice(), el = (n.enotes || []).slice();
          const merged = [];
          for (const c of text) { if (c === CH.footnote) merged.push(fl.shift() || { text: '' }); else if (c === CH.endnote) merged.push(el.shift() || { text: '' }); }
          n.text = text.split(from).join(to);
          if (to === CH.endnote) { n.enotes = merged; delete n.fnotes; } else { n.fnotes = merged; delete n.enotes; }
          k += TS.countChar(text, from);
        }
        O.history.commit('Перетворення виносок');
        O.toast('Перетворено: {n}', { n: k });
      }
    });
  };

  // hyperlinks & cross-references
  const linkAt = () => {
    const tg = TU.target();
    if (tg) { const r = TS.runAt(tg.n.runs, tg.a) || (tg.a > 0 ? TS.runAt(tg.n.runs, tg.a - 1) : null); return (r && r.link) || tg.n.link || null; }
    const n = areaTexts()[0];
    return n ? (n.link || ((n.runs || []).find(r => r.link) || {}).link || null) : null;
  };
  TU.newLink = () => {
    const tg = TU.target();
    if (!tg && !areaTexts().length) return O.toast('Виділіть текст або фрейм для гіперпосилання');
    const cur = linkAt() || 'https://';
    const fields = [{ key: 'url', label: 'URL', type: 'text', value: cur }, { key: 'style', label: 'Оформити як посилання (синій, підкреслений)', type: 'checkbox', value: true }];
    if (tg && tg.a === tg.b) fields.unshift({ key: 'text', label: 'Текст посилання', type: 'text', value: '' });
    ui.dialog({ title: 'Нове гіперпосилання', fields, onOk: v => {
      let url = String(v.url || '').trim();
      if (!url || url === 'https://') return;
      if (!/^[a-z][a-z0-9+.-]*:/i.test(url) && !url.startsWith('#')) url = (/^[^@\s]+@[^@\s]+$/.test(url) ? 'mailto:' : 'https://') + url;
      const props = Object.assign({ link: url }, v.style ? { color: '#1C64F2', under: true } : {});
      const tg2 = TU.target();
      if (tg2 && tg2.a === tg2.b) { const txt = String(v.text || '').trim() || url.replace(/^(https?:\/\/|mailto:)/, ''); TU.insert(txt, { runProps: props, label: 'Гіперпосилання' }); return; }
      if (tg2) TS.applyRange(tg2.n, 'runs', tg2.a, tg2.b, props);
      else for (const n of areaTexts()) { n.link = url; if (v.style) setFrameChar(n, { color: '#1C64F2', under: true }); }
      O.history.commit('Гіперпосилання');
      afterEdit();
    } });
  };
  TU.removeLink = () => {
    const tg = TU.target();
    if (tg) TS.applyRange(tg.n, 'runs', tg.b > tg.a ? tg.a : 0, tg.b > tg.a ? tg.b : (tg.n.text || '').length, { link: null });
    else for (const n of areaTexts()) { delete n.link; TS.stripKey(n, 'runs', ['link']); }
    O.history.commit('Видалити гіперпосилання');
    afterEdit();
  };
  TU.openLink = () => { const u = linkAt(); if (!u) return O.toast('Курсор не на гіперпосиланні'); if (/^(https?:|mailto:)/i.test(u)) window.open(u, '_blank', 'noopener'); };
  TU.linksPanel = () => {
    const rows = [];
    for (const { n, pg } of allTexts()) {
      if (n.link) rows.push({ n, pg, url: n.link, text: (n.text || '').slice(0, 40) });
      for (const r of n.runs || []) if (r.link) rows.push({ n, pg, url: r.link, text: (n.text || '').slice(r.s, Math.min(r.e, r.s + 40)), r });
    }
    const body = rows.length ? `<div class="ty-slist">${rows.map((x, i) => `<div class="ty-srow" data-li="${i}"><span class="ty-sname"><b>${esc(x.text.replace(/[\uE000-\uF8FF]/g, ''))}</b><br><small>${esc(x.url)}</small></span><button type="button" class="ib" data-la="go" title="${esc(t('Показати'))}" aria-label="${esc(t('Показати'))}">${O.icon('search', 14)}</button><button type="button" class="ib" data-la="open" title="${esc(t('Відкрити адресу'))}" aria-label="${esc(t('Відкрити адресу'))}">${O.icon('link', 14)}</button><button type="button" class="ib" data-la="del" title="${esc(t('Видалити'))}" aria-label="${esc(t('Видалити'))}">${O.icon('trash', 14)}</button></div>`).join('')}</div>` : `<div class="dlg-text">${esc(t('У документі немає гіперпосилань.'))}</div>`;
    const d = ui.dialog({ title: 'Гіперпосилання', body, buttons: [{ id: 'ok', label: 'Готово', primary: true }] });
    d.el.addEventListener('click', e => {
      const b = e.target.closest('[data-la]');
      if (!b) return;
      e.preventDefault(); e.stopPropagation();
      const x = rows[+b.closest('[data-li]').dataset.li];
      if (b.dataset.la === 'go') { d.close(); if (x.pg.id !== S.pageId) { S.pageId = x.pg.id; O.emit('page'); } O.select([x.n.id]); const bb = model.worldBounds(x.n); if (bb) V.fit(bb, 120, Math.max(V.zoom, 1)); }
      if (b.dataset.la === 'open' && /^(https?:|mailto:)/i.test(x.url)) window.open(x.url, '_blank', 'noopener');
      if (b.dataset.la === 'del') { if (x.r) { delete x.r.link; x.n.runs = TS.normRuns(x.n.runs); if (!x.n.runs.length) delete x.n.runs; } else delete x.n.link; O.history.commit('Видалити гіперпосилання'); b.closest('[data-li]').remove(); }
    });
  };
  TU.xrefDialog = () => {
    const opts = [];
    for (const { n, pg } of allTexts()) {
      if (n.path) continue;
      (n.text || '').split('\n').forEach((p, i) => { const s = p.replace(/[\uE000-\uF8FF\u00AD]/g, '').trim(); if (s && opts.length < 400) opts.push([n.id + '|' + i, `${pg.name} › ${s.slice(0, 60)}`]); });
    }
    if (!opts.length) return O.toast('Немає абзаців, на які можна послатися');
    ui.dialog({ title: 'Нове перехресне посилання', fields: [{ key: 'to', label: 'Абзац', type: 'select', value: opts[0][0], options: opts }, { key: 'fmt', label: 'Формат', type: 'select', value: 'text', options: [['text', 'Текст абзацу'], ['page', 'Номер сторінки'], ['both', 'Текст абзацу та сторінка']] }], onOk: v => {
      const [id, para] = String(v.to).split('|');
      TU.insert(CH.xref, { runProps: { xref: { id, para: +para || 0, fmt: v.fmt } }, label: 'Перехресне посилання' });
    } });
  };
  // text variables
  TU.insertVar = idx => TU.insert(TS.varChar(idx), { label: 'Текстова змінна' });
  TU.varsDialog = () => {
    const list = () => TS.customVars();
    const body = () => `<div class="ty-slist">${list().map((v, i) => v.deleted ? '' : `<div class="ty-srow" data-vi="${i}"><input type="text" data-vk="name" value="${esc(v.name)}" aria-label="${esc(t('Назва'))}"><input type="text" data-vk="text" value="${esc(v.text || '')}" aria-label="${esc(t('Текст'))}"><button type="button" class="btn" data-va="ins">${esc(t('Вставити'))}</button><button type="button" class="ib" data-va="del" aria-label="${esc(t('Видалити'))}">${O.icon('trash', 14)}</button></div>`).join('')}</div>
      <div class="row"><button type="button" class="btn" data-va="add">${O.icon('plus', 14)} ${esc(t('Нова змінна'))}</button></div>
      <label class="dlg-row"><span>${esc(t('Колонтитул: стиль абзацу'))}</span><select data-va="hdr"><option value="">—</option>${(S.doc.pstyles || []).map(s => `<option value="${s.id}"${S.doc.headerStyle === s.id ? ' selected' : ''}>${esc(s.name)}</option>`).join('')}</select></label>
      <div class="dlg-text small">${esc(t('Вбудовані змінні (дати, ім’я файлу, номер останньої сторінки, колонтитул) — у меню Текст → Текстові змінні → Вставити змінну.'))}</div>`;
    const d = ui.dialog({ title: 'Текстові змінні', body: `<div class="ty-vbody">${body()}</div>`, buttons: [{ id: 'ok', label: 'Готово', primary: true }], onOk: () => O.history.commit('Текстові змінні') });
    const redraw = () => { d.el.querySelector('.ty-vbody').innerHTML = body(); };
    d.el.addEventListener('click', e => {
      const b = e.target.closest('[data-va]');
      if (!b || b.tagName === 'SELECT') return;
      e.preventDefault(); e.stopPropagation();
      const row = b.closest('[data-vi]');
      if (b.dataset.va === 'add') { list().push({ name: t('Змінна {n}', { n: list().length + 1 }), text: '' }); redraw(); }
      if (b.dataset.va === 'del' && row) { list()[+row.dataset.vi].deleted = true; redraw(); }
      if (b.dataset.va === 'ins' && row) { O.history.commit('Текстові змінні'); TU.insertVar(16 + +row.dataset.vi); }
    });
    d.el.addEventListener('change', e => {
      if (e.target.dataset.va === 'hdr') { S.doc.headerStyle = e.target.value || null; return; }
      const row = e.target.closest('[data-vi]');
      if (row && e.target.dataset.vk) list()[+row.dataset.vi][e.target.dataset.vk] = e.target.value;
    });
  };
  TU.varPick = () => {
    const vars = TS.allVars();
    ui.dialog({ title: 'Вставити змінну', fields: [{ key: 'v', label: 'Змінна', type: 'select', value: String(vars[0].idx), options: vars.map(v => [String(v.idx), v.builtin ? t(v.name) + ' — ' + TS.varValue(v.idx, areaTexts()[0]) : v.name]) }], onOk: v => TU.insertVar(+v.v) });
  };

  // bullets & numbering
  TU.listOptions = () => {
    const c = TU.cur();
    if (!c) return O.toast('Виділіть текст');
    const L0 = c.P.list || {};
    ui.dialog({
      title: 'Маркери та нумерація',
      fields: [
        { key: 't', label: 'Тип списку', type: 'select', value: L0.t || 'bullet', options: [['none', 'Немає'], ['bullet', 'Маркери'], ['num', 'Нумерація']] },
        { key: 'ch', label: 'Символ маркера', type: 'select', value: L0.ch || '•', options: ['•', '◦', '▪', '■', '–', '—', '✓', '★', '➤', '○', '►', '·', '*'].map(x => [x, x]) },
        { key: 'chc', label: 'Інший символ маркера', type: 'text', value: '' },
        { key: 'style', label: 'Формат номера', type: 'select', value: L0.style || 'arabic', options: [['arabic', '1, 2, 3…'], ['zero', '01, 02, 03…'], ['roman', 'i, ii, iii…'], ['ROMAN', 'I, II, III…'], ['alpha', 'a, b, c…'], ['ALPHA', 'A, B, C…'], ['cyr', 'а, б, в…']] },
        { key: 'pre', label: 'Перед номером', type: 'text', value: L0.pre || '' },
        { key: 'suf', label: 'Після номера', type: 'text', value: isSet(L0.suf) ? L0.suf : '.' },
        { key: 'start', label: 'Почати з', type: 'number', value: L0.start || 1 },
        { key: 'restart', label: 'Почати нумерацію заново', type: 'checkbox', value: !!L0.restart },
        { key: 'indent', label: 'Відступ тексту від маркера, px', type: 'text', value: isSet(L0.indent) ? fmt(L0.indent) : '' },
        { key: 'color', label: 'Колір маркера (#RRGGBB)', type: 'text', value: L0.color || '' }
      ],
      onOk: v => {
        if (v.t === 'none') { TU.setPara({ list: null }); O.history.commit('Список'); return; }
        const L1 = { t: v.t };
        if (v.t === 'bullet') { L1.ch = String(v.chc || '').trim() || v.ch; TU.lastBullet = { ch: L1.ch }; }
        else { Object.assign(L1, { style: v.style, pre: v.pre, suf: v.suf, start: Math.max(0, Math.round(v.start || 1)) }); if (v.restart) L1.restart = true; TU.lastNum = { style: v.style, pre: v.pre, suf: v.suf }; }
        const ind = num(v.indent); if (isFinite(ind)) L1.indent = Math.max(0, ind);
        const col = O.color.norm(v.color || ''); if (col) L1.color = col;
        TU.setPara({ list: L1 });
        O.history.commit('Список');
      }
    });
  };
  const listEdit = fn => { const c = TU.cur(); if (!c) return O.toast('Виділіть текст'); const L1 = fn(c.P.list ? O.clone(c.P.list) : null); TU.setPara({ list: L1 }); O.history.commit('Список'); };
  TU.listToText = () => {
    const list = TU.target() ? [TU.target().n] : areaTexts();
    for (const n of list) {
      const L = O.text.layout(n);
      const inserts = [];
      for (const info of L.paras) if (info.label && !info.virtual) inserts.push([info.ps, info.label + '\t']);
      if (!inserts.length) continue;
      inserts.sort((a, b) => b[0] - a[0]);
      for (const [p, s] of inserts) { const old = n.text; n.text = old.slice(0, p) + s + old.slice(p); TS.textChanged(n, old, n.text, { noTrack: true }); }
      delete n.list; TS.stripKey(n, 'pars', ['list']);
      if (S.textEdit && S.textEdit.id === n.id) { taEl().value = n.text; O.textEdit.sync(); }
    }
    O.history.commit('Перетворити список на текст');
  };

  // placeholder / generated / rewritten text
  const LOREM = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus. Maecenas sed diam eget risus varius blandit sit amet non magna. Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Cras mattis consectetur purus sit amet fermentum. Nullam quis risus eget urna mollis ornare vel eu leo. Aenean lacinia bibendum nulla sed consectetur. Curabitur blandit tempus porttitor. Etiam porta sem malesuada magna mollis euismod. Sed posuere consectetur est at lobortis. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.'.split(/(?<=\.)\s+/);
  TU.placeholder = () => {
    const tg = TU.target();
    const list = tg ? [tg.n] : areaTexts();
    if (!list.length) return O.toast('Виділіть текстовий фрейм');
    for (const n of list) {
      const fixed = n.boxH && n.width;
      if (tg && tg.n === n && (n.text || '').trim()) {
        TU.insert(LOREM.slice(0, 3).join(' '), { label: 'Шаблонний текст' });
        continue;
      }
      if (!fixed) { n.text = LOREM.slice(0, 5).join(' '); delete n.runs; continue; }
      // fill the frame (all columns) until the next sentence would not fit
      let out = '', k = 0, para = 0;
      for (let guard = 0; guard < 2000; guard++) {
        const s = LOREM[k % LOREM.length];
        const next = out + (out ? (para >= 5 ? '\n' : ' ') : '') + s;
        if (TS.layoutWith(n, next, null, n.pars).overset) break;
        if (para >= 5) para = 0;
        out = next; k++; para++;
      }
      n.text = out || LOREM[0].split(' ').slice(0, 3).join(' ');
      delete n.runs;
      if (S.textEdit && S.textEdit.id === n.id) { taEl().value = n.text; O.textEdit.sync(); }
    }
    O.history.commit('Шаблонний текст');
  };
  const GEN = {
    uk: { s: ['{T} — це те, що об’єднує людей навколо спільної мети.', 'Ми зібрали найважливіше про {t} в одному місці.', 'Кожна деталь у темі «{t}» має значення.', 'Почніть із простого: визначте, чого ви хочете досягти завдяки {t}.', 'Досвід показує, що {t} працює найкраще, коли є чіткий план.', 'Дізнайтеся більше та поділіться своєю думкою.', 'Саме тому {t} заслуговує на вашу увагу вже сьогодні.', 'Невеликі кроки щодня дають помітний результат.', 'Спробуйте, порівняйте й оберіть те, що підходить саме вам.', 'Наша команда готова допомогти на кожному етапі.'], h: ['{T}: усе, що варто знати', 'Новий погляд на {t}', '{T} без зайвих слів'], li: ['Чітка мета', 'Зрозумілий план', 'Вимірюваний результат', 'Підтримка команди', 'Гнучкість і швидкість'] },
    en: { s: ['{T} is what brings people together around a shared goal.', 'We gathered the essentials about {t} in one place.', 'Every detail of {t} matters.', 'Start simple: decide what you want to achieve with {t}.', 'Experience shows that {t} works best with a clear plan.', 'Learn more and share your thoughts.', 'That is why {t} deserves your attention today.', 'Small steps every day lead to visible results.', 'Try, compare and choose what suits you best.', 'Our team is ready to help at every stage.'], h: ['{T}: everything you need to know', 'A fresh look at {t}', '{T}, simply explained'], li: ['A clear goal', 'A simple plan', 'Measurable results', 'Team support', 'Flexibility and speed'] },
    de: { s: ['{T} bringt Menschen um ein gemeinsames Ziel zusammen.', 'Wir haben das Wichtigste über {t} an einem Ort gesammelt.', 'Bei {t} zählt jedes Detail.', 'Fangen Sie einfach an: Was möchten Sie mit {t} erreichen?', 'Die Erfahrung zeigt: {t} funktioniert am besten mit einem klaren Plan.', 'Erfahren Sie mehr und teilen Sie Ihre Meinung.', 'Deshalb verdient {t} schon heute Ihre Aufmerksamkeit.', 'Kleine Schritte jeden Tag führen zu sichtbaren Ergebnissen.', 'Probieren Sie aus, vergleichen Sie und wählen Sie, was passt.', 'Unser Team hilft Ihnen in jeder Phase.'], h: ['{T}: alles Wichtige', 'Ein neuer Blick auf {t}', '{T} – kurz erklärt'], li: ['Ein klares Ziel', 'Ein einfacher Plan', 'Messbare Ergebnisse', 'Unterstützung im Team', 'Flexibilität und Tempo'] },
    ru: { s: ['{T} — это то, что объединяет людей вокруг общей цели.', 'Мы собрали самое важное о {t} в одном месте.', 'В теме «{t}» важна каждая деталь.', 'Начните с простого: определите, чего хотите достичь благодаря {t}.', 'Опыт показывает, что {t} лучше всего работает при чётком плане.', 'Узнайте больше и поделитесь своим мнением.', 'Именно поэтому {t} заслуживает вашего внимания уже сегодня.', 'Небольшие шаги каждый день дают заметный результат.', 'Попробуйте, сравните и выберите то, что подходит именно вам.', 'Наша команда готова помочь на каждом этапе.'], h: ['{T}: всё, что стоит знать', 'Новый взгляд на {t}', '{T} без лишних слов'], li: ['Чёткая цель', 'Понятный план', 'Измеримый результат', 'Поддержка команды', 'Гибкость и скорость'] }
  };
  TU.generate = () => {
    const tg = TU.target();
    if (!tg && !areaTexts().length) return O.toast('Виділіть текстовий фрейм');
    ui.dialog({
      title: 'Генерувати текст',
      body: `<div class="dlg-text small">${esc(t('Текст складається на пристрої з готових шаблонів (без ШІ та інтернету). Потім його легко відредагувати.'))}</div>`,
      fields: [{ key: 'topic', label: 'Тема', type: 'text', value: '' }, { key: 'kind', label: 'Що створити', type: 'select', value: 'para', options: [['para', 'Абзаци'], ['head', 'Заголовок і абзац'], ['list', 'Список переваг']] },
        { key: 'lang', label: 'Мова', type: 'select', value: GEN[O.lang] ? O.lang : 'uk', options: [['uk', 'Українська'], ['en', 'English'], ['de', 'Deutsch'], ['ru', 'Русский']] }, { key: 'n', label: 'Кількість речень', type: 'number', value: 5, min: 1, max: 40 }],
      onOk: v => {
        const g = GEN[v.lang] || GEN.uk;
        const topic = String(v.topic || '').trim() || { uk: 'дизайн', en: 'design', de: 'Design', ru: 'дизайн' }[v.lang] || 'дизайн';
        const T1 = topic[0].toUpperCase() + topic.slice(1);
        const fill = s => s.replace(/\{T\}/g, T1).replace(/\{t\}/g, topic);
        const seed = Array.from(topic).reduce((a, ch) => a + ch.charCodeAt(0), 0);
        const count = O.clamp(Math.round(v.n || 5), 1, 40);
        const sents = []; for (let i = 0; i < count; i++) sents.push(fill(g.s[(seed + i * 3) % g.s.length]));
        let out;
        if (v.kind === 'head') out = fill(g.h[seed % g.h.length]) + '\n' + sents.join(' ');
        else if (v.kind === 'list') out = g.li.slice(0, Math.min(g.li.length, Math.max(3, count))).join('\n');
        else { const ps = []; for (let i = 0; i < sents.length; i += 4) ps.push(sents.slice(i, i + 4).join(' ')); out = ps.join('\n'); }
        const tg2 = TU.target();
        if (tg2) { TU.insert(out, { label: 'Генерувати текст' }); if (v.kind === 'list') { const c2 = TU.target(); if (c2) { const a = c2.a - out.length; const [ps, pe] = TS.paraRange(c2.n.text, a, c2.a); TS.applyRange(c2.n, 'pars', ps, pe + 1, { list: { t: 'bullet', ch: '•' } }); O.history.commit('Генерувати текст'); } } return; }
        for (const n of areaTexts()) { n.text = out; delete n.runs; delete n.pars; if (v.kind === 'list') n.list = { t: 'bullet', ch: '•' }; if (v.kind === 'head') TS.applyRange(n, 'runs', 0, out.indexOf('\n'), { weight: 700, size: n.size * 1.4 }); }
        O.history.commit('Генерувати текст');
      }
    });
  };
  TU.rewrite = () => {
    if (!TU.target() && !areaTexts().length) return O.toast('Виділіть текст');
    ui.dialog({
      title: 'Переписати',
      body: `<div class="dlg-text small">${esc(t('Правила застосовуються до виділеного тексту або до всього фрейма.'))}</div>`,
      fields: [{ key: 'typo', label: 'Типографіка: лапки «», тире, три крапки, зайві пробіли', type: 'checkbox', value: true },
        { key: 'nbsp', label: 'Нерозривні пробіли після коротких слів', type: 'checkbox', value: true },
        { key: 'sent', label: 'Кожне речення з великої літери', type: 'checkbox', value: false },
        { key: 'empty', label: 'Прибрати порожні рядки', type: 'checkbox', value: false },
        { key: 'short', label: 'Скоротити до речень (0 — не скорочувати)', type: 'number', value: 0, min: 0 }],
      onOk: v => transformText(s => {
        let r = s;
        if (v.typo) {
          r = r.replace(/[ \t]{2,}/g, ' ').replace(/ +([,.;:!?…])/g, '$1').replace(/\.\.\./g, '…')
            .replace(/(^|[\s(\[{„])"(?=\S)/g, '$1«').replace(/"/g, '»').replace(/(\S) - (\S)/g, '$1 — $2').replace(/(\d)-(\d)/g, '$1–$2');
        }
        if (v.nbsp) r = r.replace(/(^|[\s«(])([A-Za-zА-Яа-яЄєІіЇїҐґ]{1,2}) (?=\S)/g, '$1$2\u00A0').replace(/ (—)/g, '\u00A0$1');
        if (v.sent) { let start = true; r = mapChars(r, ch => { if (/\p{L}/u.test(ch)) { const q = start ? ch.toUpperCase() : ch; start = false; return q; } if (/[.!?…\n]/.test(ch)) start = true; return ch; }); }
        if (v.empty) r = r.replace(/\n{2,}/g, '\n').replace(/^\n+|\n+$/g, '');
        if (v.short > 0) { const parts = r.match(/[^.!?…]+[.!?…]+\s*/g) || [r]; r = parts.slice(0, Math.round(v.short)).join('').trim(); }
        return r;
      }, 'Переписати')
    });
  };

  // text frame options (Ctrl+B)
  TU.frameOptions = () => {
    const list = areaTexts();
    if (!list.length) return O.toast('Виділіть текстовий фрейм');
    const n = list[0];
    const ins = Array.isArray(n.inset) ? n.inset : [0, 0, 0, 0];
    ui.dialog({
      title: 'Параметри текстового фрейма',
      fields: [
        { key: 'cols', label: 'Кількість колонок', type: 'number', value: n.cols || 1, min: 1, max: MAX_COLS },
        { key: 'gap', label: 'Проміжок між колонками, px', type: 'number', value: isSet(n.colGap) ? n.colGap : 12, min: 0 },
        { key: 'colw', label: 'Ширина колонки, px (0 — за шириною фрейма)', type: 'number', value: 0, min: 0 },
        { key: 'bal', label: 'Балансувати колонки', type: 'checkbox', value: !!n.colBal },
        { key: 'it', label: 'Відступ зверху, px', type: 'number', value: ins[0] }, { key: 'ir', label: 'Відступ праворуч, px', type: 'number', value: ins[1] },
        { key: 'ib', label: 'Відступ знизу, px', type: 'number', value: ins[2] }, { key: 'il', label: 'Відступ ліворуч, px', type: 'number', value: ins[3] },
        { key: 'fixed', label: 'Фіксована висота фрейма', type: 'checkbox', value: !!n.boxH },
        { key: 'h', label: 'Висота, px', type: 'number', value: Math.round(n.boxH || O.text.layout(n).h) },
        { key: 'valign', label: 'Вертикальне вирівнювання', type: 'select', value: n.valign || 'top', options: [['top', 'Вгору'], ['center', 'По центру'], ['bottom', 'Вниз'], ['justify', 'Розподілити']] },
        { key: 'opt', label: 'Оптичне вирівнювання полів', type: 'checkbox', value: !!n.optical }
      ],
      preview: true,
      label: 'Параметри текстового фрейма',
      apply: v => {
        for (const x of list) {
          const cols = O.clamp(Math.round(v.cols || 1), 1, MAX_COLS);
          x.colGap = Math.max(0, v.gap);
          const inset = [v.it, v.ir, v.ib, v.il].map(q => Math.max(0, +q || 0));
          if (inset.some(q => q)) x.inset = inset; else delete x.inset;
          setCols(x, cols);
          if (v.colw > 0 && cols >= 1) x.width = inset[1] + inset[3] + v.colw * cols + x.colGap * (cols - 1);
          if (v.bal) x.colBal = true; else delete x.colBal;
          if (v.fixed) x.boxH = Math.max(4, v.h || O.text.layout(x).h); else delete x.boxH;
          if (v.valign && v.valign !== 'top') x.valign = v.valign; else delete x.valign;
          if (v.opt) x.optical = true; else delete x.optical;
        }
      }
    });
  };
  // type on a path options
  TU.pathOptions = () => {
    const list = texts().filter(n => n.path);
    if (!list.length) return O.toast('Виділіть текст на контурі');
    const n = list[0];
    ui.dialog({
      title: 'Параметри тексту за контуром',
      fields: [{ key: 'off', label: 'Початок, % довжини контуру', type: 'number', value: n.pathOffset || 0 }, { key: 'ls', label: 'Інтервал між літерами, px', type: 'number', value: n.ls || 0 }, { key: 'flip', label: 'Віддзеркалити (з іншого боку контуру)', type: 'checkbox', value: false }],
      preview: true, label: 'Текст за контуром',
      apply: v => {
        for (const x of list) {
          x.pathOffset = O.clamp(v.off, 0, 100); x.ls = v.ls;
          if (v.flip) x.path = x.path.map(sp => ({ closed: sp.closed, pts: sp.pts.slice().reverse().map(p => Object.assign({}, p, { i: p.o, o: p.i })) }));
        }
      }
    });
  };

  // OpenType features menu
  const OT_ITEMS = [['liga', 'Стандартні лігатури', true], ['dlig', 'Дискреційні лігатури'], ['calt', 'Контекстні варіанти', true], ['swsh', 'Розчерки'], ['salt', 'Стилістичні варіанти'], ['titl', 'Заголовкові варіанти'],
    ['ordn', 'Порядкові'], ['frac', 'Дроби'], ['zero', 'Перекреслений нуль'], ['sups', 'Надрядкові символи'], ['subs', 'Підрядкові символи'], ['c2sc', 'Усі капітелі'], ['case', 'Форми з урахуванням регістру'], ['ss01', 'Стилістичний набір 1'], ['ss02', 'Стилістичний набір 2'], ['ss03', 'Стилістичний набір 3']];
  const FIGS = [['', 'Цифри за замовчуванням'], ['tnum,lnum', 'Табличні моноширинні'], ['pnum,onum', 'Пропорційні старостильні'], ['pnum,lnum', 'Пропорційні моноширинні'], ['tnum,onum', 'Табличні старостильні']];
  TU.openTypeMenu = () => {
    const c = TU.cur();
    if (!c) return O.toast('Виділіть текст');
    const ot = c.st.ot || {};
    const on = (k, def) => (ot[k] === undefined ? !!def : !!ot[k]);
    const items = OT_ITEMS.map(([k, l, def]) => ({ id: 'ot:' + k, label: l, check: () => on(k, def) })).concat(['-'], FIGS.map(([v, l]) => ({ id: 'figs:' + v, label: l, check: () => (ot.figs || '') === v })));
    const a = O.$('[data-cmd="tyOpenType"]') || O.$('#props');
    const r = a.getBoundingClientRect();
    ui.menu(items, r.left, r.bottom + 4, { onPick: id => {
      const next = Object.assign({}, ot);
      if (id.startsWith('ot:')) { const k = id.slice(3); const def = (OT_ITEMS.find(x => x[0] === k) || [])[2]; next[k] = on(k, def) ? 0 : 1; if (!!next[k] === !!def) delete next[k]; }
      else { const v = id.slice(5); if (v) next.figs = v; else delete next.figs; }
      TU.setChar({ ot: Object.keys(next).length ? next : null });
      O.history.commit('OpenType');
    } });
  };
  TU.caseMenu = () => {
    const a = O.$('[data-cmd="tyCaseMenu"]') || O.$('#props');
    const r = a.getBoundingClientRect();
    ui.menu(['chUpper', 'chLower', 'chTitle', 'chSentence'], r.left, r.bottom + 4);
  };
  TU.focusSection = key => {
    if (!texts().length) return O.toast('Виділіть текст');
    document.body.classList.add('show-right');
    const tab = O.$('#right [data-rt="design"]'); if (tab && !tab.classList.contains('on')) tab.click();
    O.panels.refresh(true, true);
    setTimeout(() => { const s = O.$(`#props [data-sec="${key}"]`); if (s) { s.scrollIntoView({ block: 'start', behavior: 'smooth' }); s.classList.add('ty-flash'); setTimeout(() => s.classList.remove('ty-flash'), 900); const i = s.querySelector('input,select'); if (i && !S.textEdit) i.focus(); } }, 30);
  };

  // ======================================================================
  // COMMANDS & MENU
  // ======================================================================
  const hasText = () => texts().length > 0;
  const hasArea = () => areaTexts().length > 0 || !!TU.target();
  const editing = () => !!TU.target();
  const commit = (fn, label) => () => { fn(); O.history.commit(label); };
  C('tyCharacter', 'Символ', () => TU.focusSection('ty-char'), { keys: ['Ctrl+T'] });
  C('tyParagraph', 'Абзац', () => TU.focusSection('ty-para'), { keys: ['Ctrl+Alt+T'] });
  C('tyTabs', 'Табулятори', () => TU.tabsDialog(), { keys: ['Ctrl+Shift+T'], enabled: hasText });
  C('tyGlyphs', 'Гліфи', () => TU.glyphsDialog(), { keys: ['Alt+Shift+F11'] });
  C('tyStory', 'Матеріал', () => TU.storyDialog(), { enabled: hasArea });
  C('tyStoryEditor', 'Редактор матеріалу…', () => TU.storyEditor(), { enabled: hasArea });
  C('tyCharStyles', 'Стилі символів', () => TU.stylesDialog('c'), { keys: ['Shift+F11'] });
  C('tyParaStyles', 'Стилі абзацу', () => TU.stylesDialog('p'), { keys: ['F11'] });
  C('tyNewPStyle', 'Новий стиль абзацу…', () => TU.newStyle('p'), { enabled: hasText });
  C('tyNewCStyle', 'Новий стиль символу…', () => TU.newStyle('c'), { enabled: hasText });
  C('tyRedefineStyle', 'Перевизначити стиль', () => TU.redefineStyle(), { enabled: hasText });
  C('tyClearOverrides', 'Очистити перевизначення', () => TU.clearOverrides(), { enabled: hasText });
  C('tyFindFont', 'Знайти/замінити шрифт…', () => TU.findFontDialog());
  C('tyFontPick', 'Шрифти…', () => { const c = TU.cur(); const a = O.$('[data-cmd="tyFontPick"]') || O.$('#btn-palette'); O.fonts.picker(a, c ? c.st.font : 'Inter', fam => { const g = O.fonts.get(fam); TU.setChar({ font: g ? g.family : fam }); O.history.commit('Шрифт'); }); }, { enabled: hasText });
  C('tyCharMore', 'Параметри символів…', () => TU.charDialog(), { enabled: hasText });
  C('tyParaMore', 'Параметри абзацу…', () => TU.paraDialog(), { enabled: hasText });
  C('tyOpenType', 'OpenType…', () => TU.openTypeMenu(), { enabled: hasText });
  C('tyCaseMenu', 'Змінити регістр', () => TU.caseMenu(), { enabled: hasText });
  [['chUpper', 'upper', 'ВЕРХНІЙ РЕГІСТР'], ['chLower', 'lower', 'нижній регістр'], ['chTitle', 'title', 'Як У Заголовках'], ['chSentence', 'sentence', 'Як у реченнях']]
    .forEach(([id, m, l]) => C(id, l, () => TU.changeCase(m), { group: 'Змінити регістр', enabled: hasText }));
  C('tyPathOptions', 'Параметри…', () => TU.pathOptions(), { enabled: () => texts().some(n => n.path) });
  // footnotes / endnotes / notes
  C('tyInsertFootnote', 'Вставити примітку', () => TU.insertNote('fn'), { enabled: hasArea });
  C('tyFnOptions', 'Параметри приміток документа…', () => TU.noteOptions('fn'));
  C('tyInsertEndnote', 'Вставити кінцеву виноску', () => TU.insertNote('en'), { enabled: hasArea });
  C('tyEnOptions', 'Параметри кінцевих виносок документа…', () => TU.noteOptions('en'));
  C('tyConvertNotes', 'Перетворення виносок і кінцевих виносок…', () => TU.convertNotes());
  C('tyNoteNew', 'Нова примітка…', () => TU.insertNote('note'), { group: 'Примітки', enabled: hasArea });
  C('tyNoteNext', 'Перейти до наступної примітки', () => TU.gotoNote(1), { group: 'Примітки' });
  C('tyNotePrev', 'Перейти до попередньої примітки', () => TU.gotoNote(-1), { group: 'Примітки' });
  C('tyNoteToText', 'Перетворити примітки на текст', () => {
    for (const n of areaTexts()) {
      const text = n.text || ''; if (text.indexOf(CH.note) < 0) continue;
      const notes = (n.notes || []).slice(); let k = 0;
      const nt = Array.from(text).map(c => (c === CH.note ? ' [' + ((notes[k++] || {}).text || '') + ']' : c)).join('');
      const old = text; n.text = nt; delete n.notes; TS.textChanged(n, old, nt, { noTrack: true }); delete n.notes;
    }
    O.history.commit('Примітки на текст');
  }, { group: 'Примітки', enabled: hasArea });
  C('tyNotesDelAll', 'Видалити всі примітки у фреймі', () => { for (const n of areaTexts()) { const old = n.text || ''; if (old.indexOf(CH.note) < 0) continue; n.text = old.split(CH.note).join(''); TS.textChanged(n, old, n.text, { noTrack: true }); delete n.notes; } O.history.commit('Видалити примітки'); }, { group: 'Примітки', enabled: hasArea });
  C('tyNotesShow', 'Показувати примітки', () => { S.settings.showNotes = S.settings.showNotes === false; O.saveSettings(); O.requestOverlay(); }, { group: 'Примітки', check: () => S.settings.showNotes !== false });
  // track changes
  C('tyTrackStory', 'Відстежувати зміни в поточному матеріалі', () => { const list = areaTexts().length ? areaTexts() : (editNode() ? [editNode()] : []); if (!list.length) return O.toast('Виділіть текстовий фрейм'); const on = !list[0].track; for (const n of list) { if (on) n.track = true; else delete n.track; } O.history.commit('Відстеження змін'); O.toast(on ? 'Зміни в матеріалі відстежуються' : 'Відстеження змін вимкнено'); }, { group: 'Відслідковувати зміни', check: () => { const n = areaTexts()[0] || editNode(); return !!(n && n.track); } });
  C('tyTrackAll', 'Відстежувати зміни в усіх матеріалах', () => { S.doc.trackAll = !S.doc.trackAll; O.history.commit('Відстеження змін'); }, { group: 'Відслідковувати зміни', check: () => !!(S.doc && S.doc.trackAll) });
  C('tyShowChanges', 'Показати зміни', () => { S.settings.showChanges = !S.settings.showChanges; O.saveSettings(); O.text.reset(); O.requestRender(); }, { group: 'Відслідковувати зміни', check: () => !!S.settings.showChanges });
  C('tyAcceptStory', 'Прийняти всі зміни в матеріалі', () => { let k = 0; for (const n of (areaTexts().length ? areaTexts() : [editNode()].filter(Boolean))) { if (TS.hasChanges(n)) { TS.acceptChanges(n, true); k++; } } O.history.commit('Прийняти зміни'); O.toast('Прийнято змін у фреймах: {n}', { n: k }); if (S.textEdit) { const n = editNode(); if (n) { taEl().value = n.text; O.textEdit.sync(); } } }, { group: 'Відслідковувати зміни' });
  C('tyRejectStory', 'Відхилити всі зміни в матеріалі', () => { let k = 0; for (const n of (areaTexts().length ? areaTexts() : [editNode()].filter(Boolean))) { if (TS.hasChanges(n)) { TS.acceptChanges(n, false); k++; } } O.history.commit('Відхилити зміни'); O.toast('Відхилено змін у фреймах: {n}', { n: k }); if (S.textEdit) { const n = editNode(); if (n) { taEl().value = n.text; O.textEdit.sync(); } } }, { group: 'Відслідковувати зміни' });
  C('tyAcceptDoc', 'Прийняти всі зміни в документі', () => { for (const { n } of allTexts()) if (TS.hasChanges(n)) TS.acceptChanges(n, true); O.history.commit('Прийняти зміни'); }, { group: 'Відслідковувати зміни' });
  C('tyRejectDoc', 'Відхилити всі зміни в документі', () => { for (const { n } of allTexts()) if (TS.hasChanges(n)) TS.acceptChanges(n, false); O.history.commit('Відхилити зміни'); }, { group: 'Відслідковувати зміни' });
  // hyperlinks
  C('tyLinkNew', 'Нове гіперпосилання…', () => TU.newLink(), { group: 'Гіперпосилання', enabled: hasArea });
  C('tyLinkRemove', 'Видалити гіперпосилання', () => TU.removeLink(), { group: 'Гіперпосилання', enabled: hasArea });
  C('tyLinkOpen', 'Перейти за адресою', () => TU.openLink(), { group: 'Гіперпосилання', enabled: hasArea });
  C('tyLinksPanel', 'Усі гіперпосилання…', () => TU.linksPanel(), { group: 'Гіперпосилання' });
  C('tyXref', 'Вставити перехресне посилання…', () => TU.xrefDialog(), { group: 'Гіперпосилання', enabled: hasArea });
  C('tyXrefUpdate', 'Оновити перехресні посилання', () => { O.text.reset(); O.requestRender(); O.toast('Перехресні посилання оновлено'); }, { group: 'Гіперпосилання' });
  // text variables
  TS.BUILTIN_VARS.forEach((v, i) => C('tyVar:' + i, v.name, () => TU.insertVar(i), { group: 'Текстові змінні', enabled: hasArea }));
  C('tyVarPick', 'Інша змінна…', () => TU.varPick(), { group: 'Текстові змінні', enabled: hasArea });
  C('tyVarsDefine', 'Визначити…', () => TU.varsDialog(), { group: 'Текстові змінні' });
  // lists
  C('tyBullets', 'Застосувати маркери', () => listEdit(() => Object.assign({ t: 'bullet', ch: '•' }, TU.lastBullet || {})), { group: 'Списки', enabled: hasText });
  C('tyNumbers', 'Застосувати нумерацію', () => listEdit(() => Object.assign({ t: 'num', style: 'arabic', suf: '.', start: 1 }, TU.lastNum || {})), { group: 'Списки', enabled: hasText });
  C('tyListOff', 'Вимкнути маркери та нумерацію', () => listEdit(() => null), { group: 'Списки', enabled: hasText });
  C('tyListToText', 'Перетворити маркери та нумерацію на текст', () => TU.listToText(), { group: 'Списки', enabled: hasText });
  C('tyRestartNum', 'Почати нумерацію заново', () => listEdit(L => (L && L.t === 'num' ? Object.assign(L, { restart: true }) : { t: 'num', style: 'arabic', suf: '.', start: 1, restart: true })), { group: 'Списки', enabled: hasText });
  C('tyContinueNum', 'Продовжити нумерацію', () => listEdit(L => { if (L) delete L.restart; return L; }), { group: 'Списки', enabled: hasText });
  C('tyListOptions', 'Маркери та нумерація…', () => TU.listOptions(), { group: 'Списки', enabled: hasText });
  // special characters, white space, breaks
  const INS = [
    ['Маркери', [['pageNum', CH.pageNum, 'Номер поточної сторінки'], ['nextPage', CH.nextPage, 'Номер наступної сторінки'], ['prevPage', CH.prevPage, 'Номер попередньої сторінки'], ['section', CH.section, 'Маркер розділу']]],
    ['Дефіси і тире', [['emDash', '—', 'Довге тире'], ['enDash', '–', 'Коротке тире'], ['softHyphen', CH.softHyphen, 'Дискреційний дефіс'], ['nbHyphen', CH.nbHyphen, 'Нерозривний дефіс']]],
    ['Лапки', [['qGuil', '«»', 'Лапки-ялинки «»'], ['qLow', '„“', 'Лапки-лапки „“'], ['qDL', '“', 'Подвійна ліва лапка'], ['qDR', '”', 'Подвійна права лапка'], ['qSL', '‘', 'Одинарна ліва лапка'], ['qSR', '’', 'Одинарна права лапка (апостроф)'], ['qD', '"', 'Пряма подвійна лапка'], ['qS', '\'', 'Пряма одинарна лапка']]],
    ['Символи', [['bullet', '•', 'Маркер списку'], ['copy', '©', 'Знак авторського права'], ['ellipsis', '…', 'Три крапки'], ['pilcrow', '¶', 'Символ абзацу'], ['reg', '®', 'Зареєстрований товарний знак'], ['sect', '§', 'Символ параграфа'], ['tm', '™', 'Товарний знак'], ['deg', '°', 'Градус'], ['times', '×', 'Знак множення'], ['pm', '±', 'Плюс-мінус'], ['numero', '№', 'Знак номера']]],
    ['Інше', [['tab', '\t', 'Табуляція'], ['rtab', CH.rightTab, 'Табуляція до правого відступу'], ['ith', CH.indentHere, 'Відступ до цієї точки'], ['endNested', CH.endNested, 'Кінець вкладеного стилю'], ['zwnj', '\u200C', 'Нероз’єднувальний символ']]]
  ];
  const SPACES = [['em', '\u2003', 'Пробіл em'], ['en', '\u2002', 'Пробіл en'], ['nbsp', '\u00A0', 'Нерозривний пробіл'], ['nbspf', '\u202F', 'Нерозривний пробіл (фіксованої ширини)'], ['hair', '\u200A', 'Волосяний пробіл'], ['sixth', '\u2006', 'Шоста частина пробілу'], ['thin', '\u2009', 'Тонкий пробіл'], ['quarter', '\u2005', 'Чверть пробілу'], ['third', '\u2004', 'Третина пробілу'], ['punct', '\u2008', 'Пробіл пунктуації'], ['figure', '\u2007', 'Цифровий пробіл'], ['flush', '\u2001', 'Вирівнюючий пробіл']];
  const BRKS = [['col', CH.colBreak, 'Розрив колонки'], ['frame', CH.frameBreak, 'Розрив фрейма'], ['page', CH.pageBreak, 'Розрив сторінки'], ['odd', CH.oddPage, 'Розрив непарної сторінки'], ['even', CH.evenPage, 'Розрив парної сторінки'], ['para', '\n', 'Повернення каретки (новий абзац)'], ['line', CH.lineBreak, 'Примусовий розрив рядка'], ['disc', CH.discLine, 'Дискреційний розрив рядка']];
  const insCmd = (id, str, label, group) => C('tyIns:' + id, label, () => {
    if (str.length === 2 && /[«„]/.test(str[0])) {
      // a pair of quotes around the selection
      const tg = TU.target();
      if (tg && tg.b > tg.a) { const sel = tg.n.text.slice(tg.a, tg.b); TU.insert(str[0] + sel + str[1], { label }); return; }
      TU.insert(str[0], { label }); return;
    }
    TU.insert(str, { label });
  }, { group, enabled: hasArea });
  INS.forEach(([g, list]) => list.forEach(([id, s, l]) => insCmd(id, s, l, 'Спеціальні символи')));
  SPACES.forEach(([id, s, l]) => insCmd(id, s, l, 'Пробіли'));
  BRKS.forEach(([id, s, l]) => insCmd(id, s, l, 'Символи розриву'));
  // placeholder, generate, rewrite, hidden characters, frame options
  C('tyPlaceholder', 'Заповнити шаблонним текстом', () => TU.placeholder(), { enabled: hasArea });
  C('tyGenerate', 'Генерувати текст…', () => TU.generate(), { enabled: hasArea });
  C('tyRewrite', 'Переписати…', () => TU.rewrite(), { enabled: hasText });
  C('tyHidden', 'Показати приховані символи', () => { S.settings.hiddenChars = !S.settings.hiddenChars; O.saveSettings(); O.requestRender(); }, { keys: ['Ctrl+Alt+I'], check: () => !!S.settings.hiddenChars });
  C('tyFrameOptions', 'Параметри текстового фрейма…', () => TU.frameOptions(), { keys: ['Ctrl+B'], enabled: hasArea });
  C('tyColsMore', 'Додати колонку', commit(() => forFrames(n => setCols(n, (n.cols || 1) + 1)), 'Колонки'), { enabled: hasArea });
  C('tyColsLess', 'Прибрати колонку', commit(() => forFrames(n => { n.cols = Math.max(1, (n.cols || 1) - 1); if (n.cols === 1) delete n.cols; }), 'Колонки'), { enabled: hasArea });
  C('tyAutoSizeOff', 'Вимкнути автовисоту фрейма', commit(() => forFrames(n => { ensureWidth(n); n.boxH = Math.max(O.text.lineHeight(n), O.text.layout(n).h); }), 'Текстовий фрейм'), { enabled: hasArea });
  // font & size submenus
  const FONT_MENU = ['Arial', 'Helvetica', 'Inter', 'Roboto', 'Open Sans', 'Montserrat', 'Georgia', 'Times New Roman', 'Playfair Display', 'Lora', 'Verdana', 'Courier New'];
  FONT_MENU.forEach(f => C('tyFont:' + f, f, () => { const g = O.fonts && O.fonts.get(f); TU.setChar({ font: g ? g.family : f }); O.history.commit('Шрифт'); }, { raw: true, group: 'Шрифт', enabled: hasText, check: () => { const c = TU.cur(); return !!c && c.st.font === f; } }));
  const SIZES = [6, 7, 8, 9, 10, 11, 12, 14, 18, 24, 30, 36, 48, 60, 72];
  SIZES.forEach(s => C('tySize:' + s, s + ' px', () => { TU.setChar({ size: s }); O.history.commit('Розмір шрифту'); }, { raw: true, group: 'Розмір', enabled: hasText, check: () => { const c = TU.cur(); return !!c && Math.abs(c.st.size - s) < 0.01; } }));
  C('tySizeOther', 'Інший…', () => { const c = TU.cur(); if (!c) return; ui.dialog({ title: 'Розмір шрифту', fields: [{ key: 's', label: 'Розмір, px', type: 'number', value: fmt(c.st.size) }], onOk: v => { if (v.s > 0) { TU.setChar({ size: Math.min(4000, v.s) }); O.history.commit('Розмір шрифту'); } } }); }, { group: 'Розмір', enabled: hasText });
  // bigger / smaller: the selected characters while editing
  const fontStep = d => { const c = TU.cur(); if (!c) return; const s = c.st.size; TU.setChar({ size: Math.max(1, Math.round(s + d * (s >= 48 ? 4 : s >= 16 ? 2 : 1))) }); O.history.commit('Розмір шрифту'); };
  C('fontBigger', 'Збільшити шрифт', () => fontStep(1), { keys: ['Ctrl+Shift+.'], enabled: hasText });
  C('fontSmaller', 'Зменшити шрифт', () => fontStep(-1), { keys: ['Ctrl+Shift+,'], enabled: hasText });

  // «Text» menu (InDesign order)
  const textMenu = O.MENUS.find(m => m[0] === 'Текст');
  const keepOld = textMenu ? textMenu[1].filter(x => typeof x === 'string' && ['googleFonts', 'uploadFont', 'localFonts'].includes(x)) : [];
  const TEXT_MENU = [
    sub('Шрифт', FONT_MENU.map(f => 'tyFont:' + f).concat(['-', 'tyFindFont'], keepOld.length ? ['-'].concat(keepOld) : [])),
    sub('Розмір', SIZES.map(s => 'tySize:' + s).concat(['-', 'tySizeOther', '-', 'fontBigger', 'fontSmaller'])),
    'tyRewrite', '-',
    'tyCharacter', 'tyParagraph', 'tyTabs', 'tyGlyphs', 'tyStory', '-',
    'tyCharStyles', 'tyParaStyles', '-',
    'createOutlines', 'tyFindFont', sub('Змінити регістр', ['chUpper', 'chLower', 'chTitle', 'chSentence']), '-',
    sub('Текст за контуром', ['textOnPath', 'tyPathOptions', 'releaseTextPath']), '-',
    sub('Примітки', ['tyNoteNew', 'tyNoteNext', 'tyNotePrev', '-', 'tyNoteToText', 'tyNotesDelAll', '-', 'tyNotesShow']),
    sub('Відслідковувати зміни', ['tyTrackStory', 'tyTrackAll', 'tyShowChanges', '-', 'tyAcceptStory', 'tyRejectStory', '-', 'tyAcceptDoc', 'tyRejectDoc']), '-',
    'tyInsertFootnote', 'tyFnOptions', 'tyInsertEndnote', 'tyEnOptions', 'tyConvertNotes', '-',
    sub('Гіперпосилання і перехресні посилання', ['tyLinkNew', 'tyLinkRemove', 'tyLinkOpen', 'tyLinksPanel', '-', 'tyXref', 'tyXrefUpdate']),
    sub('Текстові змінні', [sub('Вставити змінну', TS.BUILTIN_VARS.map((v, i) => 'tyVar:' + i).concat(['-', 'tyVarPick'])), 'tyVarsDefine']), '-',
    sub('Марковані та нумеровані списки', ['tyBullets', 'tyNumbers', 'tyListOff', '-', 'tyListToText', 'tyRestartNum', 'tyContinueNum', '-', 'tyListOptions']), '-',
    sub('Вставити спеціальний символ', INS.map(([g, list]) => sub(g, list.map(x => 'tyIns:' + x[0])))),
    sub('Вставити пробіл', SPACES.map(x => 'tyIns:' + x[0])),
    sub('Вставити символ розриву', BRKS.map(x => 'tyIns:' + x[0])),
    'tyPlaceholder', 'tyGenerate', '-',
    'tyHidden', '-',
    'tyFrameOptions', sub('Текстовий фрейм', ['tyColsMore', 'tyColsLess', 'tyAutoSizeOff', '-', 'tyStoryEditor']), sub('Стилі', ['tyNewPStyle', 'tyNewCStyle', 'tyRedefineStyle', 'tyClearOverrides'])
  ];
  if (textMenu) textMenu[1] = TEXT_MENU; else O.MENUS.splice(3, 0, ['Текст', TEXT_MENU]);

  // ======================================================================
  // RICH EDITING ON THE CANVAS
  // ======================================================================
  const ta = taEl();
  const localPt = (n, e) => { const s = V.local(e); return M.apply(M.inv(M.mul(V.m(), model.worldMatrix(n))), s); };
  let drag = null, goalX = null;
  const setSel = (a, b) => { const lo = Math.min(a, b), hi = Math.max(a, b); ta.setSelectionRange(lo, hi, b < a ? 'backward' : 'forward'); O.requestOverlay(); };
  const wordAt = (text, i) => { let a = i, b = i; const W = /[\p{L}\p{N}_\u00AD'’-]/u; while (a > 0 && W.test(text[a - 1])) a--; while (b < text.length && W.test(text[b])) b++; if (a === b && b < text.length) b++; return [a, b]; };
  ta.addEventListener('pointerdown', e => {
    if (!S.textEdit || !S.textEdit.rich || e.button !== 0) return;
    const n = editNode();
    if (!n) return;
    e.preventDefault();
    refocus();
    const idx = TS.hitIndex(n, localPt(n, e));
    goalX = null;
    if (e.detail >= 3) { const [ps, pe] = TS.paraRange(n.text || '', idx, idx); setSel(ps, pe); return; }
    if (e.detail === 2) { const [a, b] = wordAt(n.text || '', idx); setSel(a, b); return; }
    const anchor = e.shiftKey ? (ta.selectionDirection === 'backward' ? ta.selectionEnd : ta.selectionStart) : idx;
    setSel(anchor, idx);
    drag = { anchor, id: e.pointerId };
    try { ta.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
  });
  ta.addEventListener('pointermove', e => { if (!drag || !S.textEdit) return; const n = editNode(); if (!n) return; setSel(drag.anchor, TS.hitIndex(n, localPt(n, e))); });
  const endDrag = () => { drag = null; };
  ta.addEventListener('pointerup', endDrag);
  ta.addEventListener('pointercancel', endDrag);
  ta.addEventListener('mousedown', e => { if (S.textEdit && S.textEdit.rich) e.preventDefault(); });
  const keyName = e => (e.ctrlKey || e.metaKey ? 'Ctrl+' : '') + (e.altKey ? 'Alt+' : '') + (e.shiftKey ? 'Shift+' : '') + (e.key.length === 1 ? e.key.toUpperCase() : e.key);
  const EDIT_KEYS = {
    'Ctrl+B': () => { const c = TU.cur(); TU.setChar({ weight: c.st.weight >= 600 ? 400 : 700 }); return 'Жирний'; },
    'Ctrl+I': () => { const c = TU.cur(); TU.setChar({ italic: !c.st.italic }); return 'Курсив'; },
    'Ctrl+U': () => { const c = TU.cur(); TU.setChar({ under: !c.st.under }); return 'Підкреслення'; },
    'Ctrl+Shift+K': () => { const c = TU.cur(); TU.setChar({ tcase: c.st.tcase === 'upper' ? 'none' : 'upper' }); return 'Регістр'; },
    'Ctrl+Shift+H': () => { const c = TU.cur(); TU.setChar({ smcaps: !c.st.smcaps }); return 'Регістр'; },
    'Ctrl+Shift+=': () => { const c = TU.cur(); TU.setChar({ pos: c.st.pos === 'sup' ? 'normal' : 'sup' }); return 'Верхній індекс'; },
    'Ctrl+Shift++': () => { const c = TU.cur(); TU.setChar({ pos: c.st.pos === 'sup' ? 'normal' : 'sup' }); return 'Верхній індекс'; },
    'Ctrl+Alt+Shift+=': () => { const c = TU.cur(); TU.setChar({ pos: c.st.pos === 'sub' ? 'normal' : 'sub' }); return 'Нижній індекс'; },
    'Ctrl+Alt+Shift++': () => { const c = TU.cur(); TU.setChar({ pos: c.st.pos === 'sub' ? 'normal' : 'sub' }); return 'Нижній індекс'; },
    'Ctrl+Shift+L': () => { TU.setPara({ align: 'left' }); return 'Вирівнювання тексту'; },
    'Ctrl+Shift+C': () => { TU.setPara({ align: 'center' }); return 'Вирівнювання тексту'; },
    'Ctrl+Shift+R': () => { TU.setPara({ align: 'right' }); return 'Вирівнювання тексту'; },
    'Ctrl+Shift+J': () => { TU.setPara({ align: 'justify' }); return 'Вирівнювання тексту'; },
    'Ctrl+Shift+F': () => { TU.setPara({ align: 'justify-all' }); return 'Вирівнювання тексту'; }
  };
  ta.addEventListener('keydown', e => {
    if (!S.textEdit) return;
    const n = editNode();
    if (!n) return;
    const k = keyName(e);
    if (!n.path && EDIT_KEYS[k]) { e.preventDefault(); e.stopPropagation(); const label = EDIT_KEYS[k](); O.history.commit(label); return; }
    // forced line break (InDesign: Shift+Enter)
    if (k === 'Shift+Enter' && !n.path) { e.preventDefault(); TU.insert(CH.lineBreak, { label: 'Текст' }); return; }
    // text commands with shortcuts (Ctrl+T, Ctrl+Alt+I, F11…)
    for (const c of O.cmds.values()) if ((c.id.startsWith('ty') || c.id.startsWith('font')) && (c.keys || []).includes(k)) { e.preventDefault(); e.stopPropagation(); O.run(c.id); return; }
    if (!S.textEdit.rich) return;
    const dir = ta.selectionDirection === 'backward';
    const focus = dir ? ta.selectionStart : ta.selectionEnd, anchor = dir ? ta.selectionEnd : ta.selectionStart;
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault();
      const c = TS.caret(n, focus);
      if (goalX === null && c) goalX = c.x;
      const to = TS.lineMove(n, focus, e.key === 'ArrowUp' ? -1 : 1, goalX === null ? undefined : goalX);
      setSel(e.shiftKey ? anchor : to, to);
      return;
    }
    if ((e.key === 'Home' || e.key === 'End') && !e.ctrlKey && !e.metaKey) {
      e.preventDefault();
      const to = TS.lineEdge(n, focus, e.key === 'End');
      setSel(e.shiftKey ? anchor : to, to);
      goalX = null;
      return;
    }
    goalX = null;
  });
  // caret / selection tracking
  let selTimer = 0;
  document.addEventListener('selectionchange', () => {
    if (!S.textEdit || document.activeElement !== ta) return;
    lastCaret = { id: S.textEdit.id, a: Math.min(ta.selectionStart, ta.selectionEnd), b: Math.max(ta.selectionStart, ta.selectionEnd) };
    if (S.textEdit.pending && (ta.selectionStart !== ta.selectionEnd || ta.selectionStart !== S.textEdit.pendingAt)) delete S.textEdit.pending;
    if (S.textEdit.rich) O.requestOverlay();
    clearTimeout(selTimer);
    selTimer = setTimeout(() => { if (S.textEdit && document.activeElement === ta) O.panels.refresh(); }, 160);
  });
  ta.addEventListener('input', () => {
    if (!S.textEdit) return;
    if (S.textEdit.pending) S.textEdit.pendingAt = ta.selectionStart;
    if (S.textEdit.rich) O.requestOverlay();
  });
  // caret, selection, notes and text frame columns on the overlay
  const poly = (W, x, y, w, h) => [[x, y], [x + w, y], [x + w, y + h], [x, y + h]].map(([a, b]) => M.apply(W, { x: a, y: b })).map(p => O.n(p.x) + ',' + O.n(p.y)).join(' ');
  O.overlayHooks.push(Vm => {
    if (!S.doc) return '';
    let s = '';
    const pg = model.page();
    // editorial notes: small flags at their anchors
    if (S.settings.showNotes !== false) {
      model.walk(pg.children, n => {
        if (n.visible === false) return false;
        if (n.type !== 'text' || n.path || (n.text || '').indexOf(CH.note) < 0) return;
        const W = M.mul(Vm, model.worldMatrix(n));
        const text = n.text;
        let k = 0;
        for (let i = 0; i < text.length; i++) {
          if (text[i] !== CH.note) continue;
          const c = TS.caret(n, i);
          const note = (n.notes || [])[k++] || {};
          if (!c) continue;
          const p = M.apply(W, { x: c.x, y: c.y });
          s += `<g pointer-events="none"><path d="M${O.n(p.x)} ${O.n(p.y)}v-9l7 3-7 3" fill="#FFC53D" stroke="#B07D00" stroke-width="0.8"/><title>${esc(note.text || '')}</title></g>`;
        }
      });
    }
    if (!S.textEdit || !S.textEdit.rich) return s;
    const n = editNode();
    if (!n || model.pageOf(n) !== pg) return s;
    const W = M.mul(Vm, model.worldMatrix(n));
    const L = O.text.layout(n);
    // frame and column outlines
    s += `<polygon points="${poly(W, 0, 0, L.w, n.boxH || L.h)}" fill="none" stroke="var(--acc, #0D99FF)" stroke-width="1" stroke-dasharray="3 2" pointer-events="none"/>`;
    if (L.cols > 1) for (let c = 0; c < L.cols; c++) s += `<polygon points="${poly(W, L.inset[3] + c * (L.colW + L.gap), L.inset[0], L.colW, (n.boxH || L.h) - L.inset[0] - L.inset[2])}" fill="none" stroke="#9747FF" stroke-opacity=".6" stroke-width="1" pointer-events="none"/>`;
    const a = Math.min(ta.selectionStart, ta.selectionEnd), b = Math.max(ta.selectionStart, ta.selectionEnd);
    if (b > a) for (const r of TS.rangeRects(n, a, b)) s += `<polygon points="${poly(W, r.x, r.y, r.w, r.h)}" fill="#0D99FF" fill-opacity=".28" pointer-events="none"/>`;
    else if (document.activeElement === ta) {
      const c = TS.caret(n, a);
      if (c) { const p = M.apply(W, { x: c.x, y: c.y }), q = M.apply(W, { x: c.x, y: c.y + c.h }); s += `<line class="ty-caret" x1="${O.n(p.x)}" y1="${O.n(p.y)}" x2="${O.n(q.x)}" y2="${O.n(q.y)}" stroke="#0D99FF" stroke-width="1.5" pointer-events="none"/>`; }
    }
    return s;
  });
  O.on('lang', () => O.panels.refresh(true, true));
})();
