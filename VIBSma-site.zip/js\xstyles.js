'use strict';
/* VIBSma — 10 000 more design styles for the template gallery: 50 new aesthetics × 10 moods = 500 base styles,
   each in 20 colourways. An aesthetic brings the look (a motif and variant of the gallery's generator, chosen by
   mood), the fonts and a description; a mood sets lightness, contrast and saturation; a colourway sets the hue.
   Palettes are computed, then checked for contrast. Names are composed from translated parts, so every style has
   its name in each interface language. */
(function () {
  const O = window.O, GL = O.gallery;
  if (!GL || !GL.addStyles) return;

  // [key, group, looks «motif:variant» (by mood), font pairs [heading, text] (by mood), hue of accent 2 against
  //  accent 1, name [uk, en, ru, de], description [uk, en, ru, de]]
  const AE = [
    // ---- historical ----
    ['noirdeco', 'hist', ['deco:fan', 'deco:stream', 'ornate:thin'], [['Poiret One', 'Raleway'], ['Playfair Display SC', 'Montserrat']], 40,
      ['Нуар-деко', 'Noir deco', 'Нуар-деко', 'Noir-Deco'],
      ['Ар-деко нічного міста: чорний лак, латунь і прожектори.', 'Night-city art deco: black lacquer, brass and spotlights.', 'Ар-деко ночного города: чёрный лак, латунь и прожекторы.', 'Art déco der Großstadtnacht: schwarzer Lack, Messing und Scheinwerfer.']],
    ['belleepoque', 'hist', ['nouveau:vine', 'ornate:frame', 'nouveau:floral'], [['Cormorant SC', 'Lora'], ['Prata', 'Alice']], 150,
      ['Бель епок', 'Belle Époque', 'Бель эпок', 'Belle Époque'],
      ['Паризька елегантність 1900-х: афіші, звиви й позолота.', 'Parisian elegance of the 1900s: posters, curls and gilding.', 'Парижская элегантность 1900-х: афиши, завитки и позолота.', 'Pariser Eleganz um 1900: Plakate, Schnörkel und Vergoldung.']],
    ['secession', 'hist', ['pattern:mosaic', 'deco:fan', 'nouveau:vine'], [['Forum', 'Raleway'], ['Poiret One', 'Lora']], 45,
      ['Віденська сецесія', 'Vienna Secession', 'Венский сецессион', 'Wiener Secession'],
      ['Квадрати, золоті орнаменти й строга геометрія Клімта.', 'Squares, golden ornament and Klimt’s strict geometry.', 'Квадраты, золотой орнамент и строгая геометрия Климта.', 'Quadrate, Goldornamente und Klimts strenge Geometrie.']],
    ['georgian', 'hist', ['ornate:light', 'ornate:frame'], [['Playfair Display', 'PT Serif'], ['Prata', 'Lora']], 200,
      ['Георгіанський', 'Georgian', 'Георгианский', 'Georgianisch'],
      ['Симетричні фасади, світлі кольори й тонкий класичний декор.', 'Symmetrical facades, light colours and fine classical detail.', 'Симметричные фасады, светлые цвета и тонкий классический декор.', 'Symmetrische Fassaden, helle Farben und feines klassisches Dekor.']],
    ['tudor', 'hist', ['ornate:medieval', 'pattern:plaid'], [['Ruslan Display', 'Old Standard TT'], ['Alegreya SC', 'Alegreya']], 160,
      ['Тюдорівський', 'Tudor', 'Тюдоровский', 'Tudor'],
      ['Фахверк, геральдика, темне дерево й тартан.', 'Half-timbering, heraldry, dark oak and tartan.', 'Фахверк, геральдика, тёмное дерево и тартан.', 'Fachwerk, Heraldik, dunkle Eiche und Tartan.']],
    ['romanesque', 'hist', ['ornate:arch', 'pattern:mosaic'], [['Alegreya SC', 'Alegreya'], ['Ruslan Display', 'EB Garamond']], 30,
      ['Романський', 'Romanesque', 'Романский', 'Romanisch'],
      ['Масивні арки, мозаїка й камінь ранніх соборів.', 'Massive arches, mosaic and the stone of early cathedrals.', 'Массивные арки, мозаика и камень ранних соборов.', 'Massive Bögen, Mosaik und der Stein früher Dome.']],
    ['hellenistic', 'hist', ['ornate:meander', 'organic:stone'], [['Forum', 'Alice'], ['Cormorant SC', 'Spectral']], 180,
      ['Елліністичний', 'Hellenistic', 'Эллинистический', 'Hellenistisch'],
      ['Мармур, меандр, оливки й сонце Егейського моря.', 'Marble, meander, olives and Aegean sun.', 'Мрамор, меандр, оливки и солнце Эгейского моря.', 'Marmor, Mäander, Oliven und ägäische Sonne.']],
    ['cossackbaroque', 'hist', ['ornate:baroque', 'nouveau:petryk', 'ornate:empire'], [['Yeseva One', 'PT Serif'], ['Prata', 'Lora']], 50,
      ['Козацьке бароко', 'Cossack Baroque', 'Казацкое барокко', 'Kosakenbarock'],
      ['Українське бароко: грушоподібні бані, золото й пишні рослинні орнаменти.', 'Ukrainian baroque: pear-shaped domes, gold and lush plant ornament.', 'Украинское барокко: грушевидные купола, золото и пышный растительный орнамент.', 'Ukrainischer Barock: birnenförmige Kuppeln, Gold und üppige Pflanzenornamente.']],
    ['trypillia', 'hist', ['pattern:koru', 'organic:waves', 'pattern:zigzag'], [['Philosopher', 'PT Sans'], ['Kurale', 'PT Serif']], 20,
      ['Трипільський', 'Trypillian', 'Трипольский', 'Trypillja'],
      ['Спіралі й хвилі давньої кераміки: охра, теракота й чорне.', 'Spirals and waves of ancient pottery: ochre, terracotta and black.', 'Спирали и волны древней керамики: охра, терракота и чёрный.', 'Spiralen und Wellen alter Keramik: Ocker, Terrakotta und Schwarz.']],
    ['ukrmodern', 'hist', ['ornate:arch', 'nouveau:vine', 'pattern:zellige'], [['Forum', 'Lora'], ['Oranienbaum', 'PT Serif']], 140,
      ['Український модерн', 'Ukrainian Art Nouveau', 'Украинский модерн', 'Ukrainischer Jugendstil'],
      ['Модерн Кричевського: трапецієподібні арки, кахлі й народні мотиви.', 'Krychevsky’s modern: trapezoid arches, tiles and folk motifs.', 'Модерн Кричевского: трапециевидные арки, изразцы и народные мотивы.', 'Krytschewskyjs Moderne: Trapezbögen, Kacheln und Volksmotive.']],
    ['boychuk', 'hist', ['organic:sun', 'geo:flat', 'ornate:arch'], [['Ruslan Display', 'PT Serif'], ['Kelly Slab', 'Alegreya']], 200,
      ['Бойчукізм', 'Boychukism', 'Бойчукизм', 'Boitschukismus'],
      ['Монументальний розпис: площинні фігури, іконні кольори й ритм.', 'Monumental murals: flat figures, icon colours and rhythm.', 'Монументальная роспись: плоскостные фигуры, иконные цвета и ритм.', 'Monumentale Wandmalerei: flächige Figuren, Ikonenfarben und Rhythmus.']],
    ['suprematism', 'hist', ['geo:construct', 'geo:mondrian', 'geo:bauhaus'], [['Russo One', 'Roboto Condensed'], ['Dela Gothic One', 'Inter']], 180,
      ['Супрематизм', 'Suprematism', 'Супрематизм', 'Suprematismus'],
      ['Чисті фігури Малевича в білому просторі: квадрат, хрест і коло.', 'Malevich’s pure forms in white space: square, cross and circle.', 'Чистые фигуры Малевича в белом пространстве: квадрат, крест и круг.', 'Malewitschs reine Formen im weißen Raum: Quadrat, Kreuz und Kreis.']],
    ['opart', 'hist', ['pattern:stripes', 'pattern:dots', 'geo:speed'], [['Rubik Mono One', 'Inter'], ['Unbounded', 'Manrope']], 180,
      ['Оп-арт', 'Op art', 'Оп-арт', 'Op-Art'],
      ['Оптичні ілюзії: смуги, кола й ритм, що рухається на місці.', 'Optical illusions: stripes, circles and rhythm that moves in place.', 'Оптические иллюзии: полосы, круги и ритм, движущийся на месте.', 'Optische Täuschungen: Streifen, Kreise und Rhythmus, der sich bewegt.']],
    ['atomic', 'hist', ['retro:mid', 'retro:space'], [['Comfortaa', 'Nunito'], ['Montserrat Alternates', 'Nunito']], 170,
      ['Атомна доба', 'Atomic age', 'Атомная эпоха', 'Atomzeitalter'],
      ['Атоми, бумеранги й зірочки 1950-х: віра в майбутнє.', 'Atoms, boomerangs and starbursts of the 1950s: faith in the future.', 'Атомы, бумеранги и звёздочки 1950-х: вера в будущее.', 'Atome, Bumerangs und Sterne der 1950er: Glaube an die Zukunft.']],
    ['tiki', 'hist', ['organic:leaves', 'retro:sun'], [['Pacifico', 'Nunito'], ['Lobster', 'Rubik']], 150,
      ['Тікі', 'Tiki', 'Тики', 'Tiki'],
      ['Полінезійський бар 50-х: бамбук, пальми й захід сонця.', 'A 1950s Polynesian bar: bamboo, palms and sunset.', 'Полинезийский бар 50-х: бамбук, пальмы и закат.', 'Polynesische Bar der 50er: Bambus, Palmen und Sonnenuntergang.']],
    ['disco', 'hist', ['retro:sun', 'collage:kitsch', 'neon:vapor'], [['Lobster', 'Montserrat'], ['Marmelad', 'Comfortaa']], 300,
      ['Диско', 'Disco', 'Диско', 'Disco'],
      ['Дзеркальна куля, блиск і хвилі 70-х на танцполі.', 'Mirror ball, sparkle and 1970s waves on the dance floor.', 'Зеркальный шар, блеск и волны 70-х на танцполе.', 'Discokugel, Glitzer und 70er-Wellen auf der Tanzfläche.']],
    ['arcade', 'hist', ['pixel:pixel', 'neon:synth'], [['Press Start 2P', 'Roboto Mono'], ['Russo One', 'JetBrains Mono']], 160,
      ['Аркада 80-х', '80s arcade', 'Аркада 80-х', '80er-Arcade'],
      ['Ігрові автомати: пікселі, неонова сітка й рекорди.', 'Arcade cabinets: pixels, neon grid and high scores.', 'Игровые автоматы: пиксели, неоновая сетка и рекорды.', 'Spielautomaten: Pixel, Neongitter und Highscores.']],
    ['rave', 'hist', ['neon:cyber', 'collage:punk'], [['Unbounded', 'Roboto Mono'], ['Rubik Glitch', 'Jura']], 120,
      ['Рейв 90-х', '90s rave', 'Рейв 90-х', '90er-Rave'],
      ['Флаєри рейвів: кислотні кольори, глітч і смайлики.', 'Rave flyers: acid colours, glitch and smileys.', 'Флаеры рейвов: кислотные цвета, глитч и смайлики.', 'Rave-Flyer: Acid-Farben, Glitch und Smileys.']],
    // ---- modern ----
    ['frutiger', 'modern', ['glass:y2k', 'glass:aurora', 'glass:light'], [['Nunito', 'Nunito Sans'], ['Comfortaa', 'Manrope']], 120,
      ['Фрутіґер-аеро', 'Frutiger Aero', 'Фрутигер-аэро', 'Frutiger Aero'],
      ['Глянцеві бульбашки, небо, вода й скло 2000-х.', 'Glossy bubbles, sky, water and 2000s glass.', 'Глянцевые пузыри, небо, вода и стекло 2000-х.', 'Glänzende Blasen, Himmel, Wasser und Glas der 2000er.']],
    ['chrome', 'modern', ['glass:y2k', 'glass:grad'], [['Unbounded', 'Manrope'], ['Geologica', 'Inter']], 200,
      ['Рідкий хром', 'Liquid chrome', 'Жидкий хром', 'Flüssiges Chrom'],
      ['Металеві відблиски, плавні форми й холодне сяйво.', 'Metallic gleam, fluid shapes and a cool glow.', 'Металлические блики, плавные формы и холодное сияние.', 'Metallischer Glanz, fließende Formen und kühles Leuchten.']],
    ['bento', 'modern', ['cards:material', 'swiss:corp'], [['Onest', 'Inter'], ['Geologica', 'Golos Text']], 160,
      ['Бенто-сітка', 'Bento grid', 'Бенто-сетка', 'Bento-Raster'],
      ['Картки різного розміру в акуратній сітці, як на сайтах продуктів.', 'Cards of different sizes in a tidy grid, like product sites.', 'Карточки разного размера в аккуратной сетке, как на сайтах продуктов.', 'Karten verschiedener Größe in einem ordentlichen Raster wie auf Produktseiten.']],
    ['darkglass', 'modern', ['glass:glass', 'glass:aurora'], [['Inter Tight', 'Inter'], ['Wix Madefor Display', 'Manrope']], 90,
      ['Темне скло', 'Dark glass', 'Тёмное стекло', 'Dunkles Glas'],
      ['Напівпрозорі панелі над сяйвом у темряві.', 'Translucent panels over a glow in the dark.', 'Полупрозрачные панели над сиянием в темноте.', 'Durchscheinende Flächen über einem Leuchten im Dunkeln.']],
    ['quietlux', 'modern', ['minimal:lux', 'editorial:light'], [['Tenor Sans', 'Cormorant Garamond'], ['Cormorant Garamond', 'Manrope']], 30,
      ['Тиха розкіш', 'Quiet luxury', 'Тихая роскошь', 'Stiller Luxus'],
      ['Без логотипів: кашемірові тони, простір і бездоганна типографіка.', 'No logos: cashmere tones, space and flawless type.', 'Без логотипов: кашемировые тона, простор и безупречная типографика.', 'Ohne Logos: Kaschmirtöne, Weite und makellose Typografie.']],
    ['softmin', 'modern', ['minimal:light', 'soft:pastel'], [['Manrope', 'Manrope'], ['Nunito', 'Nunito Sans']], 40,
      ['М’який мінімалізм', 'Soft minimalism', 'Мягкий минимализм', 'Sanfter Minimalismus'],
      ['Округлі форми, теплий світлий фон і спокій.', 'Rounded shapes, a warm light background and calm.', 'Округлые формы, тёплый светлый фон и спокойствие.', 'Runde Formen, warmer heller Grund und Ruhe.']],
    ['acid', 'modern', ['neon:cyber', 'type:type', 'tech:circuit'], [['Tektur', 'Jura'], ['Unbounded', 'JetBrains Mono']], 110,
      ['Кислотна графіка', 'Acid graphics', 'Кислотная графика', 'Acid-Grafik'],
      ['Технічні шрифти, сітки, лазерні кольори й хаос.', 'Techno type, grids, laser colours and chaos.', 'Технические шрифты, сетки, лазерные цвета и хаос.', 'Technoschriften, Raster, Laserfarben und Chaos.']],
    ['neogrotesk', 'modern', ['swiss:swiss', 'type:type'], [['Inter Tight', 'Inter'], ['Sofia Sans Condensed', 'Sofia Sans']], 0,
      ['Новий гротеск', 'New grotesque', 'Новый гротеск', 'Neue Grotesk'],
      ['Великий гротеск, сувора сітка й один яскравий акцент.', 'Big grotesque type, a strict grid and one bright accent.', 'Крупный гротеск, строгая сетка и один яркий акцент.', 'Große Grotesk, strenges Raster und ein heller Akzent.']],
    ['blueprint', 'modern', ['tech:circuit', 'line:line', 'tech:iso'], [['JetBrains Mono', 'Roboto Mono'], ['IBM Plex Mono', 'Inter']], 180,
      ['Креслення', 'Blueprint', 'Чертёж', 'Blaupause'],
      ['Інженерні лінії, сітка й моноширинні підписи.', 'Engineering lines, a grid and monospaced labels.', 'Инженерные линии, сетка и моноширинные подписи.', 'Technische Linien, Raster und Monospace-Beschriftung.']],
    ['infographic', 'modern', ['swiss:corp', 'tech:iso', 'cards:material'], [['Golos Text', 'Golos Text'], ['Commissioner', 'Inter']], 150,
      ['Інфографічний', 'Infographic', 'Инфографический', 'Infografik'],
      ['Дані як прикраса: діаграми, піктограми й чіткі кольори.', 'Data as decoration: charts, icons and clear colours.', 'Данные как украшение: диаграммы, пиктограммы и чёткие цвета.', 'Daten als Schmuck: Diagramme, Piktogramme und klare Farben.']],
    ['biotech', 'modern', ['organic:blob', 'tech:circuit'], [['Exo 2', 'Manrope'], ['Geologica', 'Onest']], 140,
      ['Біотех', 'Biotech', 'Биотех', 'Biotech'],
      ['Органічні клітини зустрічають цифрові схеми.', 'Organic cells meet digital circuits.', 'Органические клетки встречают цифровые схемы.', 'Organische Zellen treffen digitale Schaltkreise.']],
    ['riso', 'modern', ['duotone:duo', 'pattern:dots'], [['Rubik Mono One', 'Rubik'], ['Dela Gothic One', 'IBM Plex Mono']], 180,
      ['Різографія', 'Risograph', 'Ризография', 'Risografie'],
      ['Друк у дві фарби: зсув кольорів, растр і зерно.', 'Two-ink printing: misregistration, halftone and grain.', 'Печать в две краски: сдвиг цветов, растр и зерно.', 'Zweifarbdruck: Passerversatz, Raster und Korn.']],
    ['zine', 'modern', ['collage:dada', 'collage:punk', 'collage:grunge'], [['Oswald', 'Roboto Mono'], ['Rubik Spray Paint', 'IBM Plex Mono']], 200,
      ['Зін-колаж', 'Zine collage', 'Зин-коллаж', 'Zine-Collage'],
      ['Ксерокопії, вирізки, скотч і рукописні нотатки.', 'Photocopies, cut-outs, tape and handwritten notes.', 'Ксерокопии, вырезки, скотч и рукописные заметки.', 'Fotokopien, Ausschnitte, Klebeband und Handnotizen.']],
    ['webcore', 'modern', ['brutal:raw', 'cards:material', 'pixel:pixel'], [['IBM Plex Mono', 'Roboto Mono'], ['Press Start 2P', 'JetBrains Mono']], 180,
      ['Вебкор', 'Webcore', 'Вебкор', 'Webcore'],
      ['Ранній інтернет: віконця, кнопки, пікселі й моноширинний текст.', 'The early internet: windows, buttons, pixels and monospaced text.', 'Ранний интернет: окошки, кнопки, пиксели и моноширинный текст.', 'Das frühe Internet: Fenster, Buttons, Pixel und Monospace-Text.']],
    ['playful', 'modern', ['soft:clay', 'geo:flat', 'soft:pastel'], [['Comfortaa', 'Nunito'], ['Pangolin', 'Rubik']], 160,
      ['Грайливий', 'Playful', 'Игривый', 'Verspielt'],
      ['Пухкі форми, яскраві кольори й дитяча радість.', 'Chubby shapes, bright colours and childlike joy.', 'Пухлые формы, яркие цвета и детская радость.', 'Pummelige Formen, kräftige Farben und kindliche Freude.']],
    ['concrete', 'modern', ['industrial:soft', 'brutal:raw', 'industrial:brick'], [['Oswald', 'Inter'], ['Sofia Sans Condensed', 'Roboto']], 0,
      ['Бетонний мінімалізм', 'Concrete minimalism', 'Бетонный минимализм', 'Beton-Minimalismus'],
      ['Сірий бетон, точні лінії й архітектурна тиша.', 'Grey concrete, precise lines and architectural silence.', 'Серый бетон, точные линии и архитектурная тишина.', 'Grauer Beton, präzise Linien und architektonische Stille.']],
    // ---- ethnic ----
    ['hutsul', 'ethnic', ['pattern:kilim', 'pattern:stitch', 'pattern:zigzag'], [['Yeseva One', 'PT Serif'], ['Kelly Slab', 'Alegreya']], 160,
      ['Гуцульський', 'Hutsul', 'Гуцульский', 'Huzulisch'],
      ['Карпатські ліжники, різьблення й геометрія вишивки.', 'Carpathian wool blankets, woodcarving and embroidery geometry.', 'Карпатские лижники, резьба и геометрия вышивки.', 'Karpaten-Wolldecken, Holzschnitzerei und Stickgeometrie.']],
    ['whiteonwhite', 'ethnic', ['pattern:stitch', 'ornate:thin'], [['Cormorant SC', 'Lora'], ['Ysabeau', 'Spectral']], 30,
      ['Біле по білому', 'White on white', 'Белым по белому', 'Weiß auf Weiß'],
      ['Решетилівська вишивка: тонкий візерунок білим по льону.', 'Reshetylivka embroidery: fine white stitching on linen.', 'Решетиловская вышивка: тонкий узор белым по льну.', 'Reschetyliwka-Stickerei: feines Weiß auf Leinen.']],
    ['kosiv', 'ethnic', ['nouveau:floral', 'organic:leaves', 'nouveau:petryk'], [['Marck Script', 'Lora'], ['Bad Script', 'PT Serif']], 60,
      ['Косівська кераміка', 'Kosiv ceramics', 'Косовская керамика', 'Kossiw-Keramik'],
      ['Мальовані квіти й птахи на теплій глині, зелене й жовте.', 'Painted flowers and birds on warm clay, green and yellow.', 'Расписные цветы и птицы на тёплой глине, зелёный и жёлтый.', 'Bemalte Blumen und Vögel auf warmem Ton, Grün und Gelb.']],
    ['ukiyoe', 'ethnic', ['japanese:sun', 'organic:waves', 'japanese:moon'], [['Spectral', 'Manrope'], ['Literata', 'Onest']], 180,
      ['Укійо-е', 'Ukiyo-e', 'Укиё-э', 'Ukiyo-e'],
      ['Японська гравюра: хвилі, гора Фудзі й плоскі кольори.', 'Japanese woodblock: waves, Mount Fuji and flat colour.', 'Японская гравюра: волны, гора Фудзи и плоские цвета.', 'Japanischer Holzschnitt: Wellen, Fuji und flache Farben.']],
    ['persian', 'ethnic', ['pattern:mandala', 'pattern:zellige', 'ornate:arch'], [['Prata', 'Alice'], ['El Messiri', 'Lora']], 160,
      ['Перський', 'Persian', 'Персидский', 'Persisch'],
      ['Килими, мініатюри, бірюза й кобальт із золотом.', 'Carpets, miniatures, turquoise and cobalt with gold.', 'Ковры, миниатюры, бирюза и кобальт с золотом.', 'Teppiche, Miniaturen, Türkis und Kobalt mit Gold.']],
    ['andalusian', 'ethnic', ['pattern:zellige', 'ornate:arch'], [['Forum', 'Alice'], ['El Messiri', 'PT Serif']], 190,
      ['Андалузький', 'Andalusian', 'Андалузский', 'Andalusisch'],
      ['Патіо, плитка азулежу, підковоподібні арки й апельсинові дерева.', 'Patios, azulejo tiles, horseshoe arches and orange trees.', 'Патио, плитка азулежу, подковообразные арки и апельсиновые деревья.', 'Patios, Azulejo-Fliesen, Hufeisenbögen und Orangenbäume.']],
    ['andean', 'ethnic', ['pattern:zigzag', 'pattern:kilim', 'pattern:stripes'], [['Russo One', 'PT Sans'], ['Dela Gothic One', 'Ubuntu']], 140,
      ['Андський текстиль', 'Andean textile', 'Андский текстиль', 'Anden-Textil'],
      ['Смугасті тканини Перу: ромби, лами й сміливі кольори.', 'Striped Peruvian weaving: diamonds, llamas and bold colour.', 'Полосатые ткани Перу: ромбы, ламы и смелые цвета.', 'Gestreifte Webkunst aus Peru: Rauten, Lamas und kräftige Farben.']],
    ['cycladic', 'ethnic', ['organic:arch', 'pattern:stripes', 'ornate:arch'], [['Forum', 'Manrope'], ['Literata', 'Nunito Sans']], 30,
      ['Кікладський', 'Cycladic', 'Кикладский', 'Kykladisch'],
      ['Білі будиночки, сині двері й морське світло.', 'White houses, blue doors and sea light.', 'Белые домики, синие двери и морской свет.', 'Weiße Häuser, blaue Türen und Meereslicht.']],
    ['otomi', 'ethnic', ['nouveau:floral', 'pattern:fiesta'], [['Lobster', 'Rubik'], ['Kurale', 'Nunito']], 180,
      ['Отомі', 'Otomi', 'Отоми', 'Otomí'],
      ['Мексиканська вишивка: звірі й квіти одним кольором на білому.', 'Mexican embroidery: animals and flowers in one colour on white.', 'Мексиканская вышивка: звери и цветы одним цветом на белом.', 'Mexikanische Stickerei: Tiere und Blumen einfarbig auf Weiß.']],
    // ---- mixed ----
    ['witchcore', 'mixed', ['japanese:moon', 'editorial:dark', 'nouveau:vine'], [['Cormorant SC', 'EB Garamond'], ['Oranienbaum', 'Alegreya']], 50,
      ['Відьмакор', 'Witchcore', 'Ведьмакор', 'Witchcore'],
      ['Місяць, трави, свічки й старі гримуари.', 'Moon, herbs, candles and old grimoires.', 'Луна, травы, свечи и старые гримуары.', 'Mond, Kräuter, Kerzen und alte Grimoires.']],
    ['fairycore', 'mixed', ['nouveau:floral', 'soft:pastel', 'organic:leaves'], [['Bad Script', 'Lora'], ['Marck Script', 'Ysabeau']], 300,
      ['Феєкор', 'Fairycore', 'Феекор', 'Fairycore'],
      ['Квіти, роса, крильця й м’яке світло казкового лісу.', 'Flowers, dew, wings and the soft light of an enchanted wood.', 'Цветы, роса, крылышки и мягкий свет сказочного леса.', 'Blumen, Tau, Flügel und das sanfte Licht eines Zauberwalds.']],
    ['goblincore', 'mixed', ['organic:stone', 'organic:leaves', 'organic:blob'], [['Amatic SC', 'Nunito'], ['Neucha', 'PT Sans']], 90,
      ['Ґоблінкор', 'Goblincore', 'Гоблинкор', 'Goblincore'],
      ['Гриби, мох, камінці й затишний лісовий безлад.', 'Mushrooms, moss, pebbles and the cosy mess of the forest.', 'Грибы, мох, камушки и уютный лесной беспорядок.', 'Pilze, Moos, Kiesel und gemütliche Waldunordnung.']],
    ['lightacademia', 'mixed', ['editorial:light', 'ornate:thin', 'ornate:meander'], [['Old Standard TT', 'EB Garamond'], ['Literata', 'Spectral']], 30,
      ['Світла академія', 'Light academia', 'Светлая академия', 'Light Academia'],
      ['Поезія, мармур, лляні сорочки й сонячні бібліотеки.', 'Poetry, marble, linen shirts and sunny libraries.', 'Поэзия, мрамор, льняные рубашки и солнечные библиотеки.', 'Poesie, Marmor, Leinenhemden und sonnige Bibliotheken.']],
    ['spacecore', 'mixed', ['retro:space', 'neon:afro', 'neon:synth'], [['Russo One', 'Exo 2'], ['Unbounded', 'Jura']], 60,
      ['Космокор', 'Spacecore', 'Космокор', 'Spacecore'],
      ['Туманності, планети, ракети й зоряний пил.', 'Nebulae, planets, rockets and stardust.', 'Туманности, планеты, ракеты и звёздная пыль.', 'Nebel, Planeten, Raketen und Sternenstaub.']],
    ['cinematic', 'mixed', ['editorial:dark', 'minimal:dark', 'type:type'], [['Oswald', 'Inter'], ['Sofia Sans Condensed', 'Inter']], 30,
      ['Кінематографічний', 'Cinematic', 'Кинематографичный', 'Filmisch'],
      ['Широкий кадр, темрява, титри й одне яскраве світло.', 'Wide frame, darkness, titles and one bright light.', 'Широкий кадр, темнота, титры и один яркий свет.', 'Breites Bild, Dunkelheit, Titel und ein helles Licht.']],
    ['parisiancafe', 'mixed', ['pattern:stripes', 'ornate:light', 'editorial:light'], [['Marck Script', 'PT Serif'], ['Lobster', 'Lora']], 150,
      ['Паризьке кафе', 'Parisian café', 'Парижское кафе', 'Pariser Café'],
      ['Смугасті маркізи, крейдяне меню й кава на розі.', 'Striped awnings, a chalk menu and coffee on the corner.', 'Полосатые маркизы, меловое меню и кофе на углу.', 'Gestreifte Markisen, Kreidemenü und Kaffee an der Ecke.']]
  ];

  // colours from hue (degrees), saturation and lightness (0…1)
  const H = (h, s, l) => O.color.hex(O.color.fromHsl({ h: ((h % 360) + 360) % 360, s: O.clamp(s, 0, 1), l: O.clamp(l, 0, 1) }));
  // [key, name [uk, en, ru, de], palette (h: hue of the colourway, k: its saturation, o: hue of accent 2) → [bg, surface, ink, accent, accent 2]]
  const MOODS = [
    ['light', ['Світлий', 'Light', 'Светлый', 'Hell'], (h, k, o) => [H(h, 0.25 * k, 0.97), H(h, 0.22 * k, 0.91), H(h, 0.25 * k, 0.13), H(h, 0.72 * k, 0.48), H(h + o, 0.55 * k, 0.42)]],
    ['dark', ['Темний', 'Dark', 'Тёмный', 'Dunkel'], (h, k, o) => [H(h, 0.22 * k, 0.09), H(h, 0.2 * k, 0.15), H(h, 0.12 * k, 0.94), H(h, 0.78 * k, 0.62), H(h + o, 0.6 * k, 0.58)]],
    ['pastel', ['Пастельний', 'Pastel', 'Пастельный', 'Pastell'], (h, k, o) => [H(h, 0.6 * k, 0.94), H(h + 20, 0.5 * k, 0.87), H(h, 0.25 * k, 0.25), H(h, 0.55 * k, 0.7), H(h + o, 0.55 * k, 0.78)]],
    ['vivid', ['Яскравий', 'Vivid', 'Яркий', 'Lebendig'], (h, k, o) => [H(h, 0.78 * k, 0.47), H(h, 0.72 * k, 0.4), '#FFFFFF', H(h + o, 0.9 * k, 0.6), H(h + o + 40, 0.85 * k, 0.55)]],
    ['muted', ['Приглушений', 'Muted', 'Приглушённый', 'Gedämpft'], (h, k, o) => [H(h, 0.16 * k, 0.88), H(h, 0.14 * k, 0.8), H(h, 0.2 * k, 0.18), H(h, 0.34 * k, 0.44), H(h + o, 0.24 * k, 0.55)]],
    ['contrast', ['Контрастний', 'High contrast', 'Контрастный', 'Kontrastreich'], (h, k) => [H(h, 0, 0.99), H(h, 0, 0.93), '#0B0B0B', H(h, 0.92 * k, 0.5), '#0B0B0B']],
    ['warm', ['Теплий', 'Warm', 'Теплый', 'Warm'], (h, k, o) => [H(38, 0.45, 0.93), H(32, 0.4, 0.85), H(20, 0.35, 0.15), H(h, 0.68 * k, 0.5), H(h + o, 0.5 * k, 0.4)]],
    ['cool', ['Холодний', 'Cold', 'Холодный', 'Kalt'], (h, k, o) => [H(212, 0.3, 0.96), H(212, 0.25, 0.89), H(220, 0.45, 0.14), H(h, 0.68 * k, 0.5), H(h + o, 0.5 * k, 0.45)]],
    ['neon', ['Неоновий', 'Neon', 'Неоновый', 'Neon'], (h, k, o) => [H(248, 0.5, 0.08), H(252, 0.42, 0.16), H(h, 0.2, 0.96), H(h, k, 0.6), H(h + o, k, 0.62)]],
    ['vintage', ['Вінтажний', 'Vintage', 'Винтажный', 'Vintage'], (h, k, o) => [H(40, 0.42, 0.87), H(36, 0.36, 0.77), H(24, 0.32, 0.2), H(h, 0.42 * k, 0.42), H(h + o, 0.36 * k, 0.38)]]
  ];
  // [key, hue, saturation factor, name [uk, en, ru, de]]
  const COLS = [
    ['coral', 8, 1, ['Кораловий', 'Coral', 'Коралловый', 'Koralle']], ['red', 354, 1, ['Червоний', 'Red', 'Красный', 'Rot']],
    ['terracotta', 16, 0.75, ['Теракотовий', 'Terracotta', 'Терракотовый', 'Terrakotta']], ['orange', 28, 1, ['Помаранчевий', 'Orange', 'Оранжевый', 'Orange']],
    ['amber', 40, 1, ['Бурштиновий', 'Amber', 'Янтарный', 'Bernstein']], ['mustard', 48, 0.78, ['Гірчичний', 'Mustard', 'Горчичный', 'Senf']],
    ['olive', 70, 0.5, ['Оливковий', 'Olive', 'Оливковый', 'Oliv']], ['lime', 85, 0.9, ['Лаймовий', 'Lime', 'Лаймовый', 'Limette']],
    ['emerald', 150, 0.85, ['Смарагдовий', 'Emerald', 'Изумрудный', 'Smaragd']], ['mint', 165, 0.7, ['М’ятний', 'Mint', 'Мятный', 'Mint']],
    ['turquoise', 180, 0.85, ['Бірюзовий', 'Teal', 'Бирюзовый', 'Türkis']], ['sky', 200, 0.9, ['Блакитний', 'Cyan', 'Голубой', 'Cyan']],
    ['sapphire', 220, 0.9, ['Сапфіровий', 'Sapphire', 'Сапфировый', 'Saphir']], ['indigo', 240, 0.8, ['Індиго', 'Indigo', 'Индиго', 'Indigo']],
    ['lavender', 262, 0.6, ['Лавандовий', 'Lavender', 'Лавандовый', 'Lavendel']], ['violet', 278, 0.85, ['Фіолетовий', 'Violet', 'Фиолетовый', 'Violett']],
    ['plum', 300, 0.5, ['Сливовий', 'Plum', 'Сливовый', 'Pflaume']], ['fuchsia', 318, 0.9, ['Фуксія', 'Fuchsia', 'Фуксия', 'Fuchsie']],
    ['pink', 338, 0.85, ['Рожевий', 'Pink', 'Розовый', 'Rosa']], ['graphite', 220, 0.1, ['Графітовий', 'Graphite', 'Графитовый', 'Graphit']]
  ];

  // text and accents must stand out from the background in every mood and colourway
  const lum = h => O.color.luminance(h);
  const away = (col, bg, min) => {
    if (Math.abs(lum(col) - lum(bg)) >= min) return col;
    const c = O.color.toHsl(O.color.parse(col)), dir = lum(bg) > 0.5 ? -1 : 1;
    for (let i = 1; i <= 12; i++) { const v = H(c.h, c.s, c.l + dir * i * 0.05); if (Math.abs(lum(v) - lum(bg)) >= min) return v; }
    return dir < 0 ? '#141414' : '#FFFFFF';
  };
  const palette = (mood, col, ae, look) => {
    const p = mood[2](col[1], col[2], ae[4]);
    if (Math.abs(lum(p[2]) - lum(p[0])) < 0.5) p[2] = lum(p[0]) > 0.55 ? '#141414' : '#FFFFFF';
    p[3] = away(p[3], p[0], 0.2); p[4] = away(p[4], p[0], 0.12);
    if (look === 'soft:neu') p[1] = p[0];
    return p;
  };

  // names: «Aesthetic · mood · colour» in every language (German colour names are nouns and keep their capital)
  const LANGS = ['uk', 'en', 'ru', 'de'];
  const nameOf = (a, m, c) => LANGS.map((lg, i) => `${a[5][i]} · ${m[1][i].toLowerCase()} · ${lg === 'de' ? c[3][i] : c[3][i].toLowerCase()}`);
  const rows = [], list = [];
  AE.forEach(a => rows.push(a[5], a[6]));
  // mixed so that neighbours on the wall differ in aesthetic, mood and colour: aesthetic = i mod 50,
  // mood = ⌊i / 50⌋ mod 10, and the colour runs through all 20 for each aesthetic × mood
  for (let i = 0; i < AE.length * MOODS.length * COLS.length; i++) {
    const ai = i % AE.length, mi = Math.floor(i / AE.length) % MOODS.length, ci = (Math.floor(i / (AE.length * MOODS.length)) + ai * 7 + mi * 3) % COLS.length;
    const a = AE[ai], m = MOODS[mi], c = COLS[ci], look = a[2][mi % a[2].length], [mo, v] = look.split(':'), names = nameOf(a, m, c);
    rows.push(names);
    list.push({ k: `x-${a[0]}-${m[0]}-${c[0]}`, n: names[0], g: a[1], m: mo, v, pal: palette(m, c, a, look), f: a[3][mi % a[3].length].slice(), d: a[6][0], x: { a: a[0], m: m[0], c: c[0] } });
  }
  MOODS.forEach(m => rows.push(m[1]));
  COLS.forEach(c => rows.push(c[3]));
  O.i18nAdd(rows);
  GL.addStyles(list);
  // for the gallery's filters: [key, Ukrainian name] (the names are interface strings)
  GL.X = { aesthetics: AE.map(a => [a[0], a[5][0]]), moods: MOODS.map(m => [m[0], m[1][0]]), colours: COLS.map(c => [c[0], c[3][0], H(c[1], 0.75 * c[2], 0.5)]), count: list.length };
})();
