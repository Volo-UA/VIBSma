'use strict';
/* VIBSma — Spotlight tour and the feature guide (F1).
   The tour dims the window and lights up one part of the interface at a time with a short explanation.
   The guide lists every command: it is built from the command registry and the menus at the moment it opens, so
   commands added by any module appear in it by themselves, with the shortcut, where the command lives in the menus,
   a description where one is written, «Run» and «Show where» — which opens the menu path (or the tool group) and
   lights up the item, so a click on it runs the command. */
(function () {
  const O = window.O, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const GD = O.guide = {};

  // ---------- texts (translation keys) ----------
  // parts of the window: the tour walks through them, the guide lists them under «Інтерфейс»
  const PARTS = [
    { id: 'welcome', title: 'Ласкаво просимо до VIBSma', text: 'Короткий тур покаже головні частини редактора. Стрілки ← → або Enter — далі, Esc — вийти.' },
    { id: 'logo', sel: '#btn-menu', icon: 'menu', title: 'Головне меню', text: 'Усі меню в одному списку: файл, об’єкт, текст, ефекти, вигляд та інші.' },
    { id: 'menubar', sel: '#menubar', icon: 'menu', title: 'Рядок меню', text: 'Команди згруповано як в Illustrator: Файл, Редагування, Об’єкт, Текст, Ефект, Вигляд… Меню, що не вмістилися, ховаються під «⋯».' },
    { id: 'projects', sel: '#btn-projects', icon: 'grid', title: 'Усі проєкти', text: 'Ваші документи: відкрити, створити, дублювати. Усе зберігається в браузері автоматично.' },
    { id: 'ws', sel: '#btn-ws', icon: 'layers', title: 'Робочий простір', text: 'Набори панелей для дизайну, анімації, вебу й коду. Області можна ділити й міняти.' },
    { id: 'doc', sel: '#doc-name', icon: 'page', title: 'Назва документа', text: 'Клацніть, щоб перейменувати. Поруч — назва сторінки і стан збереження.' },
    { id: 'spot', sel: '#btn-palette', icon: 'search', title: 'Spotlight — пошук усього', text: 'Ctrl+K: команди, інструменти, шари, шаблони, шрифти, кольори й калькулятор в одному полі. Ctrl+Enter — дизайн з Claude.' },
    { id: 'tools', sel: '#toolbar', icon: 'pen', title: 'Інструменти', text: 'Виділення, фігури, перо, текст, трансформації. Стрілка біля кнопки відкриває інші інструменти групи; наведіть курсор — побачите опис і клавішу.' },
    { id: 'layers', sel: ['#layers-list', '#pages-list', '#btn-left'], icon: 'layers', title: 'Шари та сторінки', text: 'Структура документа: сторінки вгорі, шари нижче. Перетягуйте, щоб змінити порядок; око й замок — видимість і блокування.' },
    { id: 'assets', sel: '[data-lt="assets"]', icon: 'component', title: 'Ресурси', text: 'Компоненти, кольори документа й шрифти, зокрема Google Fonts.' },
    { id: 'canvas', sel: '#canvas', icon: 'frame', title: 'Полотно', text: 'Тут ви малюєте. Пробіл + перетягування — рух, Ctrl + коліщатко — масштаб, правий клік — контекстне меню.' },
    { id: 'props', sel: ['#props', '#btn-right'], icon: 'sliders', title: 'Властивості', text: 'Розмір, положення, заливка, обведення, ефекти й текст виділеного. Без виділення — налаштування сторінки.' },
    { id: 'code', sel: '[data-rt="code"]', icon: 'code', title: 'Код', text: 'CSS, SVG та інший код виділеного об’єкта — для розробників.' },
    { id: 'zoom', sel: '#zoom-btn', icon: 'zoom', title: 'Масштаб перегляду', text: 'Поточний масштаб; у меню — показати все, до виділення, 100%.' },
    { id: 'present', sel: '#btn-present', icon: 'play', title: 'Презентація', text: 'Показує фрейми як слайди на весь екран (W).' },
    { id: 'lang', sel: '#btn-lang', icon: 'globe', title: 'Мова й тема', text: 'Українська, English, Русский, Deutsch; кнопка поруч перемикає світлу й темну тему.' },
    { id: 'export', sel: '#btn-export', icon: 'download', title: 'Експорт', text: 'PNG, JPG, SVG, PDF та формати інших програм (Ctrl+Shift+E).' },
    { id: 'guide', sel: '#btn-guide', icon: 'help', title: 'Довідник функцій', text: 'Усі функції з поясненнями, пошуком і кнопкою «Показати де». Відкривається клавішею F1; звідти ж можна пройти тур знову.' }
  ];
  // what each menu is for (keys are the menu labels)
  const MENU_INTRO = {
    'Файл': 'Створення, відкриття й збереження документів, імпорт (SVG, PDF, PSD, Figma), експорт у всі формати, шаблони й проєкти.',
    'Редагування': 'Скасування й повтор, буфер обміну, копіювання властивостей, дублювання й видалення.',
    'Об’єкт': 'Усе, що робиться з виділеними об’єктами: трансформації, порядок, вирівнювання, групи, булеві операції, обробка контурів, маски, компоненти, трасування.',
    'Зображення': 'Растрові фото: режими кольору, корекція (рівні, криві, тон), розмір зображення й полотна, поворот і кадрування.',
    'Текст': 'Шрифти, символ і абзац, стилі, списки, спецсимволи, примітки, гіперпосилання, текст на контурі й перетворення на криві.',
    'Виділення': 'Виділити все, інвертувати, вибрати схожі об’єкти за заливкою, обведенням чи типом, зберегти виділення.',
    'Ефект': 'Тіні, світіння, розмиття, Liquid Glass, спотворення контурів і бібліотека стилів.',
    'Фільтр': 'Фільтри для фото як у Photoshop: різкість, шум, розмиття, стилізація, спотворення, нейрофільтри.',
    'Анімація': 'Таймлайн, ключові кадри, готові пресети руху й експорт Lottie.',
    'Публікація': 'Журнали й книжки як в InDesign: сторінки, шаблонні сторінки, колонки, базова сітка, зв’язані текстові фрейми, preflight і PDF.',
    'Прототип': 'Інтерактивні переходи між фреймами й перегляд прототипу.',
    'Спільна робота': 'Коментарі, спільне редагування в реальному часі й посилання для доступу.',
    'Плагіни': 'Вбудовані помічники: контраст WCAG, перейменування шарів, пошук і заміна, палітри, фото-заповнювачі.',
    'Інтер’єр': 'Стилі інтер’єру, матеріали-текстури й мудборди.',
    'Медіа': 'Відеоредактор, музична студія й шаблони відео та треків.',
    'Вигляд': 'Масштаб, лінійки, напрямні, сітки, прив’язки, тема, мова й робочі простори.',
    'Довідка': 'Spotlight, гарячі клавіші, цей довідник, тур і поради з перенесення робіт з інших програм.'
  };
  const INTRO_UI = 'Головні частини вікна. «Показати де» підсвічує кожну з них.';
  const INTRO_TOOLS = 'Інструменти на панелі внизу полотна. Клавіша вмикає інструмент; Shift і Alt під час малювання змінюють поведінку.';
  const INTRO_OTHER = 'Команди, яких немає в меню: доступні через Spotlight (Ctrl+K), панелі або гарячі клавіші.';
  // tools whose description tips.js does not have
  const TOOL_DESC = {
    animpen: 'Малює траєкторію руху: об’єкт пролетить уздовж лінії в анімації.',
    adaptpen: 'З’єднує формати сайту: зміни в одному фреймі переносяться на зв’язані.',
    protopen: 'Протягніть від об’єкта до фрейма — вийде перехід у прототипі.'
  };
  const DESC = {
    new: 'Створює новий проєкт; поточний лишається в «Усіх проєктах».',
    open: 'Відкриває файл .obrys, SVG, PDF, зображення та інші підтримувані формати.',
    save: 'Зберігає документ у файл .obrys (у браузері він і так зберігається автоматично).',
    placeImage: 'Додає фото, відео або аудіо з диска на полотно.',
    exportDialog: 'Експорт сторінки, фреймів або виділеного в PNG, JPG, WEBP, SVG чи PDF з вибором масштабу.',
    present: 'Показує фрейми сторінки як слайди на весь екран.',
    claudeDesign: 'Опишіть дизайн словами — Claude створить редагований макет.',
    undo: 'Скасовує останню дію. Історія змін — у меню «Вигляд».',
    copyStyle: 'Копіює заливку, обведення й ефекти, щоб вставити їх на інші об’єкти.',
    duplicate: 'Створює копію поруч; Alt + перетягування робить те саме мишею.',
    group: 'Об’єднує виділене в групу, яку можна рухати й масштабувати як одне ціле.',
    frameSelection: 'Огортає виділене фреймом — контейнером з власним фоном і обрізанням.',
    autoLayout: 'Фрейм сам розкладає вміст у рядок чи стовпець із проміжками й полями, як у Figma.',
    expand: 'Перетворює фігури, булеві групи, текст і екземпляри на звичайні контури.',
    boolUnion: 'Живе об’єднання: фігури зливаються в одну, але кожну можна далі редагувати всередині групи.',
    boolSubtract: 'Живе віднімання: верхні фігури вирізають форму з нижньої.',
    boolIntersect: 'Живий перетин: лишається тільки спільна частина фігур.',
    boolExclude: 'Живе виключення: лишається все, крім місць перекриття.',
    flatten: 'Зводить виділене в один редагований контур.',
    pfUnite: 'Остаточно об’єднує фігури в один контур зі стилем верхньої.',
    pfMinusFront: 'Вирізає верхні фігури з нижньої й видаляє їх.',
    pfIntersect: 'Лишає тільки область, спільну для всіх фігур.',
    pfExclude: 'Лишає області, що не перекриваються.',
    pfDivide: 'Розрізає фігури по всіх перетинах на окремі шматки (результат — група).',
    pfTrim: 'Видаляє приховані частини фігур і обведення; фігури однакового кольору не зливаються.',
    pfMerge: 'Видаляє приховані частини й зливає фігури однакового кольору. Контур лише з обведенням стає смугою кольору обведення.',
    pfCrop: 'Обрізає нижні фігури по формі верхньої; верхня зникає.',
    pfOutline: 'Розбиває фігури на окремі лінії з кольором заливки як обведенням.',
    pfMinusBack: 'Вирізає з верхньої фігури всі, що лежать під нею.',
    makeClip: 'Верхній об’єкт стає маскою: видно лише те, що всередині нього.',
    makeCompound: 'Зводить кілька контурів в один; там, де вони перекриваються, з’являються отвори.',
    blendMake: 'Будує плавний перехід форми й кольору між двома об’єктами.',
    createComponent: 'Робить з виділеного компонент; його екземпляри оновлюються разом з ним.',
    outlineStroke: 'Перетворює обведення на заповнену фігуру тієї ж форми.',
    offsetPath: 'Створює контур, віддалений від оригіналу на задану відстань.',
    simplify: 'Зменшує кількість вузлів, зберігаючи форму.',
    createOutlines: 'Перетворює текст на криві — шрифт більше не потрібен, але текст не редагується.',
    textOnPath: 'Розміщує виділений текст уздовж виділеного контуру.',
    traceDefault: 'Перетворює растрове зображення на векторні фігури.',
    rasterize: 'Перетворює вектор на растрове зображення.',
    zoomFit: 'Показує весь вміст сторінки у вікні.',
    outline: 'Показує лише контури без заливок — зручно для точного редагування.',
    smartGuides: 'Підказки вирівнювання й відстаней під час переміщення.',
    toggleUI: 'Ховає всі панелі, лишаючи тільки полотно.',
    timeline: 'Показує таймлайн анімації з ключовими кадрами.',
    palette: 'Відкриває Spotlight: пошук команд, шарів, шаблонів і шрифтів.',
    shortcuts: 'Список усіх гарячих клавіш.'
  };
  DESC.spotlight = DESC.palette;
  DESC.pasteStyle = DESC.copyStyle;
  // icons for commands that have a matching one
  const CMD_ICON = { pfUnite: 'union', pfMinusFront: 'subtract', pfIntersect: 'intersect', pfExclude: 'exclude', pfDivide: 'divide', pfTrim: 'trim', pfMerge: 'merge', pfCrop: 'crop', pfOutline: 'outline', pfMinusBack: 'minusback', boolUnion: 'union', boolSubtract: 'subtract', boolIntersect: 'intersect', boolExclude: 'exclude', flatten: 'bool', group: 'group', ungroup: 'group', frameSelection: 'frame', autoLayout: 'autolayout', createComponent: 'component', detach: 'instance', makeClip: 'mask', useAsMask: 'mask', releaseClip: 'mask', rotate90: 'rot90', present: 'play', exportDialog: 'download', placeImage: 'image', delete: 'trash', copy: 'copy', palette: 'search', spotlight: 'sparkle', guide: 'help', tour: 'help', createOutlines: 'font', textOnPath: 'textpath', lock: 'lock', hide: 'eye', zoomFit: 'zoom', zoomIn: 'zoom', zoomOut: 'zoom', zoomSel: 'zoom', zoom100: 'zoom', copySVG: 'code' };
  const iconOf = id => O.icon(CMD_ICON[id] || (O.ICONS[id] ? id : 'command'), 16);

  // ---------- helpers ----------
  const shown = el => {
    if (!el || !el.isConnected || el.hidden) return false;
    const r = el.getBoundingClientRect();
    return r.width > 2 && r.height > 2 && r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  };
  const find = sel => { for (const s of [].concat(sel || [])) { const el = O.$(s); if (shown(el)) return el; } return null; };
  const isHidden = c => typeof c.hidden === 'function' ? c.hidden() : !!c.hidden;
  const keysOf = c => (c.keys || [])[0] ? O.keyLabel(c.keys[0]) : '';
  const norm = s => String(s || '').toLowerCase().replace(/[’'`ʼ]/g, '').replace(/ё/g, 'е');

  // ======================================================================
  // SPOTLIGHT: dim everything except one element, with a card next to it
  // ======================================================================
  let spot = null;
  GD.closeSpot = () => {
    if (!spot) return;
    const s = spot; spot = null;
    cancelAnimationFrame(s.raf);
    clearInterval(s.timer);
    s.wrap.remove();
    document.removeEventListener('keydown', s.onKey, true);
    document.removeEventListener('pointerdown', s.onDown, true);
    window.removeEventListener('resize', s.place);
    if (s.o.onClose) s.o.onClose();
  };
  // o: { el, title, text, step, total, buttons: [{ id, label, primary }], onButton(id), onKey(e) → handled, pass }
  // pass: clicks go through to the page (the lit item can be clicked); a click anywhere else closes the spotlight
  const showSpot = o => {
    if (!spot) {
      // the shade: four plain panels around the lit window
      const wrap = O.h('<div class="gd-spot"><i class="gd-sh"></i><i class="gd-sh"></i><i class="gd-sh"></i><i class="gd-sh"></i><div class="gd-hole"></div><div class="gd-card" role="dialog" aria-live="polite"></div></div>');
      document.body.appendChild(wrap);
      const s = spot = { wrap, shade: O.$$('.gd-sh', wrap), hole: wrap.querySelector('.gd-hole'), card: wrap.querySelector('.gd-card'), last: '', cur: null };
      s.place = () => s.kick();
      s.onKey = e => {
        if (!spot) return;
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); if (spot.o.pass) ui.closeMenus(); GD.closeSpot(); return; }
        if (spot.o.onKey && spot.o.onKey(e)) { e.preventDefault(); e.stopPropagation(); return; }
        // the tour blocks the editor's shortcuts; «Show where» leaves them alone
        if (!spot.o.pass) e.stopPropagation();
      };
      s.onDown = e => {
        if (!spot || !spot.o.pass || spot.card.contains(e.target)) return;
        // after this click has reached the menu item (which runs the command)
        setTimeout(() => GD.closeSpot(), 0);
      };
      document.addEventListener('keydown', s.onKey, true);
      document.addEventListener('pointerdown', s.onDown, true);
      window.addEventListener('resize', s.place);
      wrap.addEventListener('click', e => { const b = e.target.closest('[data-gb]'); if (b && spot) { if (b.dataset.gb === 'close') GD.closeSpot(); else spot.o.onButton(b.dataset.gb); } });
      // follow the element while it moves (menus opening, panels resizing): a light check every 150 ms, frame by
      // frame only while the window glides; a closed menu ends «Show where»
      const tick = () => {
        s.raf = 0;
        if (spot !== s) return;
        if (s.o.pass && s.o.el && !s.o.el.isConnected) { GD.closeSpot(); return; }
        if (place()) s.raf = requestAnimationFrame(tick);
      };
      s.kick = () => { if (!s.raf) s.raf = requestAnimationFrame(tick); };
      s.timer = setInterval(s.kick, 150);
    }
    spot.o = o; spot.last = '';
    spot.wrap.classList.toggle('pass', !!o.pass);
    spot.wrap.classList.toggle('free', !o.el);
    const dots = o.total > 1 ? `<span class="gd-dots" aria-hidden="true">${Array.from({ length: o.total }, (_, i) => `<i${i + 1 === o.step ? ' class="on"' : ''}></i>`).join('')}</span>` : '';
    spot.card.innerHTML = `<div class="gd-c-h">${o.step ? `<span class="gd-step">${o.step} / ${o.total}</span>${dots}` : `<span class="gd-step">${O.icon('sparkle', 14)} Spotlight</span>`}<button type="button" class="gd-x" data-gb="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 14)}</button></div>
      <h3>${esc(o.title)}</h3>${o.text ? `<p>${esc(o.text)}</p>` : ''}${o.note ? `<p class="gd-note">${esc(o.note)}</p>` : ''}
      <div class="gd-c-f"><span class="sp"></span>${(o.buttons || []).filter(Boolean).map(b => `<button type="button" class="btn${b.primary ? ' primary' : ''}" data-gb="${b.id}">${esc(t(b.label))}</button>`).join('')}</div>`;
    place();
    spot.kick();
    const def = spot.card.querySelector('.btn.primary');
    if (def && !o.pass) def.focus({ preventScroll: true });
  };
  // → true while the lit window is still gliding to its target
  const place = () => {
    if (!spot) return false;
    const o = spot.o, vw = innerWidth, vh = innerHeight, pad = 6;
    let r;
    if (o.el && o.el.isConnected) {
      const b = o.el.getBoundingClientRect();
      const x = Math.max(2, b.left - pad), y = Math.max(2, b.top - pad);
      r = { x, y, w: Math.min(vw - 2, b.right + pad) - x, h: Math.min(vh - 2, b.bottom + pad) - y };
    } else r = { x: vw / 2, y: vh / 2, w: 0, h: 0 };
    // the lit window glides to its target; the shade is the whole screen with that window cut out
    const cur = spot.cur || (spot.cur = Object.assign({}, r));
    const ease = matchMedia('(prefers-reduced-motion: reduce)').matches ? 1 : 0.25;
    for (const k of ['x', 'y', 'w', 'h']) { const d = r[k] - cur[k]; cur[k] = Math.abs(d) > 0.5 ? cur[k] + d * ease : r[k]; }
    const frame = [cur.x, cur.y, cur.w, cur.h, vw, vh].map(Math.round).join(',');
    if (frame !== spot.frame) {
      spot.frame = frame;
      const { x, y, w, h } = cur, px = v => Math.max(0, v) + 'px';
      const [top, bottom, left, right] = spot.shade;
      Object.assign(top.style, { left: 0, right: 0, top: 0, height: px(y) });
      Object.assign(bottom.style, { left: 0, right: 0, top: px(y + h), bottom: 0 });
      Object.assign(left.style, { left: 0, top: px(y), width: px(x), height: px(h) });
      Object.assign(right.style, { left: px(x + w), right: 0, top: px(y), height: px(h) });
      Object.assign(spot.hole.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px' });
    }
    const moving = ['x', 'y', 'w', 'h'].some(k => cur[k] !== r[k]);
    const key = [r.x, r.y, r.w, r.h, vw, vh].map(Math.round).join(',');
    if (key === spot.last) return moving;
    spot.last = key;
    const c = spot.card, cw = c.offsetWidth, ch = c.offsetHeight, gap = 14;
    let x, y;
    if (!o.el) { x = (vw - cw) / 2; y = (vh - ch) / 2; }
    else if (r.y + r.h + gap + ch < vh - 8) { x = r.x + r.w / 2 - cw / 2; y = r.y + r.h + gap; }
    else if (r.y - gap - ch > 8) { x = r.x + r.w / 2 - cw / 2; y = r.y - gap - ch; }
    else if (r.x + r.w + gap + cw < vw - 8) { x = r.x + r.w + gap; y = r.y + r.h / 2 - ch / 2; }
    else if (r.x - gap - cw > 8) { x = r.x - gap - cw; y = r.y + r.h / 2 - ch / 2; }
    else { x = (vw - cw) / 2; y = vh - ch - 16; }
    c.style.left = Math.round(O.clamp(x, 8, Math.max(8, vw - cw - 8))) + 'px';
    c.style.top = Math.round(O.clamp(y, 8, Math.max(8, vh - ch - 8))) + 'px';
    // glide between steps, but appear in place the first time
    if (!c.classList.contains('ready')) requestAnimationFrame(() => c.classList.add('ready'));
    return moving;
  };

  // ======================================================================
  // TOUR
  // ======================================================================
  const markSeen = () => { O.ls.set('guideSeen', 1); const inv = O.$('.gd-invite'); if (inv) inv.remove(); };
  GD.tour = (start = 0) => {
    markSeen();
    GD.close();
    ui.closeMenus();
    const steps = PARTS.filter(p => !p.sel || find(p.sel));
    let i = O.clamp(start, 0, steps.length - 1);
    const show = () => {
      const p = steps[i], last = i === steps.length - 1;
      showSpot({
        el: p.sel ? find(p.sel) : null, title: t(p.title), text: t(p.text), step: i + 1, total: steps.length,
        buttons: [!last && { id: 'skip', label: 'Пропустити' }, i > 0 && { id: 'prev', label: 'Назад' }, { id: last ? 'done' : 'next', label: last ? 'Готово' : 'Далі', primary: true }],
        onButton: go,
        onKey: e => {
          if (e.key === 'ArrowRight' || e.key === 'Enter' || e.key === ' ') { go(last ? 'done' : 'next'); return true; }
          if (e.key === 'ArrowLeft') { go('prev'); return true; }
          return false;
        }
      });
    };
    const go = id => {
      if (id === 'next') { i = Math.min(steps.length - 1, i + 1); show(); }
      else if (id === 'prev') { i = Math.max(0, i - 1); show(); }
      else GD.closeSpot();
    };
    show();
  };

  // ======================================================================
  // GUIDE
  // ======================================================================
  // sections: interface, tools, every menu (with its submenus as headings), commands found in no menu
  const build = () => {
    const secs = [];
    const where = new Map();
    secs.push({ key: 'ui', title: t('Інтерфейс'), intro: t(INTRO_UI), icon: 'frame', items: PARTS.filter(p => p.sel).map(p => ({ key: 'ui:' + p.id, kind: 'ui', part: p, label: t(p.title), desc: t(p.text), icon: O.icon(p.icon, 16), loc: '' })) });
    const tips = (O.tips && O.tips.TOOLS) || {};
    secs.push({ key: 'tools', title: t('Інструменти'), intro: t(INTRO_TOOLS), icon: 'pen', items: Object.entries(ui.TOOLS).map(([id, d]) => ({ key: 'tool:' + id, kind: 'tool', tool: id, label: t(d.label), keys: d.key ? O.keyLabel(d.key) : '', desc: tips[id] || TOOL_DESC[id] ? t(tips[id] || TOOL_DESC[id]) : '', icon: O.icon(d.icon, 16), loc: t('Панель інструментів') })) });
    O.MENUS.forEach(([label, items], mi) => {
      const sec = { key: 'm:' + mi, title: t(label), intro: MENU_INTRO[label] ? t(MENU_INTRO[label]) : '', icon: 'menu', items: [] };
      const seen = new Set();
      const walk = (list, path) => list.forEach(it => {
        if (it === '-' || !it) return;
        if (it.items) { sec.items.push({ kind: 'head', label: path.slice(1).concat(it.label).map(x => t(x)).join(' › ') }); walk(it.items, path.concat(it.label)); return; }
        const id = typeof it === 'string' ? it : it.id;
        const c = O.cmds.get(id);
        if (!c || isHidden(c) || seen.has(id)) return;
        seen.add(id);
        if (!where.has(id)) where.set(id, { mi, path });
        sec.items.push(cmdItem(c, mi, path));
      });
      walk(items, [label]);
      if (sec.items.some(x => x.kind !== 'head')) secs.push(sec);
    });
    const rest = new Map();
    for (const c of O.cmds.values()) {
      if (where.has(c.id) || isHidden(c) || !c.label || c.id.startsWith('tool:')) continue;
      const g = c.group || 'Інше';
      if (!rest.has(g)) rest.set(g, []);
      rest.get(g).push(cmdItem(c, -1, []));
    }
    if (rest.size) {
      const items = [];
      rest.forEach((list, g) => { items.push({ kind: 'head', label: t(g) }); items.push(...list); });
      secs.push({ key: 'other', title: t('Інші команди'), intro: t(INTRO_OTHER), icon: 'command', items });
    }
    return secs;
  };
  const cmdItem = (c, mi, path) => {
    const label = O.cmdLabel(c);
    let dis = false;
    try { dis = !!(c.enabled && !c.enabled()); } catch (e) { /* treat as available */ }
    return { key: 'cmd:' + c.id, kind: 'cmd', id: c.id, mi, path, label, keys: keysOf(c), desc: DESC[c.id] ? t(DESC[c.id]) : '', icon: iconOf(c.id), dis,
      loc: mi >= 0 ? path.map(x => t(x)).join(' › ') : t('Лише через Spotlight (Ctrl+K) або гарячу клавішу'), search: norm([label, typeof c.label === 'string' ? c.label : '', c.id, c.group ? t(c.group) : ''].join(' ')) };
  };

  let last = { sec: 'ui', q: '', scroll: 0 };
  GD.close = () => { const w = O.$('.gd-back'); if (w) w._close(); };
  GD.open = (opts = {}) => {
    if (O.$('.gd-back')) return;
    GD.closeSpot();
    ui.closeMenus();
    markSeen();
    const secs = build();
    const total = new Set([].concat(...secs.map(s => s.items.filter(x => x.kind !== 'head').map(x => x.key)))).size;
    let cur = secs.some(s => s.key === (opts.sec || last.sec)) ? (opts.sec || last.sec) : 'ui';
    const wrap = O.h(`<div class="dlg-back gd-back"><div class="gd" role="dialog" aria-modal="true" aria-label="${esc(t('Довідник функцій'))}">
      <div class="gd-h"><span class="gd-mark">${O.icon('help', 20)}</span><div class="gd-ttl"><b>${esc(t('Довідник функцій'))}</b><em>${esc(t('Функцій: {n}', { n: total }))}</em></div>
        <label class="gd-q">${O.icon('search', 15)}<input type="search" placeholder="${esc(t('Шукати функцію…'))}" aria-label="${esc(t('Шукати функцію…'))}" autocomplete="off" spellcheck="false"></label>
        <button type="button" class="btn gd-tour" data-ga="tour">${O.icon('sparkle', 14)}<span>${esc(t('Почати тур'))}</span></button>
        <button type="button" class="ib" data-ga="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 16)}</button></div>
      <div class="gd-body"><nav class="gd-nav" aria-label="${esc(t('Розділи'))}"></nav><div class="gd-main" tabindex="-1"></div></div></div></div>`);
    document.body.appendChild(wrap);
    const inp = wrap.querySelector('input'), nav = wrap.querySelector('.gd-nav'), main = wrap.querySelector('.gd-main');
    const itemHTML = it => it.kind === 'head' ? `<h4 class="gd-sub">${esc(it.label)}</h4>` : `<div class="gd-it${it.dis ? ' dis' : ''}" data-k="${esc(it.key)}">
        <span class="gd-ic">${it.icon}</span>
        <div class="gd-tx"><div class="gd-l"><b>${esc(it.label)}</b>${it.keys ? `<kbd>${esc(it.keys)}</kbd>` : ''}</div>${it.loc ? `<em>${esc(it.loc)}</em>` : ''}${it.desc ? `<p>${esc(it.desc)}</p>` : ''}</div>
        <div class="gd-acts"><button type="button" class="btn" data-ga="show">${O.icon('search', 13)}<span>${esc(t('Показати де'))}</span></button>${it.kind === 'ui' ? '' : `<button type="button" class="btn primary" data-ga="run"${it.dis ? ` disabled title="${esc(t('Зараз недоступно: спершу виділіть потрібні об’єкти'))}"` : ''}>${esc(t('Виконати'))}</button>`}</div></div>`;
    const byKey = new Map();
    secs.forEach(s => s.items.forEach(it => { if (it.key) byKey.set(it.key, it); }));
    const renderNav = () => {
      nav.innerHTML = secs.map(s => `<button type="button" data-sec="${esc(s.key)}" class="${!inp.value.trim() && s.key === cur ? 'on' : ''}">${O.icon(s.icon, 14)}<span>${esc(s.title)}</span><i>${s.items.filter(x => x.kind !== 'head').length}</i></button>`).join('');
    };
    const render = () => {
      const q = norm(inp.value.trim());
      let h = '';
      if (q) {
        const words = q.split(/\s+/);
        const done = new Set();
        let n = 0;
        for (const s of secs) {
          const hits = s.items.filter(it => {
            if (it.kind === 'head' || done.has(it.key)) return false;
            const hay = it.search || norm(it.label + ' ' + (it.part ? it.part.title : it.tool || ''));
            const ok = words.every(w => hay.includes(w) || norm(it.desc).includes(w) || norm(it.loc).includes(w));
            if (ok) done.add(it.key);
            return ok;
          });
          if (!hits.length) continue;
          n += hits.length;
          h += `<section><h3 class="gd-sec">${esc(s.title)}</h3>${hits.slice(0, 120).map(itemHTML).join('')}</section>`;
        }
        if (!n) h = `<div class="gd-empty">${esc(t('Нічого не знайдено'))}</div>`;
      } else {
        const s = secs.find(x => x.key === cur) || secs[0];
        h = `<section><h3 class="gd-sec big">${esc(s.title)}</h3>${s.intro ? `<p class="gd-intro">${esc(s.intro)}</p>` : ''}${s.items.map(itemHTML).join('')}</section>`;
      }
      main.innerHTML = h;
      main.scrollTop = 0;
      renderNav();
    };
    const close = () => { last = { sec: cur, q: inp.value, scroll: main.scrollTop }; wrap.remove(); document.removeEventListener('keydown', onKey, true); };
    wrap._close = close;
    const onKey = e => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); if (inp.value) { inp.value = ''; render(); } else close(); }
      else if (e.key === 'F1') { e.preventDefault(); e.stopPropagation(); }
    };
    document.addEventListener('keydown', onKey, true);
    inp.addEventListener('input', render);
    nav.addEventListener('click', e => { const b = e.target.closest('[data-sec]'); if (!b) return; cur = b.dataset.sec; inp.value = ''; render(); });
    wrap.addEventListener('click', e => {
      if (e.target === wrap) { close(); return; }
      const b = e.target.closest('[data-ga]');
      if (!b) return;
      const a = b.dataset.ga;
      if (a === 'close') return close();
      if (a === 'tour') return GD.tour();
      const row = b.closest('.gd-it'), it = row && byKey.get(row.dataset.k);
      if (!it) return;
      close();
      if (a === 'run') { if (it.kind === 'tool') O.setTool(it.tool); else O.run(it.id); }
      else if (a === 'show') GD.show(it);
    });
    if (opts.q !== undefined || (opts.back && last.q)) inp.value = opts.q !== undefined ? opts.q : last.q;
    render();
    if (opts.back) main.scrollTop = last.scroll;
    setTimeout(() => inp.focus(), 0);
  };

  // ---------- «Show where» ----------
  // opens the menus down to the command (the logo menu or «⋯» when the bar has no room) and returns its item
  const openMenuPath = (mi, path, id) => {
    ui.closeMenus();
    const bar = O.$('#menubar');
    let btn = bar && bar.querySelector(`.mb-item[data-i="${mi}"]`);
    let chain = path.slice(1);
    if (!shown(btn)) {
      chain = path.slice();
      btn = bar && bar.querySelector('.mb-more');
      if (!shown(btn)) btn = O.$('#btn-menu');
    }
    if (!shown(btn)) return null;
    btn.click();
    let menu = O.$$('.menu').pop();
    for (const label of chain) {
      const sub = menu && O.$$('.mi.sub', menu).find(x => x.querySelector('.mi-l').textContent === t(label));
      if (!sub) return null;
      sub.dispatchEvent(new PointerEvent('pointerover', { bubbles: true }));
      menu = O.$$('.menu').pop();
    }
    const item = menu && menu.querySelector(`.mi[data-cmd="${CSS.escape(id)}"]`);
    if (item) item.scrollIntoView({ block: 'nearest' });
    return item;
  };
  // the tool's group on the toolbar; a tool hidden in a group is shown in the group's flyout
  const openTool = tool => {
    ui.closeMenus();
    const gi = ui.TOOL_GROUPS.findIndex(g => g.includes(tool));
    const grp = gi >= 0 ? O.$$('#toolbar .tb-grp')[gi] : null;
    if (!shown(grp)) return null;
    const btn = grp.querySelector(`[data-tool="${tool}"]`);
    if (btn) return btn;
    const more = grp.querySelector('.tb-more');
    if (!more) return grp;
    more.click();
    const menu = O.$$('.menu').pop();
    return (menu && menu.querySelector(`.mi[data-cmd="tool:${tool}"]`)) || grp;
  };
  GD.show = it => {
    const back = { id: 'back', label: 'До довідника' };
    const onButton = id => { if (id === 'back') { GD.closeSpot(); ui.closeMenus(); GD.open({ back: true }); } };
    let el = null, note = '';
    if (it.kind === 'ui') { el = find(it.part.sel); note = ''; }
    else if (it.kind === 'tool') { el = openTool(it.tool); note = t('Клацніть підсвічений пункт, щоб виконати команду, або будь-де, щоб закрити.'); }
    else if (it.mi >= 0) { el = openMenuPath(it.mi, it.path, it.id); note = t('Клацніть підсвічений пункт, щоб виконати команду, або будь-де, щоб закрити.'); }
    else {
      // only reachable from Spotlight or a shortcut: light up the Spotlight button
      el = find('#btn-palette');
      note = t('Відкрийте Spotlight (Ctrl+K) і почніть вводити «{q}».', { q: it.label });
    }
    if (!el) { ui.closeMenus(); O.toast('Не вдалося показати: елемент зараз приховано'); GD.open({ back: true }); return; }
    showSpot({ el, title: it.label, text: [it.desc, it.keys ? t('Гаряча клавіша: {k}', { k: it.keys }) : ''].filter(Boolean).join(' '), note, buttons: [back], onButton, pass: true });
  };

  // ---------- commands, menu, top bar button, first run ----------
  O.ICONS.help = O.ICONS.help || '<circle cx="12" cy="12" r="8.5"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6M12 17v.1"/>';
  O.cmd('guide', 'Довідник функцій…', () => GD.open(), { keys: ['F1'], group: 'Довідка' });
  O.cmd('tour', 'Spotlight-тур інтерфейсом', () => GD.tour(), { group: 'Довідка' });
  const help = O.MENUS.find(m => m[0] === 'Довідка');
  if (help) { const i = help[1].indexOf('palette'); help[1].splice(i >= 0 ? i + 1 : 0, 0, 'guide', 'tour'); }
  const addButton = () => {
    const pal = O.$('#btn-palette');
    if (!pal || O.$('#btn-guide')) return;
    const b = O.h(`<button id="btn-guide" class="ib" type="button" title="${esc(t('Довідник функцій'))} (F1)" aria-label="${esc(t('Довідник функцій'))}">${O.icon('help', 16)}</button>`);
    b.addEventListener('click', () => GD.open());
    pal.after(b);
    O.on('lang', () => { b.removeAttribute('title'); b.dataset.tip = t('Довідник функцій') + ' (F1)'; b.setAttribute('aria-label', t('Довідник функцій')); });
  };
  // a small invitation on the first visit (never in self tests and screenshots)
  const invite = () => {
    const p = new URLSearchParams(location.search);
    if (O.ls.get('guideSeen', 0) || ['selftest', 'shot', 'fresh'].some(k => p.has(k))) return;
    if (O.$('.dlg-back, .pal-back, .gd-invite')) { setTimeout(invite, 4000); return; }
    const el = O.h(`<div class="gd-invite" role="dialog" aria-label="${esc(t('Вперше у VIBSma?'))}"><span class="gd-mark">${O.icon('sparkle', 18)}</span><div><b>${esc(t('Вперше у VIBSma?'))}</b><p>${esc(t('Хвилинний тур покаже, де що лежить, а довідник — усі функції з поясненнями.'))}</p>
      <div class="gd-inv-b"><button type="button" class="btn primary" data-gi="tour">${esc(t('Почати тур'))}</button><button type="button" class="btn" data-gi="guide">${esc(t('Довідник'))}</button></div></div>
      <button type="button" class="gd-x" data-gi="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 14)}</button></div>`);
    el.addEventListener('click', e => { const b = e.target.closest('[data-gi]'); if (!b) return; markSeen(); if (b.dataset.gi === 'tour') GD.tour(); else if (b.dataset.gi === 'guide') GD.open(); });
    document.body.appendChild(el);
  };
  const start = () => { addButton(); setTimeout(invite, 1800); };
  if (document.readyState === 'complete') start(); else window.addEventListener('load', start);

  O.i18nAdd([
    ['Ласкаво просимо до VIBSma', 'Welcome to VIBSma', 'Добро пожаловать в VIBSma', 'Willkommen bei VIBSma'],
    ['Короткий тур покаже головні частини редактора. Стрілки ← → або Enter — далі, Esc — вийти.', 'A short tour of the main parts of the editor. Arrows ← → or Enter to move on, Esc to leave.', 'Короткий тур покажет главные части редактора. Стрелки ← → или Enter — дальше, Esc — выйти.', 'Eine kurze Tour durch die wichtigsten Bereiche des Editors. Pfeile ← → oder Enter – weiter, Esc – beenden.'],
    ['Головне меню', 'Main menu', 'Главное меню', 'Hauptmenü'],
    ['Усі меню в одному списку: файл, об’єкт, текст, ефекти, вигляд та інші.', 'All menus in one list: file, object, text, effects, view and more.', 'Все меню в одном списке: файл, объект, текст, эффекты, вид и другие.', 'Alle Menüs in einer Liste: Datei, Objekt, Text, Effekte, Ansicht und mehr.'],
    ['Рядок меню', 'Menu bar', 'Строка меню', 'Menüleiste'],
    ['Команди згруповано як в Illustrator: Файл, Редагування, Об’єкт, Текст, Ефект, Вигляд… Меню, що не вмістилися, ховаються під «⋯».', 'Commands are grouped as in Illustrator: File, Edit, Object, Text, Effect, View… Menus that do not fit move under «⋯».', 'Команды сгруппированы как в Illustrator: Файл, Редактирование, Объект, Текст, Эффект, Вид… Меню, которые не поместились, прячутся под «⋯».', 'Befehle sind wie in Illustrator gruppiert: Datei, Bearbeiten, Objekt, Text, Effekt, Ansicht… Was nicht passt, steckt unter «⋯».'],
    ['Усі проєкти', 'All projects', 'Все проекты', 'Alle Projekte'],
    ['Ваші документи: відкрити, створити, дублювати. Усе зберігається в браузері автоматично.', 'Your documents: open, create, duplicate. Everything is saved in the browser automatically.', 'Ваши документы: открыть, создать, дублировать. Всё сохраняется в браузере автоматически.', 'Ihre Dokumente: öffnen, anlegen, duplizieren. Alles wird automatisch im Browser gespeichert.'],
    ['Набори панелей для дизайну, анімації, вебу й коду. Області можна ділити й міняти.', 'Panel sets for design, animation, web and code. Areas can be split and swapped.', 'Наборы панелей для дизайна, анимации, веба и кода. Области можно делить и менять.', 'Panel-Sets für Design, Animation, Web und Code. Bereiche lassen sich teilen und tauschen.'],
    ['Назва документа', 'Document name', 'Название документа', 'Dokumentname'],
    ['Клацніть, щоб перейменувати. Поруч — назва сторінки і стан збереження.', 'Click to rename. Next to it: the page name and the save status.', 'Щёлкните, чтобы переименовать. Рядом — название страницы и состояние сохранения.', 'Klicken zum Umbenennen. Daneben: Seitenname und Speicherstatus.'],
    ['Spotlight — пошук усього', 'Spotlight — search everything', 'Spotlight — поиск всего', 'Spotlight – alles durchsuchen'],
    ['Ctrl+K: команди, інструменти, шари, шаблони, шрифти, кольори й калькулятор в одному полі. Ctrl+Enter — дизайн з Claude.', 'Ctrl+K: commands, tools, layers, templates, fonts, colours and a calculator in one box. Ctrl+Enter — design with Claude.', 'Ctrl+K: команды, инструменты, слои, шаблоны, шрифты, цвета и калькулятор в одном поле. Ctrl+Enter — дизайн с Claude.', 'Strg+K: Befehle, Werkzeuge, Ebenen, Vorlagen, Schriften, Farben und Rechner in einem Feld. Strg+Enter – Design mit Claude.'],
    ['Виділення, фігури, перо, текст, трансформації. Стрілка біля кнопки відкриває інші інструменти групи; наведіть курсор — побачите опис і клавішу.', 'Selection, shapes, pen, text, transforms. The arrow next to a button opens the other tools of its group; hover to see a description and the key.', 'Выделение, фигуры, перо, текст, трансформации. Стрелка у кнопки открывает другие инструменты группы; наведите курсор — увидите описание и клавишу.', 'Auswahl, Formen, Zeichenstift, Text, Transformieren. Der Pfeil neben einer Schaltfläche öffnet die übrigen Werkzeuge der Gruppe; beim Überfahren erscheinen Beschreibung und Taste.'],
    ['Шари та сторінки', 'Layers and pages', 'Слои и страницы', 'Ebenen und Seiten'],
    ['Структура документа: сторінки вгорі, шари нижче. Перетягуйте, щоб змінити порядок; око й замок — видимість і блокування.', 'The document structure: pages on top, layers below. Drag to reorder; the eye and the lock hide and lock.', 'Структура документа: страницы вверху, слои ниже. Перетаскивайте, чтобы изменить порядок; глаз и замок — видимость и блокировка.', 'Die Dokumentstruktur: oben Seiten, darunter Ebenen. Ziehen zum Umordnen; Auge und Schloss blenden aus und sperren.'],
    ['Компоненти, кольори документа й шрифти, зокрема Google Fonts.', 'Components, document colours and fonts, including Google Fonts.', 'Компоненты, цвета документа и шрифты, в том числе Google Fonts.', 'Komponenten, Dokumentfarben und Schriften, auch Google Fonts.'],
    ['Тут ви малюєте. Пробіл + перетягування — рух, Ctrl + коліщатко — масштаб, правий клік — контекстне меню.', 'This is where you draw. Space + drag pans, Ctrl + wheel zooms, right-click opens the context menu.', 'Здесь вы рисуете. Пробел + перетаскивание — перемещение, Ctrl + колесо — масштаб, правый клик — контекстное меню.', 'Hier wird gezeichnet. Leertaste + Ziehen verschiebt, Strg + Mausrad zoomt, Rechtsklick öffnet das Kontextmenü.'],
    ['Розмір, положення, заливка, обведення, ефекти й текст виділеного. Без виділення — налаштування сторінки.', 'Size, position, fill, stroke, effects and text of the selection. With nothing selected — the page settings.', 'Размер, положение, заливка, обводка, эффекты и текст выделенного. Без выделения — настройки страницы.', 'Größe, Position, Fläche, Kontur, Effekte und Text der Auswahl. Ohne Auswahl – die Seiteneinstellungen.'],
    ['CSS, SVG та інший код виділеного об’єкта — для розробників.', 'CSS, SVG and other code of the selected object — for developers.', 'CSS, SVG и другой код выделенного объекта — для разработчиков.', 'CSS, SVG und weiterer Code des ausgewählten Objekts – für Entwickler.'],
    ['Поточний масштаб; у меню — показати все, до виділення, 100%.', 'The current zoom; its menu has fit all, zoom to selection, 100%.', 'Текущий масштаб; в меню — показать всё, к выделению, 100%.', 'Der aktuelle Zoom; im Menü: alles zeigen, auf Auswahl, 100 %.'],
    ['Презентація', 'Presentation', 'Презентация', 'Präsentation'],
    ['Показує фрейми як слайди на весь екран (W).', 'Shows the frames as full-screen slides (W).', 'Показывает фреймы как слайды на весь экран (W).', 'Zeigt die Frames als Folien im Vollbild (W).'],
    ['Мова й тема', 'Language and theme', 'Язык и тема', 'Sprache und Design'],
    ['Українська, English, Русский, Deutsch; кнопка поруч перемикає світлу й темну тему.', 'Українська, English, Русский, Deutsch; the button next to it switches the light and dark theme.', 'Українська, English, Русский, Deutsch; кнопка рядом переключает светлую и тёмную тему.', 'Українська, English, Русский, Deutsch; die Schaltfläche daneben wechselt zwischen hellem und dunklem Design.'],
    ['PNG, JPG, SVG, PDF та формати інших програм (Ctrl+Shift+E).', 'PNG, JPG, SVG, PDF and formats of other apps (Ctrl+Shift+E).', 'PNG, JPG, SVG, PDF и форматы других программ (Ctrl+Shift+E).', 'PNG, JPG, SVG, PDF und Formate anderer Programme (Strg+Umschalt+E).'],
    ['Довідник функцій', 'Feature guide', 'Справочник функций', 'Funktionsübersicht'],
    ['Довідник функцій…', 'Feature guide…', 'Справочник функций…', 'Funktionsübersicht…'],
    ['Усі функції з поясненнями, пошуком і кнопкою «Показати де». Відкривається клавішею F1; звідти ж можна пройти тур знову.', 'Every feature with explanations, search and a «Show where» button. Opens with F1; you can take the tour again from there.', 'Все функции с пояснениями, поиском и кнопкой «Показать где». Открывается клавишей F1; оттуда же можно пройти тур снова.', 'Alle Funktionen mit Erklärungen, Suche und der Schaltfläche «Zeigen, wo». Öffnet mit F1; dort lässt sich die Tour wiederholen.'],
    ['Spotlight-тур інтерфейсом', 'Spotlight tour of the interface', 'Spotlight-тур по интерфейсу', 'Spotlight-Tour durch die Oberfläche'],
    ['Створення, відкриття й збереження документів, імпорт (SVG, PDF, PSD, Figma), експорт у всі формати, шаблони й проєкти.', 'Create, open and save documents, import (SVG, PDF, PSD, Figma), export to every format, templates and projects.', 'Создание, открытие и сохранение документов, импорт (SVG, PDF, PSD, Figma), экспорт во все форматы, шаблоны и проекты.', 'Dokumente anlegen, öffnen und speichern, Import (SVG, PDF, PSD, Figma), Export in alle Formate, Vorlagen und Projekte.'],
    ['Скасування й повтор, буфер обміну, копіювання властивостей, дублювання й видалення.', 'Undo and redo, the clipboard, copying properties, duplicating and deleting.', 'Отмена и повтор, буфер обмена, копирование свойств, дублирование и удаление.', 'Rückgängig und Wiederholen, Zwischenablage, Eigenschaften kopieren, Duplizieren und Löschen.'],
    ['Усе, що робиться з виділеними об’єктами: трансформації, порядок, вирівнювання, групи, булеві операції, обробка контурів, маски, компоненти, трасування.', 'Everything you do with selected objects: transforms, order, alignment, groups, boolean operations, pathfinder, masks, components, tracing.', 'Всё, что делается с выделенными объектами: трансформации, порядок, выравнивание, группы, булевы операции, обработка контуров, маски, компоненты, трассировка.', 'Alles, was mit ausgewählten Objekten geschieht: Transformieren, Anordnen, Ausrichten, Gruppen, boolesche Operationen, Pathfinder, Masken, Komponenten, Nachzeichnen.'],
    ['Растрові фото: режими кольору, корекція (рівні, криві, тон), розмір зображення й полотна, поворот і кадрування.', 'Raster photos: colour modes, adjustments (levels, curves, hue), image and canvas size, rotation and cropping.', 'Растровые фото: цветовые режимы, коррекция (уровни, кривые, тон), размер изображения и холста, поворот и кадрирование.', 'Rasterfotos: Farbmodi, Korrekturen (Tonwerte, Kurven, Farbton), Bild- und Arbeitsflächengröße, Drehen und Freistellen.'],
    ['Шрифти, символ і абзац, стилі, списки, спецсимволи, примітки, гіперпосилання, текст на контурі й перетворення на криві.', 'Fonts, character and paragraph, styles, lists, special characters, notes, hyperlinks, type on a path and converting to outlines.', 'Шрифты, символ и абзац, стили, списки, спецсимволы, примечания, гиперссылки, текст на контуре и преобразование в кривые.', 'Schriften, Zeichen und Absatz, Formate, Listen, Sonderzeichen, Notizen, Hyperlinks, Pfadtext und Umwandeln in Pfade.'],
    ['Виділити все, інвертувати, вибрати схожі об’єкти за заливкою, обведенням чи типом, зберегти виділення.', 'Select all, invert, pick similar objects by fill, stroke or type, save a selection.', 'Выделить всё, инвертировать, выбрать похожие объекты по заливке, обводке или типу, сохранить выделение.', 'Alles auswählen, umkehren, ähnliche Objekte nach Fläche, Kontur oder Typ wählen, Auswahl speichern.'],
    ['Тіні, світіння, розмиття, Liquid Glass, спотворення контурів і бібліотека стилів.', 'Shadows, glows, blur, Liquid Glass, path distortions and the style library.', 'Тени, свечение, размытие, Liquid Glass, искажения контуров и библиотека стилей.', 'Schatten, Schein, Weichzeichnen, Liquid Glass, Pfadverzerrungen und die Stilbibliothek.'],
    ['Фільтри для фото як у Photoshop: різкість, шум, розмиття, стилізація, спотворення, нейрофільтри.', 'Photoshop-style photo filters: sharpen, noise, blur, stylize, distort, neural filters.', 'Фильтры для фото как в Photoshop: резкость, шум, размытие, стилизация, искажение, нейрофильтры.', 'Fotofilter wie in Photoshop: Scharfzeichnen, Rauschen, Weichzeichnen, Stilisieren, Verzerren, Neural Filters.'],
    ['Таймлайн, ключові кадри, готові пресети руху й експорт Lottie.', 'The timeline, keyframes, ready-made motion presets and Lottie export.', 'Таймлайн, ключевые кадры, готовые пресеты движения и экспорт Lottie.', 'Zeitleiste, Keyframes, fertige Bewegungsvorgaben und Lottie-Export.'],
    ['Журнали й книжки як в InDesign: сторінки, шаблонні сторінки, колонки, базова сітка, зв’язані текстові фрейми, preflight і PDF.', 'Magazines and books as in InDesign: pages, master pages, columns, the baseline grid, threaded text frames, preflight and PDF.', 'Журналы и книги как в InDesign: страницы, шаблонные страницы, колонки, базовая сетка, связанные текстовые фреймы, preflight и PDF.', 'Magazine und Bücher wie in InDesign: Seiten, Musterseiten, Spalten, Grundlinienraster, verkettete Textrahmen, Preflight und PDF.'],
    ['Інтерактивні переходи між фреймами й перегляд прототипу.', 'Interactive transitions between frames and the prototype preview.', 'Интерактивные переходы между фреймами и просмотр прототипа.', 'Interaktive Übergänge zwischen Frames und die Prototyp-Vorschau.'],
    ['Коментарі, спільне редагування в реальному часі й посилання для доступу.', 'Comments, real-time co-editing and share links.', 'Комментарии, совместное редактирование в реальном времени и ссылки для доступа.', 'Kommentare, gemeinsames Bearbeiten in Echtzeit und Freigabelinks.'],
    ['Вбудовані помічники: контраст WCAG, перейменування шарів, пошук і заміна, палітри, фото-заповнювачі.', 'Built-in helpers: WCAG contrast, layer renaming, find and replace, palettes, placeholder photos.', 'Встроенные помощники: контраст WCAG, переименование слоёв, поиск и замена, палитры, фото-заполнители.', 'Eingebaute Helfer: WCAG-Kontrast, Ebenen umbenennen, Suchen und Ersetzen, Paletten, Platzhalterfotos.'],
    ['Стилі інтер’єру, матеріали-текстури й мудборди.', 'Interior styles, material textures and moodboards.', 'Стили интерьера, материалы-текстуры и мудборды.', 'Einrichtungsstile, Materialtexturen und Moodboards.'],
    ['Відеоредактор, музична студія й шаблони відео та треків.', 'The video editor, the music studio and video and track templates.', 'Видеоредактор, музыкальная студия и шаблоны видео и треков.', 'Videoeditor, Musikstudio sowie Video- und Track-Vorlagen.'],
    ['Масштаб, лінійки, напрямні, сітки, прив’язки, тема, мова й робочі простори.', 'Zoom, rulers, guides, grids, snapping, theme, language and workspaces.', 'Масштаб, линейки, направляющие, сетки, привязки, тема, язык и рабочие пространства.', 'Zoom, Lineale, Hilfslinien, Raster, Ausrichten, Design, Sprache und Arbeitsbereiche.'],
    ['Spotlight, гарячі клавіші, цей довідник, тур і поради з перенесення робіт з інших програм.', 'Spotlight, keyboard shortcuts, this guide, the tour and tips for moving work from other apps.', 'Spotlight, горячие клавиши, этот справочник, тур и советы по переносу работ из других программ.', 'Spotlight, Tastenkürzel, diese Übersicht, die Tour und Tipps zum Umzug aus anderen Programmen.'],
    ['Інтерфейс', 'Interface', 'Интерфейс', 'Oberfläche'],
    ['Головні частини вікна. «Показати де» підсвічує кожну з них.', 'The main parts of the window. «Show where» lights each of them up.', 'Главные части окна. «Показать где» подсвечивает каждую из них.', 'Die Hauptbereiche des Fensters. «Zeigen, wo» hebt jeden hervor.'],
    ['Інструменти на панелі внизу полотна. Клавіша вмикає інструмент; Shift і Alt під час малювання змінюють поведінку.', 'Tools on the bar at the bottom of the canvas. The key picks a tool; Shift and Alt change how it draws.', 'Инструменты на панели внизу холста. Клавиша включает инструмент; Shift и Alt во время рисования меняют поведение.', 'Werkzeuge in der Leiste unten auf der Arbeitsfläche. Die Taste wählt das Werkzeug; Umschalt und Alt ändern das Zeichnen.'],
    ['Інші команди', 'Other commands', 'Другие команды', 'Weitere Befehle'],
    ['Команди, яких немає в меню: доступні через Spotlight (Ctrl+K), панелі або гарячі клавіші.', 'Commands that are not in a menu: reach them through Spotlight (Ctrl+K), the panels or shortcuts.', 'Команды, которых нет в меню: доступны через Spotlight (Ctrl+K), панели или горячие клавиши.', 'Befehle ohne Menüeintrag: erreichbar über Spotlight (Strg+K), die Bedienfelder oder Tastenkürzel.'],
    ['Малює траєкторію руху: об’єкт пролетить уздовж лінії в анімації.', 'Draws a motion path: the object travels along the line in the animation.', 'Рисует траекторию движения: объект пролетит вдоль линии в анимации.', 'Zeichnet einen Bewegungspfad: Das Objekt folgt der Linie in der Animation.'],
    ['З’єднує формати сайту: зміни в одному фреймі переносяться на зв’язані.', 'Links site formats: changes in one frame carry over to the linked ones.', 'Связывает форматы сайта: изменения в одном фрейме переносятся на связанные.', 'Verknüpft Website-Formate: Änderungen in einem Frame gehen auf die verknüpften über.'],
    ['Протягніть від об’єкта до фрейма — вийде перехід у прототипі.', 'Drag from an object to a frame to make a prototype transition.', 'Протяните от объекта к фрейму — получится переход в прототипе.', 'Von einem Objekt zu einem Frame ziehen ergibt einen Prototyp-Übergang.'],
    ['Створює новий проєкт; поточний лишається в «Усіх проєктах».', 'Creates a new project; the current one stays in «All projects».', 'Создаёт новый проект; текущий остаётся во «Всех проектах».', 'Legt ein neues Projekt an; das aktuelle bleibt unter «Alle Projekte».'],
    ['Відкриває файл .obrys, SVG, PDF, зображення та інші підтримувані формати.', 'Opens an .obrys file, SVG, PDF, images and other supported formats.', 'Открывает файл .obrys, SVG, PDF, изображения и другие поддерживаемые форматы.', 'Öffnet .obrys-Dateien, SVG, PDF, Bilder und weitere unterstützte Formate.'],
    ['Зберігає документ у файл .obrys (у браузері він і так зберігається автоматично).', 'Saves the document as an .obrys file (it is saved in the browser automatically anyway).', 'Сохраняет документ в файл .obrys (в браузере он и так сохраняется автоматически).', 'Speichert das Dokument als .obrys-Datei (im Browser wird es ohnehin automatisch gespeichert).'],
    ['Додає фото, відео або аудіо з диска на полотно.', 'Adds a photo, video or audio file from disk to the canvas.', 'Добавляет фото, видео или аудио с диска на холст.', 'Fügt ein Foto, Video oder Audio von der Festplatte auf die Arbeitsfläche ein.'],
    ['Експорт сторінки, фреймів або виділеного в PNG, JPG, WEBP, SVG чи PDF з вибором масштабу.', 'Exports the page, frames or the selection to PNG, JPG, WEBP, SVG or PDF at a chosen scale.', 'Экспорт страницы, фреймов или выделенного в PNG, JPG, WEBP, SVG или PDF с выбором масштаба.', 'Exportiert Seite, Frames oder Auswahl als PNG, JPG, WEBP, SVG oder PDF in wählbarer Skalierung.'],
    ['Показує фрейми сторінки як слайди на весь екран.', 'Shows the page frames as full-screen slides.', 'Показывает фреймы страницы как слайды на весь экран.', 'Zeigt die Frames der Seite als Folien im Vollbild.'],
    ['Опишіть дизайн словами — Claude створить редагований макет.', 'Describe a design in words and Claude makes an editable layout.', 'Опишите дизайн словами — Claude создаст редактируемый макет.', 'Beschreiben Sie ein Design in Worten – Claude erstellt ein bearbeitbares Layout.'],
    ['Скасовує останню дію. Історія змін — у меню «Вигляд».', 'Undoes the last action. The change history is in the «View» menu.', 'Отменяет последнее действие. История изменений — в меню «Вид».', 'Macht den letzten Schritt rückgängig. Der Verlauf steht im Menü «Ansicht».'],
    ['Копіює заливку, обведення й ефекти, щоб вставити їх на інші об’єкти.', 'Copies the fill, stroke and effects to paste them onto other objects.', 'Копирует заливку, обводку и эффекты, чтобы вставить их на другие объекты.', 'Kopiert Fläche, Kontur und Effekte, um sie auf andere Objekte zu übertragen.'],
    ['Створює копію поруч; Alt + перетягування робить те саме мишею.', 'Makes a copy next to it; Alt + drag does the same with the mouse.', 'Создаёт копию рядом; Alt + перетаскивание делает то же мышью.', 'Erstellt daneben eine Kopie; Alt + Ziehen macht dasselbe mit der Maus.'],
    ['Об’єднує виділене в групу, яку можна рухати й масштабувати як одне ціле.', 'Puts the selection into a group that moves and scales as one.', 'Объединяет выделенное в группу, которую можно двигать и масштабировать как единое целое.', 'Fasst die Auswahl zu einer Gruppe zusammen, die sich als Ganzes bewegen und skalieren lässt.'],
    ['Огортає виділене фреймом — контейнером з власним фоном і обрізанням.', 'Wraps the selection in a frame — a container with its own background and clipping.', 'Оборачивает выделенное фреймом — контейнером со своим фоном и обрезкой.', 'Umschließt die Auswahl mit einem Frame – einem Container mit eigenem Hintergrund und Beschnitt.'],
    ['Фрейм сам розкладає вміст у рядок чи стовпець із проміжками й полями, як у Figma.', 'The frame lays its content out in a row or column with gaps and padding, as in Figma.', 'Фрейм сам раскладывает содержимое в строку или столбец с промежутками и полями, как в Figma.', 'Der Frame ordnet seinen Inhalt in Zeile oder Spalte mit Abständen und Innenrand an, wie in Figma.'],
    ['Перетворює фігури, булеві групи, текст і екземпляри на звичайні контури.', 'Turns shapes, boolean groups, text and instances into plain paths.', 'Превращает фигуры, булевы группы, текст и экземпляры в обычные контуры.', 'Wandelt Formen, boolesche Gruppen, Text und Instanzen in einfache Pfade um.'],
    ['Живе об’єднання: фігури зливаються в одну, але кожну можна далі редагувати всередині групи.', 'Live union: the shapes become one, yet each stays editable inside the group.', 'Живое объединение: фигуры сливаются в одну, но каждую можно дальше редактировать внутри группы.', 'Live-Vereinigen: Die Formen werden eins, bleiben aber in der Gruppe einzeln bearbeitbar.'],
    ['Живе віднімання: верхні фігури вирізають форму з нижньої.', 'Live subtract: the upper shapes cut their form out of the bottom one.', 'Живое вычитание: верхние фигуры вырезают форму из нижней.', 'Live-Subtrahieren: Die oberen Formen schneiden ihre Form aus der unteren.'],
    ['Живий перетин: лишається тільки спільна частина фігур.', 'Live intersect: only the part the shapes share remains.', 'Живое пересечение: остаётся только общая часть фигур.', 'Live-Schnittmenge: Nur der gemeinsame Teil der Formen bleibt.'],
    ['Живе виключення: лишається все, крім місць перекриття.', 'Live exclude: everything except the overlaps remains.', 'Живое исключение: остаётся всё, кроме мест перекрытия.', 'Live-Ausschließen: Alles außer den Überlappungen bleibt.'],
    ['Зводить виділене в один редагований контур.', 'Flattens the selection into one editable path.', 'Сводит выделенное в один редактируемый контур.', 'Reduziert die Auswahl auf einen bearbeitbaren Pfad.'],
    ['Остаточно об’єднує фігури в один контур зі стилем верхньої.', 'Merges the shapes into one path for good, with the style of the top one.', 'Окончательно объединяет фигуры в один контур со стилем верхней.', 'Vereinigt die Formen dauerhaft zu einem Pfad mit dem Stil der obersten.'],
    ['Вирізає верхні фігури з нижньої й видаляє їх.', 'Cuts the upper shapes out of the bottom one and removes them.', 'Вырезает верхние фигуры из нижней и удаляет их.', 'Schneidet die oberen Formen aus der unteren und entfernt sie.'],
    ['Лишає тільки область, спільну для всіх фігур.', 'Keeps only the area all shapes share.', 'Оставляет только область, общую для всех фигур.', 'Behält nur die Fläche, die alle Formen gemeinsam haben.'],
    ['Лишає області, що не перекриваються.', 'Keeps the areas that do not overlap.', 'Оставляет области, которые не перекрываются.', 'Behält die Flächen, die sich nicht überlappen.'],
    ['Розрізає фігури по всіх перетинах на окремі шматки (результат — група).', 'Cuts the shapes along every intersection into separate pieces (the result is a group).', 'Разрезает фигуры по всем пересечениям на отдельные куски (результат — группа).', 'Zerteilt die Formen an allen Schnittlinien in einzelne Stücke (Ergebnis ist eine Gruppe).'],
    ['Видаляє приховані частини фігур і обведення; фігури однакового кольору не зливаються.', 'Removes the hidden parts of shapes and the strokes; shapes of the same colour stay separate.', 'Удаляет скрытые части фигур и обводки; фигуры одного цвета не сливаются.', 'Entfernt verdeckte Teile der Formen und die Konturen; gleichfarbige Formen bleiben getrennt.'],
    ['Видаляє приховані частини й зливає фігури однакового кольору. Контур лише з обведенням стає смугою кольору обведення.', 'Removes the hidden parts and merges shapes of the same colour. A path with only a stroke becomes a band in the stroke colour.', 'Удаляет скрытые части и сливает фигуры одного цвета. Контур только с обводкой становится полосой цвета обводки.', 'Entfernt verdeckte Teile und verschmilzt gleichfarbige Formen. Ein Pfad nur mit Kontur wird zu einem Band in der Konturfarbe.'],
    ['Обрізає нижні фігури по формі верхньої; верхня зникає.', 'Crops the lower shapes to the shape of the top one; the top one goes away.', 'Обрезает нижние фигуры по форме верхней; верхняя исчезает.', 'Beschneidet die unteren Formen auf die Form der obersten; die oberste verschwindet.'],
    ['Розбиває фігури на окремі лінії з кольором заливки як обведенням.', 'Breaks the shapes into separate lines, stroked with their fill colour.', 'Разбивает фигуры на отдельные линии с цветом заливки в качестве обводки.', 'Zerlegt die Formen in einzelne Linien mit der Flächenfarbe als Kontur.'],
    ['Вирізає з верхньої фігури всі, що лежать під нею.', 'Cuts every shape beneath it out of the top shape.', 'Вырезает из верхней фигуры все, что лежат под ней.', 'Schneidet alle darunterliegenden Formen aus der obersten Form.'],
    ['Верхній об’єкт стає маскою: видно лише те, що всередині нього.', 'The top object becomes a mask: only what lies inside it stays visible.', 'Верхний объект становится маской: видно только то, что внутри него.', 'Das oberste Objekt wird zur Maske: Sichtbar bleibt nur, was darin liegt.'],
    ['Зводить кілька контурів в один; там, де вони перекриваються, з’являються отвори.', 'Combines several paths into one; where they overlap, holes appear.', 'Сводит несколько контуров в один; там, где они перекрываются, появляются отверстия.', 'Fasst mehrere Pfade zu einem zusammen; wo sie sich überlappen, entstehen Löcher.'],
    ['Будує плавний перехід форми й кольору між двома об’єктами.', 'Builds a smooth blend of shape and colour between two objects.', 'Строит плавный переход формы и цвета между двумя объектами.', 'Erzeugt einen weichen Übergang von Form und Farbe zwischen zwei Objekten.'],
    ['Робить з виділеного компонент; його екземпляри оновлюються разом з ним.', 'Turns the selection into a component; its instances update with it.', 'Делает из выделенного компонент; его экземпляры обновляются вместе с ним.', 'Macht aus der Auswahl eine Komponente; ihre Instanzen ändern sich mit.'],
    ['Перетворює обведення на заповнену фігуру тієї ж форми.', 'Turns the stroke into a filled shape of the same form.', 'Превращает обводку в заполненную фигуру той же формы.', 'Wandelt die Kontur in eine gefüllte Form gleicher Gestalt um.'],
    ['Створює контур, віддалений від оригіналу на задану відстань.', 'Creates a path offset from the original by a set distance.', 'Создаёт контур, отстоящий от оригинала на заданное расстояние.', 'Erzeugt einen Pfad im gewählten Abstand zum Original.'],
    ['Зменшує кількість вузлів, зберігаючи форму.', 'Reduces the number of anchors while keeping the shape.', 'Уменьшает количество узлов, сохраняя форму.', 'Verringert die Zahl der Ankerpunkte und erhält die Form.'],
    ['Перетворює текст на криві — шрифт більше не потрібен, але текст не редагується.', 'Turns text into outlines — the font is no longer needed, but the text can no longer be edited.', 'Превращает текст в кривые — шрифт больше не нужен, но текст не редактируется.', 'Wandelt Text in Pfade um – die Schrift wird nicht mehr gebraucht, der Text ist aber nicht mehr editierbar.'],
    ['Розміщує виділений текст уздовж виділеного контуру.', 'Places the selected text along the selected path.', 'Размещает выделенный текст вдоль выделенного контура.', 'Setzt den ausgewählten Text auf den ausgewählten Pfad.'],
    ['Перетворює растрове зображення на векторні фігури.', 'Turns a raster image into vector shapes.', 'Превращает растровое изображение в векторные фигуры.', 'Wandelt ein Rasterbild in Vektorformen um.'],
    ['Перетворює вектор на растрове зображення.', 'Turns vectors into a raster image.', 'Превращает вектор в растровое изображение.', 'Wandelt Vektoren in ein Rasterbild um.'],
    ['Показує весь вміст сторінки у вікні.', 'Fits the whole page content in the window.', 'Показывает всё содержимое страницы в окне.', 'Zeigt den gesamten Seiteninhalt im Fenster.'],
    ['Показує лише контури без заливок — зручно для точного редагування.', 'Shows only outlines without fills — handy for precise editing.', 'Показывает только контуры без заливок — удобно для точного редактирования.', 'Zeigt nur Umrisse ohne Flächen – praktisch für genaues Bearbeiten.'],
    ['Підказки вирівнювання й відстаней під час переміщення.', 'Alignment and spacing hints while you move things.', 'Подсказки выравнивания и расстояний при перемещении.', 'Ausrichtungs- und Abstandshinweise beim Verschieben.'],
    ['Ховає всі панелі, лишаючи тільки полотно.', 'Hides all panels and leaves only the canvas.', 'Скрывает все панели, оставляя только холст.', 'Blendet alle Bedienfelder aus, nur die Arbeitsfläche bleibt.'],
    ['Показує таймлайн анімації з ключовими кадрами.', 'Shows the animation timeline with keyframes.', 'Показывает таймлайн анимации с ключевыми кадрами.', 'Zeigt die Animations-Zeitleiste mit Keyframes.'],
    ['Відкриває Spotlight: пошук команд, шарів, шаблонів і шрифтів.', 'Opens Spotlight: search for commands, layers, templates and fonts.', 'Открывает Spotlight: поиск команд, слоёв, шаблонов и шрифтов.', 'Öffnet Spotlight: Suche nach Befehlen, Ebenen, Vorlagen und Schriften.'],
    ['Список усіх гарячих клавіш.', 'A list of every keyboard shortcut.', 'Список всех горячих клавиш.', 'Eine Liste aller Tastenkürzel.'],
    ['Пропустити', 'Skip', 'Пропустить', 'Überspringen'],
    ['Функцій: {n}', 'Features: {n}', 'Функций: {n}', 'Funktionen: {n}'],
    ['Шукати функцію…', 'Search features…', 'Искать функцию…', 'Funktion suchen…'],
    ['Почати тур', 'Start tour', 'Начать тур', 'Tour starten'],
    ['Розділи', 'Sections', 'Разделы', 'Abschnitte'],
    ['Показати де', 'Show where', 'Показать где', 'Zeigen, wo'],
    ['Виконати', 'Run', 'Выполнить', 'Ausführen'],
    ['Зараз недоступно: спершу виділіть потрібні об’єкти', 'Not available right now: first select the objects it works on', 'Сейчас недоступно: сначала выделите нужные объекты', 'Gerade nicht verfügbar: zuerst die passenden Objekte auswählen'],
    ['Панель інструментів', 'Toolbar', 'Панель инструментов', 'Werkzeugleiste'],
    ['Лише через Spotlight (Ctrl+K) або гарячу клавішу', 'Only through Spotlight (Ctrl+K) or a shortcut', 'Только через Spotlight (Ctrl+K) или горячую клавишу', 'Nur über Spotlight (Strg+K) oder ein Tastenkürzel'],
    ['До довідника', 'Back to the guide', 'К справочнику', 'Zur Übersicht'],
    ['Клацніть підсвічений пункт, щоб виконати команду, або будь-де, щоб закрити.', 'Click the highlighted item to run the command, or anywhere else to close.', 'Щёлкните подсвеченный пункт, чтобы выполнить команду, или в любом другом месте, чтобы закрыть.', 'Klicken Sie auf den hervorgehobenen Eintrag, um den Befehl auszuführen, oder irgendwo anders, um zu schließen.'],
    ['Відкрийте Spotlight (Ctrl+K) і почніть вводити «{q}».', 'Open Spotlight (Ctrl+K) and start typing «{q}».', 'Откройте Spotlight (Ctrl+K) и начните вводить «{q}».', 'Öffnen Sie Spotlight (Strg+K) und tippen Sie «{q}».'],
    ['Гаряча клавіша: {k}', 'Shortcut: {k}', 'Горячая клавиша: {k}', 'Tastenkürzel: {k}'],
    ['Не вдалося показати: елемент зараз приховано', 'Can’t show it: the element is hidden right now', 'Не удалось показать: элемент сейчас скрыт', 'Kann nicht gezeigt werden: Das Element ist gerade ausgeblendet'],
    ['Вперше у VIBSma?', 'New to VIBSma?', 'Впервые в VIBSma?', 'Neu in VIBSma?'],
    ['Хвилинний тур покаже, де що лежить, а довідник — усі функції з поясненнями.', 'A one-minute tour shows where everything is, and the guide lists every feature with explanations.', 'Минутный тур покажет, где что лежит, а справочник — все функции с пояснениями.', 'Eine einminütige Tour zeigt, wo alles ist, und die Übersicht erklärt jede Funktion.'],
    ['Довідник', 'Guide', 'Справочник', 'Übersicht']
  ]);
})();
