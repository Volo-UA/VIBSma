'use strict';
/* VIBSma — template library in the spirit of Canva: the same kinds of designs (Instagram posts and stories,
   YouTube thumbnails, presentations, posters, flyers, résumés, logos, business cards, invitations, certificates,
   menus, infographics, banners…), each in many layouts × 100 colour-and-font styles. Every template is original
   VIBSma artwork and fully editable: it becomes frames with ordinary layers. «Преміум» marks the richer layouts —
   in VIBSma they are free as well. */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui, V = O.view, M = O.M;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const TP = O.templates = {};

  // ======================================================================
  // CATEGORIES: [id, name, w, h, layouts, texts{kicker,title,sub,body,cta,extra}, pages?]
  // ======================================================================
  const TX = (kicker, title, sub, body, cta, extra) => ({ kicker, title, sub, body, cta, extra });
  TP.CATS = [
    ['insta', 'Пост Instagram', 1080, 1080, ['hero', 'split', 'bold', 'photo', 'gradient', 'shapes', 'frame', 'quote'], TX('Новий сезон', 'Розпродаж до −50%', 'Лише цього тижня', 'Оберіть улюблене й отримайте подарунок до кожного замовлення.', 'Купити зараз', '@vibsma.studio')],
    ['story', 'Сторіз Instagram', 1080, 1920, ['photo', 'hero', 'gradient', 'bold', 'split', 'minimal'], TX('Сьогодні о 19:00', 'Прямий ефір', 'Відповідаємо на ваші запитання', 'Ставте питання у коментарях — розберемо найцікавіші.', 'Нагадати мені', '@vibsma.studio')],
    ['fbpost', 'Пост Facebook', 1200, 630, ['split', 'hero', 'banner', 'gradient', 'photo'], TX('Анонс', 'Відкриваємо нову студію', 'Запрошуємо на свято 25 травня', 'Майстер-класи, музика й частування для всієї родини.', 'Детальніше', 'vibsma.com')],
    ['ytthumb', 'Мініатюра YouTube', 1280, 720, ['bold', 'split', 'photo', 'gradient', 'shapes'], TX('Новий випуск', '10 порад, які змінять усе', 'Дивіться до кінця!', '', 'Дивитися', '12:45')],
    ['ytbanner', 'Банер YouTube', 2560, 1440, ['banner', 'gradient', 'shapes'], TX('Щотижня нове відео', 'Творча кухня', 'Дизайн · Фото · Відео', '', 'Підписатися', 'youtube.com/@vibsma')],
    ['slides', 'Презентація', 1920, 1080, ['split', 'hero', 'minimal', 'gradient', 'shapes', 'magazine'], TX('Звіт за квартал', 'Стратегія росту 2026', 'Команда продукту', 'Ключові результати, плани й наступні кроки.', 'Почнемо', 'vibsma.com'), 4],
    ['poster', 'Постер', 842, 1191, ['hero', 'bold', 'photo', 'frame', 'gradient', 'shapes', 'magazine'], TX('Фестиваль', 'Літо звуку', '12–14 липня · Парк Шевченка', 'Понад 30 гуртів, фудкорт і нічна сцена.', 'Квитки онлайн', 'summer-sound.ua')],
    ['flyer', 'Флаєр', 595, 842, ['split', 'hero', 'grid', 'photo', 'frame', 'magazine'], TX('Акція', 'Курси англійської', 'Перше заняття безкоштовно', 'Невеликі групи, сертифіковані викладачі, зручний розклад.', 'Записатися', '+380 67 123 45 67')],
    ['resume', 'Резюме', 595, 842, ['cv-ats', 'cv-classic', 'cv-minimal', 'cv-modern', 'cv-elegant', 'cv-bold'], TX('', '', '', '', '', '')],
    ['logo', 'Логотип', 500, 500, ['logo-badge', 'logo-mono', 'logo-word', 'logo-circle'], TX('', 'Студія', 'дизайн і бренд', '', '', 'EST. 2026')],
    ['bcard', 'Візитка', 1050, 600, ['card-split', 'card-minimal', 'card-bold'], TX('', 'Олена Коваленко', 'Арт-директорка', '', '', 'olena@vibsma.com · +380 67 123 45 67')],
    ['invite', 'Запрошення', 1050, 1500, ['frame', 'hero', 'cert-lite', 'gradient', 'minimal'], TX('Запрошуємо на', 'Весілля Анни та Марка', '14 вересня 2026 · 16:00', 'Ресторан «Сад», вул. Квіткова, 7', 'Підтвердити до 1 вересня', 'А & М')],
    ['card', 'Листівка', 1500, 1050, ['hero', 'frame', 'gradient', 'shapes', 'quote'], TX('З днем народження', 'Щастя, світла й мрій!', 'Від усієї команди', '', '', '♥')],
    ['cert', 'Сертифікат', 842, 595, ['cert', 'cert-modern', 'cert-lite'], TX('Сертифікат', 'Олена Коваленко', 'успішно завершила курс «Графічний дизайн»', 'Київ · 20 жовтня 2026', '', 'Директорка школи')],
    ['menu', 'Меню', 595, 842, ['menu', 'menu-split'], TX('Ресторан', 'Меню', 'Сезонна кухня', '', '', 'Ціни вказано в гривнях')],
    ['info', 'Інфографіка', 800, 2000, ['info-steps', 'info-stats'], TX('Дослідження 2026', 'Як ми працюємо', 'Чотири кроки до результату', 'Пояснюємо процес простими словами.', '', 'Джерело: VIBSma')],
    ['pin', 'Пін Pinterest', 1000, 1500, ['photo', 'hero', 'split', 'magazine', 'gradient'], TX('Ідея на вихідні', '7 затишних інтер’єрів', 'Збережіть, щоб не загубити', 'Прості кроки й підбірка кольорів.', 'Читати', 'vibsma.com')],
    ['linkedin', 'Банер LinkedIn', 1584, 396, ['banner', 'gradient', 'shapes'], TX('', 'Олена Коваленко', 'Дизайн продуктів · Брендинг · UX', '', '', 'vibsma.com')],
    ['fbcover', 'Обкладинка Facebook', 1640, 624, ['banner', 'gradient', 'split'], TX('Ласкаво просимо', 'Кав’ярня «Зерно»', 'Свіжа обсмажка щодня', '', '', 'вул. Хрещатик, 1')],
    ['xpost', 'Пост X (Twitter)', 1600, 900, ['split', 'hero', 'quote', 'gradient'], TX('Думка дня', 'Простота — найвища витонченість', 'Леонардо да Вінчі', '', '', '@vibsma')],
    ['email', 'Заголовок листа', 600, 200, ['banner', 'gradient'], TX('', 'Новини місяця', 'Жовтень 2026', '', '', 'VIBSma')],
    ['calendar', 'Календар', 842, 595, ['calendar'], TX('2026', 'Жовтень', '', '', '', '')],
    ['planner', 'Планер', 595, 842, ['planner'], TX('Тиждень', 'Мій планер', '', '', '', 'Головне сьогодні')],
    ['sticker', 'Наліпка', 600, 600, ['logo-badge', 'logo-circle', 'badge'], TX('', 'Зроблено з любов’ю', '100% натуральне', '', '', '★')],
    ['book', 'Обкладинка книги', 1600, 2560, ['hero', 'photo', 'bold', 'frame', 'magazine'], TX('Роман', 'Тиша над морем', 'Марія Левченко', '«Книга, яку неможливо відкласти»', '', 'Видавництво «Світанок»')],
    ['gift', 'Подарунковий сертифікат', 1200, 600, ['card-split', 'cert-modern', 'gradient'], TX('Подарунковий сертифікат', '1000 ₴', 'на будь-які послуги студії', 'Дійсний до 31.12.2026', '', '№ 0001')],
    ['letter', 'Фірмовий бланк', 595, 842, ['letterhead'], TX('', 'Студія VIBSma', 'Дизайн і бренд', 'Шановні партнери! Дякуємо за співпрацю. Цей лист — приклад фірмового бланка: замініть текст на свій.', '', 'вул. Хрещатик, 1 · Київ · hello@vibsma.com')],
    ['brochure', 'Буклет (3 згини)', 842, 595, ['brochure'], TX('Про нас', 'Школа дизайну', 'Навчаємо з 2016 року', 'Практичні курси з графічного дизайну, UX та брендингу. Невеликі групи й портфоліо на виході.', 'Записатися', '+380 67 123 45 67'), 2]
  ];
  // the richer layouts are «Premium» (Canva Pro); the rest are «Basic»
  TP.PREMIUM = new Set(['gradient', 'shapes', 'magazine', 'cv-modern', 'cv-elegant', 'cert-modern', 'info-stats', 'menu-split', 'logo-circle', 'card-bold', 'brochure', 'quote']);
  TP.cat = id => TP.CATS.find(c => c[0] === id);

  // ======================================================================
  // SVG HELPERS
  // ======================================================================
  const q = v => Math.round(v * 10) / 10;
  const A = o => Object.entries(o).filter(([, v]) => v !== undefined && v !== null && v !== '' && v !== false).map(([k, v]) => `${k}="${esc(typeof v === 'number' ? q(v) : v)}"`).join(' ');
  const RC = (id, x, y, w, h, o = {}) => `<rect ${A({ id, x, y, width: Math.max(0.5, w), height: Math.max(0.5, h), rx: o.rx, fill: o.fill || 'none', stroke: o.stroke, 'stroke-width': o.sw, opacity: o.op, 'fill-opacity': o.fop, 'stroke-dasharray': o.dash, transform: o.tf })}/>`;
  const CI = (id, cx, cy, r, o = {}) => `<circle ${A({ id, cx, cy, r: Math.max(0.5, r), fill: o.fill || 'none', stroke: o.stroke, 'stroke-width': o.sw, opacity: o.op, 'fill-opacity': o.fop })}/>`;
  const LN = (id, x1, y1, x2, y2, o = {}) => `<line ${A({ id, x1, y1, x2, y2, stroke: o.stroke, 'stroke-width': o.sw || 1, opacity: o.op, 'stroke-linecap': o.cap || 'round', 'stroke-dasharray': o.dash })}/>`;
  const PA = (id, d, o = {}) => `<path ${A({ id, d, fill: o.fill || 'none', stroke: o.stroke, 'stroke-width': o.sw, opacity: o.op, 'stroke-linecap': o.cap, 'stroke-linejoin': o.join, transform: o.tf })}/>`;
  const PG = (id, pts, o = {}) => `<polygon ${A({ id, points: pts.map(p => q(p[0]) + ',' + q(p[1])).join(' '), fill: o.fill || 'none', opacity: o.op, stroke: o.stroke, 'stroke-width': o.sw })}/>`;
  const E = (id, cx, cy, rx, ry, o = {}) => `<ellipse ${A({ id, cx, cy, rx: Math.max(0.5, rx), ry: Math.max(0.5, ry), fill: o.fill || 'none', stroke: o.stroke, 'stroke-width': o.sw, opacity: o.op })}/>`;
  const mixC = (a, b, k) => O.color.mix(a, b, k);
  const onC = h => (O.color.luminance(h) > 0.6 ? '#141414' : '#FFFFFF');
  const wrap = (s, size, maxW, k) => {
    if (!maxW) return [String(s)];
    const max = Math.max(3, Math.floor(maxW / (size * k)));
    const out = []; let cur = '';
    for (const w of String(s).split(/\s+/)) { if (!cur) cur = w; else if ((cur + ' ' + w).length <= max) cur += ' ' + w; else { out.push(cur); cur = w; } }
    if (cur) out.push(cur);
    return out;
  };
  // text block → { svg, h }
  const TT = (c, id, str, x, y, size, o = {}) => {
    if (!str && str !== 0) return { svg: '', h: 0 };
    // average glyph width in em: heavy display headings are wider than body text
    const fam = o.family || c.fb, k = (o.k || (fam === c.fh ? 0.66 : 0.56)) * (o.upper ? 1.18 : 1) + (o.ls ? o.ls / size : 0);
    const s = o.upper ? String(str).toUpperCase() : String(str);
    let lines = o.maxW ? wrap(s, size, o.maxW, k) : [s];
    if (o.maxLines && lines.length > o.maxLines) lines = lines.slice(0, o.maxLines);
    const lh = o.lh || 1.22;
    const a = A({ id, 'data-lh': lines.length > 1 ? lh : undefined, x, y, 'font-family': `'${fam}', sans-serif`, 'font-size': size, 'font-weight': o.weight || 400, 'font-style': o.italic ? 'italic' : undefined, fill: o.fill || c.ink, 'text-anchor': o.anchor || 'start', 'letter-spacing': o.ls, opacity: o.op });
    const inner = lines.length === 1 ? esc(lines[0]) : lines.map((l, i) => `<tspan x="${q(x)}" ${i ? `dy="${q(size * lh)}"` : `y="${q(y)}"`}>${esc(l)}</tspan>`).join('');
    return { svg: `<text ${a}>${inner}</text>`, h: size * lh * (lines.length - 1) + size, lines: lines.length };
  };
  // the biggest size at which the longest word fits and the text takes at most n lines
  const fit = (c, str, size, w, n = 3, upper, fam) => {
    const k = (fam === c.fb ? 0.56 : 0.66) * (upper ? 1.18 : 1);
    const longest = Math.max(1, ...String(str).split(/\s+/).map(x => x.length));
    size = Math.min(size, w / (longest * k));
    while (wrap(str, size, w, k).length > n && size > 6) size *= 0.93;
    return size;
  };
  // real photos (Unsplash licence, served by picsum.photos), sorted by topic by hand
  TP.PHOTOS = {
    work: [0, 1, 2, 3, 5, 6, 8, 9, 48, 60, 180, 201, 370, 366],
    food: [30, 63, 225, 292, 312, 326, 102, 75, 365, 42],
    people: [64, 65, 91, 129, 177, 325, 338, 349, 375, 390, 399, 27],
    nature: [10, 11, 15, 17, 28, 29, 33, 62, 66, 110, 128, 231, 235, 287, 327, 353, 368, 416],
    sea: [12, 13, 14, 16, 37, 52, 77, 215, 218, 266, 317, 323, 374, 384, 385],
    city: [43, 57, 122, 164, 214, 238, 249, 259, 283, 299, 320, 322, 376, 382, 391, 392, 411, 419],
    home: [76, 78, 146, 163, 192, 208, 305, 311, 206],
    travel: [49, 174, 401, 364, 328, 211, 234, 318, 155, 182, 190, 191, 197],
    party: [158, 117, 195, 407, 56, 223],
    flowers: [25, 82, 106, 152, 159, 189, 306, 360, 400, 104],
    animals: [40, 237, 169, 219, 200, 244],
    cozy: [167, 301, 413, 24, 367, 175, 403],
    winter: [256, 260, 423, 406],
    sport: [389, 390, 173, 103, 339]
  };
  const TOPIC = { insta: ['people', 'food', 'city'], story: ['travel', 'nature'], fbpost: ['people', 'work'], ytthumb: ['travel', 'sport'], ytbanner: ['nature'], slides: ['work', 'city'], poster: ['party', 'city'], flyer: ['work', 'people'], pin: ['home', 'cozy'], book: ['nature', 'winter'], invite: ['flowers'], card: ['flowers'], menu: ['food'], brochure: ['work', 'people'], calendar: ['nature', 'sea'], linkedin: ['work'], fbcover: ['food'], xpost: ['city'], email: ['work'], gift: ['cozy'],
    'idea-hiring': ['work'], 'idea-testimonial': ['people'], 'idea-collage4': ['travel', 'sea', 'people'], 'idea-collage3': ['nature'], 'idea-webinar': ['people'], 'idea-realestate': ['home'], 'idea-newsletter': ['work', 'city'], 'idea-landing': ['work'], 'idea-moodboard': ['home', 'nature'], 'idea-photoquote': ['nature', 'sea'], 'idea-listicle': ['home', 'cozy'], 'idea-concert': ['party'], 'idea-lost': ['animals'], 'idea-recipecard': ['food'] };
  TP.photosFor = catId => (TOPIC[catId] || ['nature', 'city', 'people']).flatMap(k => TP.PHOTOS[k] || []);
  TP.photoURL = (id, w, h) => `https://picsum.photos/id/${id}/${Math.max(16, Math.round(w))}/${Math.max(16, Math.round(h))}`;
  const photo = (c, x, y, w, h, o = {}) => {
    if (c.photos && c.photos.length && !TP.noPhotos) {
      const pid = c.photos[(c.pseed + (c.pi++) * 7) % c.photos.length];
      // thumbnails ask for small pictures; inserted templates for up to 1600 px
      const k = c.thumb ? Math.min(1, 360 / Math.max(w, h)) : Math.min(1, 1600 / Math.max(w, h));
      const url = TP.photoURL(pid, w * k, h * k);
      c.photoList.push({ x, y, w, h, rx: o.rx || 0 });
      const img = `<image id="${esc(t('Фото'))}" href="${url}" x="${q(x)}" y="${q(y)}" width="${q(w)}" height="${q(h)}" preserveAspectRatio="xMidYMid slice"/>`;
      if (!c.thumb || !o.rx) return img;
      const cid = c.idp + 'pc' + (c.gid++);
      c.defs.push(`<clipPath id="${cid}"><rect x="${q(x)}" y="${q(y)}" width="${q(w)}" height="${q(h)}" rx="${q(o.rx)}"/></clipPath>`);
      return `<g clip-path="url(#${cid})">${img}</g>`;
    }
    const id = c.idp + 'ph' + (c.gid++);
    c.defs.push(`<linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${mixC(c.a1, '#FFFFFF', 0.55)}"/><stop offset="1" stop-color="${mixC(c.a2, '#FFFFFF', 0.25)}"/></linearGradient>`);
    const s = Math.min(w, h), cx = x + w / 2, cy = y + h / 2, m = s * 0.16;
    return RC(t('Місце для фото'), x, y, w, h, { fill: `url(#${id})`, rx: o.rx }) +
      PA(t('Значок фото'), `M${q(cx - m * 1.4)} ${q(cy + m * 0.8)}L${q(cx - m * 0.5)} ${q(cy - m * 0.3)}L${q(cx + m * 0.15)} ${q(cy + m * 0.4)}L${q(cx + m * 0.6)} ${q(cy - m * 0.05)}L${q(cx + m * 1.4)} ${q(cy + m * 0.8)}Z`, { fill: '#FFFFFF', op: 0.75 }) +
      CI(t('Сонце'), cx + m * 0.75, cy - m * 0.75, m * 0.28, { fill: '#FFFFFF', op: 0.75 });
  };
  const grad = (c, a, b, x2 = 1, y2 = 1) => { const id = c.idp + 'tg' + (c.gid++); c.defs.push(`<linearGradient id="${id}" x1="0" y1="0" x2="${x2}" y2="${y2}"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>`); return `url(#${id})`; };
  const pill = (c, label, x, y, size, o = {}) => {
    if (!label) return { svg: '', h: 0, w: 0 };
    const h = size * 2.7, w = size * label.length * 0.58 + size * 3;
    const bx = o.anchor === 'middle' ? x - w / 2 : o.anchor === 'end' ? x - w : x;
    const fill = o.fill || c.a1;
    return { svg: RC(t('Кнопка'), bx, y, w, h, { fill: o.outline ? 'none' : fill, stroke: o.outline ? fill : undefined, sw: o.outline ? size * 0.12 : undefined, rx: o.square ? size * 0.3 : h / 2 }) + TT(c, t('Текст кнопки'), label, bx + w / 2, y + h / 2 + size * 0.36, size, { anchor: 'middle', weight: 700, fill: o.outline ? fill : onC(fill) }).svg, h, w };
  };
  // kicker + title + subtitle + body + button, stacked
  const stack = (c, x, y, w, o = {}) => {
    const anchor = o.align === 'center' ? 'middle' : o.align === 'right' ? 'end' : 'start';
    const ax = anchor === 'middle' ? x + w / 2 : anchor === 'end' ? x + w : x;
    const T = c.txt, ink = o.ink || c.ink, ink2 = o.ink2 || mixC(ink, o.bg || c.bg, 0.3);
    let s = '', yy = y;
    const ts = fit(c, T.title, o.size || c.u * 9, w, o.lines || 3, o.upper);
    if (T.kicker && o.kicker !== false) { const ks = Math.max(c.u * 1.6, ts * 0.2); s += TT(c, t('Підпис'), T.kicker, ax, yy + ks, ks, { anchor, upper: true, weight: 700, ls: ks * 0.14, fill: o.kc || c.a1 }).svg; yy += ks * 2.3; }
    const tt = TT(c, t('Заголовок'), T.title, ax, yy + ts * 0.86, ts, { family: c.fh, anchor, weight: o.tw || 800, maxW: w, lh: 1.06, fill: ink, upper: o.upper, italic: o.italic });
    s += tt.svg; yy += tt.h + ts * 0.4;
    const ss = Math.max(c.u * 2.2, Math.min(ts * 0.36, c.u * 4));
    if (T.sub) { const st = TT(c, t('Підзаголовок'), T.sub, ax, yy + ss, ss, { anchor, maxW: w, weight: 600, fill: o.sc || ink2, lh: 1.3 }); s += st.svg; yy += st.h + ss * 0.8; }
    if (T.body && o.body !== false) { const bs = Math.max(c.u * 1.7, ss * 0.72); const bt = TT(c, t('Текст'), T.body, ax, yy + bs, bs, { anchor, maxW: Math.min(w, bs * 30), fill: ink2, lh: 1.5 }); s += bt.svg; yy += bt.h + bs * 1.4; }
    if (T.cta && o.cta !== false) { const p = pill(c, T.cta, ax, yy, Math.max(c.u * 1.8, ss * 0.7), { anchor, fill: o.bc || c.a1, outline: o.outline }); s += p.svg; yy += p.h; }
    return { svg: s, y: yy };
  };
  const foot = (c, color, align = 'start') => { const fs = Math.max(c.u * 1.5, 8); const x = align === 'middle' ? c.W / 2 : c.pad; return c.txt.extra ? TT(c, t('Підпис внизу'), c.txt.extra, x, c.H - c.pad * 0.7, fs, { anchor: align, fill: color || mixC(c.ink, c.bg, 0.35), weight: 600, ls: fs * 0.06 }).svg : ''; };

  // ======================================================================
  // LAYOUTS (c: W, H, u, pad, bg, sf, ink, a1, a2, fh, fb, txt, defs)
  // ======================================================================
  const L = {};
  L.hero = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    const m = Math.min(W, H), wide = W > H * 1.3;
    s += CI(t('Коло'), W * 0.88, H * 0.1, m * (wide ? 0.34 : 0.27), { fill: c.a1, op: 0.9 });
    s += CI(t('Мале коло'), W * 0.1, H * 0.92, m * 0.1, { fill: c.a2, op: 0.85 });
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) s += CI(t('Крапка'), W * 0.08 + i * u * 3, H * 0.1 + j * u * 3, u * 0.45, { fill: c.ink, op: 0.25 });
    const w = W - c.pad * 2;
    // text below the big circle (tall and square formats) or beside it (wide)
    const b = stack(c, c.pad, H * (wide ? 0.3 : H > W * 1.2 ? 0.4 : 0.42), w * (wide ? 0.62 : 0.9), {});
    return s + b.svg + foot(c);
  };
  L.split = c => {
    const { W, H } = c, wide = W >= H;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    if (wide) {
      s += photo(c, W * 0.52, 0, W * 0.48, H);
      s += RC(t('Смуга'), W * 0.5, 0, W * 0.02, H, { fill: c.a1 });
      s += stack(c, c.pad, H * 0.22, W * 0.4, {}).svg;
    } else {
      s += photo(c, 0, 0, W, H * 0.5);
      s += RC(t('Плашка'), c.pad, H * 0.44, W - c.pad * 2, H * 0.5, { fill: c.sf, rx: c.u * 2 });
      s += stack(c, c.pad * 1.6, H * 0.5, W - c.pad * 3.2, {}).svg;
    }
    return s + foot(c);
  };
  L.frame = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.sf });
    s += RC(t('Рамка'), u * 4, u * 4, W - u * 8, H - u * 8, { stroke: c.a1, sw: u * 0.5 });
    s += RC(t('Внутрішня рамка'), u * 5.5, u * 5.5, W - u * 11, H - u * 11, { stroke: c.a1, sw: u * 0.18 });
    for (const [x, y] of [[u * 4, u * 4], [W - u * 4, u * 4], [u * 4, H - u * 4], [W - u * 4, H - u * 4]]) s += PG(t('Орнамент'), [[x, y - u * 1.6], [x + u * 1.6, y], [x, y + u * 1.6], [x - u * 1.6, y]], { fill: c.a1 });
    const b = stack(c, W * 0.14, H * 0.28, W * 0.72, { align: 'center', tw: 600, italic: false });
    s += b.svg;
    s += LN(t('Розділювач'), W * 0.4, b.y + u * 3, W * 0.6, b.y + u * 3, { stroke: c.a1, sw: u * 0.3 });
    return s + foot(c, c.a1, 'middle');
  };
  L.bold = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.a1 });
    s += PG(t('Діагональ'), [[0, H * 0.62], [W, H * 0.38], [W, H * 0.6], [0, H * 0.84]], { fill: c.a2 });
    s += RC(t('Стрічка'), c.pad, c.pad, u * 18, u * 4.5, { fill: c.ink });
    s += TT(c, t('Підпис'), c.txt.kicker || c.txt.extra, c.pad + u * 9, c.pad + u * 3.1, u * 2, { anchor: 'middle', fill: onC(c.ink), weight: 800, upper: true }).svg;
    const ink = onC(c.a1);
    const ts = fit(c, c.txt.title, u * 13, W - c.pad * 2, 3, true);
    s += TT(c, t('Заголовок'), c.txt.title, c.pad, H * 0.2 + ts, ts, { family: c.fh, weight: 900, upper: true, maxW: W - c.pad * 2, lh: 0.98, fill: ink }).svg;
    s += TT(c, t('Підзаголовок'), c.txt.sub, c.pad, H * 0.93, u * 3.4, { weight: 800, fill: onC(c.a2), maxW: W - c.pad * 2 }).svg;
    return s;
  };
  L.photo = c => {
    const { W, H } = c;
    let s = photo(c, 0, 0, W, H);
    s += RC(t('Затемнення'), 0, H * 0.45, W, H * 0.55, { fill: grad(c, 'rgba(0,0,0,0)', mixC(c.ink, '#000000', 0.5), 0, 1) });
    const b = stack(c, c.pad, H * 0.6, W - c.pad * 2, { ink: '#FFFFFF', ink2: '#E8E8EE', bg: '#000000', kc: c.a2 === '#FFFFFF' ? c.a1 : mixC(c.a2, '#FFFFFF', 0.3) });
    return s + b.svg + foot(c, '#FFFFFF');
  };
  L.gradient = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: grad(c, c.a1, c.a2) });
    s += CI(t('Пляма'), W * 0.15, H * 0.2, Math.min(W, H) * 0.3, { fill: '#FFFFFF', op: 0.18 });
    s += CI(t('Пляма'), W * 0.88, H * 0.85, Math.min(W, H) * 0.4, { fill: '#FFFFFF', op: 0.12 });
    const cw = Math.min(W - c.pad * 2, W > H ? W * 0.6 : W * 0.86), cx = (W - cw) / 2, cy = H * 0.24, ch = H * 0.52;
    s += RC(t('Скляна картка'), cx, cy, cw, ch, { fill: '#FFFFFF', fop: 0.2, stroke: '#FFFFFF', sw: u * 0.25, rx: u * 3.5 });
    s += stack(c, cx + c.pad * 0.6, cy + ch * 0.14, cw - c.pad * 1.2, { align: 'center', ink: '#FFFFFF', ink2: '#F4F4FA', bg: c.a1, kc: '#FFFFFF', bc: '#FFFFFF', lines: 2 }).svg;
    return s + foot(c, '#FFFFFF', 'middle');
  };
  L.shapes = c => {
    const { W, H, u } = c, m = Math.min(W, H);
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    const side = W >= H * 0.95; // square and wide: shapes on the right, text on the left
    const gx = side ? W * 0.6 : W * 0.1, gy = side ? H * 0.12 : H * 0.06, gs = side ? Math.min(W * 0.36, H * 0.76) : W * 0.8;
    s += RC(t('Квадрат'), gx, gy, gs * 0.5, gs * 0.5, { fill: c.a1 });
    s += CI(t('Коло'), gx + gs * 0.75, gy + gs * 0.25, gs * 0.25, { fill: c.a2 });
    s += PG(t('Трикутник'), [[gx, gy + gs], [gx + gs * 0.5, gy + gs * 0.5], [gx + gs * 0.5, gy + gs]], { fill: c.ink });
    s += PA(t('Півколо'), `M${q(gx + gs * 0.5)} ${q(gy + gs)}A${q(gs * 0.25)} ${q(gs * 0.25)} 0 0 1 ${q(gx + gs)} ${q(gy + gs)}Z`, { fill: c.a1, op: 0.6 });
    s += CI(t('Кільце'), gx + gs * 0.75, gy + gs * 0.75, gs * 0.12, { stroke: c.ink, sw: u * 0.6 });
    void m;
    if (side) s += stack(c, c.pad, H * 0.24, W * 0.5, { lines: 4 }).svg;
    else s += stack(c, c.pad, gy + gs + H * 0.05, W - c.pad * 2, {}).svg;
    return s + foot(c);
  };
  L.minimal = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    s += LN(t('Лінія'), c.pad, c.pad, c.pad + u * 10, c.pad, { stroke: c.ink, sw: u * 0.35 });
    s += TT(c, t('Підпис'), c.txt.kicker, W - c.pad, c.pad + u * 0.6, u * 1.6, { anchor: 'end', upper: true, ls: u * 0.25, fill: mixC(c.ink, c.bg, 0.4) }).svg;
    s += stack(c, c.pad, H * 0.55, W * (W > H ? 0.55 : 0.84), { kicker: false, tw: 400, outline: true, bc: c.ink }).svg;
    return s + foot(c);
  };
  L.magazine = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.sf });
    const ts = fit(c, c.txt.title, u * 11, W - c.pad * 2, 2, true);
    s += TT(c, t('Заголовок'), c.txt.title, W / 2, c.pad + ts * 0.9, ts, { family: c.fh, anchor: 'middle', weight: 900, upper: true, maxW: W - c.pad * 2, lh: 1, fill: c.ink }).svg;
    const top = c.pad + ts * 2.3;
    s += LN(t('Лінія'), c.pad, top - u * 1.5, W - c.pad, top - u * 1.5, { stroke: c.ink, sw: u * 0.2 });
    s += photo(c, c.pad, top, W - c.pad * 2, H * 0.48);
    const y = top + H * 0.48 + u * 4, cw = (W - c.pad * 2 - u * 4) / 2;
    s += TT(c, t('Підзаголовок'), c.txt.sub, c.pad, y + u * 3, u * 2.8, { family: c.fh, weight: 700, maxW: cw, fill: c.a1 }).svg;
    s += TT(c, t('Текст'), c.txt.body || c.txt.sub, c.pad + cw + u * 4, y + u * 2, u * 1.8, { maxW: cw, lh: 1.5, fill: mixC(c.ink, c.sf, 0.25) }).svg;
    return s + foot(c, null, 'middle');
  };
  L.quote = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.a1 });
    const ink = onC(c.a1);
    s += TT(c, t('Лапки'), '“', c.pad, c.pad + u * 22, u * 30, { family: 'Georgia', fill: c.a2, weight: 700 }).svg;
    const ts = fit(c, c.txt.title, u * 8, W - c.pad * 2, 4);
    const tt = TT(c, t('Цитата'), c.txt.title, c.pad, H * 0.42, ts, { family: c.fh, weight: 700, maxW: W - c.pad * 2, lh: 1.15, fill: ink, italic: true });
    s += tt.svg;
    s += LN(t('Лінія'), c.pad, H * 0.42 + tt.h + u * 3, c.pad + u * 8, H * 0.42 + tt.h + u * 3, { stroke: c.a2, sw: u * 0.5 });
    s += TT(c, t('Автор'), c.txt.sub, c.pad, H * 0.42 + tt.h + u * 7, u * 2.4, { fill: ink, weight: 600 }).svg;
    return s + foot(c, ink);
  };
  L.banner = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    s += PG(t('Клин'), [[W * 0.62, 0], [W, 0], [W, H], [W * 0.52, H]], { fill: c.a1 });
    s += CI(t('Коло'), W * 0.8, H * 0.5, H * 0.32, { fill: c.a2, op: 0.9 });
    s += CI(t('Кільце'), W * 0.8, H * 0.5, H * 0.42, { stroke: onC(c.a1), sw: Math.max(1, u * 0.3), op: 0.6 });
    const ts = fit(c, c.txt.title, H * 0.22, W * 0.5, 2);
    let y = H * 0.32;
    if (c.txt.kicker) { s += TT(c, t('Підпис'), c.txt.kicker, W * 0.06, y, H * 0.07, { upper: true, weight: 700, fill: c.a1, ls: H * 0.008 }).svg; y += H * 0.1; }
    s += TT(c, t('Заголовок'), c.txt.title, W * 0.06, y + ts * 0.85, ts, { family: c.fh, weight: 800, fill: c.ink, maxW: W * 0.5, lh: 1.05 }).svg;
    s += TT(c, t('Підзаголовок'), c.txt.sub, W * 0.06, H * 0.84, H * 0.075, { weight: 500, fill: mixC(c.ink, c.bg, 0.3), maxW: W * 0.5 }).svg;
    if (c.txt.extra) s += TT(c, t('Підпис внизу'), c.txt.extra, W * 0.95, H * 0.92, H * 0.06, { anchor: 'end', fill: onC(c.a1), weight: 600 }).svg;
    return s;
  };
  L.grid = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    s += RC(t('Шапка'), 0, 0, W, H * 0.3, { fill: c.a1 });
    s += stack(c, c.pad, c.pad, W - c.pad * 2, { ink: onC(c.a1), ink2: onC(c.a1), kc: onC(c.a1), body: false, cta: false, lines: 2, size: u * 7 }).svg;
    const items = [t('Гнучкий розклад'), t('Досвідчені викладачі'), t('Сертифікат')];
    const cw = (W - c.pad * 2 - u * 6) / 3, y = H * 0.36;
    items.forEach((it, i) => {
      const x = c.pad + i * (cw + u * 3);
      s += RC(t('Картка'), x, y, cw, H * 0.26, { fill: c.sf, rx: u * 2 });
      s += CI(t('Іконка'), x + cw / 2, y + H * 0.07, u * 4, { fill: i % 2 ? c.a2 : c.a1 });
      s += TT(c, t('Номер'), String(i + 1), x + cw / 2, y + H * 0.07 + u * 1.6, u * 4.4, { anchor: 'middle', weight: 800, fill: onC(i % 2 ? c.a2 : c.a1) }).svg;
      s += TT(c, t('Пункт'), it, x + cw / 2, y + H * 0.16, u * 2.2, { anchor: 'middle', weight: 700, maxW: cw - u * 2 }).svg;
    });
    s += TT(c, t('Текст'), c.txt.body, c.pad, H * 0.72, u * 2.2, { maxW: W - c.pad * 2, lh: 1.5, fill: mixC(c.ink, c.bg, 0.25) }).svg;
    s += pill(c, c.txt.cta, c.pad, H * 0.82, u * 2.4).svg;
    return s + foot(c);
  };
  L.badge = c => {
    const { W, H, u } = c, cx = W / 2, cy = H / 2, r = Math.min(W, H) * 0.42;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    const pts = []; for (let i = 0; i < 48; i++) { const a = i / 48 * Math.PI * 2, rr = i % 2 ? r : r * 1.07; pts.push([cx + Math.cos(a) * rr, cy + Math.sin(a) * rr]); }
    s += PG(t('Зубчасте коло'), pts, { fill: c.a1 });
    s += CI(t('Кільце'), cx, cy, r * 0.84, { stroke: onC(c.a1), sw: u * 0.5, dash: `${q(u)} ${q(u)}` });
    const ts = fit(c, c.txt.title, u * 9, r * 1.4, 3, true);
    s += TT(c, t('Заголовок'), c.txt.title, cx, cy - ts * 0.2, ts, { family: c.fh, anchor: 'middle', weight: 900, upper: true, maxW: r * 1.4, fill: onC(c.a1), lh: 1 }).svg;
    s += TT(c, t('Підзаголовок'), c.txt.sub, cx, cy + r * 0.45, u * 3, { anchor: 'middle', fill: onC(c.a1), weight: 600 }).svg;
    s += TT(c, t('Зірка'), c.txt.extra || '★', cx, cy - r * 0.5, u * 5, { anchor: 'middle', fill: onC(c.a1) }).svg;
    return s;
  };
  // ---------- logos ----------
  const initial = c => String(c.txt.title || 'V').trim()[0].toUpperCase();
  L['logo-badge'] = c => { const { W, H, u } = c; let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg }); s += RC(t('Знак'), W / 2 - u * 14, H * 0.18, u * 28, u * 28, { fill: c.a1, rx: u * 7 }); s += TT(c, t('Літера'), initial(c), W / 2, H * 0.18 + u * 20, u * 18, { family: c.fh, anchor: 'middle', weight: 900, fill: onC(c.a1) }).svg; s += TT(c, t('Назва'), c.txt.title, W / 2, H * 0.72, fit(c, c.txt.title, u * 9, W * 0.8, 1), { family: c.fh, anchor: 'middle', weight: 800 }).svg; s += TT(c, t('Слоган'), c.txt.sub, W / 2, H * 0.82, u * 3.4, { anchor: 'middle', upper: true, ls: u * 0.6, fill: mixC(c.ink, c.bg, 0.35) }).svg; return s; };
  L['logo-mono'] = c => { const { W, H, u } = c; let s = RC(t('Тло'), 0, 0, W, H, { fill: c.ink }); s += CI(t('Знак'), W / 2, H * 0.4, u * 17, { stroke: c.a1, sw: u * 1.6 }); s += TT(c, t('Літера'), initial(c), W / 2, H * 0.4 + u * 7, u * 20, { family: c.fh, anchor: 'middle', weight: 700, fill: c.a1 }).svg; s += TT(c, t('Назва'), c.txt.title, W / 2, H * 0.78, u * 7, { family: c.fh, anchor: 'middle', upper: true, ls: u * 1.2, fill: onC(c.ink), weight: 600 }).svg; s += TT(c, t('Рік'), c.txt.extra, W / 2, H * 0.87, u * 2.6, { anchor: 'middle', ls: u * 0.8, fill: c.a1 }).svg; return s; };
  L['logo-word'] = c => { const { W, H, u } = c; let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg }); const ts = fit(c, c.txt.title, u * 18, W * 0.84, 1); s += TT(c, t('Назва'), c.txt.title, W / 2, H * 0.55, ts, { family: c.fh, anchor: 'middle', weight: 900, fill: c.ink }).svg; s += CI(t('Крапка'), W / 2 + ts * c.txt.title.length * 0.31 + u * 2, H * 0.55 - u * 1.5, u * 2, { fill: c.a1 }); s += TT(c, t('Слоган'), c.txt.sub, W / 2, H * 0.68, u * 3.4, { anchor: 'middle', fill: mixC(c.ink, c.bg, 0.35), upper: true, ls: u * 0.5 }).svg; return s; };
  L['logo-circle'] = c => { const { W, H, u } = c; let s = RC(t('Тло'), 0, 0, W, H, { fill: c.sf }); s += CI(t('Коло'), W / 2, H / 2, u * 40, { fill: c.a1 }); s += CI(t('Кільце'), W / 2, H / 2, u * 35, { stroke: onC(c.a1), sw: u * 0.6 }); s += TT(c, t('Назва'), c.txt.title, W / 2, H / 2 + u * 2, fit(c, c.txt.title, u * 11, u * 60, 1, true), { family: c.fh, anchor: 'middle', weight: 900, upper: true, fill: onC(c.a1) }).svg; s += TT(c, t('Слоган'), c.txt.sub, W / 2, H / 2 + u * 13, u * 3.2, { anchor: 'middle', fill: onC(c.a1), ls: u * 0.4, upper: true }).svg; s += TT(c, t('Рік'), c.txt.extra, W / 2, H / 2 - u * 16, u * 3, { anchor: 'middle', fill: onC(c.a1), ls: u * 0.8 }).svg; return s; };
  // ---------- business cards ----------
  L['card-split'] = c => { const { W, H, u } = c; let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg }); s += RC(t('Смуга'), 0, 0, W * 0.36, H, { fill: c.a1 }); s += TT(c, t('Літера'), initial(c), W * 0.18, H * 0.62, u * 30, { family: c.fh, anchor: 'middle', weight: 900, fill: onC(c.a1) }).svg; s += TT(c, t('Ім’я'), c.txt.title, W * 0.42, H * 0.36, fit(c, c.txt.title, u * 9, W * 0.52, 2), { family: c.fh, weight: 800, maxW: W * 0.52 }).svg; s += TT(c, t('Посада'), c.txt.sub, W * 0.42, H * 0.5, u * 4, { fill: c.a1, weight: 600, maxW: W * 0.52 }).svg; s += TT(c, t('Контакти'), c.txt.extra || c.txt.body, W * 0.42, H * 0.78, u * 3.2, { fill: mixC(c.ink, c.bg, 0.3), maxW: W * 0.54, lh: 1.5 }).svg; return s; };
  L['card-minimal'] = c => { const { W, H, u } = c; let s = RC(t('Тло'), 0, 0, W, H, { fill: c.sf }); s += LN(t('Лінія'), W * 0.08, H * 0.5, W * 0.2, H * 0.5, { stroke: c.a1, sw: u * 0.6 }); s += TT(c, t('Ім’я'), c.txt.title, W * 0.08, H * 0.4, u * 8, { family: c.fh, weight: 400, ls: u * 0.3 }).svg; s += TT(c, t('Посада'), c.txt.sub, W * 0.08, H * 0.62, u * 3.6, { upper: true, ls: u * 0.5, fill: mixC(c.ink, c.sf, 0.35) }).svg; s += TT(c, t('Контакти'), c.txt.extra, W * 0.92, H * 0.88, u * 2.8, { anchor: 'end', fill: mixC(c.ink, c.sf, 0.3) }).svg; return s; };
  L['card-bold'] = c => { const { W, H, u } = c; let s = RC(t('Тло'), 0, 0, W, H, { fill: grad(c, c.a1, c.a2) }); s += CI(t('Коло'), W * 0.85, H * 0.15, H * 0.5, { fill: '#FFFFFF', op: 0.15 }); s += TT(c, t('Ім’я'), c.txt.title, W * 0.07, H * 0.42, fit(c, c.txt.title, u * 11, W * 0.8, 1, true), { family: c.fh, weight: 900, upper: true, fill: '#FFFFFF' }).svg; s += TT(c, t('Посада'), c.txt.sub, W * 0.07, H * 0.56, u * 4, { fill: '#FFFFFF', weight: 600 }).svg; s += TT(c, t('Контакти'), c.txt.extra, W * 0.07, H * 0.85, u * 3, { fill: '#FFFFFF', op: 0.9 }).svg; return s; };
  // ---------- certificates ----------
  const certBase = (c, modern) => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: modern ? c.bg : c.sf });
    if (modern) { s += RC(t('Смуга'), 0, 0, W * 0.04, H, { fill: c.a1 }); s += PG(t('Куток'), [[W, 0], [W, H * 0.35], [W * 0.75, 0]], { fill: c.a2, op: 0.9 }); }
    else { s += RC(t('Рамка'), u * 3, u * 3, W - u * 6, H - u * 6, { stroke: c.a1, sw: u * 0.8 }); s += RC(t('Внутрішня рамка'), u * 4.8, u * 4.8, W - u * 9.6, H - u * 9.6, { stroke: c.a1, sw: u * 0.2 }); }
    s += TT(c, t('Заголовок'), c.txt.kicker, W / 2, H * 0.24, u * 8, { family: c.fh, anchor: 'middle', weight: 800, upper: true, ls: u * 0.8, fill: c.ink }).svg;
    s += TT(c, t('Вручається'), t('цей сертифікат засвідчує, що'), W / 2, H * 0.34, u * 2.6, { anchor: 'middle', fill: mixC(c.ink, c.sf, 0.4), italic: true }).svg;
    s += TT(c, t('Ім’я'), c.txt.title, W / 2, H * 0.5, fit(c, c.txt.title, u * 10, W * 0.7, 1), { family: c.fh, anchor: 'middle', weight: 600, italic: !modern, fill: c.a1 }).svg;
    s += LN(t('Лінія'), W * 0.25, H * 0.54, W * 0.75, H * 0.54, { stroke: c.ink, sw: u * 0.15, op: 0.5 });
    s += TT(c, t('Опис'), c.txt.sub, W / 2, H * 0.62, u * 3, { anchor: 'middle', maxW: W * 0.7, fill: c.ink }).svg;
    s += LN(t('Підпис 1'), W * 0.14, H * 0.82, W * 0.38, H * 0.82, { stroke: c.ink, sw: u * 0.15 });
    s += LN(t('Підпис 2'), W * 0.62, H * 0.82, W * 0.86, H * 0.82, { stroke: c.ink, sw: u * 0.15 });
    s += TT(c, t('Дата'), c.txt.body, W * 0.26, H * 0.87, u * 2.2, { anchor: 'middle', fill: mixC(c.ink, c.sf, 0.4) }).svg;
    s += TT(c, t('Посада'), c.txt.extra, W * 0.74, H * 0.87, u * 2.2, { anchor: 'middle', fill: mixC(c.ink, c.sf, 0.4) }).svg;
    s += CI(t('Печатка'), W / 2, H * 0.82, u * 7, { fill: c.a1 });
    s += CI(t('Кільце печатки'), W / 2, H * 0.82, u * 5.8, { stroke: onC(c.a1), sw: u * 0.25, dash: `${q(u * 0.6)} ${q(u * 0.4)}` });
    s += TT(c, t('Зірка'), '★', W / 2, H * 0.82 + u * 1.8, u * 5, { anchor: 'middle', fill: onC(c.a1) }).svg;
    return s;
  };
  L.cert = c => certBase(c, false);
  L['cert-modern'] = c => certBase(c, true);
  L['cert-lite'] = c => { const { W, H, u } = c; let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg }); s += PA(t('Гілочка'), `M${q(W * 0.3)} ${q(H * 0.14)}Q${q(W * 0.5)} ${q(H * 0.06)} ${q(W * 0.7)} ${q(H * 0.14)}`, { stroke: c.a1, sw: u * 0.4 }); for (let i = 0; i < 7; i++) { const x = W * (0.33 + i * 0.057), y = H * (0.12 - Math.sin(i / 6 * Math.PI) * 0.035); s += CI(t('Листок'), x, y, u * 0.9, { fill: i % 2 ? c.a1 : c.a2 }); } s += stack(c, W * 0.12, H * 0.28, W * 0.76, { align: 'center', tw: 500, italic: true, outline: true }).svg; s += TT(c, t('Ініціали'), c.txt.extra, W / 2, H * 0.92, u * 5, { family: c.fh, anchor: 'middle', fill: c.a1 }).svg; return s; };
  // ---------- menu ----------
  const DISHES = [['Салат з печеним буряком', 'козячий сир, горіхи, мед', '185'], ['Борщ з пампушками', 'сметана, часник, зелень', '160'], ['Вареники з картоплею', 'смажена цибуля, шкварки', '145'], ['Котлета по-київськи', 'пюре, зелений горошок', '290'], ['Риба на грилі', 'овочі, лимонне масло', '340'], ['Сирники', 'сметана, ягідний соус', '150'], ['Медовик', 'ніжний крем, кава до вибору', '120']];
  L.menu = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.sf });
    s += TT(c, t('Підпис'), c.txt.kicker, W / 2, H * 0.08, u * 2.4, { anchor: 'middle', upper: true, ls: u * 0.6, fill: c.a1, weight: 700 }).svg;
    s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.16, u * 11, { family: c.fh, anchor: 'middle', weight: 700 }).svg;
    s += TT(c, t('Підзаголовок'), c.txt.sub, W / 2, H * 0.2, u * 2.4, { anchor: 'middle', italic: true, fill: mixC(c.ink, c.sf, 0.35) }).svg;
    let y = H * 0.28;
    for (const [n, d, p] of DISHES) {
      s += TT(c, t('Страва'), t(n), c.pad, y, u * 3, { family: c.fh, weight: 700 }).svg;
      s += LN(t('Пунктир'), c.pad + u * 3 * t(n).length * 0.55 + u * 2, y - u * 0.6, W - c.pad - u * 9, y - u * 0.6, { stroke: c.ink, sw: u * 0.2, dash: `${q(u * 0.4)} ${q(u * 0.8)}`, op: 0.5 });
      s += TT(c, t('Ціна'), p, W - c.pad, y, u * 3, { anchor: 'end', weight: 700, fill: c.a1 }).svg;
      s += TT(c, t('Склад'), t(d), c.pad, y + u * 3.2, u * 2.1, { fill: mixC(c.ink, c.sf, 0.4), italic: true }).svg;
      y += u * 9.5;
    }
    return s + foot(c, null, 'middle');
  };
  L['menu-split'] = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    s += photo(c, 0, 0, W, H * 0.26);
    s += RC(t('Плашка'), c.pad, H * 0.2, W - c.pad * 2, u * 13, { fill: c.a1 });
    s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.2 + u * 9, u * 8, { family: c.fh, anchor: 'middle', weight: 800, upper: true, fill: onC(c.a1), ls: u * 0.6 }).svg;
    const cw = (W - c.pad * 2 - u * 4) / 2;
    DISHES.slice(0, 6).forEach(([n, d, p], i) => {
      const x = c.pad + (i % 2) * (cw + u * 4), y = H * 0.4 + Math.floor(i / 2) * u * 16;
      s += TT(c, t('Страва'), t(n), x, y, u * 2.8, { family: c.fh, weight: 700, maxW: cw - u * 8 }).svg;
      s += TT(c, t('Ціна'), p + ' ₴', x + cw, y, u * 2.8, { anchor: 'end', weight: 800, fill: c.a1 }).svg;
      s += TT(c, t('Склад'), t(d), x, y + u * 3.6, u * 2, { maxW: cw, fill: mixC(c.ink, c.bg, 0.4) }).svg;
    });
    return s + foot(c, null, 'middle');
  };
  // ---------- infographic ----------
  const STEPS = [['Дослідження', 'Вивчаємо аудиторію та ринок.'], ['Ідеї', 'Шукаємо рішення разом із вами.'], ['Дизайн', 'Створюємо макети й прототипи.'], ['Запуск', 'Тестуємо, запускаємо, вимірюємо.']];
  L['info-steps'] = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    s += RC(t('Шапка'), 0, 0, W, H * 0.2, { fill: c.a1 });
    s += stack(c, c.pad, H * 0.03, W - c.pad * 2, { ink: onC(c.a1), ink2: onC(c.a1), kc: onC(c.a1), cta: false, body: false, size: u * 9, lines: 2 }).svg;
    STEPS.forEach(([n, d], i) => {
      const y = H * 0.27 + i * H * 0.17, cx = W * 0.18;
      if (i < STEPS.length - 1) s += LN(t('Зв’язок'), cx, y + u * 8, cx, y + H * 0.17 - u * 2, { stroke: c.a1, sw: u * 0.6, dash: `${q(u)} ${q(u)}` });
      s += CI(t('Коло кроку'), cx, y, u * 8, { fill: i % 2 ? c.a2 : c.a1 });
      s += TT(c, t('Номер'), String(i + 1).padStart(2, '0'), cx, y + u * 3, u * 8, { anchor: 'middle', weight: 800, family: c.fh, fill: onC(i % 2 ? c.a2 : c.a1) }).svg;
      s += TT(c, t('Етап'), t(n), W * 0.32, y - u * 1, u * 5, { family: c.fh, weight: 800 }).svg;
      s += TT(c, t('Опис'), t(d), W * 0.32, y + u * 5, u * 3, { maxW: W * 0.6, fill: mixC(c.ink, c.bg, 0.3), lh: 1.4 }).svg;
    });
    return s + foot(c);
  };
  L['info-stats'] = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.sf });
    s += stack(c, c.pad, c.pad, W - c.pad * 2, { cta: false, size: u * 9, lines: 2 }).svg;
    const stats = [['78%', 'клієнтів повертаються'], ['3×', 'швидше запуск'], ['120+', 'проєктів щороку']];
    stats.forEach(([v, l], i) => {
      const y = H * 0.24 + i * H * 0.13;
      s += TT(c, t('Число'), v, c.pad, y + u * 9, u * 14, { family: c.fh, weight: 900, fill: i % 2 ? c.a2 : c.a1 }).svg;
      s += TT(c, t('Підпис'), t(l), W * 0.52, y + u * 7, u * 3.6, { maxW: W * 0.42, weight: 600 }).svg;
    });
    const by = H * 0.66, bh = H * 0.24, vals = [0.45, 0.7, 0.55, 0.9, 0.75], bw = (W - c.pad * 2) / vals.length;
    s += TT(c, t('Заголовок графіка'), t('Зростання за рік'), c.pad, by - u * 3, u * 3.6, { weight: 700 }).svg;
    vals.forEach((v, i) => { s += RC(t('Стовпчик'), c.pad + i * bw + bw * 0.15, by + bh * (1 - v), bw * 0.7, bh * v, { fill: i === vals.length - 2 ? c.a1 : mixC(c.a1, c.sf, 0.55), rx: u }); });
    s += LN(t('Вісь'), c.pad, by + bh, W - c.pad, by + bh, { stroke: c.ink, sw: u * 0.3 });
    return s + foot(c);
  };
  // ---------- calendar & planner ----------
  L.calendar = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    s += photo(c, 0, 0, W * 0.38, H);
    const x0 = W * 0.42, w = W * 0.54;
    s += TT(c, t('Рік'), c.txt.kicker, x0, H * 0.12, u * 4, { fill: c.a1, weight: 800 }).svg;
    s += TT(c, t('Місяць'), c.txt.title, x0, H * 0.24, u * 10, { family: c.fh, weight: 800 }).svg;
    const days = [t('Пн'), t('Вт'), t('Ср'), t('Чт'), t('Пт'), t('Сб'), t('Нд')], cw = w / 7;
    days.forEach((d, i) => { s += TT(c, t('День тижня'), d, x0 + cw * i + cw / 2, H * 0.34, u * 2.4, { anchor: 'middle', weight: 700, fill: i > 4 ? c.a1 : c.ink }).svg; });
    const first = 2; // 1 October 2026 is a Thursday: day 1 lands in column 3 (Monday = 0)
    for (let dnum = 1; dnum <= 31; dnum++) { const k = dnum + first, col = k % 7, row = Math.floor(k / 7); s += TT(c, t('Дата'), String(dnum), x0 + cw * col + cw / 2, H * 0.43 + row * u * 9, u * 3, { anchor: 'middle', fill: col > 4 ? c.a1 : c.ink }).svg; }
    return s;
  };
  L.planner = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    s += TT(c, t('Заголовок'), c.txt.title, c.pad, c.pad + u * 6, u * 8, { family: c.fh, weight: 800 }).svg;
    s += TT(c, t('Підпис'), c.txt.kicker, W - c.pad, c.pad + u * 6, u * 2.6, { anchor: 'end', upper: true, ls: u * 0.4, fill: c.a1, weight: 700 }).svg;
    const days = ['Понеділок', 'Вівторок', 'Середа', 'Четвер', 'П’ятниця', 'Субота / неділя'];
    const bw = (W - c.pad * 2 - u * 3) / 2, bh = (H * 0.68) / 3;
    days.forEach((d, i) => {
      const x = c.pad + (i % 2) * (bw + u * 3), y = H * 0.14 + Math.floor(i / 2) * (bh + u * 2);
      s += RC(t('Блок'), x, y, bw, bh, { stroke: mixC(c.ink, c.bg, 0.7), sw: u * 0.2, rx: u * 1.5 });
      s += TT(c, t('День'), t(d), x + u * 2, y + u * 4.5, u * 2.6, { weight: 700, fill: c.a1 }).svg;
      for (let k = 1; k <= 4; k++) s += LN(t('Рядок'), x + u * 2, y + u * 5 + k * bh / 5.4, x + bw - u * 2, y + u * 5 + k * bh / 5.4, { stroke: c.ink, sw: u * 0.1, op: 0.25 });
    });
    s += RC(t('Нотатки'), c.pad, H * 0.86, W - c.pad * 2, H * 0.09, { fill: c.sf, rx: u * 1.5 });
    s += TT(c, t('Підпис внизу'), c.txt.extra, c.pad + u * 2, H * 0.86 + u * 4, u * 2.4, { weight: 700 }).svg;
    return s;
  };
  // ---------- letterhead & brochure ----------
  L.letterhead = c => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' });
    s += RC(t('Знак'), c.pad, c.pad, u * 8, u * 8, { fill: c.a1, rx: u * 2 });
    s += TT(c, t('Літера'), initial(c), c.pad + u * 4, c.pad + u * 6, u * 6, { anchor: 'middle', weight: 900, family: c.fh, fill: onC(c.a1) }).svg;
    s += TT(c, t('Назва'), c.txt.title, c.pad + u * 11, c.pad + u * 4, u * 3.6, { family: c.fh, weight: 800 }).svg;
    s += TT(c, t('Слоган'), c.txt.sub, c.pad + u * 11, c.pad + u * 7.4, u * 2, { fill: mixC(c.ink, '#FFFFFF', 0.4) }).svg;
    s += LN(t('Лінія'), c.pad, c.pad + u * 12, W - c.pad, c.pad + u * 12, { stroke: c.a1, sw: u * 0.3 });
    s += TT(c, t('Текст листа'), c.txt.body, c.pad, H * 0.22, u * 2.2, { maxW: W - c.pad * 2, lh: 1.6 }).svg;
    s += RC(t('Нижня смуга'), 0, H - u * 2, W, u * 2, { fill: c.a1 });
    s += TT(c, t('Реквізити'), c.txt.extra, W / 2, H - u * 5, u * 1.8, { anchor: 'middle', fill: mixC(c.ink, '#FFFFFF', 0.4) }).svg;
    return s;
  };
  L.brochure = (c, page) => {
    const { W, H, u } = c, cw = W / 3;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    for (let i = 1; i < 3; i++) s += LN(t('Згин'), cw * i, 0, cw * i, H, { stroke: c.ink, sw: 0.5, op: 0.15, dash: '4 4' });
    const col = (i, inner) => `<g>${inner(cw * i + u * 4, cw - u * 8)}</g>`;
    if (!page) {
      s += col(0, (x, w) => TT(c, t('Текст'), c.txt.body, x, H * 0.18, u * 2.2, { maxW: w, lh: 1.6 }).svg + photo(c, x, H * 0.5, w, H * 0.34, { rx: u }));
      s += col(1, (x, w) => TT(c, t('Підзаголовок'), t('Контакти'), x, H * 0.18, u * 3.4, { family: c.fh, weight: 800, fill: c.a1 }).svg + TT(c, t('Контакти'), c.txt.extra, x, H * 0.26, u * 2.2, { maxW: w, lh: 1.6 }).svg + pill(c, c.txt.cta, x, H * 0.4, u * 2.2).svg);
      s += RC(t('Обкладинка'), cw * 2, 0, cw, H, { fill: c.a1 });
      s += col(2, (x, w) => TT(c, t('Підпис'), c.txt.kicker, x, H * 0.2, u * 2.2, { upper: true, ls: u * 0.4, fill: onC(c.a1), weight: 700 }).svg + TT(c, t('Заголовок'), c.txt.title, x, H * 0.36, fit(c, c.txt.title, u * 7, w, 3), { family: c.fh, weight: 900, maxW: w, fill: onC(c.a1), lh: 1.05 }).svg + TT(c, t('Підзаголовок'), c.txt.sub, x, H * 0.82, u * 2.4, { fill: onC(c.a1), maxW: w }).svg);
    } else {
      ['Курси', 'Викладачі', 'Результат'].forEach((h, i) => { s += col(i, (x, w) => TT(c, t('Підзаголовок'), t(h), x, H * 0.14, u * 4, { family: c.fh, weight: 800, fill: c.a1 }).svg + photo(c, x, H * 0.2, w, H * 0.3, { rx: u }) + TT(c, t('Текст'), c.txt.body, x, H * 0.6, u * 2.1, { maxW: w, lh: 1.6 }).svg); });
    }
    return s;
  };
  // the second slide and further pages of multi-page templates
  L.slideContent = (c, i) => {
    const { W, H, u } = c;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: c.bg });
    s += RC(t('Смуга'), 0, 0, W, u * 1.2, { fill: c.a1 });
    const heads = ['Мета', 'Результати', 'Наступні кроки'];
    s += TT(c, t('Номер слайда'), String(i + 1).padStart(2, '0'), c.pad, c.pad + u * 6, u * 6, { family: c.fh, weight: 900, fill: c.a1 }).svg;
    s += TT(c, t('Заголовок'), t(heads[(i - 1) % heads.length]), c.pad + u * 12, c.pad + u * 6, u * 6, { family: c.fh, weight: 800 }).svg;
    if (i % 2) {
      ['Зрозуміти потреби клієнтів', 'Запустити новий продукт', 'Збільшити повторні продажі'].forEach((b, k) => { s += CI(t('Маркер списку'), c.pad + u * 1.5, H * 0.38 + k * u * 10 - u * 1.4, u * 1.2, { fill: c.a1 }); s += TT(c, t('Пункт'), t(b), c.pad + u * 5, H * 0.38 + k * u * 10, u * 3.6, { maxW: W * 0.45 }).svg; });
      s += photo(c, W * 0.56, H * 0.24, W * 0.38, H * 0.62, { rx: u * 2 });
    } else {
      [['+42%', 'продажі'], ['18', 'нових клієнтів'], ['4,9★', 'середня оцінка']].forEach(([v, l], k) => { const x = c.pad + k * (W - c.pad * 2) / 3; s += RC(t('Картка'), x, H * 0.3, (W - c.pad * 2) / 3 - u * 3, H * 0.5, { fill: c.sf, rx: u * 2 }); s += TT(c, t('Число'), v, x + u * 4, H * 0.3 + u * 16, u * 12, { family: c.fh, weight: 900, fill: c.a1 }).svg; s += TT(c, t('Підпис'), t(l), x + u * 4, H * 0.3 + u * 24, u * 3.6, { weight: 600 }).svg; });
    }
    return s;
  };

  // ======================================================================
  // RÉSUMÉ LAYOUTS — the text is real text in reading order (ATS-friendly unless noted)
  // ======================================================================
  TP.CV = () => ({
    name: t('Олена Коваленко'), role: t('Маркетинг-менеджерка'),
    contacts: ['olena.kovalenko@gmail.com', '+380 67 123 45 67', t('Київ, Україна'), 'linkedin.com/in/olenakovalenko'],
    summary: t('Маркетологиня з 6 роками досвіду в e-commerce та SaaS. Запускаю кампанії, що зростають у продажах, будую контент-стратегії й керую командою з 5 осіб.'),
    jobs: [
      { title: t('Маркетинг-менеджерка'), org: t('ТОВ «Нова Хвиля», Київ'), dates: '03.2022 – ' + t('теперішній час'), bullets: [t('Збільшила онлайн-продажі на 38% за рік завдяки новій email-стратегії.'), t('Запустила 24 рекламні кампанії з ROI понад 250%.'), t('Керувала командою з 5 маркетологів і бюджетом 2 млн грн.')] },
      { title: t('SMM-спеціалістка'), org: t('Агенція «Бриз», Львів'), dates: '06.2019 – 02.2022', bullets: [t('Виростила аудиторію Instagram клієнтів з 12 до 85 тис. підписників.'), t('Підготувала 300+ публікацій і 40 відеороликів.')] }
    ],
    edu: [{ title: t('Магістр маркетингу'), org: t('Київський національний економічний університет'), dates: '2014 – 2019' }],
    skills: ['Google Analytics', 'Meta Ads', 'SEO', 'Email-маркетинг', 'Figma', 'HubSpot', 'A/B-тести', t('Управління командою')],
    langs: [t('Українська — рідна'), t('Англійська — C1'), t('Німецька — B1')]
  });
  const cvSections = (c, x, y, w, o = {}) => {
    const cv = o.cv || TP.CV(), u = c.u, hs = o.hs || u * 2.7, bs = o.bs || u * 1.85, ink2 = mixC(c.ink, o.bg || '#FFFFFF', 0.3);
    let s = '', badge = 0;
    const head = label => {
      // optional round icon badge before each section heading
      if (o.badge) { const cx = x - hs * 1.5, cy = y + hs * 0.62; s += CI(t('Значок розділу'), cx, cy, hs * 0.9, { fill: o.hc || c.a1 }) + TT(c, t('Значок розділу'), ['◆', '■', '▲', '●', '★'][badge++ % 5], cx, cy + hs * 0.38, hs * 0.95, { anchor: 'middle', fill: onC(o.hc || c.a1) }).svg; }
      const r = TT(c, t('Розділ') + ': ' + label, label, x, y + hs, hs, { family: o.hf || c.fh, weight: 800, upper: o.upper !== false, ls: hs * 0.08, fill: o.hc || c.a1 }); s += r.svg; y += hs * 1.35; if (o.rule !== false) { s += LN(t('Лінія розділу'), x, y - hs * 0.15, x + w, y - hs * 0.15, { stroke: o.hc || c.a1, sw: Math.max(0.6, u * 0.12), op: 0.6 }); } y += hs * 0.5; };
    const para = (txt, size, opt = {}) => { const r = TT(c, opt.id || t('Текст'), txt, x + (opt.indent || 0), y + size, size, Object.assign({ maxW: w - (opt.indent || 0), lh: 1.4, fill: c.ink }, opt)); s += r.svg; y += r.h + size * (opt.after === undefined ? 0.55 : opt.after); };
    if (o.summary !== false) { head(t('Профіль')); para(cv.summary, bs, { id: t('Профіль'), fill: ink2 }); y += bs * 0.6; }
    head(t('Досвід роботи'));
    for (const j of cv.jobs) {
      para(j.title, bs * 1.12, { id: t('Посада'), weight: 700, after: 0.25 });
      para(j.org + ' | ' + j.dates, bs * 0.95, { id: t('Компанія і дати'), fill: ink2, after: 0.45 });
      for (const b of j.bullets) para('• ' + b, bs, { id: t('Досягнення'), indent: u * 1.2, after: 0.35 });
      y += bs * 0.6;
    }
    head(t('Освіта'));
    for (const e of cv.edu) { para(e.title, bs * 1.1, { id: t('Освіта'), weight: 700, after: 0.25 }); para(e.org + ' | ' + e.dates, bs * 0.95, { id: t('Заклад і роки'), fill: ink2 }); }
    y += bs * 0.4;
    if (o.skills !== false) { head(t('Навички')); para(cv.skills.join(' · '), bs, { id: t('Навички') }); y += bs * 0.4; }
    if (o.langs !== false) { head(t('Мови')); para(cv.langs.join(' · '), bs, { id: t('Мови') }); }
    return { svg: s, y };
  };
  L['cv-ats'] = c => {
    const { W, u } = c, cv = TP.CV();
    let s = RC(t('Тло'), 0, 0, W, c.H, { fill: '#FFFFFF' });
    const x = u * 8, w = W - u * 16;
    s += TT(c, t('Ім’я'), cv.name, x, u * 10, u * 5.2, { family: c.fb, weight: 800, fill: '#111111' }).svg;
    s += TT(c, t('Бажана посада'), cv.role, x, u * 14.2, u * 2.6, { fill: '#333333', weight: 600 }).svg;
    s += TT(c, t('Контакти'), cv.contacts.join(' | '), x, u * 18, u * 1.75, { fill: '#333333', maxW: w }).svg;
    s += cvSections(Object.assign({}, c, { a1: '#111111', fh: c.fb, ink: '#111111' }), x, u * 21, w, { hs: u * 2.3, bs: u * 1.75 }).svg;
    return s;
  };
  L['cv-classic'] = c => {
    const { W, u } = c, cv = TP.CV();
    let s = RC(t('Тло'), 0, 0, W, c.H, { fill: '#FFFFFF' });
    s += TT(c, t('Ім’я'), cv.name, W / 2, u * 11, u * 5.6, { family: c.fh, anchor: 'middle', weight: 700, fill: c.ink }).svg;
    s += TT(c, t('Бажана посада'), cv.role, W / 2, u * 15.2, u * 2.4, { anchor: 'middle', upper: true, ls: u * 0.4, fill: c.a1, weight: 600 }).svg;
    s += TT(c, t('Контакти'), cv.contacts.join('  ·  '), W / 2, u * 19, u * 1.7, { anchor: 'middle', fill: mixC(c.ink, '#FFFFFF', 0.3), maxW: W - u * 14 }).svg;
    s += LN(t('Лінія'), u * 8, u * 21.5, W - u * 8, u * 21.5, { stroke: c.ink, sw: u * 0.15 });
    s += cvSections(c, u * 8, u * 23, W - u * 16, { hs: u * 2.4, bs: u * 1.8 }).svg;
    return s;
  };
  L['cv-minimal'] = c => {
    const { W, u } = c, cv = TP.CV();
    let s = RC(t('Тло'), 0, 0, W, c.H, { fill: '#FFFFFF' });
    s += RC(t('Акцент'), u * 8, u * 7, u * 1.2, u * 9, { fill: c.a1 });
    s += TT(c, t('Ім’я'), cv.name, u * 11.5, u * 11.4, u * 5.4, { family: c.fh, weight: 800, fill: c.ink }).svg;
    s += TT(c, t('Бажана посада'), cv.role, u * 11.5, u * 15.4, u * 2.4, { fill: mixC(c.ink, '#FFFFFF', 0.35) }).svg;
    s += TT(c, t('Контакти'), cv.contacts.join(' | '), u * 8, u * 20, u * 1.7, { fill: mixC(c.ink, '#FFFFFF', 0.25), maxW: W - u * 16 }).svg;
    s += cvSections(c, u * 8, u * 22.5, W - u * 16, { hs: u * 2.2, bs: u * 1.78, rule: false, upper: false }).svg;
    return s;
  };
  // two columns: looks great, but ATS may read the columns out of order — the checker warns about it
  L['cv-modern'] = c => {
    const { W, H, u } = c, cv = TP.CV(), sw = W * 0.33;
    let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' });
    s += RC(t('Бічна панель'), 0, 0, sw, H, { fill: c.ink });
    s += CI(t('Місце для фото'), sw / 2, u * 15, u * 9, { fill: mixC(c.a1, '#FFFFFF', 0.4) });
    const side = onC(c.ink); let y = u * 31;
    const sh = (label, items) => { s += TT(c, t('Розділ') + ': ' + label, label, u * 5, y, u * 2.3, { upper: true, weight: 800, ls: u * 0.3, fill: c.a1 }).svg; y += u * 3.6; for (const it of items) { const r = TT(c, t('Пункт'), it, u * 5, y, u * 1.65, { fill: side, maxW: sw - u * 9 }); s += r.svg; y += r.h + u * 1.3; } y += u * 2.4; };
    sh(t('Контакти'), cv.contacts); sh(t('Навички'), cv.skills); sh(t('Мови'), cv.langs);
    s += TT(c, t('Ім’я'), cv.name, sw + u * 6, u * 12, fit(c, cv.name, u * 5.4, W - sw - u * 12, 2), { family: c.fh, weight: 800, maxW: W - sw - u * 12, fill: c.ink, lh: 1.05 }).svg;
    s += TT(c, t('Бажана посада'), cv.role, sw + u * 6, u * 18, u * 2.4, { fill: c.a1, weight: 700 }).svg;
    s += cvSections(c, sw + u * 6, u * 21, W - sw - u * 11, { skills: false, langs: false, hs: u * 2.2, bs: u * 1.65 }).svg;
    return s;
  };
  L['cv-elegant'] = c => {
    const { W, u } = c, cv = TP.CV();
    let s = RC(t('Тло'), 0, 0, W, c.H, { fill: mixC(c.sf, '#FFFFFF', 0.6) });
    s += RC(t('Шапка'), 0, 0, W, u * 22, { fill: c.a1 });
    s += TT(c, t('Ім’я'), cv.name, u * 8, u * 11, u * 5.6, { family: c.fh, weight: 700, fill: onC(c.a1) }).svg;
    s += TT(c, t('Бажана посада'), cv.role, u * 8, u * 15, u * 2.4, { fill: onC(c.a1), op: 0.9 }).svg;
    s += TT(c, t('Контакти'), cv.contacts.join('  ·  '), u * 8, u * 19, u * 1.6, { fill: onC(c.a1), maxW: W - u * 16 }).svg;
    s += cvSections(c, u * 8, u * 25, W - u * 16, { hs: u * 2.3, bs: u * 1.75, bg: mixC(c.sf, '#FFFFFF', 0.6) }).svg;
    return s;
  };
  L['cv-bold'] = c => {
    const { W, u } = c, cv = TP.CV();
    let s = RC(t('Тло'), 0, 0, W, c.H, { fill: '#FFFFFF' });
    s += TT(c, t('Ім’я'), cv.name.split(' ')[0], u * 8, u * 13, u * 9, { family: c.fh, weight: 900, upper: true, fill: c.ink }).svg;
    s += TT(c, t('Прізвище'), cv.name.split(' ').slice(1).join(' '), u * 8, u * 21, u * 9, { family: c.fh, weight: 900, upper: true, fill: c.a1 }).svg;
    s += TT(c, t('Бажана посада'), cv.role, u * 8, u * 25.5, u * 2.4, { weight: 700 }).svg;
    s += TT(c, t('Контакти'), cv.contacts.join(' | '), u * 8, u * 29, u * 1.65, { fill: '#444444', maxW: W - u * 16 }).svg;
    s += cvSections(c, u * 8, u * 31, W - u * 16, { hs: u * 2.2, bs: u * 1.7 }).svg;
    return s;
  };

  // ======================================================================
  // 200 MORE RÉSUMÉS: 10 layouts in the Pinterest manner (soft colours, portrait photos, arches, leaves) and
  // 10 premium layouts in the Canva Pro manner (executive, luxe, infographic…) — original VIBSma designs — ×
  // 10 styles each; five different people, so the résumés differ in content too
  // ======================================================================
  TP.PERSONAS = [
    () => Object.assign(TP.CV(), { stats: [['6+', t('років досвіду')], ['24', t('кампанії')], ['38%', t('зростання продажів')]] }),
    () => ({
      name: t('Андрій Шевчук'), role: t('UX/UI-дизайнер'), contacts: ['andriy.shevchuk@gmail.com', '+380 50 234 56 78', t('Львів, Україна'), 'behance.net/ashevchuk'],
      summary: t('Дизайнер інтерфейсів із 5 роками досвіду. Проєктую мобільні застосунки й вебсервіси, якими зручно користуватися, і перевіряю рішення на реальних людях.'),
      jobs: [{ title: t('Провідний UX/UI-дизайнер'), org: t('Студія «Піксель», Львів'), dates: '01.2023 – ' + t('теперішній час'), bullets: [t('Перепроєктував застосунок банку: оцінка в App Store зросла з 3,9 до 4,7.'), t('Створив дизайн-систему зі 180 компонентів для 4 продуктів.')] }, { title: t('UI-дизайнер'), org: t('ІТ-компанія «Сота», Київ'), dates: '05.2020 – 12.2022', bullets: [t('Спроєктував 30+ лендингів із конверсією вище середньої на 22%.'), t('Провів 45 юзабіліті-тестувань.')] }],
      edu: [{ title: t('Бакалавр графічного дизайну'), org: t('Львівська національна академія мистецтв'), dates: '2016 – 2020' }],
      skills: ['Figma', 'Prototyping', 'Design systems', t('Юзабіліті-тести'), 'Adobe Illustrator', 'HTML/CSS', 'Motion'], langs: [t('Українська — рідна'), t('Англійська — B2'), t('Польська — B1')],
      stats: [['5', t('років у дизайні')], ['4', t('продукти')], ['180', t('компонентів')]]
    }),
    () => ({
      name: t('Марія Бондар'), role: t('Frontend-розробниця'), contacts: ['maria.bondar.dev@gmail.com', '+380 93 345 67 89', t('Харків, Україна'), 'github.com/mbondar'],
      summary: t('Frontend-розробниця з 4 роками комерційного досвіду. Пишу швидкі та доступні інтерфейси на React і TypeScript, люблю чистий код і тести.'),
      jobs: [{ title: t('Frontend-розробниця'), org: t('Компанія «Хмара», Харків'), dates: '02.2022 – ' + t('теперішній час'), bullets: [t('Прискорила завантаження сайту вдвічі завдяки розділенню коду.'), t('Покрила тестами 85% компонентів інтерфейсу.')] }, { title: t('Junior-розробниця'), org: t('Стартап «Кодекс», Київ'), dates: '07.2020 – 01.2022', bullets: [t('Розробила адмін-панель для 3 000 користувачів.'), t('Впровадила дизайн-систему на React.')] }],
      edu: [{ title: t('Бакалавр комп’ютерних наук'), org: t('Харківський національний університет радіоелектроніки'), dates: '2016 – 2020' }],
      skills: ['React', 'TypeScript', 'Next.js', 'Jest', 'CSS/SCSS', 'Git', 'REST/GraphQL', t('Доступність (a11y)')], langs: [t('Українська — рідна'), t('Англійська — C1')],
      stats: [['4', t('роки досвіду')], ['2×', t('швидший сайт')], ['85%', t('покриття тестами')]]
    }),
    () => ({
      name: t('Іван Ткаченко'), role: t('Менеджер з продажу'), contacts: ['ivan.tkachenko@gmail.com', '+380 66 456 78 90', t('Дніпро, Україна'), 'linkedin.com/in/ivantkachenko'],
      summary: t('Менеджер з продажу B2B з 7 роками досвіду. Будую довгі стосунки з клієнтами, веду переговори й щороку перевиконую план.'),
      jobs: [{ title: t('Старший менеджер з продажу'), org: t('Компанія «Агротех», Дніпро'), dates: '04.2021 – ' + t('теперішній час'), bullets: [t('Перевиконав річний план продажу на 31%.'), t('Залучив 40 нових корпоративних клієнтів.')] }, { title: t('Менеджер з продажу'), org: t('Дистриб’ютор «Схід», Запоріжжя'), dates: '09.2017 – 03.2021', bullets: [t('Відкрив нові ринки збуту в 5 областях.'), t('Навчив 8 нових менеджерів.')] }],
      edu: [{ title: t('Магістр менеджменту'), org: t('Дніпровський національний університет'), dates: '2012 – 2017' }],
      skills: [t('Переговори'), 'CRM (HubSpot)', t('Холодні дзвінки'), t('Аналіз ринку'), t('Презентації'), 'Excel'], langs: [t('Українська — рідна'), t('Англійська — B2')],
      stats: [['7', t('років у продажах')], ['+31%', t('до плану')], ['40', t('нових клієнтів')]]
    }),
    () => ({
      name: t('Софія Мельник'), role: t('Вчителька англійської мови'), contacts: ['sofia.melnyk@gmail.com', '+380 97 567 89 01', t('Одеса, Україна'), 'sofiateaches.com'],
      summary: t('Вчителька англійської з 8 роками досвіду в школі та онлайн. Готую учнів до НМТ та IELTS, роблю уроки живими й корисними.'),
      jobs: [{ title: t('Вчителька англійської мови'), org: t('Ліцей №12, Одеса'), dates: '09.2018 – ' + t('теперішній час'), bullets: [t('Середній бал учнів на НМТ зріс із 152 до 178.'), t('Створила шкільний розмовний клуб на 60 учнів.')] }, { title: t('Онлайн-викладачка'), org: t('Школа «Speak Up»'), dates: '01.2016 – 08.2018', bullets: [t('Підготувала 120 студентів до IELTS (середній бал 7,0).')] }],
      edu: [{ title: t('Магістр філології'), org: t('Одеський національний університет імені І. І. Мечникова'), dates: '2011 – 2016' }],
      skills: [t('Підготовка до IELTS'), t('Онлайн-навчання'), 'Google Classroom', t('Розробка курсів'), t('Публічні виступи')], langs: [t('Українська — рідна'), t('Англійська — C2'), t('Французька — B1')],
      stats: [['8', t('років викладання')], ['178', t('середній бал НМТ')], ['120', t('студентів IELTS')]]
    })
  ];
  const persona = c => (TP.PERSONAS[(c.meta && c.meta.persona) || 0] || TP.PERSONAS[0])();
  // readable on light paper whatever the style
  const darkInk = c => (O.color.luminance(c.ink) < 0.45 ? c.ink : '#1E1E26');
  const deepAcc = (c, k = 0.45) => (O.color.luminance(c.a1) > 0.62 ? mixC(c.a1, '#000000', k) : c.a1);
  const onPaper = c => Object.assign({}, c, { ink: darkInk(c), a1: deepAcc(c) });
  const sideSec = (c, x, y, w, label, list, o = {}) => {
    const u = c.u;
    let s = TT(c, t('Розділ') + ': ' + label, label, x, y, o.hs || u * 2, { upper: true, weight: 800, ls: u * 0.3, fill: o.hc || c.a1, family: o.hf }).svg;
    y += u * 3.3;
    for (const it of list) { const r = TT(c, t('Пункт'), it, x, y, o.bs || u * 1.55, { fill: o.fill || c.ink, maxW: w, lh: 1.35 }); s += r.svg; y += r.h + u * 1.05; }
    return { svg: s, y: y + u * 1.8 };
  };
  const skillBars = (c, x, y, w, list, o = {}) => {
    const u = c.u; let s = '';
    list.forEach((it, i) => { s += TT(c, t('Навичка'), it, x, y, u * 1.5, { fill: o.fill || c.ink }).svg + RC(t('Шкала'), x, y + u * 1.1, w, u * 0.75, { fill: o.track || mixC(c.a1, '#FFFFFF', 0.7), rx: u * 0.38 }) + RC(t('Рівень'), x, y + u * 1.1, w * (0.62 + ((i * 37) % 36) / 100), u * 0.75, { fill: o.bar || c.a1, rx: u * 0.38 }); y += u * 4.1; });
    return { svg: s, y: y + u };
  };
  const chips = (c, x, y, w, list, o = {}) => {
    const u = c.u; let s = '', cx = x;
    for (const it of list) { const cw = it.length * u * 0.95 + u * 3; if (cx + cw > x + w) { cx = x; y += u * 4.2; } s += RC(t('Навичка'), cx, y - u * 2.6, cw, u * 3.6, { fill: o.fill || mixC(c.a1, '#FFFFFF', 0.82), rx: u * 1.8 }) + TT(c, t('Навичка'), it, cx + cw / 2, y - u * 0.25, u * 1.45, { anchor: 'middle', weight: 600, fill: o.ink || c.ink }).svg; cx += cw + u; }
    return { svg: s, y: y + u * 3 };
  };
  const initials = n => String(n).split(/\s+/).map(p => p[0] || '').join('').slice(0, 2);
  const nameT = (c, cv, x, y, size, w, o = {}) => TT(c, t('Ім’я'), cv.name, x, y, fit(c, cv.name, size, w, o.lines || 2, o.upper, c.fh), Object.assign({ family: c.fh, weight: 800, maxW: w, lh: 1.05 }, o));
  const roleT = (c, cv, x, y, size, o = {}) => TT(c, t('Бажана посада'), cv.role, x, y, size, Object.assign({ weight: 700, fill: c.a1 }, o));
  const leaf = (cx, cy, len, ang) => { const a = ang * Math.PI / 180, dx = Math.cos(a), dy = Math.sin(a), nx = -dy, ny = dx, w = len * 0.32; const tx = cx + dx * len, ty = cy + dy * len, mx = cx + dx * len / 2, my = cy + dy * len / 2; return `M${q(cx)} ${q(cy)}Q${q(mx + nx * w)} ${q(my + ny * w)} ${q(tx)} ${q(ty)}Q${q(mx - nx * w)} ${q(my - ny * w)} ${q(cx)} ${q(cy)}Z`; };
  const blob = (cx, cy, r, seed) => { const n = 7, pts = []; for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2, rr = r * (0.82 + ((seed * 31 + i * 17) % 30) / 100); pts.push([cx + Math.cos(a) * rr, cy + Math.sin(a) * rr]); } let d = ''; for (let i = 0; i < n; i++) { const p = pts[i], nx2 = pts[(i + 1) % n], m = [(p[0] + nx2[0]) / 2, (p[1] + nx2[1]) / 2]; d += (i ? '' : `M${q((pts[n - 1][0] + p[0]) / 2)} ${q((pts[n - 1][1] + p[1]) / 2)}`) + `Q${q(p[0])} ${q(p[1])} ${q(m[0])} ${q(m[1])}`; } return d + 'Z'; };
  const timelineJobs = (c, cv, x, y, w, o = {}) => {
    const u = c.u; let s = TT(c, t('Розділ') + ': ' + t('Досвід роботи'), t('Досвід роботи'), x, y, u * 2, { upper: true, weight: 800, ls: u * 0.25, fill: c.a1, family: c.fh }).svg;
    y += u * 4;
    const top = y;
    for (const j of cv.jobs) {
      s += CI(t('Точка'), x + u * 0.8, y - u * 0.5, u * 0.9, { fill: c.a1 });
      s += TT(c, t('Посада'), j.title, x + u * 4, y, u * 1.75, { weight: 700, fill: c.ink, maxW: w - u * 4 }).svg; y += u * 2.6;
      s += TT(c, t('Компанія і дати'), j.org + ' | ' + j.dates, x + u * 4, y, u * 1.45, { fill: mixC(c.ink, '#FFFFFF', 0.35), maxW: w - u * 4 }).svg; y += u * 2.6;
      for (const b of j.bullets) { const r = TT(c, t('Досягнення'), '• ' + b, x + u * 4, y, u * 1.5, { fill: c.ink, maxW: w - u * 5, lh: 1.35 }); s += r.svg; y += r.h + u * 1; }
      y += u * 1.8;
    }
    s = LN(t('Лінія часу'), x + u * 0.8, top - u * 0.5, x + u * 0.8, y - u * 4, { stroke: c.a1, sw: u * 0.2, op: 0.6 }) + s;
    return { svg: s, y };
  };
  const eduBlock = (c, cv, x, y, w) => { const u = c.u; let s = TT(c, t('Розділ') + ': ' + t('Освіта'), t('Освіта'), x, y, u * 2, { upper: true, weight: 800, ls: u * 0.25, fill: c.a1, family: c.fh }).svg; y += u * 3.6; for (const e of cv.edu) { s += TT(c, t('Освіта'), e.title, x, y, u * 1.7, { weight: 700, fill: c.ink, maxW: w }).svg; y += u * 2.5; const r = TT(c, t('Заклад і роки'), e.org + ' | ' + e.dates, x, y, u * 1.45, { fill: mixC(c.ink, '#FFFFFF', 0.35), maxW: w, lh: 1.35 }); s += r.svg; y += r.h + u * 2; } return { svg: s, y }; };
  const CVL = {};
  // ---------- in the Pinterest manner ----------
  CVL.arch = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), paper = mixC(c.a2, '#FFFFFF', 0.86), sw = W * 0.36; let s = RC(t('Тло'), 0, 0, W, H, { fill: paper }) + photo(c, u * 5, u * 5, sw - u * 4, u * 38, { rx: (sw - u * 4) / 2 }); let y = u * 49; for (const [l, it] of [[t('Контакти'), cv.contacts], [t('Навички'), cv.skills], [t('Мови'), cv.langs]]) { const r = sideSec(p, u * 5, y, sw - u * 7, l, it, { bs: u * 1.62 }); s += r.svg; y = r.y; } const x0 = sw + u * 4, w = W - x0 - u * 5; s += LN(t('Лінія'), sw + u * 1.5, u * 6, sw + u * 1.5, H - u * 6, { stroke: p.a1, sw: u * 0.12, op: 0.5 }); s += nameT(p, cv, x0, u * 11, u * 5, w, { weight: 700 }).svg + roleT(p, cv, x0, u * 21, u * 2, { upper: true, ls: u * 0.3 }).svg; return s + cvSections(p, x0, u * 24, w, { cv, skills: false, langs: false, hs: u * 2.18, bs: u * 1.68, bg: paper }).svg; };
  CVL.circle = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c); let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + RC(t('Шапка'), 0, 0, W, u * 22, { fill: mixC(c.a1, '#FFFFFF', 0.72) }) + CI(t('Кільце'), W / 2, u * 22, u * 11.6, { fill: '#FFFFFF' }) + photo(c, W / 2 - u * 10.5, u * 11.5, u * 21, u * 21, { rx: u * 10.5 }); s += TT(c, t('Ім’я'), cv.name, W / 2, u * 40, fit(c, cv.name, u * 4.6, W - u * 20, 1, false, c.fh), { anchor: 'middle', family: c.fh, weight: 800, fill: p.ink }).svg + roleT(p, cv, W / 2, u * 44, u * 2, { anchor: 'middle', upper: true, ls: u * 0.3 }).svg + TT(c, t('Контакти'), cv.contacts.join('  ·  '), W / 2, u * 48, u * 1.45, { anchor: 'middle', fill: '#555560', maxW: W - u * 12 }).svg; const lw = W * 0.29; let y = u * 55; for (const [l, it] of [[t('Навички'), cv.skills], [t('Мови'), cv.langs]]) { const r = sideSec(p, u * 6, y, lw - u * 4, l, it, { bs: u * 1.62 }); s += r.svg; y = r.y; } return s + cvSections(p, lw + u * 4, u * 53, W - lw - u * 10, { cv, skills: false, langs: false, hs: u * 2.13, bs: u * 1.62 }).svg; };
  CVL.pastel = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c); let s = RC(t('Тло'), 0, 0, W, H, { fill: mixC(c.a1, '#FFFFFF', 0.68) }) + RC(t('Картка'), u * 4, u * 4, W - u * 8, H - u * 8, { fill: '#FFFFFF', rx: u * 3 }) + photo(c, u * 9, u * 9, u * 15, u * 15, { rx: u * 7.5 }); s += nameT(p, cv, u * 28, u * 15, u * 4.6, W - u * 38, { lines: 1 }).svg + roleT(p, cv, u * 28, u * 20, u * 2).svg + TT(c, t('Контакти'), cv.contacts.join(' | '), u * 9, u * 29, u * 1.45, { fill: '#555560', maxW: W - u * 18 }).svg + LN(t('Лінія'), u * 9, u * 31.5, W - u * 9, u * 31.5, { stroke: p.a1, sw: u * 0.15 }); return s + cvSections(p, u * 9, u * 33, W - u * 18, { cv, hs: u * 2.18, bs: u * 1.68 }).svg; };
  CVL.split = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), sw = W * 0.38, ink = onC(c.a1); let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + RC(t('Бічна панель'), 0, 0, sw, H, { fill: c.a1 }) + photo(c, u * 5, u * 5, sw - u * 10, sw - u * 10, { rx: u * 2 }); let y = sw + u * 2; s += TT(c, t('Ім’я'), cv.name, u * 5, y + u * 3, fit(c, cv.name, u * 4.2, sw - u * 10, 2, false, c.fh), { family: c.fh, weight: 800, fill: ink, maxW: sw - u * 10, lh: 1.05 }).svg; y += u * 12; s += TT(c, t('Бажана посада'), cv.role, u * 5, y, u * 1.8, { fill: ink, weight: 700, maxW: sw - u * 10 }).svg; y += u * 6; for (const [l, it] of [[t('Контакти'), cv.contacts], [t('Мови'), cv.langs]]) { const r = sideSec(c, u * 5, y, sw - u * 10, l, it, { hc: ink, fill: ink, bs: u * 1.57 }); s += r.svg; y = r.y; } return s + cvSections(p, sw + u * 5, u * 7, W - sw - u * 10, { cv, langs: false, hs: u * 2.18, bs: u * 1.68 }).svg; };
  CVL.monogram = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), paper = mixC(c.sf, '#FFFFFF', 0.55); let s = RC(t('Тло'), 0, 0, W, H, { fill: paper }) + CI(t('Монограма'), W / 2, u * 12, u * 6.5, { stroke: p.a1, sw: u * 0.2 }) + TT(c, t('Монограма'), initials(cv.name), W / 2, u * 14, u * 5, { anchor: 'middle', family: c.fh, weight: 600, fill: p.a1 }).svg; s += TT(c, t('Ім’я'), cv.name, W / 2, u * 26, fit(c, cv.name, u * 4, W - u * 20, 1, true, c.fh), { anchor: 'middle', family: c.fh, weight: 600, upper: true, ls: u * 0.5, fill: p.ink }).svg + roleT(p, cv, W / 2, u * 30.5, u * 1.8, { anchor: 'middle', upper: true, ls: u * 0.4, weight: 600 }).svg + LN(t('Лінія'), u * 10, u * 33, W - u * 10, u * 33, { stroke: p.ink, sw: u * 0.1 }) + TT(c, t('Контакти'), cv.contacts.join('   '), W / 2, u * 36, u * 1.4, { anchor: 'middle', fill: '#555560', maxW: W - u * 16 }).svg + LN(t('Лінія'), u * 10, u * 38, W - u * 10, u * 38, { stroke: p.ink, sw: u * 0.1 }); return s + cvSections(p, u * 10, u * 40, W - u * 20, { cv, hs: u * 2.13, bs: u * 1.68, bg: paper }).svg; };
  CVL.timeline = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c); let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + CI(t('Кільце'), W - u * 16, u * 15, u * 10.4, { stroke: p.a1, sw: u * 0.4 }) + photo(c, W - u * 25.5, u * 5.5, u * 19, u * 19, { rx: u * 9.5 }); s += nameT(p, cv, u * 7, u * 12, u * 5, W - u * 40).svg + roleT(p, cv, u * 7, u * 22, u * 2).svg; let y = u * 26.5; cv.contacts.forEach((ct, i) => { s += TT(c, t('Контакти'), ct, u * 7 + (i % 2) * (W - u * 40) / 2, y + Math.floor(i / 2) * u * 2.6, u * 1.4, { fill: '#555560' }).svg; }); y = u * 35; const r0 = TT(c, t('Профіль'), cv.summary, u * 7, y, u * 1.55, { fill: '#444450', maxW: W - u * 14, lh: 1.4 }); s += r0.svg; y += r0.h + u * 4; const tl = timelineJobs(p, cv, u * 7, y, W - u * 14); s += tl.svg; y = tl.y + u; const half = (W - u * 18) / 2; const e = eduBlock(p, cv, u * 7, y, half); s += e.svg; s += TT(c, t('Розділ') + ': ' + t('Навички'), t('Навички'), u * 11 + half, y, u * 2, { upper: true, weight: 800, ls: u * 0.25, fill: p.a1, family: c.fh }).svg; s += chips(p, u * 11 + half, y + u * 5, half, cv.skills).svg; return s; };
  CVL.blob = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c); let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + PA(t('Фігура'), blob(W - u * 14, u * 12, u * 26, 3), { fill: mixC(c.a1, '#FFFFFF', 0.62) }) + PA(t('Фігура'), blob(u * 4, H - u * 6, u * 20, 7), { fill: mixC(c.a2, '#FFFFFF', 0.6) }) + photo(c, W - u * 27, u * 5, u * 21, u * 21, { rx: u * 10.5 }); s += nameT(p, cv, u * 7, u * 12, u * 5.2, W - u * 40).svg + roleT(p, cv, u * 7, u * 22, u * 2).svg + TT(c, t('Контакти'), cv.contacts.join(' | '), u * 7, u * 30, u * 1.45, { fill: '#555560', maxW: W - u * 14 }).svg; return s + cvSections(p, u * 7, u * 33, W - u * 14, { cv, hs: u * 2.18, bs: u * 1.68 }).svg; };
  CVL.skillbars = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), sw = W * 0.34, side = mixC(c.a1, '#FFFFFF', 0.86); let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + RC(t('Бічна панель'), 0, 0, sw, H, { fill: side }) + photo(c, sw / 2 - u * 10, u * 6, u * 20, u * 20, { rx: u * 10 }); let y = u * 33; const r1 = sideSec(p, u * 5, y, sw - u * 9, t('Контакти'), cv.contacts, { bs: u * 1.57 }); s += r1.svg; y = r1.y; s += TT(c, t('Розділ') + ': ' + t('Навички'), t('Навички'), u * 5, y, u * 2, { upper: true, weight: 800, ls: u * 0.3, fill: p.a1 }).svg; const sb = skillBars(p, u * 5, y + u * 3.6, sw - u * 10, cv.skills.slice(0, 6)); s += sb.svg; y = sb.y + u; const r2 = sideSec(p, u * 5, y, sw - u * 9, t('Мови'), cv.langs, { bs: u * 1.57 }); s += r2.svg; const x0 = sw + u * 5, w = W - x0 - u * 5; return s + nameT(p, cv, x0, u * 11, u * 4.8, w).svg + roleT(p, cv, x0, u * 21, u * 2).svg + cvSections(p, x0, u * 24, w, { cv, skills: false, langs: false, hs: u * 2.13, bs: u * 1.68 }).svg; };
  CVL.magazine = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), ph = H * 0.24, ink = onC(c.a1); let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + photo(c, 0, 0, W, ph) + RC(t('Плашка'), 0, ph - u * 10, W, u * 10, { fill: c.a1, op: 0.92 }) + TT(c, t('Ім’я'), cv.name, u * 6, ph - u * 3.4, fit(c, cv.name, u * 4.2, W * 0.55, 1, false, c.fh), { family: c.fh, weight: 800, fill: ink }).svg + TT(c, t('Бажана посада'), cv.role, W - u * 6, ph - u * 3.8, u * 1.8, { anchor: 'end', weight: 700, fill: ink, upper: true, ls: u * 0.2 }).svg; const rw = W * 0.3, x1 = W - rw - u * 4; let y = ph + u * 6; for (const [l, it] of [[t('Контакти'), cv.contacts], [t('Навички'), cv.skills], [t('Мови'), cv.langs]]) { const r = sideSec(p, x1, y, rw - u * 2, l, it, { bs: u * 1.57 }); s += r.svg; y = r.y; } s += LN(t('Лінія'), x1 - u * 2.5, ph + u * 4, x1 - u * 2.5, H - u * 5, { stroke: p.a1, sw: u * 0.12, op: 0.5 }); return s + cvSections(p, u * 6, ph + u * 3, x1 - u * 11, { cv, skills: false, langs: false, hs: u * 2.13, bs: u * 1.66 }).svg; };
  CVL.botanical = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), paper = mixC(c.sf, '#FFFFFF', 0.6), green = O.color.luminance(c.a2) > 0.65 ? mixC(c.a2, '#000000', 0.35) : c.a2; let s = RC(t('Тло'), 0, 0, W, H, { fill: paper }); [[W - u * 2, u * 2, 150], [W - u * 6, u * 2, 120], [W - u * 2, u * 7, 175], [W - u * 11, u * 1, 105], [u * 2, H - u * 2, -30], [u * 6, H - u * 2, -60], [u * 2, H - u * 8, 5]].forEach(([x, y, a], i) => { s += PA(t('Листок'), leaf(x, y, u * (14 - (i % 3) * 2.5), a), { fill: green, op: 0.55 + (i % 3) * 0.12 }); }); s += photo(c, u * 7, u * 7, u * 18, u * 23, { rx: u * 9 }) + TT(c, t('Ім’я'), cv.name, u * 30, u * 15, fit(c, cv.name, u * 5, W - u * 50, 2, false, c.fh), { family: c.fh, italic: true, weight: 600, fill: p.ink, maxW: W - u * 50, lh: 1.05 }).svg + roleT(p, cv, u * 30, u * 25, u * 1.8, { upper: true, ls: u * 0.3, weight: 600 }).svg + TT(c, t('Контакти'), cv.contacts.join('  ·  '), u * 7, u * 35, u * 1.4, { fill: '#555560', maxW: W - u * 14 }).svg; return s + cvSections(p, u * 7, u * 38, W - u * 14, { cv, hs: u * 2.13, bs: u * 1.66, bg: paper }).svg; };
  // ---------- premium, in the Canva Pro manner ----------
  const navy = c => (O.color.luminance(c.ink) < 0.3 ? c.ink : '#1F2A44');
  const gold = c => (O.color.luminance(c.a1) > 0.25 && O.color.luminance(c.a1) < 0.8 ? c.a1 : '#C8A24A');
  CVL.executive = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), nv = navy(c), gd = gold(c); let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + RC(t('Шапка'), 0, 0, W, u * 25, { fill: nv }) + RC(t('Акцент'), 0, u * 25, W, u * 0.8, { fill: gd }); s += TT(c, t('Ім’я'), cv.name, u * 7, u * 12, fit(c, cv.name, u * 5.4, W - u * 14, 1, true, c.fh), { family: c.fh, weight: 700, upper: true, ls: u * 0.4, fill: '#FFFFFF' }).svg + TT(c, t('Бажана посада'), cv.role, u * 7, u * 16.5, u * 2, { fill: gd, upper: true, ls: u * 0.5, weight: 700 }).svg + TT(c, t('Контакти'), cv.contacts.join('   |   '), u * 7, u * 21.5, u * 1.4, { fill: '#FFFFFF', op: 0.85, maxW: W - u * 14 }).svg; const rw = W * 0.3, x1 = W - rw - u * 5; let y = u * 32; for (const [l, it] of [[t('Навички'), cv.skills], [t('Мови'), cv.langs]]) { const r = sideSec(Object.assign({}, p, { a1: nv }), x1, y, rw, l, it, { bs: u * 1.62 }); s += r.svg; y = r.y; } s += RC(t('Бічна панель'), x1 - u * 3, u * 29, rw + u * 6, H - u * 34, { fill: nv, op: 0.05 }); return s + cvSections(Object.assign({}, p, { a1: nv }), u * 7, u * 30, x1 - u * 13, { cv, skills: false, langs: false, hs: u * 2.18, bs: u * 1.68, hc: nv }).svg; };
  CVL.gradient = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), sw = W * 0.35, a = deepAcc(c, 0.3), b = mixC(deepAcc(c, 0.3), c.a2, 0.55); let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + RC(t('Бічна панель'), 0, 0, sw, H, { fill: grad(c, a, b, 0, 1) }) + CI(t('Кільце'), sw / 2, u * 17, u * 11.2, { fill: '#FFFFFF' }) + photo(c, sw / 2 - u * 10.4, u * 6.6, u * 20.8, u * 20.8, { rx: u * 10.4 }); let y = u * 35; for (const [l, it] of [[t('Контакти'), cv.contacts], [t('Навички'), cv.skills], [t('Мови'), cv.langs]]) { const r = sideSec(c, u * 5, y, sw - u * 9, l, it, { hc: '#FFFFFF', fill: '#FFFFFF', bs: u * 1.57 }); s += r.svg; y = r.y; } const x0 = sw + u * 5, w = W - x0 - u * 5; return s + nameT(p, cv, x0, u * 12, u * 5.2, w, { weight: 900 }).svg + roleT(p, cv, x0, u * 22.5, u * 2, { fill: a }).svg + cvSections(Object.assign({}, p, { a1: a }), x0, u * 26, w, { cv, skills: false, langs: false, hs: u * 2.13, bs: u * 1.68 }).svg; };
  CVL.geo = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), a = deepAcc(c, 0.3); let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + PG(t('Фігура'), [[W * 0.55, 0], [W, 0], [W, u * 30]], { fill: a }) + PG(t('Фігура'), [[W * 0.72, 0], [W, 0], [W, u * 18]], { fill: c.a2, op: 0.85 }) + PG(t('Фігура'), [[W * 0.62, 0], [W * 0.86, 0], [W * 0.74, u * 14]], { fill: navy(c), op: 0.9 }) + PG(t('Фігура'), [[0, H], [u * 26, H], [0, H - u * 22]], { fill: a, op: 0.9 }); s += TT(c, t('Ім’я'), cv.name, u * 7, u * 13, fit(c, cv.name, u * 5.6, W * 0.55, 2, true, c.fh), { family: c.fh, weight: 900, upper: true, fill: p.ink, maxW: W * 0.55, lh: 1 }).svg + roleT(p, cv, u * 7, u * 24, u * 2, { fill: a, upper: true, ls: u * 0.3 }).svg + TT(c, t('Контакти'), cv.contacts.join(' | '), u * 7, u * 29, u * 1.4, { fill: '#555560', maxW: W - u * 14 }).svg; return s + cvSections(Object.assign({}, p, { a1: a }), u * 7, u * 32, W - u * 14, { cv, hs: u * 2.18, bs: u * 1.68 }).svg; };
  CVL.grid = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), a = O.color.luminance(c.a1) > 0.6 ? '#D7263D' : c.a1, lw = W * 0.3; let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + RC(t('Акцент'), u * 6, u * 6, u * 4, u * 4, { fill: a }); const parts = cv.name.split(' '); s += TT(c, t('Ім’я'), parts[0], u * 6, u * 19, u * 6.5, { family: c.fh, weight: 900, upper: true, fill: p.ink }).svg + TT(c, t('Прізвище'), parts.slice(1).join(' '), u * 6, u * 26, u * 6.5, { family: c.fh, weight: 900, upper: true, fill: p.ink }).svg + roleT(p, cv, u * 6, u * 31, u * 1.9, { fill: a }).svg + RC(t('Лінія'), u * 6, u * 34, W - u * 12, u * 0.5, { fill: p.ink }); let y = u * 41; ['01', '02', '03'].forEach((n, i) => { const [l, it] = [[t('Контакти'), cv.contacts], [t('Навички'), cv.skills], [t('Мови'), cv.langs]][i]; s += TT(c, t('Номер'), n, u * 6, y, u * 3.4, { family: c.fh, weight: 900, fill: a }).svg; const r = sideSec(p, u * 6, y + u * 4, lw - u * 8, l, it, { hc: p.ink, bs: u * 1.57 }); s += r.svg; y = r.y + u; }); return s + cvSections(Object.assign({}, p, { a1: a }), lw + u * 2, u * 38, W - lw - u * 8, { cv, skills: false, langs: false, hs: u * 2.13, bs: u * 1.68, hc: p.ink }).svg; };
  CVL.creative = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), a = deepAcc(c, 0.3), b = O.color.luminance(c.a2) > 0.65 ? mixC(c.a2, '#000000', 0.35) : c.a2; let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + TT(c, t('Ініціали'), initials(cv.name), W - u * 4, u * 30, u * 32, { anchor: 'end', family: c.fh, weight: 900, fill: mixC(a, '#FFFFFF', 0.85) }).svg + RC(t('Акцент'), 0, 0, u * 2.4, H, { fill: a }) + RC(t('Акцент'), u * 2.4, 0, u * 1.2, H, { fill: b }); s += nameT(p, cv, u * 9, u * 13, u * 6, W * 0.6, { weight: 900 }).svg + roleT(p, cv, u * 9, u * 24, u * 2.1, { fill: b }).svg + TT(c, t('Контакти'), cv.contacts.join(' | '), u * 9, u * 28.5, u * 1.4, { fill: '#555560', maxW: W - u * 14 }).svg; const r = cvSections(Object.assign({}, p, { a1: a }), u * 9, u * 31, W - u * 16, { cv, skills: false, hs: u * 2.18, bs: u * 1.68, hc: b }); s += r.svg; s += TT(c, t('Розділ') + ': ' + t('Навички'), t('Навички'), u * 9, r.y + u * 2, u * 1.95, { family: c.fh, weight: 800, upper: true, fill: b }).svg; return s + chips(p, u * 9, r.y + u * 7, W - u * 16, cv.skills, { fill: mixC(a, '#FFFFFF', 0.85) }).svg; };
  CVL.photohero = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), pw = W * 0.38; let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + photo(c, 0, 0, pw, H) + RC(t('Затемнення'), 0, H * 0.5, pw, H * 0.5, { fill: shade(c, '#000000', 0, 0.82) }); s += TT(c, t('Ім’я'), cv.name, u * 5, H - u * 22, fit(c, cv.name, u * 5, pw - u * 10, 2, false, c.fh), { family: c.fh, weight: 800, fill: '#FFFFFF', maxW: pw - u * 10, lh: 1.05 }).svg + TT(c, t('Бажана посада'), cv.role, u * 5, H - u * 9, u * 1.8, { fill: '#FFFFFF', weight: 700, upper: true, ls: u * 0.2, maxW: pw - u * 10 }).svg; const x0 = pw + u * 5, w = W - x0 - u * 5; const r1 = sideSec(p, x0, u * 8, w, t('Контакти'), cv.contacts.slice(0, 2).concat([cv.contacts.slice(2).join(' · ')]), { bs: u * 1.57 }); s += r1.svg; const r = cvSections(p, x0, r1.y - u * 2, w, { cv, langs: false, hs: u * 2.07, bs: u * 1.59 }); s += r.svg; return s + TT(c, t('Мови'), cv.langs.join(' · '), x0, r.y + u * 1.5, u * 1.42, { fill: '#555560', maxW: w }).svg; };
  CVL.luxe = c => { const { W, H, u } = c, cv = persona(c), gd = '#C9A96A', bgc = '#141414'; const p = Object.assign({}, c, { ink: '#ECE7DF', a1: gd }); let s = RC(t('Тло'), 0, 0, W, H, { fill: bgc }) + RC(t('Рамка'), u * 3, u * 3, W - u * 6, H - u * 6, { stroke: gd, sw: u * 0.15 }) + RC(t('Рамка'), u * 4, u * 4, W - u * 8, H - u * 8, { stroke: gd, sw: u * 0.08, op: 0.6 }); s += TT(c, t('Ім’я'), cv.name, W / 2, u * 14, fit(c, cv.name, u * 4.6, W - u * 20, 1, true, c.fh), { anchor: 'middle', family: c.fh, weight: 500, upper: true, ls: u * 0.6, fill: gd }).svg + TT(c, t('Бажана посада'), cv.role, W / 2, u * 19, u * 1.8, { anchor: 'middle', upper: true, ls: u * 0.6, fill: '#ECE7DF' }).svg + LN(t('Лінія'), W / 2 - u * 8, u * 22, W / 2 + u * 8, u * 22, { stroke: gd, sw: u * 0.15 }) + TT(c, t('Контакти'), cv.contacts.join('   '), W / 2, u * 25.5, u * 1.35, { anchor: 'middle', fill: '#BDB6AA', maxW: W - u * 16 }).svg; return s + cvSections(p, u * 9, u * 29, W - u * 18, { cv, hs: u * 2.07, bs: u * 1.68, bg: bgc, hc: gd, upper: true }).svg; };
  CVL.icons = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), a = deepAcc(c, 0.3); let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + RC(t('Шапка'), 0, 0, W, u * 26, { fill: mixC(a, '#FFFFFF', 0.9) }) + CI(t('Кільце'), u * 16, u * 13, u * 9.4, { stroke: a, sw: u * 0.5 }) + photo(c, u * 7.5, u * 4.5, u * 17, u * 17, { rx: u * 8.5 }); s += nameT(p, cv, u * 30, u * 11, u * 5, W - u * 36).svg + roleT(p, cv, u * 30, u * 21, u * 2, { fill: a }).svg + TT(c, t('Контакти'), cv.contacts.join(' | '), u * 7, u * 31, u * 1.4, { fill: '#555560', maxW: W - u * 14 }).svg; return s + cvSections(Object.assign({}, p, { a1: a }), u * 12, u * 35, W - u * 18, { cv, hs: u * 2.13, bs: u * 1.66, badge: true }).svg; };
  CVL.infographic = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), a = deepAcc(c, 0.3), ink = onC(a), lw = W * 0.34; let s = RC(t('Тло'), 0, 0, W, H, { fill: '#FFFFFF' }) + RC(t('Шапка'), 0, 0, W, u * 22, { fill: a }) + nameT(Object.assign({}, p, { ink }), cv, u * 6, u * 10, u * 5, W - u * 12, { lines: 1, fill: ink }).svg + TT(c, t('Бажана посада'), cv.role, u * 6, u * 15, u * 2, { fill: ink, weight: 700 }).svg + TT(c, t('Контакти'), cv.contacts.join(' | '), u * 6, u * 19, u * 1.35, { fill: ink, op: 0.85, maxW: W - u * 12 }).svg; let y = u * 30; (cv.stats || []).forEach(([n, l]) => { s += TT(c, t('Число'), n, u * 6, y, u * 4.4, { family: c.fh, weight: 900, fill: a }).svg + TT(c, t('Підпис'), l, u * 6, y + u * 2.6, u * 1.4, { fill: '#555560', maxW: lw - u * 8 }).svg; y += u * 8.5; }); y += u; s += TT(c, t('Розділ') + ': ' + t('Навички'), t('Навички'), u * 6, y, u * 1.9, { upper: true, weight: 800, ls: u * 0.3, fill: a }).svg; y += u * 6.5; cv.skills.slice(0, 4).forEach((sk, i) => { const cx = u * 6 + (i % 2) * (lw - u * 8) / 2 + u * 4.5, cy = y + Math.floor(i / 2) * u * 13, r = u * 4, k = 0.6 + ((i * 29) % 35) / 100, ang = -Math.PI / 2 + k * Math.PI * 2; s += CI(t('Шкала'), cx, cy, r, { stroke: mixC(a, '#FFFFFF', 0.8), sw: u * 1.1 }) + PA(t('Дуга'), `M${q(cx)} ${q(cy - r)}A${q(r)} ${q(r)} 0 ${k > 0.5 ? 1 : 0} 1 ${q(cx + Math.cos(ang) * r)} ${q(cy + Math.sin(ang) * r)}`, { stroke: a, sw: u * 1.1, cap: 'round' }) + TT(c, t('Рівень'), Math.round(k * 100) + '%', cx, cy + u * 0.5, u * 1.3, { anchor: 'middle', weight: 800, fill: p.ink }).svg + TT(c, t('Навичка'), sk, cx, cy + r + u * 3, u * 1.3, { anchor: 'middle', fill: p.ink, maxW: (lw - u * 8) / 2 }).svg; }); y += u * 28; s += sideSec(p, u * 6, y, lw - u * 8, t('Мови'), cv.langs, { bs: u * 1.57, hc: a }).svg; s += LN(t('Лінія'), lw, u * 27, lw, H - u * 6, { stroke: mixC(a, '#FFFFFF', 0.7), sw: u * 0.15 }); return s + cvSections(Object.assign({}, p, { a1: a }), lw + u * 4, u * 28, W - lw - u * 9, { cv, skills: false, langs: false, hs: u * 2.13, bs: u * 1.66 }).svg; };
  CVL.twotone = c => { const { W, H, u } = c, cv = persona(c), p = onPaper(c), a = deepAcc(c, 0.3), ink = onC(a); let s = RC(t('Тло'), 0, 0, W, H, { fill: mixC(c.a2, '#FFFFFF', 0.82) }) + PG(t('Фігура'), [[0, 0], [W, 0], [W, u * 22], [0, u * 48]], { fill: a }) + RC(t('Тінь'), u * 7.2, u * 25.2, W - u * 12, H - u * 30, { fill: '#000000', op: 0.08, rx: u * 2 }) + RC(t('Картка'), u * 6, u * 24, W - u * 12, H - u * 30, { fill: '#FFFFFF', rx: u * 2 }); s += nameT(Object.assign({}, p, { ink }), cv, u * 7, u * 10, u * 5.2, W - u * 14, { lines: 1, fill: ink }).svg + TT(c, t('Бажана посада'), cv.role, u * 7, u * 15, u * 2, { fill: ink, weight: 700, upper: true, ls: u * 0.3 }).svg + TT(c, t('Контакти'), cv.contacts.join(' | '), u * 7, u * 19.5, u * 1.35, { fill: ink, op: 0.9, maxW: W - u * 14 }).svg; return s + cvSections(Object.assign({}, p, { a1: a }), u * 11, u * 30, W - u * 22, { cv, hs: u * 2.13, bs: u * 1.66 }).svg; };
  Object.entries(CVL).forEach(([k, f]) => { L['cvx-' + k] = f; });

  // ======================================================================
  // 1000 IDEAS: 50 kinds of design people make in Canva (hiring, giveaway, testimonial, collage, coupon, ticket,
  // holidays, webinar, landing page…) — original VIBSma layouts — × 20 colour-and-font styles each
  // ======================================================================
  const items = s => String(s || '').split('|').map(x => x.trim()).filter(Boolean);
  const heart = (cx, cy, s) => `M${q(cx)} ${q(cy + s * 0.9)}C${q(cx - s * 1.6)} ${q(cy - s * 0.1)} ${q(cx - s * 0.75)} ${q(cy - s * 1.1)} ${q(cx)} ${q(cy - s * 0.4)}C${q(cx + s * 0.75)} ${q(cy - s * 1.1)} ${q(cx + s * 1.6)} ${q(cy - s * 0.1)} ${q(cx)} ${q(cy + s * 0.9)}Z`;
  const bg = (c, fill) => RC(t('Тло'), 0, 0, c.W, c.H, { fill: fill || c.bg });
  const head = (c, x, y, w, size, o = {}) => TT(c, t('Заголовок'), c.txt.title, x, y, fit(c, c.txt.title, size, w, o.lines || 2, o.upper), Object.assign({ family: c.fh, weight: 900, maxW: w, lh: 1.02 }, o));
  const listRows = (c, x, y, w, size, list, o = {}) => { let s = ''; list.forEach((it, i) => { const yy = y + i * size * (o.gap || 2.2); s += (o.bullet === false ? '' : o.num ? CI(t('Номер'), x + size * 0.6, yy - size * 0.35, size * 0.75, { fill: o.bc || c.a1 }) + TT(c, t('Номер'), String(i + 1), x + size * 0.6, yy, size * 0.8, { anchor: 'middle', weight: 800, fill: onC(o.bc || c.a1) }).svg : CI(t('Маркер списку'), x + size * 0.3, yy - size * 0.35, size * 0.22, { fill: o.bc || c.a1 })) + TT(c, t('Пункт'), it, x + size * (o.bullet === false ? 0 : 1.6), yy, size, { fill: o.fill || c.ink, weight: o.weight || 500, maxW: w - size * 1.6 }).svg; }); return s; };
  const I = {};
  I.hiring = c => { const { W, H, u } = c; let s = bg(c, c.a1) + CI(t('Коло'), W * 0.88, H * 0.12, u * 22, { fill: c.a2, op: 0.9 }); s += TT(c, t('Підпис'), c.txt.kicker, c.pad, c.pad + u * 3, u * 3, { upper: true, weight: 800, fill: onC(c.a1), ls: u * 0.4 }).svg; s += head(c, c.pad, H * 0.27, W - c.pad * 2, u * 14, { upper: true, fill: onC(c.a1) }).svg; s += TT(c, t('Посада'), c.txt.sub, c.pad, H * 0.5, u * 5, { weight: 700, fill: onC(c.a1), maxW: W - c.pad * 2 }).svg; s += listRows(c, c.pad, H * 0.6, W - c.pad * 2, u * 3.4, items(c.txt.body), { fill: onC(c.a1), bc: c.a2 }); return s + pill(c, c.txt.cta, c.pad, H * 0.84, u * 3, { fill: c.ink }).svg; };
  I.giveaway = c => { const { W, H, u } = c; let s = bg(c, grad(c, c.a1, c.a2)); const bx = W / 2, by = H * 0.3, bw = u * 30; s += RC(t('Коробка'), bx - bw / 2, by - bw * 0.35, bw, bw * 0.75, { fill: '#FFFFFF', rx: u * 2 }) + RC(t('Кришка'), bx - bw * 0.56, by - bw * 0.5, bw * 1.12, bw * 0.2, { fill: c.ink, rx: u * 1.5 }) + RC(t('Стрічка'), bx - u * 2.5, by - bw * 0.5, u * 5, bw * 0.9, { fill: c.ink }) + E(t('Бант'), bx - u * 6, by - bw * 0.58, u * 6, u * 3.5, { fill: c.ink }) + E(t('Бант'), bx + u * 6, by - bw * 0.58, u * 6, u * 3.5, { fill: c.ink }); s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.62, fit(c, c.txt.title, u * 11, W * 0.86, 1, true), { family: c.fh, weight: 900, upper: true, anchor: 'middle', fill: '#FFFFFF' }).svg; const st = items(c.txt.body); st.forEach((it, i) => { const x = W * (0.2 + i * 0.3); s += CI(t('Номер'), x, H * 0.74, u * 4.5, { fill: '#FFFFFF' }) + TT(c, t('Номер'), String(i + 1), x, H * 0.74 + u * 1.7, u * 5, { anchor: 'middle', weight: 900, fill: c.a1 }).svg + TT(c, t('Пункт'), it, x, H * 0.84, u * 2.6, { anchor: 'middle', fill: '#FFFFFF', weight: 700, maxW: W * 0.28 }).svg; }); return s + foot(c, '#FFFFFF', 'middle'); };
  I.testimonial = c => { const { W, H, u } = c; let s = bg(c, c.sf) + TT(c, t('Лапки'), '“', c.pad, c.pad + u * 24, u * 32, { family: 'Georgia', fill: c.a1, weight: 700 }).svg; s += TT(c, t('Зірки'), '★★★★★', c.pad, H * 0.36, u * 5, { fill: c.a2 === c.sf ? c.a1 : c.a2 }).svg; s += TT(c, t('Відгук'), c.txt.body, c.pad, H * 0.47, u * 4.4, { family: c.fh, italic: true, weight: 600, maxW: W - c.pad * 2, lh: 1.3, maxLines: 5 }).svg; s += CI(t('Місце для фото'), c.pad + u * 6, H * 0.84, u * 6, { fill: mixC(c.a1, '#FFFFFF', 0.5) }); s += TT(c, t('Ім’я'), c.txt.title, c.pad + u * 15, H * 0.83, u * 3.6, { weight: 800 }).svg + TT(c, t('Посада'), c.txt.sub, c.pad + u * 15, H * 0.83 + u * 4.4, u * 2.6, { fill: mixC(c.ink, c.sf, 0.4) }).svg; return s; };
  I.collage4 = c => { const { W, H, u } = c, g = u * 1.6, cw = (W - g * 3) / 2, ch = (H - g * 3) / 2; let s = bg(c); for (let i = 0; i < 4; i++) s += photo(c, g + (i % 2) * (cw + g), g + Math.floor(i / 2) * (ch + g), cw, ch, { rx: u * 2 }); const tw = Math.min(W * 0.7, c.txt.title.length * u * 3.6 + u * 10); s += RC(t('Плашка'), (W - tw) / 2, H / 2 - u * 6, tw, u * 12, { fill: c.bg, rx: u * 6 }) + TT(c, t('Заголовок'), c.txt.title, W / 2, H / 2 + u * 2.2, fit(c, c.txt.title, u * 6, tw - u * 6, 1), { family: c.fh, weight: 800, anchor: 'middle' }).svg; return s; };
  I.collage3 = c => { const { W, H, u } = c, g = u * 2; let s = bg(c) + photo(c, g, g, W - g * 2, H * 0.42, { rx: u * 3 }) + photo(c, g, H * 0.42 + g * 2, (W - g * 3) / 2, H * 0.3, { rx: u * 3 }) + photo(c, W / 2 + g / 2, H * 0.42 + g * 2, (W - g * 3) / 2, H * 0.3, { rx: u * 3 }); s += head(c, c.pad, H * 0.82, W - c.pad * 2, u * 9).svg + TT(c, t('Підзаголовок'), c.txt.sub, c.pad, H * 0.92, u * 3.2, { fill: mixC(c.ink, c.bg, 0.3) }).svg; return s; };
  I.carousel = (c, page = 0) => { const { W, H, u } = c; let s = bg(c, page % 2 ? c.sf : c.bg) + TT(c, t('Номер слайда'), `${page + 1}/3`, W - c.pad, c.pad + u * 3, u * 3, { anchor: 'end', weight: 700, fill: c.a1 }).svg; if (!page) { s += TT(c, t('Підпис'), c.txt.kicker, c.pad, H * 0.3, u * 3, { upper: true, weight: 800, fill: c.a1, ls: u * 0.3 }).svg + head(c, c.pad, H * 0.45, W - c.pad * 2, u * 11, { lines: 3 }).svg + TT(c, t('Гортай'), '→ ' + c.txt.cta, c.pad, H * 0.88, u * 3.6, { weight: 800, fill: c.a1 }).svg; } else { const it = items(c.txt.body)[page - 1] || c.txt.sub; s += TT(c, t('Номер'), '0' + page, c.pad, H * 0.32, u * 16, { family: c.fh, weight: 900, fill: c.a1 }).svg + TT(c, t('Пункт'), it, c.pad, H * 0.5, u * 6, { family: c.fh, weight: 800, maxW: W - c.pad * 2, lh: 1.1 }).svg + TT(c, t('Текст'), c.txt.sub, c.pad, H * 0.75, u * 3, { maxW: W - c.pad * 2, fill: mixC(c.ink, c.bg, 0.3), lh: 1.4 }).svg; } return s; };
  I.carousel.multi = true;
  I.webinar = c => { const { W, H, u } = c; let s = bg(c) + CI(t('Місце для фото'), W * 0.75, H * 0.45, Math.min(W, H) * 0.25, { fill: mixC(c.a1, '#FFFFFF', 0.45) }) + CI(t('Кільце'), W * 0.75, H * 0.45, Math.min(W, H) * 0.28, { stroke: c.a1, sw: u * 0.8 }); s += RC(t('Дата'), c.pad, c.pad, u * 34, u * 7, { fill: c.a1, rx: u * 3.5 }) + TT(c, t('Дата'), c.txt.kicker, c.pad + u * 17, c.pad + u * 4.8, u * 3, { anchor: 'middle', weight: 800, fill: onC(c.a1) }).svg; s += head(c, c.pad, H * 0.4, W * 0.5, u * 9, { lines: 3 }).svg + TT(c, t('Ім’я'), c.txt.sub, c.pad, H * 0.72, u * 3.4, { weight: 700, fill: c.a1 }).svg; return s + pill(c, c.txt.cta, c.pad, H * 0.8, u * 3).svg; };
  I.podcastc = c => { const { W, H, u } = c; let s = bg(c, c.ink === '#FFFFFF' ? c.bg : '#121218') + CI(t('Коло'), W / 2, H * 0.4, u * 26, { fill: c.a1 }); s += RC(t('Мікрофон'), W / 2 - u * 6, H * 0.4 - u * 15, u * 12, u * 20, { fill: '#FFFFFF', rx: u * 6 }) + PA(t('Тримач'), `M${q(W / 2 - u * 10)} ${q(H * 0.4)}Q${q(W / 2 - u * 10)} ${q(H * 0.4 + u * 14)} ${q(W / 2)} ${q(H * 0.4 + u * 14)}Q${q(W / 2 + u * 10)} ${q(H * 0.4 + u * 14)} ${q(W / 2 + u * 10)} ${q(H * 0.4)}`, { stroke: '#FFFFFF', sw: u * 1.6 }) + LN(t('Стійка'), W / 2, H * 0.4 + u * 14, W / 2, H * 0.4 + u * 21, { stroke: '#FFFFFF', sw: u * 1.6 }); s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.82, fit(c, c.txt.title, u * 10, W * 0.84, 1, true), { family: c.fh, anchor: 'middle', weight: 900, upper: true, fill: '#FFFFFF' }).svg + TT(c, t('Підзаголовок'), c.txt.sub, W / 2, H * 0.9, u * 3.4, { anchor: 'middle', fill: c.a2 === '#FFFFFF' ? c.a1 : c.a2, weight: 700 }).svg; return s; };
  I.album = c => { const { W, H, u } = c; let s = bg(c, c.a1) + CI(t('Коло'), W * 0.62, H * 0.42, u * 34, { fill: c.a2 }) + CI(t('Кільце'), W * 0.62, H * 0.42, u * 40, { stroke: c.ink, sw: u * 0.4 }); s += TT(c, t('Заголовок'), c.txt.title, c.pad, H * 0.82, fit(c, c.txt.title, u * 13, W - c.pad * 2, 2, true), { family: c.fh, weight: 900, upper: true, fill: onC(c.a1), maxW: W - c.pad * 2, lh: 0.95 }).svg + TT(c, t('Автор'), c.txt.sub, c.pad, H * 0.93, u * 3, { fill: onC(c.a1), weight: 600, ls: u * 0.3 }).svg; return s; };
  I.tiktok = c => { const { W, H, u } = c; let s = bg(c, grad(c, c.bg, c.sf)); s += RC(t('Плашка'), c.pad, H * 0.12, W - c.pad * 2, H * 0.2, { fill: c.a1, rx: u * 4 }) + TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.2, fit(c, c.txt.title, u * 8, W - c.pad * 3, 2), { family: c.fh, weight: 900, anchor: 'middle', fill: onC(c.a1), maxW: W - c.pad * 3, lh: 1.05 }).svg; s += TT(c, t('Емодзі'), c.txt.extra || '🔥', W / 2, H * 0.58, u * 34, { anchor: 'middle', family: 'Segoe UI Emoji' }).svg + TT(c, t('Підзаголовок'), c.txt.sub, W / 2, H * 0.8, u * 4.4, { anchor: 'middle', weight: 800, maxW: W - c.pad * 2 }).svg; return s; };
  I.highlights = c => { const { W, H, u } = c; let s = bg(c) + head(c, c.pad, H * 0.12, W - c.pad * 2, u * 8).svg; items(c.txt.body).slice(0, 6).forEach((it, i) => { const cx = W * (i % 2 ? 0.7 : 0.3), cy = H * (0.3 + Math.floor(i / 2) * 0.22); s += CI(t('Коло'), cx, cy, u * 13, { fill: i % 2 ? c.a2 : c.a1 }) + CI(t('Кільце'), cx, cy, u * 15, { stroke: c.ink, sw: u * 0.3, op: 0.4 }) + TT(c, t('Пункт'), it, cx, cy + u * 22, u * 3.4, { anchor: 'middle', weight: 700 }).svg + TT(c, t('Іконка'), ['★', '♥', '✈', '☕', '✿', '♪'][i], cx, cy + u * 4, u * 11, { anchor: 'middle', fill: onC(i % 2 ? c.a2 : c.a1) }).svg; }); return s; };
  I.coupon = c => { const { W, H, u } = c; let s = bg(c, c.a1) + RC(t('Рамка'), u * 4, u * 4, W - u * 8, H - u * 8, { stroke: onC(c.a1), sw: u * 0.5, dash: `${q(u * 2)} ${q(u * 1.4)}`, rx: u * 3 }); s += TT(c, t('Знижка'), c.txt.title, W * 0.3, H * 0.62, fit(c, c.txt.title, u * 34, W * 0.42, 1), { family: c.fh, weight: 900, anchor: 'middle', fill: onC(c.a1) }).svg; s += LN(t('Лінія'), W * 0.55, u * 10, W * 0.55, H - u * 10, { stroke: onC(c.a1), sw: u * 0.3, dash: `${q(u)} ${q(u)}` }); s += TT(c, t('Підпис'), c.txt.kicker, W * 0.6, H * 0.3, u * 5, { weight: 800, fill: onC(c.a1), upper: true }).svg + TT(c, t('Текст'), c.txt.sub, W * 0.6, H * 0.46, u * 4, { fill: onC(c.a1), maxW: W * 0.34 }).svg + RC(t('Код'), W * 0.6, H * 0.62, W * 0.3, u * 12, { fill: onC(c.a1), rx: u * 2 }) + TT(c, t('Код'), c.txt.extra, W * 0.75, H * 0.62 + u * 8, u * 5, { anchor: 'middle', weight: 900, fill: c.a1, ls: u * 0.6 }).svg; return s; };
  I.ticket = c => { const { W, H, u } = c, sx = W * 0.72; let s = bg(c, c.sf) + RC(t('Квиток'), u * 4, u * 6, W - u * 8, H - u * 12, { fill: c.a1, rx: u * 4 }) + CI(t('Виріз'), sx, u * 6, u * 5, { fill: c.sf }) + CI(t('Виріз'), sx, H - u * 6, u * 5, { fill: c.sf }) + LN(t('Перфорація'), sx, u * 13, sx, H - u * 13, { stroke: onC(c.a1), sw: u * 0.6, dash: `${q(u * 1.5)} ${q(u * 1.5)}`, op: 0.7 }); s += TT(c, t('Підпис'), c.txt.kicker, u * 12, H * 0.3, u * 6, { upper: true, weight: 800, fill: onC(c.a1), ls: u * 0.5 }).svg + TT(c, t('Заголовок'), c.txt.title, u * 12, H * 0.56, fit(c, c.txt.title, u * 18, sx - u * 22, 1), { family: c.fh, weight: 900, fill: onC(c.a1) }).svg + TT(c, t('Дата'), c.txt.sub, u * 12, H * 0.75, u * 5, { fill: onC(c.a1), weight: 600 }).svg; s += TT(c, t('Місце'), c.txt.extra, (sx + W - u * 4) / 2, H * 0.55, u * 7, { anchor: 'middle', weight: 900, fill: onC(c.a1) }).svg; return s; };
  I.tag = c => { const { W, H, u } = c; let s = bg(c, c.sf) + PG(t('Фігура'), [[W * 0.5, u * 6], [W - u * 8, H * 0.18], [W - u * 8, H - u * 6], [u * 8, H - u * 6], [u * 8, H * 0.18]], { fill: c.a1 }) + CI(t('Отвір'), W / 2, H * 0.14, u * 4, { fill: c.sf, stroke: onC(c.a1), sw: u * 0.6 }); s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.48, fit(c, c.txt.title, u * 16, W * 0.7, 2), { family: c.fh, weight: 700, italic: true, anchor: 'middle', fill: onC(c.a1), maxW: W * 0.7 }).svg + TT(c, t('Підпис'), c.txt.sub, W / 2, H * 0.68, u * 5, { anchor: 'middle', fill: onC(c.a1) }).svg + TT(c, t('Серце'), '♥', W / 2, H * 0.85, u * 10, { anchor: 'middle', fill: c.a2 === c.a1 ? onC(c.a1) : c.a2 }).svg; return s; };
  I.bookmark = c => { const { W, H, u } = c; let s = bg(c, c.a1) + PG(t('Фігура'), [[0, H * 0.94], [W / 2, H], [W, H * 0.94], [W, H], [0, H]], { fill: c.sf }); for (let i = 0; i < 4; i++) s += CI(t('Коло'), W / 2, H * (0.12 + i * 0.07), u * (4 - i * 0.7) * 3, { fill: c.a2, op: 0.5 + i * 0.1 }); s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.55, fit(c, c.txt.title, u * 14, W * 0.8, 4), { family: c.fh, weight: 800, anchor: 'middle', fill: onC(c.a1), maxW: W * 0.8, lh: 1.1 }).svg + TT(c, t('Підпис'), c.txt.sub, W / 2, H * 0.82, u * 5, { anchor: 'middle', fill: onC(c.a1), italic: true, maxW: W * 0.8 }).svg; return s; };
  I.xmas = c => { const { W, H, u } = c; let s = bg(c, c.ink === '#FFFFFF' ? c.bg : '#0E3B2E'); for (let i = 0; i < 60; i++) s += CI(t('Сніжинка'), (i * 97 % 100) / 100 * W, (i * 53 % 100) / 100 * H * 0.9, u * (0.4 + (i % 3) * 0.3), { fill: '#FFFFFF', op: 0.7 }); const tx = W / 2, ty = H * 0.15; for (let k = 0; k < 3; k++) s += PG(t('Фігура'), [[tx, ty + k * u * 12], [tx + u * (14 + k * 6), ty + u * (22 + k * 12)], [tx - u * (14 + k * 6), ty + u * (22 + k * 12)]], { fill: mixC('#1E7A46', c.a1, 0.2) }); s += RC(t('Стовбур'), tx - u * 3, ty + u * 46, u * 6, u * 7, { fill: '#6B3E1E' }) + TT(c, t('Зірка'), '★', tx, ty + u * 2, u * 10, { anchor: 'middle', fill: '#FFD54A' }).svg; for (let i = 0; i < 7; i++) s += CI(t('Іграшка'), tx + (i - 3) * u * 4.5, ty + u * (20 + (i % 3) * 10), u * 1.6, { fill: ['#E53935', '#FFD54A', '#29B6F6'][i % 3] }); s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.78, fit(c, c.txt.title, u * 10, W * 0.86, 2), { family: c.fh, weight: 700, anchor: 'middle', fill: '#FFFFFF', maxW: W * 0.86 }).svg + TT(c, t('Підпис'), c.txt.sub, W / 2, H * 0.9, u * 4, { anchor: 'middle', fill: '#FFD54A' }).svg; return s; };
  I.valentine = c => { const { W, H, u } = c; let s = bg(c, mixC('#FF5C8A', c.bg, 0.15)); for (let i = 0; i < 14; i++) s += PA(t('Серце'), heart((i * 71 % 100) / 100 * W, (i * 37 % 100) / 100 * H, u * (2 + i % 4)), { fill: '#FFFFFF', op: 0.35 }); s += PA(t('Серце'), heart(W / 2, H * 0.42, u * 22), { fill: '#E91E63' }); s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.44, fit(c, c.txt.title, u * 9, u * 30, 2), { family: c.fh, weight: 800, anchor: 'middle', fill: '#FFFFFF', maxW: u * 30 }).svg + TT(c, t('Підпис'), c.txt.sub, W / 2, H * 0.82, u * 5, { anchor: 'middle', fill: '#FFFFFF', italic: true, family: c.fh }).svg; return s; };
  I.halloween = c => { const { W, H, u } = c; let s = bg(c, '#160B24') + CI(t('Місяць'), W * 0.7, H * 0.25, u * 18, { fill: '#FFD27A' }); for (let i = 0; i < 5; i++) { const x = W * (0.15 + i * 0.17), y = H * (0.12 + (i % 2) * 0.1), b = u * 3; s += PA(t('Кажан'), `M${q(x - b * 2)} ${q(y)}Q${q(x - b)} ${q(y - b)} ${q(x)} ${q(y + b * 0.4)}Q${q(x + b)} ${q(y - b)} ${q(x + b * 2)} ${q(y)}Q${q(x + b)} ${q(y + b * 0.2)} ${q(x)} ${q(y + b)}Q${q(x - b)} ${q(y + b * 0.2)} ${q(x - b * 2)} ${q(y)}Z`, { fill: '#000000' }); } s += E(t('Гарбуз'), W / 2, H * 0.62, u * 16, u * 12, { fill: '#F57C00' }) + RC(t('Хвостик'), W / 2 - u, H * 0.62 - u * 15, u * 2, u * 4, { fill: '#3E7B27' }) + PG(t('Фігура'), [[W / 2 - u * 7, H * 0.6], [W / 2 - u * 3, H * 0.6], [W / 2 - u * 5, H * 0.56]], { fill: '#160B24' }) + PG(t('Фігура'), [[W / 2 + u * 3, H * 0.6], [W / 2 + u * 7, H * 0.6], [W / 2 + u * 5, H * 0.56]], { fill: '#160B24' }); s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.88, fit(c, c.txt.title, u * 10, W * 0.86, 1, true), { family: c.fh, weight: 900, upper: true, anchor: 'middle', fill: '#FF9800' }).svg + TT(c, t('Підпис'), c.txt.sub, W / 2, H * 0.95, u * 3, { anchor: 'middle', fill: '#FFFFFF' }).svg; return s; };
  I.easter = c => { const { W, H, u } = c; let s = bg(c, mixC(c.bg, '#FFF6E5', 0.5)); [[0.3, '#FFB3C7'], [0.5, '#B3E5FC'], [0.7, '#C5E1A5']].forEach(([x, col], i) => { s += E(t('Писанка'), W * x, H * 0.45, u * 11, u * 15, { fill: col }) + RC(t('Візерунок'), W * x - u * 11, H * 0.45 - u * 2, u * 22, u * 3, { fill: '#FFFFFF', op: 0.8 }) + CI(t('Крапка'), W * x, H * 0.45 + u * 7, u * 1.6, { fill: '#FFFFFF' }); void i; }); s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.78, fit(c, c.txt.title, u * 10, W * 0.86, 2), { family: c.fh, weight: 800, anchor: 'middle', fill: c.a1 }).svg + TT(c, t('Підпис'), c.txt.sub, W / 2, H * 0.88, u * 4, { anchor: 'middle' }).svg; return s; };
  I.newyear = c => { const { W, H, u } = c; let s = bg(c, '#0B1026'); [[0.25, 0.25, '#FFD54A'], [0.7, 0.2, '#FF4D8D'], [0.5, 0.42, '#4DD0E1']].forEach(([x, y, col]) => { for (let k = 0; k < 16; k++) { const a = k / 16 * Math.PI * 2, r1 = u * 4, r2 = u * 13; s += LN(t('Феєрверк'), W * x + Math.cos(a) * r1, H * y + Math.sin(a) * r1, W * x + Math.cos(a) * r2, H * y + Math.sin(a) * r2, { stroke: col, sw: u * 0.6 }); } }); s += TT(c, t('Рік'), c.txt.kicker, W / 2, H * 0.72, u * 26, { family: c.fh, anchor: 'middle', weight: 900, fill: '#FFD54A' }).svg + TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.84, u * 6, { anchor: 'middle', fill: '#FFFFFF', weight: 700, family: c.fh }).svg + TT(c, t('Підпис'), c.txt.sub, W / 2, H * 0.92, u * 3.4, { anchor: 'middle', fill: '#C9D1FF' }).svg; return s; };
  I.baby = c => { const { W, H, u } = c; let s = bg(c, '#EAF6FF'); [[0.2, 0.2], [0.75, 0.15], [0.5, 0.88]].forEach(([x, y]) => { s += E(t('Хмара'), W * x, H * y, u * 12, u * 5, { fill: '#FFFFFF' }) + CI(t('Хмара'), W * x - u * 4, H * y - u * 3, u * 5, { fill: '#FFFFFF' }) + CI(t('Хмара'), W * x + u * 3, H * y - u * 4, u * 6, { fill: '#FFFFFF' }); }); for (let i = 0; i < 9; i++) s += TT(c, t('Зірка'), '✦', (i * 61 % 100) / 100 * W, (i * 29 % 70 + 20) / 100 * H, u * 3, { fill: '#FFD27A' }).svg; s += TT(c, t('Підпис'), c.txt.kicker, W / 2, H * 0.38, u * 4, { anchor: 'middle', fill: '#7FA7D9', weight: 700, upper: true, ls: u * 0.4 }).svg + head(c, W / 2, H * 0.52, W - c.pad * 2, u * 10, { anchor: 'middle', fill: '#5B7DB1' }).svg +TT(c, t('Дата'), c.txt.sub, W / 2, H * 0.68, u * 4, { anchor: 'middle', fill: '#5B7DB1' }).svg; return s; };
  I.realestate = c => { const { W, H, u } = c; let s = bg(c) + photo(c, 0, 0, W, H * 0.58); s += RC(t('Ціна'), c.pad, H * 0.52, u * 34, u * 10, { fill: c.a1, rx: u * 2 }) + TT(c, t('Ціна'), c.txt.kicker, c.pad + u * 17, H * 0.52 + u * 6.8, u * 5, { anchor: 'middle', weight: 900, fill: onC(c.a1) }).svg; s += head(c, c.pad, H * 0.72, W - c.pad * 2, u * 7).svg + TT(c, t('Адреса'), c.txt.sub, c.pad, H * 0.79, u * 3, { fill: mixC(c.ink, c.bg, 0.35) }).svg; items(c.txt.body).forEach((it, i) => { const x = c.pad + i * (W - c.pad * 2) / 3; s += RC(t('Іконка'), x, H * 0.85, u * 4, u * 4, { fill: c.a2, rx: u }) + TT(c, t('Пункт'), it, x + u * 6, H * 0.85 + u * 3.2, u * 3, { weight: 700 }).svg; }); return s; };
  I.chalk = c => { const { W, H, u } = c, ink = '#F4F1E8'; let s = bg(c, '#2B2E2B') + RC(t('Рамка'), u * 3, u * 3, W - u * 6, H - u * 6, { stroke: '#8B5A2B', sw: u * 2 }); s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.14, u * 10, { family: c.fh, anchor: 'middle', fill: ink, weight: 700 }).svg + TT(c, t('Підзаголовок'), c.txt.sub, W / 2, H * 0.2, u * 3, { anchor: 'middle', fill: c.a2, italic: true }).svg; items(c.txt.body).forEach((it, i) => { const [n, p] = it.split('—').map(x => x.trim()); const y = H * 0.3 + i * u * 10; s += TT(c, t('Страва'), n, c.pad + u * 4, y, u * 4, { fill: ink, family: c.fh }).svg + LN(t('Пунктир'), c.pad + u * 4 + n.length * u * 2.2, y - u, W - c.pad - u * 14, y - u, { stroke: ink, sw: u * 0.2, dash: `${q(u * 0.4)} ${q(u)}`, op: 0.6 }) + TT(c, t('Ціна'), p || '', W - c.pad - u * 4, y, u * 4, { anchor: 'end', fill: c.a2 === '#FFFFFF' ? '#FFD27A' : c.a2, weight: 700 }).svg; }); return s; };
  I.pricing = c => { const { W, H, u } = c; let s = bg(c) + TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.14, fit(c, c.txt.title, u * 7, W * 0.8, 1), { family: c.fh, anchor: 'middle', weight: 900 }).svg; const tiers = items(c.txt.body), cw = (W - c.pad * 2 - u * 6) / 3; tiers.forEach((it, i) => { const [n, p] = [it.replace(/\s*\d+\s*$/, ''), (it.match(/\d+\s*$/) || [''])[0]]; const x = c.pad + i * (cw + u * 3), hl = i === 1, y = H * (hl ? 0.24 : 0.28), h = H * (hl ? 0.66 : 0.58); s += RC(t('Картка'), x, y, cw, h, { fill: hl ? c.a1 : c.sf, rx: u * 3 }) + TT(c, t('Тариф'), n, x + cw / 2, y + u * 9, u * 3.6, { anchor: 'middle', weight: 800, fill: hl ? onC(c.a1) : c.ink }).svg + TT(c, t('Ціна'), p + ' ₴', x + cw / 2, y + u * 22, u * 8, { anchor: 'middle', weight: 900, family: c.fh, fill: hl ? onC(c.a1) : c.a1 }).svg; [0, 1, 2].forEach(k => { s += TT(c, t('Пункт'), '✓ ' + t(['Підтримка', 'Хмара', 'Аналітика'][k]), x + cw / 2, y + u * (32 + k * 6), u * 2.6, { anchor: 'middle', fill: hl ? onC(c.a1) : mixC(c.ink, c.sf, 0.3) }).svg; }); s += pill(c, c.txt.cta, x + cw / 2, y + h - u * 12, u * 2.6, { anchor: 'middle', fill: hl ? c.ink : c.a1 }).svg; }); return s; };
  I.schedule = c => { const { W, H, u } = c; let s = bg(c) + head(c, c.pad, c.pad + u * 8, W - c.pad * 2, u * 8).svg; items(c.txt.body).forEach((it, i) => { const [d, tm, w] = it.split('·').map(x => x.trim()); const y = H * 0.25 + i * u * 11; s += RC(t('Рядок'), c.pad, y, W - c.pad * 2, u * 9, { fill: i % 2 ? c.sf : mixC(c.a1, c.bg, 0.85), rx: u * 2 }) + TT(c, t('День'), d, c.pad + u * 3, y + u * 5.8, u * 3.4, { weight: 900, fill: c.a1 }).svg + TT(c, t('Час'), tm || '', c.pad + u * 18, y + u * 5.8, u * 3.2, { weight: 700 }).svg + TT(c, t('Пункт'), w || '', c.pad + u * 36, y + u * 5.8, u * 3.2, {}).svg; }); return s; };
  I.checklist = c => { const { W, H, u } = c; let s = bg(c, c.sf) + head(c, c.pad, c.pad + u * 9, W - c.pad * 2, u * 9).svg + TT(c, t('Підзаголовок'), c.txt.sub, c.pad, c.pad + u * 16, u * 3.2, { fill: mixC(c.ink, c.sf, 0.35) }).svg; items(c.txt.body).forEach((it, i) => { const y = H * 0.3 + i * u * 10; s += RC(t('Позначка'), c.pad, y - u * 4, u * 5, u * 5, { stroke: c.a1, sw: u * 0.5, rx: u, fill: i < 2 ? c.a1 : 'none' }) + (i < 2 ? TT(c, t('Галочка'), '✓', c.pad + u * 2.5, y, u * 4, { anchor: 'middle', fill: onC(c.a1), weight: 900 }).svg : '') + TT(c, t('Пункт'), it, c.pad + u * 9, y, u * 3.8, { weight: 600 }).svg + LN(t('Лінія'), c.pad + u * 9, y + u * 2.5, W - c.pad, y + u * 2.5, { stroke: c.ink, sw: u * 0.12, op: 0.2 }); }); return s; };
  I.worksheet = c => { const { W, H, u } = c; let s = bg(c, '#FFFFFF') + RC(t('Шапка'), 0, 0, W, u * 18, { fill: c.a1 }) + TT(c, t('Заголовок'), c.txt.title, c.pad, u * 12, u * 7, { family: c.fh, weight: 900, fill: onC(c.a1) }).svg; s += TT(c, t('Ім’я'), t("Ім’я") + ': ____________________   ' + t('Дата') + ': __________', c.pad, u * 27, u * 2.8, {}).svg; items(c.txt.body).forEach((it, i) => { const y = u * 40 + i * u * 22; s += CI(t('Номер'), c.pad + u * 3, y - u, u * 3, { fill: c.a2 }) + TT(c, t('Номер'), String(i + 1), c.pad + u * 3, y, u * 3, { anchor: 'middle', weight: 900, fill: onC(c.a2) }).svg + TT(c, t('Завдання'), it, c.pad + u * 9, y, u * 3.2, { weight: 700, maxW: W - c.pad * 2 - u * 9 }).svg; for (let k = 1; k <= 2; k++) s += LN(t('Рядок'), c.pad + u * 9, y + k * u * 7, W - c.pad, y + k * u * 7, { stroke: c.ink, sw: u * 0.15, op: 0.35 }); }); return s; };
  I.moodboard = c => { const { W, H, u } = c, g = u * 2; let s = bg(c, c.sf) + head(c, c.pad, c.pad + u * 6, W - c.pad * 2, u * 6).svg; s += photo(c, c.pad, H * 0.16, W * 0.5, H * 0.46, { rx: u * 2 }) + photo(c, c.pad + W * 0.5 + g, H * 0.16, W - c.pad * 2 - W * 0.5 - g, H * 0.22, { rx: u * 2 }) + photo(c, c.pad + W * 0.5 + g, H * 0.4, W - c.pad * 2 - W * 0.5 - g, H * 0.22, { rx: u * 2 }); c.st.pal.forEach((col, i) => { const x = c.pad + u * 6 + i * (W - c.pad * 2) / 5; s += CI(t('Колір'), x, H * 0.75, u * 6, { fill: col, stroke: c.ink, sw: u * 0.1 }) + TT(c, t('Код кольору'), col, x, H * 0.75 + u * 11, u * 2.4, { anchor: 'middle', fill: mixC(c.ink, c.sf, 0.3) }).svg; }); s += TT(c, t('Шрифти'), c.fh + ' · ' + c.fb, c.pad, H * 0.92, u * 3, { weight: 700 }).svg; return s; };
  I.versus = c => { const { W, H, u } = c; let s = RC(t('Ліва половина'), 0, 0, W / 2, H, { fill: c.a1 }) + RC(t('Права половина'), W / 2, 0, W / 2, H, { fill: c.a2 === c.a1 ? c.ink : c.a2 }); s += CI(t('Коло'), W / 2, H / 2, u * 10, { fill: c.bg }) + TT(c, t('VS'), 'VS', W / 2, H / 2 + u * 3, u * 8, { anchor: 'middle', weight: 900, family: c.fh }).svg; s += TT(c, t('Ліворуч'), c.txt.title, W / 4, H * 0.8, fit(c, c.txt.title, u * 9, W * 0.42, 1, true), { anchor: 'middle', family: c.fh, weight: 900, upper: true, fill: onC(c.a1) }).svg + TT(c, t('Праворуч'), c.txt.sub, W * 0.75, H * 0.8, fit(c, c.txt.sub, u * 9, W * 0.42, 1, true), { anchor: 'middle', family: c.fh, weight: 900, upper: true, fill: onC(c.a2 === c.a1 ? c.ink : c.a2) }).svg + TT(c, t('Підпис'), c.txt.kicker, W / 2, u * 10, u * 3.6, { anchor: 'middle', weight: 800, fill: '#FFFFFF', upper: true, ls: u * 0.4 }).svg; return s; };
  I.statsp = c => { const { W, H, u } = c; let s = bg(c, c.ink === '#FFFFFF' ? c.bg : '#111118') + TT(c, t('Підпис'), c.txt.kicker, c.pad, c.pad + u * 4, u * 3, { upper: true, weight: 800, fill: c.a1, ls: u * 0.4 }).svg + head(c, c.pad, c.pad + u * 15, W - c.pad * 2, u * 8, { fill: '#FFFFFF' }).svg; items(c.txt.body).forEach((it, i) => { const [v, ...l] = it.split(' '); const y = H * 0.42 + i * H * 0.17; s += TT(c, t('Число'), v, c.pad, y, u * 14, { family: c.fh, weight: 900, fill: i % 2 ? c.a2 : c.a1 }).svg + TT(c, t('Підпис'), l.join(' '), W * 0.55, y - u * 4, u * 3.4, { fill: '#FFFFFF', maxW: W * 0.4 }).svg; }); return s; };
  I.photoquote = c => { const { W, H, u } = c; let s = photo(c, 0, 0, W, H) + RC(t('Затемнення'), 0, 0, W, H, { fill: '#000000', fop: 0.45 }); s += TT(c, t('Лапки'), '“', W / 2, H * 0.36, u * 26, { anchor: 'middle', fill: '#FFFFFF', family: 'Georgia', op: 0.85 }).svg + TT(c, t('Цитата'), c.txt.title, W / 2, H * 0.48, fit(c, c.txt.title, u * 7, W * 0.8, 4), { anchor: 'middle', family: c.fh, weight: 700, italic: true, fill: '#FFFFFF', maxW: W * 0.8, lh: 1.2 }).svg + TT(c, t('Автор'), '— ' + c.txt.sub, W / 2, H * 0.84, u * 3.4, { anchor: 'middle', fill: '#FFFFFF' }).svg; return s; };
  I.label = c => { const { W, H, u } = c; let s = bg(c, c.sf) + CI(t('Етикетка'), W / 2, H / 2, u * 44, { fill: c.a1 }) + CI(t('Кільце'), W / 2, H / 2, u * 39, { stroke: onC(c.a1), sw: u * 0.4 }) + CI(t('Кільце'), W / 2, H / 2, u * 37, { stroke: onC(c.a1), sw: u * 0.2, dash: `${q(u)} ${q(u)}` }); s += TT(c, t('Підпис'), c.txt.kicker, W / 2, H * 0.32, u * 3.4, { anchor: 'middle', fill: onC(c.a1), upper: true, ls: u * 0.5 }).svg + TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.52, fit(c, c.txt.title, u * 11, u * 64, 2), { anchor: 'middle', family: c.fh, weight: 900, fill: onC(c.a1), maxW: u * 64 }).svg + TT(c, t('Опис'), c.txt.sub, W / 2, H * 0.66, u * 3.4, { anchor: 'middle', fill: onC(c.a1) }).svg + TT(c, t('Вага'), c.txt.extra, W / 2, H * 0.74, u * 3, { anchor: 'middle', weight: 700, fill: onC(c.a1) }).svg; return s; };
  I.vcard = c => { const { W, H, u } = c; let s = bg(c, c.sf) + RC(t('Смуга'), 0, 0, W, H * 0.4, { fill: c.a1 }) + CI(t('Місце для фото'), W / 2, H * 0.4, u * 18, { fill: mixC(c.a1, '#FFFFFF', 0.5), stroke: c.sf, sw: u * 2 }); s += TT(c, t('Ім’я'), c.txt.title, W / 2, H * 0.64, fit(c, c.txt.title, u * 9, W * 0.86, 1), { anchor: 'middle', family: c.fh, weight: 800 }).svg + TT(c, t('Посада'), c.txt.sub, W / 2, H * 0.73, u * 4, { anchor: 'middle', fill: c.a1, weight: 700 }).svg + TT(c, t('Контакти'), items(c.txt.extra).join('  ·  ') || c.txt.extra, W / 2, H * 0.82, u * 3, { anchor: 'middle', fill: mixC(c.ink, c.sf, 0.3), maxW: W * 0.86, lh: 1.5 }).svg; return s; };
  I.stream = c => { const { W, H, u } = c; let s = bg(c, grad(c, c.bg, c.a1, 1, 0)); for (let i = 0; i < 6; i++) s += PG(t('Фігура'), [[W * (0.5 + i * 0.09), H], [W * (0.58 + i * 0.09), H], [W * (0.68 + i * 0.09), 0], [W * (0.6 + i * 0.09), 0]], { fill: '#FFFFFF', op: 0.06 }); s += RC(t('Наживо'), c.pad, H * 0.2, u * 22, u * 10, { fill: '#E91E3C', rx: u * 2 }) + TT(c, t('Наживо'), '● LIVE', c.pad + u * 11, H * 0.2 + u * 7, u * 4.4, { anchor: 'middle', weight: 900, fill: '#FFFFFF' }).svg; s += TT(c, t('Заголовок'), c.txt.title, c.pad, H * 0.68, fit(c, c.txt.title, H * 0.25, W * 0.6, 1), { family: c.fh, weight: 900, fill: onC(c.bg) }).svg + TT(c, t('Підзаголовок'), c.txt.sub, c.pad, H * 0.86, H * 0.08, { fill: onC(c.bg), weight: 600 }).svg; return s; };
  I.newsletter = c => { const { W, H, u } = c; let s = bg(c, c.sf) + RC(t('Шапка'), 0, 0, W, H * 0.12, { fill: c.a1 }) + TT(c, t('Логотип'), c.txt.kicker, c.pad, H * 0.075, u * 7, { family: c.fh, weight: 900, fill: onC(c.a1) }).svg; s += head(c, c.pad, H * 0.2, W - c.pad * 2, u * 8).svg; [0, 1, 2].forEach(i => { const y = H * 0.27 + i * H * 0.2; s += photo(c, c.pad, y, W * 0.36, H * 0.16, { rx: u * 2 }) + TT(c, t('Підзаголовок'), items(c.txt.body)[i] || c.txt.sub, c.pad + W * 0.4, y + u * 6, u * 4.4, { weight: 800, maxW: W * 0.5 }).svg + TT(c, t('Текст'), c.txt.sub, c.pad + W * 0.4, y + u * 16, u * 3, { fill: mixC(c.ink, c.sf, 0.35), maxW: W * 0.48, lh: 1.4 }).svg; }); s += pill(c, c.txt.cta, W / 2, H * 0.89, u * 3.4, { anchor: 'middle' }).svg + TT(c, t('Підпис внизу'), c.txt.extra, W / 2, H * 0.97, u * 2.4, { anchor: 'middle', fill: mixC(c.ink, c.sf, 0.45) }).svg; return s; };
  I.landing = c => { const { W, H, u } = c; let s = bg(c) + TT(c, t('Логотип'), c.txt.kicker, c.pad, u * 6, u * 2.4, { family: c.fh, weight: 900 }).svg + TT(c, t('Меню'), t('Про нас     Послуги     Контакти'), W - c.pad, u * 6, u * 1.4, { anchor: 'end', fill: mixC(c.ink, c.bg, 0.3) }).svg; s += TT(c, t('Заголовок'), c.txt.title, c.pad, H * 0.14, fit(c, c.txt.title, u * 6, W * 0.5, 3), { family: c.fh, weight: 900, maxW: W * 0.5, lh: 1.05 }).svg + TT(c, t('Текст'), c.txt.sub, c.pad, H * 0.25, u * 1.6, { maxW: W * 0.45, fill: mixC(c.ink, c.bg, 0.3), lh: 1.5 }).svg + pill(c, c.txt.cta, c.pad, H * 0.29, u * 1.5).svg + photo(c, W * 0.56, H * 0.06, W * 0.38, H * 0.3, { rx: u * 2 }); items(c.txt.body).forEach((it, i) => { const x = c.pad + i * (W - c.pad * 2) / 3; s += RC(t('Картка'), x, H * 0.44, (W - c.pad * 2) / 3 - u * 2, H * 0.2, { fill: c.sf, rx: u * 1.5 }) + CI(t('Іконка'), x + u * 4, H * 0.44 + u * 5, u * 2, { fill: i % 2 ? c.a2 : c.a1 }) + TT(c, t('Пункт'), it, x + u * 2, H * 0.44 + u * 12, u * 1.6, { weight: 800 }).svg; }); s += RC(t('Заклик'), 0, H * 0.72, W, H * 0.16, { fill: c.a1 }) + TT(c, t('Заклик'), c.txt.cta, W / 2, H * 0.81, u * 3, { anchor: 'middle', weight: 900, family: c.fh, fill: onC(c.a1) }).svg + RC(t('Підвал'), 0, H * 0.92, W, H * 0.08, { fill: c.ink }) + TT(c, t('Підпис внизу'), c.txt.extra, W / 2, H * 0.965, u * 1.2, { anchor: 'middle', fill: onC(c.ink) }).svg; return s; };
  I.onboarding = (c, page = 0) => { const { W, H, u } = c, it = items(c.txt.body)[page] || c.txt.title; let s = bg(c) + CI(t('Ілюстрація'), W / 2, H * 0.32, u * 32, { fill: mixC([c.a1, c.a2, c.a1][page], c.bg, 0.6) }) + CI(t('Ілюстрація'), W / 2, H * 0.32, u * 18, { fill: [c.a1, c.a2, c.ink][page] }); s += TT(c, t('Заголовок'), it, W / 2, H * 0.6, fit(c, it, u * 8, W * 0.8, 2), { anchor: 'middle', family: c.fh, weight: 900, maxW: W * 0.8 }).svg + TT(c, t('Текст'), c.txt.sub, W / 2, H * 0.68, u * 3.6, { anchor: 'middle', maxW: W * 0.8, fill: mixC(c.ink, c.bg, 0.35) }).svg; [0, 1, 2].forEach(k => { s += RC(t('Індикатор'), W / 2 - u * 9 + k * u * 7, H * 0.78, k === page ? u * 8 : u * 3, u * 3, { fill: k === page ? c.a1 : mixC(c.ink, c.bg, 0.75), rx: u * 1.5 }); }); s += pill(c, page === 2 ? c.txt.cta : t('Далі'), W / 2, H * 0.86, u * 4, { anchor: 'middle' }).svg; return s; };
  I.onboarding.multi = true;
  I.timeline = c => { const { W, H, u } = c; let s = bg(c) + head(c, c.pad, c.pad + u * 8, W - c.pad * 2, u * 7).svg + LN(t('Лінія часу'), W * 0.3, H * 0.18, W * 0.3, H * 0.94, { stroke: c.a1, sw: u * 0.6 }); items(c.txt.body).forEach((it, i) => { const [yr, ...rest] = it.split(' '); const y = H * 0.24 + i * H * 0.14; s += CI(t('Точка'), W * 0.3, y, u * 2.4, { fill: i % 2 ? c.a2 : c.a1 }) + TT(c, t('Рік'), yr, W * 0.24, y + u * 1.4, u * 4, { anchor: 'end', weight: 900, family: c.fh, fill: c.a1 }).svg + TT(c, t('Подія'), rest.join(' '), W * 0.36, y + u * 1.4, u * 3.4, { weight: 600, maxW: W * 0.58 }).svg; }); return s; };
  I.orgchart = c => { const { W, H, u } = c, bw = W * 0.22, bh = H * 0.12; const box = (x, y, n, r, col) => RC(t('Блок'), x - bw / 2, y, bw, bh, { fill: col, rx: u * 1.5 }) + TT(c, t('Ім’я'), n, x, y + bh * 0.45, u * 2.4, { anchor: 'middle', weight: 800, fill: onC(col) }).svg + TT(c, t('Посада'), r, x, y + bh * 0.75, u * 1.8, { anchor: 'middle', fill: onC(col) }).svg; let s = bg(c) + head(c, c.pad, c.pad + u * 4, W - c.pad * 2, u * 5).svg; const L2 = items(c.txt.body); s += LN(t('Зв’язок'), W / 2, H * 0.32, W / 2, H * 0.42, { stroke: c.ink, sw: u * 0.3 }) + LN(t('Зв’язок'), W * 0.2, H * 0.42, W * 0.8, H * 0.42, { stroke: c.ink, sw: u * 0.3 }); s += box(W / 2, H * 0.2, c.txt.sub, t('Директор'), c.a1); L2.slice(0, 3).forEach((n, i) => { const x = W * (0.2 + i * 0.3); s += LN(t('Зв’язок'), x, H * 0.42, x, H * 0.5, { stroke: c.ink, sw: u * 0.3 }) + box(x, H * 0.5, n, t('Відділ'), i === 1 ? c.a2 : c.sf === c.bg ? c.a1 : c.sf); }); return s; };
  I.roadmap = c => { const { W, H, u } = c; let s = bg(c) + head(c, c.pad, c.pad + u * 8, W * 0.7, u * 7).svg + LN(t('Шлях'), c.pad, H * 0.55, W - c.pad, H * 0.55, { stroke: c.ink, sw: u * 0.5, op: 0.3 }); items(c.txt.body).forEach((it, i, a) => { const x = c.pad + (W - c.pad * 2) * (i + 0.5) / a.length, up = i % 2 === 0; s += CI(t('Віха'), x, H * 0.55, u * 3, { fill: i % 2 ? c.a2 : c.a1 }) + TT(c, t('Етап'), 'Q' + (i + 1), x, H * 0.55 + u * 1.3, u * 2.4, { anchor: 'middle', weight: 900, fill: onC(i % 2 ? c.a2 : c.a1) }).svg + LN(t('Зв’язок'), x, H * 0.55 + (up ? -u * 3 : u * 3), x, H * (up ? 0.4 : 0.7), { stroke: c.ink, sw: u * 0.2, op: 0.4 }) + TT(c, t('Пункт'), it, x, H * (up ? 0.37 : 0.76), u * 2.6, { anchor: 'middle', weight: 700, maxW: (W - c.pad * 2) / a.length }).svg; }); return s; };
  I.agenda = c => { const { W, H, u } = c; let s = bg(c) + RC(t('Смуга'), 0, 0, W * 0.38, H, { fill: c.a1 }) + TT(c, t('Підпис'), c.txt.kicker, c.pad, H * 0.3, u * 3, { upper: true, weight: 800, fill: onC(c.a1), ls: u * 0.4 }).svg + TT(c, t('Заголовок'), c.txt.title, c.pad, H * 0.45, fit(c, c.txt.title, u * 10, W * 0.3, 2), { family: c.fh, weight: 900, fill: onC(c.a1), maxW: W * 0.3 }).svg; s += listRows(c, W * 0.45, H * 0.25, W * 0.5, u * 4, items(c.txt.body), { num: true, gap: 3 }); return s; };
  I.award = c => { const { W, H, u } = c; let s = bg(c, c.sf) + PG(t('Фігура'), [[W / 2 - u * 14, H * 0.38], [W / 2 - u * 20, H * 0.6], [W / 2 - u * 12, H * 0.56], [W / 2 - u * 8, H * 0.64], [W / 2 - u * 4, H * 0.42]], { fill: c.a2 }) + PG(t('Фігура'), [[W / 2 + u * 14, H * 0.38], [W / 2 + u * 20, H * 0.6], [W / 2 + u * 12, H * 0.56], [W / 2 + u * 8, H * 0.64], [W / 2 + u * 4, H * 0.42]], { fill: c.a2 }); const pts = []; for (let i = 0; i < 32; i++) { const a = i / 32 * Math.PI * 2, r = i % 2 ? u * 16 : u * 18; pts.push([W / 2 + Math.cos(a) * r, H * 0.3 + Math.sin(a) * r]); } s += PG(t('Фігура'), pts, { fill: c.a1 }) + CI(t('Медаль'), W / 2, H * 0.3, u * 13, { stroke: onC(c.a1), sw: u * 0.5 }) + TT(c, t('Номер'), c.txt.kicker, W / 2, H * 0.3 + u * 4, u * 11, { anchor: 'middle', weight: 900, family: c.fh, fill: onC(c.a1) }).svg; s += TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.76, fit(c, c.txt.title, u * 8, W * 0.8, 2), { anchor: 'middle', family: c.fh, weight: 800, maxW: W * 0.8 }).svg + TT(c, t('Підпис'), c.txt.sub, W / 2, H * 0.86, u * 3.4, { anchor: 'middle', fill: mixC(c.ink, c.sf, 0.35) }).svg; return s; };
  I.concert = c => { const { W, H, u } = c; let s = bg(c, c.ink === '#FFFFFF' ? c.bg : '#0E0E14') + photo(c, 0, H * 0.35, W, H * 0.45) + RC(t('Затемнення'), 0, H * 0.35, W, H * 0.45, { fill: c.a1, fop: 0.35 }); s += TT(c, t('Дата'), c.txt.kicker, c.pad, H * 0.24, u * 22, { family: c.fh, weight: 900, fill: c.a1 }).svg + TT(c, t('Заголовок'), c.txt.title, c.pad, H * 0.88, fit(c, c.txt.title, u * 14, W - c.pad * 2, 1, true), { family: c.fh, weight: 900, upper: true, fill: '#FFFFFF' }).svg + TT(c, t('Місце'), c.txt.sub, c.pad, H * 0.95, u * 3.2, { fill: '#FFFFFF', weight: 600 }).svg; return s; };
  I.lost = c => { const { W, H, u } = c; let s = bg(c, '#FFFFFF') + RC(t('Шапка'), 0, 0, W, H * 0.14, { fill: '#E53935' }) + TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.1, fit(c, c.txt.title, u * 11, W * 0.86, 1, true), { anchor: 'middle', family: c.fh, weight: 900, upper: true, fill: '#FFFFFF' }).svg + photo(c, c.pad, H * 0.18, W - c.pad * 2, H * 0.4, { rx: u * 2 }); s += TT(c, t('Опис'), c.txt.sub, W / 2, H * 0.66, u * 4.4, { anchor: 'middle', weight: 800, maxW: W * 0.86 }).svg + TT(c, t('Текст'), c.txt.body, W / 2, H * 0.73, u * 3, { anchor: 'middle', maxW: W * 0.8, fill: '#444444', lh: 1.4 }).svg + RC(t('Винагорода'), c.pad, H * 0.82, W - c.pad * 2, u * 10, { fill: '#FFEB3B', rx: u * 2 }) + TT(c, t('Винагорода'), c.txt.kicker, W / 2, H * 0.82 + u * 6.6, u * 4, { anchor: 'middle', weight: 900, fill: '#111111' }).svg + TT(c, t('Контакти'), c.txt.extra, W / 2, H * 0.95, u * 4, { anchor: 'middle', weight: 800 }).svg; return s; };
  I.sport = c => { const { W, H, u } = c; let s = bg(c, c.ink === '#FFFFFF' ? c.bg : '#101318'); for (let i = 0; i < 5; i++) s += PG(t('Фігура'), [[W * (-0.2 + i * 0.25), H], [W * (-0.1 + i * 0.25), H], [W * (0.4 + i * 0.25), 0], [W * (0.3 + i * 0.25), 0]], { fill: i % 2 ? c.a1 : c.a2, op: 0.5 }); s += TT(c, t('Підпис'), c.txt.kicker, W / 2, H * 0.2, u * 4, { anchor: 'middle', weight: 800, fill: '#FFFFFF', upper: true, ls: u * 0.6 }).svg + TT(c, t('Рахунок'), c.txt.title, W / 2, H * 0.55, fit(c, c.txt.title, u * 26, W * 0.9, 1), { anchor: 'middle', family: c.fh, weight: 900, fill: '#FFFFFF' }).svg + TT(c, t('Команди'), c.txt.sub, W / 2, H * 0.7, u * 5, { anchor: 'middle', weight: 800, fill: '#FFFFFF', upper: true }).svg; return s; };
  I.workout = c => { const { W, H, u } = c; let s = bg(c, c.ink === '#FFFFFF' ? c.bg : '#121212') + TT(c, t('Підпис'), c.txt.kicker, c.pad, c.pad + u * 5, u * 3.6, { upper: true, weight: 800, fill: c.a1, ls: u * 0.5 }).svg + head(c, c.pad, c.pad + u * 20, W - c.pad * 2, u * 12, { upper: true, fill: '#FFFFFF' }).svg; items(c.txt.body).forEach((it, i) => { const [n, r] = it.split('—').map(x => x.trim()); const y = H * 0.36 + i * u * 16; s += RC(t('Рядок'), c.pad, y, W - c.pad * 2, u * 12, { fill: '#FFFFFF', fop: 0.08, rx: u * 3 }) + TT(c, t('Вправа'), n, c.pad + u * 4, y + u * 7.6, u * 4.4, { weight: 800, fill: '#FFFFFF' }).svg + TT(c, t('Повтори'), r || '', W - c.pad - u * 4, y + u * 7.6, u * 4.4, { anchor: 'end', weight: 900, fill: c.a1 }).svg; }); return s; };
  I.recipecard = c => { const { W, H, u } = c; let s = bg(c, c.sf) + photo(c, 0, 0, W, H * 0.32) + TT(c, t('Заголовок'), c.txt.title, c.pad, H * 0.4, fit(c, c.txt.title, u * 8, W - c.pad * 2, 1), { family: c.fh, weight: 800 }).svg + TT(c, t('Час'), c.txt.kicker, c.pad, H * 0.45, u * 3, { fill: c.a1, weight: 700 }).svg; s += TT(c, t('Підзаголовок'), t('Інгредієнти'), c.pad, H * 0.53, u * 3.6, { weight: 800 }).svg + listRows(c, c.pad, H * 0.58, W * 0.42, u * 2.8, items(c.txt.body), {}); s += TT(c, t('Підзаголовок'), t('Приготування'), W * 0.52, H * 0.53, u * 3.6, { weight: 800 }).svg + listRows(c, W * 0.52, H * 0.58, W * 0.42, u * 2.8, items(c.txt.extra), { num: true, gap: 2.6 }); return s; };
  I.listicle = c => { const { W, H, u } = c; let s = bg(c) + photo(c, 0, H * 0.5, W, H * 0.5) + TT(c, t('Число'), c.txt.kicker, c.pad, H * 0.2, u * 26, { family: c.fh, weight: 900, fill: c.a1 }).svg + TT(c, t('Заголовок'), c.txt.title, c.pad, H * 0.3, fit(c, c.txt.title, u * 8, W - c.pad * 2, 2), { family: c.fh, weight: 900, maxW: W - c.pad * 2 }).svg + TT(c, t('Підзаголовок'), c.txt.sub, c.pad, H * 0.44, u * 3.4, { fill: mixC(c.ink, c.bg, 0.3) }).svg + RC(t('Плашка'), c.pad, H * 0.88, W - c.pad * 2, u * 9, { fill: c.bg, rx: u * 4.5 }) + TT(c, t('Сайт'), c.txt.extra, W / 2, H * 0.88 + u * 6, u * 3.2, { anchor: 'middle', weight: 800 }).svg; return s; };
  I.opening = c => { const { W, H, u } = c; let s = bg(c, c.sf) + RC(t('Стрічка'), 0, H * 0.46, W, u * 9, { fill: '#E53935' }) + CI(t('Бант'), W / 2 - u * 7, H * 0.46 + u * 4.5, u * 7, { fill: '#C62828' }) + CI(t('Бант'), W / 2 + u * 7, H * 0.46 + u * 4.5, u * 7, { fill: '#C62828' }) + CI(t('Бант'), W / 2, H * 0.46 + u * 4.5, u * 3.5, { fill: '#B71C1C' }); s += TT(c, t('Підпис'), c.txt.kicker, W / 2, H * 0.2, u * 3.6, { anchor: 'middle', upper: true, weight: 800, fill: c.a1, ls: u * 0.5 }).svg + TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.36, fit(c, c.txt.title, u * 11, W * 0.86, 2), { anchor: 'middle', family: c.fh, weight: 900, maxW: W * 0.86 }).svg + TT(c, t('Дата'), c.txt.sub, W / 2, H * 0.7, u * 4.4, { anchor: 'middle', weight: 700 }).svg + TT(c, t('Адреса'), c.txt.extra, W / 2, H * 0.78, u * 3, { anchor: 'middle', fill: mixC(c.ink, c.sf, 0.35) }).svg; return s; };
  I.closed = c => { const { W, H, u } = c; let s = bg(c) + LN(t('Мотузка'), W / 2, 0, W * 0.3, H * 0.3, { stroke: c.ink, sw: u * 0.5 }) + LN(t('Мотузка'), W / 2, 0, W * 0.7, H * 0.3, { stroke: c.ink, sw: u * 0.5 }) + CI(t('Цвях'), W / 2, u * 3, u * 2, { fill: c.ink }); s += RC(t('Табличка'), W * 0.14, H * 0.3, W * 0.72, H * 0.44, { fill: c.a1, rx: u * 3 }) + RC(t('Рамка'), W * 0.17, H * 0.33, W * 0.66, H * 0.38, { stroke: onC(c.a1), sw: u * 0.4, rx: u * 2 }) + TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.5, fit(c, c.txt.title, u * 11, W * 0.6, 2, true), { anchor: 'middle', family: c.fh, weight: 900, upper: true, fill: onC(c.a1), maxW: W * 0.6 }).svg + TT(c, t('Дата'), c.txt.sub, W / 2, H * 0.64, u * 3.6, { anchor: 'middle', fill: onC(c.a1), weight: 700 }).svg + TT(c, t('Підпис'), c.txt.body, W / 2, H * 0.84, u * 3.4, { anchor: 'middle', maxW: W * 0.8 }).svg; return s; };
  I.quotecard = c => { const { W, H, u } = c; let s = bg(c, c.sf) + LN(t('Лінія'), W / 2 - u * 10, H * 0.25, W / 2 + u * 10, H * 0.25, { stroke: c.a1, sw: u * 0.6 }) + TT(c, t('Цитата'), c.txt.title, W / 2, H * 0.42, fit(c, c.txt.title, u * 7, W * 0.76, 5), { anchor: 'middle', family: c.fh, weight: 500, maxW: W * 0.76, lh: 1.3 }).svg + LN(t('Лінія'), W / 2 - u * 10, H * 0.75, W / 2 + u * 10, H * 0.75, { stroke: c.a1, sw: u * 0.6 }) + TT(c, t('Автор'), c.txt.sub, W / 2, H * 0.82, u * 3, { anchor: 'middle', upper: true, ls: u * 0.5, fill: mixC(c.ink, c.sf, 0.35) }).svg; return s; };
  I.event = c => { const { W, H, u } = c; let s = bg(c, grad(c, c.a1, c.ink === '#FFFFFF' ? c.bg : '#111118', 0, 1)); s += RC(t('Дата'), c.pad, c.pad, u * 18, u * 20, { fill: '#FFFFFF', rx: u * 2 }) + TT(c, t('Дата'), c.txt.kicker.split(' ')[0] || c.txt.kicker, c.pad + u * 9, c.pad + u * 11, u * 9, { anchor: 'middle', weight: 900, fill: c.a1, family: c.fh }).svg + TT(c, t('Місяць'), c.txt.kicker.split(' ').slice(1).join(' '), c.pad + u * 9, c.pad + u * 17, u * 3, { anchor: 'middle', weight: 700, fill: '#111111', upper: true }).svg; s += head(c, c.pad, H * 0.55, W - c.pad * 2, u * 11, { fill: '#FFFFFF', upper: true, lines: 3 }).svg + TT(c, t('Місце'), c.txt.sub, c.pad, H * 0.86, u * 3.6, { fill: '#FFFFFF', weight: 600 }).svg; return s + pill(c, c.txt.cta, c.pad, H * 0.9, u * 2.8, { fill: '#FFFFFF' }).svg; };
  Object.entries(I).forEach(([k, f]) => { L['i-' + k] = f; });
  // [id, name, group, w, h, layout, texts {kicker, title, sub, body, cta, extra}, pages]
  const IX = (kicker, title, sub, body, cta, extra) => ({ kicker, title, sub, body, cta, extra });
  TP.IDEAS = [
    ['hiring', 'Ми наймаємо', 'Соцмережі', 1080, 1350, 'hiring', IX('Кар’єра', 'Ми наймаємо', 'Дизайнер(-ка) інтерфейсів', 'Гібридний формат роботи|Зарплата від 60 000 грн|Навчання за рахунок компанії', 'Надіслати резюме', '')],
    ['giveaway', 'Розіграш', 'Соцмережі', 1080, 1080, 'giveaway', IX('', 'Розіграш', '', 'Підпишіться|Поставте ♥|Позначте друга', '', '@vibsma.studio')],
    ['testimonial', 'Відгук клієнта', 'Соцмережі', 1080, 1080, 'testimonial', IX('', 'Ірина Мельник', 'Власниця кав’ярні', 'Команда зробила наш бренд впізнаваним за місяць. Клієнти помічають нову упаковку й повертаються знову!', '', '')],
    ['collage4', 'Фотоколаж 4 фото', 'Соцмережі', 1080, 1080, 'collage4', IX('', 'Наше літо', '', '', '', '')],
    ['collage3', 'Фотоколаж для сторіз', 'Соцмережі', 1080, 1920, 'collage3', IX('', 'Вихідні в горах', 'Карпати · 2026', '', '', '')],
    ['carousel', 'Карусель Instagram', 'Соцмережі', 1080, 1350, 'carousel', IX('Гайд', '3 поради, як зробити дизайн кращим', 'Збережіть, щоб не загубити', 'Менше кольорів — більше стилю|Великий заголовок притягує погляд', 'Гортайте', ''), 3],
    ['tiktok', 'Обкладинка TikTok', 'Соцмережі', 1080, 1920, 'tiktok', IX('', 'Цього ніхто не розповідає', 'Дивіться до кінця!', '', '', '🔥')],
    ['highlights', 'Обкладинки Highlights', 'Соцмережі', 1080, 1920, 'highlights', IX('', 'Актуальне', '', 'Відгуки|Каталог|Доставка|Кава|Новинки|Музика', '', '')],
    ['versus', 'Порівняння «VS»', 'Соцмережі', 1080, 1080, 'versus', IX('Що оберете?', 'Кава', 'Чай', '', '', '')],
    ['statsp', 'Пост із цифрами', 'Соцмережі', 1080, 1350, 'statsp', IX('Підсумки року', 'Ми зростаємо разом із вами', '', '12 000 нових клієнтів|98% задоволених відгуків|35 міст доставки', '', '')],
    ['photoquote', 'Цитата на фото', 'Соцмережі', 1080, 1080, 'photoquote', IX('', 'Творчість — це інтелект, який розважається', 'Альберт Ейнштейн', '', '', '')],
    ['listicle', 'Пін-список', 'Соцмережі', 1000, 1500, 'listicle', IX('10', 'ідей для затишної спальні', 'Прості кроки без ремонту', '', '', 'vibsma.com')],
    ['webinar', 'Анонс вебінару', 'Бізнес', 1200, 1200, 'webinar', IX('20 жовтня · 19:00', 'Як запустити бренд з нуля', 'Спікерка: Олена Коваленко', '', 'Зареєструватися', '')],
    ['realestate', 'Продаж нерухомості', 'Бізнес', 1080, 1350, 'realestate', IX('2 400 000 ₴', 'Затишний будинок біля лісу', 'Київська обл., с. Лісове', '3 спальні|120 м²|Гараж', '', '')],
    ['pricing', 'Прайс-лист', 'Бізнес', 1920, 1080, 'pricing', IX('', 'Оберіть свій тариф', '', 'Базовий 199|Стандарт 399|Преміум 799', 'Обрати', '')],
    ['newsletter', 'Email-розсилка', 'Бізнес', 600, 1600, 'newsletter', IX('VIBSma', 'Новини жовтня', 'Короткий опис новини для читачів розсилки.', 'Новий курс дизайну|Знижки для студентів|Історія нашої команди', 'Читати більше', 'Ви отримали лист, бо підписалися на новини')],
    ['landing', 'Лендинг', 'Бізнес', 1440, 2400, 'landing', IX('VIBSma', 'Дизайн, що продає', 'Створюйте макети, відео й музику в одному браузерному редакторі.', 'Швидко|Зручно|Безкоштовно', 'Почати безкоштовно', '© 2026 VIBSma')],
    ['onboarding', 'Онбординг застосунку', 'Бізнес', 390, 844, 'onboarding', IX('', 'Ласкаво просимо', 'Короткий опис можливості застосунку.', 'Плануйте день|Відстежуйте звички|Святкуйте успіхи', 'Почати', ''), 3],
    ['timeline', 'Історія компанії', 'Бізнес', 1080, 1350, 'timeline', IX('', 'Наша історія', '', '2016 Перша студія|2019 100 клієнтів|2022 Вихід за кордон|2026 Власний редактор', '', '')],
    ['orgchart', 'Структура команди', 'Бізнес', 1920, 1080, 'orgchart', IX('', 'Наша команда', 'Олена Коваленко', 'Маркетинг|Дизайн|Розробка', '', '')],
    ['roadmap', 'Дорожня карта', 'Бізнес', 1920, 1080, 'roadmap', IX('', 'Дорожня карта 2026', '', 'Дослідження|Прототип|Запуск|Масштабування', '', '')],
    ['agenda', 'Порядок денний', 'Бізнес', 1920, 1080, 'agenda', IX('Зустріч команди', 'План на сьогодні', '', 'Підсумки місяця|Нові цілі|Розподіл задач|Питання й відповіді', '', '')],
    ['label', 'Етикетка продукту', 'Бізнес', 1000, 1000, 'label', IX('Ручна робота', 'Липовий мед', 'з Карпат', '', '', '250 г')],
    ['vcard', 'Вертикальна візитка', 'Бізнес', 600, 1050, 'vcard', IX('', 'Олена Коваленко', 'Арт-директорка', '', '', 'olena@vibsma.com|+380 67 123 45 67')],
    ['coupon', 'Купон на знижку', 'Друк', 1500, 700, 'coupon', IX('Знижка', '−20%', 'на перше замовлення', '', '', 'VIBSMA20')],
    ['ticket', 'Квиток на подію', 'Друк', 1600, 600, 'ticket', IX('Концерт', 'Літо звуку', '14 липня 2026 · 19:00', '', '', 'Ряд 5 · Місце 12')],
    ['tag', 'Подарунковий ярлик', 'Друк', 600, 1000, 'tag', IX('', 'Для тебе', 'з любов’ю', '', '', '')],
    ['bookmark', 'Закладка для книги', 'Друк', 600, 1800, 'bookmark', IX('', 'Читай більше — мрій сміливіше', 'Книжкова крамниця', '', '', '')],
    ['chalk', 'Меню на дошці', 'Друк', 1080, 1350, 'chalk', IX('', 'Кава', 'смажимо щодня', 'Еспресо — 45|Капучино — 65|Лате — 70|Флет-вайт — 75|Какао — 60', '', '')],
    ['recipecard', 'Картка рецепта', 'Друк', 1080, 1350, 'recipecard', IX('30 хв · 4 порції', 'Сирники з ягодами', '', 'Сир 500 г|Яйце 1 шт|Борошно 3 ст. л.|Цукор 2 ст. л.', '', 'Змішайте сир і яйце|Додайте борошно й цукор|Сформуйте сирники|Обсмажте до рум’янцю')],
    ['award', 'Нагородний диплом', 'Друк', 1080, 1350, 'award', IX('1', 'Переможець конкурсу дизайну', 'Київ · 2026', '', '', '')],
    ['concert', 'Афіша концерту', 'Друк', 1080, 1500, 'concert', IX('14.07', 'Гурт «Світанок»', 'Палац спорту · Київ', '', '', '')],
    ['lost', 'Оголошення «Загублено»', 'Друк', 1080, 1500, 'lost', IX('Винагорода гарантується', 'Загублено собаку', 'Рудий бігль на ім’я Бублик', 'Востаннє бачили біля парку Шевченка. Дуже дружній, відгукується на ім’я.', '', '+380 67 123 45 67')],
    ['opening', 'Ми відкрилися!', 'Друк', 1080, 1080, 'opening', IX('Велике відкриття', 'Ми відкрилися!', '1 листопада · 10:00', '', '', 'вул. Хрещатик, 1')],
    ['closed', 'Зачинено на свята', 'Друк', 1080, 1080, 'closed', IX('', 'Зачинено', '31 грудня — 2 січня', 'Чекаємо на вас 3 січня!', '', '')],
    ['xmas', 'Різдвяна листівка', 'Свята', 1500, 1050, 'xmas', IX('', 'З Різдвом Христовим!', 'Миру, тепла й затишку', '', '', '')],
    ['valentine', 'Валентинка', 'Свята', 1080, 1080, 'valentine', IX('', 'Ти мій усесвіт', 'з Днем закоханих', '', '', '')],
    ['halloween', 'Постер на Хелловін', 'Свята', 1080, 1350, 'halloween', IX('', 'Хелловін-вечірка', '31 жовтня · 20:00', '', '', '')],
    ['easter', 'Великодня листівка', 'Свята', 1500, 1050, 'easter', IX('', 'Христос воскрес!', 'Світлих свят вашій родині', '', '', '')],
    ['newyear', 'Новорічна листівка', 'Свята', 1080, 1350, 'newyear', IX('2027', 'З Новим роком!', 'Нехай здійсняться всі мрії', '', '', '')],
    ['baby', 'Запрошення на бебі-шауер', 'Свята', 1080, 1500, 'baby', IX('Запрошуємо на', 'Свято очікування малюка', '15 листопада · 15:00', '', '', '')],
    ['event', 'Афіша події', 'Свята', 1080, 1350, 'event', IX('25 травня', 'Вечірка на даху', 'Арт-простір «Горище»', '', 'Квитки', '')],
    ['schedule', 'Розклад занять', 'Освіта', 1080, 1350, 'schedule', IX('', 'Розклад тижня', '', 'Пн · 18:00 · Йога|Вт · 19:00 · Танці|Ср · 18:30 · Пілатес|Чт · 19:00 · Стретчинг|Пт · 18:00 · Медитація', '', '')],
    ['checklist', 'Чек-лист', 'Освіта', 1080, 1350, 'checklist', IX('', 'Список справ', 'Тиждень продуктивності', 'Скласти план|Прочитати 20 сторінок|Тренування|Подзвонити батькам|Відпочити без телефону', '', '')],
    ['worksheet', 'Робочий аркуш', 'Освіта', 595, 842, 'worksheet', IX('', 'Математика · 3 клас', '', 'Розв’яжіть приклад: 24 + 18 = ?|Порівняйте числа 56 і 65|Складіть задачу про яблука', '', '')],
    ['moodboard', 'Мудборд', 'Освіта', 1920, 1080, 'moodboard', IX('', 'Мудборд проєкту', '', '', '', '')],
    ['workout', 'Тренування дня', 'Освіта', 1080, 1920, 'workout', IX('Тренування дня', 'Повне тіло', '', 'Присідання — 3×15|Віджимання — 3×12|Планка — 60 с|Випади — 3×10|Скакалка — 2 хв', '', '')],
    ['sport', 'Спортивний рахунок', 'Освіта', 1080, 1080, 'sport', IX('Фінальний рахунок', '3 : 1', 'Динамо — Шахтар', '', '', '')],
    ['podcastc', 'Обкладинка подкасту', 'Соцмережі', 1080, 1080, 'podcastc', IX('', 'Говоримо про дизайн', 'Подкаст · Випуск 12', '', '', '')],
    ['album', 'Обкладинка альбому', 'Соцмережі', 1080, 1080, 'album', IX('', 'Нічне місто', 'Гурт «Світанок»', '', '', '')]
  ];
  // the ideas as hidden categories: TP.svg and TP.make work with them unchanged
  TP.IDEAS.forEach(([id, name, group, w, h, lay, texts, pages]) => TP.CATS.push(['idea-' + id, name, w, h, ['i-' + lay], texts, pages, { idea: true, group }]));
  TP.IDEA_GROUPS = ['Соцмережі', 'Бізнес', 'Друк', 'Свята', 'Освіта'];
  TP.IDEA_VARIANTS = 20;

  // ======================================================================
  // 1000 PINS IN THE PINTEREST MANNER: the kinds of pins that do well on Pinterest (quotes, recipes, «10 ideas»
  // lists, city guides, moodboards, outfits, before / after, DIY steps, palettes, routines…) in the 1000 × 1500
  // pin format, with real photos — original VIBSma layouts (nothing is copied from Pinterest) × 20 styles each
  // ======================================================================
  const shade = (c, col, a0, a1) => { const id = c.idp + 'sh' + (c.gid++); c.defs.push(`<linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity="${a0}"/><stop offset="1" stop-color="${col}" stop-opacity="${a1}"/></linearGradient>`); return `url(#${id})`; };
  const site = (c, col, y, anchor = 'middle', x) => (c.txt.extra ? TT(c, t('Сайт'), c.txt.extra, x === undefined ? c.W / 2 : x, y || c.H - c.u * 5, c.u * 2.6, { anchor, weight: 700, fill: col || mixC(c.ink, c.bg, 0.35), ls: c.u * 0.3 }).svg : '');
  const kick = (c, x, y, anchor, fill, size) => TT(c, t('Підпис'), c.txt.kicker, x, y, size || c.u * 2.8, { anchor, upper: true, weight: 700, ls: c.u * 0.5, fill: fill || c.a1 }).svg;
  const light = c => mixC(c.a1, '#FFFFFF', 0.82);
  const P = {};
  // photo on top, colour block with the title below
  P.band = c => { const { W, H, u } = c, ph = H * 0.6, ink = onC(c.a1); return bg(c, c.a1) + photo(c, 0, 0, W, ph) + kick(c, W / 2, ph + u * 9, 'middle', ink) + head(c, W / 2, ph + u * 21, W - c.pad * 2, u * 10, { anchor: 'middle', fill: ink, lines: 3 }).svg + site(c, ink); };
  // a full photo with a light band across it
  P.overlay = c => { const { W, H, u } = c, bw = W - u * 16, by = H * 0.35, bh = H * 0.3; return bg(c) + photo(c, 0, 0, W, H) + RC(t('Плашка'), (W - bw) / 2, by, bw, bh, { fill: c.bg, op: 0.92, rx: u }) + TT(c, t('Підпис'), c.txt.sub, W / 2, by + u * 8, u * 2.6, { anchor: 'middle', upper: true, weight: 700, ls: u * 0.4, fill: c.a1 }).svg + head(c, W / 2, by + u * 19, bw - u * 10, u * 8, { anchor: 'middle', lines: 3 }).svg + site(c, '#FFFFFF'); };
  // two photos with the title in between
  P.split = c => { const { W, H, u } = c, bh = H * 0.24, y0 = (H - bh) / 2; return bg(c) + photo(c, 0, 0, W, y0) + photo(c, 0, y0 + bh, W, H - y0 - bh) + RC(t('Плашка'), 0, y0, W, bh, { fill: c.sf }) + kick(c, W / 2, y0 + u * 7, 'middle') + head(c, W / 2, y0 + u * 17, W - c.pad * 2, u * 8, { anchor: 'middle', lines: 2 }).svg + site(c, null, y0 + bh - u * 3); };
  // «10 ideas…»: photo, big number, numbered list
  P.listicle = c => { const { W, H, u } = c, ph = H * 0.36; let s = bg(c) + photo(c, 0, 0, W, ph) + CI(t('Коло'), W / 2, ph, u * 11, { fill: c.a1 }) + CI(t('Кільце'), W / 2, ph, u * 12.2, { stroke: c.bg, sw: u * 0.8 }) + TT(c, t('Число'), c.txt.kicker, W / 2, ph + u * 4.2, fit(c, c.txt.kicker, u * 12, u * 17, 1), { anchor: 'middle', family: c.fh, weight: 900, fill: onC(c.a1) }).svg; s += head(c, W / 2, ph + u * 21, W - c.pad * 2, u * 7, { anchor: 'middle', lines: 2 }).svg; s += listRows(c, c.pad + u * 4, ph + u * 42, W - c.pad * 2 - u * 8, u * 3.4, items(c.txt.body).slice(0, 5), { num: true, gap: 2.6 }); return s + site(c); };
  // recipe: photo, time, title, ingredients as chips
  P.recipe = c => { const { W, H, u } = c, ph = H * 0.48; let s = bg(c, c.sf) + photo(c, 0, 0, W, ph) + RC(t('Плашка'), c.pad, ph - u * 6, u * 32, u * 8, { fill: c.a1, rx: u * 4 }) + TT(c, t('Час'), c.txt.kicker, c.pad + u * 16, ph - u * 0.8, u * 2.8, { anchor: 'middle', weight: 800, fill: onC(c.a1) }).svg; s += head(c, c.pad, ph + u * 13, W - c.pad * 2, u * 8, { lines: 2 }).svg; let x = c.pad, y = ph + u * 33; items(c.txt.body).forEach(it => { const w = it.length * u * 1.5 + u * 5; if (x + w > W - c.pad) { x = c.pad; y += u * 7.5; } s += RC(t('Інгредієнт'), x, y - u * 4.5, w, u * 6.2, { stroke: c.a1, sw: u * 0.25, rx: u * 3.1 }) + TT(c, t('Інгредієнт'), it, x + w / 2, y - u * 0.4, u * 2.5, { anchor: 'middle', weight: 600 }).svg; x += w + u * 1.6; }); return s + pill(c, c.txt.cta, c.pad, H - u * 19, u * 2.8).svg + site(c, null, H - u * 5, 'end', W - c.pad); };
  // typographic quote
  P.quote = c => { const { W, H, u } = c; return bg(c, c.sf) + RC(t('Рамка'), u * 5, u * 5, W - u * 10, H - u * 10, { stroke: c.a1, sw: u * 0.3 }) + kick(c, W / 2, H * 0.13, 'middle') + TT(c, t('Лапки'), '“', W / 2, H * 0.32, u * 30, { anchor: 'middle', family: 'Georgia', fill: c.a1, weight: 700 }).svg + TT(c, t('Цитата'), c.txt.title, W / 2, H * 0.42, fit(c, c.txt.title, u * 7.5, W - c.pad * 2.4, 6, false, c.fh), { anchor: 'middle', family: c.fh, italic: true, weight: 600, maxW: W - c.pad * 2.4, lh: 1.25 }).svg + LN(t('Лінія'), W / 2 - u * 6, H * 0.8, W / 2 + u * 6, H * 0.8, { stroke: c.a1, sw: u * 0.4 }) + TT(c, t('Автор'), c.txt.sub, W / 2, H * 0.85, u * 3, { anchor: 'middle', upper: true, weight: 700, ls: u * 0.4 }).svg + site(c, null, H - u * 9); };
  // quote over a darkened photo
  P.quotePhoto = c => { const { W, H, u } = c; return bg(c, '#111111') + photo(c, 0, 0, W, H) + RC(t('Затемнення'), 0, H * 0.3, W, H * 0.7, { fill: shade(c, '#000000', 0, 0.88) }) + TT(c, t('Підпис'), c.txt.sub, c.pad, H * 0.66, u * 2.8, { upper: true, weight: 700, ls: u * 0.4, fill: '#FFFFFF', op: 0.85 }).svg + TT(c, t('Цитата'), c.txt.title, c.pad, H * 0.72, fit(c, c.txt.title, u * 8, W - c.pad * 2, 4, false, c.fh), { family: c.fh, weight: 800, fill: '#FFFFFF', maxW: W - c.pad * 2, lh: 1.12 }).svg + site(c, '#FFFFFF', H - u * 5, 'start', c.pad); };
  // calligraphic title over a photo in a thin frame
  P.script = c => { const { W, H, u } = c; return bg(c, '#222222') + photo(c, 0, 0, W, H) + RC(t('Затемнення'), 0, 0, W, H, { fill: '#000000', op: 0.3 }) + RC(t('Рамка'), u * 6, u * 6, W - u * 12, H - u * 12, { stroke: '#FFFFFF', sw: u * 0.3 }) + TT(c, t('Підпис'), c.txt.sub, W / 2, H * 0.38, u * 2.8, { anchor: 'middle', upper: true, ls: u * 0.6, weight: 700, fill: '#FFFFFF' }).svg + TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.48, fit(c, c.txt.title, u * 11, W - c.pad * 2.2, 3, false, c.fh), { anchor: 'middle', family: c.fh, italic: true, weight: 700, fill: '#FFFFFF', maxW: W - c.pad * 2.2, lh: 1.1 }).svg + site(c, '#FFFFFF', H - u * 11); };
  // photo in a thick coloured border
  P.border = c => { const { W, H, u } = c, ph = H * 0.7, ink = onC(c.a1); return bg(c, c.a1) + photo(c, u * 5, u * 5, W - u * 10, ph) + TT(c, t('Підпис'), c.txt.sub, W / 2, ph + u * 13, u * 2.8, { anchor: 'middle', upper: true, weight: 700, ls: u * 0.5, fill: ink }).svg + head(c, W / 2, ph + u * 23, W - c.pad * 2, u * 7.5, { anchor: 'middle', fill: ink, lines: 2, italic: true, weight: 700 }).svg + site(c, ink, H - u * 4); };
  // arch-like photo
  P.arch = c => { const { W, H, u } = c, pw = W * 0.72, ph = H * 0.56; return bg(c, c.sf) + CI(t('Коло'), W * 0.86, H * 0.07, u * 12, { fill: c.a2, op: 0.45 }) + CI(t('Коло'), W * 0.1, H * 0.6, u * 7, { fill: c.a1, op: 0.3 }) + photo(c, (W - pw) / 2, u * 8, pw, ph, { rx: pw / 2 }) + kick(c, W / 2, ph + u * 17, 'middle') + head(c, W / 2, ph + u * 28, W - c.pad * 2, u * 8.5, { anchor: 'middle', lines: 2 }).svg + TT(c, t('Підзаголовок'), c.txt.sub, W / 2, H - u * 13, u * 3.2, { anchor: 'middle', italic: true, fill: mixC(c.ink, c.sf, 0.3), maxW: W - c.pad * 2 }).svg + site(c, null, H - u * 5); };
  // four photos and a round label
  P.collage4c = c => { const { W, H, u } = c, g = u * 1.2, cw = (W - g * 3) / 2, ch = (H - g * 3) / 2, r = u * 22; let s = bg(c); for (let i = 0; i < 4; i++) s += photo(c, g + (i % 2) * (cw + g), g + Math.floor(i / 2) * (ch + g), cw, ch); return s + CI(t('Коло'), W / 2, H / 2, r, { fill: c.bg }) + CI(t('Кільце'), W / 2, H / 2, r - u * 1.6, { stroke: c.a1, sw: u * 0.3 }) + kick(c, W / 2, H / 2 - u * 7, 'middle', null, u * 2.2) + TT(c, t('Заголовок'), c.txt.title, W / 2, H / 2, fit(c, c.txt.title, u * 6, r * 1.45, 3, false, c.fh), { anchor: 'middle', family: c.fh, weight: 800, maxW: r * 1.45, lh: 1.05 }).svg + site(c, mixC(c.ink, c.bg, 0.4), H / 2 + r - u * 4); };
  // three stacked photos, the title box over the middle one
  P.stack3 = c => { const { W, H, u } = c, g = u * 1.2, ph = (H - g * 4) / 3; let s = bg(c); for (let i = 0; i < 3; i++) s += photo(c, g, g + i * (ph + g), W - g * 2, ph); const bw = W * 0.8, bh = u * 26; return s + RC(t('Плашка'), (W - bw) / 2, H / 2 - bh / 2, bw, bh, { fill: c.bg }) + kick(c, W / 2, H / 2 - u * 6, 'middle') + head(c, W / 2, H / 2 + u * 4, bw - u * 8, u * 7, { anchor: 'middle', lines: 2 }).svg + site(c, null, H / 2 + bh / 2 - u * 2.5); };
  // before / after
  P.beforeAfter = c => { const { W, H, u } = c, th = H * 0.2, ph = (H - th - u * 3) / 2, lab = items(c.txt.body); let s = bg(c, c.a1) + kick(c, W / 2, u * 9, 'middle', onC(c.a1)) + head(c, W / 2, u * 19, W - c.pad * 2, u * 7, { anchor: 'middle', fill: onC(c.a1), lines: 2 }).svg; [0, 1].forEach(i => { const y = th + i * (ph + u); s += photo(c, u * 1, y, W - u * 2, ph); const l = lab[i] || (i ? 'Після' : 'До'); s += pill(c, l, c.pad, y + ph - u * 11, u * 2.8, { fill: i ? c.a1 : c.ink }).svg; }); return s + site(c, onC(c.a1), H - u * 1.6); };
  // numbered steps on a line
  P.steps = c => { const { W, H, u } = c, ph = H * 0.3, list = items(c.txt.body).slice(0, 5); let s = bg(c) + photo(c, 0, 0, W, ph) + kick(c, c.pad, ph + u * 8, 'start') + head(c, c.pad, ph + u * 17, W - c.pad * 2, u * 7, { lines: 2 }).svg; const y0 = ph + u * 34, gap = (H - y0 - u * 12) / Math.max(1, list.length - 1 || 1); s += LN(t('Лінія'), c.pad + u * 3, y0, c.pad + u * 3, y0 + gap * (list.length - 1), { stroke: c.a1, sw: u * 0.4 }); list.forEach((it, i) => { const y = y0 + i * gap; s += CI(t('Номер'), c.pad + u * 3, y, u * 3.2, { fill: c.a1 }) + TT(c, t('Номер'), String(i + 1), c.pad + u * 3, y + u * 1.1, u * 3, { anchor: 'middle', weight: 800, fill: onC(c.a1) }).svg + TT(c, t('Крок'), it, c.pad + u * 10, y + u * 1.1, u * 3.2, { weight: 600, maxW: W - c.pad * 2 - u * 10 }).svg; }); return s + site(c, null, H - u * 4); };
  // checklist on a paper card
  P.checklist = c => { const { W, H, u } = c, x = u * 8, y = u * 12, w = W - u * 16, h = H - u * 22, list = items(c.txt.body).slice(0, 6); let s = bg(c, light(c)) + RC(t('Тінь'), x + u * 1.6, y + u * 1.6, w, h, { fill: c.a1, rx: u * 2, op: 0.35 }) + RC(t('Аркуш'), x, y, w, h, { fill: '#FFFFFF', rx: u * 2 }) + RC(t('Скотч'), W / 2 - u * 10, y - u * 3, u * 20, u * 6, { fill: c.a2, op: 0.6, tf: `rotate(-3 ${q(W / 2)} ${q(y)})` }); s += TT(c, t('Заголовок'), c.txt.title, x + u * 7, y + u * 17, fit(c, c.txt.title, u * 8, w - u * 14, 2, false, c.fh), { family: c.fh, weight: 800, fill: '#1C1C24', maxW: w - u * 14, lh: 1.05 }).svg + TT(c, t('Підзаголовок'), c.txt.sub, x + u * 7, y + u * 33, u * 3, { fill: c.a1, weight: 700, maxW: w - u * 14 }).svg; list.forEach((it, i) => { const yy = y + u * 48 + i * u * 13; s += RC(t('Позначка'), x + u * 7, yy - u * 4, u * 5, u * 5, { stroke: c.a1, sw: u * 0.4, rx: u }) + TT(c, t('Завдання'), it, x + u * 16, yy, u * 3.3, { fill: '#1C1C24', maxW: w - u * 24 }).svg + LN(t('Лінія'), x + u * 7, yy + u * 4.5, x + w - u * 7, yy + u * 4.5, { stroke: '#E4E4EA', sw: u * 0.2 }); }); return s + site(c, mixC(c.ink, light(c), 0.3), H - u * 4.5); };
  // moodboard: photos, colour swatches, title
  P.moodboard = c => { const { W, H, u } = c, g = u * 1.4, cw = (W - g * 3) / 2; let s = bg(c, c.sf) + photo(c, g, g, cw, H * 0.34) + photo(c, g, g * 2 + H * 0.34, cw, H * 0.26) + photo(c, g * 2 + cw, g, cw, H * 0.24) + photo(c, g * 2 + cw, g * 2 + H * 0.24, cw, H * 0.36); const cols = [c.a1, c.a2, mixC(c.a1, '#FFFFFF', 0.55), c.ink === '#FFFFFF' ? c.bg : c.ink, mixC(c.a2, c.sf, 0.5)]; cols.forEach((col, i) => { s += CI(t('Колір'), W / 2 + (i - 2) * u * 11, H * 0.7, u * 4.2, { fill: col, stroke: '#FFFFFF', sw: u * 0.4 }); }); return s + kick(c, W / 2, H * 0.78, 'middle') + head(c, W / 2, H * 0.86, W - c.pad * 2, u * 7, { anchor: 'middle', lines: 2 }).svg + site(c, null, H - u * 3.5); };
  // city guide: photo, huge place name, list card
  P.travel = c => { const { W, H, u } = c, cy = H * 0.6; let s = bg(c, '#202020') + photo(c, 0, 0, W, H) + RC(t('Затемнення'), 0, 0, W, H * 0.45, { fill: shade(c, '#000000', 0.55, 0) }) + kick(c, W / 2, u * 10, 'middle', '#FFFFFF') + TT(c, t('Заголовок'), c.txt.title, W / 2, u * 26, fit(c, c.txt.title, u * 17, W - c.pad * 2, 1, true, c.fh), { anchor: 'middle', family: c.fh, weight: 900, upper: true, fill: '#FFFFFF' }).svg; s += RC(t('Картка'), u * 6, cy, W - u * 12, H - cy - u * 6, { fill: c.bg, rx: u * 3 }) + TT(c, t('Підзаголовок'), c.txt.sub, c.pad + u * 2, cy + u * 10, u * 4.4, { family: c.fh, weight: 800, maxW: W - c.pad * 2 }).svg + listRows(c, c.pad + u * 2, cy + u * 20, W - c.pad * 2 - u * 4, u * 3, items(c.txt.body).slice(0, 4), { gap: 2.5 }); return s + site(c, null, H - u * 9.5); };
  // outfit: 2 × 2 photos with labels
  P.outfit = c => { const { W, H, u } = c, top = H * 0.2, g = u * 2.4, cw = (W - c.pad * 2 - g) / 2, ch = (H - top - c.pad - g) / 2, lab = items(c.txt.body); let s = bg(c, c.sf) + kick(c, W / 2, u * 9, 'middle') + head(c, W / 2, u * 19, W - c.pad * 2, u * 8, { anchor: 'middle', lines: 2 }).svg; for (let i = 0; i < 4; i++) { const x = c.pad + (i % 2) * (cw + g), y = top + Math.floor(i / 2) * (ch + g); s += photo(c, x, y, cw, ch, { rx: u * 2.4 }); if (lab[i]) s += pill(c, lab[i], x + u * 2, y + ch - u * 9, u * 2.3, { fill: c.bg }).svg; } return s + site(c, null, H - u * 2.6); };
  // polaroids on a dotted background
  P.polaroid = c => { const { W, H, u } = c; let s = bg(c, light(c)); for (let y = u * 4; y < H; y += u * 6) for (let x = u * 4; x < W; x += u * 6) s += CI(t('Крапка'), x, y, u * 0.35, { fill: c.a1, op: 0.25 }); const pol = (x, y, a) => { const w = u * 54, h = u * 62; return `<g transform="rotate(${a} ${q(x + w / 2)} ${q(y + h / 2)})">${RC(t('Полароїд'), x, y, w, h, { fill: '#FFFFFF' })}${photo(c, x + u * 3, y + u * 3, w - u * 6, u * 48)}</g>`; }; s += pol(u * 6, u * 6, -5) + pol(W - u * 60, u * 50, 4); return s + TT(c, t('Заголовок'), c.txt.title, W / 2, H * 0.86, fit(c, c.txt.title, u * 9, W - c.pad * 2, 2, false, c.fh), { anchor: 'middle', family: c.fh, italic: true, weight: 700, maxW: W - c.pad * 2 }).svg + TT(c, t('Підзаголовок'), c.txt.sub, W / 2, H * 0.94, u * 3, { anchor: 'middle', weight: 700, fill: c.a1, ls: u * 0.3 }).svg; };
  // magazine cover
  P.magazine = c => { const { W, H, u } = c; let s = bg(c, '#202020') + photo(c, 0, 0, W, H) + RC(t('Затемнення'), 0, H * 0.5, W, H * 0.5, { fill: shade(c, '#000000', 0, 0.8) }) + TT(c, t('Назва журналу'), c.txt.kicker, W / 2, u * 19, fit(c, c.txt.kicker, u * 20, W - u * 10, 1, true, c.fh), { anchor: 'middle', family: c.fh, weight: 900, upper: true, fill: '#FFFFFF', ls: u * 0.4 }).svg + TT(c, t('Випуск'), c.txt.extra, W - u * 6, u * 25, u * 2.4, { anchor: 'end', weight: 700, fill: '#FFFFFF' }).svg; items(c.txt.body).slice(0, 3).forEach((it, i) => { const y = H * 0.36 + i * u * 12; s += RC(t('Позначка'), u * 6, y - u * 3, u * 1, u * 4, { fill: c.a1 === '#FFFFFF' ? c.a2 : c.a1 }) + TT(c, t('Тема номера'), it, u * 9, y, u * 3.2, { weight: 800, fill: '#FFFFFF', upper: true, maxW: W * 0.45 }).svg; }); return s + TT(c, t('Заголовок'), c.txt.title, u * 6, H * 0.8, fit(c, c.txt.title, u * 9, W - u * 12, 3, false, c.fh), { family: c.fh, weight: 900, fill: '#FFFFFF', maxW: W - u * 12, lh: 1.02 }).svg; };
  // three tip cards with photos
  P.tips3 = c => { const { W, H, u } = c, list = items(c.txt.body).slice(0, 3), top = H * 0.24, ch = (H - top - u * 10) / 3 - u * 2; let s = bg(c) + head(c, W / 2, u * 15, W - c.pad * 2, u * 8, { anchor: 'middle', lines: 2 }).svg; list.forEach((it, i) => { const y = top + i * (ch + u * 2); s += RC(t('Картка'), u * 6, y, W - u * 12, ch, { fill: c.sf, rx: u * 2.4 }) + photo(c, u * 8, y + u * 2, ch - u * 4, ch - u * 4, { rx: u * 1.6 }) + TT(c, t('Номер'), '0' + (i + 1), u * 8 + ch, y + u * 9, u * 4.4, { family: c.fh, weight: 900, fill: c.a1 }).svg + TT(c, t('Порада'), it, u * 8 + ch, y + u * 16, u * 3.2, { weight: 700, maxW: W - ch - u * 20, lh: 1.25, fill: sfInk(c) }).svg; }); return s + site(c, null, H - u * 3.5); };
  // a huge number under a photo
  P.bigNumber = c => { const { W, H, u } = c, ph = H * 0.52; return bg(c) + photo(c, 0, 0, W, ph) + RC(t('Плашка'), c.pad, c.pad, u * 30, u * 7, { fill: c.bg, rx: u * 3.5 }) + TT(c, t('Підпис'), c.txt.sub, c.pad + u * 15, c.pad + u * 4.6, u * 2.5, { anchor: 'middle', weight: 800, upper: true, fill: c.a1 }).svg + TT(c, t('Число'), c.txt.kicker, c.pad - u, ph + u * 26, fit(c, c.txt.kicker, u * 30, W - c.pad * 2, 1, false, c.fh), { family: c.fh, weight: 900, fill: c.a1 }).svg + head(c, c.pad, ph + u * 42, W - c.pad * 2, u * 7, { lines: 3 }).svg + site(c, null, H - u * 5, 'start', c.pad); };
  // weekly planner
  P.planner = c => { const { W, H, u } = c, ph = H * 0.17, days = ['Понеділок', 'Вівторок', 'Середа', 'Четвер', 'П’ятниця', 'Субота', 'Неділя']; let s = bg(c) + photo(c, 0, 0, W, ph) + head(c, c.pad, ph + u * 12, W - c.pad * 2, u * 7.5, { lines: 1 }).svg + TT(c, t('Підзаголовок'), c.txt.sub, c.pad, ph + u * 18.5, u * 2.8, { fill: c.a1, weight: 700 }).svg; const y0 = ph + u * 26, rh = (H - y0 - u * 9) / 7; days.forEach((d, i) => { const y = y0 + i * rh; s += RC(t('Рядок'), c.pad, y, W - c.pad * 2, rh - u, { fill: i % 2 ? c.bg : c.sf, rx: u, stroke: mixC(c.ink, c.bg, 0.85), sw: u * 0.15 }) + TT(c, t('День'), t(d), c.pad + u * 2.5, y + u * 5, u * 2.6, { weight: 800, fill: c.a1, upper: true, ls: u * 0.2 }).svg + LN(t('Лінія'), c.pad + u * 2.5, y + rh * 0.62, W - c.pad - u * 2.5, y + rh * 0.62, { stroke: mixC(c.ink, c.bg, 0.8), sw: u * 0.15 }); }); return s + site(c, null, H - u * 3.5); };
  // product pin
  P.shop = c => { const { W, H, u } = c, r = W * 0.34, cx = W / 2, cy = H * 0.36; let s = bg(c, c.sf) + CI(t('Коло'), cx, cy, r + u * 3, { fill: light(c) }) + photo(c, cx - r, cy - r, r * 2, r * 2, { rx: r }) + CI(t('Цінник'), cx + r * 0.85, cy - r * 0.75, u * 10, { fill: c.a1 }) + TT(c, t('Ціна'), c.txt.sub, cx + r * 0.85, cy - r * 0.75 + u * 1.4, fit(c, c.txt.sub, u * 4.4, u * 16, 1), { anchor: 'middle', weight: 900, fill: onC(c.a1) }).svg; return s + kick(c, cx, cy + r + u * 12, 'middle') + head(c, cx, cy + r + u * 22, W - c.pad * 2, u * 7.5, { anchor: 'middle', lines: 2 }).svg + pill(c, c.txt.cta, cx, H - u * 20, u * 3, { anchor: 'middle' }).svg + site(c, null, H - u * 5); };
  // blog post pin
  P.blog = c => { const { W, H, u } = c, ph = H * 0.55; return bg(c) + photo(c, 0, 0, W, ph) + CI(t('Значок'), W - c.pad - u * 6, ph, u * 11, { fill: c.a1 }) + TT(c, t('Значок'), c.txt.kicker, W - c.pad - u * 6, ph + u * 1, fit(c, c.txt.kicker, u * 2.6, u * 17, 1, true), { anchor: 'middle', weight: 800, upper: true, fill: onC(c.a1) }).svg + head(c, c.pad, ph + u * 17, W - c.pad * 2 - u * 6, u * 7.5, { lines: 3 }).svg + TT(c, t('Підзаголовок'), c.txt.sub, c.pad, H - u * 22, u * 3, { fill: mixC(c.ink, c.bg, 0.3), maxW: W - c.pad * 2 }).svg + pill(c, c.txt.cta, c.pad, H - u * 16, u * 2.6, { outline: true }).svg + site(c, null, H - u * 10, 'end', W - c.pad); };
  // daily routine timeline with a photo column
  P.dayTimeline = c => { const { W, H, u } = c, pw = W * 0.36, list = items(c.txt.body).slice(0, 5); let s = bg(c) + photo(c, W - pw, 0, pw, H) + head(c, c.pad, c.pad + u * 9, W - pw - c.pad * 2, u * 7, { lines: 3 }).svg; const y0 = H * 0.36, gap = (H * 0.56) / Math.max(1, list.length); list.forEach((it, i) => { const [tm, ...rest] = it.split(' '); const y = y0 + i * gap; s += TT(c, t('Час'), tm, c.pad, y, u * 4.6, { family: c.fh, weight: 900, fill: c.a1 }).svg + TT(c, t('Справа'), rest.join(' '), c.pad, y + u * 5, u * 2.9, { maxW: W - pw - c.pad * 2, weight: 600 }).svg; }); return s + site(c, null, H - u * 4, 'start', c.pad); };
  // colour palette from a photo
  P.palette = c => { const { W, H, u } = c, ph = H * 0.56; const cols = [c.a1, c.a2, mixC(c.a1, '#FFFFFF', 0.45), mixC(c.a2, '#000000', 0.25), c.ink === '#FFFFFF' ? c.sf : c.ink]; let s = bg(c) + photo(c, 0, 0, W, ph); cols.forEach((col, i) => { const x = W / 2 + (i - 2) * u * 18.5; s += CI(t('Колір'), x, ph + u * 9, u * 8, { fill: col, stroke: c.bg, sw: u * 0.8 }) + TT(c, t('Код кольору'), O.color.norm(col) || col, x, ph + u * 22, u * 2.2, { anchor: 'middle', weight: 600, fill: mixC(c.ink, c.bg, 0.3) }).svg; }); return s + kick(c, W / 2, ph + u * 33, 'middle') + head(c, W / 2, ph + u * 43, W - c.pad * 2, u * 7, { anchor: 'middle', lines: 2 }).svg + site(c, null, H - u * 4); };
  // workout over a photo
  P.workout = c => { const { W, H, u } = c; let s = bg(c, '#111111') + photo(c, 0, 0, W, H) + RC(t('Затемнення'), 0, 0, W, H, { fill: '#000000', op: 0.48 }) + RC(t('Плашка'), c.pad, c.pad, u * 34, u * 7, { fill: c.a1, rx: u * 3.5 }) + TT(c, t('Підпис'), c.txt.kicker, c.pad + u * 17, c.pad + u * 4.6, u * 2.5, { anchor: 'middle', weight: 800, upper: true, fill: onC(c.a1) }).svg + TT(c, t('Заголовок'), c.txt.title, c.pad, H * 0.22, fit(c, c.txt.title, u * 10, W - c.pad * 2, 3, true, c.fh), { family: c.fh, weight: 900, upper: true, fill: '#FFFFFF', maxW: W - c.pad * 2, lh: 1 }).svg; items(c.txt.body).slice(0, 6).forEach((it, i) => { const y = H * 0.5 + i * u * 11; s += RC(t('Рядок'), c.pad, y - u * 6.5, W - c.pad * 2, u * 9, { fill: '#FFFFFF', op: 0.14, rx: u * 1.6 }) + TT(c, t('Вправа'), it, c.pad + u * 3, y, u * 3.4, { weight: 700, fill: '#FFFFFF' }).svg; }); return s + site(c, '#FFFFFF', H - u * 4); };
  // DIY: four numbered photos with steps
  P.diy = c => { const { W, H, u } = c, list = items(c.txt.body).slice(0, 4), top = H * 0.19, g = u * 2.4, cw = (W - c.pad * 2 - g) / 2, ch = H * 0.27; let s = bg(c, c.sf) + kick(c, W / 2, u * 8, 'middle') + head(c, W / 2, u * 17, W - c.pad * 2, u * 7.5, { anchor: 'middle', lines: 2 }).svg; for (let i = 0; i < 4; i++) { const x = c.pad + (i % 2) * (cw + g), y = top + Math.floor(i / 2) * (ch + u * 13); s += photo(c, x, y, cw, ch, { rx: u * 2 }) + CI(t('Номер'), x + u * 5, y + u * 5, u * 3.6, { fill: c.a1 }) + TT(c, t('Номер'), String(i + 1), x + u * 5, y + u * 6.3, u * 3.4, { anchor: 'middle', weight: 900, fill: onC(c.a1) }).svg; if (list[i]) s += TT(c, t('Крок'), list[i], x, y + ch + u * 5, u * 2.8, { weight: 700, maxW: cw }).svg; } return s + site(c, null, H - u * 4); };
  // elegant invitation
  P.invite = c => { const { W, H, u } = c, pw = W - c.pad * 2, ph = H * 0.44; return bg(c, c.sf) + photo(c, c.pad, c.pad, pw, ph, { rx: pw / 2 }) + TT(c, t('Підпис'), c.txt.kicker, W / 2, c.pad + ph + u * 10, u * 3.2, { anchor: 'middle', italic: true, family: c.fh, fill: c.a1 }).svg + TT(c, t('Заголовок'), c.txt.title, W / 2, c.pad + ph + u * 21, fit(c, c.txt.title, u * 8, W - c.pad * 2, 3, false, c.fh), { anchor: 'middle', family: c.fh, weight: 700, maxW: W - c.pad * 2, lh: 1.1 }).svg + LN(t('Лінія'), W / 2 - u * 8, H * 0.86, W / 2 + u * 8, H * 0.86, { stroke: c.a1, sw: u * 0.3 }) + TT(c, t('Дата'), c.txt.sub, W / 2, H * 0.9, u * 3.4, { anchor: 'middle', weight: 700, ls: u * 0.3, upper: true }).svg + TT(c, t('Місце'), c.txt.extra, W / 2, H * 0.94, u * 2.6, { anchor: 'middle', fill: mixC(c.ink, c.sf, 0.35) }).svg; };
  // text that lies on the second background colour must contrast with it in every style
  const sfInk = c => (Math.abs(O.color.luminance(c.ink) - O.color.luminance(c.sf)) > 0.35 ? c.ink : onC(c.sf));
  const onSf = f => c => { const k = c.ink; c.ink = sfInk(c); try { return f(c); } finally { c.ink = k; } };
  ['split', 'recipe', 'quote', 'arch', 'outfit', 'moodboard', 'diy', 'invite', 'shop'].forEach(k => { P[k] = onSf(P[k]); });
  Object.entries(P).forEach(([k, f]) => { L['p-' + k] = f; });
  // [id, name, group, layout, texts {kicker, title, sub, body, cta, extra}, photo topics]
  const PX = IX;
  TP.PINS = [
    ['q-mind', 'Цитата дня', 'Цитати', 'quote', PX('Цитата дня', 'Роби те, що можеш, з тим, що маєш, там, де ти є', 'Теодор Рузвельт', '', '', 'vibsma.com'), ['nature']],
    ['q-photo', 'Цитата на фото', 'Цитати', 'quotePhoto', PX('', 'Маленькі кроки щодня — великі зміни за рік', 'Нагадування', '', '', '@vibsma'), ['sea', 'nature']],
    ['q-script', 'Афірмація', 'Цитати', 'script', PX('', 'Я заслуговую на спокій', 'Афірмація на тиждень', '', '', 'vibsma.com'), ['flowers', 'nature']],
    ['q-border', 'Цитата в рамці', 'Цитати', 'border', PX('', 'Щастя — це шлях, а не пункт призначення', 'Пам’ятай', '', '', 'vibsma.com'), ['cozy', 'nature']],
    ['q-arch', 'Мотивація ранку', 'Цитати', 'arch', PX('Доброго ранку', 'Новий день — нові можливості', 'Почни з усмішки', '', '', 'vibsma.com'), ['nature', 'cozy']],
    ['q-overlay', 'Цитата на тлі', 'Цитати', 'overlay', PX('', 'Ти сильніший, ніж думаєш', 'Нагадування для себе', '', '', '@vibsma'), ['nature', 'sea']],
    ['f-recipe', 'Рецепт', 'Їжа', 'recipe', PX('25 хв · 2 порції', 'Паста з томатами й базиліком', '', 'Паста 200 г|Томати 4 шт|Часник|Базилік|Пармезан|Оливкова олія', 'Повний рецепт', 'vibsma.com'), ['food']],
    ['f-band', 'Сніданок', 'Їжа', 'band', PX('Сніданок за 5 хвилин', 'Вівсянка з ягодами й медом', '', '', '', 'vibsma.com'), ['food']],
    ['f-split', 'Легка вечеря', 'Їжа', 'split', PX('Легка вечеря', 'Салат із запеченим гарбузом', '', '', '', 'vibsma.com'), ['food']],
    ['f-list', 'Смузі', 'Їжа', 'listicle', PX('7', 'смузі для бадьорого ранку', '', 'Банан і шпинат|Ягідний мікс|Манго й кокос|Ківі та яблуко|Какао й арахіс', '', 'vibsma.com'), ['food']],
    ['f-steps', 'Покроковий рецепт', 'Їжа', 'steps', PX('Випічка', 'Ідеальне печиво за 4 кроки', '', 'Змішайте масло й цукор|Додайте яйце й борошно|Сформуйте кульки|Випікайте 12 хв при 180°', '', 'vibsma.com'), ['food']],
    ['f-planner', 'Меню на тиждень', 'Їжа', 'planner', PX('', 'Меню на тиждень', 'Плануйте й заощаджуйте', '', '', 'vibsma.com'), ['food']],
    ['h-list', 'Ідеї для вітальні', 'Дім', 'listicle', PX('12', 'ідей для затишної вітальні', '', 'Теплі текстилі|Живі рослини|Тепле світло|Книжкові полиці|Свічки й аромати', '', 'vibsma.com'), ['home', 'cozy']],
    ['h-mood', 'Мудборд інтер’єру', 'Дім', 'moodboard', PX('Інтер’єр', 'Скандинавський затишок', '', '', '', 'vibsma.com'), ['home', 'cozy']],
    ['h-ba', 'До і після', 'Дім', 'beforeAfter', PX('Переробка', 'Нове життя старого комода', '', 'До|Після', '', 'vibsma.com'), ['home']],
    ['h-palette', 'Палітра кольорів', 'Дім', 'palette', PX('Палітра', 'Теплі відтінки осені', '', '', '', 'vibsma.com'), ['cozy', 'nature']],
    ['h-collage', 'Колаж спальні', 'Дім', 'collage4c', PX('Натхнення', 'Затишна спальня', '', '', '', 'vibsma.com'), ['home', 'cozy']],
    ['h-tips', 'Порядок на кухні', 'Дім', 'tips3', PX('', '3 способи впорядкувати кухню', '', 'Прозорі контейнери для круп|Гачки на дверцятах шафи|Полиця-сходинка для спецій', '', 'vibsma.com'), ['home', 'food']],
    ['t-guide', 'Гід містом', 'Подорожі', 'travel', PX('Гід на вихідні', 'Львів', '48 годин у місті', 'Кава на площі Ринок|Високий Замок на світанку|Вечеря в Старому місті|Прогулянка Личаківським', '', 'vibsma.com'), ['city']],
    ['t-polaroid', 'Спогади з подорожі', 'Подорожі', 'polaroid', PX('', 'Літо біля моря', 'Одеса · 2026', '', '', ''), ['sea', 'travel']],
    ['t-list', 'Що взяти в подорож', 'Подорожі', 'listicle', PX('15', 'речей, які варто взяти в подорож', '', 'Павербанк|Багаторазова пляшка|Аптечка|Адаптер для розеток|Зручне взуття', '', 'vibsma.com'), ['travel']],
    ['t-band', 'Куди поїхати', 'Подорожі', 'band', PX('Куди поїхати', 'Карпати восени', '', '', '', 'vibsma.com'), ['nature']],
    ['t-stack', 'Фотоісторія', 'Подорожі', 'stack3', PX('Подорож', 'Тиждень у горах', '', '', '', 'vibsma.com'), ['nature', 'travel']],
    ['t-mag', 'Обкладинка журналу', 'Подорожі', 'magazine', PX('Мандри', 'Найкрасивіші місця Європи', '', 'Таємні пляжі|Маршрути на вихідні|Бюджет поїздки', '', 'Випуск 07'), ['travel', 'city']],
    ['s-outfit', 'Образ дня', 'Стиль і краса', 'outfit', PX('Образ дня', 'Осінній кежуал', '', 'Тренч|Светр|Джинси|Лофери', '', 'vibsma.com'), ['people']],
    ['s-routine', 'Ранковий ритуал', 'Стиль і краса', 'dayTimeline', PX('', 'Мій ранковий ритуал', '', '07:00 Склянка води|07:15 Розтяжка|07:30 Догляд за шкірою|08:00 Сніданок|08:30 План на день', '', 'vibsma.com'), ['people', 'cozy']],
    ['s-shop', 'Товар дня', 'Стиль і краса', 'shop', PX('Новинка', 'Сироватка з вітаміном С', '499 ₴', '', 'Купити', 'vibsma.com'), ['flowers']],
    ['s-arch', 'Тренд сезону', 'Стиль і краса', 'arch', PX('Тренд сезону', 'Пастельні кольори', 'Як носити цієї весни', '', '', 'vibsma.com'), ['people', 'flowers']],
    ['s-script', 'Б’юті-порада', 'Стиль і краса', 'script', PX('', 'Сяйво шкіри без фільтрів', 'Б’юті-порада', '', '', 'vibsma.com'), ['flowers', 'people']],
    ['s-palette', 'Кольори гардероба', 'Стиль і краса', 'palette', PX('Колористика', 'Кольори літнього гардероба', '', '', '', 'vibsma.com'), ['sea', 'people']],
    ['b-blog', 'Новий допис', 'Блог і бізнес', 'blog', PX('Новий допис', 'Як почати блог і не кинути через місяць', 'Покрокова інструкція для початківців', '', 'Читати', 'vibsma.com'), ['work']],
    ['b-tips', 'Звички продуктивних людей', 'Блог і бізнес', 'tips3', PX('', '3 звички продуктивних людей', '', 'Плануйте день з вечора|Робіть важливе зранку|Вимикайте сповіщення', '', 'vibsma.com'), ['work']],
    ['b-steps', 'Інструкція', 'Блог і бізнес', 'steps', PX('Маркетинг', '5 кроків до першого продажу', '', 'Знайдіть свою аудиторію|Створіть корисний контент|Зберіть контакти|Зробіть пропозицію|Попросіть відгук', '', 'vibsma.com'), ['work']],
    ['b-check', 'Чек-лист запуску', 'Блог і бізнес', 'checklist', PX('', 'Чек-лист запуску сайту', 'Перевірте перед стартом', 'Домен і хостинг|Логотип і кольори|Сторінка «Про нас»|Контакти й соцмережі|Аналітика', '', 'vibsma.com'), ['work']],
    ['b-fact', 'Факт у цифрах', 'Блог і бізнес', 'bigNumber', PX('87%', 'покупців читають відгуки перед покупкою', 'Статистика', '', '', 'vibsma.com'), ['work', 'city']],
    ['b-planner', 'Тижневий планер', 'Блог і бізнес', 'planner', PX('', 'Тижневий планер', 'Фокус на головному', '', '', 'vibsma.com'), ['work']],
    ['w-workout', 'Тренування вдома', 'Здоров’я', 'workout', PX('Без інвентарю', 'Тренування на 20 хвилин', '', 'Присідання — 20|Віджимання — 12|Планка — 45 с|Випади — 16|Скелелаз — 30 с', '', 'vibsma.com'), ['sport']],
    ['w-habits', 'Трекер звичок', 'Здоров’я', 'checklist', PX('', 'Трекер звичок', '30 днів турботи про себе', 'Пити 2 л води|Спати 8 годин|10 000 кроків|Менше цукру|Медитація 10 хв', '', 'vibsma.com'), ['nature']],
    ['w-yoga', 'Йога', 'Здоров’я', 'band', PX('Йога для початківців', 'Ранковий комплекс на 15 хвилин', '', '', '', 'vibsma.com'), ['sport', 'nature']],
    ['w-evening', 'Вечірній ритуал', 'Здоров’я', 'dayTimeline', PX('', 'Вечірній ритуал для сну', '', '21:00 Без екранів|21:15 Теплий душ|21:30 Читання|22:00 Дихальна практика|22:30 Сон', '', 'vibsma.com'), ['cozy']],
    ['w-365', 'Челендж на рік', 'Здоров’я', 'bigNumber', PX('365', 'днів, щоб змінити звички', 'Челендж', '', '', 'vibsma.com'), ['sport', 'nature']],
    ['w-snacks', 'Корисні перекуси', 'Здоров’я', 'listicle', PX('9', 'корисних перекусів для роботи', '', 'Горіхи|Йогурт із ягодами|Хумус і овочі|Яблуко з арахісовою пастою|Сир і крекери', '', 'vibsma.com'), ['food']],
    ['d-candle', 'Зроби сам', 'DIY і свята', 'diy', PX('Зроби сам', 'Ароматна свічка в банці', '', 'Розтопіть віск|Додайте аромат|Закріпіть ґніт|Залийте у форму', '', 'vibsma.com'), ['cozy']],
    ['d-invite', 'Запрошення на весілля', 'DIY і свята', 'invite', PX('Запрошуємо на', 'Весілля Анни та Марка', '14 вересня 2026', '', '', 'Ресторан «Сад», Київ'), ['flowers']],
    ['d-xmas', 'Новорічний декор', 'DIY і свята', 'collage4c', PX('Свята', 'Новорічний декор своїми руками', '', '', '', 'vibsma.com'), ['winter', 'cozy']],
    ['d-party', 'Ідеї для вечірки', 'DIY і свята', 'stack3', PX('Вечірка', 'День народження в стилі бохо', '', '', '', 'vibsma.com'), ['party']],
    ['d-gifts', 'Ідеї подарунків', 'DIY і свята', 'listicle', PX('20', 'ідей подарунків до 500 ₴', '', 'Свічка з ароматом|Книга|Теплий плед|Набір чаю|Фоторамка', '', 'vibsma.com'), ['cozy', 'winter']],
    ['d-memories', 'Фотоспогади', 'DIY і свята', 'polaroid', PX('', 'Наші найкращі моменти', '2026', '', '', ''), ['party', 'people']],
    ['d-wreath', 'Вінок своїми руками', 'DIY і свята', 'diy', PX('DIY', 'Осінній вінок на двері', '', 'Основа з лози|Сухе листя|Шишки й ягоди|Атласна стрічка', '', 'vibsma.com'), ['flowers', 'nature']],
    ['d-card', 'Святкова листівка', 'DIY і свята', 'border', PX('', 'Зі святом, рідні!', 'Тепла листівка', '', '', 'vibsma.com'), ['winter', 'cozy']]
  ];
  TP.PINS.forEach(([id, name, group, lay, texts, topic]) => { TP.CATS.push(['pin-' + id, name, 1000, 1500, ['p-' + lay], texts, 1, { pin: true, group }]); TOPIC['pin-' + id] = topic; });
  TP.PIN_GROUPS = ['Цитати', 'Їжа', 'Дім', 'Подорожі', 'Стиль і краса', 'Блог і бізнес', 'Здоров’я', 'DIY і свята'];
  // the 200 résumés: [id, name, set (pin | pro), layout, person]
  TP.CVS = [
    ['arch', 'Резюме «Арка»', 'pin', 'arch', 1], ['circle', 'Резюме з круглим фото', 'pin', 'circle', 0], ['pastel', 'Пастельне резюме', 'pin', 'pastel', 4], ['split', 'Резюме з кольоровою колонкою', 'pin', 'split', 2], ['monogram', 'Резюме з монограмою', 'pin', 'monogram', 3],
    ['timeline', 'Резюме-таймлайн', 'pin', 'timeline', 1], ['blob', 'Резюме з органічними формами', 'pin', 'blob', 4], ['skillbars', 'Резюме зі шкалами навичок', 'pin', 'skillbars', 2], ['magazine', 'Журнальне резюме', 'pin', 'magazine', 0], ['botanical', 'Ботанічне резюме', 'pin', 'botanical', 4],
    ['executive', 'Резюме керівника', 'pro', 'executive', 3], ['gradient', 'Градієнтне резюме', 'pro', 'gradient', 1], ['geo', 'Геометричне резюме', 'pro', 'geo', 2], ['grid', 'Резюме «Швейцарська сітка»', 'pro', 'grid', 1], ['creative', 'Креативне резюме', 'pro', 'creative', 0],
    ['photohero', 'Резюме з великим фото', 'pro', 'photohero', 4], ['luxe', 'Розкішне резюме', 'pro', 'luxe', 3], ['icons', 'Резюме з іконками', 'pro', 'icons', 0], ['infographic', 'Інфографічне резюме', 'pro', 'infographic', 2], ['twotone', 'Двоколірне резюме', 'pro', 'twotone', 3]
  ];
  TP.CVS.forEach(([id, name, set, lay, pi]) => { TP.CATS.push(['cvk-' + id, name, 595, 842, ['cvx-' + lay], TX('', '', '', '', '', ''), 1, { cv: true, group: set, persona: pi }]); TOPIC['cvk-' + id] = ['people']; });
  TP.CV_VARIANTS = 10;

  // ======================================================================
  // 1000 TEMPLATES OF THE «VIBSma Templates» BOARD (templeats/VIBSma Templates.dc.html): 10 formats, 22 layouts,
  // 10 styles with 4 palettes each and 11 topics. The board draws them with HTML and CSS flexbox; here the same
  // designs are rebuilt from ordinary SVG layers by a small flexbox-like box layout, so every one stays editable.
  // The list itself is the board's: its 102 hand-made templates, then its seeded generator for the rest.
  // ======================================================================
  // [name, English name, board width, board height, width, height]
  const KF = {
    post: ['Пост Instagram', 'Instagram post', 360, 360, 1080, 1080], story: ['Сторіз / Reels', 'Story / Reel', 360, 640, 1080, 1920],
    pin: ['Пін Pinterest', 'Pinterest pin', 360, 540, 1000, 1500], poster: ['Постер / флаєр', 'Poster / flyer', 360, 504, 900, 1260],
    pres: ['Презентація', 'Presentation', 640, 360, 1920, 1080], yt: ['Мініатюра YouTube', 'YouTube thumbnail', 640, 360, 1280, 720],
    invite: ['Запрошення', 'Invitation', 360, 504, 1000, 1400], card: ['Візитка', 'Business card', 360, 206, 1050, 600],
    resume: ['Резюме', 'Resume', 360, 509, 595, 842], menu: ['Меню', 'Menu', 360, 509, 595, 842]
  };
  const KS_UK = { minimal: 'Мінімалізм у беж', y2k: 'Неон Y2K', brutal: 'Бруталізм', retro: 'Ретро 70-х', editorial: 'Журнальний', pastel: 'Пастель', swiss: 'Швейцарська сітка', collage: 'Колаж', luxe: 'Темна розкіш', boho: 'Бохо' };
  const KN_UK = { beauty: 'Краса й нігті', food: 'Кафе та їжа', fitness: 'Фітнес', fashion: 'Мода', realty: 'Нерухомість', edu: 'Освіта', wedding: 'Весілля й свята', biz: 'Бізнес і SaaS', travel: 'Подорожі', quotes: 'Цитати', sale: 'Розпродажі й акції' };
  // real photos by topic (the board shows striped placeholders)
  const KTOPIC = { beauty: ['flowers', 'people'], food: ['food'], fitness: ['sport'], fashion: ['people', 'city'], realty: ['home'], edu: ['work', 'people'], wedding: ['flowers', 'party'], biz: ['work', 'city'], travel: ['travel', 'nature', 'sea'], quotes: ['nature', 'sea', 'cozy'], sale: ['city', 'people'] };
  // average glyph width (em, mixed case) of the board's fonts: text wraps and big type fits by it
  const KW = { 'Cormorant Garamond': 0.44, Unbounded: 0.74, Anton: 0.4, Shrikhand: 0.62, 'DM Serif Display': 0.5, Fredoka: 0.54, Archivo: 0.6, Caveat: 0.4, 'Bodoni Moda': 0.56, Forum: 0.5, Manrope: 0.56, 'Space Grotesk': 0.56, 'Space Mono': 0.6, 'DM Sans': 0.54, 'Tenor Sans': 0.6 };
  const kfw = f => (KW[f] || 0.56) * 1.04;
  // the board's contrast rule (WCAG luminance) for text on the accent colour
  const kLum = h => { const n = parseInt(h.slice(1), 16), f = x => { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); }; return 0.2126 * f(n >> 16 & 255) + 0.7152 * f(n >> 8 & 255) + 0.0722 * f(n & 255); };
  const kOn = h => (kLum(h) > 0.27 ? '#151412' : '#FFFFFF');

  // ---- box layout: a box knows its natural width (iw) and its height for a width (h); draw(x, y, w, h, ta) gives
  // SVG. Columns and rows place their children the way CSS flexbox does (gap, justify, align, flex, shrink).
  // padding, background, borders, rotation and margins around any box
  const KBX = (b, o = {}) => {
    const pd = o.p === undefined ? 0 : o.p;
    let [pt, pr, pb, pl] = Array.isArray(pd) ? (pd.length === 2 ? [pd[0], pd[1], pd[0], pd[1]] : pd) : [pd, pd, pd, pd];
    const bw = o.border ? o.border[0] : 0;
    pt += bw + (o.bt ? o.bt[0] : 0); pb += bw + (o.bb ? o.bb[0] : 0); pl += bw + (o.bl ? o.bl[0] : 0); pr += bw;
    const n = (pt || pr || pb || pl || o.bg || o.rot) ? {
      base: b.base === undefined ? undefined : b.base + pt,
      iw: () => b.iw() + pl + pr,
      h: w => b.h(w - pl - pr) + pt + pb,
      draw: (x, y, w, h, ta) => {
        let s = '';
        if (o.bg || bw) s += RC(t(o.bgName || 'Плашка'), x + bw / 2, y + bw / 2, w - bw, h - bw, { fill: o.bg, rx: o.rx, stroke: bw ? o.border[1] : undefined, sw: bw || undefined });
        s += b.draw(x + pl, y + pt, w - pl - pr, h - pt - pb, ta);
        // [width, colour, opacity, dash, cap]
        const ln = (x1, y1, x2, y2, v) => LN(t(v[3] ? 'Пунктир' : 'Лінія'), x1, y1, x2, y2, { stroke: v[1], sw: v[0], op: v[2], dash: v[3], cap: v[4] || 'butt' });
        if (o.bt) s += ln(x, y + o.bt[0] / 2, x + w, y + o.bt[0] / 2, o.bt);
        if (o.bb) s += ln(x, y + h - o.bb[0] / 2, x + w, y + h - o.bb[0] / 2, o.bb);
        if (o.bl) s += ln(x + o.bl[0] / 2, y, x + o.bl[0] / 2, y + h, o.bl);
        if (o.rot) s = `<g transform="rotate(${o.rot} ${q(x + w / 2)} ${q(y + h / 2)})">${s}</g>`;
        return s;
      }
    } : Object.assign({}, b);
    ['flex', 'self', 'mt', 'mb', 'maxW', 'shrink'].forEach(k => { if (o[k] !== undefined) n[k] = o[k]; else if (b[k] !== undefined) n[k] = b[k]; });
    const fw = o.fixW !== undefined ? o.fixW : b.fixW !== undefined ? b.fixW + pl + pr : undefined, fh = o.fixH !== undefined ? o.fixH : b.fixH !== undefined ? b.fixH + pt + pb : undefined;
    if (fw !== undefined) n.fixW = fw;
    if (fh !== undefined) n.fixH = fh;
    return n;
  };
  const KB = {};
  // text: as wide as its one line, as tall as its wrapped lines; the first baseline is known for baseline rows
  KB.text = (c, str, size, o = {}) => {
    str = str === undefined || str === null ? '' : String(str);
    const up = !!o.upper, s2 = up ? str.toUpperCase() : str, lh = o.lh || 1.2, k0 = o.k || 0.56, ke = k0 * (up ? 1.18 : 1) + (o.ls ? o.ls / size : 0);
    const lines = w => (o.nowrap || !(w > 0) ? [s2] : wrap(s2, size, w, ke));
    const b = {
      base: size * ((lh - 1) / 2 + 0.78),
      iw: () => s2.length * size * ke,
      h: w => (str ? lines(w).length * size * lh : 0),
      draw: (x, y, w, h, ta) => {
        if (!str) return '';
        const a = o.align || ta || 'start', ax = a === 'middle' ? x + w / 2 : a === 'end' ? x + w : x;
        const svg = TT(c, t(o.id || 'Текст'), str, ax, y + b.base, size, { family: o.family, weight: o.weight, italic: o.italic, upper: up, ls: o.ls || undefined, lh, fill: o.fill, anchor: a, maxW: o.nowrap ? 0 : w, k: k0, op: o.op }).svg;
        return o.outline ? svg.replace('<text ', `<text stroke="${o.outline}" stroke-width="${q(o.ow || 1)}" `) : svg;
      }
    };
    if (o.nowrap) b.shrink = 0;
    return KBX(b, o);
  };
  // a box of a given height that draws itself (photos, shapes, grids)
  KB.fn = (h, draw, o = {}) => KBX({ iw: () => o.iw || 0, h: () => h, draw }, o);
  KB.col = (c, o, ...kids) => {
    kids = kids.filter(Boolean);
    const g = o.gap || 0, al = o.align || 'stretch', jc = o.jc || 'start';
    const wOf = (k, w) => { const cap = Math.min(w, k.maxW || Infinity); if (k.fixW !== undefined) return Math.min(k.fixW, w); return (k.self || al) === 'stretch' ? cap : Math.min(k.iw(), cap); };
    const hOf = (k, w) => (k.fixH !== undefined ? k.fixH : k.h(w));
    const extra = () => kids.reduce((a, k) => a + (k.mt || 0) + (k.mb || 0), 0) + g * Math.max(0, kids.length - 1);
    return KBX({
      iw: () => Math.max(0, ...kids.map(k => (k.fixW !== undefined ? k.fixW : Math.min(k.iw(), k.maxW || Infinity)))),
      h: w => kids.reduce((a, k) => a + hOf(k, wOf(k, w)), 0) + extra(),
      draw: (x, y, w, h, ta) => {
        ta = o.ta || ta;
        const ws = kids.map(k => wOf(k, w)), hs = kids.map((k, i) => hOf(k, ws[i]));
        let free = h - hs.reduce((a, v) => a + v, 0) - extra(), gap = g, yy = y;
        const fl = kids.reduce((a, k) => a + (k.flex || 0), 0);
        if (fl && Math.abs(free) > 0.01) { kids.forEach((k, i) => { if (k.flex) hs[i] = Math.max(0, hs[i] + free * k.flex / fl); }); free = 0; }
        if (free > 0) { if (jc === 'center') yy += free / 2; else if (jc === 'end') yy += free; else if (jc === 'between' && kids.length > 1) gap += free / (kids.length - 1); }
        return kids.map((k, i) => {
          yy += k.mt || 0;
          const a = k.self || al, kx = a === 'center' ? x + (w - ws[i]) / 2 : a === 'end' ? x + w - ws[i] : x, s = k.draw(kx, yy, ws[i], hs[i], ta);
          yy += hs[i] + (k.mb || 0) + gap;
          return s;
        }).join('');
      }
    }, o);
  };
  KB.row = (c, o, ...kids) => {
    kids = kids.filter(Boolean);
    const g = o.gap || 0, al = o.align || 'center', jc = o.jc || 'start', gaps = g * Math.max(0, kids.length - 1);
    const rigid = k => k.shrink === 0 || k.fixW !== undefined;
    const widths = w => {
      const ws = kids.map(k => (k.fixW !== undefined ? k.fixW : k.flex ? 0 : Math.min(k.iw(), k.maxW || Infinity)));
      const free = w - ws.reduce((a, v) => a + v, 0) - gaps, fl = kids.reduce((a, k) => a + (k.flex || 0), 0);
      if (free > 0 && fl) kids.forEach((k, i) => { if (k.flex) ws[i] += free * k.flex / fl; });
      else if (free < 0) { const sh = kids.reduce((a, k, i) => a + (rigid(k) ? 0 : ws[i]), 0); if (sh > 0) kids.forEach((k, i) => { if (!rigid(k)) ws[i] = Math.max(0, ws[i] + free * ws[i] / sh); }); }
      return ws;
    };
    const lay = w => {
      const ws = widths(w), hs = kids.map((k, i) => (k.fixH !== undefined ? k.fixH : k.h(ws[i])));
      let B = 0, D = 0;
      if (al === 'baseline') kids.forEach((k, i) => { const bl = k.base === undefined ? hs[i] : k.base; B = Math.max(B, bl); D = Math.max(D, hs[i] - bl); });
      return { ws, hs, B, h: al === 'baseline' ? B + D : Math.max(0, ...hs) };
    };
    return KBX({
      iw: () => kids.reduce((a, k) => a + (k.fixW !== undefined ? k.fixW : Math.min(k.iw(), k.maxW || Infinity)), 0) + gaps,
      h: w => lay(w).h,
      draw: (x, y, w, h, ta) => {
        ta = o.ta || ta;
        const r = lay(w), free = w - r.ws.reduce((a, v) => a + v, 0) - gaps;
        let gap = g, xx = x;
        if (free > 0) { if (jc === 'center') xx += free / 2; else if (jc === 'end') xx += free; else if (jc === 'between' && kids.length > 1) gap += free / (kids.length - 1); }
        return kids.map((k, i) => {
          const kw = r.ws[i], a = k.self || al;
          let kh = r.hs[i], ky = y;
          if (a === 'stretch') kh = h; else if (a === 'center') ky = y + (h - kh) / 2; else if (a === 'end') ky = y + h - kh; else if (a === 'baseline') ky = y + r.B - (k.base === undefined ? kh : k.base);
          const s = k.draw(xx, ky, kw, kh, ta);
          xx += kw + gap;
          return s;
        }).join('');
      }
    }, o);
  };
  // a photo; r is a corner radius or an arch { t: top radius, b: bottom radius } (an arch clips, so it stays round
  // in the inserted template, too)
  const kPhoto = (c, x, y, w, h, r) => {
    if (w < 1 || h < 1) return '';
    if (typeof r !== 'object') return photo(c, x, y, w, h, { rx: Math.min(r || 0, w / 2, h / 2) });
    const id = c.idp + 'ka' + (c.gid++), a = Math.min(r.t, w / 2, h), b = Math.min(r.b || 0, w / 2);
    const d = `M${q(x)} ${q(y + h - b)}V${q(y + a)}A${q(a)} ${q(a)} 0 0 1 ${q(x + a)} ${q(y)}H${q(x + w - a)}A${q(a)} ${q(a)} 0 0 1 ${q(x + w)} ${q(y + a)}V${q(y + h - b)}` +
      (b ? `A${q(b)} ${q(b)} 0 0 1 ${q(x + w - b)} ${q(y + h)}H${q(x + b)}A${q(b)} ${q(b)} 0 0 1 ${q(x)} ${q(y + h - b)}` : `V${q(y + h)}H${q(x)}`) + 'Z';
    c.defs.push(`<clipPath id="${id}"><path d="${d}"/></clipPath>`);
    return `<g id="${esc(t('Фото'))}" clip-path="url(#${id})">${photo(c, x, y, w, h)}</g>`;
  };
  // the board's mkCtx, in real pixels: s is the board's scale times the board → real size factor
  const kctx = c => {
    const sp = c.meta.kt, F = KF[sp.fmt], st = KD.STYLES[sp.style], P = st.pals[sp.pal];
    const p = { bg: P.bg, ink: P.ink, accent: P.accent, soft: P.soft }, fam = v => v.replace(/"/g, '').split(',')[0];
    const head = fam(st.head), body = fam(st.body), script = fam(st.script);
    const W = c.W, H = c.H, s = Math.min(F[2], F[3]) / 360 * (W / F[2]), m = 26 * s;
    const k = { c, sp, st, p, t: KD.copyOf(sp), W, H, s, m, fh: head, land: F[2] > F[3], tall: F[3] / F[2] > 1.6, sq: F[2] === F[3], onA: kOn(p.accent), id: sp.id };
    const txt = (x, size, o) => KB.text(c, x, size, o);
    k.R = (n = 1) => (st.rad >= 999 ? 22 : st.rad) * s * n;
    k.head = (x, sz, ex = {}) => { const size = ex.size || sz * s * st.mul; return txt(x, size, Object.assign({ id: 'Заголовок', family: head, weight: st.hw, upper: !!st.up, ls: (ex.tr === undefined ? st.tr : ex.tr) * size, lh: st.lh, k: kfw(head), fill: p.ink }, ex)); };
    k.body = (x, sz, ex = {}) => txt(x, sz * s, Object.assign({ id: 'Текст', family: body, weight: st.bw, lh: 1.4, k: kfw(body), fill: p.ink }, ex));
    k.scr = (x, sz, ex = {}) => txt(x, sz * s * st.sm, Object.assign({ id: 'Підпис', family: script, weight: st.sw, italic: !!st.si, lh: 1, k: kfw(script), fill: p.accent }, ex));
    k.cap = (x, sz = 9, ex = {}) => k.body(x, sz, Object.assign({ id: 'Підпис', upper: true, ls: 0.14 * sz * s, weight: 700, lh: 1.3 }, ex));
    k.pill = (x, ex = {}) => {
      if (!x) return null;
      const fs = 10.5 * s, px = 17 * s, py = 9 * s, tb = txt(x, fs, { id: 'Текст кнопки', family: body, weight: 700, upper: !!st.up, ls: 0.03 * fs, lh: 1.2, k: kfw(body), nowrap: true, align: 'middle', fill: ex.fg || k.onA });
      const w = tb.iw() + px * 2, h = fs * 1.2 + py * 2, bd = ex.border === false || st.stroke < 3 ? 0 : 2 * s;
      return KB.fn(h, (x0, y0) => RC(t('Кнопка'), x0, y0, w, h, { fill: ex.bg || p.accent, rx: st.rad >= 18 ? h / 2 : st.rad * s, stroke: bd ? p.ink : undefined, sw: bd || undefined }) + tb.draw(x0, y0 + py, w, fs * 1.2), { fixW: w, fixH: h, shrink: 0, self: ex.self || 'start', rot: ex.rot });
    };
    k.tag = (x, ex = {}) => {
      if (!x) return null;
      const fs = 8.5 * s, px = 10 * s, py = 5 * s, tb = txt(x, fs, { id: 'Підпис', family: body, weight: 700, upper: true, ls: 0.08 * fs, lh: 1.2, k: kfw(body), nowrap: true, align: 'middle', fill: p.ink });
      const w = tb.iw() + px * 2, h = fs * 1.2 + py * 2;
      return KB.fn(h, (x0, y0) => RC(t('Плашка'), x0, y0, w, h, { fill: ex.bg, stroke: ex.bd || p.ink, sw: s, rx: st.rad >= 18 ? h / 2 : Math.min(st.rad, 4) * s }) + tb.draw(x0, y0 + py, w, fs * 1.2), { fixW: w, fixH: h, shrink: 0, self: 'start' });
    };
    k.phAt = (x, y, w, h, r) => kPhoto(c, x, y, w, h, r === undefined ? k.R() : r);
    k.ph = (o = {}) => KB.fn(o.h || 0, (x, y, w, h) => k.phAt(x, y, w, h, o.r), { flex: o.flex, fixW: o.w, fixH: o.h });
    k.deco = (x, y, d) => {
      const A1 = p.accent, nm = t('Орнамент'), cx = x + d / 2, cy = y + d / 2;
      switch (st.deco) {
        case 'star': return PG(nm, [[50, 0], [61, 39], [100, 50], [61, 61], [50, 100], [39, 61], [0, 50], [39, 39]].map(([a, b]) => [x + a * d / 100, y + b * d / 100]), { fill: A1 });
        case 'sun': return CI(nm, cx, cy, d * 0.07, { fill: A1 }) + [0.165, 0.295, 0.425].map(r => CI(nm, cx, cy, d * r, { stroke: A1, sw: d * 0.07 })).join('');
        case 'dot': case 'circle': return CI(nm, cx, cy, d / 2, { fill: A1 });
        case 'blob': return CI(nm, cx, cy, d / 2, { fill: mixC(A1, p.bg, 0.6) });
        case 'box': return RC(nm, x, y, d, d, { fill: A1, stroke: p.ink, sw: 2 * s, tf: `rotate(12 ${q(cx)} ${q(cy)})` });
        case 'ring': return CI(nm, cx, cy, d / 2 - s / 2, { stroke: A1, sw: s });
        case 'tape': return RC(t('Скотч'), x, y, d, d * 0.32, { fill: A1, op: 0.55, tf: `rotate(-14 ${q(cx)} ${q(y + d * 0.16)})` });
        case 'rule': return RC(nm, x, y, d, d * 0.06, { fill: A1 });
        default: return '';
      }
    };
    k.fit = (w, mw, mh) => Math.min(mw / (String(w).length * (kfw(head) * (st.up ? 1.18 : 1) + st.tr)), mh);
    k.col = (o, ...kids) => KB.col(c, Object.assign({ gap: 10 * s }, o), ...kids);
    k.row = (o, ...kids) => KB.row(c, Object.assign({ gap: 10 * s, align: 'center', jc: 'between' }, o), ...kids);
    k.full = (o, ...kids) => KB.col(c, Object.assign({ p: m }, o), ...kids).draw(0, 0, W, H);
    k.fullRow = (o, ...kids) => KB.row(c, Object.assign({ p: m }, o), ...kids).draw(0, 0, W, H);
    k.abs = (x, y, w, h, o, ...kids) => { const b = KB.col(c, o, ...kids); return b.draw(x, y, w, h === null ? b.h(w) : h); };
    return k;
  };

  // ---- the 22 layouts of the board, in its order (the generator picks layouts by that order)
  const KGEN = ['post', 'story', 'pin', 'poster', 'pres', 'yt', 'invite'];
  const K = {};
  K.heroPhoto = { n: 'Фото й текст', l: 'Photo + text', fm: KGEN, f(k) {
    const { s, t: T, W, H, m } = k;
    if (k.land) return k.phAt(W * 0.5, m, W * 0.5 - m, H - 2 * m) + k.abs(m, m, W * 0.5 - 2 * m, H - 2 * m, { jc: 'between' }, k.cap(T.kicker), k.col({ gap: 12 * s }, k.head(T.title, 34), k.body(T.sub, 12)), k.pill(T.cta));
    return k.full({ gap: 14 * s }, k.row({}, k.cap(T.kicker), k.body(T.handle, 9)), k.ph({ flex: 1 }), k.head(T.title, k.tall ? 34 : 28), k.row({ align: 'end' }, k.body(T.sub, 11, { flex: 1 }), k.pill(T.cta)));
  } };
  K.overlay = { n: 'Фото на все тло', l: 'Full-bleed photo', fm: KGEN, f(k) {
    const { s, t: T, W, H, m, p, st } = k, cw = k.land ? W * 0.48 : W - 2 * m;
    const card = k.col({ p: 18 * s, bg: p.bg, rx: k.R(), border: st.stroke >= 2 ? [st.stroke * s, p.ink] : undefined }, k.scr(T.kicker, 18), k.head(T.title, k.land ? 28 : 24), k.body(T.sub, 10.5), k.pill(T.cta));
    const ch = card.h(cw), tag = k.tag(T.handle, { bg: p.bg, bd: p.bg });
    return k.phAt(0, 0, W, H, 0) + tag.draw(m, m, tag.fixW, tag.fixH) + card.draw(m, H - m - ch, cw, ch);
  } };
  K.bigType = { n: 'Великий шрифт', l: 'Big type', fm: KGEN, f(k) {
    const { s, t: T, W, H, m, p, st } = k, N = k.land ? 2 : k.tall ? 4 : k.sq ? 2 : 3, fs = k.fit(T.big, W - 2 * m, (H - 2 * m) * 0.62 / N / st.lh), rows = [];
    for (let i = 0; i < N; i++) { const v = i % 3; rows.push(k.head(T.big, 0, { size: fs, nowrap: true, fill: v === 1 ? p.accent : v === 2 ? 'none' : p.ink, outline: v === 2 ? p.ink : undefined, ow: 1.4 * s })); }
    return k.deco(W - m - 46 * s, H * 0.15, 46 * s) + k.full({ jc: 'between' }, k.row({}, k.body(T.handle, 9), k.cap(T.date)), k.col({ gap: 0 }, ...rows), k.row({ align: 'end' }, k.body(T.sub, 11, { maxW: W * 0.55 }), k.pill(T.cta)));
  } };
  K.arch = { n: 'Фото-арка', l: 'Arch photo', fm: KGEN, f(k) {
    const { s, t: T, W, H, m, p } = k;
    if (k.land) { const ah = H - 2 * m, aw = ah * 0.72; return k.deco(m, m, 30 * s) + k.phAt(W - 2 * m - aw, m, aw, ah, { t: aw / 2, b: 0 }) + k.abs(m * 1.4, 0, W - aw - m * 5, H, { jc: 'center', gap: 12 * s }, k.scr(T.kicker, 22), k.head(T.title, 32), k.body(T.sub, 12), k.pill(T.cta)); }
    const ah = H * (k.tall ? 0.46 : k.sq ? 0.38 : 0.46), aw = Math.min(W * 0.62, ah * 0.76);
    return k.deco(m, m, 32 * s) + k.full({ align: 'center', jc: 'center', ta: 'middle', gap: 12 * s },
      k.ph({ w: aw, h: ah, r: { t: aw / 2, b: 4 * s } }),
      k.scr(T.kicker, k.sq ? 16 : 20, { mt: -24 * s, rot: -5, bg: p.bg, p: [3 * s, 10 * s] }),
      k.head(T.title, k.sq ? 22 : 28), k.body(T.sub, 11, { maxW: W * 0.72 }), k.sq ? null : k.cap(T.handle, 8.5, { mt: 4 * s, upper: false, ls: 0.04 * 8.5 * s }));
  } };
  K.frame = { n: 'Рамка', l: 'Frame', fm: KGEN, f(k) {
    const { s, t: T, W, H, m, p, st } = k, b = Math.max(1, st.stroke) * s, o1 = m * 0.55, o2 = o1 + 6 * s;
    const dia = KB.fn(8 * s, (x, y) => RC(t('Ромб'), x, y, 8 * s, 8 * s, { fill: p.accent, tf: `rotate(45 ${q(x + 4 * s)} ${q(y + 4 * s)})` }), { fixW: 8 * s, fixH: 8 * s });
    return RC(t('Рамка'), o1 + b / 2, o1 + b / 2, W - 2 * o1 - b, H - 2 * o1 - b, { stroke: p.accent, sw: b, rx: k.R(0.5) }) + RC(t('Внутрішня рамка'), o2 + 0.4 * s, o2 + 0.4 * s, W - 2 * o2 - 0.8 * s, H - 2 * o2 - 0.8 * s, { stroke: p.accent, sw: 0.8 * s, rx: k.R(0.4) }) +
      k.full({ align: 'center', jc: 'center', ta: 'middle', p: m * 1.7, gap: (k.tall ? 16 : 11) * s }, k.cap(T.kicker, k.land ? 10 : 9), k.head(T.title, k.land ? 36 : k.sq ? 26 : 32), dia, k.body(T.date, k.sq ? 12 : 14, { weight: 700 }), k.body(T.place, 10),
        k.sq ? null : k.body(T.cta, 9.5, { upper: true, ls: 0.14 * 9.5 * s, bb: [s, p.ink], p: [0, 0, 3 * s, 0], mt: 8 * s }));
  } };
  K.list = { n: 'Список порад', l: 'Tips list', fm: KGEN, f(k) {
    const { s, t: T, W, m, p } = k, n = k.land ? 4 : k.tall ? 5 : k.sq ? 3 : 4, line = [0.8 * s, p.ink, 0.3];
    const li = T.items.slice(0, n).map((it, i) => k.row({ align: 'baseline', jc: 'start', gap: 12 * s, bt: line, p: [(k.tall ? 14 : 9) * s, 0] }, k.head(String(i + 1).padStart(2, '0'), 15, { id: 'Номер', fill: p.accent, upper: false, tr: 0, nowrap: true }), k.body(it[0], k.tall ? 14 : 12, { id: 'Пункт', weight: 700, flex: 1 })));
    const list = k.col({ flex: 1, jc: 'center', gap: 0 }, ...li);
    if (k.land) return k.fullRow({ gap: m * 1.2, align: 'stretch' }, k.col({ fixW: (W - 2 * m) * 0.42, jc: 'between' }, k.tag(T.handle), k.head(T.title, 32), k.pill(T.cta)), list);
    return k.full({ gap: 12 * s }, k.tag(T.handle), k.head(T.title, k.tall ? 32 : 24), list, k.row({}, k.body(T.sub, 10, { flex: 1 }), k.pill(T.cta)));
  } };
  K.sale = { n: 'Знижка', l: 'Discount', fm: KGEN, f(k) {
    const { s, t: T, W, H, m, p, st } = k, D = k.land ? H * 0.7 : Math.min(W * 0.6, H * (k.sq ? 0.38 : 0.42));
    const lab = k.head(T.disc, 0, { id: 'Ціна', size: k.fit(T.disc, D * 0.74, D * 0.42), fill: k.onA, nowrap: true, upper: false, tr: 0, align: 'middle' });
    const badge = KB.fn(D, (x, y) => {
      const cx = x + D / 2, cy = y + D / 2, lh = lab.h(D);
      if (st.deco === 'star') { const pts = []; for (let i = 0; i < 32; i++) { const r = (i % 2 ? 0.41 : 0.5) * D, a = i / 32 * Math.PI * 2; pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); } return PG(t('Зірка'), pts, { fill: p.accent }) + lab.draw(x, cy - lh / 2, D, lh); }
      if (st.stroke >= 3) return `<g id="${esc(t('Значок'))}" transform="rotate(-6 ${q(cx)} ${q(cy)})">` + RC(t('Плашка'), x, y, D, D, { fill: p.accent, stroke: p.ink, sw: 2.5 * s }) + lab.draw(x, cy - lh / 2, D, lh) + '</g>';
      return CI(t('Коло'), cx, cy, D / 2, { fill: p.accent }) + lab.draw(x, cy - lh / 2, D, lh);
    }, { fixW: D, fixH: D, self: 'center' });
    if (k.land) return k.fullRow({ gap: m, align: 'center' }, k.col({ flex: 1, gap: 12 * s }, k.cap(T.kicker), k.head(T.title, 34), k.body(T.sub, 12), k.pill(T.cta)), badge);
    return k.full({ align: 'center', jc: 'between', ta: 'middle' }, k.cap(T.kicker), k.head(T.title, k.tall ? 34 : k.sq ? 22 : 28), badge, k.body(T.sub, 11, { maxW: W * 0.72 }), k.pill(T.cta, { self: 'center' }));
  } };
  K.quote = { n: 'Цитата', l: 'Quote', fm: KGEN, f(k) {
    const { s, t: T, W, m, p } = k;
    const mark = KB.fn(48 * s, (x, y) => TT(k.c, t('Лапки'), '“', x, y + 110 * s * 0.68, 110 * s, { family: 'DM Serif Display', fill: p.accent }).svg, { fixH: 48 * s });
    const bar = KB.fn(2 * s, (x, y) => RC(t('Лінія'), x, y, 36 * s, 2 * s, { fill: p.accent }), { fixW: 36 * s, fixH: 2 * s, self: 'start' });
    return k.deco(W - m - 40 * s, m, 40 * s) + k.full({ jc: 'center', gap: 14 * s, p: m * 1.4 }, mark, k.head(T.quote, k.land ? 28 : k.tall ? 28 : 20, { id: 'Цитата' }), bar, k.body(T.handle, 10, { weight: 700 }));
  } };
  K.collage = { n: 'Скрапбук-колаж', l: 'Scrapbook collage', fm: KGEN, f(k) {
    const { s, t: T, W, H, m, p } = k;
    // a photo print with a strip of tape, a little turned
    const fr = (x, y, w, h, r) => { const cx = x + w / 2, cy = y + h / 2;
      return `<g id="${esc(t('Картка'))}" transform="rotate(${r} ${q(cx)} ${q(cy)})">` + RC(t('Тінь'), x, y + 3 * s, w, h, { fill: '#000000', op: 0.1 }) + RC(t('Рамка'), x, y, w, h, { fill: '#FBFAF6' }) +
        kPhoto(k.c, x + 6 * s, y + 6 * s, w - 12 * s, h - 24 * s, 0) + RC(t('Скотч'), cx - 27 * s, y - 8 * s, 54 * s, 16 * s, { fill: p.accent, op: 0.55, tf: `rotate(${-r * 1.5} ${q(cx)} ${q(y)})` }) + '</g>'; };
    if (k.land) return fr(m, m * 1.1, W * 0.26, H * 0.62, -5) + fr(W * 0.24, H * 0.28, W * 0.24, H * 0.56, 4) + k.abs(W * 0.55, m, W * 0.45 - m, H - 2 * m, { jc: 'center', gap: 12 * s }, k.scr(T.title, 40, { id: 'Заголовок', fill: p.ink }), k.body(T.sub, 12), k.pill(T.cta));
    const z = k.sq ? 0.56 : 0.5;
    return fr(W * 0.07, H * 0.06, W * 0.52, H * z * 0.68, -5) + fr(W * 0.42, H * z * 0.28, W * 0.5, H * z * 0.62, 4) +
      k.abs(m, H * z + 12 * s, W - 2 * m, null, { gap: 10 * s }, k.scr(T.title, k.tall ? 46 : k.sq ? 30 : 38, { id: 'Заголовок', fill: p.ink }), k.body(T.sub, 11), k.sq ? null : k.pill(T.cta, { rot: -2 })) + k.deco(W - m - 34 * s, H - m - 34 * s, 34 * s);
  } };
  K.magazine = { n: 'Обкладинка журналу', l: 'Magazine cover', fm: ['story', 'pin', 'poster'], f(k) {
    const { s, t: T, W, H, m, p } = k, fs = k.fit(T.big, W - 2 * m, H * 0.17);
    return k.full({ gap: 8 * s }, k.head(T.big, 0, { size: fs, align: 'middle', lh: 0.84, nowrap: true }), k.row({ bt: [s, p.ink], bb: [s, p.ink], p: [4 * s, 0] }, k.cap('Issue ' + (k.id % 12 + 1) + ' · Fall 2026', 7.5), k.body(T.handle, 7.5)), k.ph({ flex: 1, r: 0 }),
      k.row({ align: 'end', mt: 6 * s }, k.col({ gap: 6 * s, flex: 1 }, k.head(T.title, 24), k.body(T.sub, 10)), k.scr(T.disc, 26, { nowrap: true })));
  } };
  K.swiss = { n: 'Швейцарська сітка', l: 'Swiss grid', fm: KGEN, f(k) {
    const { s, t: T, W, H, m, p } = k, mx = W / 2, my = H * (k.land ? 0.5 : 0.48), hl = { stroke: p.ink, sw: 0.8 * s, op: 0.22, cap: 'butt' };
    return LN(t('Сітка'), mx, 0, mx, H, hl) + LN(t('Сітка'), 0, my, W, my, hl) + k.phAt(mx + 10 * s, m, W - mx - 10 * s - m, my - m - 10 * s) +
      k.abs(m, m, mx - m - 14 * s, my - m - 10 * s, { jc: 'between' }, k.head(String(k.id % 9 + 1).padStart(2, '0'), k.land ? 60 : 54, { id: 'Номер', fill: p.accent, tr: -0.04 }), k.col({ gap: 2 * s }, k.body(T.kicker, 9.5, { weight: 700 }), k.body(T.date, 9.5))) +
      k.deco(mx - 12 * s, my - 12 * s, 24 * s) +
      k.abs(m, my + 14 * s, W - 2 * m, H - my - 14 * s - m, { jc: 'between', gap: 10 * s }, k.head(T.title, k.land ? 36 : k.tall ? 40 : 28), k.row({ align: 'end' }, k.body(T.sub, 10, { maxW: W * 0.5 }), k.pill(T.cta)));
  } };
  K.split = { n: 'Кольоровий блок', l: 'Color block', fm: KGEN, f(k) {
    const { s, t: T, W, H, m, p } = k, oc = k.onA;
    const block = (x, y, w, h) => RC(t('Плашка'), x, y, w, h, { fill: p.accent }) + k.abs(x, y, w, h, { p: m, jc: 'between', gap: 12 * s }, k.cap(T.kicker, 9, { fill: oc }), k.col({ gap: 10 * s }, k.head(T.title, k.land ? 32 : k.tall ? 34 : 26, { fill: oc }), k.body(T.sub, 11, { fill: oc })), k.pill(T.cta, { bg: p.bg, fg: p.ink, border: false }));
    if (k.land) return block(0, 0, W / 2, H) + k.phAt(W / 2, 0, W / 2, H, 0);
    const bh = k.sq ? 0.56 : 0.52;
    return k.phAt(0, H * bh, W, H * (1 - bh), 0) + block(0, 0, W, H * bh);
  } };
  K.thisThat = { n: 'Це чи те', l: 'This or that', fm: KGEN, f(k) {
    const { s, t: T, p, st } = k;
    const half = lab => k.col({ flex: 1, gap: 8 * s }, k.ph({ flex: 1 }), k.cap(lab, k.land ? 13 : 11, { align: 'middle' }));
    const two = KB.row(k.c, { gap: 10 * s, align: 'stretch' }, half(T.a || 'This'), half(T.b || 'That'));
    const pair = KB.fn(0, (x, y, w, h) => { const cx = x + w / 2, cy = y + h * 0.45;
      return two.draw(x, y, w, h) + `<g id="${esc(t('Значок'))}" transform="rotate(-8 ${q(cx)} ${q(cy)})">` + CI(t('Коло'), cx, cy, 23 * s, { fill: p.accent }) + TT(k.c, t('Текст'), 'or', cx, cy + 15 * s * 0.32, 15 * s, { family: k.fh, anchor: 'middle', fill: k.onA, weight: st.hw }).svg + '</g>'; }, { flex: 1 });
    return k.full({ gap: 14 * s, ta: 'middle' }, k.head(T.title, k.land ? 34 : k.tall ? 34 : 26), pair, k.body(T.sub, 10.5));
  } };
  K.moodboard = { n: 'Мудборд', l: 'Moodboard', fm: KGEN, f(k) {
    const { s, t: T, W, m, p } = k;
    // two columns, rows 1fr 1fr 0.7fr: three photos and the palette
    const grid = KB.fn(0, (x, y, w, h) => {
      const g = 8 * s, cw = (w - g) / 2, r1 = (h - 2 * g) / 2.7, r3 = r1 * 0.7, sy = y + 2 * (r1 + g), d = 22 * s, gx = 6 * s, tw = 3 * d + 2 * gx;
      return k.phAt(x, y, cw, 2 * r1 + g) + k.phAt(x + cw + g, y, cw, r1) + k.phAt(x + cw + g, y + r1 + g, cw, r1 + g + r3) + RC(t('Палітра'), x, sy, cw, r3, { fill: p.soft, rx: k.R() }) +
        [p.ink, p.accent, p.bg].map((col, i) => CI(t('Колір'), x + (cw - tw) / 2 + d / 2 + i * (d + gx), sy + r3 / 2, d / 2, { fill: col, stroke: mixC(p.ink, p.soft, 0.8), sw: s })).join('');
    }, { flex: 1 });
    if (k.land) return k.fullRow({ gap: m, align: 'stretch' }, k.col({ fixW: (W - 2 * m) * 0.36, jc: 'between' }, k.cap(T.handle), k.col({}, k.head(T.title, 32), k.body(T.sub, 12))), grid);
    return k.full({ gap: 12 * s }, k.row({}, k.cap(T.kicker, 8.5), k.body(T.handle, 9)), k.head(T.title, k.tall ? 32 : 24), grid, k.sq ? null : k.scr(T.sub, 18, { align: 'middle' }));
  } };
  K.stats = { n: 'Великі цифри', l: 'Big numbers', fm: KGEN, f(k) {
    const { s, t: T, W, p } = k, rowy = k.land || k.sq;
    const cells = T.stats.map((x, i) => k.col({ gap: 4 * s, bt: [1.5 * s, p.ink], p: [8 * s, 0, 0, 0], flex: 1 }, k.head(x[0], k.land ? 40 : k.sq ? 24 : 36, { id: 'Номер', fill: i === 0 ? p.accent : p.ink, nowrap: true, upper: false, tr: -0.02 }), k.body(x[1], 10)));
    const grid = rowy ? KB.row(k.c, { gap: 14 * s, align: 'stretch' }, ...cells) : KB.col(k.c, { gap: 14 * s }, ...cells);
    return k.full({ jc: 'between' }, k.col({}, k.cap(T.kicker), k.head(T.title, k.land ? 34 : 28, { maxW: k.land ? W * 0.6 : W })), grid, k.row({}, k.body(T.handle, 9), k.pill(T.cta)));
  } };
  K.ticket = { n: 'Квиток на подію', l: 'Event ticket', fm: KGEN, f(k) {
    const { s, t: T, W, H, m, p } = k, oc = k.onA, tw = W - 2 * m, th = H - 2 * m;
    const main = k.col({ flex: 1, jc: 'between', p: 20 * s, gap: 12 * s }, k.row({}, k.cap(T.kicker, 9, { fill: oc }), k.cap('No. 0' + (k.id % 90 + 10), 9, { fill: oc })), k.head(T.title, k.land ? 40 : k.tall ? 44 : 30, { fill: oc }), k.col({ gap: 3 * s }, k.body(T.date, 13, { fill: oc, weight: 700 }), k.body(T.place, 10, { fill: oc })));
    const dash = [1.2 * s, oc, 1, `${q(3.6 * s)} ${q(2.4 * s)}`];
    const stub = k.col(Object.assign({ align: 'center', jc: 'center', ta: 'middle', gap: 4 * s, p: 10 * s }, k.land ? { fixW: tw * 0.26, bl: dash } : { fixH: th * 0.2, bt: dash }), k.cap('Admit one', 9, { fill: oc }), k.head(T.cta, k.sq ? 14 : 16, { fill: oc }));
    const body = k.land ? KB.row(k.c, { align: 'stretch' }, main, stub) : KB.col(k.c, {}, main, stub);
    const nx = k.land ? [[m + tw * 0.74, m], [m + tw * 0.74, m + th]] : [[m, m + th * 0.8], [m + tw, m + th * 0.8]];
    return RC(t('Квиток'), m, m, tw, th, { fill: p.accent, rx: k.R(0.5) }) + body.draw(m, m, tw, th) + nx.map(([x, y]) => CI(t('Виріз'), x, y, 10 * s, { fill: p.bg })).join('') + k.deco(W - m - 30 * s, m * 0.4, 30 * s);
  } };
  K.cardA = { n: 'Візитка зі смугою', l: 'Card with stripe', fm: ['card'], f(k) {
    const { s, t: T, W, H, m, p } = k, sw = W * 0.3;
    return RC(t('Смуга'), W - sw, 0, sw, H, { fill: p.accent }) + k.abs(W - sw, 0, sw, H, { align: 'center', jc: 'center', ta: 'middle' }, k.head(KD.mono(T.person), 56, { id: 'Монограма', fill: k.onA, upper: true, nowrap: true })) +
      k.abs(m, m, W - sw - 2 * m, H - 2 * m, { jc: 'between' }, k.col({ gap: 4 * s }, k.head(T.person, 32), k.cap(T.role, 12)), k.col({ gap: s }, k.body('+1 (212) 555-0147', 12), k.body(T.handle, 12), k.body(T.place, 12)));
  } };
  K.cardB = { n: 'Візитка з монограмою', l: 'Card with monogram', fm: ['card'], f(k) {
    const { s, t: T, p } = k, D = 110 * s, lab = k.head(KD.mono(T.person), 46, { id: 'Монограма', fill: p.accent, upper: true, nowrap: true, align: 'middle' });
    const ring = KB.fn(D, (x, y) => { const lh = lab.h(D); return CI(t('Кільце'), x + D / 2, y + D / 2, D / 2 - 0.75 * s, { stroke: p.accent, sw: 1.5 * s }) + lab.draw(x, y + (D - lh) / 2, D, lh); }, { fixW: D, fixH: D });
    return k.full({ align: 'center', jc: 'center', ta: 'middle', gap: 10 * s }, ring, k.head(T.name, 30), k.cap(T.role, 11), k.body(T.handle, 11));
  } };
  const kSec = (k, ti, ...kids) => k.col({ gap: 5 * k.s }, k.cap(ti, 7.5, { fill: k.p.accent }), ...kids);
  const kJob = (k, e, mb) => k.col({ gap: k.s, mb: mb * k.s }, k.body(e[0], 8.5, { weight: 700 }), k.body(e[1], 7.2), k.body(e[2], 7.5));
  K.resumeA = { n: 'Резюме з бічною панеллю', l: 'Resume with sidebar', fm: ['resume'], f(k) {
    const { s, t: T, W, H, p } = k, sw = W * 0.36, r = KD.resData(T), pad = 18 * s, pw = sw - 2 * pad;
    return RC(t('Смуга'), 0, 0, sw, H, { fill: p.soft }) +
      k.abs(pad, pad, pw, H - 2 * pad, { gap: 16 * s }, k.ph({ w: pw, h: pw, r: pw / 2 }), kSec(k, 'Contact', k.body('+1 212 555 0147', 7.5), k.body(T.handle, 7.5), k.body(T.place, 7.5)), kSec(k, 'Skills', ...T.skills.map(x => k.body('— ' + x, 7.5)))) +
      k.abs(sw + pad, pad * 1.4, W - sw - 2 * pad, H - 2 * pad, { gap: 14 * s }, k.col({ gap: 4 * s }, k.head(T.person, 22), k.cap(T.role, 8, { fill: p.accent })), k.body(r.sum, 7.8), kSec(k, 'Experience', ...r.exp.map(e => kJob(k, e, 4))), kSec(k, 'Education', k.body(r.edu[0], 8.5, { weight: 700 }), k.body(r.edu[1], 7.2)));
  } };
  K.resumeB = { n: 'Класичне резюме', l: 'Classic resume', fm: ['resume'], f(k) {
    const { s, t: T, p } = k, r = KD.resData(T);
    const rule = KB.fn(1.2 * s, (x, y, w) => RC(t('Лінія'), x, y, w, 1.2 * s, { fill: p.accent }), { fixH: 1.2 * s });
    const left = kSec(k, 'Experience', ...r.exp.map(e => kJob(k, e, 6))), right = k.col({ gap: 14 * s }, kSec(k, 'Education', k.body(r.edu[0], 8.5, { weight: 700 }), k.body(r.edu[1], 7.2)), kSec(k, 'Skills', ...T.skills.map(x => k.body(x, 7.5))));
    left.flex = 1.4; right.flex = 1;
    return k.full({ gap: 14 * s, p: 30 * s }, k.col({ align: 'center', ta: 'middle', gap: 5 * s }, k.head(T.person, 28), k.cap(T.role, 8.5, { fill: p.accent }), k.body('+1 212 555 0147 · ' + T.handle + ' · ' + T.place, 7.2)), rule, k.body(r.sum, 8, { align: 'middle' }),
      KB.row(k.c, { gap: 18 * s, align: 'start', flex: 1 }, left, right));
  } };
  K.menuA = { n: 'Меню-список', l: 'Menu list', fm: ['menu'], f(k) {
    const { s, t: T, W, H, m, p } = k;
    const pr = it => k.row({ align: 'baseline', jc: 'start', gap: 6 * s }, k.body(it[0], 11, { id: 'Пункт', weight: 700, maxW: (W - 68 * s) * 0.7 }),
      KB.fn(s, (x, y, w) => LN(t('Пунктир'), x + s, y + s / 2, x + w - s, y + s / 2, { stroke: p.ink, sw: s, op: 0.5, dash: `0.01 ${q(2 * s)}`, cap: 'round' }), { flex: 1, fixH: s }),
      k.body(it[1] || '', 11, { id: 'Ціна', weight: 700, nowrap: true }));
    return k.deco(m * 0.6, m * 0.6, 26 * s) + k.deco(W - m * 0.6 - 26 * s, H - m * 0.6 - 26 * s, 26 * s) +
      k.full({ gap: 12 * s, p: 34 * s }, k.col({ align: 'center', ta: 'middle', gap: 6 * s }, k.cap(T.kicker, 8.5), k.head(T.name, 28), k.scr(T.menuWord, 24)), k.col({ jc: 'center', gap: 14 * s, flex: 1 }, ...T.items.map(pr)), k.body(T.place + ' · ' + T.handle, 8.5, { align: 'middle' }));
  } };
  K.menuB = { n: 'Меню з фото', l: 'Menu with photo', fm: ['menu'], f(k) {
    const { s, t: T, W, H, m, p } = k, it4 = T.items.slice(0, 4), rows = [];
    const cell = it => k.col({ gap: 2 * s, bt: [s, p.ink], p: [6 * s, 0, 0, 0], flex: 1 }, k.body(it[0], 10, { id: 'Пункт', weight: 700 }), k.body(it[1] || '', 12, { id: 'Ціна' }));
    for (let i = 0; i < it4.length; i += 2) rows.push(KB.row(k.c, { gap: 16 * s, align: 'start' }, cell(it4[i]), it4[i + 1] ? cell(it4[i + 1]) : KB.fn(0, () => '', { flex: 1 })));
    return k.phAt(0, 0, W, H * 0.34, 0) + k.abs(m, H * 0.34 + m * 0.8, W - 2 * m, H * 0.66 - m * 1.8, { gap: 12 * s }, k.row({ align: 'end' }, k.head(T.menuWord, 30), k.cap(T.name, 8)), k.col({ flex: 1, jc: 'center', gap: 14 * s }, ...rows), k.row({}, k.body(T.place, 8), k.body(T.handle, 8)));
  } };
  // layouts with richer artwork are marked «Premium», as elsewhere in the library (they are free in VIBSma)
  const KPREM = new Set(['magazine', 'collage', 'moodboard', 'ticket', 'swiss', 'stats', 'arch']);

  // the board's data and its seeded generator, verbatim (L: the formats of each layout, in the board's order)
  const KD = (L => {
    const STYLES={
     minimal:{l:'Minimal beige',kw:'minimal aesthetic neutral clean nude',head:'"Cormorant Garamond",serif',hw:500,up:0,tr:-0.01,lh:1,mul:1.25,wf:0.46,body:'Manrope,sans-serif',bw:500,script:'"Cormorant Garamond",serif',sw:500,si:1,sm:1.2,rad:0,stroke:1,deco:'none',
      pals:[{bg:'#efe8de',ink:'#2b2622',accent:'#a1846a',soft:'#e0d4c3'},{bg:'#f4f1ec',ink:'#1f1f1e',accent:'#8c8577',soft:'#e4dfd6'},{bg:'#e9ebe3',ink:'#2f3a2f',accent:'#6f7d5c',soft:'#d6dbc9'},{bg:'#d9c8b4',ink:'#3b2a20',accent:'#5e4433',soft:'#cbb79f'}]},
     y2k:{l:'Y2K neon',kw:'y2k neon chrome rave 2000s',head:'Unbounded,sans-serif',hw:800,up:1,tr:-0.02,lh:0.95,mul:0.8,wf:0.9,body:'"Space Grotesk",sans-serif',bw:500,script:'Unbounded,sans-serif',sw:500,si:0,sm:0.6,rad:999,stroke:2,deco:'star',
      pals:[{bg:'#0d0d12',ink:'#f2f2f2',accent:'#c6ff3d',soft:'#26262f'},{bg:'#c3c9ff',ink:'#141414',accent:'#ff3fa4',soft:'#aab2f5'},{bg:'#1b0b3a',ink:'#ffffff',accent:'#38f2ff',soft:'#2e1a5a'},{bg:'#f1f1f1',ink:'#0f0f0f',accent:'#3d5cff',soft:'#dcdcdc'}]},
     brutal:{l:'Brutal bold',kw:'brutalist bold big type loud',head:'Anton,sans-serif',hw:400,up:1,tr:0,lh:0.92,mul:1.25,wf:0.46,body:'"Space Mono",monospace',bw:400,script:'Anton,sans-serif',sw:400,si:0,sm:0.9,rad:0,stroke:3,deco:'box',
      pals:[{bg:'#ff4a1c',ink:'#111111',accent:'#f2efe6',soft:'#e8431a'},{bg:'#f2efe6',ink:'#111111',accent:'#ff4a1c',soft:'#dedad0'},{bg:'#1a1a1a',ink:'#e8ff3a',accent:'#e8ff3a',soft:'#2c2c2c'},{bg:'#2340ff',ink:'#ffffff',accent:'#ffe14a',soft:'#1b33d6'}]},
     retro:{l:'Retro 70s',kw:'retro 70s groovy vintage seventies',head:'Shrikhand,cursive',hw:400,up:0,tr:0,lh:1.02,mul:0.95,wf:0.66,body:'"DM Sans",sans-serif',bw:500,script:'Shrikhand,cursive',sw:400,si:0,sm:0.75,rad:18,stroke:2,deco:'sun',
      pals:[{bg:'#f3e3c3',ink:'#5a2e1a',accent:'#e2711d',soft:'#e8d2a8'},{bg:'#2f4b3a',ink:'#f3e3c3',accent:'#e8a33d',soft:'#3c5c48'},{bg:'#e9c46a',ink:'#3d2314',accent:'#c8423f',soft:'#dcb252'},{bg:'#7a2e1f',ink:'#f6e7cb',accent:'#f2a541',soft:'#8c3a29'}]},
     editorial:{l:'Editorial',kw:'editorial magazine vogue serif',head:'"DM Serif Display",serif',hw:400,up:0,tr:-0.01,lh:1,mul:1.05,wf:0.52,body:'Manrope,sans-serif',bw:500,script:'"DM Serif Display",serif',sw:400,si:1,sm:1,rad:0,stroke:1,deco:'rule',
      pals:[{bg:'#f5f3ee',ink:'#111111',accent:'#c1121f',soft:'#dfdace'},{bg:'#121212',ink:'#f5f3ee',accent:'#d9c39a',soft:'#262626'},{bg:'#e8e4da',ink:'#1a1a2e',accent:'#1a1a2e',soft:'#d4cdbd'},{bg:'#fbfaf7',ink:'#222222',accent:'#4e6a46',soft:'#e9e5dc'}]},
     pastel:{l:'Pastel soft',kw:'pastel soft girl cute kawaii',head:'Fredoka,sans-serif',hw:600,up:0,tr:-0.01,lh:1.05,mul:0.95,wf:0.56,body:'"DM Sans",sans-serif',bw:500,script:'Caveat,cursive',sw:700,si:0,sm:1.25,rad:26,stroke:0,deco:'blob',
      pals:[{bg:'#ffe3ec',ink:'#5b3a4a',accent:'#e86f98',soft:'#ffd0de'},{bg:'#e3eeff',ink:'#2f3d58',accent:'#5f8de0',soft:'#cfdffa'},{bg:'#efe6ff',ink:'#45385e',accent:'#8e6ee0',soft:'#e0d2fb'},{bg:'#e3f5e9',ink:'#2f4f3e',accent:'#3f9e68',soft:'#cdebd7'}]},
     swiss:{l:'Swiss grid',kw:'swiss grid modernist helvetica',head:'Archivo,sans-serif',hw:900,up:0,tr:-0.035,lh:0.92,mul:0.98,wf:0.62,body:'Archivo,sans-serif',bw:500,script:'Archivo,sans-serif',sw:500,si:0,sm:0.65,rad:0,stroke:1,deco:'circle',
      pals:[{bg:'#f0eee9',ink:'#111111',accent:'#e30613',soft:'#dcd9d1'},{bg:'#121212',ink:'#f0eee9',accent:'#ff5a1f',soft:'#2a2a2a'},{bg:'#ffd23f',ink:'#111111',accent:'#111111',soft:'#efc22e'},{bg:'#e8eef2',ink:'#0b2545',accent:'#0f7f78',soft:'#d2dde5'}]},
     collage:{l:'Collage',kw:'collage scrapbook journal tape paper',head:'Caveat,cursive',hw:700,up:0,tr:0,lh:0.95,mul:1.4,wf:0.4,body:'"Space Mono",monospace',bw:400,script:'Caveat,cursive',sw:700,si:0,sm:1.2,rad:2,stroke:0,deco:'tape',
      pals:[{bg:'#f1ece1',ink:'#1d1d1d',accent:'#e94f37',soft:'#e2dccd'},{bg:'#d8e2dc',ink:'#222222',accent:'#e0577a',soft:'#c6d3cb'},{bg:'#2b2b2b',ink:'#f1ece1',accent:'#f7d046',soft:'#3b3b3b'},{bg:'#f7d6bf',ink:'#3a2a1a',accent:'#3d5a80',soft:'#ecc4a8'}]},
     luxe:{l:'Dark luxe',kw:'luxury dark gold elegant premium',head:'"Bodoni Moda",serif',hw:500,up:1,tr:0.08,lh:1.1,mul:0.85,wf:0.78,body:'"Tenor Sans",sans-serif',bw:400,script:'"Bodoni Moda",serif',sw:500,si:1,sm:1,rad:0,stroke:1,deco:'ring',
      pals:[{bg:'#0f0f0f',ink:'#e9dcc0',accent:'#c9a45c',soft:'#1f1e1c'},{bg:'#14213d',ink:'#f1e9d8',accent:'#d4af37',soft:'#1f2e52'},{bg:'#2a0f14',ink:'#f3e6d8',accent:'#c99a6b',soft:'#3a1820'},{bg:'#0d1f1a',ink:'#efe6d2',accent:'#bfa36f',soft:'#18342c'}]},
     boho:{l:'Boho organic',kw:'boho organic earthy terracotta natural',head:'Forum,serif',hw:400,up:1,tr:0.05,lh:1.05,mul:1,wf:0.62,body:'"DM Sans",sans-serif',bw:500,script:'Caveat,cursive',sw:600,si:0,sm:1.25,rad:0,stroke:1,deco:'dot',
      pals:[{bg:'#efe2d0',ink:'#5c3d2e',accent:'#b8603e',soft:'#e2cfb6'},{bg:'#c98b6b',ink:'#fff7ee',accent:'#5c3322',soft:'#bb7b5c'},{bg:'#e7dfcf',ink:'#3f4a3c',accent:'#8a6a3f',soft:'#d8cdb6'},{bg:'#f4e9e1',ink:'#6b4a3a',accent:'#b97f4c',soft:'#ead7c9'}]}
    };
    const SKEYS=Object.keys(STYLES);
    const DSTATS=[['10k+','happy clients'],['4.9','average rating'],['24/7','support']];
    const NICHES={
     beauty:{label:'Beauty & nails',kw:'nails manicure salon beauty spa lash makeup',kicker:'Nail studio',title:'Soft nails season',sub:'Booking open for October',cta:'Book now',big:'Glow',event:'Studio opening party',date:'Oct 18 · 12:00',place:'14 Rose St, Brooklyn',items:[['Classic manicure','$35'],['Gel polish','$28'],['Pedicure','$45'],['Nail art','from $5'],['Spa hand care','$22']],photo:'photo: nails',handle:'@lacquer.studio',quote:'Well-kept hands are the best accessory',disc:'-20%',name:'Lacquer Studio',person:'Ella Moore',role:'Nail artist',skills:['Gel & acrylic','Nude designs','Hand care','Hygiene'],menuWord:'Price list'},
     food:{label:'Cafe & food',kw:'coffee cafe restaurant food menu bakery brunch',kicker:'Coffee house',title:'Autumn menu is here',sub:'Pumpkin latte and fresh pastries daily',cta:'Order now',big:'Brew',event:'Coffee tasting night',date:'Oct 20 · 7 pm',place:'3 Mill Lane, Portland',items:[['Pumpkin latte','$5.5'],['Flat white','$4.5'],['Almond croissant','$4'],['Ricotta pancakes','$9'],['Oat matcha','$6']],photo:'photo: coffee / dish',handle:'@grain.coffee',quote:'Coffee first, everything else later',disc:'-15%',name:'Grain Coffee',person:'Leo Martin',role:'Head barista',skills:['Espresso','Filter brewing','Latte art','Roasting'],menuWord:'Menu'},
     fitness:{label:'Fitness',kw:'gym fitness workout yoga pilates sport training',kicker:'Fitness studio',title:'Train with me',sub:'Your first class is on us',cta:'Start today',big:'Move',event:'Weekend 5K run',date:'Oct 26 · 9 am',place:'Riverside Park',items:[['Personal training','$60'],['Monthly pass','$120'],['Group class','$18'],['Stretch & mobility','$22'],['Meal plan','$80']],photo:'photo: workout',handle:'@move.gym',quote:'Discipline is a form of self-love',disc:'-30%',name:'Move Gym',person:'Max Carter',role:'Personal trainer',skills:['Strength','Mobility','HIIT','Nutrition'],menuWord:'Pricing',stats:[['−12 kg','in 90 days'],['5×','workouts a week'],['0','crash diets']]},
     fashion:{label:'Fashion',kw:'fashion outfit clothing shop style ootd lookbook',kicker:'New in',title:'The autumn capsule',sub:'A limited linen & wool edit',cta:'Shop the look',big:'Style',event:'Collection launch',date:'Oct 24 · 7 pm',place:'Fabric Showroom, SoHo',items:[['Camel trench','$189'],['Oversized knit','$98'],['Shirt dress','$120'],['Leather tote','$210'],['Wool scarf','$45']],photo:'photo: outfit',handle:'@fabric.label',quote:'Style is saying who you are without speaking',disc:'-40%',name:'Fabric Label',person:'Sofia Hayes',role:'Fashion stylist',skills:['Capsule wardrobes','Personal shopping','Shoots','Trend research'],menuWord:'Lookbook'},
     realty:{label:'Real estate',kw:'real estate home house apartment realtor property interior',kicker:'Just listed',title:'Your dream home',sub:'2 bed · 1,200 sq ft · city views',cta:'Book a viewing',big:'Home',event:'Open house',date:'Sat, Oct 19 · 11 am',place:'48 Linden Ave',items:[['Studio, 450 sq ft','$320k'],['1 bed, 700 sq ft','$410k'],['2 bed, 1,200 sq ft','$560k'],['Penthouse','$1.2M'],['Parking spot','$25k']],photo:'photo: interior',handle:'@nest.realty',quote:'Home is the place you always want to return to',disc:'SOLD',name:'Nest Realty',person:'Ian Brooks',role:'Real estate agent',skills:['Negotiation','Valuation','Staging','Mortgages'],menuWord:'Listings',stats:[['120+','homes sold'],['18 days','average sale'],['98%','asking price']]},
     edu:{label:'Education',kw:'education course school study learn class teacher webinar',kicker:'Online school',title:'English from zero',sub:'Live classes in small groups',cta:'Enroll now',big:'Learn',event:'Free webinar',date:'Oct 28 · 6:30 pm',place:'Online · Zoom',items:[['Starter course','$120'],['Speaking club','$15'],['1:1 lesson','$30'],['IELTS prep','$240'],['Trial lesson','Free']],photo:'photo: study',handle:'@word.school',quote:'It is never too late to learn',disc:'-25%',name:'Word School',person:'Maria Lane',role:'English teacher',skills:['IELTS','Conversation','Curriculum','Kids & adults'],menuWord:'Courses',stats:[['3,400','students'],['92%','pass IELTS'],['6','levels']]},
     wedding:{label:'Weddings & events',kw:'wedding invitation party birthday celebration bridal event shower',kicker:'Together with their families',title:'Anna & Tom',sub:'request the pleasure of your company',cta:'RSVP',big:'Love',event:'Anna & Tom',date:'June 14, 2027',place:'Linden Grove Estate',items:[['Guests arrive','3:00'],['Ceremony','4:00'],['Dinner','5:30'],['First dance','7:00'],['Cake','9:00']],photo:'photo: couple',handle:'#annaandtom',quote:'Love is when home becomes a person',disc:'Yes!',name:'Anna & Tom',person:'Anna Grey',role:'Wedding planner',skills:['Venues','Budgets','Vendors','Day-of timing'],menuWord:'Order of the day'},
     biz:{label:'Business & SaaS',kw:'business saas startup corporate company marketing pitch deck report',kicker:'Product launch',title:'Grow together',sub:'Automate busywork in 15 minutes',cta:'Try it free',big:'Grow',event:'Grow Summit 2026',date:'Oct 30 · 10 am',place:'Pier 27, San Francisco',items:[['Starter','$9/mo'],['Team','$29/mo'],['Business','$79/mo'],['Integrations','Included'],['Support 24/7','Included']],photo:'photo: team / product',handle:'@growapp',quote:'The best time to start is today',disc:'-50%',name:'Grow',person:'David Kim',role:'Product manager',skills:['Strategy','Analytics','Roadmaps','Launches'],menuWord:'Pricing',stats:[['+48%','more qualified leads'],['15 min','average setup'],['2,000+','teams on board']]},
     travel:{label:'Travel',kw:'travel trip vacation tour holiday adventure guide',kicker:'Travel guide',title:'Alps in autumn',sub:'3-day guided trip with transfers',cta:'Book trip',big:'Roam',event:'Summit hike',date:'Oct 25–27',place:'Chamonix, France',items:[['Lisbon weekend','$420'],['Swiss Alps','$890'],['Amalfi coast','$760'],['Iceland ring road','$1,150'],['Kyoto in fall','$1,340']],photo:'photo: landscape',handle:'@wander.trips',quote:'Collect moments, not things',disc:'-20%',name:'Wander Trips',person:'Iris Cole',role:'Travel manager',skills:['Itineraries','Group tours','Visas','Budgeting'],menuWord:'Trips'},
     quotes:{label:'Quotes',kw:'quote motivation inspiration affirmation self care mindset',kicker:'Daily reminder',title:'Slow is still moving',sub:'Save this for later',cta:'Save',big:'Breathe',event:'Morning meditation',date:'Sundays · 8 am',place:'Central Park',items:[['Drink water first'],['Walk without your phone'],['Write 3 gratitudes'],['Sleep before 11'],['Say no without explaining']],photo:'photo: mood',handle:'@quiet.daily',quote:'You don’t have to see the whole staircase, just take the first step',disc:'365',name:'Quiet',person:'Kate Reed',role:'Life coach',skills:['Habits','Mindfulness','Journaling','Goals'],menuWord:'Rituals'},
     sale:{label:'Sales & promo',kw:'sale discount black friday promo deal offer shop cyber',kicker:'Online store',title:'Black Friday',sub:'Everything on sale until Sunday',cta:'Shop now',big:'SALE',event:'Late night shopping',date:'Nov 29 · 8 pm',place:'Downtown Mall',items:[['Headphones','$79'],['Smart watch','$149'],['Speaker','$49'],['Power bank','$29'],['Phone case','$12']],photo:'photo: product',handle:'@cart.shop',quote:'The best buy is the one that makes you smile every day',disc:'-70%',name:'Cart Shop',person:'Owen Park',role:'Marketing lead',skills:['Campaigns','CRM','Promo','Analytics'],menuWord:'Best sellers'}
    };
    const NKEYS=Object.keys(NICHES);
    const it1=a=>a.map(x=>[x]);
    const T=[
     ['post','arch','boho',0,'beauty',{kicker:'Lacquer Studio'}],
     ['post','bigType','y2k',0,'fitness',{sub:'New HIIT classes every Tuesday & Friday',cta:'Join'}],
     ['post','quote','minimal',0,'quotes',{quote:'Slow mornings are a form of self-respect'}],
     ['post','sale','brutal',0,'sale',{}],
     ['post','list','pastel',0,'edu',{title:'5 study habits that actually work',items:it1(['Plan your week on Sunday','Study in 25-minute sprints','Teach it to a friend','Review, don’t reread'])}],
     ['post','split','editorial',1,'fashion',{}],
     ['post','swiss','swiss',0,'biz',{title:'Q3 results are in',sub:'+48% revenue, 2k new teams',kicker:'Quarterly update',date:'Q3 · 2026',cta:'Read report'}],
     ['post','heroPhoto','minimal',2,'food',{title:'Slow Sunday brunch',sub:'Every weekend, 9 am – 2 pm',cta:'Reserve'}],
     ['post','collage','collage',0,'travel',{title:'Lisbon in 3 days',sub:'Tram 28, pastel de nata and sunsets'}],
     ['post','overlay','luxe',0,'realty',{title:'Penthouse on Fifth',sub:'3 bed · 2,400 sq ft · skyline view'}],
     ['post','thisThat','pastel',1,'fashion',{title:'This or that?',sub:'Pick your autumn vibe in the comments'}],
     ['post','frame','retro',0,'food',{kicker:'Since 1974',title:'Grain Coffee',date:'Open daily 7–7',cta:'Visit us'}],
     ['post','bigType','retro',2,'quotes',{big:'Groovy',sub:'Good vibes only this weekend'}],
     ['post','moodboard','minimal',1,'fashion',{title:'Neutral mood',sub:'Linen, oat and soft light'}],
     ['post','stats','swiss',3,'biz',{title:'Why teams switch to Grow'}],
     ['post','ticket','y2k',2,'wedding',{title:'Rave in the garage',date:'Oct 31 · 11 pm',place:'Warehouse 9',kicker:'Halloween party'}],
     ['post','list','brutal',2,'fitness',{title:'4 moves for a strong core',items:it1(['Dead bug','Plank shoulder taps','Hollow hold','Bird dog']),cta:'Save it'}],
     ['post','sale','pastel',2,'beauty',{title:'Lash lift week',disc:'-25%',sub:'Only until Sunday'}],
     ['story','heroPhoto','y2k',1,'beauty',{title:'Chrome nails are back'}],
     ['story','magazine','editorial',0,'fashion',{big:'STYLE',title:'The new neutrals',sub:'12 pieces for a calm wardrobe'}],
     ['story','quote','luxe',1,'quotes',{quote:'Elegance is when the inside is as beautiful as the outside'}],
     ['story','list','minimal',3,'travel',{title:'Packing list: a weekend in the Alps',items:it1(['Wool layers','Trail shoes','Thermos','Film camera','A good book']),cta:'Save list'}],
     ['story','overlay','pastel',3,'food',{title:'New: matcha cloud latte',sub:'Oat milk, honey foam'}],
     ['story','bigType','brutal',3,'sale',{sub:'Up to 70% off everything',cta:'Swipe up'}],
     ['story','collage','collage',1,'wedding',{title:'Our love story',sub:'Save the date · June 14, 2027'}],
     ['story','arch','boho',2,'travel',{title:'Desert escape',kicker:'Wander',sub:'Joshua Tree · 4 nights under the stars'}],
     ['story','split','retro',3,'fitness',{title:'Sunset yoga club',sub:'Every Thursday on the rooftop',kicker:'Move Gym'}],
     ['story','swiss','swiss',1,'edu',{title:'Design school intake',kicker:'Applications open',date:'Nov 1',cta:'Apply'}],
     ['story','thisThat','y2k',3,'beauty',{title:'Glossy or matte?',a:'Glossy',b:'Matte',sub:'Vote in the poll'}],
     ['story','moodboard','boho',1,'wedding',{title:'Boho wedding mood',sub:'Terracotta, pampas & candlelight'}],
     ['story','ticket','retro',1,'food',{title:'Taco Tuesday',date:'Every Tue · 6 pm',place:'Grain Kitchen',kicker:'Live music'}],
     ['story','sale','luxe',2,'fashion',{title:'Private sale',sub:'Members only · 48 hours'}],
     ['pin','list','editorial',3,'food',{title:'7 cozy fall recipes',items:it1(['Pumpkin soup','Apple crumble','Chai pancakes','Mushroom risotto','Baked pears']),cta:'Get recipes'}],
     ['pin','moodboard','pastel',0,'beauty',{title:'Spring nail ideas',sub:'Save for your next appointment'}],
     ['pin','magazine','luxe',3,'travel',{big:'ROAM',title:'Kyoto in fall',sub:'Temples, tea and red maples'}],
     ['pin','arch','minimal',0,'realty',{title:'Calm bedroom ideas',kicker:'Interior notes',sub:'Linen, oak and warm light'}],
     ['pin','quote','pastel',2,'quotes',{quote:'You are allowed to rest'}],
     ['pin','collage','collage',3,'travel',{title:'Paris on a budget',sub:'Free museums, picnic spots, cheap eats'}],
     ['pin','bigType','swiss',2,'edu',{sub:'A 30-day plan to learn anything faster',cta:'Save plan'}],
     ['pin','heroPhoto','retro',1,'travel',{title:'Road trip playlist',sub:'50 songs for the open road',cta:'Listen'}],
     ['pin','thisThat','minimal',3,'realty',{title:'Oak or walnut?',a:'Oak',b:'Walnut',sub:'Which floor would you pick?'}],
     ['pin','stats','editorial',2,'fitness',{title:'My 90-day transformation',kicker:'Fitness diary'}],
     ['pin','split','boho',3,'food',{title:'Sourdough for beginners',sub:'A simple step-by-step guide',kicker:'Baking'}],
     ['pin','overlay','y2k',2,'fashion',{title:'Y2K outfit ideas',sub:'Low rise, baby tees, chrome'}],
     ['poster','bigType','brutal',1,'biz',{sub:'Grow Summit · Oct 30 · Pier 27',cta:'Get tickets'}],
     ['poster','frame','luxe',0,'wedding',{kicker:'You are invited',title:'Gala Night',date:'Dec 31 · 9 pm',place:'The Grand Hall'}],
     ['poster','swiss','swiss',0,'edu',{title:'Typography week',kicker:'Lecture series',date:'Nov 4–8',cta:'Free entry'}],
     ['poster','ticket','brutal',2,'fitness',{title:'City 5K run',kicker:'Race day'}],
     ['poster','magazine','retro',0,'food',{title:'The fall issue',sub:'Coffee, pastry and slow mornings'}],
     ['poster','sale','y2k',0,'sale',{title:'Cyber Monday',disc:'-60%'}],
     ['poster','split','swiss',2,'fitness',{title:'Pilates reformer',sub:'Small classes · all levels',kicker:'Move Gym'}],
     ['poster','collage','collage',2,'sale',{title:'Flea market',sub:'Vintage, vinyl & vibes · Sat 10–4',cta:'Free entry'}],
     ['poster','arch','retro',2,'travel',{title:'Visit Palm Springs',kicker:'Wish you were here',sub:'Sun, pools and mid-century homes'}],
     ['poster','heroPhoto','editorial',0,'biz',{title:'Design for good',kicker:'Exhibition',sub:'Opening Oct 30 · Free entry',cta:'RSVP'}],
     ['pres','heroPhoto','minimal',1,'biz',{title:'Brand strategy 2027',kicker:'Grow · Board meeting',sub:'Where we are, and where we go next',cta:'Q4 review'}],
     ['pres','stats','swiss',0,'biz',{title:'Results that speak',kicker:'2026 in numbers'}],
     ['pres','split','editorial',2,'edu',{title:'Intro to color theory',sub:'Lesson 01 · Foundations',kicker:'Word School'}],
     ['pres','bigType','y2k',1,'biz',{big:'Pitch',sub:'Seed round · 2026',cta:'Let’s talk'}],
     ['pres','list','swiss',3,'biz',{title:'Agenda',items:it1(['Where we are','The market','Product roadmap','Team & hiring']),cta:'Grow'}],
     ['pres','quote','luxe',1,'biz',{quote:'Simplicity is the ultimate sophistication',handle:'Brand principles'}],
     ['pres','moodboard','boho',0,'fashion',{title:'Brand moodboard',sub:'Warm, tactile, honest'}],
     ['pres','frame','minimal',3,'edu',{kicker:'Thank you',title:'Questions?',date:'maria@wordschool.com',place:'wordschool.com',cta:'Get in touch'}],
     ['yt','split','brutal',0,'fitness',{title:'10-min abs, no equipment',kicker:'Workout',sub:'Follow along, beginner friendly',cta:'Watch'}],
     ['yt','heroPhoto','y2k',0,'beauty',{title:'Get ready with me',sub:'Chrome nails + glossy lips',kicker:'GRWM',cta:'New video'}],
     ['yt','thisThat','brutal',3,'fashion',{title:'$20 vs $200 outfit',a:'$20',b:'$200',sub:'Can you tell the difference?'}],
     ['yt','bigType','retro',3,'travel',{sub:'I drove 2,000 miles across California',cta:'Watch'}],
     ['yt','collage','collage',0,'food',{title:'What I eat in a day',sub:'Easy, cozy, healthy',cta:'Watch'}],
     ['yt','sale','y2k',3,'sale',{title:'Haul: the best deals',sub:'Everything I bought this Black Friday'}],
     ['yt','overlay','editorial',1,'realty',{title:'Inside a $2M loft',sub:'Full home tour'}],
     ['yt','stats','brutal',2,'biz',{title:'How I grew to 100k',kicker:'Case study',stats:[['100k','subscribers'],['14','months'],['$0','on ads']]}],
     ['invite','frame','minimal',0,'wedding',{}],
     ['invite','arch','boho',3,'wedding',{kicker:'Save the date',sub:'June 14, 2027 · Linden Grove'}],
     ['invite','ticket','retro',2,'wedding',{title:'Mia turns 30',date:'Nov 8 · 8 pm',place:'The Disco Room',kicker:'Birthday party'}],
     ['invite','frame','luxe',3,'wedding',{title:'Clara & James',date:'September 9, 2027',place:'Villa Rosa, Lake Como'}],
     ['invite','collage','pastel',0,'wedding',{title:'Baby shower',sub:'For little Ava · Oct 27 · 2 pm',cta:'RSVP by Oct 20'}],
     ['invite','bigType','y2k',2,'wedding',{big:'Party',sub:'Mia’s 30th · Nov 8 · The Disco Room',cta:'RSVP'}],
     ['invite','arch','pastel',1,'wedding',{kicker:'Bridal shower',title:'Brunch for Ella',sub:'Sunday, May 2 · Rose Cafe'}],
     ['invite','frame','editorial',0,'biz',{kicker:'Grow Summit',title:'You’re invited',cta:'Register'}],
     ['card','cardA','minimal',0,'beauty',{}],
     ['card','cardB','luxe',0,'realty',{}],
     ['card','cardA','brutal',0,'biz',{}],
     ['card','cardB','boho',0,'fitness',{person:'Nora Bell',role:'Yoga teacher',handle:'@nora.flow',name:'Nora Flow'}],
     ['card','cardA','pastel',1,'edu',{}],
     ['card','cardB','editorial',3,'fashion',{}],
     ['card','cardA','y2k',2,'food',{}],
     ['resume','resumeA','minimal',0,'biz',{}],
     ['resume','resumeB','editorial',0,'fashion',{}],
     ['resume','resumeA','swiss',3,'edu',{}],
     ['resume','resumeB','luxe',0,'realty',{}],
     ['resume','resumeA','pastel',3,'beauty',{}],
     ['resume','resumeB','brutal',1,'biz',{person:'Sam Rivera',role:'Brand designer',skills:['Identity','Type','Motion','Art direction']}],
     ['resume','resumeA','boho',2,'travel',{}],
     ['menu','menuA','retro',0,'food',{}],
     ['menu','menuB','minimal',0,'food',{menuWord:'Brunch'}],
     ['menu','menuA','luxe',1,'food',{name:'Maison Noir',kicker:'Wine bar',items:[['Burrata & figs','$16'],['Oysters (6)','$24'],['Truffle tagliatelle','$28'],['Duck confit','$32'],['Glass of Champagne','$18']],menuWord:'Dinner',place:'21 Rue Noire',handle:'@maison.noir'}],
     ['menu','menuA','pastel',0,'beauty',{}],
     ['menu','menuB','editorial',3,'fitness',{}],
     ['menu','menuA','boho',0,'wedding',{}],
     ['menu','menuB','brutal',1,'food',{name:'Smash Burger Co.',kicker:'Burgers',items:[['Double smash','$12'],['Crispy chicken','$11'],['Loaded fries','$6'],['Thick shake','$7']],menuWord:'Menu',handle:'@smash.co'}],
     ['menu','menuA','swiss',1,'biz',{}]
    ];
    function copyOf(sp){const n=NICHES[sp.niche];return Object.assign({},n,{title:sp.fmt==='invite'?n.event:n.title,stats:n.stats||DSTATS},sp.o)}
    const resData=t=>({sum:t.role+' with 6 years of experience. I care about clear decisions, small details and working closely with people.',exp:[[t.role,t.name+' · 2021 — now','Leading key projects and a team of four.'],[t.role,'Field Studio · 2018 — 2021','Shipped 30+ projects for local brands.']],edu:['New York University','BA · 2014 — 2018']});
    const mono=n=>n.split(' ').map(w=>w[0]).join('').slice(0,2);
    function nameOf(sp){const t=copyOf(sp);if(sp.fmt==='card'||sp.fmt==='resume')return t.person+' — '+t.role;if(sp.fmt==='menu')return t.name+' '+t.menuWord.toLowerCase();if(sp.lay==='quote')return '“'+t.quote+'”';if(sp.lay==='bigType')return t.big+' — '+t.sub;return t.title}
    const ALT={
     beauty:{titles:['Soft nails season','Chrome nails are back','Fall nail trends','Lash lift week','Your glow-up starts here','Book your fall set'],subs:['Booking open for October','Gel, chrome & minimal art','New clients get 15% off','Walk-ins welcome on weekends'],kickers:['Nail studio','Beauty bar','Lash & brow','Self-care Sunday'],bigs:['Glow','Nails','Gloss'],events:['Studio opening party','Beauty pop-up','Lash masterclass'],quotes:['Well-kept hands are the best accessory','Self-care is not a luxury','Glow is an attitude']},
     food:{titles:['Autumn menu is here','Slow Sunday brunch','New: matcha cloud latte','Fresh out of the oven','Pumpkin spice is back','Coffee & cake o’clock'],subs:['Pumpkin latte and fresh pastries daily','Every weekend, 9 am – 2 pm','Oat milk at no extra cost','Order ahead and skip the line'],kickers:['Coffee house','Bakery','Brunch spot','Neighborhood cafe'],bigs:['Brew','Fresh','Yum'],events:['Coffee tasting night','Latte art class','Bakery open day'],quotes:['Coffee first, everything else later','Life happens, coffee helps','Good food, good mood']},
     fitness:{titles:['Train with me','30 days of strength','Sunset yoga club','4 moves for a strong core','No excuses Monday','Pilates for beginners'],subs:['Your first class is on us','Small groups, all levels','New HIIT classes every Tue & Fri','Mat, reformer and stretch'],kickers:['Fitness studio','Yoga club','Run club','Pilates'],bigs:['Move','Sweat','Power'],events:['Weekend 5K run','Rooftop yoga','Bootcamp day'],quotes:['Discipline is a form of self-love','Strong is the new pretty','One more rep']},
     fashion:{titles:['The autumn capsule','New neutrals','Y2K outfit ideas','How to style a trench','The weekend edit','Denim, reimagined'],subs:['A limited linen & wool edit','Free shipping over $100','12 pieces for a calm wardrobe','Drop 03 is live'],kickers:['New in','Lookbook','Style notes','The edit'],bigs:['Style','Chic','Mode'],events:['Collection launch','Sample sale','Styling night'],quotes:['Style is saying who you are without speaking','Dress for the life you want','Less, but better']},
     realty:{titles:['Your dream home','Just listed: loft downtown','Open house this Saturday','Calm bedroom ideas','Penthouse on Fifth','Sold in 7 days'],subs:['2 bed · 1,200 sq ft · city views','3 bed · garden · quiet street','Book a private viewing today','Move-in ready, pets welcome'],kickers:['Just listed','For sale','Interior notes','New development'],bigs:['Home','Nest','Sold'],events:['Open house','Home staging talk','New tower launch'],quotes:['Home is the place you always want to return to','Good design is a quiet luxury','Every room tells a story']},
     edu:{titles:['English from zero','5 study habits that work','Design school intake','Free webinar this week','Learn to code in 12 weeks','Speak with confidence'],subs:['Live classes in small groups','Applications close Nov 1','Certificate included','Start with a free trial lesson'],kickers:['Online school','Course','Workshop','Masterclass'],bigs:['Learn','Study','Think'],events:['Free webinar','Open lecture','Graduation day'],quotes:['It is never too late to learn','Small steps, every day','Curiosity is a superpower']},
     wedding:{titles:['Anna & Tom','Save the date','Baby shower','Mia turns 30','Bridal brunch','Our love story'],subs:['request the pleasure of your company','Dinner, dancing and good company','Dress code: garden formal','RSVP by May 1'],kickers:['Together with their families','You are invited','Save the date','Join us'],bigs:['Love','Party','Cheers'],events:['Anna & Tom','Clara & James','Mia’s 30th'],quotes:['Love is when home becomes a person','Together is a beautiful place to be','Here’s to us']},
     biz:{titles:['Grow together','Q3 results are in','Launch day','Meet the new dashboard','Brand strategy 2027','Hiring: product designer'],subs:['Automate busywork in 15 minutes','+48% revenue, 2k new teams','Free for teams up to 5','Remote · full time'],kickers:['Product launch','Quarterly update','Case study','We’re hiring'],bigs:['Grow','Launch','Scale'],events:['Grow Summit 2026','Founder breakfast','Product demo day'],quotes:['The best time to start is today','Done is better than perfect','Build what people need']},
     travel:{titles:['Alps in autumn','Lisbon in 3 days','Paris on a budget','Desert escape','Kyoto in fall','Road trip playlist'],subs:['3-day guided trip with transfers','Flights + hotel from $420','Hidden gems and local food','Save for your next trip'],kickers:['Travel guide','Weekend trip','Bucket list','Wanderlust'],bigs:['Roam','Explore','Away'],events:['Summit hike','Travel photo night','Island hopping'],quotes:['Collect moments, not things','Not all who wander are lost','Go where you feel alive']},
     quotes:{titles:['Slow is still moving','You are allowed to rest','Small steps count','Be kind to your mind','Today is a fresh start','Progress over perfection'],subs:['Save this for later','Your daily reminder','Share with someone who needs it','Read this twice'],kickers:['Daily reminder','Note to self','Monday mood','Affirmation'],bigs:['Breathe','Calm','Begin'],events:['Morning meditation','Journaling circle','Breathwork session'],quotes:['You don’t have to see the whole staircase, just take the first step','Slow mornings are a form of self-respect','You are allowed to rest','Bloom where you are planted']},
     sale:{titles:['Black Friday','Cyber Monday','Summer sale','Only 3 days left','Flash sale','Buy 1 get 1'],subs:['Everything on sale until Sunday','Use code VIBS for an extra 10%','Free shipping on all orders','While stocks last'],kickers:['Online store','Limited offer','Today only','Members only'],bigs:['SALE','Deals','Promo'],discs:['-70%','-50%','-30%','-60%'],events:['Late night shopping','Sample sale','Pop-up market'],quotes:['The best buy is the one that makes you smile every day','Treat yourself','Good things are coming']}
    };
    const FW={post:20,story:16,pin:14,poster:10,pres:8,yt:8,invite:7,card:5,resume:5,menu:7};
    function gen(count){let a=20261016;const r=()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
     const pick=x=>x[r()*x.length|0],LK=Object.keys(L),fk=Object.keys(FW),tw=fk.reduce((s,k)=>s+FW[k],0),seen=new Set(T.map(x=>x.slice(0,5).join('|'))),out=[];let g=0;
     while(out.length<count&&g<50000){g++;let x=r()*tw,i=0;while(x>FW[fk[i]]){x-=FW[fk[i]];i++}const fmt=fk[i];
      const lay=pick(LK.filter(k=>L[k].fm.includes(fmt)));let niche=pick(NKEYS);if(fmt==='invite'&&r()<0.5)niche='wedding';if(fmt==='menu'&&r()<0.4)niche='food';
      const style=pick(SKEYS),pal=r()*4|0,key=[fmt,lay,style,pal,niche].join('|');if(seen.has(key))continue;seen.add(key);
      const A=ALT[niche],o={title:fmt==='invite'?pick(A.events):pick(A.titles),sub:pick(A.subs),kicker:pick(A.kickers),big:pick(A.bigs),quote:pick(A.quotes)};if(A.discs)o.disc=pick(A.discs);
      out.push([fmt,lay,style,pal,niche,o])}
     return out}
    return { STYLES, NICHES, T, copyOf, resData, mono, nameOf, gen };
  })(Object.fromEntries(Object.entries(K).map(([key, v]) => [key, { fm: v.fm }])));

  // the 1000: [format, layout, style, palette, topic, own texts] → hidden categories, so TP.svg and TP.make build
  // them like any other template; each one carries its own style (palette and fonts) in the category
  TP.KT = KD.T.concat(KD.gen(1000 - KD.T.length)).map((r, i) => ({ id: i + 1, fmt: r[0], lay: r[1], style: r[2], pal: r[3], niche: r[4], o: r[5] }));
  TP.KFORMATS = KF; TP.KSTYLES = KS_UK; TP.KTOPICS = KN_UK;
  const kfam = v => v.replace(/"/g, '').split(',')[0];
  TP.KFONTS = Array.from(new Set(Object.values(KD.STYLES).flatMap(st => [st.head, st.body, st.script].map(kfam)).concat('DM Serif Display')));
  TP.KT.forEach(sp => {
    const F = KF[sp.fmt], S0 = KD.STYLES[sp.style], P = S0.pals[sp.pal];
    sp.name = KD.nameOf(sp);
    const st = { k: 'kt', n: KS_UK[sp.style], pal: [P.bg, P.soft, P.ink, P.accent, P.accent], f: Array.from(new Set([S0.head, S0.body, S0.script].map(kfam).concat(sp.lay === 'quote' ? ['DM Serif Display'] : []))), i: sp.id };
    TP.CATS.push(['kt-' + sp.id, sp.name, F[4], F[5], ['k-' + sp.lay], TX('', '', '', '', '', ''), 1, { kt: sp, raw: true, group: sp.fmt, st, resume: sp.fmt === 'resume' }]);
    TOPIC['kt-' + sp.id] = KTOPIC[sp.niche];
  });
  Object.keys(K).forEach(key => { L['k-' + key] = c => RC(t('Тло'), 0, 0, c.W, c.H, { fill: c.bg }) + K[key].f(kctx(c)); });
  // search: the board's English words and the names in the interface language
  const kHay = sp => {
    if (sp.hay && sp.hay[0] === O.lang) return sp.hay[1];
    const N = KD.NICHES[sp.niche], S0 = KD.STYLES[sp.style], F = KF[sp.fmt], Ly = K[sp.lay];
    const s = [sp.name, N.label, N.kw, S0.l, S0.kw, F[1], Ly.l, t(F[0]), t(KS_UK[sp.style]), t(KN_UK[sp.niche]), t(Ly.n)].join(' ').toLowerCase();
    sp.hay = [O.lang, s];
    return s;
  };
  // f: { sty, nic } — the style and topic filters of the gallery
  TP.ktItems = (fmt, tier, q, f = {}) => {
    const out = [], words = q ? q.split(/\s+/) : [];
    for (const sp of TP.KT) {
      if ((fmt && sp.fmt !== fmt) || (f.sty && sp.style !== f.sty) || (f.nic && sp.niche !== f.nic)) continue;
      const prem = KPREM.has(sp.lay);
      if ((tier === 'pro' && !prem) || (tier === 'free' && prem)) continue;
      if (words.length && !words.every(w => kHay(sp).includes(w))) continue;
      out.push({ cat: 'kt-' + sp.id, lay: 'k-' + sp.lay, st: 'kt', prem, key: 'kt-' + sp.id + '|k-' + sp.lay + '|kt', tip: [sp.name, t(KF[sp.fmt][0]), t(KS_UK[sp.style]), t(KN_UK[sp.niche])].join(' · ') });
    }
    return out;
  };

  // ======================================================================
  // BUILD
  // ======================================================================
  // the catalogue mixes the 100 hand-made styles (the 10 000 new ones would make millions of combinations);
  // any style of the gallery still builds by its key
  const STY = () => (O.gallery && (O.gallery.CORE || O.gallery.STYLES)) || [{ k: 'base', n: 'Базовий', pal: ['#FFFFFF', '#F2F2F5', '#151520', '#5B5BF0', '#FF7A59'], f: ['Inter', 'Inter'], i: 0 }];
  // the names of the board's templates are their own text, not interface strings
  TP.catName = cat => (cat[7] && cat[7].raw ? cat[1] : t(cat[1]));
  TP.ctx = (cat, st, W, H) => {
    const [bg, sf, ink, a1, a2] = st.pal;
    const u = Math.min(W, H) / 100;
    const txt = {}; for (const [k, v] of Object.entries(cat[5])) txt[k] = v ? t(v) : '';
    return { W, H, u, pad: Math.max(u * 7, Math.min(W, H) * 0.07), bg, sf, ink, a1: a1 === bg ? a2 : a1, a2: a2 === bg ? a1 : a2, fh: st.f[0], fb: st.f[1], txt, defs: [], gid: 0, st, meta: cat[7] || null };
  };
  TP.svg = (catId, layout, styleKey, page = 0, opts = {}) => {
    const cat = TP.cat(catId), st = (cat[7] && cat[7].st) || STY().find(s => s.k === styleKey) || (O.gallery && O.gallery.get(styleKey)) || STY()[0];
    const W = opts.w || cat[2], H = opts.h || cat[3];
    const c = TP.ctx(cat, st, W, H);
    // gradient ids must be unique when many thumbnails share one page
    c.defs = []; c.gid = 0; c.idp = opts.idp || '';
    c.photos = TP.photosFor(catId); c.pseed = (st.i || 0) * 3 + page * 5; c.pi = 0; c.thumb = !!opts.thumb; c.photoList = [];
    let body = '';
    try {
      if (page > 0 && L[layout] && L[layout].multi) body = L[layout](c, page);
      else if (page > 0 && layout === 'brochure') body = L.brochure(c, page);
      else if (page > 0) body = L.slideContent(c, page);
      else body = (L[layout] || L.hero)(c, page);
    } catch (e) { console.error(catId, layout, e); body = L.hero(c); }
    return { svg: `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><defs>${c.defs.join('')}</defs>${body}</svg>`, bg: c.bg, W, H, st, photos: c.photoList };
  };
  // the SVG layers go into a frame; the background is locked
  const fillFrame = (f, svg, name) => {
    const g = O.io.importSVG(svg, { container: f, noCenter: true, noCommit: true, keepGroup: true, name });
    if (!g) return;
    const kids = g.children.slice();
    kids.forEach(k => { k.m = M.mul(g.m, k.m); });
    f.children.splice(f.children.indexOf(g), 1, ...kids);
    kids.forEach(k => { if (k.name === t('Тло')) k.locked = true; });
    model.reindex();
  };
  // photos of an inserted template: rounded corners back, then the picture is downloaded into the project
  // (export, offline work and sharing need the data itself, not a link)
  const photoData = new Map();
  TP.embedPhotos = (f, list) => {
    if (!list || !list.length) return;
    model.walk(f.children, n => {
      const p = (n.fills || []).find(x => x.type === 'image');
      if (!p || n.type !== 'rect') return;
      const a = S.doc.assets[p.asset];
      if (!a || !/^https:\/\/picsum\.photos\//.test(a.data || '')) return;
      const b = model.localBounds(n), m = n.m || [1, 0, 0, 1, 0, 0];
      const hit = list.find(r => Math.abs(r.x - m[4]) < 2 && Math.abs(r.y - m[5]) < 2 && Math.abs(r.w - b.w) < 2);
      if (hit && hit.rx) n.radius = hit.rx;
      const url = a.data, aid = p.asset;
      const done = data => { const asset = S.doc.assets[aid]; if (asset && data) { asset.data = data; O.requestRender(); } };
      if (photoData.has(url)) { photoData.get(url).then(done); return; }
      const job = fetch(url).then(r => (r.ok ? r.blob() : null)).then(bl => (bl ? O.io.blobToData(bl) : null)).catch(() => null);
      photoData.set(url, job);
      job.then(done);
    });
  };
  TP.make = (catId, layout, styleKey, at) => {
    const cat = TP.cat(catId);
    const pages = cat[6] || 1;
    const page = model.page(), frames = [];
    let x = at ? at.x : 0;
    for (let p = 0; p < pages; p++) {
      const { svg, bg, W, H, st, photos } = TP.svg(catId, layout, styleKey, p);
      const f = model.create('frame', { name: `${TP.catName(cat)}${pages > 1 ? ' ' + (p + 1) : ''} — ${t(st.n)}`, w: W, h: H, m: M.translate(x, at ? at.y : 0), fills: [O.paint.solid(bg)], clip: true });
      if (catId === 'resume' || (cat[7] && (cat[7].cv || cat[7].resume))) f.resume = true;
      model.insert(f, page);
      model.reindex();
      fillFrame(f, svg, TP.catName(cat));
      TP.embedPhotos(f, photos);
      frames.push(f);
      x += W + 120;
      if (O.fonts) st.f.forEach(fm => { O.fonts.load(fm, 400).catch(() => {}); O.fonts.load(fm, 700).catch(() => {}); O.fonts.load(fm, 800).catch(() => {}); });
    }
    return frames;
  };
  TP.use = async (catId, layout, styleKey, opts = {}) => {
    if (opts.newProject && O.projects && !O.projects.disabled) { const d = model.newDoc(); d.name = TP.catName(TP.cat(catId)); await O.projects.createFrom(d); }
    const pg = model.page();
    const b = pg.children.length ? model.selBounds(pg.children.filter(n => n.visible !== false)) : null;
    const frames = TP.make(catId, layout, styleKey, b ? { x: Math.round(b.x + b.w + 200), y: Math.round(b.y) } : { x: 0, y: 0 });
    O.select(frames.map(f => f.id));
    O.history.commit('Шаблон');
    setTimeout(() => V.fit(model.selBounds(frames), 80, 1), 0);
    O.toast('Шаблон «{name}» додано', { name: TP.catName(TP.cat(catId)) });
    if (catId === 'resume') O.toast('Порада: Файл → «Перевірити резюме на ATS…»');
    return frames;
  };

  // ======================================================================
  // GALLERY (Canva-like)
  // ======================================================================
  let el = null;
  TP.close = () => { if (el) { el.remove(); el = null; } };
  // every template = category × layout × style; the styles change in a stable, varied order
  // the 1000 ideas: 50 kinds × 20 styles, mixed row by row so neighbours differ
  TP.ideaItems = (group, tier, q, set = 'idea', variants = TP.IDEA_VARIANTS) => {
    const out = [], styles = STY(), ideas = TP.CATS.filter(c => c[7] && c[7][set] && (!group || c[7].group === group));
    for (let v = 0; v < variants; v++) ideas.forEach((cat, ii) => {
      const st = styles[(ii * 7 + v * 37) % styles.length], prem = group === 'pro' || (ii + v) % 4 === 0;
      if ((tier === 'pro' && !prem) || (tier === 'free' && prem)) return;
      if (q && !(t(cat[1]) + ' ' + t(cat[7].group) + ' ' + t(st.n)).toLowerCase().includes(q)) return;
      out.push({ cat: cat[0], lay: cat[4][0], st: st.k, prem, key: cat[0] + '|' + cat[4][0] + '|' + st.k });
    });
    return out;
  };
  TP.items = (catId, tier, q, f) => {
    if (catId === 'kt' || String(catId).startsWith('kt:')) return TP.ktItems(catId === 'kt' ? '' : catId.slice(3), tier, q, f);
    if (catId === 'ideas' || String(catId).startsWith('ideas:')) return TP.ideaItems(catId === 'ideas' ? '' : catId.slice(6), tier, q);
    if (catId === 'pins' || String(catId).startsWith('pins:')) return TP.ideaItems(catId === 'pins' ? '' : catId.slice(5), tier, q, 'pin');
    if (catId === 'cvpin' || catId === 'cvpro') return TP.ideaItems(catId.slice(2), tier, q, 'cv', TP.CV_VARIANTS);
    // «Résumé»: the Pinterest-style and the premium ones, then the six base layouts
    if (catId === 'resume') return TP.items('cvpin', tier, q).concat(TP.items('cvpro', tier, q), TP.items('resume-base', tier, q));
    const out = [], styles = STY();
    const cats = catId === 'all' ? TP.CATS.filter(c => !c[7]) : [TP.cat(catId === 'resume-base' ? 'resume' : catId)];
    for (let si = 0; si < styles.length; si++) for (const cat of cats) cat[4].forEach((lay, li) => {
      const prem = TP.PREMIUM.has(lay) || (si + li) % 5 === 0;
      if (tier === 'pro' && !prem) return;
      if (tier === 'free' && prem) return;
      const st = styles[(si * 7 + li * 13 + cat[0].length) % styles.length];
      if (q && !(t(cat[1]) + ' ' + t(st.n) + ' ' + st.gname).toLowerCase().includes(q)) return;
      out.push({ cat: cat[0], lay, st: st.k, prem, key: cat[0] + '|' + lay + '|' + st.k });
    });
    // dedupe and mix
    const seen = new Set();
    return out.filter(x => (seen.has(x.key) ? false : (seen.add(x.key), true)));
  };
  TP.count = () => TP.CATS.reduce((a, c) => a + c[4].length, 0) * STY().length;
  let thumbN = 0;
  const thumb = it => {
    const { svg } = TP.svg(it.cat, it.lay, it.st, 0, { idp: 'tpt' + (thumbN++) + '_', thumb: true });
    return svg.replace('<svg ', '<svg class="tp-svg" preserveAspectRatio="xMidYMid meet" ').replace(/ width="\d+" height="\d+"/, '');
  };
  TP.open = (opts = {}) => {
    TP.close();
    // the 1000 ideas open first (the last category is remembered after that)
    let cat = opts.cat || O.ls.get('tpCat3', 'pins'), tier = 'all', q = '', shown = 0, list = [];
    const kf = { sty: '', nic: '' }; // style and topic filters of the board's 1000
    el = O.h(`<div class="tp-back"><div class="tp" role="dialog" aria-modal="true" aria-label="${esc(t('Шаблони'))}">
      <div class="tp-h"><h2>${esc(t('Шаблони'))}</h2><input type="search" class="tp-q" placeholder="${esc(t('Пошук шаблонів: стиль, тип…'))}" aria-label="${esc(t('Пошук шаблонів'))}">
        <div class="tp-tiers" role="tablist">${[['all', 'Усі'], ['pro', '👑 Преміум'], ['free', 'Базові']].map(([k, l]) => `<button type="button" role="tab" data-tier="${k}" class="${k === tier ? 'on' : ''}">${esc(t(l))}</button>`).join('')}</div>
        <label class="chk"><input type="checkbox" class="tp-new"><span>${esc(t('У новому проєкті'))}</span></label>
        <button type="button" class="ib" data-tpa="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 16)}</button></div>
      <div class="tp-main"><nav class="tp-cats">${[['kt', '🧩 1000 шаблонів VIBSma', '', '']].concat(Object.entries(TP.KFORMATS).map(([k, F]) => ['kt:' + k, '· ' + t(F[0]), '', '']), [['pins', '📌 1000 пінів Pinterest', '', '']],TP.PIN_GROUPS.map(g => ['pins:' + g, '· ' + t(g), '', '']), [['cvpin', '📄 100 резюме з Pinterest', '', ''], ['cvpro', '👑 100 преміум-резюме', '', ''], ['ideas', '✨ 1000 ідей', '', '']]).concat(TP.IDEA_GROUPS.map(g => ['ideas:' + g, '· ' + t(g), '', ''])).concat([['gl', '⭐ 10 000+ стилів і мої шаблони', '', ''], ['all', 'Усі шаблони', '', '']], TP.CATS.filter(c => !c[7]).map(c => [c[0], c[1], c[2], c[3]])).map(([id, n, w, h]) => `<button type="button" data-cat="${id}" class="${id === cat ? 'on' : ''}${id.includes(':') ? ' sub' : ''}"><span>${esc(t(n))}</span>${w ? `<em>${w}×${h}</em>` : ''}</button>`).join('')}</nav>
      <div class="tp-body"><div class="tp-info"></div><div class="tp-grid" role="list"></div><div class="tp-more"></div></div></div></div></div>`);
    document.body.appendChild(el);
    const grid = el.querySelector('.tp-grid'), info = el.querySelector('.tp-info'), body = el.querySelector('.tp-body');
    const more = () => {
      const chunk = list.slice(shown, shown + 36);
      shown += chunk.length;
      grid.insertAdjacentHTML('beforeend', chunk.map(it => `<button type="button" class="tp-card" role="listitem" data-it="${esc(it.key)}" title="${esc(it.tip || t(TP.cat(it.cat)[1]) + ' · ' + t((STY().find(s => s.k === it.st) || { n: '' }).n))}">${it.prem ? `<span class="tp-pro" title="${esc(t('Преміум-шаблон — у VIBSma безкоштовно'))}">👑</span>` : ''}${thumb(it)}<span class="tp-cap">${esc(TP.catName(TP.cat(it.cat)))}</span></button>`).join(''));
      el.querySelector('.tp-more').textContent = shown < list.length ? t('Прокрутіть, щоб побачити ще') : '';
    };
    const render = () => {
      const kt = /^kt(:|$)/.test(cat);
      list = TP.items(cat, tier, q.toLowerCase(), kf);
      shown = 0; grid.innerHTML = ''; grid.classList.toggle('rows', cat !== 'all' && !/^(ideas|pins|cvp|resume|kt)/.test(cat));
      // the board's templates use its own fonts; the thumbnails redraw when they arrive
      if (kt && O.fonts) TP.KFONTS.forEach(f => O.fonts.load(f).catch(() => {}));
      const c = cat !== 'all' && !kt && TP.cat(cat);
      const ttl = cat === 'kt' ? t('1000 шаблонів VIBSma') : kt ? t(TP.KFORMATS[cat.slice(3)][0]) : cat === 'ideas' ? t('1000 ідей для дизайну') : cat === 'pins' ? t('1000 пінів у стилі Pinterest') : cat === 'cvpin' ? t('Резюме в стилі Pinterest') : cat === 'cvpro' ? t('Преміум-резюме (як Canva Pro)') : cat.includes(':') ? t(cat.split(':')[1]) : c ? t(c[1]) : t('Усі шаблони');
      const sel = (key, all, names) => `<select data-kf="${key}" aria-label="${esc(t(key === 'sty' ? 'Стиль' : 'Тема'))}"><option value="">${esc(t(all))}</option>${Object.entries(names).map(([k, n]) => `<option value="${k}"${kf[key] === k ? ' selected' : ''}>${esc(t(n))}</option>`).join('')}</select>`;
      info.innerHTML = `<b>${esc(ttl)}</b> <span>${esc(t('{n} шаблонів', { n: list.length }))}</span>${kt ? ' ' + sel('sty', 'Усі стилі', TP.KSTYLES) + ' ' + sel('nic', 'Усі теми', TP.KTOPICS) : ''}${cat === 'resume' ? ` <button type="button" class="btn" data-tpa="ats">${esc(t('Перевірити резюме на ATS…'))}</button>` : ''}`;
      body.scrollTop = 0;
      more();
    };
    render();
    body.addEventListener('scroll', () => { if (body.scrollTop + body.clientHeight > body.scrollHeight - 600 && shown < list.length) more(); });
    el.querySelector('.tp-q').addEventListener('input', O.debounce(e => { q = e.target.value.trim(); render(); }, 200));
    el.addEventListener('change', e => { const s = e.target.closest('[data-kf]'); if (s) { kf[s.dataset.kf] = s.value; render(); } });
    el.addEventListener('click', async e => {
      if (e.target === el) return TP.close();
      const b = e.target.closest('[data-cat],[data-tier],[data-it],[data-tpa]');
      if (!b) return;
      if (b.dataset.cat === 'gl') { TP.close(); if (O.gallery) O.gallery.open(); return; }
      if (b.dataset.cat) { cat = b.dataset.cat; O.ls.set('tpCat3', cat); el.querySelectorAll('[data-cat]').forEach(x => x.classList.toggle('on', x === b)); render(); }
      if (b.dataset.tier) { tier = b.dataset.tier; el.querySelectorAll('[data-tier]').forEach(x => x.classList.toggle('on', x === b)); render(); }
      if (b.dataset.tpa === 'close') TP.close();
      if (b.dataset.tpa === 'ats') { TP.close(); O.ats && O.ats.dialog(); }
      if (b.dataset.it) { const [c2, lay, st] = b.dataset.it.split('|'); const nw = el.querySelector('.tp-new').checked; TP.close(); await TP.use(c2, lay, st, { newProject: nw }); }
    });
    el.addEventListener('keydown', e => { if (e.key === 'Escape') { e.stopPropagation(); TP.close(); } });
    setTimeout(() => el && el.querySelector('.tp-q').focus(), 0);
  };

  O.cmd('canvaTemplates', 'Шаблони — 1000 дизайнів (як у Canva)…', () => TP.open(), { group: 'Файл', keys: ['Ctrl+Alt+Shift+J'] });
  O.cmd('resumeTemplates', 'Шаблони резюме…', () => TP.open({ cat: 'resume' }), { group: 'Файл' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл');
  O.cmd('pinTemplates', 'Піни Pinterest — 1000 шаблонів…', () => TP.open({ cat: 'pins' }), { group: 'Файл' });
  O.cmd('ktTemplates', 'Шаблони VIBSma — 1000 дизайнів…', () => TP.open({ cat: 'kt' }), { group: 'Файл' });
  if (fileMenu) { const i = fileMenu[1].indexOf('new'); fileMenu[1].splice(i < 0 ? 1 : i + 1, 0, 'canvaTemplates', 'ktTemplates', 'pinTemplates', 'resumeTemplates'); }
  // «New project» dialog: the template library as one more tile
  if (O.projects && O.projects.templates) O.projects.templates.splice(2, 0, { id: 'canva', name: 'Шаблони за категоріями…', icon: 'grid', make: () => { setTimeout(() => TP.open(), 0); return null; } });
})();
