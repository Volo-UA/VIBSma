'use strict';
/* VIBSma — Satzspiegel (type area) construction, as taught in German typography.
   Methods: Neunerteilung (Villard / Tschichold), Zwölferteilung, any n-division, diagonal construction
   (Diagonalkonstruktion), golden section 2:3:5:8, medieval canon 2:3:4:6, own ratio and manual margins.
   Result: page margins (Bund / Kopf / Außen / Fuß), columns, gutter, optional register (Registerhaltigkeit)
   against the baseline grid; the construction lines can be shown over the pages. */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui, M = O.M;
  const t = (s, v) => O.t(s, v), esc = O.esc, n_ = O.n;
  const PR = O.print;
  const MM = PR.MM;
  const SZ = O.satz = {};
  SZ.METHODS = [
    ['nine', 'Дев’ятинний поділ (Neunerteilung, Villard / Tschichold)'],
    ['twelve', 'Поділ на 12 (Zwölferteilung)'],
    ['ndiv', 'Поділ на n частин'],
    ['diagonal', 'Діагональна конструкція'],
    ['golden', 'Золотий перетин 2 : 3 : 5 : 8'],
    ['canon', 'Середньовічний канон 2 : 3 : 4 : 6'],
    ['ratio', 'Власне співвідношення полів'],
    ['manual', 'Вручну']
  ];
  const RATIOS = { golden: [2, 3, 5, 8], canon: [2, 3, 4, 6] };
  // margins in px for a page w × h (px): { t, b, i, o }
  SZ.compute = (w, h, o = {}) => {
    const m = o.method || 'nine';
    if (m === 'nine' || m === 'twelve' || m === 'ndiv') {
      const n = m === 'nine' ? 9 : m === 'twelve' ? 12 : Math.max(3, Math.round(o.n || 10));
      return { i: w / n, o: 2 * w / n, t: h / n, b: 2 * h / n };
    }
    if (m === 'diagonal') {
      // the text block keeps the page proportions; its corners sit on the page and spread diagonals
      const i = Math.max(1, Math.min(w / 4, o.inner || w / 9));
      return { i, o: 2 * i, t: h * i / w, b: 2 * h * i / w };
    }
    if (m === 'manual') return { i: o.mi || 0, o: o.mo || 0, t: o.mt || 0, b: o.mb || 0 };
    // ratio methods: the margins follow Bund : Kopf : Außen : Fuß, scaled so that the text area takes `area` of the page
    const r = m === 'ratio' ? [o.ri || 2, o.rt || 3, o.ro || 4, o.rb || 6] : RATIOS[m] || RATIOS.canon;
    const A = Math.min(0.95, Math.max(0.2, o.area || (m === 'golden' ? 0.5 : 0.56)));
    const a = r[0] + r[2], c = r[1] + r[3];
    // (w − s·a)(h − s·c) = A·w·h  →  a·c·s² − (w·c + h·a)·s + w·h·(1 − A) = 0
    const B = w * c + h * a, disc = B * B - 4 * a * c * w * h * (1 - A);
    const s = (B - Math.sqrt(Math.max(0, disc))) / (2 * a * c);
    return { i: r[0] * s, t: r[1] * s, o: r[2] * s, b: r[3] * s };
  };
  // fit the text area height to whole baseline steps (the bottom margin absorbs the rest)
  SZ.register = (h, mg, step) => {
    if (!step) return mg;
    const area = h - mg.t - mg.b, k = Math.max(1, Math.floor(area / step));
    return Object.assign({}, mg, { b: h - mg.t - k * step });
  };
  SZ.areaShare = (w, h, mg) => Math.max(0, (w - mg.i - mg.o) * (h - mg.t - mg.b)) / (w * h);

  // ---------- targets ----------
  const pagesOf = () => {
    const pg = model.page();
    let list = O.sel().map(n => (n.type === 'frame' ? n : model.ancestors(n).find(a => a.type === 'frame' && model.ancestors(a).every(x => x.type !== 'frame')))).filter(Boolean);
    list = Array.from(new Set(list));
    if (!list.length && pg.pub) list = PR.pages(pg);
    return list;
  };
  const allPubFrames = () => { const pg = model.page(); const out = PR.pages(pg); if (pg.pub) for (const m of PR.masters()) if (m.master.pub === pg.pub.id) out.push(m); return out; };

  // ---------- preview: a spread with the type area and its construction lines ----------
  const preview = (w, h, mg, opts) => {
    const k = 150 / Math.max(w, h), W = w * k, H = h * k, P = 10;
    const pageR = (x0, left) => {
      const l = left ? mg.o : mg.i, r = left ? mg.i : mg.o;
      let s = `<rect x="${n_(x0)}" y="${P}" width="${n_(W)}" height="${n_(H)}" fill="#fff" stroke="#c9c9d1"/>`;
      if (opts.lines) {
        const spine = left ? x0 + W : x0, outer = left ? x0 : x0 + W;
        s += `<line x1="${n_(spine)}" y1="${P}" x2="${n_(outer)}" y2="${n_(P + H)}" stroke="#E040FB" stroke-width=".6" opacity=".6"/>`;
        s += `<line x1="${n_(spine)}" y1="${n_(P + H)}" x2="${n_(outer)}" y2="${P}" stroke="#E040FB" stroke-width=".6" opacity=".35"/>`;
      }
      s += `<rect x="${n_(x0 + l * k)}" y="${n_(P + mg.t * k)}" width="${n_(Math.max(0, W - (l + r) * k))}" height="${n_(Math.max(0, H - (mg.t + mg.b) * k))}" fill="#9747FF" fill-opacity=".16" stroke="#9747FF" stroke-width="1"/>`;
      const cols = Math.max(1, opts.cols || 1), g = (opts.gutter || 0) * k, cw = (W - (l + r) * k - g * (cols - 1)) / cols;
      for (let i = 1; i < cols; i++) { const x = x0 + l * k + i * cw + (i - 1) * g; s += `<rect x="${n_(x)}" y="${n_(P + mg.t * k)}" width="${n_(g)}" height="${n_(Math.max(0, H - (mg.t + mg.b) * k))}" fill="#fff" opacity=".85"/>`; }
      if (opts.step && opts.step * k > 1.6) { let d = ''; for (let y = mg.t; y <= h - mg.b + 0.01; y += opts.step) d += `M${n_(x0 + l * k)} ${n_(P + y * k)}h${n_(Math.max(0, W - (l + r) * k))}`; s += `<path d="${d}" stroke="#00B4D8" stroke-width=".4" opacity=".7"/>`; }
      return s;
    };
    let s = '';
    if (opts.facing) {
      s += pageR(P, true) + pageR(P + W, false);
      if (opts.lines) s += `<line x1="${P}" y1="${n_(P + H)}" x2="${n_(P + 2 * W)}" y2="${P}" stroke="#0D99FF" stroke-width=".6" opacity=".6"/><line x1="${P}" y1="${P}" x2="${n_(P + 2 * W)}" y2="${n_(P + H)}" stroke="#0D99FF" stroke-width=".6" opacity=".6"/>`;
      return `<svg width="${n_(2 * W + 2 * P)}" height="${n_(H + 2 * P)}" viewBox="0 0 ${n_(2 * W + 2 * P)} ${n_(H + 2 * P)}">${s}</svg>`;
    }
    s += pageR(P, false);
    return `<svg width="${n_(W + 2 * P)}" height="${n_(H + 2 * P)}" viewBox="0 0 ${n_(W + 2 * P)} ${n_(H + 2 * P)}">${s}</svg>`;
  };

  // ---------- dialog ----------
  SZ.dialog = () => {
    let targets = pagesOf();
    const pg = model.page();
    const ref = targets[0];
    if (!ref) return O.toast('Виділіть сторінку чи фрейм або відкрийте сторінку публікації');
    const last = O.ls.get('satzLast', {});
    const facing = !!(pg.pub && pg.pub.facing) || !!(ref.print && ref.print.side);
    const bl = (pg.pub && pg.pub.baseline) || S.doc.baseline || { step: 12, start: 0 };
    const mm = v => O.fmt(v / MM, 2);
    const cur = (ref.print && ref.print.margins) || { t: 0, b: 0, i: 0, o: 0 };
    const d = ui.dialog({
      title: 'Satzspiegel (конструкція полів)',
      body: `<div class="sz"><div class="sz-pv"></div><div class="sz-info"></div></div><div class="dlg-text">${esc(t('Satzspiegel — площа набору на сторінці. Поля: корінець (Bund), верх (Kopf), зовнішнє (Außen), низ (Fuß). Класичні побудови дають гармонійні пропорції сторінки й тексту.'))}</div>`,
      fields: [
        { key: 'method', label: 'Побудова', type: 'select', value: last.method || 'nine', options: SZ.METHODS },
        { key: 'n', label: 'n (кількість частин)', type: 'number', value: last.n || 10, min: 3, max: 30 },
        { key: 'inner', label: 'Корінець для діагональної побудови', type: 'number', value: last.inner || O.fmt(ref.w / 9 / MM, 1), unit: 'мм' },
        { key: 'area', label: 'Площа набору, % сторінки', type: 'number', value: last.area || 50, min: 20, max: 95 },
        { key: 'ri', label: 'Співвідношення: корінець', type: 'number', value: last.ri || 2 },
        { key: 'rt', label: 'Співвідношення: верх', type: 'number', value: last.rt || 3 },
        { key: 'ro', label: 'Співвідношення: зовнішнє', type: 'number', value: last.ro || 4 },
        { key: 'rb', label: 'Співвідношення: низ', type: 'number', value: last.rb || 6 },
        { key: 'mi', label: 'Корінець (Bund)', type: 'number', value: mm(cur.i), unit: 'мм' },
        { key: 'mt', label: 'Верх (Kopf)', type: 'number', value: mm(cur.t), unit: 'мм' },
        { key: 'mo', label: 'Зовнішнє (Außen)', type: 'number', value: mm(cur.o), unit: 'мм' },
        { key: 'mb', label: 'Низ (Fuß)', type: 'number', value: mm(cur.b), unit: 'мм' },
        { key: 'cols', label: 'Колонок', type: 'number', value: (ref.print && ref.print.cols) || last.cols || 1, min: 1, max: 12 },
        { key: 'gutter', label: 'Проміжок між колонками', type: 'number', value: last.gutter === undefined ? 4 : last.gutter, unit: 'мм' },
        { key: 'reg', label: 'Registerhaltigkeit: висота набору кратна базовій сітці', type: 'checkbox', value: last.reg !== false },
        { key: 'step', label: 'Крок базової сітки', type: 'number', value: bl.step || 12, unit: 'pt' },
        { key: 'lines', label: 'Показувати лінії побудови на сторінках', type: 'checkbox', value: last.lines !== false },
        { key: 'all', label: 'Застосувати до всіх сторінок і шаблонів публікації', type: 'checkbox', value: !!pg.pub }
      ],
      buttons: [{ id: 'ok', label: 'Застосувати', primary: true }],
      onOk: v => {
        O.ls.set('satzLast', v);
        if (v.all && pg.pub) targets = allPubFrames();
        const res = calc(v);
        for (const f of targets) {
          const mg = targets.length && (f.w !== ref.w || f.h !== ref.h) ? calcFor(v, f.w, f.h) : res;
          f.print = Object.assign(f.print || { bleed: 0 }, { margins: { t: Math.round(mg.t * 100) / 100, b: Math.round(mg.b * 100) / 100, i: Math.round(mg.i * 100) / 100, o: Math.round(mg.o * 100) / 100 }, cols: Math.max(1, Math.round(v.cols || 1)), gutter: (v.gutter || 0) * MM, satz: { method: v.method, lines: !!v.lines } });
        }
        if (v.reg) { const nb = { step: Math.max(1, v.step), start: Math.round(res.t * 100) / 100 }; if (pg.pub) pg.pub.baseline = nb; else S.doc.baseline = nb; }
        O.history.commit('Satzspiegel');
        O.requestOverlay();
        O.toast('Satzspiegel: площа набору {p}% сторінки', { p: Math.round(SZ.areaShare(ref.w, ref.h, res) * 100) });
      }
    });
    d.el.querySelector('.dlg').classList.add('wide', 'two-col', 'sz-dlg');
    const calcFor = (v, w, h) => { let mg = SZ.compute(w, h, { method: v.method, n: v.n, inner: v.inner * MM, area: v.area / 100, ri: v.ri, rt: v.rt, ro: v.ro, rb: v.rb, mi: v.mi * MM, mt: v.mt * MM, mo: v.mo * MM, mb: v.mb * MM }); if (v.reg) mg = SZ.register(h, mg, v.step); return mg; };
    const calc = v => calcFor(v, ref.w, ref.h);
    const read = () => { const v = {}; d.el.querySelectorAll('[data-k]').forEach(el => { v[el.dataset.k] = el.type === 'checkbox' ? el.checked : el.type === 'number' ? parseFloat(el.value) || 0 : el.value; }); return v; };
    const show = (k, on) => { const el = d.el.querySelector(`[data-k="${k}"]`); if (el) { const row = el.closest('.dlg-row') || el.parentElement; row.hidden = !on; } };
    const upd = () => {
      const v = read(), m = v.method;
      show('n', m === 'ndiv'); show('inner', m === 'diagonal'); show('area', ['golden', 'canon', 'ratio'].includes(m));
      ['ri', 'rt', 'ro', 'rb'].forEach(k => show(k, m === 'ratio'));
      const mg = calc(v);
      // manual fields always show the result (editable in «Manual»)
      if (m !== 'manual') { const set = (k, val) => { const el = d.el.querySelector(`[data-k="${k}"]`); if (el && document.activeElement !== el) el.value = O.fmt(val / MM, 2); }; set('mi', mg.i); set('mt', mg.t); set('mo', mg.o); set('mb', mg.b); }
      ['mi', 'mt', 'mo', 'mb'].forEach(k => { const el = d.el.querySelector(`[data-k="${k}"]`); if (el) el.readOnly = m !== 'manual'; });
      d.el.querySelector('.sz-pv').innerHTML = preview(ref.w, ref.h, mg, { facing, lines: v.lines, cols: v.cols, gutter: v.gutter * MM, step: v.reg ? v.step : 0 });
      const tw = ref.w - mg.i - mg.o, th = ref.h - mg.t - mg.b;
      d.el.querySelector('.sz-info').innerHTML = `<b>${esc(t('Сторінка'))}</b> ${O.fmt(ref.w / MM, 1)} × ${O.fmt(ref.h / MM, 1)} ${esc(t('мм'))}<br><b>${esc(t('Площа набору'))}</b> ${O.fmt(tw / MM, 1)} × ${O.fmt(th / MM, 1)} ${esc(t('мм'))} · ${Math.round(SZ.areaShare(ref.w, ref.h, mg) * 100)}%<br><b>${esc(t('Поля'))}</b> ${esc(t('корінець'))} ${O.fmt(mg.i / MM, 1)} · ${esc(t('верх'))} ${O.fmt(mg.t / MM, 1)} · ${esc(t('зовнішнє'))} ${O.fmt(mg.o / MM, 1)} · ${esc(t('низ'))} ${O.fmt(mg.b / MM, 1)} ${esc(t('мм'))}${v.reg ? `<br><b>${esc(t('Рядків базової сітки'))}</b> ${Math.round(th / v.step)}` : ''}<br><em>${esc(t('Застосовується до: {n}', { n: (v.all && pg.pub ? allPubFrames() : targets).length }))}</em>`;
    };
    d.el.addEventListener('input', upd);
    d.el.addEventListener('change', upd);
    upd();
  };

  // ---------- construction lines on the canvas ----------
  O.overlayHooks.push(Vm => {
    if (!S.doc || S.settings.printGuides === false) return '';
    let s = '';
    for (const f of model.page().children) {
      if (f.type !== 'frame' || !f.print || !f.print.satz || !f.print.satz.lines || f.visible === false) continue;
      const W = M.mul(Vm, f.m);
      const P = (x, y) => { const p = M.apply(W, { x, y }); return n_(p.x) + ' ' + n_(p.y); };
      const left = f.print.side === 'left', w = f.w, h = f.h;
      // page diagonal from the spine top to the outer bottom, and the spread diagonal through the outer top corner
      const spine = left ? w : 0, outer = left ? 0 : w;
      s += `<path d="M${P(spine, 0)}L${P(outer, h)}" stroke="#E040FB" stroke-width="1" stroke-opacity=".45" fill="none" pointer-events="none"/>`;
      s += `<path d="M${P(spine, h / 2)}L${P(outer, 0)}" stroke="#0D99FF" stroke-width="1" stroke-opacity=".45" fill="none" pointer-events="none"/>`;
      if (f.print.satz.method === 'nine' || f.print.satz.method === 'twelve') {
        const n = f.print.satz.method === 'nine' ? 9 : 12;
        let d = '';
        for (let i = 1; i < n; i++) d += `M${P(w * i / n, 0)}L${P(w * i / n, h)}M${P(0, h * i / n)}L${P(w, h * i / n)}`;
        s += `<path d="${d}" stroke="#9747FF" stroke-width="1" stroke-opacity=".18" fill="none" pointer-events="none"/>`;
      }
    }
    return s;
  });

  O.cmd('pubSatz', 'Satzspiegel (конструкція полів)…', () => SZ.dialog(), { keys: ['Ctrl+Alt+Shift+G'], group: 'Публікація' });
  const pm = O.MENUS.find(m => m[0] === 'Публікація');
  if (pm) { const i = pm[1].indexOf('pubMargins'); pm[1].splice(i >= 0 ? i + 1 : pm[1].length, 0, 'pubSatz'); }
})();
