'use strict';
/* VIBSma — SVG renderer (canvas + export) */
(function () {
  const O = window.O, M = O.M, G = O.G, R = O.R, model = O.model, S = O.state;
  const n_ = O.n, esc = O.esc;

  // ---------- assets ----------
  const blobCache = new Map();
  const dataToBlob = d => {
    const [head, body] = d.split(',');
    const mime = (/:(.*?);/.exec(head) || [])[1] || 'application/octet-stream';
    const bin = atob(body);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: mime });
  };
  O.dataToBlob = dataToBlob;
  O.assetURL = (id, forExport) => {
    const a = S.doc.assets[id];
    if (!a) return '';
    if (forExport) return a.data;
    let u = blobCache.get(id);
    if (!u) {
      try { u = URL.createObjectURL(dataToBlob(a.data)); } catch (e) { u = a.data; }
      blobCache.set(id, u);
    }
    return u;
  };

  // small JPEG copy of an image asset (thumbnails, previews): never decodes the full photo twice
  const previews = new Map();
  O.assetPreview = (id, max = 480) => {
    const key = id + '@' + max;
    if (!previews.has(key)) {
      previews.set(key, (async () => {
        const a = S.doc.assets[id];
        if (!a || !a.data || !/^data:image\//.test(a.data)) return a && a.data ? a.data : '';
        if (Math.max(a.w || 0, a.h || 0) <= max && a.data.length < 400000) return a.data;
        const img = await O.io.loadImage(O.assetURL(id), 15000);
        const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
        const cv = document.createElement('canvas');
        cv.width = Math.max(1, Math.round(img.naturalWidth * k)); cv.height = Math.max(1, Math.round(img.naturalHeight * k));
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        return cv.toDataURL(/png|webp|gif|svg/.test(a.data.slice(0, 30)) ? 'image/png' : 'image/jpeg', 0.85);
      })().catch(() => ''));
      if (previews.size > 400) previews.delete(previews.keys().next().value);
    }
    return previews.get(key);
  };
  const newCtx = opts =>Object.assign({ defs: [], pfx: '', hit: true, exp: false, hitId: null, hide: null, depth: 0, zoom: 1 }, opts);

  // ---------- paints ----------
  const stopsMarkup = stops => stops.slice().sort((a, b) => a.o - b.o)
    .map(s => `<stop offset="${n_(s.o)}" stop-color="${s.color}"${(s.a === undefined ? 1 : s.a) < 1 ? ` stop-opacity="${n_(s.a)}"` : ''}/>`).join('');
  function paintRef(p, n, ctx, key) {
    if (p.type === 'solid') return { paint: p.color, op: p.opacity === undefined ? 1 : p.opacity };
    const b = model.localBounds(n);
    const id = ctx.pfx + 'p' + n.id + key;
    const bw = Math.max(b.w, 1e-3), bh = Math.max(b.h, 1e-3);
    const gt = `matrix(${n_(bw)} 0 0 ${n_(bh)} ${n_(b.x)} ${n_(b.y)})`;
    if (p.type === 'linear') {
      ctx.defs.push(`<linearGradient id="${id}" gradientUnits="userSpaceOnUse" gradientTransform="${gt}" x1="${n_(p.from.x)}" y1="${n_(p.from.y)}" x2="${n_(p.to.x)}" y2="${n_(p.to.y)}">${stopsMarkup(p.stops)}</linearGradient>`);
    } else if (p.type === 'radial') {
      const r = Math.max(1e-4, Math.hypot(p.to.x - p.from.x, p.to.y - p.from.y));
      ctx.defs.push(`<radialGradient id="${id}" gradientUnits="userSpaceOnUse" gradientTransform="${gt}" cx="${n_(p.from.x)}" cy="${n_(p.from.y)}" r="${n_(r)}">${stopsMarkup(p.stops)}</radialGradient>`);
    } else if (p.type === 'image') {
      const a = S.doc.assets[p.asset] || { w: 100, h: 100 };
      const href = esc(ctx.assetURL ? ctx.assetURL(p.asset) : O.assetURL(p.asset, ctx.exp));
      const hr = ctx.exp ? `href="${href}" xlink:href="${href}"` : `href="${href}"`;
      // Figma: rotation in 90° steps, crop = zoom + position inside the shape
      const rot = (((p.rot || 0) % 360) + 360) % 360;
      if (p.mode === 'tile') {
        const iw = Math.max(1, (a.w || 100) * (p.scale || 1)), ih = Math.max(1, (a.h || 100) * (p.scale || 1));
        ctx.defs.push(`<pattern id="${id}" patternUnits="userSpaceOnUse" x="${n_(b.x)}" y="${n_(b.y)}" width="${n_(iw)}" height="${n_(ih)}"${rot ? ` patternTransform="rotate(${rot} ${n_(b.x)} ${n_(b.y)})"` : ''}><image ${hr} width="${n_(iw)}" height="${n_(ih)}" preserveAspectRatio="none"/></pattern>`);
      } else {
        // a quarter turn swaps the box the image is laid into
        const side = rot === 90 || rot === 270;
        const iw = side ? bh : bw, ih = side ? bw : bh, ix = (bw - iw) / 2, iy = (bh - ih) / 2;
        const tr = rot ? ` transform="rotate(${rot} ${n_(bw / 2)} ${n_(bh / 2)})"` : '';
        let img;
        if (p.mode === 'crop') {
          const cr = p.crop || {}, z = Math.max(1, cr.z || 1), aw = a.w || 100, ah = a.h || 100;
          const k = Math.max(iw / aw, ih / ah) * z, dw = aw * k, dh = ah * k;
          const cx = cr.x === undefined ? 0.5 : cr.x, cy = cr.y === undefined ? 0.5 : cr.y;
          img = `<image ${hr} x="${n_(ix + (iw - dw) * cx)}" y="${n_(iy + (ih - dh) * cy)}" width="${n_(dw)}" height="${n_(dh)}" preserveAspectRatio="none"${tr}/>`;
        } else {
          const par = p.mode === 'fit' ? 'xMidYMid meet' : p.mode === 'stretch' ? 'none' : 'xMidYMid slice';
          img = `<image ${hr} x="${n_(ix)}" y="${n_(iy)}" width="${n_(iw)}" height="${n_(ih)}" preserveAspectRatio="${par}"${tr}/>`;
        }
        ctx.defs.push(`<pattern id="${id}" patternUnits="userSpaceOnUse" x="${n_(b.x)}" y="${n_(b.y)}" width="${n_(bw)}" height="${n_(bh)}">${img}</pattern>`);
      }
    }
    return { paint: `url(#${id})`, op: p.opacity === undefined ? 1 : p.opacity };
  }
  O.paintColor = p => !p ? '#000000' : p.type === 'solid' ? p.color : (p.stops && p.stops[0] ? p.stops[0].color : '#888888');

  // ---------- markers (arrowheads) ----------
  const MARKERS = {
    arrow: { body: c => `<path d="M1 1L9 5L1 9" fill="none" stroke="${c}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>`, ref: 8.5 },
    triangle: { body: c => `<path d="M0 0L10 5L0 10Z" fill="${c}"/>`, ref: 6 },
    circle: { body: c => `<circle cx="5" cy="5" r="4.5" fill="${c}"/>`, ref: 5 },
    square: { body: c => `<rect x="1" y="1" width="8" height="8" fill="${c}"/>`, ref: 5 },
    diamond: { body: c => `<path d="M5 0L10 5L5 10L0 5Z" fill="${c}"/>`, ref: 5 },
    bar: { body: c => `<rect x="4" y="0" width="2" height="10" fill="${c}"/>`, ref: 5 }
  };
  O.MARKERS = MARKERS;
  function markerAttrs(n, ctx, color) {
    let out = '';
    const size = Math.max(n.sw * 4, 8);
    const mk = (type, which) => {
      const def = MARKERS[type];
      if (!def) return;
      const id = ctx.pfx + 'm' + which + n.id;
      ctx.defs.push(`<marker id="${id}" viewBox="0 0 10 10" refX="${def.ref}" refY="5" markerUnits="userSpaceOnUse" markerWidth="${n_(size)}" markerHeight="${n_(size)}" orient="auto-start-reverse">${def.body(color)}</marker>`);
      out += ` marker-${which === 's' ? 'start' : 'end'}="url(#${id})"`;
    };
    if (n.ms && n.ms !== 'none') mk(n.ms, 's');
    if (n.me && n.me !== 'none') mk(n.me, 'e');
    return out;
  }

  // ---------- effects ----------
  // effects drawn by their own renderers (Liquid Glass) instead of the SVG filter chain
  const OWN_FX = new Set(['bgblur', 'glass']);
  function filterAttr(n, ctx) {
    const fx = (n.effects || []).filter(e => e.visible !== false && !OWN_FX.has(e.type));
    const adj = O.photoAdjustPrims ? O.photoAdjustPrims(n) : '';
    if (!fx.length && !adj) return '';
    const id = ctx.pfx + 'fx' + n.id;
    let b = model.localBounds(n);
    if (n.type === 'frame' && !n.clip) b = R.union(b, model.childrenBounds(n, M.id()));
    let margin = (n.sw || 0) * 2 + 4;
    for (const e of fx) margin = Math.max(margin, (e.blur || 0) * 2 + Math.abs(e.x || 0) + Math.abs(e.y || 0) + Math.abs(e.spread || 0) + (n.sw || 0) * 2 + 4);
    const r = R.expand(b, margin);
    let prims = adj, below = [], above = [];
    // photo adjustments (brightness, contrast…) come first and feed every other effect
    let src = adj ? 'adj' : 'SourceGraphic';
    fx.forEach((e, i) => {
      const col = e.color || '#000000', op = e.opacity === undefined ? 0.25 : e.opacity;
      const sd = n_(Math.max(0, (e.blur || 0) / 2));
      if (e.type === 'shadow' || e.type === 'glow') {
        const dx = e.type === 'glow' ? 0 : (e.x || 0), dy = e.type === 'glow' ? 0 : (e.y || 0);
        let srcA = 'SourceAlpha';
        if (e.spread) { prims += `<feMorphology in="SourceAlpha" operator="${e.spread > 0 ? 'dilate' : 'erode'}" radius="${n_(Math.abs(e.spread))}" result="sp${i}"/>`; srcA = 'sp' + i; }
        prims += `<feGaussianBlur in="${srcA}" stdDeviation="${sd}" result="bl${i}"/><feOffset in="bl${i}" dx="${n_(dx)}" dy="${n_(dy)}" result="of${i}"/><feFlood flood-color="${col}" flood-opacity="${n_(op)}" result="fl${i}"/><feComposite in="fl${i}" in2="of${i}" operator="in" result="ds${i}"/>`;
        below.push('ds' + i);
      } else if (e.type === 'inner' || e.type === 'innerglow') {
        const dx = e.type === 'innerglow' ? 0 : (e.x || 0), dy = e.type === 'innerglow' ? 0 : (e.y || 0);
        prims += `<feOffset in="SourceAlpha" dx="${n_(dx)}" dy="${n_(dy)}" result="io${i}"/><feGaussianBlur in="io${i}" stdDeviation="${sd}" result="ib${i}"/><feComposite in="SourceAlpha" in2="ib${i}" operator="arithmetic" k2="1" k3="-1" result="id${i}"/><feFlood flood-color="${col}" flood-opacity="${n_(op)}" result="if${i}"/><feComposite in="if${i}" in2="id${i}" operator="in" result="is${i}"/>`;
        above.push('is' + i);
      } else if (e.type === 'blur') {
        prims += `<feGaussianBlur in="${src}" stdDeviation="${sd}" result="lb${i}"/>`;
        src = 'lb' + i;
      }
    });
    const merge = below.concat([src], above).map(x => `<feMergeNode in="${x}"/>`).join('');
    ctx.defs.push(`<filter id="${id}" filterUnits="userSpaceOnUse" x="${n_(r.x)}" y="${n_(r.y)}" width="${n_(r.w)}" height="${n_(r.h)}" color-interpolation-filters="sRGB">${prims}<feMerge>${merge}</feMerge></filter>`);
    return ` filter="url(#${id})"`;
  }

  // ---------- geometry ----------
  function geo(n) {
    switch (n.type) {
      case 'rect': case 'frame': case 'instance': {
        const r = n.radius;
        if (Array.isArray(r) && !(r[0] === r[1] && r[1] === r[2] && r[2] === r[3])) return { tag: 'path', attrs: `d="${G.toD(G.rectSub(n.w, n.h, r))}"` };
        const rr = Math.min(Array.isArray(r) ? r[0] : (r || 0), Math.min(n.w, n.h) / 2);
        return { tag: 'rect', attrs: `width="${n_(n.w)}" height="${n_(n.h)}"${rr > 0 ? ` rx="${n_(rr)}" ry="${n_(rr)}"` : ''}` };
      }
      case 'ellipse': return { tag: 'ellipse', attrs: `cx="${n_(n.w / 2)}" cy="${n_(n.h / 2)}" rx="${n_(n.w / 2)}" ry="${n_(n.h / 2)}"` };
      case 'polygon': case 'star': return { tag: 'path', attrs: `d="${G.toD(G.shapeSubs(n))}"` };
      case 'path': return { tag: 'path', attrs: `d="${G.toD(n.subpaths)}"${n.fillRule === 'evenodd' ? ' fill-rule="evenodd"' : ''}` };
      case 'bool': return { tag: 'path', attrs: `d="${G.toD(model.boolResult(n))}"` };
    }
    return null;
  }
  O.geo = geo;
  const isOpen = n => n.type === 'path' && n.subpaths.some(sp => !sp.closed);
  function strokeCommon(n, w) {
    let s = ` stroke-width="${n_(w)}"`;
    if (n.cap && n.cap !== 'butt') s += ` stroke-linecap="${n.cap}"`;
    if (n.join && n.join !== 'miter') s += ` stroke-linejoin="${n.join}"`;
    else if (n.miter && n.miter !== 4) s += ` stroke-miterlimit="${n_(n.miter)}"`;
    const ts = n.trimS === undefined ? 0 : n.trimS, te = n.trimE === undefined ? 1 : n.trimE;
    if (ts > 0.0001 || te < 0.9999) {
      // trim paths (animated line drawing): normalised path length with a single dash
      const len = Math.max(0, te - ts);
      s += ` pathLength="1" stroke-dasharray="${n_(len)} ${n_(1 + len)}" stroke-dashoffset="${n_(-ts)}"`;
    } else if (n.dash && n.dash.length) s += ` stroke-dasharray="${n.dash.map(n_).join(' ')}"`;
    return s;
  }
  function paintLayers(n, ctx, g, opt = {}) {
    if (!g) return '';
    const useFills = opt.fills !== false, useStrokes = opt.strokes !== false;
    const fills = useFills ? (n.fills || []).filter(p => p.visible !== false) : [];
    const strokes = useStrokes && n.sw > 0 ? (n.strokes || []).filter(p => p.visible !== false) : [];
    const open = isOpen(n);
    const align = open ? 'center' : (n.sa || 'center');
    const markers = open && strokes.length && ((n.ms && n.ms !== 'none') || (n.me && n.me !== 'none')) ? markerAttrs(n, ctx, O.paintColor(strokes[strokes.length - 1])) : '';
    const tag = g.tag, ga = g.attrs;
    let out = '';
    if (fills.length <= 1 && strokes.length <= 1 && (align === 'center' || !strokes.length)) {
      const f = fills[0] ? paintRef(fills[0], n, ctx, 'f0') : null;
      const s = strokes[0] ? paintRef(strokes[0], n, ctx, 's0') : null;
      out += `<${tag} ${ga} fill="${f ? f.paint : 'none'}"${f && f.op < 1 ? ` fill-opacity="${n_(f.op)}"` : ''}`;
      if (s) out += ` stroke="${s.paint}"${s.op < 1 ? ` stroke-opacity="${n_(s.op)}"` : ''}${strokeCommon(n, n.sw)}${markers}`;
      out += '/>';
    } else {
      fills.forEach((p, i) => {
        const f = paintRef(p, n, ctx, 'f' + i);
        out += `<${tag} ${ga} fill="${f.paint}"${f.op < 1 ? ` fill-opacity="${n_(f.op)}"` : ''}/>`;
      });
      strokes.forEach((p, i) => {
        const s = paintRef(p, n, ctx, 's' + i);
        const sa = `fill="none" stroke="${s.paint}"${s.op < 1 ? ` stroke-opacity="${n_(s.op)}"` : ''}`;
        if (align === 'inside') {
          const cid = ctx.pfx + 'ci' + n.id;
          if (i === 0) ctx.defs.push(`<clipPath id="${cid}"><${tag} ${ga}/></clipPath>`);
          out += `<${tag} ${ga} ${sa}${strokeCommon(n, n.sw * 2)} clip-path="url(#${cid})"/>`;
        } else if (align === 'outside') {
          const mid = ctx.pfx + 'co' + n.id;
          if (i === 0) ctx.defs.push(`<mask id="${mid}" maskUnits="userSpaceOnUse" x="-100000" y="-100000" width="200000" height="200000"><rect x="-100000" y="-100000" width="200000" height="200000" fill="#fff"/><${tag} ${ga} fill="#000"/></mask>`);
          out += `<${tag} ${ga} ${sa}${strokeCommon(n, n.sw * 2)} mask="url(#${mid})"/>`;
        } else {
          out += `<${tag} ${ga} ${sa}${strokeCommon(n, n.sw)}${i === strokes.length - 1 ? markers : ''}/>`;
        }
      });
    }
    if (ctx.hit && opt.hit !== false && (!fills.length || open)) {
      out += `<${tag} ${ga} fill="none" stroke="transparent" stroke-width="${n_(Math.max(n.sw || 0, 8 / ctx.zoom))}" pointer-events="stroke"/>`;
    }
    return out;
  }

  // ---------- text ----------
  // automatic page number (master pages): «#» becomes the number of the page frame being drawn
  const autoNum = (n, ctx, s) => (n.autoNum ? String(s).replace(/#/g, ctx.pageNum === undefined || ctx.pageNum === null ? '#' : ctx.pageNum) : s);
  function textMarkup(n, ctx) {
    // area / point text: InDesign-style typesetting engine (typeset.js)
    if (!n.path && O.typeset) return O.typeset.markup(n, ctx, { paintRef, strokeCommon });
    const fills = (n.fills || []).filter(p => p.visible !== false);
    const strokes = n.sw > 0 ? (n.strokes || []).filter(p => p.visible !== false) : [];
    let base = `font-family="${esc(O.text.family(n.font))}" font-size="${n_(n.size)}"`;
    if (n.weight && n.weight !== 400) base += ` font-weight="${n.weight}"`;
    if (n.italic) base += ' font-style="italic"';
    if (n.ls) base += ` letter-spacing="${n_(n.ls)}"`;
    if (n.deco && n.deco !== 'none') base += ` text-decoration="${n.deco}"`;
    base += ' xml:space="preserve"';
    let content, hit = '';
    if (n.path) {
      const pid = ctx.pfx + 'tp' + n.id;
      const d = G.toD(n.path);
      ctx.defs.push(`<path id="${pid}" d="${d}"/>`);
      content = `<textPath href="#${pid}"${ctx.exp ? ` xlink:href="#${pid}"` : ''} startOffset="${n_(n.pathOffset || 0)}%">${esc(autoNum(n, ctx, O.text.content(n)))}</textPath>`;
      if (ctx.hit) hit = `<path d="${d}" fill="none" stroke="transparent" stroke-width="${n_(Math.max(n.size, 8 / ctx.zoom))}" pointer-events="stroke"/>`;
    } else {
      const L = O.text.layout(n);
      const anchor = n.align === 'center' ? 'middle' : n.align === 'right' ? 'end' : 'start';
      const x = n.align === 'center' ? L.w / 2 : n.align === 'right' ? L.w : 0;
      if (anchor !== 'start') base += ` text-anchor="${anchor}"`;
      // text frame with a fixed height: overset lines are hidden (InDesign)
      const lines = n.boxH ? L.lines.slice(0, Math.max(1, Math.floor(n.boxH / L.lh + 1e-6))) : L.lines;
      content = lines.map(l => {
        const just = n.align === 'justify' && !l.last && l.t.trim() && n.width;
        return `<tspan x="${n_(just ? 0 : x)}" y="${n_(l.y)}"${just ? ` textLength="${n_(L.w)}" lengthAdjust="spacing"` : ''}>${esc(autoNum(n, ctx, l.t))}</tspan>`;
      }).join('');
      if (ctx.hit) hit = `<rect width="${n_(L.w)}" height="${n_(n.boxH || L.h)}" fill="none" pointer-events="all"/>`;
    }
    let out = '';
    if (fills.length <= 1 && strokes.length <= 1) {
      const f = fills[0] ? paintRef(fills[0], n, ctx, 'f0') : null;
      const s = strokes[0] ? paintRef(strokes[0], n, ctx, 's0') : null;
      out = `<text ${base} fill="${f ? f.paint : 'none'}"${f && f.op < 1 ? ` fill-opacity="${n_(f.op)}"` : ''}${s ? ` stroke="${s.paint}"${s.op < 1 ? ` stroke-opacity="${n_(s.op)}"` : ''}${strokeCommon(n, n.sw)} paint-order="stroke"` : ''}>${content}</text>`;
    } else {
      strokes.forEach((p, i) => { const s = paintRef(p, n, ctx, 's' + i); out += `<text ${base} fill="none" stroke="${s.paint}"${strokeCommon(n, n.sw)}>${content}</text>`; });
      fills.forEach((p, i) => { const f = paintRef(p, n, ctx, 'f' + i); out += `<text ${base} fill="${f.paint}"${f.op < 1 ? ` fill-opacity="${n_(f.op)}"` : ''}>${content}</text>`; });
    }
    return hit + out;
  }

  // ---------- containers ----------
  function clipShapes(node, m) {
    if (node.visible === false) return '';
    if (node.type === 'group' && !node.mask) return node.children.map(c => clipShapes(c, M.mul(m, c.m))).join('');
    const subs = model.subsIn(node, m);
    return `<path d="${G.toD(subs)}"${node.fillRule === 'evenodd' ? ' clip-rule="evenodd"' : ''}/>`;
  }
  function groupMarkup(n, ctx) {
    if (n.mask && n.children.length > 1) {
      const mk = n.children[0];
      const cid = ctx.pfx + 'mk' + n.id;
      ctx.defs.push(`<clipPath id="${cid}">${clipShapes(mk, mk.m)}</clipPath>`);
      return `<g clip-path="url(#${cid})">${n.children.slice(1).map(c => nodeMarkup(c, ctx)).join('')}</g>`;
    }
    return n.children.map(c => nodeMarkup(c, ctx)).join('');
  }
  function frameMarkup(n, ctx) {
    const g = geo(n);
    let out = paintLayers(n, ctx, g, { strokes: false, hit: false });
    if (ctx.hit) out += `<${g.tag} ${g.attrs} fill="none" pointer-events="all"/>`;
    // publication pages pass their number down to master-page instances and «#» page-number texts
    const prevNum = ctx.pageNum;
    if (n.print && n.print.num !== undefined && n.print.num !== null) ctx.pageNum = n.print.num;
    else if (n.print && n.print.label && (ctx.pageNum === undefined || ctx.pageNum === null)) ctx.pageNum = n.print.label;
    let kids = n.children.map(c => nodeMarkup(c, ctx)).join('');
    ctx.pageNum = prevNum;
    if (n.clip && kids) {
      const cid = ctx.pfx + 'fc' + n.id;
      ctx.defs.push(`<clipPath id="${cid}"><${g.tag} ${g.attrs}/></clipPath>`);
      kids = `<g clip-path="url(#${cid})">${kids}</g>`;
    }
    out += kids;
    out += paintLayers(n, ctx, g, { fills: false, hit: false });
    return out;
  }
  function instanceMarkup(n, ctx) {
    const comp = model.get(n.ref);
    if (!comp || comp.type !== 'frame' || ctx.depth > 5) {
      return `<rect width="${n_(n.w)}" height="${n_(n.h)}" fill="${comp ? 'none' : 'rgba(242,72,34,.08)'}" stroke="#F24822" stroke-dasharray="4 4" vector-effect="non-scaling-stroke"/>`;
    }
    const sx = comp.w ? n.w / comp.w : 1, sy = comp.h ? n.h / comp.h : 1;
    const sub = Object.assign({}, ctx, { hitId: ctx.hitId || (ctx.exp ? null : n.id), pfx: ctx.pfx + 'i' + n.id + '_', depth: ctx.depth + 1 });
    sub.defs = ctx.defs;
    // instance overrides (text, visibility, colour of layers), keyed by layer name path
    const src = n.ov && O.components && Object.keys(n.ov).length ? O.components.applyOv(comp, n.ov) : comp;
    return `<g transform="scale(${n_(sx)} ${n_(sy)})">${frameMarkup(src, sub)}</g>`;
  }

  function nodeMarkup(n, ctx) {
    if (n.visible === false) return '';
    if (ctx.hide && ctx.hide === n.id) return '';
    if (n.span && O.anim && O.anim.hiddenNow(n)) return '';
    let a = '<g';
    if (!ctx.exp && !ctx.ghost) a += ` data-id="${ctx.hitId || n.id}"`;
    if (!M.isId(n.m)) a += ` transform="${M.str(n.m)}"`;
    if (n.opacity !== undefined && n.opacity < 1) a += ` opacity="${n_(n.opacity)}"`;
    if (n.blend && n.blend !== 'normal') a += ` style="mix-blend-mode:${n.blend}"`;
    a += filterAttr(n, ctx);
    if (n.locked && ctx.hit) a += ' pointer-events="none"';
    a += '>';
    let inner = '';
    switch (n.type) {
      case 'rect': case 'ellipse': case 'polygon': case 'star': case 'path': case 'bool':
        inner = paintLayers(n, ctx, geo(n)); break;
      case 'text': inner = textMarkup(n, ctx); break;
      case 'group': inner = groupMarkup(n, ctx); break;
      case 'frame': inner = frameMarkup(n, ctx); break;
      case 'instance': inner = instanceMarkup(n, ctx); break;
      case 'raster': inner = rasterMarkup(n, ctx); break;
    }
    // module renderers (Liquid Glass backdrop, media badges): markup under and over the node's own paint
    let pre = '', post = '';
    for (const hk of fxHooks) {
      try { const r = hk(n, ctx); if (r) { pre += r.pre || ''; post += r.post || ''; } } catch (e) { console.error(e); }
    }
    return a + pre + inner + post + '</g>';
  }
  const fxHooks = [];
  // pixel layer: bitmap stretched to w×h (a live canvas preview replaces it while painting)
  function rasterMarkup(n, ctx) {
    const live = !ctx.exp && O.raster && O.raster.liveURL ? O.raster.liveURL(n.id) : null;
    const url = live || (n.asset ? (ctx.assetURL ? ctx.assetURL(n.asset) : O.assetURL(n.asset, ctx.exp)) : '');
    let s = '';
    if (url) {
      const href = esc(url);
      s += `<image ${ctx.exp ? `href="${href}" xlink:href="${href}"` : `href="${href}"`} width="${n_(n.w)}" height="${n_(n.h)}" preserveAspectRatio="none"/>`;
    }
    if (ctx.hit) s += `<rect width="${n_(n.w)}" height="${n_(n.h)}" fill="none" pointer-events="all"/>`;
    return s;
  }

  // visual padding (strokes/effects) for export bounds
  function visualPad(n) {
    let p = 0;
    if ((n.strokes || []).some(s => s.visible !== false) && n.sw > 0) {
      p = n.sa === 'outside' ? n.sw : n.sa === 'inside' ? 0 : n.sw / 2;
      if (n.join === 'miter' && n.type === 'path') p *= Math.min(n.miter || 4, 4);
      if ((n.ms && n.ms !== 'none') || (n.me && n.me !== 'none')) p = Math.max(p, Math.max(n.sw * 4, 8) / 2);
    }
    for (const e of (n.effects || [])) if (e.visible !== false && e.type !== 'inner' && e.type !== 'innerglow' && !OWN_FX.has(e.type)) p = Math.max(p, (e.blur || 0) * 1.5 + Math.max(Math.abs(e.x || 0), Math.abs(e.y || 0)) + Math.max(0, e.spread || 0));
    if (n.children && !(n.type === 'frame' && n.clip)) for (const c of n.children) p = Math.max(p, visualPad(c));
    return p;
  }

  O.render = {
    newCtx,
    nodeMarkup,
    fxHooks,
    visualPad: n => visualPad(n),
    page() {
      const pg = model.page();
      model.layoutAll();
      const ctx = newCtx({ zoom: O.view ? O.view.zoom : 1, hide: S.textEdit && !S.textEdit.rich ? S.textEdit.id : null });
      const body = pg.children.map(n => nodeMarkup(n, ctx)).join('');
      O.$('#doc-defs').innerHTML = ctx.defs.join('');
      O.$('#doc-root').innerHTML = body;
    },
    // standalone SVG for a list of nodes (or whole page)
    svg(nodes, opts = {}) {
      model.layoutAll();
      const pg = model.page();
      const list = nodes && nodes.length ? nodes : pg.children.filter(n => n.visible !== false);
      let b = null;
      for (const n of list) {
        const wb = model.worldBounds(n);
        if (!wb) continue;
        const fullClip = n.type === 'frame' && n.clip && !(n.effects || []).length;
        b = R.union(b, fullClip ? wb : R.expand(wb, visualPad(n)));
      }
      if (!b) b = { x: 0, y: 0, w: 1, h: 1 };
      b = { x: Math.floor(b.x), y: Math.floor(b.y), w: Math.max(1, Math.ceil(b.x + b.w) - Math.floor(b.x)), h: Math.max(1, Math.ceil(b.y + b.h) - Math.floor(b.y)) };
      const ctx = newCtx({ hit: false, exp: true, assetURL: opts.assetURL || null });
      const body = list.map(n => {
        const P = model.parentMatrix(n);
        const inner = nodeMarkup(n.visible === false ? Object.assign({}, n, { visible: true }) : n, ctx);
        return M.isId(P) ? inner : `<g transform="${M.str(P)}">${inner}</g>`;
      }).join('');
      const sc = opts.scale || 1;
      const bg = opts.bg ? `<rect x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" fill="${opts.bg}"/>` : '';
      // embedded @font-face rules (data URLs) keep web fonts in exported files
      const fontStyle = opts.fontCSS ? `<style>${opts.fontCSS.replace(/<\/?style[^>]*>/gi, '').replace(/]]>/g, '')}</style>` : '';
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${n_(b.w * sc)}" height="${n_(b.h * sc)}" viewBox="${b.x} ${b.y} ${b.w} ${b.h}">` +
        (ctx.defs.length || fontStyle ? `<defs>${fontStyle}${ctx.defs.join('')}</defs>` : '') + bg + body + '</svg>';
      return { svg, bounds: b };
    }
  };
})();
