'use strict';
/* VIBSma — account: sign up and sign in like on any site — e-mail and password (with a confirmation letter and
   password reset), or Google, or Apple. The account keeps the progress: projects and saved styles are synced
   (cloud.js, Firebase). Visitors never enter keys or client IDs — the site is connected once in js/config.js.
   Without that connection the editor still works, saving in this browser. */
(function () {
  const O = window.O, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const AC = O.account = {};
  const CL = () => O.cloud;

  AC.user = () => O.ls.get('account', null);
  AC.setUser = u => {
    O.ls.set('account', u);
    if (u && u.name) { O.ls.set('collabName', u.name); if (O.collab && O.collab.me) O.collab.me.name = u.name; }
    AC.renderButton();
    O.emit('account', u);
  };
  const MAIL = [[/@(gmail|googlemail)\.com$/i, 'google', 'Gmail'], [/@(icloud|me|mac)\.com$/i, 'apple', 'iCloud'], [/@privaterelay\.appleid\.com$/i, 'apple', 'Apple ID'], [/@(outlook|hotmail|live)\.[a-z.]+$/i, 'mail', 'Outlook'], [/@ukr\.net$/i, 'mail', 'ukr.net']];
  AC.mailKind = email => { const m = MAIL.find(([re]) => re.test(email || '')); return m ? { provider: m[1], label: m[2] } : { provider: 'mail', label: 'E-mail' }; };

  // ---------- provider logos ----------
  const G_LOGO = '<svg viewBox="0 0 48 48" width="18" height="18" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>';
  const A_LOGO = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M16.4 12.6c0-2.5 2-3.7 2.1-3.8-1.2-1.7-3-1.9-3.6-2-1.5-.2-3 .9-3.8.9-.8 0-2-.9-3.3-.9-1.7 0-3.3 1-4.2 2.5-1.8 3.1-.5 7.7 1.3 10.2.9 1.2 1.9 2.6 3.2 2.6 1.3-.1 1.8-.8 3.3-.8s2 .8 3.3.8c1.4 0 2.3-1.3 3.1-2.5 1-1.4 1.4-2.8 1.4-2.9-.1 0-2.8-1.1-2.8-4.1zM14 5.2c.7-.8 1.2-2 1-3.2-1 0-2.2.7-2.9 1.5-.6.7-1.2 1.9-1 3.1 1.1.1 2.2-.6 2.9-1.4z"/></svg>';
  AC.LOGOS = { google: G_LOGO, apple: A_LOGO };

  // ---------- top bar button ----------
  AC.renderButton = () => {
    let b = O.$('#btn-account');
    if (!b) {
      const anchor = O.$('#btn-export');
      if (!anchor) return;
      b = O.h(`<button id="btn-account" class="acct-btn" type="button"></button>`);
      anchor.parentNode.insertBefore(b, anchor);
      b.addEventListener('click', () => (AC.user() ? AC.menu(b) : AC.dialog()));
    }
    const u = AC.user();
    const label = u ? t('Обліковий запис: {name}', { name: u.name || u.email }) : t('Увійти або зареєструватися');
    b.title = label; b.setAttribute('aria-label', label);
    if (!u) { b.innerHTML = `${O.icon('user', 16)}<span class="lbl">${esc(t('Увійти'))}</span>`; b.classList.remove('in'); return; }
    const ini = String(u.name || u.email || '?').trim().split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase();
    const st = CL() && CL().status;
    b.classList.add('in');
    b.innerHTML = (u.picture ? `<img src="${esc(u.picture)}" alt="" referrerpolicy="no-referrer">` : `<span class="acct-ini">${esc(ini)}</span>`) + (u.cloud ? `<i class="acct-sync ${esc(st || 'off')}" aria-hidden="true"></i>` : '');
  };
  O.on('cloud-status', () => AC.renderButton());
  const syncLabel = () => {
    const c = CL();
    if (!c || !c.user) return t('Проєкти зберігаються лише в цьому браузері');
    if (c.status === 'sync') return t('Синхронізація…');
    if (c.status === 'error') return t('Помилка синхронізації: {msg}', { msg: c.statusMsg });
    return c.lastSync ? t('Прогрес збережено в обліковому записі · {time}', { time: new Date(c.lastSync).toLocaleTimeString(O.lang, { hour: '2-digit', minute: '2-digit' }) }) : t('Прогрес зберігається в обліковому записі');
  };
  AC.menu = anchor => {
    const u = AC.user(), r = anchor.getBoundingClientRect(), cloud = u && u.cloud;
    const items = [{ id: 'who', label: `${u.name || ''} · ${u.email || ''}`, raw: true, enabled: () => false }, { id: 'sync', label: syncLabel(), raw: true, enabled: () => false }];
    if (cloud && !u.verified && u.via === 'email') items.push({ id: 'verify', label: 'Надіслати лист підтвердження ще раз' }, { id: 'reload', label: 'Я вже підтвердив(-ла) пошту' });
    items.push('-');
    if (cloud) items.push({ id: 'syncnow', label: 'Синхронізувати зараз' });
    items.push({ id: 'projects', label: 'Мої проєкти…' }, { id: 'edit', label: 'Профіль…' });
    if (cloud && u.via === 'email') items.push({ id: 'pass', label: 'Змінити пароль…' });
    if (!cloud && CL() && CL().configured()) items.push({ id: 'connect', label: 'Увійти, щоб зберігати прогрес в обліковому записі…' });
    items.push('-', { id: 'out', label: 'Вийти' });
    ui.menu(items, Math.max(8, r.right - 300), r.bottom + 6, {
      onPick: async id => {
        try {
          if (id === 'verify') { await CL().resendVerify(); O.toast('Лист надіслано на {email}', { email: u.email }); }
          if (id === 'reload') { await CL().refreshUser(); O.toast(AC.user().verified ? 'Пошту підтверджено' : 'Пошту ще не підтверджено: відкрийте посилання з листа'); }
          if (id === 'syncnow') { await CL().syncAll(); O.toast(CL().status === 'ok' ? 'Синхронізовано' : CL().statusMsg); }
          if (id === 'projects') O.run('projects');
          if (id === 'edit') AC.profile();
          if (id === 'pass') { await CL().reset(u.email); O.toast('Посилання для зміни пароля надіслано на {email}', { email: u.email }); }
          if (id === 'connect') AC.dialog();
          if (id === 'out') { if (cloud) await CL().signOut(); AC.setUser(null); O.toast('Ви вийшли з облікового запису'); }
        } catch (e) { O.toast(CL() ? CL().err(e) : e.message); }
      }
    });
  };
  AC.profile = () => {
    const u = AC.user();
    ui.dialog({ title: 'Профіль', fields: [{ key: 'name', label: 'Ім’я', type: 'text', value: u.name || '' }], body: `<div class="dlg-text">${esc(u.email || '')}</div>`, onOk: async v => { const n = v.name.trim().slice(0, 60); if (!n) return; if (u.cloud) { try { await CL().rename(n); } catch (e) { O.toast(CL().err(e)); } } else AC.setUser(Object.assign({}, u, { name: n })); } });
  };

  // ---------- sign-in / sign-up dialog ----------
  AC.dialog = (opts = {}) => {
    const online = !!(CL() && CL().configured());
    let mode = opts.mode || 'in';
    const d = ui.dialog({
      title: 'Вхід у VIBSma',
      body: `<div class="acct">
        ${opts.reason ? `<p class="acct-reason">${esc(opts.reason)}</p>` : ''}
        <div class="acct-tabs" role="tablist"><button type="button" role="tab" data-mode="in">${esc(t('Вхід'))}</button><button type="button" role="tab" data-mode="up">${esc(t('Реєстрація'))}</button></div>
        <p class="acct-lead"></p>
        <button type="button" class="acct-prov google" data-ac="google">${G_LOGO}<span>${esc(t('Продовжити з Google'))}</span></button>
        <button type="button" class="acct-prov apple" data-ac="apple">${A_LOGO}<span>${esc(t('Продовжити з Apple'))}</span></button>
        <div class="acct-or"><span>${esc(t('або e-mail'))}</span></div>
        <label class="acct-f up-only"><span>${esc(t('Ім’я'))}</span><input type="text" class="acct-name" autocomplete="name"></label>
        <label class="acct-f"><span>${esc(t('E-mail'))}</span><input type="email" class="acct-email" placeholder="name@gmail.com" autocomplete="email" spellcheck="false"></label>
        <label class="acct-f"><span>${esc(t('Пароль'))}</span><span class="acct-pass"><input type="password" class="acct-pw" autocomplete="current-password" minlength="6"><button type="button" class="ib" data-ac="show" title="${esc(t('Показати пароль'))}" aria-label="${esc(t('Показати пароль'))}">${O.icon('eye', 15)}</button></span></label>
        <div class="acct-row in-only"><button type="button" class="link" data-ac="forgot">${esc(t('Забули пароль?'))}</button></div>
        <div class="acct-msg" aria-live="polite"></div>
        <button type="button" class="btn primary acct-go" data-ac="go"></button>
        <p class="acct-small">${esc(online ? t('Ваші проєкти й стилі зберігатимуться в обліковому записі та будуть доступні на будь-якому комп’ютері.') : t('Вхід ще не підключено на цьому сайті: власник має один раз указати налаштування Firebase у js/config.js (інструкція — FIREBASE.md). Доти проєкти зберігаються в цьому браузері.'))}</p></div>`,
      // the dialog's own footer is hidden; Enter in a field submits through this button
      buttons: [{ id: 'ok', label: 'OK', primary: true }],
      keepOpen: true,
      onOk: () => go()
    });
    d.el.querySelector('.dlg').classList.add('acct-dlg');
    d.el.querySelector('.dlg-f').hidden = true;
    const $ = s => d.el.querySelector(s);
    const msg = (m, kind) => { const el = $('.acct-msg'); el.textContent = m || ''; el.className = 'acct-msg' + (kind ? ' ' + kind : ''); };
    const setMode = m => {
      mode = m;
      d.el.querySelectorAll('[data-mode]').forEach(b => { b.classList.toggle('on', b.dataset.mode === m); b.setAttribute('aria-selected', b.dataset.mode === m); });
      d.el.querySelectorAll('.up-only').forEach(x => { x.hidden = m !== 'up'; });
      d.el.querySelectorAll('.in-only').forEach(x => { x.hidden = m !== 'in'; });
      $('.acct-lead').textContent = m === 'up' ? t('Створіть обліковий запис: прогрес збережеться, і ви зможете ділитися проєктами.') : t('Увійдіть, щоб продовжити з того місця, де зупинилися.');
      $('.acct-go').textContent = m === 'up' ? t('Зареєструватися') : t('Увійти');
      $('.acct-pw').autocomplete = m === 'up' ? 'new-password' : 'current-password';
      msg('');
    };
    setMode(mode);
    if (!online) d.el.querySelectorAll('[data-ac="google"],[data-ac="apple"],[data-ac="go"],[data-ac="forgot"]').forEach(b => { b.disabled = true; });
    const done = u => { d.close(); const p = O.cloud.profile(u); O.toast('Вітаємо, {name}!', { name: p.name }); };
    const go = async () => {
      if (!online || $('.acct-go').disabled) return;
      const email = $('.acct-email').value.trim(), pw = $('.acct-pw').value, name = $('.acct-name').value.trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return msg(t('Введіть правильну адресу e-mail'), 'err');
      if (pw.length < 6) return msg(t('Пароль — щонайменше 6 символів'), 'err');
      if (mode === 'up' && !name) return msg(t('Як вас звати?'), 'err');
      $('.acct-go').disabled = true;
      msg(mode === 'up' ? t('Створюю обліковий запис…') : t('Вхід…'));
      try {
        if (mode === 'up') { const u = await O.cloud.signUp(name, email, pw); d.close(); ui.alert('Майже готово', esc(t('Ми надіслали лист на {email}. Відкрийте посилання з нього, щоб підтвердити пошту. Ви вже можете працювати — прогрес зберігається.', { email: u.email }))); }
        else done(await O.cloud.signIn(email, pw));
      } catch (e) { msg(O.cloud.err(e), 'err'); if (e.code === 'auth/email-already-in-use') setMode('in'); }
      finally { const b = $('.acct-go'); if (b) b.disabled = false; }
    };
    d.el.addEventListener('click', async e => {
      const tab = e.target.closest('[data-mode]');
      if (tab) { e.preventDefault(); setMode(tab.dataset.mode); return; }
      const b = e.target.closest('[data-ac]');
      if (!b) return;
      e.preventDefault(); e.stopPropagation();
      const k = b.dataset.ac;
      if (k === 'show') { const i = $('.acct-pw'); i.type = i.type === 'password' ? 'text' : 'password'; return; }
      if (!online) return;
      try {
        if (k === 'go') return go();
        if (k === 'forgot') { const email = $('.acct-email').value.trim(); if (!/@/.test(email)) return msg(t('Введіть e-mail, і ми надішлемо посилання для нового пароля'), 'err'); await O.cloud.reset(email); msg(t('Посилання для нового пароля надіслано на {email}', { email }), 'ok'); return; }
        if (k === 'google' || k === 'apple') { msg(t('Відкриваю вхід…')); const u = await O.cloud[k](); if (u) done(u); else msg(''); }
      } catch (err) { msg(O.cloud.err(err), 'err'); }
    });
    setTimeout(() => (mode === 'up' ? $('.acct-name') : $('.acct-email')).focus(), 30);
    if (opts.email) $('.acct-email').value = opts.email;
    if (online) O.cloud.ready().catch(err => msg(O.cloud.err(err), 'err'));
  };

  O.ICONS.user = O.ICONS.user || '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>';
  O.cmd('account', 'Увійти або зареєструватися…', () => (AC.user() ? AC.menu(O.$('#btn-account')) : AC.dialog()), { group: 'Файл' });
  O.cmd('signup', 'Зареєструватися…', () => AC.dialog({ mode: 'up' }), { group: 'Файл' });
  O.on('lang', () => AC.renderButton());
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', AC.renderButton); else AC.renderButton();
})();
