'use strict';
/* VIBSma — interactive prototyping (Figma: Prototype).
   n.proto = [{ trigger, action, target, url, anim, dur, ease, delay, key }]
   triggers: click, hover, press, after (delay), key · actions: navigate, overlay, swap, back, close, scroll, url
   animations: instant, dissolve, smart (Smart Animate: layers with the same name move / resize), move-in, push, slide
   page.protoStart: first frame of the flow. Play: Shift+Space or ▶ in the top bar. */
(function () {
  const O = window.O, M = O.M, R = O.R, model = O.model, S = O.state, ui = O.ui, V = O.view, ph = O.ph;
  const t = (s, v) => O.t(s, v), esc = O.esc, n_ = O.n;
  const PT = O.proto = {};
  PT.TRIGGERS = [['click', 'Натискання'], ['hover', 'Наведення'], ['press', 'Утримання'], ['after', 'Після затримки'], ['key', 'Клавіша']];
  PT.ACTIONS = [['navigate', 'Перейти до'], ['overlay', 'Відкрити як оверлей'], ['swap', 'Замінити оверлей'], ['back', 'Назад'], ['close', 'Закрити оверлей'], ['scroll', 'Прокрутити до'], ['url', 'Відкрити посилання']];
  PT.ANIMS = [['instant', 'Миттєво'], ['dissolve', 'Розчинення'], ['smart', 'Smart Animate'], ['move-left', 'Наїзд справа наліво'], ['move-right', 'Наїзд зліва направо'], ['push-left', 'Зсув наліво'], ['push-right', 'Зсув направо'], ['slide-up', 'Знизу вгору'], ['slide-down', 'Згори вниз']];
  PT.EASE = [['ease-out', 'Ease out'], ['ease-in-out', 'Ease in-out'], ['ease-in', 'Ease in'], ['linear', 'Лінійно'], ['cubic-bezier(.34,1.56,.64,1)', 'Пружина']];
  const needsTarget = a => ['navigate', 'overlay', 'swap', 'scroll'].includes(a);
  PT.DEF = () => ({ trigger: 'click', action: 'navigate', target: '', anim: 'dissolve', dur: 300, ease: 'ease-out', delay: 800, key: '' });
  const topFrames = pg => (pg || model.page()).children.filter(n => n.type === 'frame' && n.visible !== false);
  const topFrameOf = n => { const a = model.ancestors(n); const top = a.length ? a[a.length - 1] : n; return top.type === 'frame' ? top : null; };

  // ---------- Design panel ----------
  O.panels.extraSections.push(nodes => {
    if (nodes.length !== 1) return '';
    const n = nodes[0];
    const list = n.proto || [];
    const pg = model.page();
    const frames = topFrames(pg);
    const home = topFrameOf(n);
    const rows = list.map((it, i) => {
      const targets = it.action === 'scroll' && home ? model.ancestors(n).length ? [] : [] : [];
      void targets;
      let opts = frames.filter(f => f !== home || it.action === 'overlay').map(f => [f.id, f.name]);
      if (it.action === 'scroll' && home) { opts = []; model.walk(home.children, c => { opts.push([c.id, c.name]); return false; }); }
      return `<div class="pr-it">
        <div class="row">${ph.sel(`data-pr="trigger" data-i="${i}"`, it.trigger, PT.TRIGGERS, 'Подія')}${ph.ib(`data-pra="del" data-i="${i}"`, 'minus', 'Видалити взаємодію')}</div>
        ${it.trigger === 'after' ? `<div class="row">${ph.inp(`data-pr="delay" data-i="${i}"`, it.delay || 800, 'Затримка', 'мс')}</div>` : ''}
        ${it.trigger === 'key' ? `<div class="row">${ph.inp(`data-pr="key" data-i="${i}"`, it.key || '', 'Клавіша (напр. ArrowRight)')}</div>` : ''}
        <div class="row">${ph.sel(`data-pr="action" data-i="${i}"`, it.action, PT.ACTIONS, 'Дія')}</div>
        ${needsTarget(it.action) ? `<div class="row">${ph.sel(`data-pr="target" data-i="${i}"`, it.target || '', [['', t('— оберіть —')]].concat(opts), 'Ціль')}</div>` : ''}
        ${it.action === 'url' ? `<div class="row">${ph.inp(`data-pr="url" data-i="${i}"`, it.url || 'https://', 'Посилання')}</div>` : ''}
        ${['navigate', 'overlay', 'swap', 'back'].includes(it.action) ? `<div class="row">${ph.sel(`data-pr="anim" data-i="${i}"`, it.anim || 'dissolve', PT.ANIMS, 'Анімація')}</div><div class="grid2">${ph.inp(`data-pr="dur" data-i="${i}"`, it.dur === undefined ? 300 : it.dur, 'Тривалість', 'мс')}${ph.sel(`data-pr="ease" data-i="${i}"`, it.ease || 'ease-out', PT.EASE, 'Згладжування')}</div>` : ''}
      </div>`;
    }).join('');
    const isStart = n.type === 'frame' && frames.includes(n);
    const start = isStart ? `<div class="row"><label class="chk"><input type="checkbox" data-pr-start="1"${(pg.protoStart || (frames[0] && frames[0].id)) === n.id ? ' checked' : ''}><span>${esc(t('Початок прототипу'))}</span></label><button type="button" class="btn" data-cmd="protoPlay">${O.icon('play', 13)} ${esc(t('Відтворити'))}</button></div>` : '';
    return ph.sec('Прототип', start + rows + (list.length ? '' : `<div class="row note">${esc(t('Додайте взаємодію: що відбувається при натисканні, наведенні чи через затримку.'))}</div>`), ph.ib('data-pra="add"', 'plus', 'Додати взаємодію'));
  });
  document.addEventListener('change', e => {
    const el = e.target;
    if (!ph.inProps(el)) return;
    const n = O.sel()[0];
    if (!n) return;
    if (el.dataset.prStart) { const pg = model.page(); pg.protoStart = el.checked ? n.id : null; O.history.commit('Початок прототипу'); return; }
    const k = el.dataset.pr;
    if (!k) return;
    const it = (n.proto || [])[+el.dataset.i];
    if (!it) return;
    it[k] = ['dur', 'delay'].includes(k) ? Math.max(0, parseFloat(el.value) || 0) : el.value;
    if (k === 'action' && it.action === 'overlay' && it.anim === 'smart') it.anim = 'dissolve';
    O.history.commit('Прототип');
  });
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('button[data-pra]');
    if (!b || !ph.inProps(b)) return;
    const n = O.sel()[0];
    if (!n) return;
    if (b.dataset.pra === 'add') { n.proto = (n.proto || []).concat([PT.DEF()]); if (n.type === 'frame' && topFrames().includes(n)) n.proto[n.proto.length - 1].trigger = 'after'; }
    if (b.dataset.pra === 'del') n.proto.splice(+b.dataset.i, 1);
    if (n.proto && !n.proto.length) delete n.proto;
    O.history.commit('Прототип');
  });

  // ---------- overlay: arrows from hotspots to their targets ----------
  const arrow = (a, b, col, dashed) => {
    const dx = Math.max(40, Math.abs(b.x - a.x) / 2);
    const end = `M${n_(b.x)} ${n_(b.y)}l-8 -5M${n_(b.x)} ${n_(b.y)}l-8 5`;
    return `<path d="M${n_(a.x)} ${n_(a.y)}C${n_(a.x + dx)} ${n_(a.y)} ${n_(b.x - dx)} ${n_(b.y)} ${n_(b.x)} ${n_(b.y)}" fill="none" stroke="${col}" stroke-width="1.6"${dashed ? ' stroke-dasharray="5 4"' : ''} pointer-events="none"/><path d="${end}" stroke="${col}" stroke-width="1.6" fill="none" pointer-events="none"/><circle cx="${n_(a.x)}" cy="${n_(a.y)}" r="4" fill="${col}" pointer-events="none"/>`;
  };
  O.overlayHooks.push(Vm => {
    if (!S.doc) return '';
    const show = S.settings.protoLinks !== false;
    const selIds = new Set(S.sel);
    const pen = S.tool === 'protopen';
    let s = '';
    const pg = model.page();
    model.walk(pg.children, n => {
      if (!n.proto || !n.proto.length) return;
      if (!pen && !(show && (selIds.has(n.id) || S.settings.protoAll))) return;
      const b = model.worldBounds(n);
      const a = M.apply(Vm, { x: b.x + b.w, y: b.y + b.h / 2 });
      for (const it of n.proto) {
        const tg = it.target && model.get(it.target);
        if (!tg || !needsTarget(it.action)) continue;
        const tb = model.worldBounds(tg);
        const p = M.apply(Vm, { x: tb.x, y: tb.y + Math.min(tb.h / 2, 40) });
        s += arrow(a, p, '#0D99FF', it.action === 'overlay' || it.action === 'swap');
      }
    });
    // start flag
    const st = pg.protoStart && model.get(pg.protoStart);
    if (st && (pen || S.settings.protoAll)) { const b = model.worldBounds(st); const p = M.apply(Vm, { x: b.x, y: b.y }); s += `<g pointer-events="none"><rect x="${n_(p.x)}" y="${n_(p.y - 42)}" width="70" height="18" rx="4" fill="#0D99FF"/><text x="${n_(p.x + 8)}" y="${n_(p.y - 29)}" fill="#fff" font-size="11" font-family="system-ui,sans-serif">▶ ${esc(t('Старт'))}</text></g>`; }
    // pen: line to the mouse
    const tl = O.tools.protopen;
    if (pen && tl.src && tl.mouse) { const src = model.get(tl.src); if (src) { const b = model.worldBounds(src); s += arrow(M.apply(Vm, { x: b.x + b.w, y: b.y + b.h / 2 }), M.apply(Vm, tl.mouse), '#0D99FF', true); s += `<g fill="none" stroke="#0D99FF" stroke-width="2" pointer-events="none">${O.outlineOf(src, M.mul(Vm, model.worldMatrix(src)))}</g>`; } }
    return s;
  });
  O.cmd('protoLinks', 'Показувати всі зв’язки прототипу', () => { S.settings.protoAll = !S.settings.protoAll; O.saveSettings(); O.requestOverlay(); }, { group: 'Вигляд', check: () => !!S.settings.protoAll });

  // ---------- prototype pen: click an element, then the target frame ----------
  const frameAt = p => { const list = model.page().children; for (let i = list.length - 1; i >= 0; i--) { const f = list[i]; if (f.type === 'frame' && f.visible !== false && V.containsWorld(f, p)) return f; } return null; };
  O.tools.protopen = {
    cursor: 'crosshair', noHandles: true, hideBox: true, src: null, mouse: null,
    activate() { this.src = null; O.toast('Клацніть елемент (кнопку), потім фрейм, куди він веде'); },
    deactivate() { this.src = null; },
    down(ev) {
      if (!this.src) {
        const id = V.hitLeaf(ev.clientX, ev.clientY);
        const n = id ? V.pick(id, ev.ctrl) : (ev.h && ev.h.startsWith('frame:') ? model.get(ev.h.slice(6)) : frameAt(ev.p));
        if (n) { this.src = n.id; O.select([n.id]); }
        O.requestOverlay();
        return;
      }
      const src = model.get(this.src);
      const f = (ev.h && ev.h.startsWith('frame:') ? model.get(ev.h.slice(6)) : null) || frameAt(ev.p);
      if (src && f && f !== src) {
        src.proto = (src.proto || []).concat([Object.assign(PT.DEF(), { target: f.id })]);
        O.select([src.id]);
        O.history.commit('Зв’язок прототипу');
        O.toast('«{a}» → «{b}»', { a: src.name, b: f.name });
      }
      this.src = null;
      O.requestOverlay();
    },
    move(ev) { this.mouse = ev.p; if (this.src) O.requestOverlay(); },
    up() {},
    key(e) { if (e.key === 'Escape') { this.src = null; O.requestOverlay(); return true; } return false; }
  };
  O.ICONS.protopen = '<path d="M4 6h6v6H4z"/><path d="M14 12h6v6h-6z"/><path d="M10 9c4 0 4 6 4 6" /><path d="M12.4 13.2L14 15l1.8-1.6"/>';
  O.ICONS.comment = '<path d="M4.5 5.5h15v10h-8l-4.5 3.5v-3.5H4.5z"/>';
  ui.TOOLS.protopen = { label: 'Перо прототипу', key: 'Shift+X', icon: 'protopen' };
  const penGroup = ui.TOOL_GROUPS.find(g => g.includes('adaptpen')) || ui.TOOL_GROUPS.find(g => g.includes('pen'));
  penGroup.push('protopen');
  O.cmd('tool:protopen', 'Перо прототипу', () => O.setTool('protopen'), { keys: ['Shift+X'], group: 'Інструмент' });
  if (ui.TOOL_OPTIONS) ui.TOOL_OPTIONS.protopen = () => `<span class="to-hint">${esc(t('Клік по кнопці, потім по фрейму-цілі. Esc — скасувати. Параметри переходу — на панелі «Дизайн»'))}</span>`;

  // ---------- player ----------
  let player = null;
  const screenSVG = (f, uid) => {
    model.layoutAll();
    const ctx = O.render.newCtx({ hit: false, exp: false, pfx: 'pt' + uid + '_', assetURL: id => O.assetURL(id) });
    const body = O.render.nodeMarkup(Object.assign({}, f, { m: M.id(), proto: f.proto }), ctx);
    return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${n_(f.w)} ${n_(f.h)}" width="100%" height="100%" preserveAspectRatio="xMinYMin meet"><defs>${ctx.defs.join('')}</defs>${body}</svg>`;
  };
  const fitScale = (f, vw, vh, overlay) => {
    const tall = f.h / f.w > (vh / vw) * 1.25 && !overlay;
    return tall ? Math.min(1.5, (vw * 0.98) / f.w) : Math.min(1.5, (vw * 0.96) / f.w, (vh * 0.94) / f.h);
  };
  PT.play = startId => {
    const pg = model.page();
    const frames = topFrames(pg);
    if (!frames.length) return O.toast('На сторінці немає фреймів');
    const selTop = O.sel()[0] && topFrameOf(O.sel()[0]);
    const start = model.get(startId) || selTop || model.get(pg.protoStart) || frames[0];
    const el = O.h(`<div class="pt-player" role="dialog" aria-label="${esc(t('Прототип'))}"><div class="pt-bar"><span class="pt-name"></span><span class="sp"></span><button type="button" data-pp="restart" title="${esc(t('Спочатку'))}">↺</button><button type="button" data-pp="hot" title="${esc(t('Показати активні зони'))}">◎</button><button type="button" data-pp="x" title="${esc(t('Закрити (Esc)'))}">✕</button></div><div class="pt-view"></div></div>`);
    document.body.appendChild(el);
    const view = el.querySelector('.pt-view');
    let uid = 0, cur = null, timers = [];
    const hist = [], overlays = [];
    const clearTimers = () => { timers.forEach(clearTimeout); timers = []; };
    const build = (f, isOverlay) => {
      const vw = view.clientWidth || window.innerWidth, vh = view.clientHeight || window.innerHeight;
      const k = fitScale(f, vw, vh, isOverlay);
      const scr = document.createElement('div');
      scr.className = 'pt-screen' + (isOverlay ? ' pt-ov' : '');
      scr.style.width = f.w * k + 'px'; scr.style.height = f.h * k + 'px';
      scr.innerHTML = screenSVG(f, ++uid);
      scr._f = f; scr._k = k;
      // hotspots
      const fb = model.worldBounds(f);
      const add = (n, b) => {
        const hs = document.createElement('div');
        hs.className = 'pt-hot';
        Object.assign(hs.style, { left: (b.x - fb.x) * k + 'px', top: (b.y - fb.y) * k + 'px', width: b.w * k + 'px', height: b.h * k + 'px' });
        for (const it of n.proto) {
          const go = ev => { if (ev) ev.stopPropagation(); run(it, scr); };
          if (it.trigger === 'click') { hs.addEventListener('click', go); hs.style.cursor = 'pointer'; }
          if (it.trigger === 'hover') hs.addEventListener('mouseenter', go);
          if (it.trigger === 'press') hs.addEventListener('pointerdown', go);
        }
        scr.appendChild(hs);
      };
      model.walk(f.children, n => { if (n.visible === false) return false; if (n.proto && n.proto.some(it => ['click', 'hover', 'press'].includes(it.trigger))) add(n, model.worldBounds(n)); });
      return scr;
    };
    const armTimers = (f, scr) => {
      const visit = n => { for (const it of n.proto || []) if (it.trigger === 'after') timers.push(setTimeout(() => { if (scr.isConnected) run(it, scr); }, it.delay || 800)); };
      visit(f); model.walk(f.children, n => { visit(n); });
    };
    const keyItems = () => { const list = []; const f = cur && cur._f; if (!f) return list; const visit = n => (n.proto || []).forEach(it => { if (it.trigger === 'key') list.push(it); }); visit(f); model.walk(f.children, visit); return list; };
    const animate = (oldEl, newEl, it, back) => {
      const dur = it.dur === undefined ? 300 : it.dur, ease = it.ease || 'ease-out';
      let a = it.anim || 'instant';
      if (back) a = { 'move-left': 'move-right', 'move-right': 'move-left', 'push-left': 'push-right', 'push-right': 'push-left', 'slide-up': 'slide-down', 'slide-down': 'slide-up' }[a] || a;
      if (!dur || a === 'instant') return Promise.resolve();
      const o = { duration: dur, easing: ease, fill: 'both' };
      const W = view.clientWidth, H = view.clientHeight;
      const jobs = [];
      if (a === 'dissolve') jobs.push(newEl.animate([{ opacity: 0 }, { opacity: 1 }], o));
      if (a === 'move-left') jobs.push(newEl.animate([{ transform: `translateX(${W}px)` }, { transform: 'none' }], o));
      if (a === 'move-right') jobs.push(newEl.animate([{ transform: `translateX(${-W}px)` }, { transform: 'none' }], o));
      if (a === 'push-left') { jobs.push(newEl.animate([{ transform: `translateX(${W}px)` }, { transform: 'none' }], o)); if (oldEl) jobs.push(oldEl.animate([{ transform: 'none' }, { transform: `translateX(${-W}px)` }], o)); }
      if (a === 'push-right') { jobs.push(newEl.animate([{ transform: `translateX(${-W}px)` }, { transform: 'none' }], o)); if (oldEl) jobs.push(oldEl.animate([{ transform: 'none' }, { transform: `translateX(${W}px)` }], o)); }
      if (a === 'slide-up') jobs.push(newEl.animate([{ transform: `translateY(${H}px)` }, { transform: 'none' }], o));
      if (a === 'slide-down') jobs.push(newEl.animate([{ transform: `translateY(${-H}px)` }, { transform: 'none' }], o));
      if (a === 'smart') jobs.push(...smart(oldEl, newEl, o));
      return Promise.all(jobs.map(j => j.finished.catch(() => {})));
    };
    // Smart Animate: layers with the same name move and resize from the old screen to the new one
    const smart = (oldEl, newEl, o) => {
      const jobs = [];
      if (!oldEl) return [newEl.animate([{ opacity: 0 }, { opacity: 1 }], o)];
      const of = oldEl._f, nf = newEl._f, k = newEl._k;
      const byName = f => { const m = new Map(); for (const c of f.children) if (c.visible !== false && !m.has(c.name)) m.set(c.name, c); return m; };
      const om = byName(of), nm = byName(nf);
      const ob = model.worldBounds(of), nb = model.worldBounds(nf);
      for (const [name, c] of nm) {
        const g = newEl.querySelector(`[data-id="${c.id}"]`);
        if (!g) continue;
        const wrap = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        g.parentNode.insertBefore(wrap, g); wrap.appendChild(g);
        const prev = om.get(name);
        if (!prev) { jobs.push(wrap.animate([{ opacity: 0 }, { opacity: 1 }], o)); continue; }
        const a = model.worldBounds(prev), b = model.worldBounds(c);
        const ax = a.x - ob.x, ay = a.y - ob.y, bx = b.x - nb.x, by = b.y - nb.y;
        const sx = b.w ? a.w / b.w : 1, sy = b.h ? a.h / b.h : 1;
        wrap.style.transformOrigin = `${bx}px ${by}px`;
        jobs.push(wrap.animate([{ transform: `translate(${ax - bx}px, ${ay - by}px) scale(${sx}, ${sy})`, opacity: prev.opacity === undefined ? 1 : prev.opacity }, { transform: 'none', opacity: c.opacity === undefined ? 1 : c.opacity }], o));
      }
      void k;
      // layers that disappear fade out on the old screen
      oldEl.style.position = 'absolute';
      jobs.push(oldEl.animate([{ opacity: 1 }, { opacity: 0 }], Object.assign({}, o, { duration: o.duration * 0.6 })));
      return jobs;
    };
    const show = async (f, it, back) => {
      clearTimers();
      const scr = build(f, false);
      const old = cur;
      view.appendChild(scr);
      if (old) { old.classList.add('pt-leaving'); }
      cur = scr;
      el.querySelector('.pt-name').textContent = f.name;
      await animate(old, scr, it || {}, back);
      if (old && old.isConnected) old.remove();
      view.scrollTop = 0;
      armTimers(f, scr);
    };
    const openOverlay = async (f, it, swap) => {
      if (swap && overlays.length) overlays.pop().back.remove();
      const back = document.createElement('div');
      back.className = 'pt-ovback';
      const scr = build(f, true);
      back.appendChild(scr);
      back.addEventListener('click', e => { if (e.target === back) closeOverlay(); });
      el.appendChild(back);
      overlays.push({ back, scr });
      await animate(null, scr, it);
      armTimers(f, scr);
    };
    const closeOverlay = () => { const o = overlays.pop(); if (o) o.back.remove(); };
    const run = (it, from) => {
      const tg = it.target && model.get(it.target);
      if (it.action === 'url') { if (it.url) window.open(it.url, '_blank', 'noopener'); return; }
      if (it.action === 'back') { if (overlays.length) return closeOverlay(); const prev = hist.pop(); if (prev) show(prev.f, prev.it, true); return; }
      if (it.action === 'close') return closeOverlay();
      if (!tg) return;
      if (it.action === 'scroll') { const k = from._k || 1; const fb = model.worldBounds(from._f), b = model.worldBounds(tg); view.scrollTo({ top: (b.y - fb.y) * k, behavior: 'smooth' }); return; }
      if (it.action === 'overlay') return openOverlay(tg, it, false);
      if (it.action === 'swap') return openOverlay(tg, it, true);
      if (it.action === 'navigate') { while (overlays.length) closeOverlay(); if (cur) hist.push({ f: cur._f, it }); show(tg, it, false); }
    };
    const close = () => { clearTimers(); el.remove(); document.removeEventListener('keydown', key, true); player = null; };
    const key = e => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); if (overlays.length) closeOverlay(); else close(); return; }
      const it = keyItems().find(x => x.key && (x.key === e.key || x.key.toLowerCase() === e.key.toLowerCase()));
      if (it) { e.preventDefault(); e.stopPropagation(); run(it, cur); return; }
      if (e.key === 'Backspace' || (e.key === 'ArrowLeft' && e.altKey)) { e.preventDefault(); e.stopPropagation(); run({ action: 'back', anim: 'push-left', dur: 250 }, cur); return; }
      e.stopPropagation();
    };
    document.addEventListener('keydown', key, true);
    el.addEventListener('click', e => {
      const b = e.target.closest('[data-pp]');
      if (b) { if (b.dataset.pp === 'x') close(); if (b.dataset.pp === 'restart') { hist.length = 0; while (overlays.length) closeOverlay(); show(start, { anim: 'instant' }); } if (b.dataset.pp === 'hot') el.classList.toggle('pt-showhot'); return; }
      // a click outside every hotspot briefly highlights them (like Figma)
      if (!e.target.closest('.pt-hot') && e.target.closest('.pt-screen')) { el.classList.add('pt-flash'); setTimeout(() => el.classList.remove('pt-flash'), 450); }
    });
    player = { el, close, run, show, get current() { return cur && cur._f; }, get overlays() { return overlays.length; } };
    show(start, { anim: 'instant' });
    return player;
  };
  PT.player = () => player;
  O.cmd('protoPlay', 'Відтворити прототип', () => PT.play(), { keys: ['Shift+Space'], group: 'Прототип' });
  O.cmd('protoStart', 'Зробити фрейм початком прототипу', () => { const f = O.sel()[0] && topFrameOf(O.sel()[0]); if (!f) return O.toast('Виділіть фрейм'); model.page().protoStart = f.id; O.history.commit('Початок прототипу'); }, { group: 'Прототип' });
  O.MENUS.splice(O.MENUS.findIndex(m => m[0] === 'Вигляд'), 0, ['Прототип', ['protoPlay', 'protoStart', '-', 'tool:protopen', 'protoLinks']]);
  // ▶ in the top bar plays the prototype when the page has interactions, otherwise the slide presentation
  const pres = O.$('#btn-present');
  if (pres) pres.addEventListener('click', e => {
    let has = false;
    model.walk(model.page().children, n => { if (n.proto && n.proto.length) has = true; });
    if (has) { e.stopImmediatePropagation(); PT.play(); }
  }, true);

  // ---------- HTML export: clickable links between frames ----------
  PT.linkAttrs = n => {
    const it = (n.proto || []).find(x => x.trigger === 'click' && (x.action === 'url' || (x.action === 'navigate' && x.target)));
    if (!it) return '';
    if (it.action === 'url') return it.url ? ` onclick="${esc(`window.open(${JSON.stringify(it.url)},'_blank')`)}" style="cursor:pointer"` : '';
    const tg = model.get(it.target);
    if (!tg) return '';
    const js = `var t=document.querySelector(${JSON.stringify('[aria-label=' + JSON.stringify(tg.name) + ']')});if(t)t.scrollIntoView({behavior:'smooth'})`;
    return ` onclick="${esc(js)}" style="cursor:pointer" role="link"`;
  };
})();
