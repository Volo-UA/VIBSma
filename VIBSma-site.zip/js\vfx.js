'use strict';
/* VIBSma — video editor extras:
   · 82 more effects (100 in all): colour looks, camera motion, overlays (light leaks, snow, rain, confetti,
     particles, scanlines, camera UI…), frames and pixel effects (duotone, kaleidoscope, thermal, night vision…);
   · 100 video templates: 25 kinds (intro, outro, lower third, quote, countdown, sale, slideshow, travel, product,
     birthday, wedding, event, news, podcast, tutorial, before/after, tips, logo reveal, glitch, neon, retro,
     cinema, kinetic type, motivation, recipe) × 4 variants (16:9, 16:9, 9:16, 1:1) with backgrounds, texts,
     animations, transitions and effects;
   · the «Шаблони» and «Фони» tabs of the media bin. */
(function () {
  const O = window.O, S = O.state, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const VE = O.video, BG = O.backgrounds;
  if (!VE || !VE.defFx) return;
  const def = VE.defFx;
  const hash = n => { const x = Math.sin(n * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); };
  const prog = (c, local) => (c && c.dur ? Math.min(1, local / c.dur) : 0);

  // ======================================================================
  // EFFECTS
  // ======================================================================
  // ---------- colour looks (CSS filters, fast) ----------
  const COLOR = 'Колір';
  [['warm', 'Теплий тон', 'sepia(0.25) saturate(1.2) hue-rotate(-8deg)'], ['cool', 'Холодний тон', 'saturate(1.1) hue-rotate(14deg) brightness(1.02)'],
    ['vintage', 'Вінтаж', 'sepia(0.45) contrast(0.9) saturate(0.8) brightness(1.05)'], ['faded', 'Вицвілий', 'contrast(0.8) saturate(0.7) brightness(1.1)'],
    ['hicon', 'Висока контрастність', 'contrast(1.45)'], ['locon', 'М’який контраст', 'contrast(0.75) brightness(1.05)'],
    ['bright', 'Яскраво', 'brightness(1.25)'], ['dark', 'Темно', 'brightness(0.7)'], ['vivid', 'Соковито', 'saturate(1.7) contrast(1.1)'],
    ['muted', 'Приглушено', 'saturate(0.45)'], ['noir', 'Нуар', 'grayscale(1) contrast(1.5) brightness(0.9)'],
    ['hue90', 'Зсув кольору 90°', 'hue-rotate(90deg)'], ['hue180', 'Зсув кольору 180°', 'hue-rotate(180deg)'],
    ['cyber', 'Кіберпанк', 'hue-rotate(-30deg) saturate(1.6) contrast(1.15)'], ['golden', 'Золота година', 'sepia(0.5) saturate(1.6) hue-rotate(-15deg) brightness(1.05)']
  ].forEach(([id, l, f]) => def(id, l, COLOR, 'filter', () => f));
  def('dreamy', 'Мрійливо', COLOR, 'filter', (local, k) => `brightness(1.1) saturate(1.2) contrast(0.85) blur(${Math.max(1, Math.round(1.5 * k))}px)`);
  def('softfocus', 'М’який фокус', COLOR, 'filter', (local, k) => `blur(${Math.max(1, Math.round(3 * k))}px) brightness(1.05)`);
  def('huecycle', 'Райдужна зміна кольору', COLOR, 'filter', local => `hue-rotate(${Math.round(local * 90) % 360}deg)`);
  def('pulsebright', 'Пульсуюча яскравість', COLOR, 'filter', local => `brightness(${(1 + 0.25 * Math.max(0, Math.sin(local * Math.PI * 2))).toFixed(3)})`);
  def('strobebw', 'Стробоскоп Ч/Б', COLOR, 'filter', local => (Math.floor(local * 4) % 2 ? 'grayscale(1) contrast(1.3)' : ''));

  // ---------- motion (camera moves) ----------
  const MOT = 'Рух';
  def('kbIn', 'Наближення Кена Бернса', MOT, 'motion', (s, l, k, W, H, c) => { s.sc *= 1 + 0.15 * prog(c, l); });
  def('kbOut', 'Віддалення Кена Бернса', MOT, 'motion', (s, l, k, W, H, c) => { s.sc *= 1.15 - 0.15 * prog(c, l); });
  def('panL', 'Панорама ліворуч', MOT, 'motion', (s, l, k, W, H, c) => { s.sc *= 1.15; s.x += (0.5 - prog(c, l)) * 0.1 * W; });
  def('panR', 'Панорама праворуч', MOT, 'motion', (s, l, k, W, H, c) => { s.sc *= 1.15; s.x -= (0.5 - prog(c, l)) * 0.1 * W; });
  def('panU', 'Панорама вгору', MOT, 'motion', (s, l, k, W, H, c) => { s.sc *= 1.15; s.y += (0.5 - prog(c, l)) * 0.1 * H; });
  def('panD', 'Панорама вниз', MOT, 'motion', (s, l, k, W, H, c) => { s.sc *= 1.15; s.y -= (0.5 - prog(c, l)) * 0.1 * H; });
  def('rotSlow', 'Повільне обертання', MOT, 'motion', (s, l) => { s.rot += l * 6; s.sc *= 1.12; });
  def('spin', 'Безперервне обертання', MOT, 'motion', (s, l) => { s.rot += l * 120; });
  def('bounce', 'Підстрибування', MOT, 'motion', (s, l, k, W, H) => { s.y -= Math.abs(Math.sin(l * Math.PI * 2)) * 0.04 * H; });
  def('wobble', 'Похитування', MOT, 'motion', (s, l) => { s.rot += Math.sin(l * 8) * 3; });
  def('swing', 'Гойдалка', MOT, 'motion', (s, l) => { s.rot += Math.sin(l * 3) * 8; });
  def('heartbeat', 'Серцебиття', MOT, 'motion', (s, l) => { s.sc *= 1 + 0.08 * Math.pow(Math.max(0, Math.sin(l * Math.PI * 2.4)), 8); });
  def('quake', 'Землетрус', MOT, 'motion', (s, l, k) => { const f = Math.floor(l * 30); s.x += (hash(f) - 0.5) * 40 * k; s.y += (hash(f + 99) - 0.5) * 30 * k; s.rot += (hash(f + 7) - 0.5) * 2; });
  def('drift', 'Дрейф', MOT, 'motion', (s, l, k, W, H) => { s.sc *= 1.06; s.x += Math.sin(l * 0.7) * 0.02 * W; s.y += Math.cos(l * 0.5) * 0.015 * H; });
  def('float', 'Плавання', MOT, 'motion', (s, l, k, W, H) => { s.y += Math.sin(l * 2) * 0.02 * H; });
  def('flipH', 'Переворот по горизонталі', MOT, 'motion', (s, l) => { s.sx = Math.cos(l * Math.PI); });
  def('zoomPunch', 'Ривок на біт', MOT, 'motion', (s, l) => { s.sc *= 1 + 0.15 * Math.exp(-((l % 1) * 8)); });
  def('handheld', 'Ручна камера', MOT, 'motion', (s, l, k) => { s.sc *= 1.04; s.x += (Math.sin(l * 1.3) + Math.sin(l * 2.9) * 0.5) * 6 * k; s.y += (Math.cos(l * 1.1) + Math.sin(l * 3.7) * 0.5) * 5 * k; s.rot += Math.sin(l * 0.9) * 0.4; });
  def('squash', 'Пружинка', MOT, 'motion', (s, l) => { const v = Math.sin(l * Math.PI * 3) * 0.06; s.sx = 1 + v; s.sy = 1 - v; });
  def('blink', 'Мерехтіння', MOT, 'motion', (s, l) => { s.alpha *= 0.6 + 0.4 * Math.abs(Math.sin(l * 4)); });

  // ---------- overlays over the whole frame ----------
  const OV = 'Накладання';
  const leak = cols => (ctx, l, W, H) => { ctx.globalCompositeOperation = 'screen'; const x = W * (0.5 + 0.45 * Math.sin(l * 0.6)), y = H * (0.35 + 0.25 * Math.cos(l * 0.45)); const g = ctx.createRadialGradient(x, y, 0, x, y, Math.max(W, H) * 0.65); g.addColorStop(0, cols[0]); g.addColorStop(0.45, cols[1]); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); };
  def('leakBlue', 'Синя засвітка', OV, 'frame', leak(['rgba(80,170,255,.55)', 'rgba(120,80,255,.2)']));
  def('leakGreen', 'Зелена засвітка', OV, 'frame', leak(['rgba(120,255,160,.45)', 'rgba(255,240,120,.18)']));
  def('leakRainbow', 'Райдужна засвітка', OV, 'frame', (ctx, l, W, H) => { ctx.globalCompositeOperation = 'screen'; const g = ctx.createLinearGradient(W * ((l * 0.2) % 1) - W, 0, W * ((l * 0.2) % 1) + W, H); ['rgba(255,60,60,.25)', 'rgba(255,200,60,.25)', 'rgba(60,255,120,.25)', 'rgba(60,160,255,.25)', 'rgba(200,60,255,.25)'].forEach((c, i, a) => g.addColorStop(i / (a.length - 1), c)); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); });
  const particles = (n, draw) => (ctx, l, W, H, k) => { for (let i = 0; i < n; i++) draw(ctx, i, l, W, H, k, hash(i), hash(i + 0.37), hash(i + 0.71)); };
  def('snow', 'Сніг', OV, 'frame', particles(120, (g, i, l, W, H, k, a, b, c) => { const y = ((b + l * (0.05 + c * 0.08)) % 1) * H, x = a * W + Math.sin(l * 1.5 + i) * 12 * k; g.fillStyle = `rgba(255,255,255,${0.5 + c * 0.5})`; g.beginPath(); g.arc(x, y, (1 + c * 3) * k, 0, 7); g.fill(); }));
  def('rain', 'Дощ', OV, 'frame', particles(140, (g, i, l, W, H, k, a, b, c) => { const y = ((b + l * (0.9 + c)) % 1) * H, x = a * W; g.strokeStyle = 'rgba(200,220,255,.45)'; g.lineWidth = Math.max(1, k); g.beginPath(); g.moveTo(x, y); g.lineTo(x - 6 * k, y + 28 * k); g.stroke(); }));
  def('confetti', 'Конфеті', OV, 'frame', particles(80, (g, i, l, W, H, k, a, b, c) => { const y = ((b + l * (0.15 + c * 0.15)) % 1) * H, x = a * W + Math.sin(l * 2 + i) * 20 * k; g.save(); g.translate(x, y); g.rotate(l * (2 + c * 4) + i); g.fillStyle = ['#FF3B5C', '#FFD23F', '#3BCEAC', '#4361EE', '#F72585'][i % 5]; g.fillRect(-5 * k, -9 * k, 10 * k, 18 * k * Math.abs(Math.cos(l * 3 + i))); g.restore(); }));
  def('bokehP', 'Частинки боке', OV, 'frame', particles(28, (g, i, l, W, H, k, a, b, c) => { const y = (1 - ((b + l * 0.03 * (1 + c)) % 1)) * H, x = a * W; g.globalCompositeOperation = 'screen'; g.fillStyle = `hsla(${Math.round(c * 360)},90%,70%,.18)`; g.beginPath(); g.arc(x, y, (20 + c * 50) * k, 0, 7); g.fill(); g.globalCompositeOperation = 'source-over'; }));
  def('stars', 'Мерехтливі зірки', OV, 'frame', particles(70, (g, i, l, W, H, k, a, b, c) => { const al = Math.max(0, Math.sin(l * (1 + c * 3) + i)); g.fillStyle = `rgba(255,255,255,${al})`; g.beginPath(); g.arc(a * W, b * H, (1 + c * 2) * k, 0, 7); g.fill(); }));
  def('hearts', 'Сердечка', OV, 'frame', particles(18, (g, i, l, W, H, k, a, b, c) => { const y = (1 - ((b + l * (0.08 + c * 0.06)) % 1)) * H, x = a * W + Math.sin(l * 2 + i) * 20 * k; g.font = `${Math.round((30 + c * 40) * k)}px system-ui`; g.globalAlpha = 0.85; g.fillText('❤️', x, y); g.globalAlpha = 1; }));
  def('sparkles', 'Іскри', OV, 'frame', particles(30, (g, i, l, W, H, k, a, b, c) => { const p = (l * (0.8 + c) + b) % 1, s = Math.sin(p * Math.PI) * (8 + c * 14) * k; if (s <= 0) return; const x = a * W, y = hash(i + Math.floor(l * (0.8 + c) + b)) * H; g.fillStyle = 'rgba(255,250,220,.95)'; g.beginPath(); g.moveTo(x, y - s); g.lineTo(x + s * 0.25, y - s * 0.25); g.lineTo(x + s, y); g.lineTo(x + s * 0.25, y + s * 0.25); g.lineTo(x, y + s); g.lineTo(x - s * 0.25, y + s * 0.25); g.lineTo(x - s, y); g.lineTo(x - s * 0.25, y - s * 0.25); g.closePath(); g.fill(); }));
  def('dust', 'Пил у світлі', OV, 'frame', particles(90, (g, i, l, W, H, k, a, b, c) => { const x = ((a + l * 0.01 * (c - 0.5)) % 1 + 1) % 1 * W, y = ((b + l * 0.008) % 1) * H; g.fillStyle = `rgba(255,240,210,${0.15 + c * 0.35})`; g.beginPath(); g.arc(x, y, (0.6 + c * 1.6) * k, 0, 7); g.fill(); }));
  def('fog', 'Туман', OV, 'frame', particles(6, (g, i, l, W, H, k, a, b, c) => { const x = ((a + l * 0.02 * (1 + c)) % 1.4 - 0.2) * W, y = (0.3 + b * 0.6) * H, r = (0.25 + c * 0.2) * Math.max(W, H); const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(235,240,245,.28)'); gr.addColorStop(1, 'rgba(235,240,245,0)'); g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2); }));
  def('scanlines', 'Розгортка', OV, 'frame', (g, l, W, H, k) => { g.fillStyle = 'rgba(0,0,0,.18)'; const st = Math.max(2, Math.round(3 * k)); for (let y = 0; y < H; y += st) g.fillRect(0, y, W, Math.max(1, Math.round(k))); });
  def('crt', 'Старий телевізор', OV, 'frame', (g, l, W, H, k) => { g.fillStyle = 'rgba(0,0,0,.2)'; const st = Math.max(2, Math.round(3 * k)); for (let y = 0; y < H; y += st) g.fillRect(0, y, W, Math.max(1, Math.round(k))); const gr = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.7); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.85)'); g.fillStyle = gr; g.fillRect(0, 0, W, H); g.fillStyle = `rgba(255,255,255,${0.03 + 0.03 * hash(Math.floor(l * 24))})`; g.fillRect(0, 0, W, H); });
  def('wvignette', 'Біла віньєтка', OV, 'frame', (g, l, W, H) => { const gr = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.7); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(255,255,255,.85)'); g.fillStyle = gr; g.fillRect(0, 0, W, H); });
  def('flashBeat', 'Кольорові спалахи', OV, 'frame', (g, l, W, H) => { const p = l % 1; if (p > 0.15) return; g.fillStyle = `hsla(${Math.floor(l) * 67 % 360},90%,60%,${(0.15 - p) * 3})`; g.fillRect(0, 0, W, H); });
  def('flare', 'Відблиск, що рухається', OV, 'frame', (g, l, W, H) => { g.globalCompositeOperation = 'screen'; const x = W * ((l * 0.15) % 1.4 - 0.2), y = H * 0.3; const gr = g.createRadialGradient(x, y, 0, x, y, H * 0.5); gr.addColorStop(0, 'rgba(255,250,230,.8)'); gr.addColorStop(0.1, 'rgba(255,200,120,.35)'); gr.addColorStop(1, 'rgba(255,200,120,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H); for (let i = 1; i <= 3; i++) { const fx = x + (W / 2 - x) * i * 0.5, fy = y + (H / 2 - y) * i * 0.5; g.fillStyle = `rgba(160,200,255,${0.12 / i})`; g.beginPath(); g.arc(fx, fy, H * 0.04 * i, 0, 7); g.fill(); } });
  def('rays', 'Сонячні промені', OV, 'frame', (g, l, W, H) => { g.globalCompositeOperation = 'screen'; for (let i = 0; i < 7; i++) { const a = 0.15 + i * 0.12 + Math.sin(l * 0.5 + i) * 0.02; g.fillStyle = 'rgba(255,240,200,.08)'; g.beginPath(); g.moveTo(-W * 0.05, -H * 0.05); g.lineTo(Math.cos(a) * W * 2, Math.sin(a) * W * 2); g.lineTo(Math.cos(a + 0.05) * W * 2, Math.sin(a + 0.05) * W * 2); g.closePath(); g.fill(); } });
  def('filmburn', 'Опік плівки', OV, 'frame', (g, l, W, H) => { g.globalCompositeOperation = 'screen'; const p = 0.5 + 0.5 * Math.sin(l * 1.7); const gr = g.createLinearGradient(0, 0, W, 0); gr.addColorStop(0, `rgba(255,90,20,${0.5 * p})`); gr.addColorStop(0.25, 'rgba(255,60,20,0)'); gr.addColorStop(0.8, 'rgba(255,60,20,0)'); gr.addColorStop(1, `rgba(255,180,60,${0.6 * (1 - p)})`); g.fillStyle = gr; g.fillRect(0, 0, W, H); });
  def('rec', 'Камера REC', OV, 'frame', (g, l, W, H, k) => { const m = 40 * k, s = 60 * k; g.strokeStyle = '#fff'; g.lineWidth = 3 * k; [[m, m, 1, 1], [W - m, m, -1, 1], [m, H - m, 1, -1], [W - m, H - m, -1, -1]].forEach(([x, y, dx, dy]) => { g.beginPath(); g.moveTo(x, y + dy * s); g.lineTo(x, y); g.lineTo(x + dx * s, y); g.stroke(); }); if (Math.floor(l * 2) % 2 === 0) { g.fillStyle = '#FF2D2D'; g.beginPath(); g.arc(m + 30 * k, m + 50 * k, 12 * k, 0, 7); g.fill(); } g.fillStyle = '#fff'; g.font = `600 ${Math.round(28 * k)}px ui-monospace, monospace`; g.fillText('REC', m + 52 * k, m + 60 * k); const tc = new Date(l * 1000).toISOString().slice(11, 22); g.textAlign = 'right'; g.fillText(tc, W - m - 10 * k, H - m - 20 * k); g.textAlign = 'left'; });

  // ---------- frames ----------
  const FR = 'Рамки';
  def('lb239', 'Широкий кадр 2.39:1', FR, 'frame', (g, l, W, H) => { const bh = Math.max(0, (H - W / 2.39) / 2); g.fillStyle = '#000'; g.fillRect(0, 0, W, bh); g.fillRect(0, H - bh, W, bh); });
  def('polaroid', 'Полароїд', FR, 'frame', (g, l, W, H) => { const m = Math.min(W, H) * 0.05; g.fillStyle = '#F7F5EF'; g.fillRect(0, 0, W, m); g.fillRect(0, 0, m, H); g.fillRect(W - m, 0, m, H); g.fillRect(0, H - m * 3, W, m * 3); });
  def('filmstrip', 'Кіноплівка', FR, 'frame', (g, l, W, H, k) => { const bh = H * 0.08; g.fillStyle = '#111'; g.fillRect(0, 0, W, bh); g.fillRect(0, H - bh, W, bh); g.fillStyle = '#EEE'; const st = bh * 0.9, off = (l * 120 * k) % st; for (let x = -off; x < W; x += st) { g.fillRect(x + st * 0.25, bh * 0.3, st * 0.5, bh * 0.4); g.fillRect(x + st * 0.25, H - bh * 0.7, st * 0.5, bh * 0.4); } });
  def('border', 'Біла рамка', FR, 'frame', (g, l, W, H) => { const m = Math.min(W, H) * 0.035; g.fillStyle = '#fff'; g.fillRect(0, 0, W, m); g.fillRect(0, H - m, W, m); g.fillRect(0, 0, m, H); g.fillRect(W - m, 0, m, H); });
  def('neonborder', 'Неонова рамка', FR, 'frame', (g, l, W, H, k) => { const m = Math.min(W, H) * 0.04; g.strokeStyle = `hsl(${Math.round(l * 60) % 360},100%,60%)`; g.lineWidth = 6 * k; g.shadowColor = g.strokeStyle; g.shadowBlur = 24 * k; g.strokeRect(m, m, W - m * 2, H - m * 2); });
  def('vbars', 'Вертикальні смуги з боків', FR, 'frame', (g, l, W, H) => { const w = Math.max(0, (W - H * 9 / 16) / 2); g.fillStyle = '#000'; g.fillRect(0, 0, w, H); g.fillRect(W - w, 0, w, H); });

  // ---------- pixel effects (rendered into the clip's own layer) ----------
  const PX = 'Пікселі';
  const pix = fn => (L, l, W, H, k) => { const g = L.cv.getContext('2d'); let im; try { im = g.getImageData(0, 0, W, H); } catch (e) { return; } fn(im.data, W, H, l, k); g.putImageData(im, 0, 0); };
  const duo = (a, b) => { const A = O.color.parse(a), B = O.color.parse(b); return pix(d => { for (let i = 0; i < d.length; i += 4) { const v = (0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]) / 255; d[i] = A.r + (B.r - A.r) * v; d[i + 1] = A.g + (B.g - A.g) * v; d[i + 2] = A.b + (B.b - A.b) * v; } }); };
  def('posterize', 'Постеризація', PX, 'layer', pix(d => { for (let i = 0; i < d.length; i += 4) for (let c = 0; c < 3; c++) d[i + c] = Math.round(d[i + c] / 64) * 64; }));
  def('duoPink', 'Дуотон: рожевий і синій', PX, 'layer', duo('#1B1464', '#FF5FA2'));
  def('duoTeal', 'Дуотон: бірюза й помаранч', PX, 'layer', duo('#0B3C49', '#FFB45E'));
  def('duoGold', 'Дуотон: фіолет і золото', PX, 'layer', duo('#2A0845', '#F5D06F'));
  def('comic', 'Комікс (чорно-біле)', PX, 'layer', pix(d => { for (let i = 0; i < d.length; i += 4) { const v = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; d[i] = d[i + 1] = d[i + 2] = v > 118 ? 255 : 0; } }));
  def('edgeneon', 'Неонові контури', PX, 'layer', pix((d, W, H) => { const L = new Float32Array(W * H); for (let i = 0, j = 0; i < d.length; i += 4, j++) L[j] = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const j = y * W + x, e = Math.min(255, (Math.abs(L[j + 1] - L[j - 1]) + Math.abs(L[j + W] - L[j - W])) * 2); const i = j * 4; d[i] = e * 0.3; d[i + 1] = e; d[i + 2] = e * 0.95; } }));
  def('thermal', 'Тепловізор', PX, 'layer', pix(d => { for (let i = 0; i < d.length; i += 4) { const v = (0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]) / 255; d[i] = 255 * Math.min(1, Math.max(0, v * 2 - 0.3)); d[i + 1] = 255 * Math.max(0, Math.sin(v * Math.PI)); d[i + 2] = 255 * Math.max(0, 1 - v * 2); } }));
  def('nightvision', 'Нічне бачення', PX, 'layer', pix((d, W, H, l) => { for (let i = 0; i < d.length; i += 4) { const v = (0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]) * 1.3 + (hash(i + Math.floor(l * 24)) - 0.5) * 40; d[i] = v * 0.25; d[i + 1] = Math.min(255, v); d[i + 2] = v * 0.3; } }));
  def('xray', 'Рентген', PX, 'layer', pix(d => { for (let i = 0; i < d.length; i += 4) { const v = 255 - (0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]); d[i] = v * 0.75; d[i + 1] = v * 0.9; d[i + 2] = Math.min(255, v * 1.15); } }));
  def('dither', 'Дизеринг 1-біт', PX, 'layer', pix((d, W) => { const B = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5]; for (let i = 0, j = 0; i < d.length; i += 4, j++) { const x = j % W, y = (j / W) | 0, v = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; d[i] = d[i + 1] = d[i + 2] = v > (B[(y % 4) * 4 + (x % 4)] + 0.5) * 16 ? 240 : 20; } }));
  def('chroma', 'Сильна хроматична аберація', PX, 'layer', pix((d, W, H, l, k) => { const s = d.slice(), sh = Math.max(2, Math.round(14 * k)); for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const i = (y * W + x) * 4, r = (y * W + Math.min(W - 1, x + sh)) * 4, b = (y * W + Math.max(0, x - sh)) * 4; d[i] = s[r]; d[i + 2] = s[b + 2]; } }));
  def('static', 'Телевізійні перешкоди', PX, 'layer', pix((d, W, H, l) => { const f = Math.floor(l * 24); for (let i = 0; i < d.length; i += 4) { const n = hash(i * 0.001 + f) * 255; d[i] = d[i] * 0.6 + n * 0.4; d[i + 1] = d[i + 1] * 0.6 + n * 0.4; d[i + 2] = d[i + 2] * 0.6 + n * 0.4; } }));
  const draw = fn => (L, l, W, H, k) => { const g = L.cv.getContext('2d'), tc = L.tmp.getContext('2d'); tc.setTransform(1, 0, 0, 1, 0, 0); tc.clearRect(0, 0, W, H); tc.drawImage(L.cv, 0, 0); g.save(); g.clearRect(0, 0, W, H); fn(g, L.tmp, W, H, l, k); g.restore(); };
  def('kaleido', 'Калейдоскоп', PX, 'layer', draw((g, src, W, H) => { g.drawImage(src, 0, 0, W / 2, H / 2, 0, 0, W / 2, H / 2); g.save(); g.translate(W, 0); g.scale(-1, 1); g.drawImage(src, 0, 0, W / 2, H / 2, 0, 0, W / 2, H / 2); g.restore(); g.save(); g.translate(0, H); g.scale(1, -1); g.drawImage(src, 0, 0, W / 2, H / 2, 0, 0, W / 2, H / 2); g.restore(); g.save(); g.translate(W, H); g.scale(-1, -1); g.drawImage(src, 0, 0, W / 2, H / 2, 0, 0, W / 2, H / 2); g.restore(); }));
  def('mirrorV', 'Дзеркало зверху вниз', PX, 'layer', draw((g, src, W, H) => { g.drawImage(src, 0, 0, W, H / 2, 0, 0, W, H / 2); g.translate(0, H); g.scale(1, -1); g.drawImage(src, 0, 0, W, H / 2, 0, 0, W, H / 2); }));
  def('tile', 'Мозаїка 2×2', PX, 'layer', draw((g, src, W, H) => { for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) g.drawImage(src, 0, 0, W, H, i * W / 2, j * H / 2, W / 2, H / 2); }));
  def('wavy', 'Хвиляста картинка', PX, 'layer', draw((g, src, W, H, l, k) => { const st = Math.max(2, Math.round(4 * k)); for (let y = 0; y < H; y += st) g.drawImage(src, 0, y, W, st, Math.sin(y / H * 12 + l * 4) * 14 * k, y, W, st); }));

  // ======================================================================
  // VIDEO TEMPLATES
  // ======================================================================
  const RAT = [['16:9', 1920, 1080], ['16:9', 1920, 1080], ['9:16', 1080, 1920], ['1:1', 1080, 1080]];
  // scene: [background style, seconds, effects, transition, texts]; text: [content, preset, y (−0.5…0.5 of height), anim in, anim out, size]
  const KINDS = [
    ['intro', 'Інтро-заголовок', ['aurora', 'glow', 'mesh', 'neongrid'], v => [[0, 4, ['kbIn', 'dust'], 'none', [['Ваша назва', 0, -0.04, 'zoomIn', 'fade', 130], ['Підзаголовок відео', 5, 0.12, 'fade', 'fade', 56]]]]],
    ['outro', 'Кінцева заставка', ['grad', 'bokeh', 'space', 'blobs'], v => [[0, 5, ['bokehP'], 'none', [['Дякуємо за перегляд!', 0, -0.1, 'pop', 'fade', 110], ['Підпишіться на канал', 9, 0.1, 'slideU', 'fade', 60], ['👍 🔔', 0, 0.28, 'pop', 'fade', 110]]]]],
    ['lower', 'Нижня третина', ['grad', 'waves', 'mountains', 'sky'], v => [[0, 5, ['kbIn'], 'none', [['Олена Коваленко', 2, 0.28, 'slideL', 'slideL', 58], ['Арт-директорка', 9, 0.37, 'slideL', 'slideL', 40]]]]],
    ['quote', 'Цитата', ['topo', 'grad', 'blobs', 'terrazzo'], v => [[0, 6, ['drift', 'faded'], 'none', [['Простота — найвища витонченість', 7, -0.04, 'type', 'fade', 76], ['Леонардо да Вінчі', 11, 0.16, 'fade', 'fade', 54]]]]],
    ['count', 'Відлік 3-2-1', ['neongrid', 'synth', 'space', 'glow'], v => [['3', 'zoomPunch'], ['2', 'zoomPunch'], ['1', 'zoomPunch']].map(([n]) => [0, 1, ['zoomPunch', 'flashBeat'], 'flashT', [[n, 3, 0, 'pop', 'zoomIn', 300]]]).concat([[1, 1.5, ['confetti'], 'flashT', [['Старт!', 0, 0, 'pop', 'fade', 160]]]])],
    ['sale', 'Розпродаж', ['memphis', 'stripes', 'confetti', 'dots'], v => [[0, 2, ['zoomPunch'], 'none', [['Розпродаж до −50%', 0, -0.06, 'pop', 'fade', 120]]], [1, 2.5, ['heartbeat'], 'slideL', [['Лише цього тижня', 9, -0.06, 'slideL', 'fade', 70], ['Купити зараз', 2, 0.14, 'pop', 'fade', 64]]]]],
    ['slides', 'Слайдшоу', ['mountains', 'sky', 'waves', 'leaves'], v => [[0, 3, ['kbIn', 'warm'], 'none', [['Наші спогади', 11, 0, 'fade', 'fade', 110]]], [1, 3, ['panL', 'warm'], 'dissolve', [['Літо 2026', 11, 0.3, 'fade', 'fade', 80]]], [2, 3, ['kbOut', 'warm', 'leakRainbow'], 'dissolve', [['Разом', 11, 0, 'fade', 'fade', 120]]]]],
    ['travel', 'Влог подорожі', ['mountains', 'sky', 'leaves', 'waves'], v => [[0, 3, ['rec', 'handheld'], 'none', [['Подорож', 4, -0.08, 'zoomIn', 'fade', 150], ['Карпати', 8, 0.12, 'slideU', 'fade', 90]]], [1, 2.5, ['handheld', 'golden'], 'zoomIn', [['День 1', 9, -0.35, 'slideR', 'fade', 50]]]]],
    ['product', 'Анонс продукту', ['glow', 'mesh', 'iso', 'grad'], v => [[0, 2, ['kbIn'], 'none', [['Новинка', 9, -0.2, 'pop', 'fade', 56], ['Знайомтеся: VIBSma Pro', 0, 0, 'zoomIn', 'fade', 100]]], [1, 2.5, ['flare'], 'zoomOut', [['Уже в продажу', 2, 0.05, 'pop', 'fade', 70]]]]],
    ['bday', 'З днем народження', ['confetti', 'bokeh', 'memphis', 'blobs'], v => [[0, 4, ['confetti', 'swing'], 'none', [['З днем народження', 8, -0.08, 'pop', 'fade', 110], ['Щастя, світла й мрій!', 11, 0.12, 'fade', 'fade', 70], ['🎂🎉', 0, 0.3, 'pop', 'fade', 110]]]]],
    ['wedding', 'Весілля', ['bokeh', 'deco', 'leaves', 'glow'], v => [[0, 5, ['kbIn', 'sparkles', 'dreamy'], 'none', [['Весілля Анни та Марка', 7, -0.05, 'fade', 'fade', 90], ['14 вересня 2026 · 16:00', 5, 0.12, 'fade', 'fade', 50]]]]],
    ['event', 'Анонс події', ['synth', 'neongrid', 'stripes', 'aurora'], v => [[0, 2, ['zoomPunch', 'flashBeat'], 'none', [['Фестиваль', 9, -0.18, 'pop', 'fade', 56], ['Літо звуку', 3, 0, 'zoomIn', 'fade', 140]]], [1, 2.5, ['drift'], 'glitchT', [['12–14 липня · Парк Шевченка', 1, 0.05, 'slideU', 'fade', 56]]]]],
    ['news', 'Термінові новини', ['blueprint', 'grad', 'stripes', 'checker'], v => [[0, 4, ['scanlines', 'kbIn'], 'none', [['ТЕРМІНОВІ НОВИНИ', 9, -0.05, 'slideR', 'fade', 80], ['Головне за сьогодні', 2, 0.32, 'slideL', 'fade', 50]]]]],
    ['podcast', 'Подкаст', ['halftone', 'glow', 'mesh', 'deco'], v => [[0, 5, ['pulsebright'], 'none', [['Подкаст', 9, -0.2, 'fade', 'fade', 56], ['Випуск 12: про дизайн', 0, 0, 'zoomIn', 'fade', 96], ['🎙', 0, 0.22, 'pop', 'fade', 120]]]]],
    ['tutorial', 'Урок у 3 кроки', ['blueprint', 'grad', 'dots', 'iso'], v => [[0, 2, [], 'none', [['Урок', 0, 0, 'zoomIn', 'fade', 140]]], [1, 2, [], 'slideL', [['Крок 1', 2, 0, 'slideL', 'fade', 90]]], [2, 2, [], 'slideL', [['Крок 2', 2, 0, 'slideL', 'fade', 90]]], [3, 2, [], 'slideL', [['Крок 3', 2, 0, 'slideL', 'fade', 90]]], [0, 2, ['confetti'], 'circle', [['Готово!', 0, 0, 'pop', 'fade', 130]]]]],
    ['ba', 'До / після', ['grad', 'mesh', 'waves', 'blobs'], v => [[0, 2.5, ['muted', 'faded'], 'none', [['До', 9, -0.35, 'fade', 'fade', 60]]], [1, 2.5, ['vivid', 'sparkles'], 'wipeL', [['Після', 9, -0.35, 'fade', 'fade', 60]]]]],
    ['tips', 'Топ-5 порад', ['memphis', 'dots', 'stripes', 'grad'], v => [[0, 2, ['zoomPunch'], 'none', [['Топ-5 порад', 0, 0, 'pop', 'fade', 130]]]].concat([1, 2, 3].map(i => [i, 2, [], 'slideU', [[t('Порада {n}', { n: i }), 2, 0, 'slideU', 'fade', 90]]]))],
    ['logo', 'Розкриття логотипа', ['glow', 'space', 'mesh', 'neongrid'], v => [[0, 3, ['flare', 'kbIn'], 'none', [['VIBSma', 3, -0.03, 'zoomIn', 'fade', 170], ['дизайн і бренд', 5, 0.13, 'fade', 'fade', 50]]]]],
    ['glitch', 'Глітч-інтро', ['neongrid', 'checker', 'space', 'stripes'], v => [[0, 3, ['quake', 'scanlines', 'static'], 'none', [['Нове відео', 4, 0, 'zoomIn', 'fade', 150]]], [1, 1.5, ['flashBeat'], 'glitchT', [['VIBSma', 0, 0, 'pop', 'fade', 140]]]]],
    ['neon', 'Неонова вивіска', ['neongrid', 'space', 'synth', 'glow'], v => [[0, 4, ['neonborder', 'blink'], 'none', [['Відкрито', 3, -0.06, 'fade', 'fade', 150], ['Неонова ніч', 3, 0.16, 'fade', 'fade', 64]]]]],
    ['retro', 'Ретро VHS', ['synth', 'neongrid', 'stripes', 'memphis'], v => [[0, 4, ['vhs', 'crt', 'drift'], 'none', [['Ретро', 8, -0.05, 'zoomIn', 'fade', 160], ['1986', 4, 0.18, 'fade', 'fade', 80]]]]],
    ['cinema', 'Кіно-титри', ['space', 'grad', 'mountains', 'glow'], v => [[0, 3, ['lb239', 'film'], 'none', [['Студія VIBSma', 7, -0.04, 'fade', 'fade', 60], ['представляє', 5, 0.06, 'fade', 'fade', 40]]], [1, 3, ['lb239', 'film', 'kbIn'], 'black', [['Фільм', 7, 0, 'fade', 'fade', 150]]]]],
    ['kinetic', 'Кінетична типографіка', ['grad', 'checker', 'stripes', 'halftone'], v => ['Думай', 'Твори', 'Дій'].map((w, i) => [i, 1.2, ['zoomPunch'], i ? 'zoomIn' : 'none', [[w, 4, 0, ['pop', 'slideL', 'zoomIn'][i], 'zoomOut', 220]]])],
    ['motiv', 'Мотивація', ['mountains', 'sky', 'aurora', 'glow'], v => [[0, 5, ['kbIn', 'rays'], 'none', [['Ти зможеш', 0, -0.08, 'zoomIn', 'fade', 140], ['Кожен день — новий шанс', 5, 0.12, 'fade', 'fade', 60]]]]],
    ['recipe', 'Рецепт', ['terrazzo', 'leaves', 'checker', 'dots'], v => [[0, 2.5, ['warm'], 'none', [['Рецепт дня', 9, -0.2, 'pop', 'fade', 56], ['Сирники', 11, 0, 'zoomIn', 'fade', 150]]], [1, 2.5, ['warm', 'panR'], 'slideL', [['Інгредієнти', 2, -0.3, 'slideL', 'fade', 56], ['сметана, ягідний соус', 1, 0.3, 'fade', 'fade', 50]]], [2, 2, ['confetti'], 'circle', [['Смачного!', 8, 0, 'pop', 'fade', 130]]]]]
  ];
  VE.TEMPLATES = [];
  KINDS.forEach(([id, name, styles], ki) => { for (let v = 0; v < 4; v++) VE.TEMPLATES.push({ id: id + '-' + (v + 1), kind: id, name, v, ki, style: styles[v], ratio: RAT[v] }); });
  // the background picture of a scene: the template's style, palette moving with the scene number
  const bgId = (tp, scene) => { const list = BG.LIST.filter(b => b.style === tp.style); return list[(tp.v + scene) % list.length].id; };
  const bgAssets = new Map();
  const bgAsset = (id, W, H) => {
    const key = id + '|' + W + 'x' + H;
    for (const [aid, a] of Object.entries(S.doc.assets || {})) if (a && a.bgKey === key) return aid;
    const aid = O.uid();
    S.doc.assets[aid] = { data: BG.dataURL(id, W, H), w: W, h: H, name: t('Фон') + ': ' + BG.label(BG.LIST.find(b => b.id === id)), bgKey: key };
    return aid;
  };
  void bgAssets;
  VE.applyTemplate = (tid, mode = 'replace') => {
    const tp = VE.TEMPLATES.find(x => x.id === tid);
    if (!tp) return;
    const v = VE.doc(), kind = KINDS[tp.ki];
    if (mode === 'replace') { v.clips = []; v.ratio = tp.ratio[0]; v.w = tp.ratio[1]; v.h = tp.ratio[2]; }
    const main = v.tracks.find(x => x.main) || v.tracks.find(x => x.kind === 'video');
    // one text track per line of a scene, so texts shown together do not overlap on the timeline
    const textTrack = j => { let list = v.tracks.filter(x => x.kind === 'text'); while (list.length <= j) { VE.addTrack('text'); list = v.tracks.filter(x => x.kind === 'text'); } return list[list.length - 1 - j]; };
    let at = mode === 'replace' ? 0 : v.clips.filter(c => c.track === main.id).reduce((m, c) => Math.max(m, c.start + c.dur), 0);
    const scenes = kind[3](tp.v);
    const k = Math.min(v.w, v.h) / 1080;
    scenes.forEach(([scene, dur, fx, trans, texts], i) => {
      const bid = bgId(tp, scene), light = BG.lum(bid) > 0.55;
      const asset = bgAsset(bid, v.w, v.h);
      v.clips.push(VE.newClip('image', { track: main.id, asset, name: t(kind[1]), start: at, dur, fit: 'cover', fx: fx.slice(), trans: { type: i ? trans : 'none', d: 0.5 } }));
      texts.forEach(([content, pi, y, ain, aout, size], j) => {
        const [pname, p] = VE.TEXT_PRESETS[pi] || VE.TEXT_PRESETS[0];
        const T = Object.assign({ content: t(content), font: p.font || 'Inter', size: 96, weight: 700, color: '#FFFFFF', stroke: 0, strokeColor: '#000000', bg: '', glow: '', align: 'center', italic: false }, p, { size: Math.round(size * k) });
        delete T.y;
        // readable on any background: dark letters on light backgrounds, a soft shadow on busy dark ones
        const plain = !T.bg && /^#F/i.test(T.color || '') && !T.stroke;
        if (plain && light) { T.color = '#141414'; if (T.glow && T.glow !== '#000000') T.glow = ''; }
        else if (plain && !T.glow) T.glow = 'rgba(0,0,0,.55)';
        if (p.font && O.fonts) O.fonts.load(p.font).then(() => VE.draw()).catch(() => {});
        const d0 = Math.min(0.25 * j, dur * 0.4);
        v.clips.push(VE.newClip('text', { track: textTrack(j).id, name: t(pname), start: at + d0, dur: Math.max(0.6, dur - d0), y: Math.round(y * v.h), text: T, anim: { in: ain, out: aout, d: 0.4 } }));
      });
      at += dur;
    });
    VE.commit(t('Шаблон відео'));
    VE.resize();
    VE.seek(mode === 'replace' ? 0 : VE.playheadAt());
    O.toast('Шаблон «{name}» додано', { name: t(tp.name) });
  };
  VE.backgroundClip = id => {
    const v = VE.doc();
    const aid = bgAsset(id, v.w, v.h);
    const c = VE.addAsset(aid, {});
    if (c) { c.fit = 'cover'; c.dur = 5; }
    VE.commit(t('Фон'));
  };

  // ---------- media bin tabs ----------
  const thumbs = new Map();
  const thumbOf = (id, w, h) => { const key = id + w + 'x' + h; if (!thumbs.has(key)) thumbs.set(key, BG.dataURL(id, w, h)); return thumbs.get(key); };
  VE.BIN_EXTRA.vtpl = {
    label: 'Шаблони',
    render: () => `<div class="ve-note">${esc(t('Шаблонів: {n}. Клік — замінити проєкт шаблоном, Shift+клік — додати в кінець.', { n: VE.TEMPLATES.length }))}</div><div class="vt-grid">${VE.TEMPLATES.map(tp => { const [r, w, h] = tp.ratio; const tw = 120, th = Math.round(tw * h / w); const first = KINDS[tp.ki][3](tp.v)[0][4][0]; const light = BG.lum(bgId(tp, 0)) > 0.55; return `<button type="button" class="vt-card" data-vtpl="${tp.id}" title="${esc(t(tp.name))} · ${r}"><span class="vt-th"><img src="${thumbOf(bgId(tp, 0), 160, Math.round(160 * h / w))}" alt="" width="${tw}" height="${th}"><i style="color:${light ? '#141414' : '#FFFFFF'}">${esc(t(first[0]))}</i></span><b>${esc(t(tp.name))}</b><em>${r} · ${tp.v + 1}</em></button>`; }).join('')}</div>`
  };
  VE.BIN_EXTRA.vbg = {
    label: 'Фони',
    render: () => `<div class="ve-note">${esc(t('Клік додає фон кліпом на головну доріжку.'))}</div><div class="vt-grid bg">${BG.LIST.map(b => `<button type="button" class="vt-card" data-vbg="${b.id}" title="${esc(BG.label(b))}"><img src="${thumbOf(b.id, 160, 90)}" alt="" width="120" height="68"><em>${esc(BG.label(b))}</em></button>`).join('')}</div>`
  };
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('.ve-root [data-vtpl], .ve-root [data-vbg]');
    if (!b) return;
    e.stopPropagation();
    if (b.dataset.vbg) return VE.backgroundClip(b.dataset.vbg);
    const id = b.dataset.vtpl;
    if (e.shiftKey) return VE.applyTemplate(id, 'append');
    if (!VE.doc().clips.length) return VE.applyTemplate(id, 'replace');
    ui.dialog({ title: 'Шаблон відео', body: `<div class="dlg-text">${esc(t('У проєкті вже є кліпи. Замінити їх шаблоном чи додати шаблон у кінець?'))}</div>`, buttons: [{ id: 'append', label: 'Додати в кінець' }, { id: 'ok', label: 'Замінити', primary: true }], onOk: (v, btn) => VE.applyTemplate(id, btn === 'append' ? 'append' : 'replace') });
  }, true);
  O.cmd('videoTemplates', 'Шаблони відео…', () => { if (O.setMode) O.setMode('video'); else VE.open(); setTimeout(() => VE.showBin('vtpl'), 50); }, { group: 'Медіа' });
  const media = O.MENUS.find(m => m[0] === 'Медіа');
  if (media) media[1].push('-', 'videoTemplates');
})();
