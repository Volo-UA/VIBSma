'use strict';
/* VIBSma — modes: Design ↔ Video (CapCut-like editor) ↔ Music (FL Studio-like studio).
   The switch sits in the workspace menu of the top bar and at the top of the video editor and the studio. */
(function () {
  const O = window.O;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  // [id, label, icon, shortcut]
  O.MODES = [['design', 'Дизайн', '✏️', ''], ['video', 'Відео', '🎬', 'Ctrl+Alt+Shift+V'], ['music', 'Музика', '🎹', 'Ctrl+Alt+Shift+M']];
  O.mode = () => (O.studio && O.studio.isOpen() ? 'music' : O.video && O.video.isOpen() ? 'video' : 'design');
  O.setMode = m => {
    if (m === O.mode()) return;
    if (m !== 'music' && O.studio) O.studio.close();
    if (m !== 'video' && O.video) O.video.close();
    if (m === 'video' && O.video) O.video.open();
    if (m === 'music' && O.studio) O.studio.open();
    O.emit('mode', m);
  };
  O.modeSwitch = cur => `<div class="mode-sw" role="tablist" aria-label="${esc(t('Режим'))}">${O.MODES.map(([id, label, ic, key]) => `<button type="button" role="tab" data-mode-sw="${id}" aria-selected="${id === cur}" class="${id === cur ? 'on' : ''}" title="${esc(t(label))}${key ? ' (' + esc(O.keyLabel(key)) + ')' : ''}"><span aria-hidden="true">${ic}</span> ${esc(t(label))}</button>`).join('')}</div>`;
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('[data-mode-sw]');
    if (!b) return;
    e.stopPropagation();
    O.setMode(b.dataset.modeSw);
  }, true);
  O.MODES.forEach(([id, label]) => O.cmd('mode:' + id, 'Режим: ' + label, () => O.setMode(id), { group: 'Вигляд', check: () => O.mode() === id, label: () => t('Режим') + ': ' + t(label) }));
  const view = O.MENUS.find(m => m[0] === 'Вигляд');
  if (view) view[1].unshift({ label: 'Режим', items: O.MODES.map(m => 'mode:' + m[0]) }, '-');
})();
