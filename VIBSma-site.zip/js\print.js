'use strict';
/* VIBSma — print & publishing.
   · A0 … A14 button in the top bar (frames named «A4 — 595×842»), ISO / US paper sizes
   · Photoshop-style «New document» presets: Photo, Print, Art & Illustration, Web, Mobile, Film & Video
   · InDesign-style publications (magazines, booklets): facing pages / spreads, margins, columns, bleed,
     baseline grid (Grundlinienraster), master pages (Musterseiten) with automatic page numbers,
     threaded text frames with overset marker, autoflow «Place text», paragraph styles, preflight, PDF of pages or spreads.
   Units: 1 px = 1 pt (as in the PDF export), so A4 = 595 × 842 px at 72 ppi. */
(function () {
  const O = window.O, M = O.M, R = O.R, model = O.model, S = O.state, ui = O.ui, V = O.view;
  const t = (s, v) => O.t(s, v), esc = O.esc, n_ = O.n;
  const PR = O.print = {};
  const MM = PR.MM = 72 / 25.4;
  const IN = 72;
  const round = Math.round;

  // ======================================================================
  // PAPER SIZES
  // ======================================================================
  // ISO 216 A series: each size halves the longer side of the previous one (A11 … A14 continue the rule)
  PR.A = (() => { const out = []; let w = 841, h = 1189; for (let i = 0; i <= 14; i++) { out.push({ name: 'A' + i, w, h }); const nw = Math.floor(h / 2); h = w; w = nw; } return out; })();
  PR.B = (() => { const out = []; let w = 1000, h = 1414; for (let i = 0; i <= 10; i++) { out.push({ name: 'B' + i, w, h }); const nw = Math.floor(h / 2); h = w; w = nw; } return out; })();
  // size in px for a size in mm at a resolution (72 ppi: 1 px = 1 pt)
  PR.mmToPx = (mm, ppi = 72) => round(mm / 25.4 * ppi);
  PR.frameName = (name, w, h) => `${name} — ${w}×${h}`;
  // frame tool presets: ISO A / B, US paper (px at 72 ppi = pt)
  const printPresets = PR.A.map(a => [a.name, PR.mmToPx(a.w), PR.mmToPx(a.h)])
    .concat([['B4', PR.mmToPx(250), PR.mmToPx(353)], ['B5', PR.mmToPx(176), PR.mmToPx(250)], ['Letter', 612, 792], ['Legal', 612, 1008], ['Tabloid', 792, 1224], ['Журнал US 8.375×10.875″', 603, 783], ['Дайджест 5.5×8.25″', 396, 594], ['Візитка 90×50 мм', 255, 142], ['Візитка 85×55 мм', 241, 156], ['Конверт DL', PR.mmToPx(110), PR.mmToPx(220)]]);

  // ---------- Photoshop «New document» presets: [name, w, h, unit, ppi] ----------
  PR.PS = [
    ['Фото', [['Альбомна 2 × 3', 3, 2, 'in', 300], ['Книжкова 2 × 3', 2, 3, 'in', 300], ['Альбомна 4 × 6', 6, 4, 'in', 300], ['Книжкова 4 × 6', 4, 6, 'in', 300], ['Альбомна 5 × 7', 7, 5, 'in', 300], ['Книжкова 5 × 7', 5, 7, 'in', 300], ['Альбомна 8 × 10', 10, 8, 'in', 300], ['Книжкова 8 × 10', 8, 10, 'in', 300], ['Фото 10 × 15 см', 150, 100, 'mm', 300], ['Фото 13 × 18 см', 180, 130, 'mm', 300], ['Квадрат 20 × 20 см', 200, 200, 'mm', 300]]],
    ['Друк', [['Letter', 8.5, 11, 'in', 300], ['Legal', 8.5, 14, 'in', 300], ['Tabloid', 11, 17, 'in', 300]].concat(PR.A.slice(0, 7).map(a => [a.name, a.w, a.h, 'mm', 300]), [['B3', 353, 500, 'mm', 300], ['B4', 250, 353, 'mm', 300], ['B5', 176, 250, 'mm', 300], ['Розмір Photoshop за замовчуванням', 7, 5, 'in', 300]])],
    ['Мистецтво та ілюстрація', [['Постер 18 × 24″', 18, 24, 'in', 300], ['Постер 24 × 36″', 24, 36, 'in', 150], ['Постер 50 × 70 см', 500, 700, 'mm', 150], ['Листівка 6 × 4″', 6, 4, 'in', 300], ['Папір 11 × 8.5″', 11, 8.5, 'in', 300], ['Квадрат 3000 px', 3000, 3000, 'px', 300], ['Полотно 1920 × 1080', 1920, 1080, 'px', 72], ['Комікс-сторінка 6.625 × 10.25″', 6.625, 10.25, 'in', 600]]],
    ['Веб', [['Веб: найпоширеніший', 1366, 768, 'px', 72], ['Веб: мінімальний', 1024, 768, 'px', 72], ['Веб: великий', 1920, 1080, 'px', 72], ['Десктоп Figma', 1440, 1024, 'px', 72], ['MacBook Air', 1280, 832, 'px', 72], ['MacBook Pro 14″', 1512, 982, 'px', 72], ['iMac 24″', 2240, 1260, 'px', 72], ['QHD 1440p', 2560, 1440, 'px', 72], ['Банер 728 × 90', 728, 90, 'px', 72], ['Банер 300 × 250', 300, 250, 'px', 72], ['Банер 160 × 600', 160, 600, 'px', 72]]],
    ['Мобільні', [['iPhone 16 Pro Max', 1320, 2868, 'px', 72], ['iPhone 16 Pro', 1206, 2622, 'px', 72], ['iPhone 16 Plus', 1290, 2796, 'px', 72], ['iPhone 16 / 15', 1179, 2556, 'px', 72], ['iPhone SE', 750, 1334, 'px', 72], ['iPad Pro 13″', 2064, 2752, 'px', 72], ['iPad Pro 11″', 1668, 2420, 'px', 72], ['iPad Air', 1640, 2360, 'px', 72], ['iPad mini', 1488, 2266, 'px', 72], ['Android 1080p', 1080, 1920, 'px', 72], ['Android 20:9', 1080, 2400, 'px', 72], ['Google Pixel 9', 1080, 2424, 'px', 72], ['Apple Watch 46 мм', 416, 496, 'px', 72], ['Apple Watch Ultra', 410, 502, 'px', 72]]],
    ['Фільм і відео', [['HDV/HDTV 720p', 1280, 720, 'px', 72], ['HDTV 1080p', 1920, 1080, 'px', 72], ['2K DCI', 2048, 1080, 'px', 72], ['UHD 4K', 3840, 2160, 'px', 72], ['DCI 4K', 4096, 2160, 'px', 72], ['UHD 8K', 7680, 4320, 'px', 72], ['NTSC DV', 720, 480, 'px', 72], ['PAL D1/DV', 720, 576, 'px', 72], ['Вертикальне 9:16', 1080, 1920, 'px', 72], ['Квадрат 1:1', 1080, 1080, 'px', 72], ['Соцмережі 4:5', 1080, 1350, 'px', 72], ['Кіно 2.39:1', 2048, 858, 'px', 72]]]
  ];
  const toPx = (v, unit, ppi) => unit === 'px' ? round(v) : unit === 'in' ? round(v * ppi) : unit === 'cm' ? round(v / 2.54 * ppi) : unit === 'pt' ? round(v / 72 * ppi) : round(v / 25.4 * ppi);
  const fromPx = (px, unit, ppi) => unit === 'px' ? px : unit === 'in' ? px / ppi : unit === 'cm' ? px / ppi * 2.54 : unit === 'pt' ? px / ppi * 72 : px / ppi * 25.4;
  PR.toPx = toPx;

  // frame tool presets: Photoshop categories next to the Figma ones, print sizes with A0 … A14
  const pr = O.FRAME_PRESETS;
  const printIdx = pr.findIndex(g => g[0] === 'Друк');
  if (printIdx >= 0) pr[printIdx][1] = printPresets; else pr.push(['Друк', printPresets]);
  for (const [cat, list] of PR.PS) if (cat !== 'Друк' && cat !== 'Веб') pr.push([cat === 'Мобільні' ? 'Мобільні (Photoshop)' : cat, list.map(([nm, w, h, u, ppi]) => [nm, toPx(w, u, ppi), toPx(h, u, ppi)])]);

  // insert one frame at the centre of the view (or right of the selection)
  PR.addFrame = (name, w, h, opts = {}) => {
    const c = R.center(V.viewRect());
    const f = model.create('frame', { w, h, name: PR.frameName(name, w, h), m: M.translate(round(c.x - w / 2), round(c.y - h / 2)), fills: [O.paint.solid(opts.bg || '#FFFFFF')] });
    if (opts.print) f.print = opts.print;
    model.insert(f, model.page());
    O.select([f.id]); O.setTool('select');
    O.history.commit('Фрейм');
    setTimeout(() => V.fit(model.worldBounds(f), 80, 1), 0);
    return f;
  };

  // ======================================================================
  // «A» BUTTON: A0 … A14
  // ======================================================================
  const aState = { land: O.ls.get('aLand', false), ppi: O.ls.get('aPpi', 72) };
  PR.aMenu = (x, y) => {
    const items = [
      { id: 'ppi:72', label: t('72 ppi (вектор, 1 px = 1 pt)'), raw: true, check: () => aState.ppi === 72 },
      { id: 'ppi:150', label: '150 ppi', raw: true, check: () => aState.ppi === 150 },
      { id: 'ppi:300', label: t('300 ppi (як у Photoshop)'), raw: true, check: () => aState.ppi === 300 },
      '-',
      { id: 'orient', label: t('Альбомна орієнтація'), raw: true, check: () => aState.land },
      '-'
    ].concat(PR.A.map((a, i) => {
      const [wm, hm] = aState.land ? [a.h, a.w] : [a.w, a.h];
      const w = PR.mmToPx(wm, aState.ppi), h = PR.mmToPx(hm, aState.ppi);
      return { id: 'a:' + i, label: `${a.name}   ${wm} × ${hm} ${t('мм')}   ·   ${w} × ${h} px`, raw: true };
    }));
    ui.menu(items, x, y, {
      onPick: id => {
        if (id.startsWith('ppi:')) { aState.ppi = +id.slice(4); O.ls.set('aPpi', aState.ppi); return PR.aMenu(x, y); }
        if (id === 'orient') { aState.land = !aState.land; O.ls.set('aLand', aState.land); return PR.aMenu(x, y); }
        const a = PR.A[+id.slice(2)];
        const [wm, hm] = aState.land ? [a.h, a.w] : [a.w, a.h];
        PR.addFrame(a.name, PR.mmToPx(wm, aState.ppi), PR.mmToPx(hm, aState.ppi), { print: { paper: a.name, ppi: aState.ppi, margins: { t: 0, b: 0, i: 0, o: 0 }, cols: 1, gutter: 0, bleed: 0 } });
        O.toast('Створено формат {name}', { name: a.name });
      }
    });
  };
  O.cmd('aFormat', 'Створити A-формат…', () => { const b = O.$('#btn-aformat'); const r = b ? b.getBoundingClientRect() : { left: 200, bottom: 48 }; PR.aMenu(r.left, r.bottom + 4); }, { keys: ['Alt+Shift+A'], group: 'Файл' });
  {
    const bar = O.$('#topbar .tb-r');
    if (bar && !O.$('#btn-aformat')) {
      const b = O.h(`<button id="btn-aformat" class="btn aformat" type="button" title="${esc(t('Створити A-формат: A0 … A14'))}" aria-label="${esc(t('Створити A-формат'))}" aria-haspopup="menu"><b>A</b><span class="lbl">${esc(t('A-формат'))}</span>${O.icon('chevdown', 12)}</button>`);
      bar.insertBefore(b, O.$('#btn-export'));
      b.addEventListener('click', () => { const r = b.getBoundingClientRect(); if (O.$('.menu')) { ui.closeMenus(); return; } PR.aMenu(r.left, r.bottom + 4); });
      O.on('lang', () => { b.querySelector('.lbl').textContent = t('A-формат'); b.title = t('Створити A-формат: A0 … A14'); });
    }
  }

  // ======================================================================
  // PHOTOSHOP-STYLE «NEW DOCUMENT»
  // ======================================================================
  PR.newDocDialog = (opts = {}) => new Promise(resolve => {
    let cat = O.ls.get('psCat', 0), pick = null;
    const st = { name: t('Без назви'), w: 1920, h: 1080, unit: 'px', ppi: 72, bg: '#FFFFFF', art: 1 };
    const body = `<div class="psn">
      <div class="psn-cats" role="tablist">${PR.PS.map(([c], i) => `<button type="button" role="tab" data-cat="${i}">${esc(t(c))}</button>`).join('')}</div>
      <div class="psn-main"><div class="psn-grid"></div>
      <aside class="psn-side">
        <label class="dlg-row"><span>${esc(t('Назва'))}</span><input type="text" data-ps="name"></label>
        <div class="psn-2"><label class="dlg-row"><span>${esc(t('Ширина'))}</span><input type="number" step="any" min="0" data-ps="w"></label><label class="dlg-row"><span>${esc(t('Висота'))}</span><input type="number" step="any" min="0" data-ps="h"></label></div>
        <div class="psn-2"><label class="dlg-row"><span>${esc(t('Одиниці'))}</span><select data-ps="unit"><option value="px">${esc(t('пікселі'))}</option><option value="mm">${esc(t('міліметри'))}</option><option value="cm">${esc(t('сантиметри'))}</option><option value="in">${esc(t('дюйми'))}</option><option value="pt">${esc(t('пункти'))}</option></select></label>
        <label class="dlg-row"><span>${esc(t('Роздільна здатність, ppi'))}</span><input type="number" step="1" min="1" data-ps="ppi"></label></div>
        <div class="psn-2"><div class="dlg-row"><span>${esc(t('Орієнтація'))}</span><span class="psn-or"><button type="button" class="ib" data-or="p" title="${esc(t('Книжкова'))}" aria-label="${esc(t('Книжкова'))}">${O.icon('page', 16)}</button><button type="button" class="ib" data-or="l" title="${esc(t('Альбомна'))}" aria-label="${esc(t('Альбомна'))}"><svg class="ic" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><rect x="3.5" y="6" width="17" height="12" rx="1"/></svg></button></span></div>
        <label class="dlg-row"><span>${esc(t('Монтажних областей'))}</span><input type="number" step="1" min="1" max="50" data-ps="art"></label></div>
        <label class="dlg-row"><span>${esc(t('Фон'))}</span><select data-ps="bg"><option value="#FFFFFF">${esc(t('Білий'))}</option><option value="#000000">${esc(t('Чорний'))}</option><option value="">${esc(t('Прозорий'))}</option><option value="custom">${esc(t('Інший колір…'))}</option></select></label>
        <input type="color" data-ps="bgc" value="#F2F2F2" hidden aria-label="${esc(t('Колір фону'))}">
        <div class="psn-px"></div>
      </aside></div></div>`;
    const d = ui.dialog({
      title: opts.title || 'Новий документ', body,
      buttons: (O.video ? [{ id: 'video', label: '🎬 Відеопроєкт у цьому форматі' }] : []).concat([{ id: 'cur', label: 'Додати в поточний проєкт' }, { id: 'ok', label: 'Створити', primary: true }]),
      onOk: (v, btn) => resolve(Object.assign(read(), { into: btn === 'cur', video: btn === 'video' })),
      onCancel: () => resolve(null)
    });
    d.el.querySelector('.dlg').classList.add('wide', 'psn-dlg');
    const $ = s => d.el.querySelector(s);
    const read = () => {
      const unit = $('[data-ps="unit"]').value, ppi = Math.max(1, +$('[data-ps="ppi"]').value || 72);
      const w = Math.max(1, toPx(+$('[data-ps="w"]').value || 1, unit, ppi)), h = Math.max(1, toPx(+$('[data-ps="h"]').value || 1, unit, ppi));
      let bg = $('[data-ps="bg"]').value; if (bg === 'custom') bg = $('[data-ps="bgc"]').value;
      return { name: $('[data-ps="name"]').value.trim() || t('Без назви'), w, h, ppi, bg, art: O.clamp(Math.round(+$('[data-ps="art"]').value || 1), 1, 50), preset: pick, cat: PR.PS[cat][0] };
    };
    const fill = () => {
      $('[data-ps="name"]').value = st.name; $('[data-ps="w"]').value = O.fmt(st.w, 3); $('[data-ps="h"]').value = O.fmt(st.h, 3);
      $('[data-ps="unit"]').value = st.unit; $('[data-ps="ppi"]').value = st.ppi; $('[data-ps="art"]').value = st.art;
      upd();
    };
    const upd = () => {
      const r = read();
      $('.psn-px').textContent = `${r.w} × ${r.h} px · ${O.fmt(r.w / r.ppi * 25.4, 1)} × ${O.fmt(r.h / r.ppi * 25.4, 1)} ${t('мм')} @ ${r.ppi} ppi`;
      $('[data-or="p"]').classList.toggle('on', r.h >= r.w); $('[data-or="l"]').classList.toggle('on', r.w > r.h);
      $('[data-ps="bgc"]').hidden = $('[data-ps="bg"]').value !== 'custom';
    };
    const grid = () => {
      d.el.querySelectorAll('[data-cat]').forEach(b => b.classList.toggle('on', +b.dataset.cat === cat));
      $('.psn-grid').innerHTML = PR.PS[cat][1].map(([nm, w, h, u, ppi], i) => {
        const pw = toPx(w, u, ppi), ph = toPx(h, u, ppi), k = 46 / Math.max(pw, ph);
        return `<button type="button" class="psn-card" data-pi="${i}"><span class="psn-th"><i style="width:${Math.max(4, pw * k)}px;height:${Math.max(4, ph * k)}px"></i></span><b>${esc(t(nm))}</b><em>${u === 'px' ? `${w} × ${h} px` : `${w} × ${h} ${u === 'in' ? 'in' : t('мм')} @ ${ppi} ppi`}</em><em>${pw} × ${ph} px</em></button>`;
      }).join('');
    };
    d.el.addEventListener('click', e => {
      const c = e.target.closest('[data-cat]');
      if (c) { e.stopPropagation(); cat = +c.dataset.cat; O.ls.set('psCat', cat); grid(); return; }
      const p = e.target.closest('[data-pi]');
      if (p) {
        e.stopPropagation();
        const [nm, w, h, u, ppi] = PR.PS[cat][1][+p.dataset.pi];
        pick = nm;
        Object.assign(st, { name: t(nm), w, h, unit: u, ppi });
        d.el.querySelectorAll('.psn-card').forEach(x => x.classList.toggle('on', x === p));
        fill(); return;
      }
      const o = e.target.closest('[data-or]');
      if (o) {
        e.stopPropagation();
        const w = +$('[data-ps="w"]').value, h = +$('[data-ps="h"]').value;
        if ((o.dataset.or === 'l') !== (w > h)) { $('[data-ps="w"]').value = h; $('[data-ps="h"]').value = w; }
        upd();
      }
    });
    d.el.addEventListener('input', upd);
    d.el.addEventListener('change', e => {
      if (e.target.dataset.ps === 'unit') {
        // keep the physical size when switching units
        const prevUnit = st.unit, ppi = +$('[data-ps="ppi"]').value || 72;
        const wpx = toPx(+$('[data-ps="w"]').value || 1, prevUnit, ppi), hpx = toPx(+$('[data-ps="h"]').value || 1, prevUnit, ppi);
        st.unit = e.target.value;
        $('[data-ps="w"]').value = O.fmt(fromPx(wpx, st.unit, ppi), 3); $('[data-ps="h"]').value = O.fmt(fromPx(hpx, st.unit, ppi), 3);
      }
      upd();
    });
    grid(); fill();
  });
  PR.makeDoc = v => {
    const frames = [];
    for (let i = 0; i < v.art; i++) frames.push([v.art > 1 ? `${v.name} ${i + 1}` : v.name, v.w, v.h]);
    const prev = S.doc;
    const doc = model.newDoc();
    doc.name = v.name;
    S.doc = doc;
    try {
      let x = 0;
      for (const [nm, w, h] of frames) {
        const f = model.create('frame', { name: PR.frameName(nm, w, h), w, h, m: M.translate(x, 0), fills: v.bg ? [O.paint.solid(v.bg)] : [] });
        f.print = { ppi: v.ppi, preset: v.preset || null, margins: { t: 0, b: 0, i: 0, o: 0 }, cols: 1, gutter: 0, bleed: 0 };
        doc.pages[0].children.push(f);
        x += w + Math.max(80, round(w * 0.06));
      }
    } finally { S.doc = prev; }
    // a print document: photos are kept as TIFF at 300 dpi (imagemenu.js)
    if (v.cat === 'Друк') doc.printImages = { fmt: 'tiff', dpi: 300, ppi: v.ppi, color: 'rgb' };
    return doc;
  };
  PR.newDocument = async () => {
    const v = await PR.newDocDialog();
    if (!v) return null;
    if (v.video && O.video) {
      // CapCut-style: a video project with this canvas, opened in the video editor
      O.video.setSize(v.w, v.h, v.name);
      O.history.commit('Формат кадру');
      O.video.open();
      return null;
    }
    if (v.into) {
      const b = model.page().children.length ? model.selBounds(model.page().children) : null;
      let x = b ? round(b.x + b.w + 200) : 0;
      const ids = [];
      for (let i = 0; i < v.art; i++) {
        const nm = v.art > 1 ? `${v.name} ${i + 1}` : v.name;
        const f = model.create('frame', { name: PR.frameName(nm, v.w, v.h), w: v.w, h: v.h, m: M.translate(x, b ? round(b.y) : 0), fills: v.bg ? [O.paint.solid(v.bg)] : [] });
        f.print = { ppi: v.ppi, preset: v.preset || null, margins: { t: 0, b: 0, i: 0, o: 0 }, cols: 1, gutter: 0, bleed: 0 };
        model.insert(f, model.page());
        ids.push(f.id);
        x += v.w + 80;
      }
      if (v.cat === 'Друк') S.doc.printImages = { fmt: 'tiff', dpi: 300, ppi: v.ppi, color: 'rgb' };
      O.select(ids); O.history.commit('Новий документ');
      setTimeout(() => V.fit(model.selBounds(O.sel()), 80, 1), 0);
      return null;
    }
    return PR.makeDoc(v);
  };
  O.cmd('psNew', 'Новий документ (набори Photoshop)…', async () => { const doc = await PR.newDocument(); if (doc) { if (O.projects && !O.projects.disabled) await O.projects.createFrom(doc); else { model.load(doc); setTimeout(() => V.fit(null, 80, 1), 0); } } }, { keys: ['Ctrl+Alt+Shift+O'], group: 'Файл' });

  // ======================================================================
  // PUBLICATIONS (InDesign)
  // ======================================================================
  const PAGE_SIZES = [['A4', 210, 297], ['A5', 148, 210], ['A3', 297, 420], ['A6', 105, 148], ['B5', 176, 250], ['Letter', 215.9, 279.4], ['Журнал US', 212.7, 276.2], ['Дайджест', 139.7, 209.6], ['Tabloid', 279.4, 431.8], ['Квадрат 210', 210, 210], ['Свій розмір', 0, 0]];
  PR.pubOf = pg => (pg || model.page()).pub || null;
  PR.pages = pg => (pg || model.page()).children.filter(n => n.type === 'frame' && n.print && n.print.pageOf);
  PR.masters = () => { const out = []; for (const pg of S.doc.pages) model.walk(pg.children, n => { if (n.type === 'frame' && n.master) out.push(n); return n.type === 'frame' && n.master ? false : undefined; }); return out; };
  PR.masterKeys = () => Array.from(new Set(PR.masters().map(m => m.master.key))).sort();
  const masterFor = (key, side) => { const ms = PR.masters().filter(m => m.master.key === key); return ms.find(m => m.master.side === side) || ms.find(m => m.master.side === 'single') || ms[0] || null; };
  // margins of a page in px: left/right swap inside/outside on facing pages
  PR.margins = f => {
    const p = f.print || {}, mg = p.margins || { t: 0, b: 0, i: 0, o: 0 };
    const left = p.side === 'left';
    return { t: mg.t || 0, b: mg.b || 0, l: (p.side ? (left ? mg.o : mg.i) : mg.i) || 0, r: (p.side ? (left ? mg.i : mg.o) : mg.o) || 0 };
  };
  PR.columns = f => {
    const p = f.print || {}, m = PR.margins(f);
    const cols = Math.max(1, p.cols || 1), g = p.gutter || 0;
    const w = (f.w - m.l - m.r - g * (cols - 1)) / cols;
    const out = [];
    for (let i = 0; i < cols; i++) out.push({ x: m.l + i * (w + g), y: m.t, w, h: f.h - m.t - m.b });
    return w > 0 ? out : [];
  };

  PR.pubDialog = (opts = {}) => new Promise(resolve => {
    const last = O.ls.get('pubLast', {});
    const d = ui.dialog({
      title: opts.title || 'Новий журнал / публікація',
      body: `<div class="dlg-text">${esc(t('Як «Новий документ» в InDesign: сторінки з розворотами, поля, колонки, виліт, базова сітка і шаблонна сторінка A з автоматичними номерами сторінок. Розміри в мм; 1 px = 1 pt.'))}</div>`,
      fields: [
        { key: 'name', label: 'Назва', type: 'text', value: last.name || t('Журнал') },
        { key: 'size', label: 'Формат сторінки', type: 'select', value: last.size || 'A4', options: PAGE_SIZES.map(([k, w, h]) => [k, w ? `${t(k)} · ${O.fmt(w, 1)} × ${O.fmt(h, 1)} ${t('мм')}` : t('Свій розмір')]) },
        { key: 'w', label: 'Ширина (для свого розміру)', type: 'number', value: last.w || 210, unit: 'мм' },
        { key: 'h', label: 'Висота (для свого розміру)', type: 'number', value: last.h || 297, unit: 'мм' },
        { key: 'land', label: 'Альбомна орієнтація', type: 'checkbox', value: !!last.land },
        { key: 'pages', label: 'Кількість сторінок', type: 'number', value: last.pages || 8, min: 1, max: 500 },
        { key: 'start', label: 'Номер першої сторінки', type: 'number', value: last.start || 1, min: 1 },
        { key: 'facing', label: 'Розвороти (сторінки віч-на-віч)', type: 'checkbox', value: last.facing !== false },
        { key: 'satz', label: 'Satzspiegel (конструкція полів)', type: 'select', value: last.satz || 'manual', options: O.satz ? O.satz.METHODS.filter(m => !['ndiv', 'diagonal', 'ratio'].includes(m[0])).map(([k, l]) => [k, k === 'manual' ? 'Вручну (поля нижче)' : l]) : [['manual', 'Вручну (поля нижче)']] },
        { key: 'mt', label: 'Поле: верх', type: 'number', value: last.mt === undefined ? 15 : last.mt, unit: 'мм' },
        { key: 'mb', label: 'Поле: низ', type: 'number', value: last.mb === undefined ? 20 : last.mb, unit: 'мм' },
        { key: 'mi', label: 'Поле: всередині (корінець)', type: 'number', value: last.mi === undefined ? 18 : last.mi, unit: 'мм' },
        { key: 'mo', label: 'Поле: ззовні', type: 'number', value: last.mo === undefined ? 15 : last.mo, unit: 'мм' },
        { key: 'cols', label: 'Колонок', type: 'number', value: last.cols || 2, min: 1, max: 12 },
        { key: 'gutter', label: 'Проміжок між колонками', type: 'number', value: last.gutter === undefined ? 5 : last.gutter, unit: 'мм' },
        { key: 'bleed', label: 'Виліт (Bleed)', type: 'number', value: last.bleed === undefined ? 3 : last.bleed, unit: 'мм' },
        { key: 'base', label: 'Базова сітка: крок', type: 'number', value: last.base || 12, unit: 'pt' },
        { key: 'master', label: 'Шаблонна сторінка A з номерами сторінок і колонтитулом', type: 'checkbox', value: last.master !== false },
        { key: 'text', label: 'Текстові фрейми в колонках (зв’язані через усі сторінки)', type: 'checkbox', value: !!last.text }
      ],
      buttons: opts.inCurrent ? [{ id: 'ok', label: 'Створити', primary: true }] : [{ id: 'cur', label: 'Нова сторінка в цьому проєкті' }, { id: 'ok', label: 'Створити проєкт', primary: true }],
      onOk: (v, btn) => { O.ls.set('pubLast', v); resolve(Object.assign(v, { into: opts.inCurrent || btn === 'cur' })); },
      onCancel: () => resolve(null)
    });
    d.el.querySelector('.dlg').classList.add('wide', 'two-col');
  });

  // build the publication into a document: «Шаблони» page with master A, publication page with page frames
  PR.buildPub = (doc, v) => {
    const prev = S.doc, prevPage = S.pageId;
    S.doc = doc;
    try {
      const size = PAGE_SIZES.find(s => s[0] === v.size) || PAGE_SIZES[0];
      let wm = size[1] || v.w, hm = size[2] || v.h;
      if (v.land) [wm, hm] = [hm, wm];
      const W = round(wm * MM), H = round(hm * MM);
      if (v.satz && v.satz !== 'manual' && O.satz) {
        // classic type area: the margins come from the construction, the height is registered to the baseline grid
        const mg = O.satz.register(H, O.satz.compute(W, H, { method: v.satz }), v.base || 12);
        v = Object.assign({}, v, { mt: mg.t / MM, mb: mg.b / MM, mi: mg.i / MM, mo: mg.o / MM });
      }
      const pub = { id: O.uid(), name: v.name, w: W, h: H, facing: !!v.facing, start: Math.max(1, round(v.start || 1)), bleed: round((v.bleed || 0) * MM * 100) / 100, baseline: { step: v.base || 12, start: round((v.mt || 0) * MM) }, master: v.master ? 'A' : null };
      const print = side => Object.assign({ margins: { t: round(v.mt * MM), b: round(v.mb * MM), i: round(v.mi * MM), o: round(v.mo * MM) }, cols: Math.max(1, round(v.cols || 1)), gutter: round((v.gutter || 0) * MM * 10) / 10, bleed: pub.bleed, side }, v.satz && v.satz !== 'manual' ? { satz: { method: v.satz, lines: false } } : {});
      // masters
      if (v.master) {
        let mp = doc.pages.find(p => p.masters);
        if (!mp) { mp = model.newPage(t('Шаблони (Musterseiten)')); mp.masters = true; doc.pages.push(mp); }
        PR.makeMasterSpread(mp, 'A', pub, print, v.name);
      }
      // the publication page
      let pg = doc.pages.find(p => !p.masters && !p.children.length && !p.pub);
      if (!pg) {
        pg = model.newPage(v.name);
        const mi = doc.pages.findIndex(p => p.masters);
        doc.pages.splice(mi >= 0 ? mi : doc.pages.length, 0, pg);
      }
      pg.name = v.name; pg.pub = pub; pg.bg = null;
      // a magazine is printed: its photos are kept as TIFF at 300 dpi (pages are in points, 72 per inch)
      if (!doc.printImages) doc.printImages = { fmt: 'tiff', dpi: 300, ppi: 72, color: 'rgb' };
      S.pageId = pg.id;
      model.reindex();
      for (let i = 0; i < Math.max(1, round(v.pages || 1)); i++) PR.newPageFrame(pg, print(null));
      PR.relayout(pg);
      if (v.text) PR.columnFrames(PR.pages(pg), { thread: true, filler: true });
      model.reindex();
      return pg;
    } finally { S.doc = prev; S.pageId = prevPage; if (prev) model.reindex(); }
  };
  PR.makeMasterSpread = (mp, key, pub, print, title) => {
    const sides = pub.facing ? ['left', 'right'] : ['single'];
    const y = mp.children.reduce((m, n) => { const b = n.type === 'frame' ? { y: n.m[5], h: n.h } : null; return b ? Math.max(m, b.y + b.h + 120) : m; }, 0);
    let x = 0;
    const made = [];
    for (const side of sides) {
      const f = model.create('frame', { name: `${key}-${t('Шаблон')} (${t(side === 'left' ? 'ліва' : side === 'right' ? 'права' : 'сторінка')}) — ${pub.w}×${pub.h}`, w: pub.w, h: pub.h, m: M.translate(x, y), fills: [O.paint.solid('#FFFFFF')], component: true, clip: true });
      f.master = { key, side, pub: pub.id };
      f.print = Object.assign(print(side === 'single' ? null : side), { label: key });
      const mg = PR.margins(f);
      // running header + automatic page number (outer corner)
      const outerRight = side !== 'left';
      const num = model.create('text', { name: t('Номер сторінки'), text: '#', autoNum: true, font: 'Inter', size: 9, weight: 600, align: outerRight ? 'right' : 'left', width: 60, fills: [O.paint.solid('#1E1E24')] });
      num.m = M.translate(outerRight ? pub.w - mg.r - 60 : mg.l, pub.h - mg.b + round(mg.b / 2) - 6);
      const head = model.create('text', { name: t('Колонтитул'), text: title || t('Журнал'), font: 'Inter', size: 8, weight: 400, tcase: 'upper', ls: 0.8, align: outerRight ? 'right' : 'left', width: round(pub.w / 2), fills: [O.paint.solid('#66667A')] });
      head.m = M.translate(outerRight ? pub.w - mg.r - round(pub.w / 2) : mg.l, Math.max(6, round(mg.t / 2) - 5));
      const rule = model.create('rect', { name: t('Лінія колонтитула'), w: pub.w - mg.l - mg.r, h: 0.5, m: M.translate(mg.l, Math.max(14, round(mg.t / 2) + 7)), fills: [O.paint.solid('#C9C9D1')] });
      f.children = [head, rule, num];
      mp.children.push(f);
      made.push(f);
      x += pub.w;
    }
    return made;
  };
  PR.newPageFrame = (pg, print) => {
    const pub = pg.pub;
    const f = model.create('frame', { name: t('Сторінка'), w: pub.w, h: pub.h, fills: [O.paint.solid('#FFFFFF')], clip: true });
    f.print = Object.assign({ pageOf: pub.id, master: pub.master, num: 0 }, print);
    pg.children.push(f);
    return f;
  };
  // number the pages, pick left / right sides, place spreads one under another (like InDesign's pasteboard)
  PR.relayout = (pg) => {
    pg = pg || model.page();
    const pub = pg.pub;
    if (!pub) return;
    const pages = PR.pages(pg);
    // keep the visual order: top to bottom, then left to right
    pages.sort((a, b) => ((a.print.num || 0) - (b.print.num || 0)) || (a.m[5] - b.m[5]) || (a.m[4] - b.m[4]));
    const GAP = 70;
    pages.forEach((f, i) => {
      const num = pub.start + i;
      const side = pub.facing ? (num % 2 === 0 ? 'left' : 'right') : null;
      f.print.num = num; f.print.side = side;
      f.name = `${t('Сторінка')} ${num} — ${f.w}×${f.h}`;
      let row, x;
      if (pub.facing) { row = Math.floor(num / 2) - Math.floor(pub.start / 2); x = side === 'left' ? 0 : pub.w; }
      else { row = i; x = 0; }
      f.m = M.translate(x, row * (pub.h + GAP));
    });
    // keep z-order = page order
    const others = pg.children.filter(n => !pages.includes(n));
    pg.children = pages.concat(others);
    pages.forEach(f => PR.applyMaster(f, f.print.master));
    model.reindex();
  };
  // master page: a locked instance of the master frame as the bottom layer of the page frame
  PR.applyMaster = (f, key) => {
    f.children = f.children.filter(c => !c.isMaster);
    f.print.master = key || null;
    if (!key) return;
    const m = masterFor(key, f.print.side || 'single');
    if (!m) return;
    const inst = model.create('instance', { name: `${t('Шаблон')} ${key}`, ref: m.id, w: f.w, h: f.h, locked: true, isMaster: true, m: M.id() });
    f.children.unshift(inst);
  };

  // text frames in every column of the pages, threaded column → column → next page
  const FILLER = 'Це текст-заповнювач. Він перетікає з колонки в колонку і зі сторінки на сторінку через зв’язані текстові фрейми, як в InDesign. Змініть текст у будь-якому фреймі — решта перерозподілиться автоматично. Щоб вставити власний матеріал, виділіть фрейм і скористайтеся командою «Помістити текст…». ';
  PR.columnFrames = (pages, o = {}) => {
    const made = [];
    for (const f of pages) {
      f.children = f.children.filter(c => !(c.type === 'text' && c.colFrame));
      for (const c of PR.columns(f)) {
        const tx = model.create('text', { name: t('Текстовий фрейм'), text: '', font: o.font || 'Inter', size: o.size || 10, lh: o.lh || 1.4, width: round(c.w * 100) / 100, boxH: round(c.h * 100) / 100, align: 'left', fills: [O.paint.solid('#1E1E24')], m: M.translate(c.x, c.y), colFrame: true });
        f.children.push(tx);
        made.push(tx);
      }
    }
    if (o.thread) for (let i = 0; i < made.length - 1; i++) made[i].next = made[i + 1].id;
    if (o.filler && made.length) made[0].text = (t(FILLER.trim()) + ' ').repeat(Math.max(4, made.length * 3)).trim();
    model.reindex();
    PR.flowAll();
    return made;
  };

  // ---------- threaded text ----------
  // what fits into a frame: the same typesetting as on the canvas (columns, indents, spacing, character formatting)
  PR.overset = n => !!(n.boxH && n.width && O.text.layout(n).overset);
  const fit = (n, text, runs, pars) => {
    if (!n.width || !n.boxH) return { take: text, rest: null };
    const L = O.typeset.layoutWith(n, text, runs, pars);
    if (!L.overset) return { take: text, rest: null };
    const cut = Math.max(0, Math.min(text.length, L.fitEnd));
    if (cut > 0 && text[cut - 1] === '\n') return { take: text.slice(0, cut - 1), rest: text.slice(cut), brk: true };
    return { take: text.slice(0, cut), rest: text.slice(cut), brk: false };
  };
  PR.chains = () => {
    const all = [];
    for (const pg of S.doc.pages) model.walk(pg.children, n => { if (n.type === 'text') all.push(n); });
    const byId = new Map(all.map(n => [n.id, n]));
    const pointed = new Set(all.filter(n => n.next && byId.has(n.next)).map(n => n.next));
    const chains = [];
    for (const n of all) {
      if (!n.next || pointed.has(n.id)) continue;
      const ch = [n], seen = new Set([n.id]);
      let c = n;
      while (c.next && byId.has(c.next) && !seen.has(c.next)) { c = byId.get(c.next); seen.add(c.id); ch.push(c); }
      chains.push(ch);
    }
    return chains;
  };
  PR.chainOf = n => PR.chains().find(ch => ch.includes(n)) || null;
  PR.story = ch => ch.map((n, i) => (n.text || '') + (n.brk && i < ch.length - 1 ? '\n' : '')).join('');
  // character / paragraph formatting and notes of the whole story (offsets in PR.story)
  const NOTE_FIELDS = [['fnotes', ''], ['enotes', ''], ['notes', '']];
  PR.storyRuns = (ch, field) => {
    const out = [];
    let off = 0;
    ch.forEach((n, i) => { for (const r of n[field] || []) out.push(Object.assign({}, r, { s: r.s + off, e: r.e + off })); off += (n.text || '').length + (n.brk && i < ch.length - 1 ? 1 : 0); });
    return out;
  };
  const setRuns = (n, field, list) => { if (list && list.length) n[field] = list; else delete n[field]; };
  PR.flowChain = ch => {
    let rest = PR.story(ch);
    let runs = PR.storyRuns(ch, 'runs'), pars = PR.storyRuns(ch, 'pars');
    const notes = NOTE_FIELDS.map(([f]) => [].concat(...ch.map(n => n[f] || [])));
    ch.forEach((n, i) => {
      if (!n.width) n.width = Math.max(20, O.text.layout(n).w);
      if (!n.boxH) n.boxH = Math.max(O.text.lineHeight(n), O.text.layout(n).h);
      if (rest === null) { n.text = ''; n.brk = false; setRuns(n, 'runs', null); setRuns(n, 'pars', null); return; }
      if (i === ch.length - 1) { n.text = rest; n.brk = false; setRuns(n, 'runs', runs); setRuns(n, 'pars', pars); return; }
      const r = fit(n, rest, runs, pars);
      n.text = r.take; n.brk = !!r.brk;
      setRuns(n, 'runs', O.typeset.sliceRuns(runs, 0, r.take.length));
      setRuns(n, 'pars', O.typeset.sliceRuns(pars, 0, r.take.length + 1));
      if (r.rest !== null) { const skip = r.take.length + (r.brk ? 1 : 0); runs = O.typeset.sliceRuns(runs, skip, Infinity); pars = O.typeset.sliceRuns(pars, skip, Infinity); }
      rest = r.rest;
    });
    // footnotes / endnotes / notes follow their markers
    NOTE_FIELDS.forEach(([f, mark], k) => {
      if (!notes[k].length) return;
      let at = 0;
      for (const n of ch) { const c = O.typeset.countChar(n.text || '', mark); if (c) n[f] = notes[k].slice(at, at + c); else delete n[f]; at += c; }
    });
  };
  PR.flowAll = () => { if (!S.doc) return; for (const ch of PR.chains()) PR.flowChain(ch); };
  // reflow before every undo step is recorded, so undo / redo always see distributed text
  {
    const H = O.history, orig = H.commit.bind(H);
    H.commit = label => { try { if (!S.textEditActive) PR.flowAll(); } catch (e) { console.error(e); } return orig(label); };
    O.on('fonts', () => { PR.flowAll(); O.requestRender(); });
  }
  PR.thread = () => {
    const texts = S.sel.map(model.get).filter(n => n && n.type === 'text' && !n.path);
    if (texts.length < 2) return O.toast('Виділіть по черзі 2 або більше текстових фрейми (Shift+клік)');
    texts.forEach(n => { if (!n.width) n.width = Math.max(20, O.text.layout(n).w); if (!n.boxH) n.boxH = Math.max(O.text.lineHeight(n) * 3, O.text.layout(n).h); });
    for (let i = 0; i < texts.length - 1; i++) {
      const tail = (PR.chainOf(texts[i]) || [texts[i]]).slice(-1)[0];
      if (tail !== texts[i + 1]) tail.next = texts[i + 1].id;
    }
    O.history.commit('Зв’язування текстових фреймів');
    O.toast('Текст перетікає між {n} фреймами', { n: texts.length });
  };
  PR.unthread = () => {
    const texts = O.sel().filter(n => n.type === 'text');
    for (const n of texts) {
      const ch = PR.chainOf(n);
      if (!ch) continue;
      const story = PR.story(ch);
      const runs = PR.storyRuns(ch, 'runs'), pars = PR.storyRuns(ch, 'pars');
      const notes = ['fnotes', 'enotes', 'notes'].map(f => [].concat(...ch.map(x => x[f] || [])));
      ch.forEach(x => { delete x.next; x.brk = false; delete x.runs; delete x.pars; delete x.fnotes; delete x.enotes; delete x.notes; });
      ch[0].text = story;
      if (runs.length) ch[0].runs = runs;
      if (pars.length) ch[0].pars = pars;
      ['fnotes', 'enotes', 'notes'].forEach((f, k) => { if (notes[k].length) ch[0][f] = notes[k]; });
      ch.slice(1).forEach(x => { x.text = ''; });
    }
    O.history.commit('Розірвати зв’язок');
  };
  // the «Text frame» section of the Design panel lives in typeui.js (columns, inset, threads)
  document.addEventListener('change', e => {
    const el = e.target;
    if (!el.dataset || !el.dataset.pt || !O.$('#props') || !O.$('#props').contains(el)) return;
    const n = O.sel()[0];
    if (!n || n.type !== 'text') return;
    if (el.dataset.pt === 'box') {
      if (el.checked) { if (!n.width) n.width = Math.max(20, O.text.layout(n).w); n.boxH = Math.max(O.text.lineHeight(n), O.text.layout(n).h); } else delete n.boxH;
    }
    if (el.dataset.pt === 'boxH') { const v = parseFloat(el.value); if (isFinite(v) && v > 0) n.boxH = v; }
    O.history.commit('Текстовий фрейм');
  });
  // overset marker (red +) and thread lines
  O.overlayHooks.push(Vm => {
    if (!S.doc) return '';
    let s = '';
    const pg = model.page();
    const selIds = new Set(S.sel);
    model.walk(pg.children, n => {
      if (n.visible === false) return false;
      if (n.type !== 'text' || !n.boxH || !n.width) return;
      const W = M.mul(Vm, model.worldMatrix(n));
      const p = M.apply(W, { x: n.width, y: n.boxH });
      const isLast = !n.next || !model.get(n.next);
      if (isLast && PR.overset(n)) s += `<g pointer-events="none"><rect x="${n_(p.x - 9)}" y="${n_(p.y - 9)}" width="10" height="10" fill="#fff" stroke="#E5484D"/><path d="M${n_(p.x - 4)} ${n_(p.y - 7)}v6M${n_(p.x - 7)} ${n_(p.y - 4)}h6" stroke="#E5484D" stroke-width="1.4"/></g>`;
      if (n.next && (selIds.has(n.id) || selIds.has(n.next))) {
        const nx = model.get(n.next);
        if (nx && model.pageOf(nx) === pg) {
          const q = M.apply(M.mul(Vm, model.worldMatrix(nx)), { x: 0, y: 0 });
          s += `<path d="M${n_(p.x)} ${n_(p.y)}C${n_(p.x + 40)} ${n_(p.y)} ${n_(q.x - 40)} ${n_(q.y)} ${n_(q.x)} ${n_(q.y)}" fill="none" stroke="#0D99FF" stroke-width="1.2" stroke-dasharray="4 3" pointer-events="none"/><circle cx="${n_(q.x)}" cy="${n_(q.y)}" r="3" fill="#0D99FF" pointer-events="none"/>`;
        }
      }
    });
    return s;
  });

  // ---------- place text (autoflow: adds pages until the story fits) ----------
  PR.placeText = async () => {
    const files = await O.io.pickFiles('.txt,.md,.markdown,.csv,.html,.htm,.rtf,text/plain', false);
    const f = files[0];
    if (!f) return;
    let text = await f.text();
    if (/\.html?$/i.test(f.name)) { const dd = new DOMParser().parseFromString(text, 'text/html'); dd.querySelectorAll('br').forEach(b => b.replaceWith('\n')); dd.querySelectorAll('p,div,h1,h2,h3,h4,li').forEach(b => b.append('\n')); text = dd.body.textContent; }
    if (/\.rtf$/i.test(f.name)) text = text.replace(/\\par[d]?/g, '\n').replace(/\{\*?\\[^{}]+}|[{}]|\\[a-z]+-?\d* ?/gi, '');
    text = text.replace(/\r\n?/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
    let target = O.sel().find(n => n.type === 'text');
    const pg = model.page();
    if (!target) {
      // into the selected page (or the first page) of the publication: column frames, threaded
      const sel = O.sel()[0];
      let page = sel ? (sel.print && sel.print.pageOf ? sel : model.ancestors(sel).find(a => a.print && a.print.pageOf)) : null;
      if (!page) page = PR.pages(pg)[0];
      if (!page) return O.toast('Виділіть текстовий фрейм або сторінку публікації');
      const pages = PR.pages(pg).slice(PR.pages(pg).indexOf(page));
      target = PR.columnFrames(pages, { thread: true })[0];
    }
    const added = PR.autoflow(target, text);
    model.reindex();
    O.history.commit('Помістити текст');
    O.toast(added ? 'Текст розміщено, додано сторінок: {n}' : 'Текст розміщено', { n: added });
  };
  // put a story into a chain and add publication pages (with threaded column frames) until it fits
  PR.autoflow = (target, text) => {
    const pg = model.pageOf(target) || model.page();
    const ch = PR.chainOf(target) || [target];
    ch.forEach(n => { n.text = ''; n.brk = false; delete n.runs; delete n.pars; });
    ch[0].text = text;
    if (!ch[0].width) ch[0].width = 400;
    if (!ch[0].boxH) ch[0].boxH = 600;
    PR.flowAll();
    let added = 0;
    if (pg.pub) {
      while (added < 400) {
        const chain = PR.chainOf(ch[0]) || ch;
        const last = chain[chain.length - 1];
        if (!PR.overset(last)) break;
        const lastPage = model.ancestors(last).find(a => a.print && a.print.pageOf) || PR.pages(pg).slice(-1)[0];
        const np = PR.newPageFrame(pg, O.clone(Object.assign({}, lastPage.print, { num: 1e6 + added })));
        PR.relayout(pg);
        const fr = PR.columnFrames([np], { thread: true, font: last.font, size: last.size, lh: last.lh });
        last.next = fr[0].id;
        model.reindex();
        PR.flowAll();
        added++;
      }
    }
    return added;
  };

  // ---------- pages: add / delete / masters ----------
  const pubPage = () => { const pg = model.page(); if (!pg.pub) { O.toast('Відкрийте сторінку публікації (створіть: Публікація → Новий журнал)'); return null; } return pg; };
  const selPages = () => { const pg = model.page(); const out = new Set(); for (const n of O.sel()) { const p = n.print && n.print.pageOf ? n : model.ancestors(n).find(a => a.print && a.print.pageOf); if (p) out.add(p); } return PR.pages(pg).filter(p => out.has(p)); };
  PR.addPages = () => {
    const pg = pubPage(); if (!pg) return;
    const pages = PR.pages(pg);
    const after = selPages().slice(-1)[0] || pages[pages.length - 1];
    ui.dialog({
      title: 'Додати сторінки',
      fields: [{ key: 'n', label: 'Кількість', type: 'number', value: 2, min: 1, max: 200 }, { key: 'after', label: 'Після сторінки', type: 'number', value: after ? after.print.num : 0 }, { key: 'master', label: 'Шаблон', type: 'select', value: pg.pub.master || '', options: [['', 'Без шаблону']].concat(PR.masterKeys().map(k => [k, k + '-' + t('Шаблон')])) }],
      buttons: [{ id: 'ok', label: 'Додати', primary: true }],
      onOk: v => {
        const base = after ? after.print : { margins: { t: 0, b: 0, i: 0, o: 0 }, cols: 1, gutter: 0 };
        const n = O.clamp(round(v.n), 1, 200);
        // new pages get numbers between «after» and the next page, relayout renumbers them
        for (let i = 0; i < n; i++) { const f = PR.newPageFrame(pg, Object.assign(O.clone(base), { master: v.master || null })); f.print.num = (v.after || 0) + 0.001 * (i + 1); }
        PR.relayout(pg);
        O.history.commit('Додати сторінки');
        O.toast('Додано сторінок: {n}', { n });
      }
    });
  };
  PR.deletePages = () => {
    const pg = pubPage(); if (!pg) return;
    const del = selPages();
    if (!del.length) return O.toast('Виділіть сторінки (фрейми сторінок)');
    pg.children = pg.children.filter(n => !del.includes(n));
    model.reindex();
    PR.relayout(pg);
    O.select([]);
    O.history.commit('Видалити сторінки');
  };
  PR.applyMasterDlg = () => {
    const pg = pubPage(); if (!pg) return;
    const targets = selPages().length ? selPages() : PR.pages(pg);
    ui.dialog({
      title: 'Застосувати шаблонну сторінку',
      body: `<div class="dlg-text">${esc(t('Сторінок: {n}. Шаблон лежить на сторінці «Шаблони»: зміни в ньому одразу з’являються на всіх сторінках.', { n: targets.length }))}</div>`,
      fields: [{ key: 'm', label: 'Шаблон', type: 'select', value: pg.pub.master || '', options: [['', 'Без шаблону']].concat(PR.masterKeys().map(k => [k, k + '-' + t('Шаблон')])) }],
      onOk: v => { targets.forEach(f => PR.applyMaster(f, v.m || null)); model.reindex(); O.history.commit('Шаблонна сторінка'); }
    });
  };
  PR.newMaster = () => {
    const pg = pubPage(); if (!pg) return;
    const keys = PR.masterKeys();
    const key = String.fromCharCode(65 + keys.length);
    let mp = S.doc.pages.find(p => p.masters);
    if (!mp) { mp = model.newPage(t('Шаблони (Musterseiten)')); mp.masters = true; S.doc.pages.push(mp); }
    const ref = PR.pages(pg)[0];
    const base = ref ? ref.print : { margins: { t: 0, b: 0, i: 0, o: 0 }, cols: 1, gutter: 0 };
    PR.makeMasterSpread(mp, key, pg.pub, side => Object.assign(O.clone(base), { side, num: undefined, pageOf: undefined, master: undefined }), pg.pub.name);
    model.reindex();
    O.history.commit('Нова шаблонна сторінка');
    O.toast('Створено {k}-Шаблон на сторінці «Шаблони»', { k: key });
  };
  PR.pageNumber = () => {
    const s = O.sel()[0];
    const host = s && s.type === 'frame' ? s : s ? model.ancestors(s).find(a => a.type === 'frame') : null;
    if (!host) return O.toast('Виділіть сторінку або шаблон');
    const mg = PR.margins(host);
    const n = model.create('text', { name: t('Номер сторінки'), text: '#', autoNum: true, font: 'Inter', size: 9, weight: 600, fills: [O.paint.solid('#1E1E24')], m: M.translate(host.w / 2 - 6, host.h - Math.max(18, mg.b / 2 + 6)) });
    model.insert(n, host);
    O.select([n.id]);
    O.history.commit('Номер сторінки');
  };
  PR.marginsDlg = () => {
    const pg = model.page();
    let targets = selPages();
    if (!targets.length) targets = O.sel().filter(n => n.type === 'frame');
    if (!targets.length) targets = PR.pages(pg);
    if (!targets.length) return O.toast('Виділіть фрейм або сторінку');
    const p0 = targets[0].print || { margins: { t: 0, b: 0, i: 0, o: 0 }, cols: 1, gutter: 0, bleed: 0 };
    const mm = v => O.fmt((v || 0) / MM, 2);
    ui.dialog({
      title: 'Поля та колонки',
      fields: [{ key: 't', label: 'Верх', type: 'number', value: mm(p0.margins.t), unit: 'мм' }, { key: 'b', label: 'Низ', type: 'number', value: mm(p0.margins.b), unit: 'мм' }, { key: 'i', label: 'Всередині / ліве', type: 'number', value: mm(p0.margins.i), unit: 'мм' }, { key: 'o', label: 'Ззовні / праве', type: 'number', value: mm(p0.margins.o), unit: 'мм' }, { key: 'cols', label: 'Колонок', type: 'number', value: p0.cols || 1, min: 1 }, { key: 'g', label: 'Проміжок', type: 'number', value: mm(p0.gutter), unit: 'мм' }, { key: 'bl', label: 'Виліт', type: 'number', value: mm(p0.bleed), unit: 'мм' }],
      onOk: v => {
        targets.forEach(f => {
          f.print = Object.assign(f.print || {}, { margins: { t: v.t * MM, b: v.b * MM, i: v.i * MM, o: v.o * MM }, cols: Math.max(1, round(v.cols)), gutter: v.g * MM, bleed: v.bl * MM });
        });
        O.history.commit('Поля та колонки');
      }
    });
  };
  PR.baselineDlg = () => {
    const pg = model.page();
    const bl = (pg.pub && pg.pub.baseline) || S.doc.baseline || { step: 12, start: 0 };
    ui.dialog({
      title: 'Базова сітка (Grundlinienraster)',
      fields: [{ key: 'step', label: 'Крок', type: 'number', value: bl.step, unit: 'pt' }, { key: 'start', label: 'Початок від верху сторінки', type: 'number', value: O.fmt(bl.start / MM, 2), unit: 'мм' }, { key: 'show', label: 'Показувати базову сітку', type: 'checkbox', value: S.settings.baseline !== false }],
      onOk: v => {
        const nb = { step: Math.max(1, v.step), start: v.start * MM };
        if (pg.pub) pg.pub.baseline = nb; else S.doc.baseline = nb;
        S.settings.baseline = v.show; O.saveSettings();
        O.history.commit('Базова сітка');
      }
    });
  };
  // align the selected texts to the baseline grid: line height = multiple of the step, first baseline on a grid line
  PR.snapBaseline = () => {
    const texts = O.sel().filter(n => n.type === 'text' && !n.path);
    if (!texts.length) return O.toast('Виділіть текст');
    for (const n of texts) {
      const page = model.ancestors(n).find(a => a.print) || null;
      const pg = model.pageOf(n);
      const bl = (pg && pg.pub && pg.pub.baseline) || S.doc.baseline || { step: 12, start: 0 };
      const lh = Math.max(1, Math.round(O.text.lineHeight(n) / bl.step)) * bl.step;
      n.lh = lh / n.size;
      const L = O.text.layout(n);
      // first baseline (local y = L.lines[0].y) onto the grid, in page coordinates
      const Pm = page ? M.inv(model.worldMatrix(page)) : M.id();
      const wm = model.worldMatrix(n);
      const base = M.apply(M.mul(Pm, wm), { x: 0, y: L.lines[0] ? L.lines[0].y : 0 });
      const k = Math.round((base.y - bl.start) / bl.step);
      const dy = bl.start + k * bl.step - base.y;
      n.m = n.m.slice(); n.m[5] += dy;
    }
    O.history.commit('Вирівняти за базовою сіткою');
  };

  // ---------- overlay: bleed, margins, columns, baseline grid ----------
  O.overlayHooks.unshift(Vm => {
    if (!S.doc || S.settings.printGuides === false) return '';
    const pg = model.page();
    const pub = pg.pub;
    const bl = (pub && pub.baseline) || S.doc.baseline;
    let s = '';
    const poly = (W, x, y, w, h, attrs) => { const pts = [[x, y], [x + w, y], [x + w, y + h], [x, y + h]].map(([a, b]) => M.apply(W, { x: a, y: b })); return `<polygon points="${pts.map(p => n_(p.x) + ',' + n_(p.y)).join(' ')}" ${attrs} pointer-events="none"/>`; };
    for (const f of pg.children) {
      if (f.type !== 'frame' || !f.print || f.visible === false) continue;
      const W = M.mul(Vm, f.m);
      const zoom = Math.hypot(W[0], W[1]);
      const p = f.print, mg = PR.margins(f);
      if (p.bleed > 0) s += poly(W, -p.bleed, -p.bleed, f.w + 2 * p.bleed, f.h + 2 * p.bleed, 'fill="none" stroke="#E5484D" stroke-width="1" stroke-dasharray="3 2"');
      if (mg.t || mg.b || mg.l || mg.r) s += poly(W, mg.l, mg.t, f.w - mg.l - mg.r, f.h - mg.t - mg.b, 'fill="none" stroke="#E040FB" stroke-width="1"');
      if ((p.cols || 1) > 1) for (const c of PR.columns(f)) s += poly(W, c.x, c.y, c.w, c.h, 'fill="none" stroke="#9747FF" stroke-width="1" stroke-opacity="0.8"');
      if (bl && S.settings.baseline !== false && bl.step * zoom >= 4 && (p.pageOf || f.master)) {
        let d = '';
        for (let y = bl.start; y <= f.h - mg.b + 0.01; y += bl.step) { const a = M.apply(W, { x: 0, y }), b = M.apply(W, { x: f.w, y }); d += `M${n_(a.x)} ${n_(a.y)}L${n_(b.x)} ${n_(b.y)}`; }
        if (d) s += `<path d="${d}" stroke="#00B4D8" stroke-opacity="0.35" stroke-width="1" fill="none" pointer-events="none"/>`;
      }
    }
    // spine of each spread
    if (pub && pub.facing) for (const f of PR.pages(pg)) if (f.print.side === 'left') { const W = M.mul(Vm, f.m); const a = M.apply(W, { x: f.w, y: 0 }), b = M.apply(W, { x: f.w, y: f.h }); s += `<line x1="${n_(a.x)}" y1="${n_(a.y)}" x2="${n_(b.x)}" y2="${n_(b.y)}" stroke="#66667A" stroke-width="1" stroke-dasharray="2 3" pointer-events="none"/>`; }
    return s;
  });
  O.cmd('printGuides', 'Поля, колонки й виліт', () => { S.settings.printGuides = S.settings.printGuides === false; O.saveSettings(); O.requestOverlay(); }, { group: 'Вигляд', check: () => S.settings.printGuides !== false });
  O.cmd('baselineShow', 'Базова сітка', () => { S.settings.baseline = S.settings.baseline === false; O.saveSettings(); O.requestOverlay(); }, { keys: ['Ctrl+Alt+\''], group: 'Вигляд', check: () => S.settings.baseline !== false });

  // ---------- paragraph styles ----------
  // a paragraph style keeps paragraph and character attributes (typeset.js); applying it to a whole frame copies them in
  const STYLE_KEYS = PR.STYLE_KEYS = ['font', 'size', 'weight', 'italic', 'lh', 'ls', 'align', 'tcase', 'deco', 'kern', 'hs', 'vs', 'bs', 'skew', 'smcaps', 'pos', 'ot', 'lang', 'nobreak',
    'li', 'ri', 'fi', 'lri', 'spb', 'spa', 'grid', 'dcl', 'dcc', 'shade', 'border', 'hyph', 'composer', 'list', 'tabs'];
  PR.styleOf = n => { const s = {}; STYLE_KEYS.forEach(k => { if (n[k] !== undefined && n[k] !== null) s[k] = O.clone(n[k]); }); s.color = n.fills && n.fills[0] && n.fills[0].type === 'solid' ? n.fills[0].color : null; return s; };
  PR.applyStyle = (n, st) => {
    STYLE_KEYS.forEach(k => { if (st.props[k] !== undefined) n[k] = O.clone(st.props[k]); });
    if (st.props.color) n.fills = [O.paint.solid(st.props.color)];
    n.pstyle = st.id;
    if (n.pars) { n.pars.forEach(p => { delete p.ps; }); n.pars = n.pars.filter(p => Object.keys(p).some(k => k !== 's' && k !== 'e')); if (!n.pars.length) delete n.pars; }
  };
  const pstyles = () => (S.doc.pstyles = S.doc.pstyles || []);
  // the paragraph / character style pickers of the Design panel live in typeui.js  // starter styles for publications
  PR.defaultStyles = () => {
    if (pstyles().length) return;
    const mk = (name, p) => pstyles().push({ id: O.uid(), name, props: Object.assign({ font: 'Inter', size: 10, weight: 400, italic: false, lh: 1.4, ls: 0, align: 'left', tcase: 'none', deco: 'none', color: '#1E1E24' }, p) });
    mk(t('Заголовок 1'), { size: 32, weight: 800, lh: 1.1 });
    mk(t('Заголовок 2'), { size: 18, weight: 700, lh: 1.25 });
    mk(t('Лід'), { size: 13, weight: 500, lh: 1.45 });
    mk(t('Основний текст'), { size: 10, lh: 1.4, align: 'justify' });
    mk(t('Підпис'), { size: 8, italic: true, lh: 1.3, color: '#66667A' });
    mk(t('Цитата'), { font: 'Playfair Display', size: 16, italic: true, lh: 1.35 });
  };

  // ---------- preflight ----------
  PR.preflight = () => {
    const issues = [];
    const known = n => { const f = String(n.font || '').replace(/["']/g, ''); return (O.fonts && O.fonts.isGoogle(f)) || (O.fonts && O.fonts.SYSTEM.includes(f)) || (S.doc.fonts || []).some(x => x.family === f) || (O.io.localFonts || []).includes(f); };
    for (const pg of S.doc.pages) model.walk(pg.children, n => {
      if (n.type === 'text') {
        if (n.boxH && (!n.next || !model.get(n.next)) && PR.overset(n)) issues.push([n, t('Текст не вміщається у фрейм')]);
        if (!known(n)) issues.push([n, t('Шрифт «{f}» недоступний', { f: n.font })]);
        if (n.size < 6) issues.push([n, t('Дуже дрібний шрифт: {s} pt', { s: O.fmt(n.size) })]);
      }
      for (const f of n.fills || []) {
        if (f.type !== 'image' || f.visible === false) continue;
        const a = S.doc.assets[f.asset];
        if (!a || !n.w) continue;
        const ppi = Math.min(a.w / (n.w / 72), a.h / ((n.h || n.w) / 72));
        if (ppi < 150) issues.push([n, t('Низька роздільна здатність зображення: {p} ppi (для друку потрібно 300)', { p: round(ppi) })]);
      }
    });
    for (const pg of S.doc.pages) {
      if (!pg.pub || !pg.pub.bleed) continue;
      for (const f of PR.pages(pg)) for (const c of f.children) {
        if (c.isMaster || c.visible === false) continue;
        const b = model.boundsIn(c, c.m);
        const near = (v, edge) => Math.abs(v - edge) < 1.5;
        if ((near(b.x, 0) || near(b.y, 0) || near(b.x + b.w, f.w) || near(b.y + b.h, f.h)) && (c.fills || []).some(p => p.type === 'image')) issues.push([c, t('Зображення торкається краю сторінки, але не заходить на виліт')]);
      }
    }
    const body = issues.length ? `<div class="pf-list">${issues.slice(0, 200).map(([n, msg], i) => `<button type="button" class="pf-it" data-pf="${i}"><b>${esc(n.name)}</b><span>${esc(msg)}</span></button>`).join('')}</div>` : `<div class="dlg-text">✓ ${esc(t('Проблем не знайдено. Документ готовий до друку.'))}</div>`;
    const d = ui.dialog({ title: t('Перевірка перед друком (Preflight)') + (issues.length ? ` · ${issues.length}` : ''), body, buttons: [{ id: 'ok', label: 'Закрити', primary: true }] });
    d.el.addEventListener('click', e => {
      const b = e.target.closest('[data-pf]');
      if (!b) return;
      const n = issues[+b.dataset.pf][0];
      const pg = model.pageOf(n);
      if (pg && pg.id !== S.pageId) { S.pageId = pg.id; O.emit('page'); }
      O.select([n.id]);
      setTimeout(() => V.fit(model.worldBounds(n), 120, 4), 0);
    });
  };

  // ---------- PDF of the publication ----------
  PR.exportPub = () => {
    const pg = pubPage(); if (!pg) return;
    const pages = PR.pages(pg);
    if (!pages.length) return O.toast('Немає сторінок');
    ui.dialog({
      title: 'Експорт публікації в PDF',
      fields: [{ key: 'spreads', label: 'Розворотами (дві сторінки на аркуш)', type: 'checkbox', value: false }, { key: 'range', label: 'Сторінки (наприклад «1-4, 8»; порожньо — усі)', type: 'text', value: '' }],
      buttons: [{ id: 'ok', label: 'Далі…', primary: true }],
      onOk: v => {
        let list = pages;
        if (v.range.trim()) {
          const want = new Set();
          v.range.split(',').forEach(part => { const [a, b] = part.split('-').map(x => parseInt(x, 10)); if (isFinite(a)) for (let i = a; i <= (isFinite(b) ? b : a); i++) want.add(i); });
          list = pages.filter(f => want.has(f.print.num));
        }
        let groups;
        if (v.spreads && pg.pub.facing) {
          groups = [];
          for (const f of list) {
            const last = groups[groups.length - 1];
            if (last && f.print.side === 'right' && last.length === 1 && last[0].print.side === 'left' && last[0].print.num === f.print.num - 1) last.push(f);
            else groups.push([f]);
          }
        } else groups = list.map(f => [f]);
        if (O.pdf && O.pdf.save) O.pdf.save(groups); else O.io.export('pdf', 1, groups);
      }
    });
  };

  // ---------- new publication ----------
  PR.newPub = async () => {
    const v = await PR.pubDialog();
    if (!v) return;
    if (v.into) {
      const pg = PR.buildPub(S.doc, v);
      S.pageId = pg.id;
      PR.defaultStyles();
      model.reindex(); O.emit('page'); O.select([]);
      O.history.commit('Нова публікація');
      setTimeout(() => V.fit(null, 80, 1), 0);
      return;
    }
    const doc = model.newDoc();
    doc.name = v.name;
    const pg = PR.buildPub(doc, v);
    const prev = S.doc; S.doc = doc; try { PR.defaultStyles(); } finally { S.doc = prev; }
    doc.pages = [pg].concat(doc.pages.filter(p => p !== pg));
    if (O.projects && !O.projects.disabled) await O.projects.createFrom(doc); else { model.load(doc); setTimeout(() => V.fit(null, 80, 1), 0); }
  };
  PR.columnFramesCmd = () => {
    const pg = model.page();
    let pages = selPages();
    if (!pages.length) pages = PR.pages(pg);
    if (!pages.length) return O.toast('Немає сторінок публікації');
    PR.columnFrames(pages, { thread: true, filler: true });
    O.history.commit('Текстові фрейми в колонках');
  };

  O.cmd('pubNew', 'Новий журнал / публікація…', () => PR.newPub(), { keys: ['Ctrl+Alt+Shift+N'], group: 'Публікація' });
  O.cmd('pubAddPages', 'Додати сторінки…', () => PR.addPages(), { group: 'Публікація' });
  O.cmd('pubDeletePages', 'Видалити виділені сторінки', () => PR.deletePages(), { group: 'Публікація' });
  O.cmd('pubRelayout', 'Перенумерувати й перекомпонувати розвороти', () => { const pg = pubPage(); if (pg) { PR.relayout(pg); O.history.commit('Розвороти'); } }, { group: 'Публікація' });
  O.cmd('pubApplyMaster', 'Застосувати шаблонну сторінку…', () => PR.applyMasterDlg(), { group: 'Публікація' });
  O.cmd('pubNewMaster', 'Нова шаблонна сторінка (Musterseite)', () => PR.newMaster(), { group: 'Публікація' });
  O.cmd('pubPageNumber', 'Вставити автоматичний номер сторінки', () => PR.pageNumber(), { keys: ['Ctrl+Alt+Shift+3'], group: 'Публікація' });
  O.cmd('pubMargins', 'Поля та колонки…', () => PR.marginsDlg(), { group: 'Публікація' });
  O.cmd('pubBaseline', 'Базова сітка (Grundlinienraster)…', () => PR.baselineDlg(), { group: 'Публікація' });
  O.cmd('pubSnapBaseline', 'Вирівняти текст за базовою сіткою', () => PR.snapBaseline(), { group: 'Публікація' });
  O.cmd('pubColumns', 'Текстові фрейми в колонках', () => PR.columnFramesCmd(), { group: 'Публікація' });
  O.cmd('pubThread', 'Зв’язати текстові фрейми', () => PR.thread(), { group: 'Публікація' });
  O.cmd('pubUnthread', 'Розірвати зв’язок текстових фреймів', () => PR.unthread(), { group: 'Публікація' });
  O.cmd('pubPlaceText', 'Помістити текст…', () => PR.placeText(), { group: 'Публікація' });
  O.cmd('pubStyles', 'Базові стилі абзаців', () => { PR.defaultStyles(); O.history.commit('Стилі абзаців'); O.toast('Стилі абзаців додано: виділіть текст і оберіть стиль на панелі «Дизайн»'); }, { group: 'Публікація' });
  O.cmd('pubPreflight', 'Перевірка перед друком (Preflight)…', () => PR.preflight(), { keys: ['Ctrl+Alt+Shift+F'], group: 'Публікація' });
  O.cmd('pubExport', 'Експорт публікації в PDF…', () => PR.exportPub(), { group: 'Публікація' });

  O.MENUS.splice(O.MENUS.findIndex(m => m[0] === 'Вигляд'), 0, ['Публікація', ['pubNew', 'psNew', 'aFormat', '-', 'pubAddPages', 'pubDeletePages', 'pubRelayout', '-', 'pubNewMaster', 'pubApplyMaster', 'pubPageNumber', '-', 'pubMargins', 'pubBaseline', 'pubSnapBaseline', '-', 'pubColumns', 'pubPlaceText', 'pubThread', 'pubUnthread', 'pubStyles', '-', 'pubPreflight', 'pubExport']]);
  const viewMenu = O.MENUS.find(m => m[0] === 'Вигляд');
  if (viewMenu) viewMenu[1].splice(viewMenu[1].indexOf('grid') + 1, 0, 'printGuides', 'baselineShow');
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл')[1];
  fileMenu.splice(Math.max(0, fileMenu.indexOf('new') + 1), 0, 'psNew', 'aFormat', 'pubNew');
  if (O.projects) {
    O.projects.templates.push(
      { id: 'psnew', name: 'Набори Photoshop…', icon: 'image', size: t('Фото · Друк · Відео'), make: () => PR.newDocument() },
      { id: 'mag', name: 'Журнал / буклет (InDesign)', icon: 'page', size: 'A4 · ' + t('розвороти'), make: async () => { const v = await PR.pubDialog({ inCurrent: true }); if (!v) return null; const doc = model.newDoc(); doc.name = v.name; const pg = PR.buildPub(doc, v); const prev = S.doc; S.doc = doc; try { PR.defaultStyles(); } finally { S.doc = prev; } doc.pages = [pg].concat(doc.pages.filter(p => p !== pg)); return doc; } },
      { id: 'aseries', name: 'Аркуші A0 … A14', icon: 'page', size: '2384×3370 … 17×26', make: () => { const d = model.newDoc(); d.name = t('Формати A'); const prev = S.doc; S.doc = d; try { let x = 0; for (const a of PR.A) { const w = PR.mmToPx(a.w), h = PR.mmToPx(a.h); d.pages[0].children.push(model.create('frame', { name: PR.frameName(a.name, w, h), w, h, m: M.translate(x, 0), fills: [O.paint.solid('#FFFFFF')] })); x += w + 60; } } finally { S.doc = prev; } return d; } }
    );
    const a4 = O.projects.templates.find(x => x.id === 'a4');
    if (a4) a4.make = () => O.projects.framesDoc(t('Постер A4'), [[PR.frameName('A4', 595, 842), 595, 842]]);
  }
})();
