'use strict';
/* VIBSma — video editor in the spirit of CapCut, with a DaVinci-style Color page.
   S.doc.video = { ratio, w, h, fps, bg, bgMode, magnet, tracks[], clips[] }
   tracks: main video track (magnet keeps it gap-free), overlays, text, audio.
   clips: video / image / frame (a design frame of this document) / text / color / audio, with start, dur, in, speed,
   volume, fades, transform (x, y, scale, rot, opacity), crop, fit, in/out animations, transition, effects, keyframes,
   a colour grade (see grade.js). Preview and export share one compositor; export records the canvas + audio. */
(function () {
  const O = window.O, model = O.model, S = O.state, ui = O.ui, io = O.io, GR = O.grade;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const VE = O.video = {};
  // CapCut canvas formats (+ 4K and cinema); 'custom' is set by VE.setSize
  const RATIOS = [['16:9', 1920, 1080], ['9:16', 1080, 1920], ['1:1', 1080, 1080], ['4:5', 1080, 1350], ['4:3', 1440, 1080], ['3:4', 1080, 1440], ['21:9', 2560, 1080], ['2.35:1', 2538, 1080], ['2:1', 2160, 1080], ['1.85:1', 1998, 1080], ['3:2', 1620, 1080], ['2:3', 1080, 1620], ['5.8″', 1125, 2436], ['16:9 4K', 3840, 2160], ['9:16 4K', 2160, 3840], ['16:9 720p', 1280, 720]];
  // platform presets (CapCut «Canvas» list + social networks) — also shown in «New document»
  VE.PLATFORMS = [['TikTok', 1080, 1920], ['YouTube', 1920, 1080], ['YouTube 4K', 3840, 2160], ['YouTube Shorts', 1080, 1920], ['Instagram Reels', 1080, 1920], ['Instagram Stories', 1080, 1920], ['Instagram: квадрат 1:1', 1080, 1080], ['Instagram: портрет 4:5', 1080, 1350], ['Facebook: відео 16:9', 1920, 1080], ['Facebook: пост 1:1', 1080, 1080], ['X (Twitter) 16:9', 1280, 720], ['LinkedIn 1:1', 1080, 1080], ['Pinterest 2:3', 1000, 1500], ['Snapchat 9:16', 1080, 1920], ['Кіно 2.35:1', 2538, 1080], ['Широкий 21:9', 2560, 1080], ['Класичний 4:3', 1440, 1080], ['Портрет 3:4', 1080, 1440], ['iPhone 5.8″', 1125, 2436]];
  const TRANS = [['none', 'Без переходу'], ['dissolve', 'Розчинення'], ['black', 'Через чорне'], ['white', 'Через біле'], ['slideL', 'Зсув ліворуч'], ['slideR', 'Зсув праворуч'], ['slideU', 'Зсув угору'], ['zoomIn', 'Наближення'], ['zoomOut', 'Віддалення'], ['wipeL', 'Шторка'], ['wipeR', 'Шторка праворуч'], ['wipeU', 'Шторка вгору'], ['circle', 'Коло'], ['diamond', 'Ромб'], ['blur', 'Розмиття'], ['spin', 'Обертання'], ['flashT', 'Спалах'], ['glitchT', 'Глітч']];
  const ANIMS_IN = [['none', 'Немає'], ['fade', 'Поява'], ['zoomIn', 'Збільшення'], ['zoomOut', 'Зменшення'], ['slideL', 'Виїзд зліва'], ['slideR', 'Виїзд справа'], ['slideU', 'Виїзд знизу'], ['spin', 'Обертання'], ['pop', 'Поп'], ['type', 'Друкарська машинка']];
  const ANIMS_OUT = [['none', 'Немає'], ['fade', 'Зникнення'], ['zoomIn', 'Збільшення'], ['zoomOut', 'Зменшення'], ['slideL', 'Виїзд ліворуч'], ['slideR', 'Виїзд праворуч'], ['slideD', 'Виїзд униз'], ['spin', 'Обертання']];
  const EFFECTS = [['blur', 'Розмиття'], ['vignette', 'Віньєтка'], ['grain', 'Плівкове зерно'], ['shake', 'Тремтіння камери'], ['pulse', 'Пульсація'], ['mirror', 'Дзеркало'], ['flash', 'Спалахи'], ['bw', 'Чорно-білий'], ['invert', 'Негатив'], ['sepia', 'Сепія'], ['beauty', 'Згладжування шкіри'], ['letterbox', 'Кіношні смуги'], ['lightleak', 'Засвітка плівки'], ['film', 'Старе кіно'], ['vhs', 'VHS'], ['glitch', 'Глітч'], ['rgb', 'RGB-зсув'], ['pixelate', 'Пікселізація']];
  // effects that need the clip rendered into its own layer first
  const LAYER_FX = new Set(['vhs', 'glitch', 'rgb', 'pixelate']);
  // more effects plug in here (vfx.js): { id, label, cat, kind: 'motion' | 'filter' | 'over' | 'layer' | 'frame', run }
  VE.EFFECTS = EFFECTS;
  VE.FX = new Map();
  VE.defFx = (id, label, cat, kind, run) => { VE.FX.set(id, { id, label, cat, kind, run }); if (!EFFECTS.some(e => e[0] === id)) EFFECTS.push([id, label]); };
  const xfx = (c, kind) => (c.fx || []).map(e => VE.FX.get(e)).filter(d => d && d.kind === kind);
  // extra tabs of the media bin (templates, backgrounds): VE.BIN_EXTRA[tab] = { label, render }
  VE.BIN_EXTRA = {};
  const BLENDS = [['normal', 'Звичайний'], ['multiply', 'Множення'], ['screen', 'Екран'], ['overlay', 'Перекриття'], ['darken', 'Затемнення'], ['lighten', 'Освітлення'], ['color-dodge', 'Освітлення основи'], ['color-burn', 'Затемнення основи'], ['hard-light', 'Жорстке світло'], ['soft-light', 'М’яке світло'], ['difference', 'Різниця'], ['exclusion', 'Виключення'], ['hue', 'Тон'], ['saturation', 'Насиченість'], ['color', 'Колір'], ['luminosity', 'Яскравість']];
  const MASKS = [['none', 'Без маски'], ['linear', 'Лінійна'], ['mirror', 'Дзеркальна смуга'], ['circle', 'Коло'], ['rect', 'Прямокутник'], ['heart', 'Серце'], ['star', 'Зірка']];
  // CapCut speed curves: speed multipliers over the clip (normalised so the duration stays)
  const CURVES = [['none', 'Без кривої'], ['montage', 'Монтаж'], ['hero', 'Герой'], ['bullet', 'Куля'], ['jump', 'Стрибок'], ['flashIn', 'Спалах на вході'], ['flashOut', 'Спалах на виході']];
  const CURVE_PTS = { montage: [1.6, 1.6, 0.4, 0.4, 1.6, 1.6, 0.4, 0.4, 1.6], hero: [1.6, 1.6, 1.6, 0.2, 0.2, 0.2, 1.6, 1.6, 1.6], bullet: [2, 2, 0.15, 0.15, 0.15, 0.15, 2, 2, 2], jump: [1, 1, 1, 3, 3, 1, 1, 1, 1], flashIn: [3, 2.5, 1.5, 0.8, 0.6, 0.6, 0.6, 0.6, 0.6], flashOut: [0.6, 0.6, 0.6, 0.6, 0.6, 0.8, 1.5, 2.5, 3] };
  const VOICES = [['none', 'Без ефекту'], ['telephone', 'Телефон'], ['radio', 'Радіо'], ['megaphone', 'Мегафон'], ['echo', 'Луна'], ['hall', 'Зал'], ['robot', 'Робот'], ['underwater', 'Під водою']];
  const STICKERS = ['😀', '😂', '😍', '🥳', '😎', '🤯', '😭', '👍', '👏', '🙌', '🔥', '✨', '💥', '⭐', '❤️', '💯', '🎉', '🎵', '📍', '➡️', '⬇️', '✅', '❌', '⚡', '🌈', '☀️', '🌙', '🍕', '☕', '🎬', '📸', '💡'];
  const TEXT_PRESETS = [
    ['Заголовок', { size: 120, weight: 800, color: '#FFFFFF', stroke: 0, bg: '' }],
    ['Субтитр', { size: 56, weight: 600, color: '#FFFFFF', stroke: 6, strokeColor: '#000000', bg: '', y: 0.36 }],
    ['Підпис з тлом', { size: 52, weight: 700, color: '#111111', bg: '#FFD84D', y: 0.3 }],
    ['Неон', { size: 110, weight: 700, color: '#FFFFFF', glow: '#FF3DCB' }],
    ['Контур', { size: 120, weight: 900, color: 'rgba(0,0,0,0)', stroke: 5, strokeColor: '#FFFFFF' }],
    ['Мінімал', { size: 64, weight: 300, color: '#FFFFFF', font: 'Playfair Display' }],
    ['Жовтий субтитр', { size: 58, weight: 800, color: '#FFE14D', stroke: 6, strokeColor: '#000000', y: 0.36 }],
    ['Кіно-титр', { size: 92, weight: 600, color: '#F4E9D8', font: 'Cinzel' }],
    ['Ретро', { size: 110, weight: 400, color: '#FF7A59', stroke: 4, strokeColor: '#2B1B5A', font: 'Pacifico' }],
    ['Тег', { size: 48, weight: 800, color: '#FFFFFF', bg: '#FF3B5C', y: -0.3 }],
    ['Тінь', { size: 104, weight: 800, color: '#FFFFFF', glow: '#000000' }],
    ['Рукопис', { size: 96, weight: 400, color: '#FFFFFF', font: 'Caveat' }]
  ];
  const KF_PROPS = ['x', 'y', 'scale', 'rot', 'opacity', 'volume'];

  // ======================================================================
  // MODEL
  // ======================================================================
  const tr = (kind, name, extra) => Object.assign({ id: O.uid(), kind, name }, extra || {});
  VE.newProject = () => ({ ratio: '16:9', w: 1920, h: 1080, fps: 30, bg: '#000000', bgMode: 'color', magnet: true, tracks: [tr('text', 'Текст'), tr('overlay', 'Накладання'), tr('video', 'Головна', { main: true }), tr('audio', 'Аудіо')] });
  VE.doc = () => { if (!S.doc.video) S.doc.video = VE.newProject(); const v = S.doc.video; v.clips = v.clips || []; return v; };
  const D = () => VE.doc();
  const track = id => D().tracks.find(x => x.id === id);
  const mainTrack = () => D().tracks.find(x => x.main) || D().tracks.find(x => x.kind === 'video');
  const clipsOn = id => D().clips.filter(c => c.track === id).sort((a, b) => a.start - b.start);
  VE.duration = () => D().clips.reduce((m, c) => Math.max(m, c.start + c.dur), 0);
  const assetDur = a => (a && isFinite(a.duration) && a.duration > 0 ? a.duration : 0);
  VE.newClip = (kind, props) => Object.assign({ id: O.uid(), kind, start: 0, dur: 5, in: 0, speed: 1, volume: 1, fadeIn: 0, fadeOut: 0, x: 0, y: 0, scale: 1, rot: 0, opacity: 1, fit: 'contain', crop: { l: 0, t: 0, r: 0, b: 0 }, anim: { in: 'none', out: 'none', d: 0.5 }, trans: { type: 'none', d: 0.6 }, fx: [], grade: null, kf: {} }, props);
  // keep the main track gap-free (CapCut «magnet»)
  const pack = () => {
    const v = D();
    if (!v.magnet) return;
    let x = 0;
    for (const c of clipsOn(mainTrack().id)) { c.start = Math.round(x * 1000) / 1000; x += c.dur; }
  };
  let playhead = 0, selected = null, zoom = 80, playing = false, colorPage = false, bypass = false, exporting = null;
  const commit = label => { pack(); O.history.commit(label); VE.refresh(); };

  // ---------- adding media ----------
  const isImage = a => a && typeof a.data === 'string' && /^data:image\//.test(a.data);
  const kindOfAsset = a => (a ? (a.kind === 'video' || /^data:video\//.test(a.data || '') ? 'video' : a.kind === 'audio' || /^data:audio\//.test(a.data || '') ? 'audio' : isImage(a) && !a.thumbOf ? 'image' : null) : null);
  VE.addAsset = (id, opts = {}) => {
    const a = S.doc.assets[id];
    const kind = kindOfAsset(a);
    if (!kind) return null;
    const v = D();
    const tid = opts.track || (kind === 'audio' ? (v.tracks.find(x => x.kind === 'audio') || {}).id : opts.overlay ? (v.tracks.find(x => x.kind === 'overlay') || {}).id : mainTrack().id);
    const dur = kind === 'image' ? 4 : (assetDur(a) || 5);
    const onMain = tid === mainTrack().id;
    const start = opts.at !== undefined ? opts.at : onMain && v.magnet ? VE.duration.call(null, tid) : playhead;
    const c = VE.newClip(kind, { track: tid, asset: id, name: a.name || t(kind === 'video' ? 'Відео' : kind === 'audio' ? 'Аудіо' : 'Фото'), start: onMain && v.magnet ? clipsOn(tid).reduce((m, x) => Math.max(m, x.start + x.dur), 0) : start, dur, fit: 'contain' });
    v.clips.push(c);
    selected = c.id;
    return c;
  };
  VE.addFrame = (frameId) => {
    const f = model.get(frameId);
    if (!f) return null;
    const v = D();
    const c = VE.newClip('frame', { track: mainTrack().id, frame: frameId, name: f.name, dur: 4, start: clipsOn(mainTrack().id).reduce((m, x) => Math.max(m, x.start + x.dur), 0) });
    v.clips.push(c); selected = c.id; return c;
  };
  VE.addText = (i = 0) => {
    const v = D();
    const [name, p] = TEXT_PRESETS[i];
    const tid = (v.tracks.find(x => x.kind === 'text') || mainTrack()).id;
    const c = VE.newClip('text', { track: tid, name: t(name), start: playhead, dur: 3, y: (p.y || 0) * v.h, text: Object.assign({ content: t(name === 'Субтитр' ? 'Ваш текст тут' : name), font: p.font || 'Inter', size: 96, weight: 700, color: '#FFFFFF', stroke: 0, strokeColor: '#000000', bg: '', glow: '', align: 'center', italic: false }, p), anim: { in: 'fade', out: 'fade', d: 0.4 } });
    delete c.text.y;
    if (p.font && O.fonts && O.fonts.load) O.fonts.load(p.font).then(() => VE.draw()).catch(() => {});
    v.clips.push(c); selected = c.id; return c;
  };
  // emoji sticker: a text clip with a «pop» entrance
  VE.addSticker = (emoji) => {
    const v = D();
    const tid = (v.tracks.find(x => x.kind === 'text') || mainTrack()).id;
    const c = VE.newClip('text', { track: tid, name: t('Стікер'), start: playhead, dur: 3, text: { content: emoji, font: 'Inter', size: Math.round(Math.min(v.w, v.h) * 0.22), weight: 400, color: '#FFFFFF', stroke: 0, strokeColor: '#000000', bg: '', glow: '', align: 'center', italic: false }, anim: { in: 'pop', out: 'fade', d: 0.35 } });
    v.clips.push(c); selected = c.id; return c;
  };
  // an extra track (CapCut lets you stack as many overlays as you like)
  VE.addTrack = kind => {
    const v = D();
    const n = v.tracks.filter(x => x.kind === kind).length + 1;
    const tk = tr(kind, t(kind === 'audio' ? 'Аудіо' : kind === 'text' ? 'Текст' : 'Накладання') + ' ' + n);
    if (kind === 'audio') v.tracks.push(tk); else v.tracks.unshift(tk);
    return tk;
  };
  // «Extract audio»: the sound of a video clip goes to its own audio clip, the video is muted
  VE.extractAudio = () => {
    const c = sel();
    if (!c || c.kind !== 'video') return O.toast('Виділіть відеокліп');
    const v = D();
    const at = v.tracks.find(x => x.kind === 'audio' && !clipsOn(x.id).some(o => o.start < c.start + c.dur && o.start + o.dur > c.start)) || VE.addTrack('audio');
    const a = Object.assign(O.clone(c), { id: O.uid(), kind: 'audio', track: at.id, name: (c.name || '') + ' — ' + t('аудіо'), fx: [], grade: null, mask: null, chroma: null, trans: { type: 'none', d: 0.6 }, anim: { in: 'none', out: 'none', d: 0.5 } });
    c.volume = 0; if (c.kf) delete c.kf.volume;
    v.clips.push(a); selected = a.id;
    commit('Відокремити аудіо');
  };
  // probe duration and size of a video / audio file
  const probe = (url, kind) => new Promise(res => {
    const el = document.createElement(kind === 'audio' ? 'audio' : 'video');
    el.preload = 'metadata'; el.muted = true;
    const done = info => { el.src = ''; res(info); };
    el.onloadedmetadata = async () => {
      let d = el.duration;
      if (!isFinite(d)) { el.currentTime = 1e9; await new Promise(r => { el.ontimeupdate = r; setTimeout(r, 2000); }); d = el.duration; el.currentTime = 0; }
      let thumb = '';
      if (kind === 'video') {
        await new Promise(r => { el.onseeked = r; el.currentTime = Math.min(0.5, (d || 1) / 3); setTimeout(r, 2500); });
        try { const cv = document.createElement('canvas'); const k = 160 / Math.max(1, el.videoWidth); cv.width = 160; cv.height = Math.max(1, Math.round(el.videoHeight * k)); cv.getContext('2d').drawImage(el, 0, 0, cv.width, cv.height); thumb = cv.toDataURL('image/jpeg', 0.7); } catch (e) { /* no frame */ }
      }
      done({ duration: d, w: el.videoWidth || 0, h: el.videoHeight || 0, thumb });
    };
    el.onerror = () => done({ duration: NaN, w: 0, h: 0, thumb: '' });
    setTimeout(() => done({ duration: NaN, w: 0, h: 0, thumb: '' }), 15000);
    el.src = url;
  });
  VE.importFiles = async files => {
    const added = [];
    for (const f of files) {
      const isA = /^audio\//.test(f.type) || /\.(mp3|wav|ogg|oga|opus|m4a|aac|flac|weba)$/i.test(f.name);
      const isV = /^video\//.test(f.type) || /\.(mp4|m4v|webm|mov|mkv|ogv)$/i.test(f.name);
      try {
        if (!isA && !isV) { const a = await io.addAsset(await io.blobToData(f), f.name.replace(/\.[^.]+$/, '')); added.push(a.id); continue; }
        const data = await io.blobToData(f.type ? f : new Blob([f], { type: isA ? 'audio/mpeg' : 'video/mp4' }));
        const url = URL.createObjectURL(f);
        const info = await probe(url, isA ? 'audio' : 'video');
        URL.revokeObjectURL(url);
        const id = O.uid();
        S.doc.assets[id] = { data, kind: isA ? 'audio' : 'video', name: f.name.replace(/\.[^.]+$/, ''), duration: info.duration, w: info.w, h: info.h, thumb: info.thumb, size: f.size };
        added.push(id);
      } catch (e) { console.warn(e); O.toast('Не вдалося відкрити «{name}»', { name: f.name }); }
    }
    return added;
  };

  // ======================================================================
  // EVALUATION (keyframes, animations, transitions)
  // ======================================================================
  const ease = x => (x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2);
  VE.val = (c, prop, local) => {
    const k = c.kf && c.kf[prop];
    if (!k || !k.length) return c[prop];
    if (local <= k[0].t) return k[0].v;
    if (local >= k[k.length - 1].t) return k[k.length - 1].v;
    for (let i = 0; i < k.length - 1; i++) if (local >= k[i].t && local <= k[i + 1].t) { const p = (local - k[i].t) / Math.max(1e-6, k[i + 1].t - k[i].t); return k[i].v + (k[i + 1].v - k[i].v) * ease(p); }
    return c[prop];
  };
  // speed curve: multiplier at a point p ∈ [0, 1] of the clip (piecewise linear, average 1)
  const curveNorm = new Map();
  const curveAt = (name, p) => {
    const pts = CURVE_PTS[name];
    if (!pts) return 1;
    if (!curveNorm.has(name)) { let s = 0; for (let i = 0; i < 200; i++) { const q = (i + 0.5) / 200 * (pts.length - 1), j = Math.floor(q); s += pts[j] + (pts[Math.min(pts.length - 1, j + 1)] - pts[j]) * (q - j); } curveNorm.set(name, s / 200); }
    const q = Math.max(0, Math.min(1, p)) * (pts.length - 1), j = Math.floor(q);
    return (pts[j] + (pts[Math.min(pts.length - 1, j + 1)] - pts[j]) * (q - j)) / curveNorm.get(name);
  };
  VE.curveAt = curveAt;
  // seconds of source consumed after lt seconds of the clip
  const srcOffset = (c, lt) => {
    if (!c.curve || c.curve === 'none') return lt * c.speed;
    const n = 48, d = Math.max(0.001, c.dur);
    let s = 0;
    for (let i = 0; i < n; i++) { const a = lt * i / n, b = lt * (i + 1) / n; s += (b - a) * curveAt(c.curve, (a + b) / 2 / d); }
    return s * c.speed;
  };
  const srcTime = (c, tt) => c.in + srcOffset(c, Math.max(0, tt - c.start));
  VE.srcTime = srcTime;

  // ======================================================================
  // MEDIA ELEMENTS + AUDIO
  // ======================================================================
  const pool = new Map();     // clip id → { el, gain }
  const images = new Map();   // asset id → Image
  const frames = new Map();   // frame id → { key, canvas, busy }
  let ac = null, master = null, recDest = null;
  const audio = () => {
    if (!ac) {
      ac = new (window.AudioContext || window.webkitAudioContext)();
      master = ac.createGain(); master.connect(ac.destination);
      recDest = ac.createMediaStreamDestination(); master.connect(recDest);
    }
    if (ac.state === 'suspended') ac.resume().catch(() => {});
    return ac;
  };
  const mediaOf = c => {
    let m = pool.get(c.id);
    const url = O.assetURL(c.asset);
    if (m && m.url === url) return m;
    if (m) { try { m.el.pause(); } catch (e) { /* ignore */ } }
    const el = document.createElement(c.kind === 'audio' ? 'audio' : 'video');
    el.preload = 'auto'; el.playsInline = true; el.crossOrigin = 'anonymous'; el.src = url;
    el.addEventListener('seeked', () => { if (!playing) VE.draw(); });
    el.addEventListener('loadeddata', () => { if (!playing) VE.draw(); });
    m = { el, url, gain: null };
    pool.set(c.id, m);
    return m;
  };
  // element → [noise reduction] → [voice effect] → gain → master; rebuilt when the clip settings change
  let hallIR = null;
  const voiceChain = (a, c) => {
    const nodes = [];
    const bi = (type, f, q) => { const b = a.createBiquadFilter(); b.type = type; b.frequency.value = f; if (q) b.Q.value = q; return b; };
    if (c.denoise) {
      // rumble / hiss cut + gentle expander-like compression (CapCut «Reduce noise»)
      nodes.push(bi('highpass', 90, 0.7), bi('lowpass', 9000, 0.7), bi('notch', 50, 8));
      const comp = a.createDynamicsCompressor(); comp.threshold.value = -38; comp.ratio.value = 3; comp.knee.value = 12; comp.attack.value = 0.005; comp.release.value = 0.2; nodes.push(comp);
    }
    if (c.enhance) { const p = bi('peaking', 3000, 1); p.gain.value = 4; const l = bi('lowshelf', 160); l.gain.value = 2; const comp = a.createDynamicsCompressor(); comp.threshold.value = -20; comp.ratio.value = 3; nodes.push(l, p, comp); }
    const v = c.voice || 'none';
    let tail = null;
    if (v === 'telephone') nodes.push(bi('highpass', 400, 1), bi('lowpass', 3000, 1));
    if (v === 'radio') { nodes.push(bi('highpass', 300, 0.7), bi('lowpass', 4500, 0.7)); const ws = a.createWaveShaper(); const cu = new Float32Array(1024); for (let i = 0; i < 1024; i++) { const x = i / 512 - 1; cu[i] = Math.tanh(x * 2.2); } ws.curve = cu; nodes.push(ws); }
    if (v === 'megaphone') { nodes.push(bi('bandpass', 1500, 1.2)); const ws = a.createWaveShaper(); const cu = new Float32Array(1024); for (let i = 0; i < 1024; i++) { const x = i / 512 - 1; cu[i] = Math.tanh(x * 6); } ws.curve = cu; nodes.push(ws); }
    if (v === 'underwater') nodes.push(bi('lowpass', 500, 4));
    if (v === 'echo' || v === 'hall' || v === 'robot') {
      // parallel wet path built around an input node
      const inp = a.createGain(), out = a.createGain();
      inp.connect(out);
      if (v === 'echo') { const d = a.createDelay(1); d.delayTime.value = 0.28; const fb = a.createGain(); fb.gain.value = 0.42; inp.connect(d); d.connect(fb); fb.connect(d); d.connect(out); }
      if (v === 'hall') { if (!hallIR || hallIR.sampleRate !== a.sampleRate) { const len = a.sampleRate * 2.6; hallIR = a.createBuffer(2, len, a.sampleRate); for (let ch = 0; ch < 2; ch++) { const d = hallIR.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3); } } const cv = a.createConvolver(); cv.buffer = hallIR; const wg = a.createGain(); wg.gain.value = 0.55; inp.connect(cv); cv.connect(wg); wg.connect(out); }
      if (v === 'robot') { inp.disconnect(); const ring = a.createGain(); ring.gain.value = 0; const osc = a.createOscillator(); osc.frequency.value = 55; osc.connect(ring.gain); osc.start(); inp.connect(ring); ring.connect(out); }
      nodes.push(inp); tail = out;
    }
    return { nodes, tail };
  };
  const routeAudio = (m, c) => {
    try {
      const a = audio();
      if (!m.src) { m.src = a.createMediaElementSource(m.el); m.gain = a.createGain(); m.gain.connect(master); }
      const key = c ? [c.voice || 'none', !!c.denoise, !!c.enhance].join('|') : 'none';
      if (m.key === key) return;
      m.key = key;
      try { m.src.disconnect(); } catch (e) { /* ignore */ }
      (m.chain || []).forEach(n => { try { n.disconnect(); } catch (e) { /* ignore */ } });
      const { nodes, tail } = c ? voiceChain(a, c) : { nodes: [], tail: null };
      let cur = m.src;
      for (const n of nodes) { cur.connect(n); cur = n; }
      if (tail) cur = tail;
      cur.connect(m.gain);
      m.chain = nodes.concat(tail ? [tail] : []);
    } catch (e) { console.warn(e); }
  };
  const imageOf = id => {
    let im = images.get(id);
    if (!im) { im = new Image(); im.onload = () => { if (!playing) VE.draw(); }; im.src = O.assetURL(id); images.set(id, im); }
    return im.complete && im.naturalWidth ? im : null;
  };
  const frameOf = c => {
    const f = model.get(c.frame);
    if (!f) return null;
    const key = JSON.stringify(f).length + ':' + f.w + 'x' + f.h + ':' + (f.children || []).length;
    let e = frames.get(c.frame);
    if (!e || (e.key !== key && !e.busy)) {
      e = { key, canvas: e && e.canvas, busy: true };
      frames.set(c.frame, e);
      const sc = Math.min(2, 1920 / Math.max(f.w, f.h));
      io.renderImage([f], { scale: sc, type: 'image/png' }).then(r => { e.canvas = r.canvas; e.busy = false; if (!playing) VE.draw(); }).catch(() => { e.busy = false; });
    }
    return e.canvas || null;
  };
  // keep media elements in step with the playhead
  const syncMedia = (tt, play) => {
    const v = D();
    const solo = null;
    void solo;
    for (const c of v.clips) {
      if (c.kind !== 'video' && c.kind !== 'audio') continue;
      const tk = track(c.track);
      const m = mediaOf(c);
      const active = tt >= c.start - 0.05 && tt < c.start + c.dur;
      const local = srcTime(c, tt);
      if (!active) { if (!m.el.paused) m.el.pause(); continue; }
      if (play) {
        routeAudio(m, c);
        const lt = Math.max(0, tt - c.start);
        let vol = VE.val(c, 'volume', lt);
        if (c.fadeIn && lt < c.fadeIn) vol *= lt / c.fadeIn;
        if (c.fadeOut && c.dur - lt < c.fadeOut) vol *= Math.max(0, (c.dur - lt) / c.fadeOut);
        if (tk && tk.mute) vol = 0;
        if (m.gain) m.gain.gain.value = Math.max(0, vol); else m.el.volume = Math.min(1, Math.max(0, vol));
        m.el.playbackRate = Math.min(16, Math.max(0.0625, c.speed * (c.curve && c.curve !== 'none' ? curveAt(c.curve, lt / Math.max(0.001, c.dur)) : 1)));
        if ('preservesPitch' in m.el) m.el.preservesPitch = !c.pitchShift;
        if (m.el.paused) { try { m.el.currentTime = local; } catch (e) { /* not ready */ } m.el.play().catch(() => {}); }
        else if (Math.abs(m.el.currentTime - local) > 0.3) { try { m.el.currentTime = local; } catch (e) { /* ignore */ } }
      } else {
        if (!m.el.paused) m.el.pause();
        if (c.kind === 'video' && Math.abs(m.el.currentTime - local) > 0.03) { try { m.el.currentTime = local; } catch (e) { /* ignore */ } }
      }
    }
  };
  const stopAll = () => { for (const m of pool.values()) { try { m.el.pause(); } catch (e) { /* ignore */ } } };

  // ======================================================================
  // COMPOSITOR
  // ======================================================================
  const grain = (() => { const cv = document.createElement('canvas'); cv.width = cv.height = 128; const c = cv.getContext('2d'); const d = c.createImageData(128, 128); for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 40; } c.putImageData(d, 0, 0); return cv; })();
  // ---------- chroma key (WebGL2): key colour → transparent, with smoothness and spill suppression ----------
  const CK = { gl: null, cv: null, prog: null, tex: null };
  const chromaKey = (src, w, h, o) => {
    if (!CK.gl) {
      CK.cv = document.createElement('canvas');
      const gl = CK.gl = CK.cv.getContext('webgl2', { premultipliedAlpha: false, preserveDrawingBuffer: true });
      if (!gl) return null;
      const sh = (type, s) => { const x = gl.createShader(type); gl.shaderSource(x, s); gl.compileShader(x); if (!gl.getShaderParameter(x, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(x)); return x; };
      const p = gl.createProgram();
      gl.attachShader(p, sh(gl.VERTEX_SHADER, '#version 300 es\nin vec2 a;out vec2 uv;void main(){uv=a*.5+.5;uv.y=1.-uv.y;gl_Position=vec4(a,0,1);}'));
      gl.attachShader(p, sh(gl.FRAGMENT_SHADER, `#version 300 es
precision highp float;in vec2 uv;out vec4 o;uniform sampler2D t;uniform vec3 key;uniform float sim,smo,spill;
vec2 cc(vec3 c){return vec2(-0.1687*c.r-0.3313*c.g+0.5*c.b,0.5*c.r-0.4187*c.g-0.0813*c.b);}
void main(){vec4 s=texture(t,uv);vec3 c=s.rgb;float d=distance(cc(c),cc(key));float base=d-sim;
float a=pow(clamp(base/max(smo,1e-4),0.,1.),1.5);float de=pow(clamp(base/max(spill,1e-4),0.,1.),1.5);
float l=dot(c,vec3(.2126,.7152,.0722));c=mix(vec3(l),c,de);o=vec4(c,s.a*a);}`));
      gl.linkProgram(p); CK.prog = p;
      const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(p, 'a'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      CK.tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, CK.tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    }
    const gl = CK.gl;
    if (!gl) return null;
    const k = Math.min(1, 1920 / Math.max(w, h));
    CK.cv.width = Math.max(1, Math.round(w * k)); CK.cv.height = Math.max(1, Math.round(h * k));
    gl.viewport(0, 0, CK.cv.width, CK.cv.height);
    gl.useProgram(CK.prog);
    gl.bindTexture(gl.TEXTURE_2D, CK.tex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
    const hex = O.color && O.color.norm ? O.color.norm(o.color) || '#00FF00' : o.color;
    const rgb = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16) / 255);
    gl.uniform3f(gl.getUniformLocation(CK.prog, 'key'), rgb[0], rgb[1], rgb[2]);
    gl.uniform1f(gl.getUniformLocation(CK.prog, 'sim'), o.sim === undefined ? 0.4 : o.sim);
    gl.uniform1f(gl.getUniformLocation(CK.prog, 'smo'), o.smooth === undefined ? 0.08 : o.smooth);
    gl.uniform1f(gl.getUniformLocation(CK.prog, 'spill'), o.spill === undefined ? 0.1 : o.spill);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    return CK.cv;
  };
  VE.chromaKey = chromaKey;
  // ---------- layers (masks, blend modes, pixel effects) ----------
  const layerPool = [];
  const getLayer = (W, H, depth) => {
    let L = layerPool[depth];
    if (!L) L = layerPool[depth] = { cv: document.createElement('canvas'), mk: document.createElement('canvas'), tmp: document.createElement('canvas') };
    for (const c of [L.cv, L.mk, L.tmp]) if (c.width !== W || c.height !== H) { c.width = W; c.height = H; }
    L.cv.getContext('2d').clearRect(0, 0, W, H);
    return L;
  };
  let layerDepth = 0;
  const shapePath = (g, type, w, h) => {
    g.beginPath();
    if (type === 'circle') g.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2);
    else if (type === 'rect') { g.roundRect ? g.roundRect(-w / 2, -h / 2, w, h, Math.min(w, h) * 0.04) : g.rect(-w / 2, -h / 2, w, h); }
    else if (type === 'heart') { const s = Math.min(w, h) / 2; g.moveTo(0, s * 0.95); g.bezierCurveTo(-s * 1.6, -s * 0.15, -s * 0.75, -s * 1.15, 0, -s * 0.45); g.bezierCurveTo(s * 0.75, -s * 1.15, s * 1.6, -s * 0.15, 0, s * 0.95); g.closePath(); }
    else if (type === 'star') { const R = Math.min(w, h) / 2, r = R * 0.45; for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r : R; g[i ? 'lineTo' : 'moveTo'](Math.cos(a) * rr, Math.sin(a) * rr); } g.closePath(); }
  };
  const applyMask = (L, m, W, H, k) => {
    const g = L.mk.getContext('2d');
    g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, W, H);
    const f = Math.max(0, (m.feather || 0) * k);
    g.filter = f ? `blur(${Math.round(f)}px)` : 'none';
    g.translate(W / 2 + (m.x || 0) * k, H / 2 + (m.y || 0) * k);
    g.rotate((m.rot || 0) * Math.PI / 180);
    g.fillStyle = '#fff';
    const mw = (m.w || 600) * k, mh = (m.h || 600) * k;
    if (m.type === 'linear') g.fillRect(-W * 2, 0, W * 4, H * 4);
    else if (m.type === 'mirror') g.fillRect(-W * 2, -mh / 2, W * 4, mh);
    else { shapePath(g, m.type, mw, mh); g.fill(); }
    g.setTransform(1, 0, 0, 1, 0, 0); g.filter = 'none';
    const lc = L.cv.getContext('2d');
    lc.save(); lc.globalCompositeOperation = m.invert ? 'destination-out' : 'destination-in'; lc.drawImage(L.mk, 0, 0); lc.restore();
  };
  const rgbShift = (L, W, H, dx) => {
    const lc = L.cv.getContext('2d');
    let id;
    try { id = lc.getImageData(0, 0, W, H); } catch (e) { return; }
    const s = id.data, out = new Uint8ClampedArray(s);
    const d = Math.round(dx);
    for (let y = 0; y < H; y++) {
      const row = y * W * 4;
      for (let x = 0; x < W; x++) {
        const i = row + x * 4;
        const xr = Math.min(W - 1, Math.max(0, x + d)), xb = Math.min(W - 1, Math.max(0, x - d));
        out[i] = s[row + xr * 4]; out[i + 2] = s[row + xb * 4 + 2];
        out[i + 3] = Math.max(s[i + 3], s[row + xr * 4 + 3], s[row + xb * 4 + 3]);
      }
    }
    lc.putImageData(new ImageData(out, W, H), 0, 0);
  };
  const layerFx = (L, c, local, W, H, k) => {
    const fx = c.fx || [], lc = L.cv.getContext('2d');
    const rnd = n => { const x = Math.sin(n * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); };
    if (fx.includes('pixelate')) {
      const px = Math.max(4, Math.round(18 * k)), tw = Math.max(1, Math.round(W / px)), th = Math.max(1, Math.round(H / px));
      const tc = L.tmp.getContext('2d'); tc.clearRect(0, 0, W, H); tc.imageSmoothingEnabled = true; tc.drawImage(L.cv, 0, 0, tw, th);
      lc.clearRect(0, 0, W, H); lc.imageSmoothingEnabled = false; lc.drawImage(L.tmp, 0, 0, tw, th, 0, 0, W, H); lc.imageSmoothingEnabled = true;
    }
    if (fx.includes('glitch')) {
      const fr = Math.floor(local * 12), on = rnd(fr) > 0.55;
      if (on) {
        const tc = L.tmp.getContext('2d'); tc.clearRect(0, 0, W, H); tc.drawImage(L.cv, 0, 0);
        for (let i = 0; i < 7; i++) { const y = rnd(fr * 7 + i) * H, h = (0.02 + rnd(fr * 13 + i) * 0.08) * H, dx = (rnd(fr * 3 + i) - 0.5) * 0.12 * W; lc.clearRect(0, y, W, h); lc.drawImage(L.tmp, 0, y, W, h, dx, y, W, h); }
        rgbShift(L, W, H, 10 * k * (rnd(fr * 5) + 0.5));
      }
    }
    if (fx.includes('rgb')) rgbShift(L, W, H, 7 * k);
    for (const d of xfx(c, 'layer')) { try { d.run(L, local, W, H, k, c); } catch (e) { console.warn(d.id, e); } }
    if (fx.includes('vhs')) {
      rgbShift(L, W, H, 4 * k);
      lc.save(); lc.globalCompositeOperation = 'source-atop';
      lc.fillStyle = 'rgba(0,0,0,.16)'; for (let y = 0; y < H; y += Math.max(2, Math.round(3 * k))) lc.fillRect(0, y, W, Math.max(1, Math.round(k)));
      const band = ((local * 0.23) % 1) * H; const gr = lc.createLinearGradient(0, band - 30 * k, 0, band + 30 * k); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,.18)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); lc.fillStyle = gr; lc.fillRect(0, band - 30 * k, W, 60 * k);
      lc.restore();
    }
  };
  const needsLayer = c => (c.mask && c.mask.type && c.mask.type !== 'none') || (c.blend && c.blend !== 'normal') || (c.fx || []).some(e => LAYER_FX.has(e) || (VE.FX.get(e) || {}).kind === 'layer');
  const sourceOf = c => {
    if (c.kind === 'video') { const m = mediaOf(c); return m.el.readyState >= 2 ? { el: m.el, w: m.el.videoWidth, h: m.el.videoHeight } : null; }
    if (c.kind === 'image') { const im = imageOf(c.asset); return im ? { el: im, w: im.naturalWidth, h: im.naturalHeight } : null; }
    if (c.kind === 'frame') { const cv = frameOf(c); return cv ? { el: cv, w: cv.width, h: cv.height } : null; }
    return null;
  };
  const drawText = (ctx, c, k, progress, local) => {
    const T = c.text || {};
    let s = String(T.content || '');
    if (c.anim.in === 'type' && local < c.anim.d * 2) s = s.slice(0, Math.ceil(s.length * Math.min(1, local / (c.anim.d * 2))));
    const size = (T.size || 96) * k;
    ctx.font = `${T.italic ? 'italic ' : ''}${T.weight || 700} ${size}px "${T.font || 'Inter'}", system-ui, sans-serif`;
    ctx.textAlign = T.align || 'center'; ctx.textBaseline = 'middle';
    const lines = s.split('\n'), lh = size * 1.18;
    const w = Math.max(...lines.map(l => ctx.measureText(l).width), 1);
    const y0 = -((lines.length - 1) * lh) / 2;
    const ax = ctx.textAlign === 'left' ? -w / 2 : ctx.textAlign === 'right' ? w / 2 : 0;
    if (T.bg) { ctx.fillStyle = T.bg; const pad = size * 0.3; const r = size * 0.2; const x = -w / 2 - pad, y = y0 - lh / 2 - pad * 0.4, bw = w + pad * 2, bh = lines.length * lh + pad * 0.8; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, bw, bh, r) : ctx.rect(x, y, bw, bh); ctx.fill(); }
    if (T.glow) { ctx.shadowColor = T.glow; ctx.shadowBlur = size * 0.45; }
    lines.forEach((l, i) => {
      const y = y0 + i * lh;
      if (T.stroke) { ctx.lineWidth = T.stroke * k * 2; ctx.strokeStyle = T.strokeColor || '#000'; ctx.lineJoin = 'round'; ctx.strokeText(l, ax, y); }
      ctx.fillStyle = T.color || '#fff'; ctx.fillText(l, ax, y);
      if (T.glow) { ctx.fillText(l, ax, y); }
    });
    ctx.shadowBlur = 0;
    void progress;
  };
  // the look of a clip at time tt (with an optional transition role)
  const drawClip = (ctx, c, tt, W, H, k, role, raw) => {
    const v = D();
    const local = Math.min(c.dur, Math.max(0, tt - c.start));
    if (!raw && needsLayer(c) && layerDepth < 3) {
      // render into a layer, then mask / pixel effects / blend onto the frame
      const L = getLayer(W, H, layerDepth++);
      try {
        drawClip(L.cv.getContext('2d'), c, tt, W, H, k, role, true);
        if ((c.fx || []).some(e => LAYER_FX.has(e) || (VE.FX.get(e) || {}).kind === 'layer')) layerFx(L, c, local, W, H, k);
        if (c.mask && c.mask.type && c.mask.type !== 'none') applyMask(L, c.mask, W, H, k);
        ctx.save(); ctx.globalCompositeOperation = c.blend && c.blend !== 'normal' ? c.blend : 'source-over'; ctx.drawImage(L.cv, 0, 0); ctx.restore();
      } finally { layerDepth--; }
      return;
    }
    let alpha = VE.val(c, 'opacity', local), sc = VE.val(c, 'scale', local), rot = VE.val(c, 'rot', local), x = VE.val(c, 'x', local) * k, y = VE.val(c, 'y', local) * k;
    // in / out animations
    const d = Math.max(0.05, c.anim.d || 0.5);
    const pin = local < d ? ease(local / d) : 1, pout = c.dur - local < d ? ease((c.dur - local) / d) : 1;
    const A = (kind, p, out) => {
      if (p >= 1) return;
      const q = 1 - p;
      if (kind === 'fade') alpha *= p;
      if (kind === 'zoomIn') { sc *= out ? 1 + q * 0.3 : 0.6 + 0.4 * p; alpha *= p; }
      if (kind === 'zoomOut') { sc *= out ? 1 - q * 0.4 : 1.4 - 0.4 * p; alpha *= p; }
      if (kind === 'slideL') x += (out ? -1 : -1) * q * W;
      if (kind === 'slideR') x += q * W;
      if (kind === 'slideU') y += q * H;
      if (kind === 'slideD') y += q * H;
      if (kind === 'spin') { rot += q * (out ? 180 : -180); alpha *= p; }
      if (kind === 'pop') { sc *= p < 1 ? 0.5 + 0.6 * p - 0.1 * Math.sin(p * Math.PI) : 1; alpha *= Math.min(1, p * 2); }
    };
    if (!role) { A(c.anim.in, pin, false); A(c.anim.out, pout, true); }
    if (role) { alpha *= role.alpha === undefined ? 1 : role.alpha; x += (role.dx || 0) * W; y += (role.dy || 0) * H; sc *= role.scale || 1; rot += role.rot || 0; }
    // effects that move the picture
    for (const e of c.fx || []) {
      if (e === 'shake') { x += Math.sin(local * 41) * 9 * k; y += Math.cos(local * 37) * 7 * k; rot += Math.sin(local * 23) * 0.6; }
      if (e === 'pulse') sc *= 1 + 0.04 * Math.max(0, Math.sin(local * Math.PI * 4));
    }
    const mfx = xfx(c, 'motion');
    if (mfx.length) { const st = { x, y, sc, rot, alpha, sx: 1, sy: 1 }; for (const d of mfx) d.run(st, local, k, W, H, c); ({ x, y, sc, rot, alpha } = st); var flipX = st.sx, flipY = st.sy; }
    if (alpha <= 0.001) return;
    ctx.save();
    ctx.globalAlpha = Math.min(1, alpha);
    ctx.translate(W / 2 + x, H / 2 + y);
    if (rot) ctx.rotate(rot * Math.PI / 180);
    if ((c.fx || []).includes('mirror')) ctx.scale(-1, 1);
    if (mfx.length && (flipX !== 1 || flipY !== 1)) ctx.scale(flipX || 1e-3, flipY || 1e-3);
    const filters = [];
    for (const d of xfx(c, 'filter')) { const f = d.run(local, k, c); if (f) filters.push(f); }
    if ((c.fx || []).includes('blur')) filters.push(`blur(${Math.round(12 * k)}px)`);
    if ((c.fx || []).includes('bw')) filters.push('grayscale(1)');
    if ((c.fx || []).includes('invert')) filters.push('invert(1)');
    if ((c.fx || []).includes('sepia')) filters.push('sepia(0.85)');
    if ((c.fx || []).includes('film')) { const fl = 0.92 + 0.08 * Math.abs(Math.sin(local * 47) * Math.cos(local * 13)); filters.push(`sepia(0.35) contrast(1.1) brightness(${fl.toFixed(3)})`); }
    if (role && role.blur) filters.push(`blur(${Math.round(role.blur * k)}px)`);
    if (filters.length) ctx.filter = filters.join(' ');
    if (role && role.clip) { ctx.beginPath(); role.clip(ctx, W, H); ctx.clip(); }
    if (c.kind === 'text') { ctx.scale(sc, sc); drawText(ctx, c, k, pin, local); ctx.restore(); frameFx(ctx, c, local, W, H, k); return; }
    if (c.kind === 'color') { ctx.scale(sc, sc); ctx.fillStyle = c.color || '#000'; ctx.fillRect(-W / 2, -H / 2, W, H); ctx.restore(); frameFx(ctx, c, local, W, H, k); return; }
    const s = sourceOf(c);
    if (!s || !s.w) { ctx.restore(); return; }
    const cr = c.crop || { l: 0, t: 0, r: 0, b: 0 };
    const sx = s.w * cr.l, sy = s.h * cr.t, sw = Math.max(1, s.w * (1 - cr.l - cr.r)), sh = Math.max(1, s.h * (1 - cr.t - cr.b));
    let dw, dh;
    if (c.fit === 'fill') { dw = W; dh = H; }
    else { const f = c.fit === 'cover' ? Math.max(W / sw, H / sh) : Math.min(W / sw, H / sh); dw = sw * f; dh = sh * f; }
    dw *= sc; dh *= sc;
    let src = s.el, srcRect = [sx, sy, sw, sh];
    if (c.grade && GR.active(c.grade) && !bypass) {
      const gw = Math.min(dw, 1920), gh = dh * gw / dw;
      const tmp = document.createElement('canvas');
      void tmp;
      const g = GR.apply(s.el, c.grade, Math.min(s.w, Math.max(64, gw * s.w / sw)), Math.min(s.h, Math.max(64, gh * s.h / sh)));
      if (g) { src = g; srcRect = [sx * g.width / s.w, sy * g.height / s.h, sw * g.width / s.w, sh * g.height / s.h]; }
    }
    if (c.chroma && c.chroma.on) {
      const kw = src === s.el ? s.w : src.width, kh = src === s.el ? s.h : src.height;
      const kc = chromaKey(src, kw, kh, c.chroma);
      if (kc) { srcRect = [srcRect[0] * kc.width / kw, srcRect[1] * kc.height / kh, srcRect[2] * kc.width / kw, srcRect[3] * kc.height / kh]; src = kc; }
    }
    ctx.drawImage(src, srcRect[0], srcRect[1], srcRect[2], srcRect[3], -dw / 2, -dh / 2, dw, dh);
    if ((c.fx || []).includes('beauty')) { ctx.save(); ctx.globalAlpha *= 0.55; ctx.filter = `blur(${Math.max(1, Math.round(3 * k))}px) brightness(1.06) saturate(1.05)`; ctx.drawImage(src, srcRect[0], srcRect[1], srcRect[2], srcRect[3], -dw / 2, -dh / 2, dw, dh); ctx.restore(); }
    ctx.filter = 'none';
    if ((c.fx || []).includes('vignette')) { const gr = ctx.createRadialGradient(0, 0, Math.min(dw, dh) * 0.25, 0, 0, Math.max(dw, dh) * 0.62); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.75)'); ctx.fillStyle = gr; ctx.fillRect(-dw / 2, -dh / 2, dw, dh); }
    if ((c.fx || []).includes('grain')) { ctx.globalAlpha *= 0.9; ctx.fillStyle = ctx.createPattern(grain, 'repeat'); ctx.save(); ctx.translate((local * 997) % 128, (local * 613) % 128); ctx.fillRect(-dw / 2 - 128, -dh / 2 - 128, dw + 256, dh + 256); ctx.restore(); }
    if ((c.fx || []).includes('flash')) { const f = Math.max(0, Math.sin(local * Math.PI * 2)); if (f > 0.9) { ctx.fillStyle = `rgba(255,255,255,${(f - 0.9) * 6})`; ctx.fillRect(-dw / 2, -dh / 2, dw, dh); } }
    for (const d of xfx(c, 'over')) { ctx.save(); try { d.run(ctx, dw, dh, local, k, c); } catch (e) { console.warn(d.id, e); } ctx.restore(); }
    void v;
    ctx.restore();
    frameFx(ctx, c, local, W, H, k);
  };
  // effects drawn over the whole frame (not transformed with the clip)
  const frameFx = (ctx, c, local, W, H, k) => {
    const fx = c.fx || [];
    for (const d of xfx(c, 'frame')) { ctx.save(); try { d.run(ctx, local, W, H, k, c); } catch (e) { console.warn(d.id, e); } ctx.restore(); }
    if (fx.includes('lightleak')) {
      ctx.save(); ctx.globalCompositeOperation = 'screen';
      const x = W * (0.5 + 0.45 * Math.sin(local * 0.7)), y = H * (0.3 + 0.2 * Math.cos(local * 0.5));
      const gr = ctx.createRadialGradient(x, y, 0, x, y, Math.max(W, H) * 0.6);
      gr.addColorStop(0, 'rgba(255,170,60,.55)'); gr.addColorStop(0.45, 'rgba(255,60,90,.22)'); gr.addColorStop(1, 'rgba(255,60,90,0)');
      ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H); ctx.restore();
    }
    if (fx.includes('film')) { ctx.save(); ctx.globalAlpha = 0.5; ctx.fillStyle = ctx.createPattern(grain, 'repeat'); ctx.translate((local * 769) % 128, (local * 331) % 128); ctx.fillRect(-128, -128, W + 256, H + 256); ctx.restore(); if (Math.sin(local * 29) > 0.97) { ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.fillRect(W * ((local * 7.3) % 1), 0, Math.max(1, k * 2), H); } }
    if (fx.includes('letterbox')) { const bh = Math.max(0, (H - W / 2.35) / 2); ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, bh); ctx.fillRect(0, H - bh, W, bh); }
  };
  // transition into clip c from the previous clip on the same track
  const transitionRoles = (type, p) => {
    switch (type) {
      case 'dissolve': return [{ alpha: 1 - p }, { alpha: p }];
      case 'black': case 'white': return [{ alpha: p < 0.5 ? 1 - p * 2 : 0 }, { alpha: p < 0.5 ? 0 : (p - 0.5) * 2 }];
      case 'slideL': return [{ dx: -p }, { dx: 1 - p }];
      case 'slideR': return [{ dx: p }, { dx: -(1 - p) }];
      case 'slideU': return [{ dy: -p }, { dy: 1 - p }];
      case 'zoomIn': return [{ scale: 1 + p * 0.6, alpha: 1 - p }, { scale: 0.7 + 0.3 * p, alpha: p }];
      case 'zoomOut': return [{ scale: 1 - p * 0.3, alpha: 1 - p }, { scale: 1.4 - 0.4 * p, alpha: p }];
      case 'wipeL': return [{}, { clip: (ctx, W, H) => ctx.rect(-W / 2, -H / 2, W * p, H) }];
      case 'circle': return [{}, { clip: (ctx, W, H) => ctx.arc(0, 0, Math.hypot(W, H) / 2 * p, 0, Math.PI * 2) }];
      case 'wipeR': return [{}, { clip: (ctx, W, H) => ctx.rect(W / 2 - W * p, -H / 2, W * p, H) }];
      case 'wipeU': return [{}, { clip: (ctx, W, H) => ctx.rect(-W / 2, H / 2 - H * p, W, H * p) }];
      case 'diamond': return [{}, { clip: (ctx, W, H) => { const r = (W + H) / 2 * p; ctx.moveTo(0, -r); ctx.lineTo(r, 0); ctx.lineTo(0, r); ctx.lineTo(-r, 0); ctx.closePath(); } }];
      case 'spin': return [{ alpha: 1 - p, scale: 1 - p * 0.5, rot: p * 180 }, { alpha: p, scale: 0.5 + p * 0.5, rot: -(1 - p) * 180 }];
      case 'flashT': return [{ alpha: p < 0.5 ? 1 : 0 }, { alpha: p < 0.5 ? 0 : 1 }];
      case 'glitchT': { const j = Math.sin(p * 91) * 0.04 * (1 - Math.abs(p - 0.5) * 2); return [{ alpha: p < 0.5 ? 1 : 0, dx: j }, { alpha: p < 0.5 ? 0 : 1, dx: -j }]; }
      case 'blur': return [{ alpha: 1 - p, blur: 30 * p }, { alpha: p, blur: 30 * (1 - p) }];
      default: return [{ alpha: 0 }, {}];
    }
  };
  VE.renderAt = (ctx, tt, W, H) => {
    const v = D();
    const k = W / v.w;
    ctx.save();
    ctx.fillStyle = v.bg || '#000'; ctx.fillRect(0, 0, W, H);
    const vis = v.tracks.filter(x => x.kind !== 'audio' && !x.hidden);
    // render order: main track first, then overlays below → above in the list order reversed (top of the list is drawn last)
    const order = vis.slice().reverse();
    const main = mainTrack();
    if (v.bgMode === 'blur') {
      const c = clipsOn(main.id).find(x => tt >= x.start && tt < x.start + x.dur);
      if (c && (c.kind === 'video' || c.kind === 'image' || c.kind === 'frame')) {
        const s = sourceOf(c);
        if (s && s.w) { ctx.filter = `blur(${Math.round(40 * k)}px) brightness(0.7)`; const f = Math.max(W / s.w, H / s.h) * 1.1; ctx.drawImage(s.el, (W - s.w * f) / 2, (H - s.h * f) / 2, s.w * f, s.h * f); ctx.filter = 'none'; }
      }
    }
    for (const tk of order) {
      const list = clipsOn(tk.id);
      for (let i = 0; i < list.length; i++) {
        const c = list[i];
        if (c.kind === 'audio') continue;
        const tdur = c.trans && c.trans.type !== 'none' ? Math.min(c.trans.d || 0.6, c.dur) : 0;
        const prev = list[i - 1];
        const inTrans = tdur && prev && Math.abs(prev.start + prev.dur - c.start) < 0.05 && tt >= c.start - tdur / 2 && tt < c.start + tdur / 2;
        if (inTrans) {
          const p = (tt - (c.start - tdur / 2)) / tdur;
          const [ra, rb] = transitionRoles(c.trans.type, p);
          drawClip(ctx, prev, Math.min(tt, prev.start + prev.dur - 0.001), W, H, k, ra);
          if (c.trans.type === 'black' || c.trans.type === 'white') { ctx.fillStyle = c.trans.type === 'black' ? '#000' : '#fff'; ctx.globalAlpha = 1 - Math.abs(p - 0.5) * 2; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
          drawClip(ctx, c, Math.max(tt, c.start), W, H, k, rb);
          if (c.trans.type === 'flashT') { ctx.fillStyle = '#fff'; ctx.globalAlpha = Math.max(0, 1 - Math.abs(p - 0.5) * 3); ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
          continue;
        }
        // the previous clip is already drawn by the transition of the next one
        const next = list[i + 1];
        const ntd = next && next.trans && next.trans.type !== 'none' ? Math.min(next.trans.d || 0.6, next.dur) : 0;
        if (ntd && Math.abs(c.start + c.dur - next.start) < 0.05 && tt >= next.start - ntd / 2 && tt < next.start + ntd / 2) continue;
        if (tt >= c.start && tt < c.start + c.dur) drawClip(ctx, c, tt, W, H, k, null);
      }
    }
    ctx.restore();
  };

  // ======================================================================
  // UI
  // ======================================================================
  let root = null, cv = null, raf = 0, t0 = 0, p0 = 0;
  const fmtT = s => { s = Math.max(0, s); const m = Math.floor(s / 60), r = s - m * 60; return String(m).padStart(2, '0') + ':' + r.toFixed(2).padStart(5, '0'); };
  const sel = () => D().clips.find(c => c.id === selected) || null;
  VE.draw = () => {
    if (!cv) return;
    const v = D();
    const ctx = cv.getContext('2d');
    VE.renderAt(ctx, playhead, cv.width, cv.height);
    if (root) {
      const ti = root.querySelector('.ve-time'); if (ti) ti.textContent = fmtT(playhead) + ' / ' + fmtT(VE.duration());
      const ph = root.querySelector('.ve-ph'); if (ph) ph.style.left = (playhead * zoom) + 'px';
      if (colorPage) drawScopes();
    }
    void v;
  };
  const sizeCanvas = () => {
    const v = D();
    const box = root.querySelector('.ve-stage');
    const bw = box.clientWidth - 16, bh = box.clientHeight - 16;
    const k = Math.min(bw / v.w, bh / v.h);
    const q = Math.min(1, 960 / Math.max(v.w, v.h)); // preview resolution
    if (!exporting) { cv.width = Math.round(v.w * q); cv.height = Math.round(v.h * q); }
    cv.style.width = Math.max(10, Math.round(v.w * k)) + 'px'; cv.style.height = Math.max(10, Math.round(v.h * k)) + 'px';
  };
  const loop = () => {
    if (!playing) return;
    playhead = p0 + (performance.now() - t0) / 1000;
    const end = VE.duration();
    if (playhead >= end) {
      if (exporting) { exporting.finish(); return; }
      playhead = end; VE.pause(); VE.draw(); return;
    }
    syncMedia(playhead, true);
    VE.draw();
    raf = requestAnimationFrame(loop);
  };
  VE.play = () => {
    if (playing) return;
    if (playhead >= VE.duration() - 0.02) playhead = 0;
    audio();
    playing = true; t0 = performance.now(); p0 = playhead;
    syncMedia(playhead, true);
    raf = requestAnimationFrame(loop);
    if (root) root.querySelector('[data-ve="play"]').innerHTML = '❚❚';
  };
  VE.pause = () => {
    playing = false; cancelAnimationFrame(raf); stopAll();
    if (root) { const b = root.querySelector('[data-ve="play"]'); if (b) b.innerHTML = '▶'; }
    syncMedia(playhead, false);
  };
  VE.seek = s => { playhead = Math.max(0, Math.min(VE.duration(), s)); if (playing) { t0 = performance.now(); p0 = playhead; } syncMedia(playhead, playing); VE.draw(); };

  // ---------- editing ----------
  VE.split = () => {
    const v = D();
    const c = sel() && sel().start < playhead && sel().start + sel().dur > playhead ? sel() : v.clips.find(x => track(x.track) && track(x.track).main && x.start < playhead && x.start + x.dur > playhead);
    if (!c) return O.toast('Поставте курсор часу всередину кліпу');
    const cut = playhead - c.start;
    const b = Object.assign(O.clone(c), { id: O.uid(), start: playhead, dur: c.dur - cut, in: srcTime(c, playhead), trans: { type: 'none', d: 0.6 } });
    // a speed curve belongs to the whole clip: the halves keep the plain speed
    if (c.curve && c.curve !== 'none') { c.curve = 'none'; b.curve = 'none'; }
    if (c.beats) b.beats = c.beats;
    // keyframes split between the halves
    for (const k of Object.keys(c.kf || {})) { b.kf[k] = c.kf[k].filter(x => x.t >= cut).map(x => ({ t: x.t - cut, v: x.v })); c.kf[k] = c.kf[k].filter(x => x.t <= cut); }
    c.dur = cut; c.anim = Object.assign({}, c.anim, { out: 'none' }); b.anim = Object.assign({}, b.anim, { in: 'none' });
    v.clips.push(b); selected = b.id;
    commit('Розрізати кліп');
  };
  VE.remove = () => { const c = sel(); if (!c) return; D().clips = D().clips.filter(x => x !== c); selected = null; commit('Видалити кліп'); };
  VE.duplicate = () => {
    const c = sel(); if (!c) return;
    const b = Object.assign(O.clone(c), { id: O.uid(), start: c.start + c.dur });
    const v = D();
    if (track(c.track).main && v.magnet) { const list = clipsOn(c.track); const i = list.indexOf(c); list.slice(i + 1).forEach(x => { x.start += c.dur; }); }
    v.clips.push(b); selected = b.id; commit('Дублювати кліп');
  };
  // CapCut-like «freeze frame»: an image of the current frame inserted at the playhead
  VE.freeze = async () => {
    const c = sel();
    if (!c || c.kind !== 'video' || playhead <= c.start || playhead >= c.start + c.dur) return O.toast('Виділіть відеокліп і поставте курсор на потрібний кадр');
    const m = mediaOf(c);
    const tmp = document.createElement('canvas'); tmp.width = m.el.videoWidth; tmp.height = m.el.videoHeight;
    tmp.getContext('2d').drawImage(m.el, 0, 0);
    const a = await io.addAsset(tmp.toDataURL('image/jpeg', 0.92), (c.name || '') + ' — ' + t('стоп-кадр'));
    VE.split();
    const after = sel();
    const f = VE.newClip('image', { track: c.track, asset: a.id, name: t('Стоп-кадр'), start: playhead, dur: 2, fit: c.fit, x: c.x, y: c.y, scale: c.scale, grade: O.clone(c.grade) });
    clipsOn(c.track).filter(x => x.start >= playhead).forEach(x => { if (x !== f) x.start += 2; });
    D().clips.push(f); selected = f.id; void after;
    commit('Стоп-кадр');
  };
  VE.setRatio = r => {
    const v = D(); const R = RATIOS.find(x => x[0] === r); if (!R) return;
    v.ratio = r; v.w = R[1]; v.h = R[2];
    commit('Формат кадру'); if (root) { sizeCanvas(); VE.draw(); }
  };
  // any canvas size (from «New document» or a platform preset)
  VE.setSize = (w, h, name) => {
    const v = D();
    const R = RATIOS.find(x => x[1] === w && x[2] === h);
    v.ratio = R ? R[0] : 'custom'; v.w = Math.max(16, Math.round(w / 2) * 2); v.h = Math.max(16, Math.round(h / 2) * 2);
    if (name) v.name = name;
    return v;
  };

  // ---------- beats (CapCut «Beat»: markers on music, snapping, auto-cut) ----------
  const decoded = new Map();
  const decodeAsset = async id => {
    if (!decoded.has(id)) decoded.set(id, (async () => { const buf = await (await fetch(O.assetURL(id))).arrayBuffer(); const a = audio(); return a.decodeAudioData.length > 1 ? new Promise((res, rej) => a.decodeAudioData(buf, res, rej)) : a.decodeAudioData(buf); })());
    return decoded.get(id);
  };
  // onset detection: energy of 1024-sample windows against the local average
  VE.findBeats = ab => {
    const ch = ab.getChannelData(0), sr = ab.sampleRate, win = 1024;
    const n = Math.floor(ch.length / win), en = new Float32Array(n);
    for (let i = 0; i < n; i++) { let s = 0; for (let j = i * win; j < (i + 1) * win; j += 2) s += ch[j] * ch[j]; en[i] = s; }
    const out = []; let last = -1;
    const minGap = Math.round(0.28 * sr / win);
    for (let i = 1; i < n - 1; i++) {
      let avg = 0, cnt = 0;
      for (let j = Math.max(0, i - 43); j < Math.min(n, i + 43); j++) { avg += en[j]; cnt++; }
      avg /= cnt;
      if (en[i] > avg * 1.45 && en[i] >= en[i - 1] && en[i] >= en[i + 1] && en[i] > 1e-4 && (last < 0 || i - last >= minGap)) { out.push(Math.round(i * win / sr * 1000) / 1000); last = i; }
    }
    return out;
  };
  VE.detectBeats = async () => {
    const c = sel();
    const target = c && (c.kind === 'audio' || c.kind === 'video') ? c : D().clips.find(x => x.kind === 'audio');
    if (!target) return O.toast('Виділіть аудіо- або відеокліп з музикою');
    O.toast('Пошук ритму…');
    try {
      const ab = await decodeAsset(target.asset);
      target.beats = VE.findBeats(ab);
      commit('Біти');
      O.toast('Знайдено бітів: {n}', { n: target.beats.length });
    } catch (e) { console.warn(e); O.toast('Не вдалося проаналізувати аудіо'); }
  };
  // beat times on the timeline
  const beatTimes = () => {
    const out = [];
    for (const c of D().clips) for (const b of c.beats || []) { if (b < c.in) continue; const tl = c.start + (b - c.in) / c.speed; if (tl <= c.start + c.dur) out.push(tl); }
    return out.sort((a, b) => a - b);
  };
  VE.beatTimes = beatTimes;
  // clips of the main track follow the beats (photo slideshows, montages)
  VE.cutToBeat = (every = 1) => {
    const bt = beatTimes();
    if (bt.length < 2) return O.toast('Спершу знайдіть біти в музиці');
    const list = clipsOn(mainTrack().id);
    if (!list.length) return O.toast('Додайте кліпи на головну доріжку');
    let i = bt.findIndex(b => b >= (list[0].start || 0) - 0.01);
    if (i < 0) i = 0;
    let at = bt[i];
    const first = list[0].start; void first;
    for (const c of list) {
      const nb = bt[i + every];
      const d = nb !== undefined ? nb - at : 2;
      const a = c.asset ? S.doc.assets[c.asset] : null;
      const mx = c.kind === 'video' && assetDur(a) ? (assetDur(a) - c.in) / c.speed : Infinity;
      c.start = at; c.dur = Math.max(0.1, Math.min(mx, d));
      at = c.start + c.dur; i += every;
    }
    const m = D().magnet; D().magnet = false; commit('Монтаж під біт'); D().magnet = m;
  };

  // ---------- subtitles (SRT / VTT import & export, captions from a script, live recognition) ----------
  const subTrack = () => D().tracks.find(x => x.kind === 'text' && x.subs) || (() => { const tk = VE.addTrack('text'); tk.name = 'Субтитри'; tk.subs = true; return tk; })();
  const subClip = (text, start, dur) => VE.newClip('text', { track: subTrack().id, name: t('Субтитр'), start, dur: Math.max(0.2, dur), y: D().h * 0.36, text: { content: text, font: 'Inter', size: Math.round(D().h * 0.045 * (D().h > D().w ? 0.8 : 1)), weight: 700, color: '#FFFFFF', stroke: 5, strokeColor: '#000000', bg: '', glow: '', align: 'center', italic: false }, anim: { in: 'none', out: 'none', d: 0.2 } });
  const ts = s => { const v = s.trim().replace(',', '.').split(':').map(Number); return v.length === 3 ? v[0] * 3600 + v[1] * 60 + v[2] : v.length === 2 ? v[0] * 60 + v[1] : v[0]; };
  VE.parseSubs = text => {
    const out = [];
    const blocks = String(text).replace(/\r/g, '').split(/\n{2,}/);
    for (const b of blocks) {
      const lines = b.split('\n').filter(l => l.trim() && l.trim() !== 'WEBVTT');
      const ti = lines.findIndex(l => /-->/.test(l));
      if (ti < 0) continue;
      const [a, z] = lines[ti].split('-->').map(x => x.trim().split(/\s+/)[0]);
      const txt = lines.slice(ti + 1).join('\n').replace(/<[^>]+>/g, '').trim();
      if (txt) out.push({ start: ts(a), end: ts(z), text: txt });
    }
    return out;
  };
  VE.importSubs = async () => {
    const f = (await io.pickFiles('.srt,.vtt,.txt', false))[0];
    if (!f) return;
    const list = VE.parseSubs(await f.text());
    if (!list.length) return O.toast('У файлі немає субтитрів');
    for (const s of list) D().clips.push(subClip(s.text, s.start, s.end - s.start));
    commit('Субтитри');
    O.toast('Додано субтитрів: {n}', { n: list.length });
  };
  const srtTime = s => { const ms = Math.round(s * 1000); const h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, sec = Math.floor(ms / 1000) % 60; return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')},${String(ms % 1000).padStart(3, '0')}`; };
  VE.toSRT = () => {
    const tk = D().tracks.filter(x => x.kind === 'text').map(x => x.id);
    const subs = D().clips.filter(c => c.kind === 'text' && tk.includes(c.track) && c.text && /\S/.test(c.text.content) && !/^\p{Extended_Pictographic}+$/u.test(c.text.content.trim())).sort((a, b) => a.start - b.start);
    return subs.map((c, i) => `${i + 1}\n${srtTime(c.start)} --> ${srtTime(c.start + c.dur)}\n${c.text.content}\n`).join('\n');
  };
  VE.exportSRT = () => { const s = VE.toSRT(); if (!s) return O.toast('Немає текстових кліпів для субтитрів'); O.download(new Blob([s], { type: 'text/plain;charset=utf-8' }), String(S.doc.name || 'video').replace(/[\\/:*?"<>|]+/g, '_') + '.srt'); };
  // the script is split into short phrases spread over the time range in proportion to their length
  VE.captionsFromScript = (text, from, to) => {
    const words = String(text).replace(/\s+/g, ' ').trim().split(' ').filter(Boolean);
    if (!words.length) return 0;
    const phrases = []; let cur = [];
    for (const w of words) { cur.push(w); if (cur.length >= 7 || /[.!?…;:]$/.test(w) || (cur.length >= 4 && /,$/.test(w))) { phrases.push(cur.join(' ')); cur = []; } }
    if (cur.length) phrases.push(cur.join(' '));
    const total = phrases.reduce((s, p) => s + p.length + 4, 0), span = Math.max(0.5, to - from);
    let at = from;
    for (const p of phrases) { const d = span * (p.length + 4) / total; D().clips.push(subClip(p, at, d)); at += d; }
    return phrases.length;
  };
  VE.scriptDialog = () => {
    const end = VE.duration() || 10;
    ui.dialog({
      title: 'Субтитри з тексту',
      body: `<div class="dlg-text">${esc(t('Вставте текст озвучки: його буде поділено на короткі фрази й рівномірно розставлено по часу. Потім підправте межі на монтажній стрічці.'))}</div><textarea class="ve-script" rows="8" style="width:100%"></textarea>`,
      fields: [{ key: 'from', label: 'Від, с', type: 'number', value: 0 }, { key: 'to', label: 'До, с', type: 'number', value: O.fmt(end, 2) }],
      onOk: v => { const txt = O.$('.ve-script') ? O.$('.ve-script').value : ''; const n = VE.captionsFromScript(txt, +v.from || 0, +v.to || end); if (n) { commit('Субтитри'); O.toast('Додано субтитрів: {n}', { n }); } }
    });
  };
  // live speech recognition (Chrome / Edge): plays the timeline and turns what the microphone hears into captions
  let recog = null;
  VE.autoCaptions = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return O.toast('Автосубтитри потребують Chrome або Edge (розпізнавання мовлення)');
    if (recog) { recog.stop(); return; }
    recog = new SR();
    recog.lang = { uk: 'uk-UA', en: 'en-US', ru: 'ru-RU', de: 'de-DE' }[O.lang] || navigator.language || 'en-US';
    recog.continuous = true; recog.interimResults = false;
    let from = playhead;
    recog.onresult = e => {
      for (let i = e.resultIndex; i < e.results.length; i++) if (e.results[i].isFinal) {
        const txt = e.results[i][0].transcript.trim();
        if (txt) { const now = playhead; VE.captionsFromScript(txt, from, Math.max(from + 0.6, now)); from = now; commit('Автосубтитри'); }
      }
    };
    recog.onend = () => { recog = null; VE.pause(); O.toast('Автосубтитри зупинено'); VE.refresh(); };
    recog.onerror = e => O.toast('Розпізнавання: {msg}', { msg: e.error });
    recog.start();
    VE.play();
    O.toast('Слухаю… Звук відео має бути чутно в мікрофон. Натисніть ще раз, щоб зупинити.');
  };
  // keyframe toggle (◆) for a property at the playhead
  VE.toggleKey = (prop) => {
    const c = sel(); if (!c) return;
    const lt = Math.round(Math.max(0, Math.min(c.dur, playhead - c.start)) * 1000) / 1000;
    c.kf = c.kf || {}; const k = c.kf[prop] = c.kf[prop] || [];
    const i = k.findIndex(x => Math.abs(x.t - lt) < 1 / (D().fps || 30));
    if (i >= 0) k.splice(i, 1); else { k.push({ t: lt, v: VE.val(c, prop, lt) }); k.sort((a, b) => a.t - b.t); }
    if (!k.length) delete c.kf[prop];
    commit('Ключовий кадр');
  };
  const setProp = (c, prop, val) => {
    const lt = Math.max(0, Math.min(c.dur, playhead - c.start));
    if (KF_PROPS.includes(prop) && c.kf && c.kf[prop] && c.kf[prop].length) {
      const k = c.kf[prop];
      const i = k.findIndex(x => Math.abs(x.t - lt) < 1 / (D().fps || 30));
      if (i >= 0) k[i].v = val; else { k.push({ t: lt, v: val }); k.sort((a, b) => a.t - b.t); }
    } else c[prop] = val;
  };

  // ---------- timeline ----------
  const TL = {};
  TL.render = () => {
    if (!root) return;
    const v = D();
    const body = root.querySelector('.ve-tl-lanes');
    const heads = root.querySelector('.ve-tl-heads');
    const end = Math.max(VE.duration() + 10, 30);
    const W = end * zoom;
    const order = v.tracks.filter(x => x.kind !== 'audio').concat(v.tracks.filter(x => x.kind === 'audio'));
    heads.innerHTML = '<div class="ve-ruler-h"></div>' + order.map(tk => `<div class="ve-th${tk.main ? ' main' : ''}" data-tk="${tk.id}"><span>${esc(t(tk.name))}</span><button type="button" class="ve-ib" data-tka="mute" title="${esc(t(tk.kind === 'audio' || tk.main ? 'Без звуку' : 'Сховати'))}">${tk.mute || tk.hidden ? '⊘' : (tk.kind === 'audio' ? '🔊' : '👁')}</button></div>`).join('');
    let ruler = '';
    const step = zoom > 120 ? 1 : zoom > 40 ? 2 : zoom > 15 ? 5 : 10;
    for (let s = 0; s <= end; s += step) ruler += `<span class="ve-tick" style="left:${s * zoom}px">${fmtT(s).replace(/\.\d+$/, '')}</span>`;
    for (const b of beatTimes()) ruler += `<i class="ve-beat" style="left:${b * zoom}px"></i>`;
    body.innerHTML = `<div class="ve-ruler" style="width:${W}px">${ruler}</div>` + order.map(tk => `<div class="ve-lane${tk.main ? ' main' : ''}" data-lane="${tk.id}" style="width:${W}px">${clipsOn(tk.id).map(c => {
      const a = c.asset ? S.doc.assets[c.asset] : null;
      const thumb = c.kind === 'video' && a && a.thumb ? `background-image:url(${a.thumb});` : c.kind === 'image' && a ? `background-image:url(${O.assetURL(c.asset)});` : '';
      const kfs = Object.values(c.kf || {}).flat().map(k => `<i class="ve-kf" style="left:${k.t * zoom}px"></i>`).join('');
      const label = c.kind === 'text' ? (c.text && c.text.content) : c.name;
      return `<div class="ve-clip k-${c.kind}${c.id === selected ? ' sel' : ''}" data-clip="${c.id}" style="left:${c.start * zoom}px;width:${Math.max(4, c.dur * zoom)}px;${thumb}"><span class="ve-cn">${esc(label || '')}${c.speed !== 1 ? ` · ${O.fmt(c.speed, 2)}×` : ''}${c.curve && c.curve !== 'none' ? ' · ⤳' : ''}${c.mask && c.mask.type !== 'none' ? ' · ◐' : ''}${c.chroma && c.chroma.on ? ' · 🟩' : ''}${c.grade && GR.active(c.grade) ? ' · 🎨' : ''}</span>${c.trans && c.trans.type !== 'none' ? `<i class="ve-tr" title="${esc(t('Перехід'))}">⋈</i>` : ''}${kfs}<b class="ve-h l" data-edge="l"></b><b class="ve-h r" data-edge="r"></b></div>`;
    }).join('')}</div>`).join('') + `<div class="ve-ph" style="left:${playhead * zoom}px"></div>`;
    // audio waveforms are drawn lazily
    body.querySelectorAll('.ve-clip.k-audio').forEach(el => wave(el, D().clips.find(c => c.id === el.dataset.clip)));
  };
  const waves = new Map();
  const wave = async (el, c) => {
    if (!c || !c.asset) return;
    let pk = waves.get(c.asset);
    if (!pk) {
      waves.set(c.asset, 'busy');
      try { const buf = await (await fetch(O.assetURL(c.asset))).arrayBuffer(); const ab = await audio().decodeAudioData(buf); const ch = ab.getChannelData(0); const n = 600, st = Math.floor(ch.length / n) || 1; pk = { peaks: Array.from({ length: n }, (_, i) => { let m = 0; for (let j = i * st; j < (i + 1) * st && j < ch.length; j += 32) m = Math.max(m, Math.abs(ch[j])); return m; }), dur: ab.duration }; waves.set(c.asset, pk); TL.render(); } catch (e) { waves.set(c.asset, null); }
      return;
    }
    if (pk === 'busy' || !pk) return;
    const w = el.clientWidth, h = el.clientHeight;
    const cnv = document.createElement('canvas'); cnv.width = Math.max(1, w); cnv.height = h; cnv.className = 've-wave';
    const g = cnv.getContext('2d'); g.fillStyle = 'rgba(255,255,255,.55)';
    for (let x = 0; x < w; x++) { const st = c.in + (x / zoom) * c.speed; const i = Math.floor(st / pk.dur * pk.peaks.length); const p = pk.peaks[i] || 0; g.fillRect(x, h / 2 - p * h * 0.45, 1, Math.max(1, p * h * 0.9)); }
    el.prepend(cnv);
  };
  const snapPoints = (exceptId) => { const pts = [0, playhead].concat(beatTimes()); for (const c of D().clips) if (c.id !== exceptId) pts.push(c.start, c.start + c.dur); return pts; };
  const snap = (x, exceptId) => { if (!D().snapOff) for (const p of snapPoints(exceptId)) if (Math.abs(p - x) * zoom < 8) return p; return x; };
  TL.bind = () => {
    const lanes = root.querySelector('.ve-tl-lanes');
    lanes.addEventListener('pointerdown', e => {
      const r = lanes.getBoundingClientRect();
      const timeAt = ev => (ev.clientX - r.left + lanes.scrollLeft) / zoom;
      const clipEl = e.target.closest('[data-clip]');
      if (e.target.closest('.ve-ruler') || !clipEl) {
        if (!clipEl && !e.target.closest('.ve-ruler')) { selected = null; VE.refresh(); }
        const mv = ev => VE.seek(timeAt(ev));
        mv(e);
        lanes.setPointerCapture(e.pointerId);
        const up = () => { lanes.removeEventListener('pointermove', mv); lanes.removeEventListener('pointerup', up); };
        lanes.addEventListener('pointermove', mv); lanes.addEventListener('pointerup', up);
        return;
      }
      const c = D().clips.find(x => x.id === clipEl.dataset.clip);
      if (!c) return;
      selected = c.id;
      const edge = e.target.dataset.edge;
      const x0 = timeAt(e), s0 = c.start, d0 = c.dur, in0 = c.in;
      const a = c.asset ? S.doc.assets[c.asset] : null;
      const maxSrc = (c.kind === 'video' || c.kind === 'audio') ? assetDur(a) : Infinity;
      let moved = false;
      lanes.setPointerCapture(e.pointerId);
      const mv = ev => {
        const dt = timeAt(ev) - x0;
        if (Math.abs(dt) * zoom > 2) moved = true;
        if (!moved) return;
        if (edge === 'l') {
          let ns = snap(s0 + dt, c.id);
          ns = Math.min(s0 + d0 - 0.1, Math.max(ns, s0 - in0 / c.speed, 0));
          c.in = in0 + (ns - s0) * c.speed; c.dur = d0 - (ns - s0); c.start = ns;
        } else if (edge === 'r') {
          let ne = snap(s0 + d0 + dt, c.id);
          ne = Math.max(s0 + 0.1, Math.min(ne, maxSrc === Infinity ? Infinity : s0 + (maxSrc - in0) / c.speed));
          c.dur = ne - s0;
        } else {
          c.start = Math.max(0, snap(s0 + dt, c.id));
          if (Math.abs(snap(s0 + dt + d0, c.id) - (s0 + dt + d0)) > 0 && snap(s0 + dt + d0, c.id) !== s0 + dt + d0) c.start = Math.max(0, snap(s0 + dt + d0, c.id) - d0);
          // move between tracks of the same family
          const lane = document.elementFromPoint(ev.clientX, ev.clientY);
          const ln = lane && lane.closest && lane.closest('[data-lane]');
          if (ln) { const tk = track(ln.dataset.lane); if (tk && (tk.kind === 'audio') === (c.kind === 'audio')) c.track = tk.id; }
        }
        TL.render(); VE.draw();
      };
      const up = () => { lanes.removeEventListener('pointermove', mv); lanes.removeEventListener('pointerup', up); if (moved) { if (!edge && track(c.track).main && D().magnet) { /* re-order main track by drop position */ } commit(edge ? 'Обрізати кліп' : 'Перемістити кліп'); } else VE.refresh(); };
      lanes.addEventListener('pointermove', mv); lanes.addEventListener('pointerup', up);
    });
    root.querySelector('.ve-tl-heads').addEventListener('click', e => {
      const b = e.target.closest('[data-tka]'); if (!b) return;
      const tk = track(b.closest('[data-tk]').dataset.tk);
      if (tk.kind === 'audio' || tk.main) tk.mute = !tk.mute; else tk.hidden = !tk.hidden;
      commit('Доріжка');
    });
    // drag from the media bin onto a lane
    lanes.addEventListener('dragover', e => { if (e.dataTransfer.types.includes('text/obrys-asset') || e.dataTransfer.types.includes('text/obrys-frame')) e.preventDefault(); });
    lanes.addEventListener('drop', e => {
      const id = e.dataTransfer.getData('text/obrys-asset'), fid = e.dataTransfer.getData('text/obrys-frame');
      if (!id && !fid) return;
      e.preventDefault();
      const r = lanes.getBoundingClientRect();
      const at = Math.max(0, (e.clientX - r.left + lanes.scrollLeft) / zoom);
      const ln = e.target.closest('[data-lane]');
      const tk = ln ? track(ln.dataset.lane) : null;
      const c = fid ? VE.addFrame(fid) : VE.addAsset(id, { track: tk ? tk.id : undefined, at });
      if (c && tk && !tk.main) { c.track = tk.id; c.start = at; }
      commit('Додати кліп');
    });
  };

  // ---------- media bin ----------
  const BIN_TABS = [['media', 'Медіа'], ['audio', 'Аудіо'], ['text', 'Текст'], ['stickers', 'Стікери'], ['trans', 'Переходи'], ['fx', 'Ефекти'], ['filters', 'Фільтри'], ['design', 'Дизайн']];
  let binTab = 'media';
  const renderBin = () => {
    const el = root.querySelector('.ve-bin');
    const assets = Object.entries(S.doc.assets || {});
    const tabs = Object.entries(VE.BIN_EXTRA).map(([k, x]) => [k, x.label]).concat(BIN_TABS);
    let h = `<div class="ve-tabs">${tabs.map(([k, l]) => `<button type="button" data-bin="${k}" class="${binTab === k ? 'on' : ''}">${esc(t(l))}</button>`).join('')}</div><div class="ve-bin-b">`;
    if (binTab === 'media' || binTab === 'audio') {
      h += `<button type="button" class="btn primary ve-imp" data-ve="import">${esc(t(binTab === 'audio' ? 'Імпорт аудіо…' : 'Імпорт відео й фото…'))}</button>`;
      if (binTab === 'audio') h += `<button type="button" class="btn" data-ve="studio">🎹 ${esc(t('Музична студія'))}</button><div class="ve-sec">${esc(t('Біт'))}</div><div class="ve-row"><button type="button" class="btn" data-ve="beats">♫ ${esc(t('Знайти біти'))}</button><button type="button" class="btn" data-ve="cutbeat">${esc(t('Монтаж під біт'))}</button><button type="button" class="btn" data-ve="cutbeat2">${esc(t('Кожен 2-й біт'))}</button></div>`;
      const list = assets.filter(([, a]) => (binTab === 'audio' ? kindOfAsset(a) === 'audio' : ['video', 'image'].includes(kindOfAsset(a))));
      h += `<div class="ve-grid">${list.map(([id, a]) => { const k = kindOfAsset(a); const th = k === 'image' ? O.assetURL(id) : a.thumb || ''; return `<div class="ve-item" draggable="true" data-asset="${id}" title="${esc(a.name || '')}">${th ? `<img src="${th}" alt="">` : `<span class="ve-ico">${k === 'audio' ? '♪' : '▶'}</span>`}<em>${esc(a.name || '')}${a.duration ? ' · ' + fmtT(a.duration).replace(/^00:/, '') : ''}</em><button type="button" class="ve-add" data-add="${id}" title="${esc(t('Додати на монтажну стрічку'))}">+</button></div>`; }).join('') || `<div class="ve-empty">${esc(t('Перетягніть файли сюди або натисніть «Імпорт»'))}</div>`}</div>`;
    }
    if (binTab === 'text') h += `<div class="ve-sec">${esc(t('Субтитри'))}</div><div class="ve-row"><button type="button" class="btn" data-ve="autocap">🎙 ${esc(t('Автосубтитри'))}</button><button type="button" class="btn" data-ve="script">${esc(t('З тексту…'))}</button><button type="button" class="btn" data-ve="subsin">${esc(t('Імпорт SRT / VTT…'))}</button><button type="button" class="btn" data-ve="subsout">${esc(t('Експорт SRT'))}</button></div><div class="ve-sec">${esc(t('Стилі тексту'))}</div><div class="ve-list">${TEXT_PRESETS.map(([n, p], i) => `<button type="button" class="ve-tp" data-text="${i}" style="font-weight:${p.weight};${p.bg ? `background:${p.bg};color:#111;` : ''}${p.glow ? `text-shadow:0 0 8px ${p.glow};` : ''}${p.stroke && p.color.startsWith('rgba(0') ? '-webkit-text-stroke:1px #fff;color:transparent;' : ''}${p.font ? `font-family:'${p.font}';` : ''}">${esc(t(n))}</button>`).join('')}</div>`;
    if (binTab === 'stickers') h += `<div class="ve-note">${esc(t('Клік додає стікер у позицію курсора часу.'))}</div><div class="ve-stk">${STICKERS.map(s => `<button type="button" data-sticker="${s}">${s}</button>`).join('')}</div>`;
    if (binTab === 'trans') h += `<div class="ve-note">${esc(t('Виділіть кліп: перехід застосовується на його початку (від попереднього кліпу).'))}</div><div class="ve-list">${TRANS.map(([k, l]) => `<button type="button" data-trans="${k}">${esc(t(l))}</button>`).join('')}</div>`;
    if (VE.BIN_EXTRA[binTab]) h += VE.BIN_EXTRA[binTab].render(sel());
    if (binTab === 'fx') {
      // grouped by category; the first 18 are the basic set
      const cats = new Map();
      EFFECTS.forEach(([k, l]) => { const c = (VE.FX.get(k) || {}).cat || 'Базові'; if (!cats.has(c)) cats.set(c, []); cats.get(c).push([k, l]); });
      h += `<div class="ve-note">${esc(t('Клік вмикає або вимикає ефект на виділеному кліпі. Ефектів: {n}', { n: EFFECTS.length }))}</div>` + Array.from(cats).map(([c, list]) => `<div class="ve-sec">${esc(t(c))}</div><div class="ve-list">${list.map(([k, l]) => `<button type="button" data-fx="${k}" class="${sel() && (sel().fx || []).includes(k) ? 'on' : ''}">${esc(t(l))}</button>`).join('')}</div>`).join('');
    }
    if (binTab === 'filters') h += `<div class="ve-note">${esc(t('Фільтр — це готова кольорокорекція. Доналаштуйте її на сторінці «Колір».'))}</div><div class="ve-list">${GR.PRESETS.map(([l], i) => `<button type="button" data-filter="${i}">${esc(t(l))}</button>`).join('')}</div>`;
    if (binTab === 'design') {
      const fr = []; for (const pg of S.doc.pages) for (const n of pg.children) if (n.type === 'frame' && n.visible !== false && !n.print) fr.push(n);
      h += `<div class="ve-note">${esc(t('Фрейми з полотна стають кадрами відео (титри, заставки, слайди).'))}</div><div class="ve-list">${fr.map(f => `<button type="button" draggable="true" data-frame="${f.id}">▭ ${esc(f.name)}</button>`).join('') || `<div class="ve-empty">${esc(t('У документі немає фреймів'))}</div>`}</div>`;
    }
    h += '</div>';
    el.innerHTML = h;
  };

  // ---------- inspector ----------
  const fld = (prop, label, val, opt = {}) => `<label class="ve-f"><span>${esc(t(label))}</span><input type="${opt.type || 'number'}" step="${opt.step || 'any'}" ${opt.min !== undefined ? `min="${opt.min}"` : ''} ${opt.max !== undefined ? `max="${opt.max}"` : ''} data-p="${prop}" value="${esc(val)}">${KF_PROPS.includes(prop) ? `<button type="button" class="ve-kfb${sel() && sel().kf && sel().kf[prop] && sel().kf[prop].length ? ' on' : ''}" data-kf="${prop}" title="${esc(t('Ключовий кадр у позиції курсора'))}">◆</button>` : ''}</label>`;
  const selF = (prop, label, val, opts) => `<label class="ve-f"><span>${esc(t(label))}</span><select data-p="${prop}">${opts.map(([v, l]) => `<option value="${v}"${String(v) === String(val) ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select></label>`;
  const renderInspector = () => {
    const el = root.querySelector('.ve-insp');
    const c = sel();
    const v = D();
    if (!c) {
      el.innerHTML = `<h4>${esc(t('Проєкт'))}</h4>${selF('ratio', 'Формат кадру', v.ratio, RATIOS.map(r => [r[0], r[0] + ` (${r[1]}×${r[2]})`]).concat(v.ratio === 'custom' ? [['custom', t('Свій розмір') + ` (${v.w}×${v.h})`]] : []))}<label class="ve-f"><span>${esc(t('Платформа'))}</span><select data-ve="platform"><option value="">—</option>${VE.PLATFORMS.map(([n, w, h], i) => `<option value="${i}">${esc(t(n))} · ${w}×${h}</option>`).join('')}</select></label>${selF('fps', 'Кадрів за секунду', v.fps, [[24, '24'], [25, '25'], [30, '30'], [60, '60']])}${selF('bgMode', 'Тло', v.bgMode, [['color', 'Колір'], ['blur', 'Розмите відео']])}<label class="ve-f"><span>${esc(t('Колір тла'))}</span><input type="color" data-p="bg" value="${v.bg}"></label><label class="ve-chk"><input type="checkbox" data-p="magnet"${v.magnet ? ' checked' : ''}> ${esc(t('Магніт головної доріжки'))}</label><div class="ve-note">${esc(t('Виділіть кліп на монтажній стрічці, щоб змінити його.'))}</div>`;
      return;
    }
    const lt = Math.max(0, Math.min(c.dur, playhead - c.start));
    const vv = p => O.fmt(VE.val(c, p, lt), 3);
    let h = `<h4>${esc(c.kind === 'text' ? t('Текст') : c.name || '')}</h4>`;
    if (c.kind === 'text') {
      const T = c.text;
      h += `<label class="ve-f col"><span>${esc(t('Текст'))}</span><textarea data-tp="content" rows="3">${esc(T.content)}</textarea></label>
        <label class="ve-f"><span>${esc(t('Шрифт'))}</span><input type="text" data-tp="font" value="${esc(T.font)}" list="ve-fonts"></label>
        <datalist id="ve-fonts">${(O.fonts ? O.fonts.google.slice(0, 300).map(g => g.family) : ['Inter']).map(f => `<option value="${esc(f)}">`).join('')}</datalist>
        <label class="ve-f"><span>${esc(t('Розмір'))}</span><input type="number" data-tp="size" value="${T.size}"></label>
        <label class="ve-f"><span>${esc(t('Насиченість шрифту'))}</span><input type="number" step="100" min="100" max="900" data-tp="weight" value="${T.weight}"></label>
        <label class="ve-f"><span>${esc(t('Колір'))}</span><input type="color" data-tp="color" value="${/^#/.test(T.color) ? T.color : '#ffffff'}"></label>
        <label class="ve-f"><span>${esc(t('Обведення'))}</span><input type="number" min="0" data-tp="stroke" value="${T.stroke || 0}"><input type="color" data-tp="strokeColor" value="${T.strokeColor || '#000000'}"></label>
        <label class="ve-f"><span>${esc(t('Тло тексту'))}</span><input type="color" data-tp="bg" value="${T.bg || '#000000'}"><button type="button" class="ve-ib" data-tpclear="bg">✕</button></label>
        <label class="ve-f"><span>${esc(t('Світіння'))}</span><input type="color" data-tp="glow" value="${T.glow || '#ff3dcb'}"><button type="button" class="ve-ib" data-tpclear="glow">✕</button></label>`;
    }
    h += `<div class="ve-sec">${esc(t('Час'))}</div>${fld('start', 'Початок, с', O.fmt(c.start, 3), { min: 0 })}${fld('dur', 'Тривалість, с', O.fmt(c.dur, 3), { min: 0.1 })}`;
    if (c.kind === 'video' || c.kind === 'audio') {
      h += fld('speed', 'Швидкість', c.speed, { min: 0.1, max: 16, step: 0.05 }) + selF('curve', 'Крива швидкості', c.curve || 'none', CURVES) + `<label class="ve-chk"><input type="checkbox" data-p="pitchShift"${c.pitchShift ? ' checked' : ''}> ${esc(t('Змінювати тон разом зі швидкістю'))}</label>`;
      h += `<div class="ve-sec">${esc(t('Звук'))}</div>` + fld('volume', 'Гучність', vv('volume'), { min: 0, max: 4, step: 0.05 }) + fld('fadeIn', 'Наростання звуку, с', c.fadeIn, { min: 0 }) + fld('fadeOut', 'Затухання звуку, с', c.fadeOut, { min: 0 }) + selF('voice', 'Зміна голосу', c.voice || 'none', VOICES) + `<label class="ve-chk"><input type="checkbox" data-p="denoise"${c.denoise ? ' checked' : ''}> ${esc(t('Зменшити шум'))}</label><label class="ve-chk"><input type="checkbox" data-p="enhance"${c.enhance ? ' checked' : ''}> ${esc(t('Покращити голос'))}</label>`;
      if (c.kind === 'video') h += `<div class="ve-row"><button type="button" class="btn" data-ve="extract">${esc(t('Відокремити аудіо'))}</button></div>`;
      if (c.beats && c.beats.length) h += `<div class="ve-note">♫ ${esc(t('Бітів: {n}', { n: c.beats.length }))}</div>`;
    }
    if (c.kind !== 'audio') {
      h += `<div class="ve-sec">${esc(t('Кадр'))}</div>${fld('x', 'X', vv('x'))}${fld('y', 'Y', vv('y'))}${fld('scale', 'Масштаб', vv('scale'), { step: 0.01, min: 0.01 })}${fld('rot', 'Поворот', vv('rot'))}${fld('opacity', 'Непрозорість', vv('opacity'), { step: 0.05, min: 0, max: 1 })}`;
      if (c.kind !== 'text' && c.kind !== 'color') h += selF('fit', 'Вписування', c.fit, [['contain', 'Вписати'], ['cover', 'Заповнити'], ['fill', 'Розтягнути']]) + `<div class="ve-sec">${esc(t('Кадрування'))}</div>` + ['l', 't', 'r', 'b'].map(k => `<label class="ve-f"><span>${esc(t({ l: 'Ліворуч', t: 'Згори', r: 'Праворуч', b: 'Знизу' }[k]))}</span><input type="range" min="0" max="45" data-crop="${k}" value="${Math.round((c.crop[k] || 0) * 100)}"></label>`).join('');
      h += `<div class="ve-sec">${esc(t('Накладання'))}</div>${selF('blend', 'Режим накладання', c.blend || 'normal', BLENDS)}`;
      const mk = c.mask || { type: 'none' };
      h += `<div class="ve-sec">${esc(t('Маска'))}</div>${selF('mask.type', 'Форма', mk.type, MASKS)}` + (mk.type !== 'none' ? `${fld('mask.x', 'X', mk.x || 0)}${fld('mask.y', 'Y', mk.y || 0)}${mk.type !== 'linear' ? fld('mask.w', 'Ширина', mk.w || 600, { min: 1 }) : ''}${mk.type !== 'linear' && mk.type !== 'mirror' ? fld('mask.h', 'Висота', mk.h || 600, { min: 1 }) : mk.type === 'mirror' ? fld('mask.h', 'Висота смуги', mk.h || 600, { min: 1 }) : ''}${fld('mask.rot', 'Поворот', mk.rot || 0)}${fld('mask.feather', 'Розтушовка', mk.feather || 0, { min: 0 })}<label class="ve-chk"><input type="checkbox" data-p="mask.invert"${mk.invert ? ' checked' : ''}> ${esc(t('Інвертувати маску'))}</label>` : '');
      if (c.kind !== 'text' && c.kind !== 'color') {
        const ck = c.chroma || { on: false, color: '#00FF00', sim: 0.4, smooth: 0.08, spill: 0.1 };
        h += `<div class="ve-sec">${esc(t('Хромакей (видалити фон за кольором)'))}</div><label class="ve-chk"><input type="checkbox" data-p="chroma.on"${ck.on ? ' checked' : ''}> ${esc(t('Увімкнути хромакей'))}</label>` + (ck.on ? `<label class="ve-f"><span>${esc(t('Колір фону'))}</span><input type="color" data-p="chroma.color" value="${O.color && O.color.norm ? O.color.norm(ck.color) || '#00FF00' : ck.color}"><button type="button" class="btn" data-ve="pickkey" title="${esc(t('Взяти колір з кутка кадру'))}">⌖</button></label>${fld('chroma.sim', 'Сила', ck.sim, { min: 0, max: 1, step: 0.01 })}${fld('chroma.smooth', 'М’якість країв', ck.smooth, { min: 0, max: 0.5, step: 0.01 })}${fld('chroma.spill', 'Прибрати відблиск', ck.spill, { min: 0, max: 0.5, step: 0.01 })}` : '');
      }
      h += `<div class="ve-sec">${esc(t('Анімація'))}</div>${selF('anim.in', 'Поява', c.anim.in, ANIMS_IN)}${selF('anim.out', 'Зникнення', c.anim.out, ANIMS_OUT)}${fld('anim.d', 'Тривалість анімації, с', c.anim.d, { min: 0.05, step: 0.05 })}`;
      h += `<div class="ve-sec">${esc(t('Перехід на початку'))}</div>${selF('trans.type', 'Тип', c.trans.type, TRANS)}${fld('trans.d', 'Тривалість переходу, с', c.trans.d, { min: 0.1, step: 0.1 })}`;
      if (c.kind !== 'text') h += `<div class="ve-row"><button type="button" class="btn primary" data-ve="color">🎨 ${esc(t('Колір (як у DaVinci)'))}</button></div>`;
    }
    h += `<div class="ve-row"><button type="button" class="btn" data-ve="split">✂ ${esc(t('Розрізати'))}</button><button type="button" class="btn" data-ve="dup">${esc(t('Дублювати'))}</button>${c.kind === 'video' ? `<button type="button" class="btn" data-ve="freeze">${esc(t('Стоп-кадр'))}</button>` : ''}<button type="button" class="btn" data-ve="del">${esc(t('Видалити'))}</button></div>`;
    el.innerHTML = h;
  };

  // ---------- Color page ----------
  let gNode = 0, scopeKind = 'parade', clipboard = null;
  const gradeOf = c => { if (!c.grade) c.grade = GR.newGrade(); if (!c.grade.nodes.length) c.grade.nodes.push(GR.newNode(t('Вузол {n}', { n: 1 }))); gNode = Math.min(gNode, c.grade.nodes.length - 1); return c.grade; };
  const drawScopes = () => { const sc = root && root.querySelector('.ve-scope'); if (sc && cv) GR.scope(cv, sc, scopeKind); };
  const renderColor = () => {
    const el = root.querySelector('.ve-color');
    const c = sel();
    if (!c || c.kind === 'audio' || c.kind === 'text') { el.innerHTML = `<div class="ve-note">${esc(t('Виділіть відео, фото або кадр дизайну на монтажній стрічці.'))}</div>`; return; }
    if (!GR.supported()) { el.innerHTML = `<div class="ve-note">${esc(t('Браузер не підтримує WebGL2 — кольорокорекція недоступна.'))}</div>`; return; }
    const g = gradeOf(c), n = g.nodes[gNode];
    el.innerHTML = `<div class="gc-top"><div class="gc-nodes">${g.nodes.map((x, i) => `<button type="button" class="gc-node${i === gNode ? ' on' : ''}${x.on ? '' : ' off'}" data-node="${i}"><b>${String(i + 1).padStart(2, '0')}</b>${esc(x.name)}</button>`).join('')}<button type="button" class="gc-node add" data-ga="add" title="${esc(t('Новий послідовний вузол'))}">+</button></div>
        <div class="gc-tools"><label class="ve-chk"><input type="checkbox" data-ga="on"${n.on ? ' checked' : ''}> ${esc(t('Вузол увімкнено'))}</label><select data-ga="preset"><option value="">${esc(t('Пресет…'))}</option>${GR.PRESETS.map(([l], i) => `<option value="${i}">${esc(t(l))}</option>`).join('')}</select>
        <button type="button" class="btn" data-ga="lut">${esc(t(n.lut ? 'Інший LUT…' : 'Завантажити LUT (.cube)…'))}</button>${n.lut ? `<button type="button" class="btn" data-ga="unlut">${esc(t('Прибрати LUT'))}</button>` : ''}
        <button type="button" class="btn" data-ga="copy">${esc(t('Копіювати грейд'))}</button><button type="button" class="btn" data-ga="paste"${clipboard ? '' : ' disabled'}>${esc(t('Вставити грейд'))}</button><button type="button" class="btn" data-ga="all"${clipboard ? '' : ' disabled'}>${esc(t('На всі кліпи'))}</button>
        <button type="button" class="btn" data-ga="reset">${esc(t('Скинути вузол'))}</button>${g.nodes.length > 1 ? `<button type="button" class="btn" data-ga="delnode">${esc(t('Видалити вузол'))}</button>` : ''}<label class="ve-chk"><input type="checkbox" data-ga="bypass"${bypass ? ' checked' : ''}> ${esc(t('До / після (вимкнути грейд)'))}</label></div></div>
      <div class="gc-main"><div class="gc-wheels"></div><div class="gc-prim">${[['temp', 'Температура', -1, 1, 0.01], ['tint', 'Відтінок', -1, 1, 0.01], ['exposure', 'Експозиція', -2, 2, 0.01], ['contrast', 'Контраст', 0, 2, 0.01], ['pivot', 'Півот', 0, 1, 0.005], ['shadows', 'Тіні', -1, 1, 0.01], ['highlights', 'Світла', -1, 1, 0.01], ['sat', 'Насиченість', 0, 2, 0.01], ['hue', 'Тон', -180, 180, 1], ['mix', 'Мікс вузла', 0, 1, 0.01]].map(([k, l, mn, mx, st]) => `<label class="gc-s"><span>${esc(t(l))}</span><input type="range" min="${mn}" max="${mx}" step="${st}" data-gp="${k}" value="${n[k]}"><em>${O.fmt(n[k], 2)}</em></label>`).join('')}</div><div class="gc-curves"></div>
      <div class="gc-scopes"><select data-ga="scope">${[['parade', 'RGB Parade'], ['waveform', 'Waveform'], ['vector', 'Vectorscope'], ['histogram', 'Гістограма']].map(([k, l]) => `<option value="${k}"${k === scopeKind ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select><canvas class="ve-scope" width="300" height="170"></canvas></div></div>`;
    const live = () => { VE.draw(); };
    const end = () => commit('Кольорокорекція');
    const wh = el.querySelector('.gc-wheels');
    for (const [k, l] of [['lift', 'Lift (тіні)'], ['gamma', 'Gamma (середні)'], ['gain', 'Gain (світла)'], ['offset', 'Offset']]) wh.appendChild(GR.wheelWidget(l, n[k], live, end));
    el.querySelector('.gc-curves').appendChild(GR.curveWidget(n, live, end));
    drawScopes();
  };
  const colorEvents = () => {
    const el = root.querySelector('.ve-color');
    el.addEventListener('input', e => { const k = e.target.dataset.gp; if (!k) return; const c = sel(); if (!c) return; const n = gradeOf(c).nodes[gNode]; n[k] = +e.target.value; e.target.nextElementSibling.textContent = O.fmt(n[k], 2); VE.draw(); });
    el.addEventListener('change', async e => {
      const c = sel(); if (!c) return; const g = gradeOf(c), n = g.nodes[gNode];
      const a = e.target.dataset.ga;
      if (e.target.dataset.gp) return commit('Кольорокорекція');
      if (a === 'on') { n.on = e.target.checked; commit('Вузол'); }
      if (a === 'preset' && e.target.value !== '') { GR.applyPreset(n, +e.target.value); commit('Пресет кольору'); }
      if (a === 'scope') { scopeKind = e.target.value; drawScopes(); }
      if (a === 'bypass') { bypass = e.target.checked; VE.draw(); }
    });
    el.addEventListener('dblclick', e => { const k = e.target.dataset && e.target.dataset.gp; if (!k) return; const c = sel(); const n = gradeOf(c).nodes[gNode]; n[k] = GR.newNode()[k]; commit('Кольорокорекція'); });
    el.addEventListener('click', async e => {
      const b = e.target.closest('[data-node],[data-ga]'); if (!b || b.tagName === 'SELECT' || b.tagName === 'INPUT') return;
      const c = sel(); if (!c) return; const g = gradeOf(c);
      if (b.dataset.node !== undefined) { gNode = +b.dataset.node; VE.refresh(); return; }
      const a = b.dataset.ga;
      if (a === 'add') { g.nodes.push(GR.newNode(t('Вузол {n}', { n: g.nodes.length + 1 }))); gNode = g.nodes.length - 1; commit('Новий вузол'); }
      if (a === 'delnode') { g.nodes.splice(gNode, 1); gNode = Math.max(0, gNode - 1); commit('Видалити вузол'); }
      if (a === 'reset') { const name = g.nodes[gNode].name; g.nodes[gNode] = GR.newNode(name); commit('Скинути вузол'); }
      if (a === 'copy') { clipboard = O.clone(g); O.toast('Грейд скопійовано'); VE.refresh(); }
      if (a === 'paste' && clipboard) { c.grade = O.clone(clipboard); commit('Вставити грейд'); }
      if (a === 'all' && clipboard) { for (const x of D().clips) if (['video', 'image', 'frame'].includes(x.kind)) x.grade = O.clone(clipboard); commit('Грейд на всі кліпи'); }
      if (a === 'unlut') { g.nodes[gNode].lut = null; commit('LUT'); }
      if (a === 'lut') {
        const f = (await io.pickFiles('.cube', false))[0];
        if (!f) return;
        const text = await f.text();
        try { GR.parseCube(text); } catch (err) { return O.toast(err.message); }
        const id = O.uid();
        S.doc.assets[id] = { data: 'data:text/plain;base64,' + btoa(unescape(encodeURIComponent(text))), name: f.name, kind: 'lut' };
        g.nodes[gNode].lut = id;
        commit('LUT');
      }
    });
  };

  // ---------- export ----------
  VE.exportDialog = () => {
    const v = D();
    if (!v.clips.length) return O.toast('Додайте кліпи на монтажну стрічку');
    const types = ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm'];
    const mime = window.MediaRecorder ? types.find(x => MediaRecorder.isTypeSupported(x)) : null;
    if (!mime) return O.toast('Цей браузер не вміє записувати відео. Скористайтеся Chrome, Edge або Firefox.');
    const short = Math.min(v.w, v.h);
    ui.dialog({
      title: 'Експорт відео',
      body: `<div class="dlg-text">${esc(t('Відео записується в реальному часі ({d}). Не перемикайте вкладку до кінця запису.', { d: fmtT(VE.duration()) }))}</div>`,
      fields: [{ key: 'res', label: 'Роздільна здатність', type: 'select', value: String(Math.min(2160, short >= 1080 ? 1080 : short)), options: [['480', '480p'], ['720', '720p'], ['1080', '1080p'], ['1440', '2K (1440p)'], ['2160', '4K (2160p)']] }, { key: 'fps', label: 'Кадрів за секунду', type: 'select', value: String(v.fps), options: [['24', '24'], ['25', '25'], ['30', '30'], ['50', '50'], ['60', '60']] }, { key: 'q', label: 'Якість', type: 'select', value: 'high', options: [['normal', 'Звичайна'], ['high', 'Висока'], ['max', 'Максимальна']] }, { key: 'fmt', label: 'Формат', type: 'select', value: 'video', options: [['video', mime.startsWith('video/mp4') ? 'MP4 (H.264 + AAC)' : 'WebM (VP9 + Opus)'], ['webm', 'WebM'], ['audio', 'Лише аудіо'], ['srt', 'Субтитри SRT'], ['png', 'Поточний кадр PNG']] }],
      buttons: [{ id: 'ok', label: 'Експортувати', primary: true }],
      onOk: o => {
        if (o.fmt === 'srt') return VE.exportSRT();
        if (o.fmt === 'png') return VE.snapshot(+o.res);
        const m = o.fmt === 'webm' ? (['video/webm;codecs=vp9,opus', 'video/webm'].find(x => MediaRecorder.isTypeSupported(x)) || mime) : mime;
        VE.export({ res: +o.res, fps: +o.fps, q: o.q, mime: m, audio: o.fmt === 'audio' }).catch(e => { console.error(e); O.toast('Помилка експорту: {msg}', { msg: e.message }); });
      }
    });
  };
  // the frame under the playhead as PNG
  VE.snapshot = (res) => {
    const v = D();
    const k = (res || Math.min(v.w, v.h)) / Math.min(v.w, v.h);
    const c2 = document.createElement('canvas'); c2.width = Math.round(v.w * k); c2.height = Math.round(v.h * k);
    VE.renderAt(c2.getContext('2d'), playhead, c2.width, c2.height);
    c2.toBlob(b => { if (b) O.download(b, String(S.doc.name || 'frame').replace(/[\\/:*?"<>|]+/g, '_') + ' ' + fmtT(playhead).replace(/[:.]/g, '-') + '.png'); }, 'image/png');
  };
  VE.export = opts => new Promise((resolve, reject) => {
    const v = D();
    const short = Math.min(v.w, v.h), k = opts.res / short;
    const W = Math.round(v.w * k / 2) * 2, H = Math.round(v.h * k / 2) * 2;
    VE.pause();
    const prevW = cv.width, prevH = cv.height;
    cv.width = W; cv.height = H;
    audio();
    let stream, recOpts;
    if (opts.audio) {
      stream = new MediaStream(recDest.stream.getAudioTracks());
      const am = ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/mp4', 'audio/webm'].find(x => MediaRecorder.isTypeSupported(x));
      opts.mime = am || 'audio/webm';
      recOpts = { mimeType: opts.mime, audioBitsPerSecond: 192000 };
    } else {
      stream = cv.captureStream(opts.fps);
      recDest.stream.getAudioTracks().forEach(tk => stream.addTrack(tk));
      const bits = { normal: 0.08, high: 0.15, max: 0.3 }[opts.q] || 0.15;
      recOpts = { mimeType: opts.mime, videoBitsPerSecond: Math.round(W * H * opts.fps * bits), audioBitsPerSecond: 192000 };
    }
    const rec = new MediaRecorder(stream, recOpts);
    const chunks = [];
    rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    const ov = O.h(`<div class="ve-exp"><div><b>${esc(t('Експорт відео'))}</b><progress max="1" value="0"></progress><span></span><button type="button" class="btn">${esc(t('Зупинити'))}</button></div></div>`);
    root.appendChild(ov);
    const pr = ov.querySelector('progress'), lab = ov.querySelector('span');
    const tick = setInterval(() => { pr.value = playhead / Math.max(0.01, VE.duration()); lab.textContent = fmtT(playhead) + ' / ' + fmtT(VE.duration()); }, 200);
    let stopped = false;
    const finish = () => {
      if (stopped) return; stopped = true;
      clearInterval(tick);
      playing = false; cancelAnimationFrame(raf); stopAll();
      rec.onstop = () => {
        exporting = null; ov.remove();
        cv.width = prevW; cv.height = prevH; VE.draw();
        const type = opts.mime.split(';')[0];
        const blob = new Blob(chunks, { type });
        O.download(blob, String(S.doc.name || 'video').replace(/[\\/:*?"<>|]+/g, '_') + ({ 'video/mp4': '.mp4', 'audio/mp4': '.m4a', 'audio/ogg': '.ogg', 'audio/webm': '.weba' }[type] || '.webm'));
        O.toast('Відео збережено ({mb} МБ)', { mb: (blob.size / 1048576).toFixed(1) });
        resolve(blob);
      };
      try { rec.stop(); } catch (e) { reject(e); }
    };
    ov.querySelector('button').onclick = finish;
    exporting = { finish };
    playhead = 0;
    rec.start(250);
    // give media elements a moment to seek to the start
    syncMedia(0, false);
    setTimeout(() => VE.play(), 300);
  });

  // ---------- shell ----------
  VE.refresh = () => {
    if (!root) return;
    renderBin(); TL.render();
    root.classList.toggle('color', colorPage);
    root.querySelector('[data-ve="colorpage"]').classList.toggle('on', colorPage);
    if (colorPage) renderColor(); else renderInspector();
    const rs = root.querySelector('[data-ve="ratio"]');
    if (rs) { const cu = rs.querySelector('[value="custom"]'); if (D().ratio === 'custom') { if (!cu) rs.appendChild(new Option(t('Свій розмір'), 'custom')); rs.lastChild.textContent = `${t('Свій розмір')} ${D().w}×${D().h}`; } else if (cu) cu.remove(); rs.value = D().ratio; }
    sizeCanvas(); VE.draw();
  };
  VE.open = () => {
    if (root) return;
    D();
    root = O.h(`<div class="ve-root" role="dialog" aria-label="${esc(t('Відеоредактор'))}">
      <div class="ve-top">${O.modeSwitch ? O.modeSwitch('video') : `<b class="ve-logo">🎬 ${esc(t('Відеоредактор'))}</b>`}<select data-ve="ratio" title="${esc(t('Формат кадру'))}">${RATIOS.map(r => `<option value="${r[0]}">${r[0]}</option>`).join('')}</select>
        <button type="button" class="btn" data-ve="undo" title="Ctrl+Z">↶</button><button type="button" class="btn" data-ve="redo" title="Ctrl+Shift+Z">↷</button>
        <span class="sp"></span><button type="button" class="btn" data-ve="colorpage">🎨 ${esc(t('Колір'))}</button><button type="button" class="btn primary" data-ve="export">${esc(t('Експорт'))}</button><button type="button" class="btn" data-ve="close" title="Esc">✕</button></div>
      <div class="ve-mid"><div class="ve-bin"></div><div class="ve-view"><div class="ve-stage"><canvas class="ve-cv"></canvas></div><div class="ve-ctl"><button type="button" class="ve-ib" data-ve="start" title="Home">⏮</button><button type="button" class="ve-ib" data-ve="play" title="${esc(t('Пробіл'))}">▶</button><span class="ve-time"></span><span class="sp"></span><button type="button" class="ve-ib" data-ve="full" title="${esc(t('На весь екран'))}">⛶</button></div></div><div class="ve-insp"></div><div class="ve-color"></div></div>
      <div class="ve-tl"><div class="ve-tl-bar"><button type="button" class="ve-ib" data-ve="split" title="${esc(t('Розрізати (Ctrl+B)'))}">✂</button><button type="button" class="ve-ib" data-ve="del" title="Delete">🗑</button><button type="button" class="ve-ib" data-ve="dup" title="Ctrl+D">⧉</button><button type="button" class="ve-ib" data-ve="freeze" title="${esc(t('Стоп-кадр'))}">❄</button><button type="button" class="ve-ib" data-ve="addtext" title="${esc(t('Додати текст'))}">T</button><button type="button" class="ve-ib" data-ve="addtrack" title="${esc(t('Додати доріжку'))}">⊕</button><button type="button" class="ve-ib" data-ve="beats" title="${esc(t('Знайти біти'))}">♫</button><button type="button" class="ve-ib" data-ve="snapshot" title="${esc(t('Зберегти кадр як PNG'))}">📷</button><span class="sp"></span><label class="ve-chk"><input type="checkbox" data-ve="snap"> ${esc(t('Прилипання'))}</label><span>🔍</span><input type="range" min="10" max="300" value="${zoom}" data-ve="zoom" aria-label="${esc(t('Масштаб монтажної стрічки'))}"></div>
        <div class="ve-tl-body"><div class="ve-tl-heads"></div><div class="ve-tl-lanes"></div></div></div></div>`);
    document.body.appendChild(root);
    cv = root.querySelector('.ve-cv');
    root.querySelector('[data-ve="snap"]').checked = !D().snapOff;
    root.addEventListener('click', e => {
      const b = e.target.closest('[data-ve],[data-bin],[data-add],[data-text],[data-trans],[data-fx],[data-filter],[data-frame],[data-kf],[data-tpclear],[data-sticker]');
      if (!b || b.tagName === 'SELECT') return;
      const c = sel();
      if (b.dataset.sticker) { VE.addSticker(b.dataset.sticker); commit('Стікер'); return; }
      if (b.dataset.bin) { binTab = b.dataset.bin; renderBin(); return; }
      if (b.dataset.add) { VE.addAsset(b.dataset.add); commit('Додати кліп'); return; }
      if (b.dataset.text) { VE.addText(+b.dataset.text); commit('Додати текст'); return; }
      if (b.dataset.frame && e.detail >= 1) { VE.addFrame(b.dataset.frame); commit('Додати кадр дизайну'); return; }
      if (b.dataset.trans) { if (!c) return O.toast('Виділіть кліп'); c.trans = { type: b.dataset.trans, d: c.trans.d || 0.6 }; commit('Перехід'); return; }
      if (b.dataset.fx) { if (!c) return O.toast('Виділіть кліп'); c.fx = c.fx || []; const i = c.fx.indexOf(b.dataset.fx); if (i >= 0) c.fx.splice(i, 1); else c.fx.push(b.dataset.fx); commit('Ефект'); return; }
      if (b.dataset.filter !== undefined) { if (!c || c.kind === 'audio' || c.kind === 'text') return O.toast('Виділіть відео або фото'); const g = gradeOf(c); GR.applyPreset(g.nodes[0], +b.dataset.filter); commit('Фільтр'); return; }
      if (b.dataset.kf) { VE.toggleKey(b.dataset.kf); return; }
      if (b.dataset.tpclear) { if (c && c.text) { c.text[b.dataset.tpclear] = ''; commit('Текст'); } return; }
      const a = b.dataset.ve;
      if (a === 'close') VE.close();
      if (a === 'play') playing ? VE.pause() : VE.play();
      if (a === 'start') VE.seek(0);
      if (a === 'split') VE.split();
      if (a === 'del') VE.remove();
      if (a === 'dup') VE.duplicate();
      if (a === 'freeze') VE.freeze();
      if (a === 'addtext') { VE.addText(0); commit('Додати текст'); }
      if (a === 'undo') { O.history.undo(); VE.refresh(); }
      if (a === 'redo') { O.history.redo(); VE.refresh(); }
      if (a === 'export') VE.exportDialog();
      if (a === 'colorpage') { colorPage = !colorPage; VE.refresh(); }
      if (a === 'color') { colorPage = true; VE.refresh(); }
      if (a === 'full') { const st = root.querySelector('.ve-stage'); if (st.requestFullscreen) st.requestFullscreen().catch(() => {}); }
      if (a === 'studio' && O.studio) { if (O.setMode) O.setMode('music'); else O.studio.open(); }
      if (a === 'beats') VE.detectBeats();
      if (a === 'cutbeat') VE.cutToBeat(1);
      if (a === 'cutbeat2') VE.cutToBeat(2);
      if (a === 'autocap') VE.autoCaptions();
      if (a === 'script') VE.scriptDialog();
      if (a === 'subsin') VE.importSubs();
      if (a === 'subsout') VE.exportSRT();
      if (a === 'extract') VE.extractAudio();
      if (a === 'snapshot') VE.snapshot();
      if (a === 'addtrack') { const r = b.getBoundingClientRect(); ui.menu([{ id: 'overlay', label: t('Доріжка накладання'), raw: true }, { id: 'text', label: t('Текстова доріжка'), raw: true }, { id: 'audio', label: t('Аудіодоріжка'), raw: true }], r.left, r.bottom + 4, { onPick: k => { VE.addTrack(k); commit('Доріжка'); } }); }
      if (a === 'pickkey' && c) {
        // the colour of the top-left corner of the source is usually the backdrop
        const s = sourceOf(c);
        if (s && s.w) { const tmp = document.createElement('canvas'); tmp.width = tmp.height = 4; const g = tmp.getContext('2d'); g.drawImage(s.el, 0, 0, Math.max(1, s.w * 0.03), Math.max(1, s.h * 0.03), 0, 0, 4, 4); const d = g.getImageData(1, 1, 1, 1).data; c.chroma = Object.assign({}, c.chroma, { color: '#' + [d[0], d[1], d[2]].map(x => x.toString(16).padStart(2, '0')).join('').toUpperCase() }); commit('Хромакей'); }
      }
      if (a === 'import') io.pickFiles(binTab === 'audio' ? 'audio/*,' + io.EXTRA_MEDIA : 'video/*,image/*,' + io.EXTRA_MEDIA, true).then(async fs => { if (!fs.length) return; O.toast('Імпорт…'); await VE.importFiles(fs); commit('Імпорт медіа'); });
    });
    root.addEventListener('change', e => {
      const el = e.target, c = sel(), v = D();
      if (el.dataset.ve === 'ratio') return VE.setRatio(el.value);
      if (el.dataset.ve === 'platform' && el.value !== '') { const [n, w, h] = VE.PLATFORMS[+el.value]; VE.setSize(w, h); commit('Формат кадру'); O.toast('Формат: {name}', { name: t(n) }); return; }
      if (el.dataset.ve === 'snap') { v.snapOff = !el.checked; return; }
      if (el.dataset.crop && c) { c.crop[el.dataset.crop] = +el.value / 100; return commit('Кадрування'); }
      if (el.dataset.tp && c && c.text) { c.text[el.dataset.tp] = el.type === 'number' ? +el.value : el.value; if (el.dataset.tp === 'font' && O.fonts) O.fonts.load(el.value).then(() => VE.draw()); return commit('Текст'); }
      const p = el.dataset.p;
      if (!p) return;
      if (!c) { if (p === 'ratio') return VE.setRatio(el.value); v[p] = el.type === 'checkbox' ? el.checked : p === 'fps' ? +el.value : el.value; return commit('Проєкт'); }
      const val = el.type === 'checkbox' ? el.checked : el.type === 'number' || el.type === 'range' ? parseFloat(el.value) : el.value;
      if (p.includes('.')) {
        const [a, b] = p.split('.');
        if (a === 'chroma' && !c.chroma) c.chroma = { on: false, color: '#00FF00', sim: 0.4, smooth: 0.08, spill: 0.1 };
        if (a === 'mask' && !c.mask) c.mask = { type: 'none', x: 0, y: 0, w: Math.round(Math.min(v.w, v.h) * 0.6), h: Math.round(Math.min(v.w, v.h) * 0.6), rot: 0, feather: 0, invert: false };
        c[a] = Object.assign({}, c[a], { [b]: typeof val === 'number' && !isFinite(val) ? c[a][b] : val });
      }
      else if (p === 'speed') { const s = Math.min(16, Math.max(0.1, val || 1)); c.dur = c.dur * c.speed / s; c.speed = s; }
      else if (p === 'dur') { const a = c.asset ? S.doc.assets[c.asset] : null; const mx = (c.kind === 'video' || c.kind === 'audio') && assetDur(a) ? (assetDur(a) - c.in) / c.speed : Infinity; c.dur = Math.max(0.1, Math.min(mx, val)); }
      else if (KF_PROPS.includes(p)) setProp(c, p, val);
      else c[p] = val;
      commit('Властивість кліпу');
    });
    root.addEventListener('input', e => { if (e.target.dataset.ve === 'zoom') { zoom = +e.target.value; TL.render(); } if (e.target.dataset.tp === 'content') { const c = sel(); if (c) { c.text.content = e.target.value; VE.draw(); } } });
    root.addEventListener('dragstart', e => { const it = e.target.closest('[data-asset],[data-frame]'); if (!it) return; if (it.dataset.asset) e.dataTransfer.setData('text/obrys-asset', it.dataset.asset); else e.dataTransfer.setData('text/obrys-frame', it.dataset.frame); });
    // files dropped into the editor go to the media bin
    root.addEventListener('dragover', e => { if (Array.from(e.dataTransfer.types).includes('Files')) { e.preventDefault(); e.stopPropagation(); } }, true);
    root.addEventListener('drop', async e => { const fs = Array.from(e.dataTransfer.files || []); if (!fs.length) return; e.preventDefault(); e.stopPropagation(); O.toast('Імпорт…'); const ids = await VE.importFiles(fs); ids.forEach(id => VE.addAsset(id)); commit('Імпорт медіа'); }, true);
    colorEvents();
    TL.bind();
    document.addEventListener('keydown', keys, true);
    window.addEventListener('resize', onResize);
    VE.refresh();
  };
  const onResize = () => { if (root) { sizeCanvas(); VE.draw(); } };
  const keys = e => {
    if (!root || root.querySelector('.ve-exp')) return;
    if (O.$('.dlg-back')) return;
    const tg = e.target;
    const typing = tg && (tg.tagName === 'TEXTAREA' || (tg.tagName === 'INPUT' && !['range', 'checkbox', 'color'].includes(tg.type)));
    if (typing) { if (e.key === 'Escape') tg.blur(); e.stopPropagation(); return; }
    const k = e.key, ctrl = e.ctrlKey || e.metaKey;
    let done = true;
    if (k === ' ') playing ? VE.pause() : VE.play();
    else if (ctrl && (e.code === 'KeyB')) VE.split();
    else if (!ctrl && e.code === 'KeyS') VE.split();
    else if (k === 'Delete' || k === 'Backspace') VE.remove();
    else if (ctrl && e.code === 'KeyD') VE.duplicate();
    else if (ctrl && e.code === 'KeyZ') { if (e.shiftKey) O.history.redo(); else O.history.undo(); VE.refresh(); }
    else if (k === 'ArrowLeft') VE.seek(playhead - (e.shiftKey ? 1 : 1 / D().fps));
    else if (k === 'ArrowRight') VE.seek(playhead + (e.shiftKey ? 1 : 1 / D().fps));
    else if (k === 'Home') VE.seek(0);
    else if (k === 'End') VE.seek(VE.duration());
    else if (k === 'Escape') { if (colorPage) { colorPage = false; VE.refresh(); } else VE.close(); }
    else if (k === '=' || k === '+') { zoom = Math.min(300, zoom * 1.25); TL.render(); }
    else if (k === '-') { zoom = Math.max(10, zoom / 1.25); TL.render(); }
    else done = false;
    if (done) e.preventDefault();
    e.stopPropagation();
  };
  VE.close = () => {
    if (!root) return;
    VE.pause();
    document.removeEventListener('keydown', keys, true);
    window.removeEventListener('resize', onResize);
    root.remove(); root = null; cv = null;
  };
  VE.isOpen = () => !!root;
  // for templates and backgrounds (vfx.js)
  VE.commit = commit;
  VE.TEXT_PRESETS = TEXT_PRESETS;
  VE.resize = () => { if (root) { sizeCanvas(); VE.draw(); } };
  VE.playheadAt = () => playhead;
  VE.showBin = tab => { binTab = tab; if (root) renderBin(); };
  VE.state = () => ({ playhead, selected, playing, colorPage });
  VE.select = id => { selected = id; VE.refresh(); };
  O.on('change', () => { if (root && !playing) { VE.refresh(); } });

  O.cmd('videoEditor', 'Відеоредактор (як CapCut)…', () => VE.open(), { keys: ['Ctrl+Alt+Shift+V'], group: 'Медіа' });
  // CapCut / social formats in «New document» and in the frame tool presets
  if (O.print && O.print.PS && !O.print.PS.some(c => c[0] === 'Відео CapCut')) O.print.PS.splice(O.print.PS.findIndex(c => c[0] === 'Фільм і відео') + 1 || O.print.PS.length, 0, ['Відео CapCut', VE.PLATFORMS.map(([n, w, h]) => [n, w, h, 'px', 72])]);
  if (O.FRAME_PRESETS && !O.FRAME_PRESETS.some(c => c[0] === 'Відео CapCut')) O.FRAME_PRESETS.push(['Відео CapCut', VE.PLATFORMS.map(([n, w, h]) => [n, w, h])]);
})();
