'use strict';
/* VIBSma — Spotlight (Ctrl+K, Ctrl+/ or the search button): one search box for everything —
   commands and tools, layers on every page, pages, projects, design templates (100 styles), Google Fonts,
   colours (HEX → fill of the selection), a calculator and unit converter, and «Design with Claude»:
   a description becomes an editable design (the Claude API writes an SVG, VIBSma imports it as layers).
   Looks like Claude's own design language: warm ivory paper, clay accent, serif prompt line. */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui, V = O.view;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const SP = O.spotlight = { open: false };

  // ---------- search helpers ----------
  const norm = s => String(s || '').toLowerCase().replace(/[’'`ʼ]/g, '').replace(/ё/g, 'е');
  // score: 0 = no match; whole-prefix > word-prefix > substring > letters in order
  const score = (text, q) => {
    if (!q) return 1;
    const s = norm(text);
    if (!s) return 0;
    if (s.startsWith(q)) return 100 - Math.min(40, s.length - q.length);
    const i = s.indexOf(q);
    if (i > 0 && /[\s/«(—-]/.test(s[i - 1])) return 70;
    if (i >= 0) return 50;
    let j = 0;
    for (const c of s) if (c === q[j]) j++;
    return j === q.length && q.length > 2 ? 20 : 0;
  };
  const recent = () => O.ls.get('spotRecent', []);
  const remember = key => O.ls.set('spotRecent', [key].concat(recent().filter(k => k !== key)).slice(0, 8));

  // ---------- calculator & units ----------
  const UNITS = { px: 1, pt: 96 / 72, mm: 96 / 25.4, cm: 96 / 2.54, in: 96, pc: 16 };
  const calc = q => {
    const s = q.replace(/,/g, '.').replace(/×/g, '*').replace(/÷/g, '/').trim();
    const u = /^(-?\d*\.?\d+)\s*(px|pt|mm|cm|in|pc)\s*(?:(?:в|у|to|in|→|=)\s*(px|pt|mm|cm|in|pc))?$/i.exec(s);
    if (u) {
      const v = parseFloat(u[1]), from = u[2].toLowerCase(), px = v * UNITS[from];
      const to = u[3] ? [u[3].toLowerCase()] : ['px', 'mm', 'pt'].filter(x => x !== from);
      return to.map(k => O.fmt(px / UNITS[k], 3) + ' ' + k).join(' · ');
    }
    if (!/^[\d+\-*/().%\s^]+$/.test(s) || !/[\d)]\s*[+\-*/%^]\s*[\d(]/.test(s)) return null;
    try {
      const v = Function('"use strict";return (' + s.replace(/\^/g, '**') + ')')();
      return isFinite(v) ? String(Math.round(v * 1e6) / 1e6) : null;
    } catch (e) { return null; }
  };

  // ---------- sources ----------
  const ICON_FOR = { frame: 'frame', group: 'group', text: 'text', rect: 'rect', ellipse: 'ellipse', path: 'path', polygon: 'polygon', star: 'star', instance: 'instance', bool: 'union' };
  const sources = {
    cmd: q => {
      const out = [];
      for (const c of O.cmds.values()) {
        if (!c.label || c.hidden) continue;
        const label = O.cmdLabel(c);
        const sc = Math.max(score(label, q), score(c.label, q) * 0.9, c.group ? score(t(c.group), q) * 0.4 : 0, q && c.id.toLowerCase().includes(q) ? 30 : 0);
        if (!sc) continue;
        const dis = c.enabled && !c.enabled();
        out.push({ key: 'cmd:' + c.id, kind: 'cmd', sc: sc - (dis ? 15 : 0), label, sub: c.group ? t(c.group) : '', keys: (c.keys || [])[0] || '', dis, icon: c.id.startsWith('tool:') ? (O.ui.TOOLS[c.id.slice(5)] || {}).icon || 'pen' : 'command', run: () => O.run(c.id) });
      }
      return out;
    },
    layer: q => {
      if (!q || !S.doc) return [];
      const out = [];
      for (const pg of S.doc.pages) {
        model.walk(pg.children, n => {
          if (out.length > 400) return false;
          const sc = score(n.name, q) || (n.type === 'text' && score(O.text.content(n), q) * 0.6);
          if (sc) out.push({ key: 'layer:' + n.id, kind: 'layer', sc: sc * 0.95, label: n.name, sub: pg.name + (n.type === 'text' ? ' · «' + O.text.content(n).slice(0, 40) + '»' : ''), icon: ICON_FOR[n.type] || 'rect', node: n, run: () => SP.goLayer(pg, n) });
        });
      }
      return out;
    },
    page: q => (S.doc ? S.doc.pages : []).map(pg => ({ pg, sc: score(pg.name, q) })).filter(x => x.sc && q).map(({ pg, sc }) => ({ key: 'page:' + pg.id, kind: 'page', sc: sc * 0.9, label: pg.name, sub: t('Сторінка · шарів: {n}', { n: pg.children.length }), icon: 'page', run: () => { S.pageId = pg.id; S.sel = []; model.reindex(); O.emit('page'); O.emit('change'); setTimeout(() => V.fit(null, 80, 1), 0); } })),
    project: q => (SP.projects || []).map(p => ({ p, sc: score(p.name, q) })).filter(x => x.sc && q).map(({ p, sc }) => ({ key: 'project:' + p.id, kind: 'project', sc: sc * 0.85, label: p.name || t('Без назви'), sub: t('Проєкт'), icon: 'grid', thumb: p.thumb, run: () => O.projects.open(p.id) })),
    template: q => (O.gallery ? O.gallery.search(q, 40) : []).map(st => ({ key: 'tpl:' + st.k, kind: 'template', sc: (q ? st.sc : 1) * 0.8, label: t(st.n), sub: t(st.gname) + ' · ' + t('шаблон'), icon: 'star', style: st, run: () => O.gallery.open({ style: st.k }) })),
    font: q => {
      if (!q || q.length < 2 || !O.fonts || !O.fonts.google) return [];
      const out = [];
      for (const g of O.fonts.google) { const sc = score(g.family, q); if (sc > 40) out.push({ key: 'font:' + g.family, kind: 'font', sc: sc * 0.7, label: g.family, sub: t('Шрифт Google Fonts'), icon: 'text', family: g.family, run: () => { O.fonts.load(g.family); O.fonts.apply(g.family); } }); if (out.length > 30) break; }
      return out;
    }
  };
  // instant answers on top: colour, calculator
  const answers = raw => {
    const out = [];
    const c = O.color.field(raw);
    if (c && /^#?[0-9a-fфисвуа]{3,8}$/i.test(raw.trim())) {
      const nodes = O.topSel();
      out.push({ key: 'color', kind: 'color', sc: 1000, label: c.hex, sub: nodes.length ? t('Застосувати як заливку виділеного') : t('Додати в кольори документа'), icon: 'drop', color: c.hex, run: () => {
        if (nodes.length) { nodes.forEach(n => { n.fills = (n.fills && n.fills.length ? n.fills : [O.paint.solid(c.hex)]); const p = n.fills.find(f => f.type === 'solid') || n.fills[0]; if (p.type !== 'solid') n.fills[0] = O.paint.solid(c.hex); else { p.color = c.hex; delete p.sw; } }); O.history.commit('Колір'); }
        else { S.doc.swatches.push({ id: O.uid(), name: c.hex, color: c.hex }); O.history.commit('Зразок кольору'); O.toast('Колір {c} додано в «Ресурси»', { c: c.hex }); }
      } });
    }
    const r = calc(raw);
    if (r !== null) out.push({ key: 'calc', kind: 'calc', sc: 999, label: '= ' + r, sub: t('Калькулятор — Enter копіює результат'), icon: 'hash', run: () => { O.copyText(r.split(' ')[0]); O.toast('Скопійовано: {v}', { v: r }); } });
    return out;
  };
  const claudeItem = raw => ({ key: 'claude', kind: 'claude', sc: -1, label: raw ? t('Створити дизайн з Claude: «{q}»', { q: raw.slice(0, 60) }) : t('Створити дизайн з Claude…'), sub: t('Опишіть, що потрібно — Claude намалює редагований макет'), icon: 'sparkle', run: () => SP.claudeDialog({ prompt: raw }) });

  SP.goLayer = (pg, n) => {
    if (S.pageId !== pg.id) { S.pageId = pg.id; model.reindex(); O.emit('page'); }
    O.select([n.id]);
    O.emit('change');
    setTimeout(() => { const b = model.worldBounds(n); if (b) V.fit(b, 120, 2); }, 0);
  };

  const CATS = [['all', 'Усе'], ['cmd', 'Команди'], ['layer', 'Шари'], ['template', 'Шаблони'], ['project', 'Проєкти'], ['font', 'Шрифти']];
  const GROUP_TITLE = { answer: 'Відповідь', recent: 'Нещодавні', cmd: 'Команди та інструменти', layer: 'Шари', page: 'Сторінки', template: 'Шаблони дизайну', project: 'Проєкти', font: 'Шрифти', claude: 'Claude' };
  const SUGGEST = ['new', 'tool:frame', 'tool:rect', 'tool:text', 'tool:pen', 'pinTemplates', 'timeline', 'exportHub'];

  SP.show = (opts = {}) => {
    if (O.$('.pal-back')) return;
    SP.open = true;
    const wrap = O.h(`<div class="pal-back spot-back"><div class="spot" role="dialog" aria-label="${esc(t('Пошук'))}">
      <div class="spot-in"><span class="spot-mark">${O.icon('sparkle', 20)}</span><input id="pal-q" placeholder="${esc(t('Шукайте що завгодно або опишіть дизайн для Claude…'))}" autocomplete="off" spellcheck="false" aria-label="${esc(t('Пошук'))}"><kbd class="spot-esc">Esc</kbd></div>
      <div class="spot-cats" role="tablist">${CATS.map(([k, l]) => `<button type="button" data-cat="${k}" role="tab">${esc(t(l))}</button>`).join('')}</div>
      <div class="spot-main"><div class="spot-list pal-list" role="listbox"></div><aside class="spot-prev" aria-live="polite"></aside></div>
      <div class="spot-foot"><span>${esc(t('↑↓ вибір · Enter відкрити · Tab розділ'))}</span><span class="sp"></span><span>${esc(t('Також: колір #FF6600, 12*8, 25 mm'))}</span></div></div></div>`);
    document.body.appendChild(wrap);
    const inp = wrap.querySelector('input'), box = wrap.querySelector('.spot-list'), prev = wrap.querySelector('.spot-prev');
    let cat = opts.cat || 'all', items = [], idx = 0;
    if (O.projects && !O.projects.disabled) O.projects.list().then(l => { SP.projects = l; if (inp.value.trim()) render(); }).catch(() => {});
    const collect = () => {
      const raw = inp.value.trim(), q = norm(raw);
      let list = [];
      if (!q) {
        const rec = recent().map(k => k.startsWith('cmd:') ? O.cmds.get(k.slice(4)) : null).filter(Boolean);
        const sug = SUGGEST.map(id => O.cmds.get(id)).filter(c => c && !rec.includes(c));
        const asItem = (c, grp) => ({ key: 'cmd:' + c.id, kind: 'cmd', grp, label: O.cmdLabel(c), sub: c.group ? t(c.group) : '', keys: (c.keys || [])[0] || '', icon: 'command', run: () => O.run(c.id) });
        if (cat === 'all' || cat === 'cmd') list = rec.map(c => asItem(c, 'recent')).concat(sug.map(c => asItem(c, 'cmd')));
        if (cat === 'all' || cat === 'template') list = list.concat(sources.template('').slice(0, cat === 'template' ? 40 : 6).map(x => Object.assign(x, { grp: 'template' })));
        if (cat === 'project') list = (SP.projects || []).slice(0, 30).map(p => ({ key: 'project:' + p.id, kind: 'project', grp: 'project', label: p.name || t('Без назви'), sub: t('Проєкт'), icon: 'grid', thumb: p.thumb, run: () => O.projects.open(p.id) }));
        if (cat === 'layer' && S.doc) { const l = []; model.walk(model.page().children, n => { if (l.length < 60) l.push({ key: 'layer:' + n.id, kind: 'layer', grp: 'layer', label: n.name, sub: model.page().name, icon: ICON_FOR[n.type] || 'rect', node: n, run: () => SP.goLayer(model.page(), n) }); }); list = l; }
        if (cat === 'all') list.push(Object.assign(claudeItem(''), { grp: 'claude' }));
        return list;
      }
      const ans = cat === 'all' ? answers(raw).map(a => Object.assign(a, { grp: 'answer' })) : [];
      const kinds = cat === 'all' ? ['cmd', 'layer', 'page', 'template', 'project', 'font'] : cat === 'layer' ? ['layer', 'page'] : [cat];
      const caps = { cmd: 12, layer: 10, page: 4, template: 8, project: 6, font: 6 };
      for (const k of kinds) {
        const r = sources[k](q).sort((a, b) => b.sc - a.sc).slice(0, cat === 'all' ? caps[k] : 60);
        list = list.concat(r.map(x => Object.assign(x, { grp: k })));
      }
      // groups ordered by their best hit
      const best = {};
      list.forEach(x => { best[x.grp] = Math.max(best[x.grp] || 0, x.sc); });
      list.sort((a, b) => (best[b.grp] - best[a.grp]) || (b.sc - a.sc));
      list = ans.concat(list);
      if (cat === 'all') list.push(Object.assign(claudeItem(raw), { grp: 'claude' }));
      return list;
    };
    const itemHTML = (it, i) => `<div class="spot-it${i === idx ? ' on' : ''}${it.dis ? ' dis' : ''}" data-i="${i}" role="option" aria-selected="${i === idx}">
        <span class="spot-ic${it.kind === 'claude' ? ' claude' : ''}"${it.color ? ` style="background:${it.color}"` : ''}>${it.color ? '' : it.style && O.gallery ? O.gallery.miniSwatch(it.style) : O.icon(it.icon || 'command', 16)}</span>
        <span class="spot-t"><b>${esc(it.label)}</b>${it.sub ? `<em>${esc(it.sub)}</em>` : ''}</span>${it.keys ? `<kbd>${esc(O.keyLabel(it.keys))}</kbd>` : ''}</div>`;
    const preview = () => {
      const it = items[idx];
      if (!it) { prev.innerHTML = ''; return; }
      let h = '';
      if (it.kind === 'template' && O.gallery) h = `<div class="spot-pv-img">${O.gallery.thumbSVG(it.style, 'post', 220)}</div><h4>${esc(t(it.style.n))}</h4><p>${esc(t(it.style.d))}</p><div class="spot-pal">${it.style.pal.map(c => `<i style="background:${c}"></i>`).join('')}</div><p class="spot-meta">${esc(it.style.f[0])} · ${esc(it.style.f[1])}</p>`;
      else if (it.kind === 'layer' && it.node) { let img = ''; try { img = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(O.render.svg([it.node], {}).svg); } catch (e) { /* ignore */ } h = `<div class="spot-pv-img chk">${img ? `<img src="${img}" alt="">` : ''}</div><h4>${esc(it.label)}</h4><p>${esc(it.sub)}</p>`; }
      else if (it.kind === 'project') h = `<div class="spot-pv-img">${it.thumb ? `<img src="${it.thumb}" alt="">` : O.icon('frame', 40)}</div><h4>${esc(it.label)}</h4><p>${esc(t('Enter — відкрити проєкт'))}</p>`;
      else if (it.kind === 'font') { if (O.fonts) O.fonts.load(it.family); h = `<div class="spot-font" style="font-family:'${esc(it.family)}',var(--font)">Аа Bb<br><small>${esc(t('Швидка руда лисиця'))} — The quick brown fox</small></div><h4>${esc(it.family)}</h4><p>${esc(O.topSel().some(n => n.type === 'text') ? t('Enter — застосувати до виділеного тексту') : t('Enter — завантажити шрифт'))}</p>`; }
      else if (it.kind === 'color') h = `<div class="spot-color" style="background:${it.color}"></div><h4>${esc(it.color)}</h4><p>${esc(it.sub)}</p>`;
      else if (it.kind === 'claude') h = `<div class="spot-claude">${O.icon('sparkle', 34)}</div><h4>${esc(t('Дизайн з Claude'))}</h4><p>${esc(t('Claude створить макет у вибраному форматі й стилі. Кожен елемент стане окремим шаром, який можна редагувати.'))}</p>`;
      else h = `<div class="spot-claude cmd">${O.icon(it.icon || 'command', 30)}</div><h4>${esc(it.label)}</h4><p>${esc(it.sub || '')}</p>${it.keys ? `<p class="spot-meta"><kbd>${esc(O.keyLabel(it.keys))}</kbd></p>` : ''}`;
      prev.innerHTML = h;
    };
    const render = () => {
      items = collect();
      idx = Math.min(idx, Math.max(0, items.length - 1));
      let h = '', last = null;
      items.forEach((it, i) => { if (it.grp !== last) { h += `<div class="spot-h">${esc(t(GROUP_TITLE[it.grp] || ''))}</div>`; last = it.grp; } h += itemHTML(it, i); });
      box.innerHTML = h || `<div class="pal-empty">${esc(t('Нічого не знайдено'))}</div>`;
      wrap.querySelectorAll('[data-cat]').forEach(b => b.classList.toggle('on', b.dataset.cat === cat));
      const on = box.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest' });
      preview();
    };
    const move = i => {
      idx = O.clamp(i, 0, items.length - 1);
      box.querySelectorAll('.spot-it').forEach(el => { const on = +el.dataset.i === idx; el.classList.toggle('on', on); el.setAttribute('aria-selected', on); if (on) el.scrollIntoView({ block: 'nearest' }); });
      preview();
    };
    const close = () => { wrap.remove(); SP.open = false; };
    const go = i => {
      const it = items[i];
      if (!it || it.dis) return;
      close();
      remember(it.key);
      try { it.run(); } catch (e) { console.error(e); O.toast('Помилка: {msg}', { msg: e.message }); }
    };
    inp.addEventListener('input', () => { idx = 0; render(); });
    inp.addEventListener('keydown', e => {
      e.stopPropagation();
      if (e.key === 'ArrowDown') { move(idx + 1); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { move(idx - 1); e.preventDefault(); }
      else if (e.key === 'Enter') { e.preventDefault(); if (e.ctrlKey || e.metaKey) { const raw = inp.value.trim(); close(); SP.claudeDialog({ prompt: raw }); } else go(idx); }
      else if (e.key === 'Escape') { close(); e.preventDefault(); }
      else if (e.key === 'Tab') { e.preventDefault(); const i = CATS.findIndex(c => c[0] === cat); cat = CATS[(i + (e.shiftKey ? CATS.length - 1 : 1)) % CATS.length][0]; idx = 0; render(); }
    });
    box.addEventListener('click', e => { const it = e.target.closest('.spot-it'); if (it) go(+it.dataset.i); });
    box.addEventListener('mousemove', e => { const it = e.target.closest('.spot-it'); if (it && +it.dataset.i !== idx) move(+it.dataset.i); });
    wrap.querySelector('.spot-cats').addEventListener('click', e => { const b = e.target.closest('[data-cat]'); if (!b) return; cat = b.dataset.cat; idx = 0; render(); inp.focus(); });
    wrap.addEventListener('pointerdown', e => { if (e.target === wrap) close(); });
    if (opts.q) inp.value = opts.q;
    render();
    setTimeout(() => inp.focus(), 0);
  };
  // the old command palette opens Spotlight (Ctrl+/, Ctrl+K and the search button)
  ui.palette = () => SP.show();
  O.ICONS.sparkle = O.ICONS.sparkle || '<path d="M12 3l1.6 5.2a3 3 0 0 0 2 2L21 12l-5.4 1.8a3 3 0 0 0-2 2L12 21l-1.6-5.2a3 3 0 0 0-2-2L3 12l5.4-1.8a3 3 0 0 0 2-2z"/>';
  O.ICONS.command = O.ICONS.command || '<path d="M9 6v12M15 6v12M6 9h12M6 15h12"/><path d="M9 6a3 3 0 1 0-3 3M15 6a3 3 0 1 1 3 3M9 18a3 3 0 1 1-3-3M15 18a3 3 0 1 0 3-3"/>';
  O.ICONS.hash = O.ICONS.hash || '<path d="M5 9h14M5 15h14M10 4l-2 16M16 4l-2 16"/>';
  O.ICONS.drop = O.ICONS.drop || '<path d="M12 3s6 6.6 6 11a6 6 0 0 1-12 0c0-4.4 6-11 6-11z"/>';

  // ======================================================================
  // DESIGN WITH CLAUDE
  // ======================================================================
  // The browser talks to the Claude API directly with the person's own API key (kept in this browser only when asked).
  // Claude returns one SVG; VIBSma turns it into editable layers inside a new frame.
  SP.FORMATS = [['post', 'Пост Instagram', 1080, 1350], ['square', 'Квадрат', 1080, 1080], ['story', 'Story / Reels', 1080, 1920], ['a4', 'Постер A4', 595, 842], ['slide', 'Слайд 16:9', 1920, 1080], ['web', 'Перший екран сайту', 1440, 900], ['mobile', 'Екран застосунку', 390, 844], ['card', 'Візитка', 1050, 600], ['logo', 'Логотип', 1024, 1024]];
  const SYSTEM = [
    'You are a senior graphic designer working inside VIBSma, a vector design editor.',
    'Design exactly what the person describes and reply with one complete standalone SVG document and nothing else.',
    'Rules for the SVG:',
    '- Root: <svg xmlns="http://www.w3.org/2000/svg" width="W" height="H" viewBox="0 0 W H"> with the exact size given.',
    '- Use only these elements: g, rect, circle, ellipse, line, polyline, polygon, path, text, tspan, defs, linearGradient, radialGradient, stop, clipPath. No <image>, <foreignObject>, <style>, <script>, CSS classes or external references.',
    '- Inline presentation attributes (fill, stroke, stroke-width, opacity, font-family, font-size, font-weight, letter-spacing, text-anchor).',
    '- Give every element and group a short descriptive id in the language of the request (it becomes the layer name), e.g. id="Заголовок", id="Кнопка".',
    '- Fonts: Google Fonts family names (for example Inter, Playfair Display, Montserrat), with a generic fallback.',
    '- Write all visible text in the language of the request. Keep text editable as <text>, never convert it to paths.',
    '- Make it polished: clear hierarchy, generous spacing, a coherent palette, aligned to an invisible grid, readable contrast.'
  ].join('\n');
  const keyStore = () => O.ls.get('claudeKey', '') || sessionStorage.getItem('obrysClaudeKey') || '';
  SP.claudeDialog = (opts = {}) => {
    // the hand-made 100 (plus the chosen style when it is one of the 10 000 new ones)
    const styles = O.gallery ? (O.gallery.CORE || O.gallery.STYLES).concat(opts.style && O.gallery.get(opts.style) && !(O.gallery.CORE || []).some(s => s.k === opts.style) ? [O.gallery.get(opts.style)] : []) : [];
    const fmt = O.ls.get('claudeFmt', 'post');
    const d = ui.dialog({
      title: 'Дизайн з Claude',
      body: `<div class="cl-hero">${O.icon('sparkle', 22)}<div><b>${esc(t('Опишіть дизайн — Claude намалює його'))}</b><span>${esc(t('Результат — звичайні шари VIBSma: текст, фігури, градієнти. Їх можна редагувати, анімувати й експортувати.'))}</span></div></div>
        <textarea class="cl-prompt" rows="4" placeholder="${esc(t('Наприклад: постер джазового фестивалю в Києві, 12 червня, темно-синій із золотом, велика типографіка'))}">${esc(opts.prompt || '')}</textarea>
        <div class="cl-row"><label><span>${esc(t('Формат'))}</span><select class="cl-fmt">${SP.FORMATS.map(([k, l, w, h]) => `<option value="${k}"${k === fmt ? ' selected' : ''}>${esc(t(l))} · ${w}×${h}</option>`).join('')}</select></label>
        <label><span>${esc(t('Стиль'))}</span><select class="cl-style"><option value="">${esc(t('На розсуд Claude'))}</option>${styles.map(s => `<option value="${s.k}"${s.k === opts.style ? ' selected' : ''}>${esc(t(s.n))}</option>`).join('')}</select></label></div>
        <details class="cl-key"${keyStore() ? '' : ' open'}><summary>${esc(t('Ключ Claude API'))}${keyStore() ? ' ✓' : ''}</summary>
          <div class="dlg-text small">${esc(t('Потрібен ваш ключ з console.anthropic.com. Запит іде напряму з браузера до Anthropic; ключ ніде, крім цього браузера, не зберігається.'))}</div>
          <input class="cl-apikey" type="password" autocomplete="off" spellcheck="false" placeholder="sk-ant-…" value="${esc(keyStore())}">
          <label class="chk"><input type="checkbox" class="cl-remember"${O.ls.get('claudeKey', '') ? ' checked' : ''}><span>${esc(t('Запам’ятати ключ у цьому браузері'))}</span></label></details>
        <div class="cl-status" aria-live="polite"></div>`,
      buttons: [{ id: 'ok', label: 'Створити дизайн', primary: true }],
      keepOpen: true,
      onOk: () => run()
    });
    d.el.querySelector('.dlg').classList.add('cl-dlg');
    const $ = s => d.el.querySelector(s);
    const status = (msg, cls) => { const el = $('.cl-status'); el.className = 'cl-status' + (cls ? ' ' + cls : ''); el.textContent = msg; };
    setTimeout(() => { const ta = $('.cl-prompt'); ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); }, 30);
    let busy = false;
    const run = async () => {
      if (busy) return;
      const prompt = $('.cl-prompt').value.trim();
      if (!prompt) return status(t('Опишіть, що потрібно створити'), 'err');
      const apiKey = $('.cl-apikey').value.trim();
      if (!apiKey) { $('.cl-key').open = true; $('.cl-apikey').focus(); return status(t('Вставте ключ Claude API'), 'err'); }
      if ($('.cl-remember').checked) O.ls.set('claudeKey', apiKey); else { O.ls.set('claudeKey', ''); try { sessionStorage.setItem('obrysClaudeKey', apiKey); } catch (e) { /* ignore */ } }
      const f = SP.FORMATS.find(x => x[0] === $('.cl-fmt').value) || SP.FORMATS[0];
      O.ls.set('claudeFmt', f[0]);
      const st = styles.find(s => s.k === $('.cl-style').value);
      busy = true;
      d.el.querySelector('[data-b="ok"]').disabled = true;
      try {
        const svg = await SP.generate({ apiKey, prompt, w: f[2], h: f[3], style: st, onProgress: n => status(t('Claude малює… отримано {n} символів', { n })) });
        SP.placeDesign(svg, f[2], f[3], prompt);
        d.close();
        O.toast('Дизайн від Claude додано на полотно');
      } catch (e) {
        console.warn(e);
        status(e.message || String(e), 'err');
      } finally { busy = false; const b = d.el.querySelector('[data-b="ok"]'); if (b) b.disabled = false; }
    };
  };
  SP.generate = async ({ apiKey, prompt, w, h, style, onProgress }) => {
    status0(onProgress);
    let Anthropic;
    try { ({ default: Anthropic } = await import('https://cdn.jsdelivr.net/npm/@anthropic-ai/sdk/+esm')); } catch (e) { throw new Error(t('Не вдалося завантажити Anthropic SDK — потрібен інтернет')); }
    const client = new Anthropic({ apiKey, dangerouslyAllowBrowser: true });
    const styleText = style ? `\nStyle: ${O.tIn('en', style.n)} — ${O.tIn('en', style.d)} Palette: ${style.pal.join(', ')}. Fonts: ${style.f[0]} (headings), ${style.f[1]} (text).` : '';
    const stream = client.beta.messages.stream({
      model: 'claude-opus-5-5',
      max_tokens: 64000,
      output_config: { effort: 'high' },
      // if a safety classifier declines, the API retries on a suitable model by itself
      betas: ['server-side-fallback-2026-07-01'],
      fallbacks: 'default',
      system: SYSTEM,
      messages: [{ role: 'user', content: `Canvas: ${w}×${h} px.${styleText}\n\n${prompt}` }]
    });
    let n = 0;
    for await (const ev of stream) {
      if (ev.type === 'content_block_delta' && ev.delta.type === 'text_delta') { n += ev.delta.text.length; if (onProgress) onProgress(n); }
    }
    const msg = await stream.finalMessage();
    if (msg.stop_reason === 'refusal') throw new Error(t('Claude відмовився виконати цей запит. Змініть опис.'));
    const text = msg.content.filter(b => b.type === 'text').map(b => b.text).join('');
    const m = /<svg[\s\S]*<\/svg>/i.exec(text);
    if (!m) throw new Error(msg.stop_reason === 'max_tokens' ? t('Відповідь обірвалася: дизайн задовгий. Спробуйте простіший опис.') : t('Claude не повернув SVG. Спробуйте ще раз.'));
    return m[0];
  };
  const status0 = fn => { if (fn) fn(0); };
  // a new frame next to the existing work, the SVG inside it as layers
  SP.placeDesign = (svg, w, h, prompt) => {
    const page = model.page();
    const b = page.children.length ? model.selBounds(page.children) : null;
    const name = String(prompt || t('Дизайн')).replace(/\s+/g, ' ').slice(0, 40);
    const f = model.create('frame', { name: `Claude · ${name}`, w, h, m: O.M.translate(b ? Math.round(b.x + b.w + 120) : 0, b ? Math.round(b.y) : 0), fills: [O.paint.solid('#FFFFFF')], clip: true });
    model.insert(f, page);
    model.reindex();
    const g = O.io.importSVG(svg, { container: f, noCenter: true, noCommit: true, name: t('Дизайн Claude') });
    if (!g) { model.remove(f); throw new Error(t('Не вдалося прочитати SVG від Claude')); }
    O.select([f.id]);
    O.history.commit('Дизайн з Claude');
    setTimeout(() => V.fit(model.worldBounds(f), 80, 1), 0);
    return f;
  };
  O.cmd('claudeDesign', 'Дизайн з Claude…', () => SP.claudeDialog(), { keys: ['Ctrl+Alt+Shift+A'], group: 'Файл' });
  O.cmd('spotlight', 'Spotlight: пошук усього…', () => SP.show(), { group: 'Довідка' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл');
  if (fileMenu) { const i = fileMenu[1].indexOf('new'); fileMenu[1].splice(i >= 0 ? i + 1 : 0, 0, 'claudeDesign'); }
})();
