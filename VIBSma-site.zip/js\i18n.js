'use strict';
/* VIBSma — localisation. Ukrainian strings in the source are the keys; i18n-data.js maps them to en / ru / de. */
(function () {
  const O = window.O;
  const LANGS = O.LANGS = { uk: 'Українська', en: 'English', ru: 'Русский', de: 'Deutsch' };
  const maps = { en: new Map(), ru: new Map(), de: new Map() };
  O.I18N_ROWS = [];
  O.i18nAdd = rows => {
    for (const r of rows) {
      O.I18N_ROWS.push(r);
      maps.en.set(r[0], r[1]); maps.ru.set(r[0], r[2]); maps.de.set(r[0], r[3]);
    }
  };
  const detect = () => {
    const list = (navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || 'en']).map(l => String(l).toLowerCase());
    for (const l of list) { const k = l.slice(0, 2); if (LANGS[k]) return k; }
    return 'en';
  };
  const fromUrl = new URLSearchParams(location.search).get('lang');
  const saved = O.ls.get('lang', '');
  // English unless the person picked a language (menu View → Language, or ?lang= in the address)
  void detect;
  O.lang = LANGS[fromUrl] ? fromUrl : (LANGS[saved] ? saved : 'en');
  O.missing = new Set();
  const fill = (s, vars) => !vars ? s : s.replace(/\{(\w+)\}/g, (m, k) => (vars[k] !== undefined && vars[k] !== null ? String(vars[k]) : m));
  O.t = (s, vars) => {
    if (s === undefined || s === null) return '';
    s = String(s);
    if (O.lang === 'uk' || !s) return fill(s, vars);
    const v = maps[O.lang].get(s);
    if (v === undefined) { O.missing.add(s); return fill(s, vars); }
    return fill(v, vars);
  };
  // a string in a given language (whatever the UI language is), e.g. English names for prompts
  O.tIn = (lang, s) => (lang === 'uk' || !maps[lang] ? String(s) : (maps[lang].get(String(s)) || String(s)));
  O.applyI18n = root => {
    root = root || document;
    root.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = O.t(el.dataset.i18n); });
    root.querySelectorAll('[data-i18n-title]').forEach(el => { el.title = O.t(el.dataset.i18nTitle); });
    root.querySelectorAll('[data-i18n-aria]').forEach(el => { el.setAttribute('aria-label', O.t(el.dataset.i18nAria)); });
    root.querySelectorAll('[data-i18n-ph]').forEach(el => { el.placeholder = O.t(el.dataset.i18nPh); });
    document.documentElement.lang = O.lang;
    document.title = O.t('VIBSma');
  };
  O.setLang = lang => {
    if (!LANGS[lang] || lang === O.lang) return;
    O.lang = lang;
    O.ls.set('lang', lang);
    O.applyI18n();
    O.emit('lang', lang);
  };
  // German keyboards label Ctrl as "Strg" and Shift as "Umschalt".
  // Used when the UI is German or a German (QWERTZ) keyboard layout is detected.
  O.germanKeyboard = false;
  const baseKeyLabel = O.keyLabel;
  O.keyLabel = k => {
    const s = baseKeyLabel(k);
    if (O.isMac || !(O.lang === 'de' || O.germanKeyboard)) return s;
    return s.replace(/Ctrl\+/g, 'Strg+').replace(/Shift\+/g, 'Umschalt+');
  };
  const markGerman = () => { if (!O.germanKeyboard) { O.germanKeyboard = true; O.emit('lang', O.lang); } };
  try {
    if (navigator.keyboard && navigator.keyboard.getLayoutMap) {
      navigator.keyboard.getLayoutMap().then(map => {
        if (map.get('KeyY') === 'z' && (map.get('BracketLeft') === 'ü' || map.get('Semicolon') === 'ö')) markGerman();
      }).catch(() => {});
    }
  } catch (e) { /* layout map unavailable */ }
  // QWERTZ also shows up in key events: the key at the Y position prints "z"
  document.addEventListener('keydown', e => { if (e.code === 'KeyY' && e.key === 'z') markGerman(); }, true);
})();
