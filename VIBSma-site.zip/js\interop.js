'use strict';
/* VIBSma — interop: Figma clipboard and .fig files (kiwi format), Photoshop PSD import/export */
(function () {
  const O = window.O, M = O.M, G = O.G, R = O.R, model = O.model, S = O.state, V = O.view;
  const t = (s, v) => O.t(s, v);
  const X = O.interop = {};

  // ---------- lazy script loading ----------
  const loading = {};
  O.loadScript = src => loading[src] || (loading[src] = new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = () => res();
    s.onerror = () => { delete loading[src]; rej(new Error(t('Не вдалося завантажити модуль {name}', { name: src }))); };
    document.head.appendChild(s);
  }));

  // ---------- decompression ----------
  const inflateWith = async (fmt, u8) => new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream(fmt))).arrayBuffer());
  X.inflate = async u8 => {
    if (u8[0] === 0x28 && u8[1] === 0xB5 && u8[2] === 0x2F && u8[3] === 0xFD) {
      await O.loadScript('vendor/fzstd.js');
      return window.fzstd.decompress(u8);
    }
    for (const fmt of ['deflate-raw', 'deflate']) { try { return await inflateWith(fmt, u8); } catch (e) { /* try next */ } }
    return u8;
  };

  // ---------- kiwi binary format (Figma's schema-based serialization) ----------
  const f32 = new Float32Array(1), i32 = new Int32Array(f32.buffer);
  const utf8 = new TextDecoder();
  class BB {
    constructor(u8) { this.d = u8; this.i = 0; }
    byte() { if (this.i >= this.d.length) throw new Error('kiwi: out of bounds'); return this.d[this.i++]; }
    vuint() { let v = 0, shift = 0, b; do { b = this.byte(); v += (b & 127) * Math.pow(2, shift); shift += 7; } while ((b & 128) && shift < 70); return v; }
    vint() { const v = this.vuint(); return v % 2 ? -(v + 1) / 2 : v / 2; }
    vfloat() {
      const d = this.d, i = this.i;
      if (d[i] === 0) { this.i++; return 0; }
      if (i + 4 > d.length) throw new Error('kiwi: out of bounds');
      let bits = d[i] | (d[i + 1] << 8) | (d[i + 2] << 16) | (d[i + 3] << 24);
      this.i += 4;
      bits = (bits << 23) | (bits >>> 9);
      i32[0] = bits;
      return f32[0];
    }
    str() { const st = this.i; while (this.i < this.d.length && this.d[this.i] !== 0) this.i++; const s = utf8.decode(this.d.subarray(st, this.i)); this.i++; return s; }
    bytes() { const n = this.vuint(); const out = this.d.subarray(this.i, this.i + n); this.i += n; return out; }
  }
  const BUILTIN = ['bool', 'byte', 'int', 'uint', 'float', 'string', 'int64', 'uint64'];
  const KINDS = ['ENUM', 'STRUCT', 'MESSAGE'];
  X.decodeSchema = u8 => {
    const bb = new BB(u8);
    const count = bb.vuint(), defs = [];
    for (let i = 0; i < count; i++) {
      const name = bb.str(), kind = KINDS[bb.byte()], fc = bb.vuint(), fields = [];
      for (let j = 0; j < fc; j++) {
        const fname = bb.str(), type = bb.vint(), isArray = !!(bb.byte() & 1), value = bb.vuint();
        fields.push({ name: fname, type, isArray, value });
      }
      defs.push({ name, kind, fields });
    }
    const byName = {};
    for (const d of defs) {
      byName[d.name] = d;
      d.byValue = {};
      for (const f of d.fields) { f.typeName = f.type < 0 ? BUILTIN[~f.type] : (defs[f.type] && defs[f.type].name); d.byValue[f.value] = f; }
    }
    return { defs, byName };
  };
  X.decode = (schema, u8, rootName) => {
    const bb = new BB(u8);
    const value = typeName => {
      switch (typeName) {
        case 'bool': return !!bb.byte();
        case 'byte': return bb.byte();
        case 'int': case 'int64': return bb.vint();
        case 'uint': case 'uint64': return bb.vuint();
        case 'float': return bb.vfloat();
        case 'string': return bb.str();
      }
      const d = schema.byName[typeName];
      if (!d) throw new Error('kiwi: unknown type ' + typeName);
      if (d.kind === 'ENUM') { const v = bb.vuint(); return d.byValue[v] ? d.byValue[v].name : v; }
      const obj = {};
      if (d.kind === 'STRUCT') { for (const f of d.fields) obj[f.name] = field(f); return obj; }
      for (;;) {
        const tag = bb.vuint();
        if (tag === 0) return obj;
        const f = d.byValue[tag];
        if (!f) throw new Error('kiwi: unknown field ' + tag + ' in ' + d.name);
        obj[f.name] = field(f);
      }
    };
    const field = f => {
      if (!f.isArray) return value(f.typeName);
      if (f.typeName === 'byte') return bb.bytes();
      const n = bb.vuint(), arr = new Array(n);
      for (let k = 0; k < n; k++) arr[k] = value(f.typeName);
      return arr;
    };
    return value(rootName);
  };
  // "fig-kiwi" archive: header, version, then length-prefixed chunks (schema, data)
  X.decodeFig = async bytes => {
    const head = utf8.decode(bytes.subarray(0, 8));
    if (!head.startsWith('fig-')) throw new Error('not a Figma archive');
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let off = 12;
    const chunks = [];
    while (off + 4 <= bytes.length) { const len = dv.getUint32(off, true); off += 4; chunks.push(bytes.subarray(off, off + len)); off += len; }
    if (chunks.length < 2) throw new Error('Figma archive is incomplete');
    const schema = X.decodeSchema(await X.inflate(chunks[0]));
    const data = await X.inflate(chunks[1]);
    const root = schema.byName.Message ? 'Message' : (schema.defs.filter(d => d.kind === 'MESSAGE').pop() || {}).name;
    return X.decode(schema, data, root);
  };

  // ---------- Figma nodes -> VIBSma nodes ----------
  const hex = c => O.color.hex({ r: (c.r || 0) * 255, g: (c.g || 0) * 255, b: (c.b || 0) * 255 });
  const BLEND = { NORMAL: 'normal', PASS_THROUGH: 'normal', MULTIPLY: 'multiply', SCREEN: 'screen', OVERLAY: 'overlay', DARKEN: 'darken', LIGHTEN: 'lighten', COLOR_DODGE: 'color-dodge', LINEAR_DODGE: 'color-dodge', COLOR_BURN: 'color-burn', LINEAR_BURN: 'color-burn', HARD_LIGHT: 'hard-light', SOFT_LIGHT: 'soft-light', DIFFERENCE: 'difference', EXCLUSION: 'exclusion', HUE: 'hue', SATURATION: 'saturation', COLOR: 'color', LUMINOSITY: 'luminosity' };
  const hashHex = h => h ? Array.from(h.hash || h).map(b => (+b).toString(16).padStart(2, '0')).join('') : '';
  const tf = T => T ? [T.m00, T.m10, T.m01, T.m11, T.m02, T.m12].map(v => +v || 0) : M.id();
  X.pathFromBlob = u8 => {
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let i = 0, cur = null;
    const subs = [];
    const f = () => { const v = dv.getFloat32(i, true); i += 4; return v; };
    const ensure = () => { if (!cur) { cur = { closed: false, pts: [G.pt(0, 0)] }; subs.push(cur); } return cur; };
    while (i < u8.length) {
      const c = u8[i++];
      if (c === 0) {
        if (cur) {
          cur.closed = true;
          const a = cur.pts[0], b = cur.pts[cur.pts.length - 1];
          if (cur.pts.length > 1 && Math.abs(a.x - b.x) < 1e-4 && Math.abs(a.y - b.y) < 1e-4) { a.i = b.i; cur.pts.pop(); }
        }
        cur = null;
      } else if (c === 1) { cur = { closed: false, pts: [G.pt(f(), f())] }; subs.push(cur); }
      else if (c === 2) { const x = f(), y = f(); ensure().pts.push(G.pt(x, y)); }
      else if (c === 3) {
        const qx = f(), qy = f(), x = f(), y = f(), sp = ensure(), l = sp.pts[sp.pts.length - 1];
        l.o = { x: l.x + 2 / 3 * (qx - l.x), y: l.y + 2 / 3 * (qy - l.y) };
        sp.pts.push(G.pt(x, y, { x: x + 2 / 3 * (qx - x), y: y + 2 / 3 * (qy - y) }));
      } else if (c === 4) {
        const ax = f(), ay = f(), bx = f(), by = f(), x = f(), y = f(), sp = ensure();
        sp.pts[sp.pts.length - 1].o = { x: ax, y: ay };
        sp.pts.push(G.pt(x, y, { x: bx, y: by }));
      } else break;
    }
    for (const sp of subs) for (const p of sp.pts) p.t = G.detectType(p);
    return subs.filter(sp => sp.pts.length > 1);
  };
  X.toNodes = (msg, ctx) => {
    const list = msg.nodeChanges || [];
    const blobs = msg.blobs || [];
    const key = g => g ? g.sessionID + ':' + g.localID : '';
    const byId = new Map(), kids = new Map();
    for (const n of list) byId.set(key(n.guid), n);
    for (const n of list) {
      const pk = n.parentIndex && key(n.parentIndex.guid);
      if (!pk) continue;
      if (!kids.has(pk)) kids.set(pk, []);
      kids.get(pk).push(n);
    }
    const pos = n => (n.parentIndex && n.parentIndex.position) || '';
    for (const arr of kids.values()) arr.sort((a, b) => (pos(a) < pos(b) ? -1 : pos(a) > pos(b) ? 1 : 0));
    const blobBytes = idx => { const b = blobs[idx]; return b ? (b.bytes || b) : null; };
    const geom = arr => {
      let subs = [], rule = 'nonzero';
      for (const g of arr || []) {
        const bytes = blobBytes(g.commandsBlob);
        if (!bytes || !bytes.length) continue;
        subs = subs.concat(X.pathFromBlob(bytes));
        if (g.windingRule === 'ODD' || g.windingRule === 'EVENODD') rule = 'evenodd';
      }
      return { subs, rule };
    };
    const paints = arr => (arr || []).map(p => {
      const vis = p.visible !== false, op = p.opacity === undefined ? 1 : p.opacity;
      if (p.type === 'SOLID') { const c = p.color || { r: 0, g: 0, b: 0, a: 1 }; return { type: 'solid', color: hex(c), opacity: op * (c.a === undefined ? 1 : c.a), visible: vis }; }
      if (p.type && p.type.indexOf('GRADIENT') === 0) {
        const stops = (p.stops || []).map(s => ({ o: s.position || 0, color: hex(s.color || {}), a: s.color && s.color.a !== undefined ? s.color.a : 1 }));
        const iT = M.inv(tf(p.transform));
        const radial = p.type !== 'GRADIENT_LINEAR';
        return { type: radial ? 'radial' : 'linear', visible: vis, opacity: op, from: M.apply(iT, radial ? { x: 0.5, y: 0.5 } : { x: 0, y: 0.5 }), to: M.apply(iT, { x: 1, y: 0.5 }), stops: stops.length > 1 ? stops : [{ o: 0, color: '#FFFFFF', a: 1 }, { o: 1, color: '#000000', a: 1 }] };
      }
      if (p.type === 'IMAGE') {
        const h = hashHex(p.image);
        const asset = ctx && ctx.images && ctx.images[h];
        if (asset) return { type: 'image', asset, mode: { FIT: 'fit', TILE: 'tile', STRETCH: 'stretch' }[p.imageScaleMode] || 'fill', scale: p.scale || 1, opacity: op, visible: vis };
        return { type: 'solid', color: '#D9D9D9', opacity: op, visible: vis };
      }
      return null;
    }).filter(Boolean);
    const effects = arr => (arr || []).map(e => {
      const vis = e.visible !== false, c = e.color || { r: 0, g: 0, b: 0, a: 0.25 };
      const base = { x: e.offset ? e.offset.x : 0, y: e.offset ? e.offset.y : 0, blur: e.radius || 0, spread: e.spread || 0, color: hex(c), opacity: c.a === undefined ? 0.25 : c.a, visible: vis };
      if (e.type === 'DROP_SHADOW') return Object.assign({ type: 'shadow' }, base);
      if (e.type === 'INNER_SHADOW') return Object.assign({ type: 'inner' }, base);
      if (e.type === 'FOREGROUND_BLUR' || e.type === 'LAYER_BLUR') return { type: 'blur', blur: e.radius || 0, visible: vis };
      return null;
    }).filter(Boolean);
    const radius = n => {
      if (n.rectangleCornerRadiiIndependent) return [n.rectangleTopLeftCornerRadius || 0, n.rectangleTopRightCornerRadius || 0, n.rectangleBottomRightCornerRadius || 0, n.rectangleBottomLeftCornerRadius || 0];
      return n.cornerRadius || 0;
    };
    const weightOf = st => /thin|hairline/i.test(st) ? 100 : /extra ?light|ultra ?light/i.test(st) ? 200 : /light/i.test(st) ? 300 : /medium/i.test(st) ? 500 : /semi ?bold|demi/i.test(st) ? 600 : /extra ?bold|ultra ?bold/i.test(st) ? 800 : /black|heavy/i.test(st) ? 900 : /bold/i.test(st) ? 700 : 400;
    let count = 0;
    const conv = fn => {
      const base = { name: fn.name || '', visible: fn.visible !== false, opacity: fn.opacity === undefined ? 1 : fn.opacity, blend: BLEND[fn.blendMode] || 'normal', m: tf(fn.transform) };
      const style = {
        fills: paints(fn.fillPaints), strokes: paints(fn.strokePaints), sw: fn.strokeWeight === undefined ? 1 : fn.strokeWeight,
        sa: { INSIDE: 'inside', OUTSIDE: 'outside' }[fn.strokeAlign] || 'center', effects: effects(fn.effects),
        cap: { ROUND: 'round', SQUARE: 'square' }[fn.strokeCap] || 'butt', join: { ROUND: 'round', BEVEL: 'bevel' }[fn.strokeJoin] || 'miter',
        dash: Array.isArray(fn.dashPattern) ? fn.dashPattern.filter(v => v > 0) : []
      };
      const w = fn.size ? fn.size.x : 0, h = fn.size ? fn.size.y : 0;
      const children = () => (kids.get(key(fn.guid)) || []).map(conv).filter(Boolean);
      count++;
      switch (fn.type) {
        case 'FRAME': case 'SYMBOL': case 'INSTANCE': case 'COMPONENT_SET': case 'SECTION':
          return model.create('frame', Object.assign({}, base, style, { w, h, clip: !fn.frameMaskDisabled, radius: radius(fn), children: children(), component: fn.type === 'SYMBOL', name: base.name || t('Фрейм') }));
        case 'GROUP': {
          const ch = children();
          if (!ch.length) return null;
          return model.create('group', Object.assign({}, base, { m: M.id(), children: ch, name: base.name || t('Група') }));
        }
        case 'BOOLEAN_OPERATION': {
          const ch = children();
          if (!ch.length) return null;
          return model.create('bool', Object.assign({}, base, style, { m: M.id(), op: { SUBTRACT: 'subtract', INTERSECT: 'intersect', XOR: 'exclude' }[fn.booleanOperation] || 'union', children: ch, name: base.name || t('Булева група') }));
        }
        case 'RECTANGLE': case 'ROUNDED_RECTANGLE':
          return model.create('rect', Object.assign({}, base, style, { w, h, radius: radius(fn), name: base.name || model.autoName('rect') }));
        case 'ELLIPSE':
          return model.create('ellipse', Object.assign({}, base, style, { w, h, name: base.name || model.autoName('ellipse') }));
        case 'TEXT': {
          const st = fn.fontName ? (fn.fontName.style || '') : '';
          const size = fn.fontSize || 16;
          const ls = fn.letterSpacing ? (fn.letterSpacing.units === 'PERCENT' ? fn.letterSpacing.value * size / 100 : fn.letterSpacing.value || 0) : 0;
          let lh = null;
          if (fn.lineHeight && fn.lineHeight.value) lh = fn.lineHeight.units === 'PERCENT' ? fn.lineHeight.value / 100 : fn.lineHeight.units === 'PIXELS' ? fn.lineHeight.value / size : null;
          const text = (fn.textData && fn.textData.characters) || fn.characters || '';
          return model.create('text', Object.assign({}, base, style, {
            text, font: fn.fontName ? fn.fontName.family : 'Arial', weight: weightOf(st), italic: /italic|oblique/i.test(st), size, ls, lh,
            align: { CENTER: 'center', RIGHT: 'right', JUSTIFIED: 'justify' }[fn.textAlignHorizontal] || 'left',
            width: fn.textAutoResize === 'WIDTH_AND_HEIGHT' ? null : (w || null),
            fills: style.fills.length ? style.fills : [O.paint.solid('#000000')], name: base.name || text.slice(0, 40) || t('Текст')
          }));
        }
        case 'LINE':
          return model.create('path', Object.assign({}, base, style, { subpaths: [{ closed: false, pts: [G.pt(0, 0), G.pt(w, 0)] }], name: base.name || model.autoName('line') }));
        default: {
          const g1 = geom(fn.fillGeometry);
          if (g1.subs.length) return model.create('path', Object.assign({}, base, style, { subpaths: g1.subs, fillRule: g1.rule, name: base.name || model.autoName('path') }));
          const g2 = geom(fn.strokeGeometry);
          if (g2.subs.length) return model.create('path', Object.assign({}, base, style, { subpaths: g2.subs, fillRule: 'nonzero', fills: style.strokes, strokes: [], name: base.name || model.autoName('path') }));
          if (w && h) return model.create('rect', Object.assign({}, base, style, { w, h, name: base.name || model.autoName('rect') }));
          return null;
        }
      }
    };
    const isRootish = n => !n || n.type === 'DOCUMENT' || n.type === 'CANVAS';
    // canvases become pages (for .fig files); for the clipboard, all top nodes go to one list
    const pages = [];
    const canvases = list.filter(n => n.type === 'CANVAS');
    if (ctx && ctx.pages && canvases.length) {
      canvases.sort((a, b) => (pos(a) < pos(b) ? -1 : 1));
      for (const cv of canvases) {
        if (cv.internalOnly) continue;
        const nodes = (kids.get(key(cv.guid)) || []).map(conv).filter(Boolean);
        pages.push({ name: cv.name || t('Сторінка'), nodes, bg: cv.backgroundColor ? hex(cv.backgroundColor) : null });
      }
      return { pages, count };
    }
    const tops = list.filter(n => !isRootish(n) && isRootish(byId.get(key(n.parentIndex && n.parentIndex.guid))));
    tops.sort((a, b) => (pos(a) < pos(b) ? -1 : pos(a) > pos(b) ? 1 : 0));
    return { nodes: tops.map(conv).filter(Boolean), count };
  };

  // paste Figma layers copied with Ctrl+C
  X.extractFigmaClipboard = html => {
    const m = /\(figma\)([\s\S]*?)\(\/figma\)/.exec(html || '');
    if (!m) return null;
    const b64 = m[1].replace(/[^A-Za-z0-9+/=]/g, '');
    const bin = atob(b64);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return u8;
  };
  X.pasteFigma = async html => {
    const bytes = X.extractFigmaClipboard(html);
    if (!bytes) return false;
    const msg = await X.decodeFig(bytes);
    const { nodes, count } = X.toNodes(msg, {});
    if (!nodes.length) throw new Error('empty Figma clipboard');
    const c = R.center(V.viewRect());
    const cont = V.containerAt(c);
    nodes.forEach(n => model.insert(n, cont));
    model.reindex();
    const b = model.selBounds(nodes);
    if (b && !R.intersects(b, V.viewRect())) {
      const bc = R.center(b);
      nodes.forEach(n => model.applyWorld(n, M.translate(Math.round(c.x - bc.x), Math.round(c.y - bc.y)), 'resize'));
    }
    O.select(nodes.map(n => n.id));
    O.history.commit('Вставлення з Figma');
    O.toast('Вставлено з Figma: {n} шарів', { n: count });
    return true;
  };
  O.io.pasteHooks.push(async ({ html }) => {
    if (!html || html.indexOf('(figma)') < 0) return false;
    try { return await X.pasteFigma(html); }
    catch (e) {
      console.warn(e);
      O.toast('Не вдалося прочитати дані Figma. У Figma натисніть правою кнопкою → Copy/Paste as → Copy as SVG і вставте ще раз.');
      return true;
    }
  });

  // ---------- minimal ZIP reader (for .fig files) ----------
  X.unzip = u8 => {
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let eocd = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 70000); i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    if (eocd < 0) throw new Error('zip: end of central directory not found');
    const count = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const files = {};
    for (let k = 0; k < count; k++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true);
      const nameLen = dv.getUint16(p + 28, true), extraLen = dv.getUint16(p + 30, true), commentLen = dv.getUint16(p + 32, true), localOff = dv.getUint32(p + 42, true);
      const name = utf8.decode(u8.subarray(p + 46, p + 46 + nameLen));
      const start = localOff + 30 + dv.getUint16(localOff + 26, true) + dv.getUint16(localOff + 28, true);
      files[name] = { method, data: u8.subarray(start, start + csize) };
      p += 46 + nameLen + extraLen + commentLen;
    }
    return files;
  };
  const zipData = async e => (e.method === 8 ? inflateWith('deflate-raw', e.data) : e.data);
  const sniffMime = u8 => (u8[0] === 0x89 && u8[1] === 0x50 ? 'image/png' : u8[0] === 0xFF && u8[1] === 0xD8 ? 'image/jpeg' : u8[0] === 0x47 && u8[1] === 0x49 ? 'image/gif' : u8[8] === 0x57 && u8[9] === 0x45 ? 'image/webp' : 'image/png');
  X.importFigFile = async file => {
    O.toast('Відкриваю файл Figma…');
    try {
      const u8 = new Uint8Array(await file.arrayBuffer());
      let figBytes = u8;
      const images = {};
      if (u8[0] === 0x50 && u8[1] === 0x4B) {
        const files = X.unzip(u8);
        const mainName = files['canvas.fig'] ? 'canvas.fig' : Object.keys(files).find(k => /\.fig$/i.test(k));
        if (!mainName) throw new Error('canvas.fig not found');
        figBytes = await zipData(files[mainName]);
        for (const [name, e] of Object.entries(files)) {
          if (!name.startsWith('images/')) continue;
          const data = await zipData(e);
          const id = O.uid();
          const url = await O.io.blobToData(new Blob([data], { type: sniffMime(data) }));
          let w = 100, h = 100;
          try { const img = await O.io.loadImage(url); w = img.naturalWidth; h = img.naturalHeight; } catch (err) { /* keep defaults */ }
          S.doc.assets[id] = { data: url, w, h, name: name.slice(7) };
          images[name.slice(7).toLowerCase()] = id;
        }
      }
      const msg = await X.decodeFig(figBytes);
      const res = X.toNodes(msg, { pages: true, images });
      const prevPages = S.doc.pages.length;
      for (const pg of res.pages || []) {
        const page = model.newPage(pg.name);
        page.bg = pg.bg;
        page.children = pg.nodes;
        S.doc.pages.push(page);
      }
      if (!res.pages || !res.pages.length) throw new Error('no pages');
      if (prevPages === 1 && !S.doc.pages[0].children.length) S.doc.pages.shift();
      model.reindex();
      S.pageId = S.doc.pages[S.doc.pages.length - res.pages.length].id;
      S.sel = [];
      O.history.commit('Імпорт Figma');
      O.emit('page');
      O.toast('Імпортовано з Figma: сторінок {p}, шарів {n}', { p: res.pages.length, n: res.count });
    } catch (e) {
      console.warn(e);
      O.toast('Не вдалося відкрити файл Figma ({msg}). Спробуйте в Figma «Copy as SVG» або експорт SVG.', { msg: e.message });
    }
  };

  // ---------- Photoshop PSD ----------
  const PS_BLEND = { 'normal': 'normal', 'pass through': 'normal', 'dissolve': 'normal', 'darken': 'darken', 'multiply': 'multiply', 'color burn': 'color-burn', 'linear burn': 'color-burn', 'darker color': 'darken', 'lighten': 'lighten', 'screen': 'screen', 'color dodge': 'color-dodge', 'linear dodge': 'color-dodge', 'lighter color': 'lighten', 'overlay': 'overlay', 'soft light': 'soft-light', 'hard light': 'hard-light', 'vivid light': 'hard-light', 'linear light': 'hard-light', 'pin light': 'hard-light', 'hard mix': 'hard-light', 'difference': 'difference', 'exclusion': 'exclusion', 'subtract': 'difference', 'divide': 'screen', 'hue': 'hue', 'saturation': 'saturation', 'color': 'color', 'luminosity': 'luminosity' };
  const TO_PS = { 'normal': 'normal', 'darken': 'darken', 'multiply': 'multiply', 'color-burn': 'color burn', 'lighten': 'lighten', 'screen': 'screen', 'color-dodge': 'color dodge', 'overlay': 'overlay', 'soft-light': 'soft light', 'hard-light': 'hard light', 'difference': 'difference', 'exclusion': 'exclusion', 'hue': 'hue', 'saturation': 'saturation', 'color': 'color', 'luminosity': 'luminosity' };
  const opac = v => (v === undefined || v === null ? 1 : (v > 1 ? v / 255 : v));
  X.importPSD = async (file, at) => {
    O.toast('Відкриваю PSD…');
    try {
      await O.loadScript('vendor/ag-psd.js');
      const psd = window.agPsd.readPsd(await file.arrayBuffer(), { skipThumbnail: true });
      let layers = 0;
      const conv = layer => {
        if (layer.children) {
          const g = model.create('group', { name: layer.name || t('Група'), visible: !layer.hidden, opacity: opac(layer.opacity), blend: PS_BLEND[layer.blendMode] || 'normal' });
          g.children = layer.children.map(conv).filter(Boolean);
          return g.children.length ? g : null;
        }
        const cv = layer.canvas;
        if (!cv || !cv.width || !cv.height) return null;
        const id = O.uid();
        S.doc.assets[id] = { data: cv.toDataURL('image/png'), w: cv.width, h: cv.height, name: layer.name || 'layer' };
        layers++;
        return model.create('raster', { name: layer.name || t('Шар'), w: cv.width, h: cv.height, pw: cv.width, ph: cv.height, asset: id, m: M.translate(layer.left || 0, layer.top || 0), visible: !layer.hidden, opacity: opac(layer.opacity), blend: PS_BLEND[layer.blendMode] || 'normal' });
      };
      let children = (psd.children || []).map(conv).filter(Boolean);
      if (!children.length && psd.canvas) {
        const id = O.uid();
        S.doc.assets[id] = { data: psd.canvas.toDataURL('image/png'), w: psd.width, h: psd.height, name: file.name };
        children = [model.create('raster', { name: t('Тло'), w: psd.width, h: psd.height, pw: psd.width, ph: psd.height, asset: id })];
        layers = 1;
      }
      const c = at || R.center(V.viewRect());
      const frame = model.create('frame', { name: file.name.replace(/\.psd$/i, ''), w: psd.width, h: psd.height, fills: [], clip: true, m: M.translate(Math.round(c.x - psd.width / 2), Math.round(c.y - psd.height / 2)) });
      frame.children = children;
      model.insert(frame, model.page());
      O.select([frame.id]);
      O.history.commit('Імпорт PSD');
      V.fit(model.worldBounds(frame), 80, 4);
      O.toast('Імпортовано з Photoshop: шарів {n}', { n: layers });
    } catch (e) {
      console.warn(e);
      O.toast('Не вдалося відкрити PSD: {msg}', { msg: e.message });
    }
  };
  X.exportPSD = async () => {
    try {
      await O.loadScript('vendor/ag-psd.js');
      const sel = O.topSel();
      const frame = sel.length === 1 && sel[0].type === 'frame' ? sel[0] : (!sel.length ? model.page().children.find(n => n.type === 'frame' && n.visible !== false) : null);
      const items = frame ? frame.children.filter(n => n.visible !== false) : (sel.length ? sel : model.page().children.filter(n => n.visible !== false));
      if (!items.length && !frame) return O.toast('Немає що експортувати');
      const area = frame ? model.worldBounds(frame) : model.selBounds(items);
      const W = Math.max(1, Math.ceil(area.w)), H = Math.max(1, Math.ceil(area.h));
      const layers = [];
      if (frame && (frame.fills || []).some(f => f.visible !== false)) {
        const bg = Object.assign({}, frame, { children: [], effects: [] });
        const { canvas } = await O.io.renderImage([bg], { scale: 1, type: 'image/png' });
        layers.push({ name: t('Тло'), left: 0, top: 0, canvas });
      }
      for (const n of items) {
        const { canvas, bounds } = await O.io.renderImage([Object.assign({}, n, { opacity: 1, blend: 'normal' })], { scale: 1, type: 'image/png' });
        layers.push({ name: n.name, left: Math.round(bounds.x - area.x), top: Math.round(bounds.y - area.y), canvas, opacity: n.opacity === undefined ? 1 : n.opacity, blendMode: TO_PS[n.blend] || 'normal' });
      }
      const { canvas: comp } = await O.io.renderImage(frame ? [frame] : items, { scale: 1, type: 'image/png' });
      const buf = window.agPsd.writePsd({ width: W, height: H, canvas: comp, children: layers }, { generateThumbnail: true });
      O.download(new Blob([buf], { type: 'image/vnd.adobe.photoshop' }), String((frame || items[0]).name || S.doc.name).replace(/[\\/:*?"<>|]+/g, '_') + '.psd');
      O.toast('Експортовано PSD: шарів {n}', { n: layers.length });
    } catch (e) {
      console.warn(e);
      O.toast('Помилка експорту: {msg}', { msg: e.message });
    }
  };
  O.io.openHooks.push({ test: f => /\.psd$/i.test(f.name || ''), open: (f, at) => X.importPSD(f, at) });
  O.io.openHooks.push({ test: f => /\.fig$/i.test(f.name || ''), open: f => X.importFigFile(f) });

  // ---------- commands ----------
  O.cmd('importPSD', 'Імпортувати PSD (Photoshop)…', async () => { const f = await O.io.pickFiles('.psd'); if (f[0]) X.importPSD(f[0]); }, { group: 'Файл' });
  O.cmd('exportPSD', 'Експорт PSD (Photoshop)', () => X.exportPSD(), { group: 'Файл' });
  O.cmd('importFig', 'Імпортувати файл Figma (.fig)…', async () => { const f = await O.io.pickFiles('.fig'); if (f[0]) X.importFigFile(f[0]); }, { group: 'Файл' });
  O.cmd('transferHelp', 'Як перенести з Figma, Photoshop, Illustrator', () => O.ui.alert('Перенесення з інших програм', [
    `<p><b>Figma.</b> ${O.esc(t('Виділіть шари й натисніть Ctrl+C, потім Ctrl+V тут. Якщо щось не перенеслося, у Figma: правий клік → Copy/Paste as → Copy as SVG. Файли .fig відкриваються через «Імпортувати файл Figma».'))}</p>`,
    `<p><b>Illustrator.</b> ${O.esc(t('Виділіть об’єкти, Ctrl+C, потім Ctrl+V тут: Illustrator кладе в буфер SVG. Також можна зберегти файл як SVG і перетягнути його у вікно.'))}</p>`,
    `<p><b>Photoshop.</b> ${O.esc(t('Ctrl+C у Photoshop вставляє зображення. Щоб перенести всі шари, відкрийте файл .psd: Файл → Імпортувати PSD або просто перетягніть його у вікно.'))}</p>`
  ].join('')), { group: 'Довідка' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл')[1];
  fileMenu.splice(fileMenu.indexOf('importSVG') + 1, 0, 'importPSD', 'importFig');
  const exportSub = fileMenu.find(x => x && x.items && x.label === 'Швидкий експорт');
  if (exportSub) exportSub.items.push('exportPSD');
  O.MENUS.find(m => m[0] === 'Довідка')[1].push('transferHelp');
})();
