'use strict';
/* VIBSma — 100 track templates for the music studio: 20 genres × 5 variants (key, tempo, groove).
   Each template is a complete arrangement: drum channels, bass, chords and a lead (or arpeggio) with their own
   sounds, two patterns (verse and chorus, 4 bars each), a song in the playlist and mixer effects. Everything stays
   editable in the Channel Rack, piano roll, playlist and mixer. */
(function () {
  const O = window.O, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const ST = O.studio;
  if (!ST || !ST.ch) return;
  const SCALES = { minor: [0, 2, 3, 5, 7, 8, 10], major: [0, 2, 4, 5, 7, 9, 11], dorian: [0, 2, 3, 5, 7, 9, 10], phrygian: [0, 1, 3, 5, 7, 8, 10], mixolydian: [0, 2, 4, 5, 7, 9, 10] };
  const KEYS = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  // drums: 16 steps per bar, x = hit, o = soft hit
  const g = (name, bpm, swing, scale, prog, drums, bass, chords, lead, extra = {}) => Object.assign({ name, bpm, swing, scale, prog, drums, bass, chords, lead }, extra);
  const GENRES = [
    g('Хіп-хоп (бум-бап)', 90, 30, 'minor', [0, 5, 3, 4], { kick: ['x.......x.x.....', 'x......xx.x.....'], snare: ['....x.......x...'], hat: ['x.x.x.x.x.x.x.x.', 'x.xox.x.x.xox.x.'] }, ['Square Bass', 'x.....x...x.....'], ['Pluck', '..x.....x.......'], ['Bell', 'riff']),
    g('Трап', 140, 0, 'phrygian', [0, 5, 6, 0], { kick: ['x.........x.....', 'x......x..x.....'], clap: ['........x.......'], hat: ['xxxxxxxxxxxxxxxx', 'x.xxx.x.xxxxx.x.'], ohat: ['......x.........'] }, ['808', 'x.........x...x.'], ['Soft Pad', 'pad'], ['Bell', 'sparse']),
    g('Lo-fi', 80, 40, 'dorian', [1, 4, 0, 5], { kick: ['x......x..x.....', 'x.......x.x....x'], snare: ['....x.......x...'], hat: ['x.o.x.o.x.o.x.o.'], rim: ['..........x.....'] }, ['Sub Bass', 'x.......x...x...'], ['Soft Pad', 'pad'], ['Pluck', 'sparse']),
    g('Хаус', 124, 0, 'minor', [0, 5, 2, 6], { kick: ['x...x...x...x...'], clap: ['....x.......x...'], ohat: ['..x...x...x...x.'], hat: ['x.x.x.x.x.x.x.x.'] }, ['Square Bass', '..x...x...x...x.'], ['Organ', '...x..x....x..x.'], ['Pluck', 'arp']),
    g('Дип-хаус', 120, 10, 'minor', [0, 3, 5, 4], { kick: ['x...x...x...x...'], clap: ['....x.......x...'], hat: ['..x...x...x...x.'], perc: ['.......x.......x'] }, ['Sub Bass', 'x..x..x...x..x..'], ['Soft Pad', 'pad'], ['Bell', 'riff']),
    g('Техно', 130, 0, 'minor', [0, 0, 5, 6], { kick: ['x...x...x...x...'], hat: ['..x...x...x...x.'], clap: ['....x.......x...'], perc: ['x..x..x..x..x...'] }, ['Sub Bass', '.xxx.xxx.xxx.xxx'], ['Saw Lead', 'stab'], ['Saw Lead', 'arp']),
    g('Драм-н-бейс', 174, 0, 'minor', [0, 5, 3, 6], { kick: ['x.........x.....', 'x.........xx....'], snare: ['....x.......x...'], hat: ['x.xxx.xxx.xxx.xx'] }, ['Square Bass', 'x.......x.x.....'], ['Soft Pad', 'pad'], ['Bell', 'riff']),
    g('Дабстеп', 140, 0, 'minor', [0, 5, 6, 4], { kick: ['x.........x.....'], snare: ['........x.......'], hat: ['x.x.x.x.x.x.x.x.'], crash: ['x...............'] }, ['Supersaw', 'x.x.xx..x.x.x...'], ['Soft Pad', 'pad'], ['Saw Lead', 'sparse']),
    g('Реггетон', 95, 0, 'minor', [0, 5, 2, 6], { kick: ['x...x...x...x...'], snare: ['...x..x....x..x.'], hat: ['x.x.x.x.x.x.x.x.'] }, ['Sub Bass', 'x...x...x...x...'], ['Pluck', '...x..x....x..x.'], ['Saw Lead', 'riff']),
    g('Афробіт', 105, 15, 'major', [0, 3, 4, 3], { kick: ['x.....x...x.....'], rim: ['..x..x....x..x..'], hat: ['xoxoxoxoxoxoxoxo'], perc: ['x..x..x...x.x...'] }, ['Square Bass', 'x..x...x..x.....'], ['Organ', '..x...x...x...x.'], ['Pluck', 'riff']),
    g('Поп', 118, 0, 'major', [0, 4, 5, 3], { kick: ['x.......x.......', 'x.......x.x.....'], clap: ['....x.......x...'], hat: ['x.x.x.x.x.x.x.x.'] }, ['Square Bass', 'x.x.x.x.x.x.x.x.'], ['Supersaw', 'pad'], ['Saw Lead', 'riff']),
    g('Синтвейв', 100, 0, 'minor', [0, 5, 2, 6], { kick: ['x.......x.......'], snare: ['....x.......x...'], hat: ['xxxxxxxxxxxxxxxx'] }, ['Square Bass', 'xxxxxxxxxxxxxxxx'], ['Supersaw', 'pad'], ['Saw Lead', 'riff']),
    g('Фанк', 104, 20, 'dorian', [0, 3, 0, 4], { kick: ['x..x..x...x.....'], snare: ['....x..x.x..x...'], hat: ['xxxxxxxxxxxxxxxx'] }, ['Square Bass', 'x..x.x..x.xx..x.'], ['Organ', '.x..x..x.x..x...'], ['Pluck', 'riff']),
    g('Диско', 120, 0, 'major', [0, 5, 3, 4], { kick: ['x...x...x...x...'], ohat: ['..x...x...x...x.'], clap: ['....x.......x...'] }, ['Square Bass', 'x.x.x.x.x.x.x.x.'], ['Organ', 'pad'], ['Bell', 'arp']),
    g('Рок-біт', 120, 0, 'major', [0, 4, 5, 3], { kick: ['x.....x.x.......'], snare: ['....x.......x...'], hat: ['x.x.x.x.x.x.x.x.'], crash: ['x...............'] }, ['Square Bass', 'x.x.x.x.x.x.x.x.'], ['Supersaw', 'x.......x.......'], ['Saw Lead', 'riff']),
    g('Ембієнт', 70, 0, 'major', [0, 3, 5, 4], { kick: ['x...............'], perc: ['........x.......'] }, ['Sub Bass', 'x...............'], ['Soft Pad', 'pad'], ['Bell', 'sparse']),
    g('Чилаут', 95, 10, 'major', [0, 5, 3, 4], { kick: ['x.......x..x....'], rim: ['....x.......x...'], hat: ['x.o.x.o.x.o.x.o.'] }, ['Sub Bass', 'x.......x...x...'], ['Soft Pad', 'pad'], ['Pluck', 'arp']),
    g('Джаз-хоп', 88, 45, 'dorian', [1, 4, 0, 5], { kick: ['x......x..x.....'], snare: ['....x.......x...'], hat: ['x.xox.x.x.xox.x.'] }, ['Sub Bass', 'x.....x.x.......'], ['Organ', 'pad7'], ['Bell', 'riff']),
    g('UK Garage', 132, 35, 'minor', [0, 6, 5, 4], { kick: ['x.....x...x.....'], snare: ['....x.......x...'], hat: ['..x.x...x.x..xx.'] }, ['Sub Bass', 'x..x....x.x.....'], ['Organ', '..x..x....x..x..'], ['Pluck', 'riff']),
    g('Дрил', 142, 0, 'minor', [0, 5, 0, 6], { kick: ['x......x..x.....'], snare: ['......x.......x.'], hat: ['x..x..x.x..x..x.'] }, ['808', 'x......x..x.....'], ['Soft Pad', 'pad'], ['Bell', 'sparse'])
  ];
  const ROOTS = [0, 2, 5, 7, 9], TEMPO = [0, -4, 4, -2, 2];
  ST.TEMPLATES = [];
  GENRES.forEach((G, gi) => { for (let v = 0; v < 5; v++) ST.TEMPLATES.push({ id: 'g' + gi + 'v' + v, gi, v, name: G.name, key: KEYS[ROOTS[v] % 12] + (G.scale === 'major' || G.scale === 'mixolydian' ? '' : 'm'), bpm: G.bpm + TEMPO[v] }); });

  const rng = seed => { let s = (seed * 2654435761) >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; };
  const steps = (str, bars, fillStr) => { const out = []; for (let b = 0; b < bars; b++) { const s = (b === bars - 1 && fillStr) ? fillStr : str; for (const ch of s) out.push(ch === 'x' ? 1 : ch === 'o' ? 0.55 : 0); } return out; };
  const DRUM_NAMES = { kick: 'Kick', snare: 'Snare', clap: 'Clap', hat: 'Hi-hat', ohat: 'Open hat', tom: 'Tom', '808': '808 Bass', rim: 'Rim', cowbell: 'Cowbell', crash: 'Crash', perc: 'Perc' };
  const MIX = (type, p) => Object.assign({ type, on: true }, O.clone(ST.FXDEF[type].p), p || {});

  ST.buildTemplate = id => {
    const tp = ST.TEMPLATES.find(x => x.id === id);
    const G = GENRES[tp.gi], v = tp.v, root = ROOTS[v], sc = SCALES[G.scale], R = rng(tp.gi * 13 + v + 1);
    const note = (deg, oct) => 12 * (oct + 1) + root + sc[((deg % 7) + 7) % 7] + 12 * Math.floor(deg / 7);
    const COL = ST.COLORS;
    const chans = [];
    let mix = 1;
    // drums: each sound on its own channel, all on mixer insert 1 (drum bus)
    for (const [kind, pats] of Object.entries(G.drums)) chans.push(ST.ch(DRUM_NAMES[kind] || kind, 'drum', { drum: { kind, pitch: 0, decay: kind === '808' ? 1.3 : 1, tone: 0.5 }, mixer: 1, color: COL[chans.length % COL.length], _pats: pats }));
    const bassIs808 = G.bass[0] === '808';
    const bass = bassIs808 ? ST.ch('808 Bass', 'drum', { drum: { kind: '808', pitch: 0, decay: 1.4, tone: 0.35 }, mixer: 2, color: COL[5] }) : ST.ch(t('Бас'), 'synth', { synth: O.clone(ST.SYNTHS[G.bass[0]]), mixer: 2, color: COL[5], vol: 0.75 });
    const chords = ST.ch(t('Акорди'), 'synth', { synth: O.clone(ST.SYNTHS[G.chords[0]]), mixer: 3, color: COL[6], vol: 0.55 });
    const lead = ST.ch(t('Мелодія'), 'synth', { synth: O.clone(ST.SYNTHS[G.lead[0]]), mixer: 4, color: COL[4], vol: 0.6 });
    chans.push(bass, chords, lead);
    mix = 4;
    const BARS = 4, LEN = 16 * BARS;
    const mkPattern = (name, chorus) => {
      const p = { id: O.uid(), name, len: LEN, steps: {}, notes: {} };
      for (const c of chans) if (c._pats) {
        const pats = c._pats, s = pats[(v + (chorus ? 1 : 0)) % pats.length];
        // a fill in the last bar of the chorus: busier hats / extra kick
        const fill = chorus && /hat|snare/.test(c.drum.kind) ? s.replace(/\./g, (m, i) => (i > 11 && i % 2 === 0 ? 'o' : m)) : null;
        p.steps[c.id] = steps(s, BARS, fill);
      }
      // bass: the chord root on the genre's rhythm, held until the next hit
      if (bassIs808) p.steps[bass.id] = steps(G.bass[1], BARS);
      else {
        const hits = []; for (let i = 0; i < 16; i++) if (G.bass[1][i] === 'x') hits.push(i);
        p.notes[bass.id] = [];
        for (let b = 0; b < BARS; b++) hits.forEach((h, k) => { const nx = k < hits.length - 1 ? hits[k + 1] : 16; p.notes[bass.id].push({ p: note(G.prog[b], 2) + (G.bass[1] === 'xxxxxxxxxxxxxxxx' && h % 2 ? 12 : 0), s: b * 16 + h, l: Math.max(1, nx - h), v: 0.85 }); });
      }
      // chords: triads (or 7ths) as a pad or rhythmic stabs
      const style = G.chords[1];
      p.notes[chords.id] = [];
      for (let b = 0; b < BARS; b++) {
        const d = G.prog[b], tones = [note(d, 4), note(d + 2, 4), note(d + 4, 4)].concat(style === 'pad7' ? [note(d + 6, 4)] : []);
        if (style === 'pad' || style === 'pad7') tones.forEach(n => p.notes[chords.id].push({ p: n, s: b * 16, l: 16, v: 0.6 }));
        else if (style === 'stab') [0, 6, 10].forEach(h => tones.forEach(n => p.notes[chords.id].push({ p: n, s: b * 16 + h, l: 2, v: 0.6 })));
        else for (let i = 0; i < 16; i++) if (style[i] === 'x') tones.forEach(n => p.notes[chords.id].push({ p: n, s: b * 16 + i, l: 2, v: 0.6 }));
      }
      // lead: in the chorus — a riff, an arpeggio or a few sparse bell notes, from the chord tones
      p.notes[lead.id] = [];
      if (chorus) {
        const mode = G.lead[1];
        for (let b = 0; b < BARS; b++) {
          const d = G.prog[b], tones = [0, 2, 4, 7].map(x => note(d + x, 5));
          if (mode === 'arp') for (let i = 0; i < 16; i++) p.notes[lead.id].push({ p: tones[i % 4], s: b * 16 + i, l: 1, v: 0.55 + (i % 4 === 0 ? 0.2 : 0) });
          else if (mode === 'sparse') [0, 6, 10].forEach((h, k) => { if (R() > 0.25) p.notes[lead.id].push({ p: tones[Math.floor(R() * 4)], s: b * 16 + h, l: 4 + k, v: 0.6 }); });
          else { let i = 0; while (i < 16) { const l = [1, 2, 2, 3, 4][Math.floor(R() * 5)]; if (R() > 0.2) p.notes[lead.id].push({ p: R() > 0.3 ? tones[Math.floor(R() * 3)] : note(d + 1 + Math.floor(R() * 5), 5), s: b * 16 + i, l: Math.min(l, 16 - i), v: 0.7 }); i += l; } }
        }
      }
      return p;
    };
    const verse = mkPattern(t('Куплет'), false), chorus = mkPattern(t('Приспів'), true);
    chans.forEach(c => { delete c._pats; });
    const mixer = [{ id: 'm0', name: 'Master', vol: 0.85, pan: 0, mute: false, solo: false, fx: [MIX('comp', { thr: -14, ratio: 2, gain: 2 }), MIX('limiter')] }];
    for (let i = 1; i <= 8; i++) mixer.push({ id: 'm' + i, name: t('Інсерт {n}', { n: i }), vol: 0.8, pan: 0, mute: false, solo: false, fx: [] });
    mixer[1].name = t('Ударні'); mixer[1].fx = [MIX('comp', { thr: -18, ratio: 4 }), MIX('eq', { low: 2, mid: -1, high: 1 })];
    mixer[2].name = t('Бас'); mixer[2].fx = [MIX('filter', { type: 'lowpass', freq: 3500 })];
    mixer[3].name = t('Акорди'); mixer[3].fx = [MIX('reverb', { size: 3, mix: 0.35 }), MIX('chorus')];
    mixer[4].name = t('Мелодія'); mixer[4].fx = [MIX('delay', { time: 60 / tp.bpm * 0.75, fb: 0.3, mix: 0.22 }), MIX('reverb', { size: 2, mix: 0.25 })];
    void mix;
    const tracks = Array.from({ length: 8 }, (_, i) => ({ id: O.uid(), name: t('Доріжка {n}', { n: i + 1 }), mute: false }));
    const order = [verse, verse, chorus, chorus, verse, chorus];
    const clips = order.map((p, i) => ({ id: O.uid(), track: tracks[0].id, kind: 'pattern', ref: p.id, start: i * LEN, len: LEN }));
    return { bpm: tp.bpm, swing: G.swing, metro: false, mode: 'song', pattern: chorus.id, channels: chans, patterns: [verse, chorus], playlist: { tracks, clips }, mixer, template: tp.id };
  };
  ST.applyTemplate = (id, play) => {
    const tp = ST.TEMPLATES.find(x => x.id === id);
    ST.load(ST.buildTemplate(id));
    O.toast('Шаблон треку «{name}» · {key} · {bpm} BPM', { name: t(tp.name), key: tp.key, bpm: tp.bpm });
    if (play && ST.play) setTimeout(() => ST.play(), 150);
  };

  // ---------- dialog inside the studio ----------
  ST.templatesDialog = () => {
    const root = O.$('.st-root');
    if (!root || root.querySelector('.at-back')) return;
    const back = O.h(`<div class="at-back"><div class="at" role="dialog" aria-label="${esc(t('Шаблони треків'))}"><div class="at-h"><b>🎼 ${esc(t('Шаблони треків'))}</b><span>${esc(t('{n} шаблонів: 20 жанрів × 5 варіантів. Клік — завантажити й відтворити.', { n: ST.TEMPLATES.length }))}</span><span class="sp"></span><button type="button" class="btn" data-at="close">✕</button></div>
      <div class="at-list">${GENRES.map((G, gi) => `<div class="at-g"><b>${esc(t(G.name))}</b><div class="at-vs">${ST.TEMPLATES.filter(x => x.gi === gi).map(x => `<button type="button" data-atp="${x.id}" class="${(O.state.doc.studio || {}).template === x.id ? 'on' : ''}"><span>${esc(x.key)}</span><em>${x.bpm} BPM</em></button>`).join('')}</div></div>`).join('')}</div></div></div>`);
    root.appendChild(back);
    back.addEventListener('click', e => {
      if (e.target === back || e.target.closest('[data-at="close"]')) return back.remove();
      const b = e.target.closest('[data-atp]');
      if (!b) return;
      back.querySelectorAll('[data-atp]').forEach(x => x.classList.toggle('on', x === b));
      ST.applyTemplate(b.dataset.atp, true);
    });
  };
  O.cmd('audioTemplates', 'Шаблони треків…', () => { if (O.setMode) O.setMode('music'); else ST.open(); setTimeout(() => ST.templatesDialog(), 60); }, { group: 'Медіа' });
  const media = O.MENUS.find(m => m[0] === 'Медіа');
  if (media) media[1].push('audioTemplates');
})();
