'use strict';
/* VIBSma — Liquid Glass effect (Apple style): the content under a shape is blurred, saturated and
   refracted at the edges like a thick glass lens, then tinted by the shape's fills and lit by a specular rim.
   Rendered in plain SVG (displacement map + filters), so it shows on the canvas and in PNG / SVG / PDF export;
   the HTML export uses backdrop-filter. */
(function () {
  const O = window.O, M = O.M, R = O.R, model = O.model, S = O.state;
  const n_ = O.n, esc = O.esc, t = (s, v) => O.t(s, v);
  const GL = O.glass = {};
  // rimColor / rimColor2: the light on the top-left and bottom-right edges; rim: its width (0 = automatic);
  // rainbow: a spectral rim; sheen: gloss from the top; tint / tintOp: colour of the glass itself
  GL.DEFAULT = { type: 'glass', visible: true, blur: 8, refract: 36, depth: 22, light: 0.7, sat: 1.6, x: 0, y: 0, color: '#FFFFFF', opacity: 0.15, rimColor: '#FFFFFF', rimColor2: '#FFFFFF', rim: 0, rainbow: false, sheen: 0.15, tint: '#FFFFFF', tintOp: 0 };
  // ready-made looks (Liquid Glass dialog)
  GL.PRESETS = [
    ['clear', 'Прозоре (iOS)', { blur: 4, refract: 40, depth: 24, light: 0.75, sat: 1.7, rimColor: '#FFFFFF', rimColor2: '#FFFFFF', rainbow: false, sheen: 0.15, tintOp: 0 }],
    ['frosted', 'Матове', { blur: 22, refract: 18, depth: 18, light: 0.55, sat: 1.3, rimColor: '#FFFFFF', rimColor2: '#FFFFFF', rainbow: false, sheen: 0.2, tint: '#FFFFFF', tintOp: 0.18 }],
    ['tinted', 'Тоноване', { blur: 10, refract: 30, depth: 22, light: 0.6, sat: 1.8, rimColor: '#BFE3FF', rimColor2: '#6FB8FF', rainbow: false, sheen: 0.12, tint: '#2E8BFF', tintOp: 0.22 }],
    ['dark', 'Темне', { blur: 14, refract: 26, depth: 20, light: 0.35, sat: 1.2, rimColor: '#FFFFFF', rimColor2: '#7A7A88', rainbow: false, sheen: 0.06, tint: '#0B0B10', tintOp: 0.45 }],
    ['gold', 'Золоте', { blur: 8, refract: 34, depth: 22, light: 0.8, sat: 1.4, rimColor: '#FFE7A3', rimColor2: '#C9902B', rainbow: false, sheen: 0.18, tint: '#F5C451', tintOp: 0.14 }],
    ['rainbow', 'Райдужне', { blur: 6, refract: 46, depth: 26, light: 0.85, sat: 1.9, rainbow: true, sheen: 0.16, tintOp: 0 }],
    ['crystal', 'Кришталь', { blur: 0, refract: 64, depth: 34, light: 0.95, sat: 2, rimColor: '#FFFFFF', rimColor2: '#DDEBFF', rainbow: false, sheen: 0.24, tintOp: 0 }]
  ];
  const SHAPES = new Set(['rect', 'frame', 'instance', 'ellipse', 'polygon', 'star', 'path', 'bool']);

  // displacement map: R / G = outward normal × lens strength near the edge, 128 = no shift
  const maps = new Map();
  GL.map = (w, h, r, depth, ellipse) => {
    const key = [Math.round(w), Math.round(h), Math.round(r), Math.round(depth), ellipse ? 1 : 0].join('|');
    if (maps.has(key)) return maps.get(key);
    const k = Math.min(1, 256 / Math.max(w, h, 1));
    const cw = Math.max(2, Math.round(w * k)), ch = Math.max(2, Math.round(h * k));
    const cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
    const c = cv.getContext('2d');
    const img = c.createImageData(cw, ch), d = img.data;
    const hw = w / 2, hh = h / 2, rr = Math.max(0, Math.min(r, hw, hh));
    const dep = Math.max(1, depth);
    for (let py = 0; py < ch; py++) {
      for (let px = 0; px < cw; px++) {
        const x = (px + 0.5) / k - hw, y = (py + 0.5) / k - hh;
        let dist, nx, ny;
        if (ellipse) {
          const ex = x / hw, ey = y / hh, rad = Math.hypot(ex, ey) || 1e-6;
          dist = (1 - rad) * Math.min(hw, hh);
          const gx = x / (hw * hw), gy = y / (hh * hh), gl = Math.hypot(gx, gy) || 1;
          nx = gx / gl; ny = gy / gl;
        } else {
          const qx = Math.abs(x) - (hw - rr), qy = Math.abs(y) - (hh - rr);
          if (qx > 0 && qy > 0) { const l = Math.hypot(qx, qy) || 1; dist = rr - l; nx = qx / l; ny = qy / l; }
          else if (qx > qy) { dist = rr - qx; nx = 1; ny = 0; }
          else { dist = rr - qy; nx = 0; ny = 1; }
          nx *= Math.sign(x) || 1; ny *= Math.sign(y) || 1;
        }
        const s = dist >= 0 && dist < dep ? Math.pow(1 - dist / dep, 2) : 0;
        const i = (py * cw + px) * 4;
        d[i] = Math.round(128 + nx * s * 127); d[i + 1] = Math.round(128 + ny * s * 127); d[i + 2] = 128; d[i + 3] = 255;
      }
    }
    c.putImageData(img, 0, 0);
    const url = cv.toDataURL('image/png');
    maps.set(key, url);
    if (maps.size > 80) maps.delete(maps.keys().next().value);
    return url;
  };

  // everything painted before n, in world coordinates (siblings below it, then up the tree)
  const backdrop = (n, sub) => {
    const parts = [];
    let child = n, parent = model.parent(n);
    while (parent) {
      const isPg = model.isPage(parent);
      const below = parent.children.slice(0, parent.children.indexOf(child)).filter(c => c.visible !== false);
      const P = isPg ? M.id() : model.worldMatrix(parent);
      const own = below.map(c => O.render.nodeMarkup(c, sub)).join('');
      if (own) parts.unshift(M.isId(P) ? own : `<g transform="${M.str(P)}">${own}</g>`);
      if (isPg) { if (parent.bg) parts.unshift(`<rect x="-100000" y="-100000" width="200000" height="200000" fill="${parent.bg}"/>`); break; }
      if (parent.type === 'frame') {
        // the frame's own background (without children or effects)
        const bare = Object.assign({}, parent, { children: [], effects: [], m: M.id(), strokes: [] });
        parts.unshift(`<g transform="${M.str(P)}">${O.render.nodeMarkup(bare, sub)}</g>`);
      }
      child = parent; parent = model.parent(parent);
    }
    return parts.join('');
  };

  O.render.fxHooks.push((n, ctx) => {
    const g = (n.effects || []).find(e => e.type === 'glass' && e.visible !== false);
    if (!g || ctx.ghost || !SHAPES.has(n.type) || !model.exists(n.id)) return null;
    const geo = O.geo(n);
    if (!geo) return null;
    const b = model.localBounds(n);
    if (b.w < 1 || b.h < 1) return null;
    const id = ctx.pfx + 'lg' + n.id;
    const sub = Object.assign({}, ctx, { ghost: true, hit: false, pfx: ctx.pfx + 'lg' + n.id + '_', defs: ctx.defs });
    let back = '';
    // inside component instances the tree position is the component's, not the instance's: no backdrop there
    if (!ctx.depth) { try { back = backdrop(n, sub); } catch (e) { console.warn(e); } }
    const blur = Math.max(0, g.blur || 0), refr = g.refract === undefined ? 36 : g.refract, depth = Math.max(1, g.depth || 22);
    const light = g.light === undefined ? 0.7 : g.light, sat = g.sat === undefined ? 1.6 : g.sat;
    const r = Array.isArray(n.radius) ? n.radius[0] : (n.radius || 0);
    const map = GL.map(b.w, b.h, n.type === 'ellipse' ? 0 : r, depth, n.type === 'ellipse');
    const pad = blur * 3 + Math.abs(refr) + 8;
    const inv = M.inv(model.worldMatrix(n));
    ctx.defs.push(`<clipPath id="${id}c"><${geo.tag} ${geo.attrs}/></clipPath>`);
    ctx.defs.push(`<filter id="${id}f" filterUnits="userSpaceOnUse" x="${n_(b.x - pad)}" y="${n_(b.y - pad)}" width="${n_(b.w + 2 * pad)}" height="${n_(b.h + 2 * pad)}" color-interpolation-filters="sRGB">` +
      `<feGaussianBlur in="SourceGraphic" stdDeviation="${n_(blur / 2)}" result="b"/>` +
      `<feImage href="${map}" xlink:href="${map}" x="${n_(b.x)}" y="${n_(b.y)}" width="${n_(b.w)}" height="${n_(b.h)}" preserveAspectRatio="none" result="m"/>` +
      `<feDisplacementMap in="b" in2="m" scale="${n_(refr)}" xChannelSelector="R" yChannelSelector="G" result="d"/>` +
      `<feColorMatrix in="d" type="saturate" values="${n_(sat)}"/></filter>`);
    // specular rim: bright top-left and bottom-right edges (their colours can be set), plus a soft sheen from the top
    const c1 = esc(g.rimColor || '#FFFFFF'), c2 = esc(g.rimColor2 || g.rimColor || '#FFFFFF');
    const rimStops = g.rainbow
      ? ['#FF5A5A', '#FFB84D', '#FFF36B', '#5BFF8C', '#4DD8FF', '#6B7BFF', '#E46BFF'].map((c, k, a) => `<stop offset="${n_(k / (a.length - 1))}" stop-color="${c}" stop-opacity="${n_(light * (k % 3 === 1 ? 0.55 : 0.9))}"/>`).join('')
      : `<stop offset="0" stop-color="${c1}" stop-opacity="${n_(light)}"/><stop offset=".32" stop-color="${c1}" stop-opacity="0"/><stop offset=".7" stop-color="${c2}" stop-opacity="0"/><stop offset="1" stop-color="${c2}" stop-opacity="${n_(light * 0.55)}"/>`;
    ctx.defs.push(`<linearGradient id="${id}r" x1="0" y1="0" x2="1" y2="1">${rimStops}</linearGradient>`);
    const sheen = g.sheen === undefined ? light * 0.22 : Math.max(0, g.sheen);
    ctx.defs.push(`<linearGradient id="${id}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="${n_(Math.min(1, sheen))}"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/></linearGradient>`);
    const rim = g.rim > 0 ? g.rim : Math.max(1, Math.min(b.w, b.h) / 60);
    const tint = g.tintOp > 0 ? `<${geo.tag} ${geo.attrs} fill="${esc(g.tint || '#FFFFFF')}" fill-opacity="${n_(Math.min(1, g.tintOp))}"/>` : '';
    const pre = `<g clip-path="url(#${id}c)" pointer-events="none"><g filter="url(#${id}f)"><g transform="${M.str(inv)}">${back}</g></g>${tint}</g>`;
    const post = `<g pointer-events="none" clip-path="url(#${id}c)"><${geo.tag} ${geo.attrs} fill="url(#${id}s)"/><${geo.tag} ${geo.attrs} fill="none" stroke="url(#${id}r)" stroke-width="${n_(rim * 2)}"/></g>`;
    return { pre, post };
  });

  // apply to the selection: a light tint so the glass reads on any background
  GL.apply = () => {
    const ns = O.topSel().filter(n => SHAPES.has(n.type));
    if (!ns.length) return O.toast('Виділіть прямокутник, еліпс, фрейм або контур');
    ns.forEach(n => {
      n.effects = (n.effects || []).filter(e => e.type !== 'glass');
      n.effects.unshift(Object.assign({}, GL.DEFAULT));
      if (!n.effects.some(e => e.type === 'shadow')) n.effects.push({ type: 'shadow', x: 0, y: 8, blur: 24, spread: 0, color: '#000000', opacity: 0.18, visible: true });
      const solid = (n.fills || []).filter(f => f.visible !== false);
      if (!solid.length || solid.every(f => f.type === 'solid' && (f.opacity === undefined || f.opacity > 0.5))) n.fills = [O.paint.solid('#FFFFFF', 0.12)];
      if ((n.type === 'rect' || n.type === 'frame') && !n.radius) n.radius = Math.round(Math.min(n.w, n.h) * 0.22);
    });
    O.history.commit('Liquid Glass');
  };
  // ready-made glass panel over whatever is under the view centre
  GL.panel = () => {
    const V = O.view, c = R.center(V.viewRect());
    const cont = V.containerAt(c);
    const lp = M.apply(M.inv(model.containerMatrix(cont)), c);
    const n = model.create('rect', { name: 'Liquid Glass', w: 320, h: 120, radius: 36, m: M.translate(Math.round(lp.x - 160), Math.round(lp.y - 60)), fills: [O.paint.solid('#FFFFFF', 0.12)], effects: [Object.assign({}, GL.DEFAULT), { type: 'shadow', x: 0, y: 8, blur: 24, spread: 0, color: '#000000', opacity: 0.18, visible: true }] });
    model.insert(n, cont);
    O.select([n.id]);
    O.history.commit('Liquid Glass');
  };
  // every setting in one dialog, with ready-made looks and a live preview
  GL.dialog = () => {
    let ns = O.topSel().filter(n => SHAPES.has(n.type));
    if (!ns.length) return O.toast('Виділіть прямокутник, еліпс, фрейм або контур');
    const cur = Object.assign({}, GL.DEFAULT, ((ns[0].effects || []).find(e => e.type === 'glass')) || {});
    const pct = v => Math.round((v || 0) * 100);
    const col = (k, label) => ({ key: k, type: 'html', html: `<label class="dlg-row"><span>${esc(t(label))}</span><input type="color" data-k="${k}" value="${esc(cur[k] || '#FFFFFF')}"></label>` });
    O.ui.dialog({
      title: 'Liquid Glass',
      preview: true, label: 'Liquid Glass',
      fields: [
        { key: 'preset', label: 'Готовий вигляд', type: 'select', value: '', options: [['', '—']].concat(GL.PRESETS.map(p => [p[0], p[1]])) },
        { key: 'blur', label: 'Матовість (розмиття під склом)', type: 'number', value: cur.blur, min: 0, unit: 'px' },
        { key: 'refract', label: 'Заломлення на краях', type: 'number', value: cur.refract },
        { key: 'depth', label: 'Товщина скла', type: 'number', value: cur.depth, min: 1, unit: 'px' },
        { key: 'sat', label: 'Насиченість під склом', type: 'number', value: pct(cur.sat), min: 0, unit: '%' },
        { key: 'light', label: 'Яскравість контуру', type: 'number', value: pct(cur.light), min: 0, max: 100, unit: '%' },
        col('rimColor', 'Колір контуру зверху зліва'),
        col('rimColor2', 'Колір контуру знизу справа'),
        { key: 'rim', label: 'Товщина контуру (0 — авто)', type: 'number', value: cur.rim || 0, min: 0, unit: 'px' },
        { key: 'rainbow', label: 'Райдужний контур', type: 'checkbox', value: !!cur.rainbow },
        { key: 'sheen', label: 'Глянець зверху', type: 'number', value: pct(cur.sheen), min: 0, max: 100, unit: '%' },
        col('tint', 'Колір скла'),
        { key: 'tintOp', label: 'Сила кольору скла', type: 'number', value: pct(cur.tintOp), min: 0, max: 100, unit: '%' }
      ],
      onOpen: wrap => {
        const sel = wrap.querySelector('[data-k="preset"]');
        sel.addEventListener('change', () => {
          const p = GL.PRESETS.find(x => x[0] === sel.value);
          if (!p) return;
          for (const [k, v] of Object.entries(p[2])) {
            const el = wrap.querySelector(`[data-k="${k}"]`);
            if (!el) continue;
            if (el.type === 'checkbox') el.checked = !!v;
            else el.value = ['sat', 'light', 'sheen', 'tintOp'].includes(k) ? pct(v) : v;
          }
        });
      },
      apply: v => {
        ns = O.topSel().filter(n => SHAPES.has(n.type));
        ns.forEach(n => {
          n.effects = n.effects || [];
          let e = n.effects.find(x => x.type === 'glass');
          if (!e) { e = Object.assign({}, GL.DEFAULT); n.effects.unshift(e); }
          Object.assign(e, {
            blur: Math.max(0, v.blur), refract: v.refract, depth: Math.max(1, v.depth), sat: Math.max(0, v.sat / 100), light: O.clamp(v.light / 100, 0, 1),
            rimColor: O.color.norm(v.rimColor) || '#FFFFFF', rimColor2: O.color.norm(v.rimColor2) || '#FFFFFF', rim: Math.max(0, v.rim), rainbow: !!v.rainbow,
            sheen: O.clamp(v.sheen / 100, 0, 1), tint: O.color.norm(v.tint) || '#FFFFFF', tintOp: O.clamp(v.tintOp / 100, 0, 1), visible: true
          });
        });
      }
    });
  };
  O.cmd('fxGlass', 'Liquid Glass (рідке скло)', () => GL.apply(), { group: 'Ефект' });
  O.cmd('glassPanel', 'Нова панель Liquid Glass', () => GL.panel(), { group: 'Ефект' });
  O.cmd('glassDialog', 'Налаштувати Liquid Glass…', () => GL.dialog(), { group: 'Ефект' });
  const fx = O.MENUS.find(m => m[0] === 'Ефект');
  if (fx) fx[1].splice(fx[1].indexOf('fxBlur') + 1, 0, 'fxGlass', 'glassDialog', 'glassPanel');
})();
