'use strict';
/* VIBSma — built-in self test. Open index.html?selftest to run. */
(function () {
  const O = window.O;
  const errors = [];
  window.addEventListener('error', e => errors.push('onerror: ' + e.message + ' @ ' + String(e.filename || '').split('/').pop() + ':' + e.lineno));
  window.addEventListener('unhandledrejection', e => errors.push('unhandled: ' + ((e.reason && (e.reason.stack || e.reason.message)) || e.reason)));
  const origErr = console.error;
  const short = s => String(s).replace(/file:\/\/\/[^\s)]*\/obrys\//g, '');
  console.error = function (...a) { errors.push(short('console.error: ' + a.map(x => x && x.stack ? x.stack.split('\n').slice(0, 4).join(' | ') : String(x)).join(' '))); origErr.apply(console, a); };

  O.selftest = async () => {
    O.trace = msg => { document.title = document.title.replace(/ \| .*$/, '') + ' | ' + msg; };
    const out = [];
    let fail = 0, pass = 0;
    const { model, M, G, ops, view: V } = O;
    const S = O.state;
    const record = (name, good, info) => { out.push((good ? 'PASS ' : 'FAIL ') + name + (info ? ' — ' + info : '')); if (good) pass++; else fail++; };
    const step = async (name, fn) => {
      const before = errors.length;
      document.title = 'SELFTEST running: ' + name + ' (' + (pass + fail) + ' done, ' + fail + ' failed)';
      try {
        const r = await fn();
        const errs = errors.slice(before);
        if (errs.length) record(name, false, 'errors: ' + errs.join(' || '));
        else record(name, r !== false, typeof r === 'string' ? r : '');
      } catch (e) { record(name, false, e.message + ' :: ' + short(String(e.stack || '').split('\n').slice(1, 3).join(' | '))); }
      O.flushRender();
    };
    const ev = (wx, wy, extra = {}) => {
      const s = V.toScreen({ x: wx, y: wy });
      const r = V.el.getBoundingClientRect();
      return Object.assign({ e: {}, clientX: r.left + s.x, clientY: r.top + s.y, s, p: { x: wx, y: wy }, shift: false, alt: false, ctrl: false, h: null, button: 0 }, extra);
    };
    const drag = (tool, pts, extra) => {
      O.setTool(tool);
      const t = O.tools[tool];
      t.down(ev(pts[0][0], pts[0][1], extra));
      for (const p of pts.slice(1)) if (t.move) t.move(ev(p[0], p[1], extra));
      const l = pts[pts.length - 1];
      if (t.up) t.up(ev(l[0], l[1], extra));
      O.flushRender();
    };
    const line = (a, b, n = 12) => { const o = []; for (let i = 0; i <= n; i++) o.push([a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n]); return o; };
    const count = () => model.page().children.length;
    const mkRect = (x, y, w, h, color) => { const n = model.create('rect', { w, h, m: M.translate(x, y), fills: [O.paint.solid(color || '#3366FF')] }); model.insert(n, model.page()); return n; };
    const geomOK = n => n && n.type === 'path' && n.subpaths.length > 0 && n.subpaths.every(sp => sp.pts.every(p => isFinite(p.x) && isFinite(p.y)));
    const fresh = () => { model.load(model.newDoc()); V.zoom = 1; V.x = 120; V.y = 120; V.apply(); O.setTool('select'); };

    await step('vendor libraries loaded', () => !!(window.paper && window.ClipperLib && window.ImageTracer && window.opentype) ? 'paper ' + window.paper.version : false);
    await step('blank document', () => { fresh(); return count() === 0; });
    await step('rectangle tool (drag)', () => { drag('rect', [[0, 0], [40, 30], [100, 80]]); const n = O.sel()[0]; return n && n.type === 'rect' && Math.abs(n.w - 100) < 0.01 && Math.abs(n.h - 80) < 0.01 ? `${n.w}×${n.h}` : false; });
    await step('ellipse tool (drag, shift)', () => { drag('ellipse', [[60, 20], [120, 70], [160, 100]], { shift: true }); const n = O.sel()[0]; return n && n.type === 'ellipse' && Math.abs(n.w - n.h) < 0.01; });
    await step('render produces SVG nodes', () => O.$$('#doc-root [data-id]').length >= 2 ? O.$$('#doc-root [data-id]').length + ' nodes' : false);
    await step('boolean group (live union)', () => {
      O.select(model.page().children.map(n => n.id));
      const b = ops.boolean('union');
      const r = model.boolResult(b);
      return b && b.type === 'bool' && r.length > 0 && model.localBounds(b).w > 150 ? 'bounds w=' + O.fmt(model.localBounds(b).w) : false;
    });
    await step('undo / redo', () => { O.history.undo(); const a = count(); O.history.redo(); const b = count(); return a === 2 && b === 1 ? '' : false; });
    await step('expand boolean to path', () => { O.select([model.page().children[0].id]); ops.expand(); return geomOK(O.sel()[0]); });
    await step('pathfinder divide', () => {
      fresh(); const a = mkRect(0, 0, 100, 100, '#FF0000'), b = mkRect(50, 50, 100, 100, '#00FF00');
      O.select([a.id, b.id]); ops.pathfinder('divide');
      const g = O.sel()[0];
      return g && g.type === 'group' && g.children.length === 3 ? '3 pieces' : 'pieces=' + (g && g.children && g.children.length) && false;
    });
    for (const k of ['trim', 'merge', 'crop', 'outline', 'minusback']) {
      await step('pathfinder ' + k, () => {
        fresh(); const a = mkRect(0, 0, 100, 100, '#FF0000'), b = mkRect(50, 50, 100, 100, k === 'merge' ? '#FF0000' : '#00FF00');
        O.select([a.id, b.id]); ops.pathfinder(k);
        const g = O.sel()[0];
        return g && g.children && g.children.length >= 1 ? g.children.length + ' result(s)' : false;
      });
    }
    // a pen path with only a stroke used to become an invisible piece that punched a hole in the shape below
    for (const k of ['merge', 'trim']) {
      await step('pathfinder ' + k + ' with a stroke-only path', () => {
        fresh(); const a = mkRect(0, 0, 100, 100, '#D9D9D9');
        const p = model.create('path', { subpaths: [{ closed: true, pts: [G.pt(200, 50), G.pt(50, 50), G.pt(125, 200)] }] }); model.insert(p, model.page());
        O.select([a.id, p.id]); ops.pathfinder(k);
        const g = O.sel()[0], kids = (g && g.children) || [];
        const painted = kids.every(c => c.fills.some(f => f.visible !== false));
        const grey = kids.filter(c => c.fills[0].color === '#D9D9D9').reduce((s, c) => s + Math.abs(G.toPaper(c.subpaths).area), 0);
        const ring = kids.some(c => c.fills[0].color === '#000000');
        return painted && ring && grey > 9800 ? kids.length + ' pieces, grey area ' + Math.round(grey) : 'painted=' + painted + ' ring=' + ring + ' grey=' + Math.round(grey) && false;
      });
    }
    await step('destructive minus front', () => { fresh(); const a = mkRect(0, 0, 100, 100), b = mkRect(50, 50, 100, 100); O.select([a.id, b.id]); const r = ops.boolean('subtract', null, { destructive: true }); return geomOK(r) && Math.abs(Math.abs(G.toPaper(r.subpaths).area) - 7500) < 1 ? 'area 7500' : false; });
    await step('pen tool (corner + smooth + Enter)', () => {
      fresh(); O.setTool('pen'); const t = O.tools.pen;
      t.down(ev(300, 0)); t.up(ev(300, 0));
      t.down(ev(400, 0)); t.move(ev(430, 30)); t.move(ev(450, 50)); t.up(ev(450, 50));
      t.down(ev(500, 100)); t.up(ev(500, 100));
      t.key({ key: 'Enter' });
      const n = model.page().children[0];
      return geomOK(n) && n.subpaths[0].pts.length === 3 && n.subpaths[0].pts[1].o ? '3 anchors, smooth middle' : false;
    });
    await step('pen closes path on first anchor', () => {
      O.setTool('pen'); const t = O.tools.pen; O.select([]);
      t.down(ev(0, 200)); t.up(ev(0, 200)); t.down(ev(100, 200)); t.up(ev(100, 200)); t.down(ev(50, 280)); t.up(ev(50, 280));
      t.down(ev(0, 200)); t.up(ev(0, 200));
      const n = model.page().children[model.page().children.length - 1];
      O.setTool('select');
      return n.subpaths[0].closed && n.subpaths[0].pts.length === 3;
    });
    await step('direct selection moves anchor', () => {
      const n = model.page().children[0];
      O.select([n.id]); S.edit = { id: n.id, sel: new Set(['0:0']) }; O.setTool('direct');
      const t = O.tools.direct, a = n.subpaths[0].pts[0];
      const x0 = a.x;
      t.startDrag(ev(a.x, a.y), n, 'anchors', '0:0'); t.move(ev(a.x + 20, a.y + 10)); t.move(ev(a.x + 30, a.y + 10)); t.up(ev(a.x + 30, a.y + 10));
      const moved = n.subpaths[0].pts[0].x - x0;
      O.setTool('select');
      return Math.abs(moved - 30) < 1 ? 'dx=' + O.fmt(moved) : false;
    });
    await step('pencil tool', () => { fresh(); const pts = []; for (let i = 0; i <= 40; i++) pts.push([i * 5, Math.sin(i / 4) * 30]); drag('pencil', pts); const n = O.sel()[0]; return geomOK(n) && n.subpaths[0].pts.length < 40 ? n.subpaths[0].pts.length + ' anchors after fitting' : false; });
    for (const bt of ['calligraphic', 'taper', 'round']) {
      await step('paintbrush ' + bt, () => {
        O.toolOpts.brushType = bt; const c0 = count();
        const pts = []; for (let i = 0; i <= 40; i++) pts.push([i * 6, 150 + Math.cos(i / 5) * 40]);
        drag('brush', pts); const n = O.sel()[0];
        if (count() !== c0 + 1) throw new Error('no new shape');
        const filled = bt === 'round' ? n.strokes.length && n.sw > 1 : n.fills.length && !n.strokes.length;
        return geomOK(n) && filled ? n.subpaths.length + ' contour(s), ' + n.subpaths[0].pts.length + ' anchors' : false;
      });
    }
    await step('blob brush merges strokes', () => {
      fresh(); drag('blob', line([0, 0], [200, 0])); const first = O.sel()[0].id;
      drag('blob', line([100, -50], [100, 50])); const n = O.sel()[0];
      return geomOK(n) && n.id === first && count() === 1 ? 'merged into one shape' : 'count=' + count() && false;
    });
    await step('eraser cuts shape', () => {
      fresh(); const r = mkRect(0, 0, 200, 100); O.select([]);
      O.view.zoom = 1; O.toolOpts.eraserSize = 20;
      drag('eraser', line([100, -40], [100, 140], 20));
      const n = model.get(r.id);
      return geomOK(n) ? n.subpaths.length + ' contours' : false;
    });
    await step('knife splits shape', () => {
      fresh(); mkRect(0, 0, 200, 100); O.select([]);
      drag('knife', line([100, -40], [100, 140], 20));
      return count() === 2 && model.page().children.every(geomOK) ? '2 pieces' : 'count=' + count() && false;
    });
    await step('scissors cuts open path in two', () => {
      fresh(); const n = model.create('path', { subpaths: [{ closed: false, pts: [G.pt(0, 0), G.pt(200, 0)] }] }); model.insert(n, model.page()); O.select([n.id]);
      O.setTool('scissors'); O.tools.scissors.down(ev(100, 0)); O.setTool('select');
      return count() === 2 ? '' : false;
    });
    await step('text tool + editing', () => {
      fresh(); O.setTool('text'); const t = O.tools.text; t.down(ev(10, 10)); t.up(ev(10, 10));
      const ta = O.$('#text-editor'); ta.value = 'Привіт, VIBSma!'; O.textEdit.input(); O.textEdit.end();
      const n = O.sel()[0];
      return n && n.type === 'text' && n.text === 'Привіт, VIBSma!' && model.localBounds(n).w > 50 ? 'w=' + O.fmt(model.localBounds(n).w) : false;
    });
    await step('area text wraps', () => { const n = model.create('text', { text: 'Дуже довгий текст, який має переноситися на кілька рядків', width: 120 }); model.insert(n, model.page()); return O.text.layout(n).lines.length > 2 ? O.text.layout(n).lines.length + ' lines' : false; });
    await step('text on path', () => {
      const e = model.create('ellipse', { w: 200, h: 200, m: M.translate(300, 0) }); model.insert(e, model.page());
      ops.textOnPath(e); O.textEdit.end(true);
      const n = O.sel()[0];
      O.flushRender();
      return n && n.type === 'text' && n.path && O.$$('#doc-root textPath').length > 0;
    });
    await step('outline stroke', () => {
      fresh(); const p = model.create('path', { sw: 10, subpaths: [{ closed: false, pts: [G.pt(0, 0), G.pt(100, 50, null, null), G.pt(200, 0)] }] }); model.insert(p, model.page()); O.select([p.id]);
      ops.outlineStroke(); const n = O.sel()[0];
      return geomOK(n) && n.fills.length && !n.strokes.length;
    });
    await step('offset path', () => { fresh(); const r = mkRect(0, 0, 100, 100); O.select([r.id]); ops.offsetPath(10, 'round', 4); const n = O.sel()[0]; const b = model.localBounds(n); return geomOK(n) && Math.abs(b.w - 120) < 1 ? 'w=' + O.fmt(b.w) : false; });
    await step('join two open paths', () => {
      fresh(); const a = model.create('path', { subpaths: [{ closed: false, pts: [G.pt(0, 0), G.pt(100, 0)] }] }), b = model.create('path', { subpaths: [{ closed: false, pts: [G.pt(110, 0), G.pt(200, 50)] }] });
      model.insert(a, model.page()); model.insert(b, model.page()); O.select([a.id, b.id]); ops.join();
      return count() === 1 && model.page().children[0].subpaths[0].pts.length === 4;
    });
    await step('compound path make / release', () => { fresh(); const a = mkRect(0, 0, 100, 100), b = mkRect(25, 25, 50, 50); O.select([a.id, b.id]); ops.makeCompound(); const c = O.sel()[0]; const ok1 = c.subpaths.length === 2 && c.fillRule === 'evenodd'; ops.releaseCompound(); return ok1 && count() === 2; });
    await step('clipping mask make / release', () => { fresh(); const a = mkRect(0, 0, 100, 100), b = model.create('ellipse', { w: 80, h: 80, m: M.translate(10, 10) }); model.insert(b, model.page()); O.select([a.id, b.id]); ops.makeClip('top'); const g = O.sel()[0]; O.flushRender(); const ok1 = g.mask && g.children[0].id === b.id && O.$$('#doc-defs clipPath').length > 0; ops.releaseClip(); return ok1 && !g.mask; });
    await step('group / ungroup / frame selection', () => { fresh(); const a = mkRect(0, 0, 50, 50), b = mkRect(100, 0, 50, 50); O.select([a.id, b.id]); const g = ops.group(); const ok1 = g.children.length === 2; ops.ungroup(); const ok2 = count() === 2; O.select([a.id, b.id]); const f = ops.frameSelection(); return ok1 && ok2 && f.type === 'frame' && Math.abs(f.w - 150) < 0.01; });
    await step('auto layout', () => { fresh(); const a = mkRect(0, 0, 50, 50), b = mkRect(80, 0, 50, 50), c = mkRect(160, 0, 50, 50); O.select([a.id, b.id, c.id]); ops.autoLayout(); const f = O.sel()[0]; model.layoutAll(); return f.layout && f.layout.dir === 'h' && Math.abs(f.w - (10 + 150 + 2 * f.layout.gap + 10)) < 0.01 ? 'gap=' + f.layout.gap : false; });
    await step('component, instance, detach', () => {
      fresh(); const a = mkRect(0, 0, 80, 40); O.select([a.id]); ops.createComponent(); const comp = O.sel()[0];
      ops.insertInstance(comp.id); const inst = O.sel()[0]; O.flushRender();
      const ok1 = comp.component && inst.type === 'instance' && O.$$(`#doc-root [data-id="${inst.id}"]`).length > 0;
      ops.detach(); const d = O.sel()[0];
      return ok1 && d.type === 'frame' && !d.component && d.children.length === 1;
    });
    await step('blend between shapes', () => { fresh(); const a = mkRect(0, 0, 50, 50, '#FF0000'), b = mkRect(300, 0, 50, 50, '#0000FF'); O.select([a.id, b.id]); ops.blend(a, b, 4); const g = O.sel()[0]; return g.children.length === 6 && g.children[2].fills[0].color !== '#FF0000' ? '4 steps' : false; });
    await step('blend different shapes', () => { fresh(); const a = mkRect(0, 0, 50, 50, '#FF0000'); const b = model.create('star', { w: 80, h: 80, m: M.translate(300, 0) }); model.insert(b, model.page()); ops.blend(a, b, 3); return O.sel()[0].children.length === 5; });
    for (const [name, fn] of [['pucker & bloat', () => ops.puckerBloat(40)], ['roughen', () => ops.roughen(3, 20, false)], ['zig zag', () => ops.zigzag(5, 4, true)], ['twist', () => ops.twist(90)], ['round corners', () => ops.roundCorners(8)], ['simplify', () => ops.simplifyPath(1)], ['smooth', () => ops.smoothPath()], ['add anchors', () => ops.addAnchors()], ['reverse', () => ops.reverse()]]) {
      await step('effect: ' + name, () => { fresh(); const s = model.create('star', { w: 100, h: 100 }); model.insert(s, model.page()); O.select([s.id]); fn(); return geomOK(model.get(s.id)); });
    }
    await step('transform each with copies', () => { fresh(); const a = mkRect(0, 0, 40, 40); O.select([a.id]); ops.transformEach({ sx: 90, sy: 90, dx: 50, dy: 0, rotate: 15, copies: 5 }); return count() === 6; });
    await step('rotate tool with Alt copy + transform again', () => {
      fresh(); const a = mkRect(0, 0, 100, 20); O.select([a.id]);
      O.setTool('rotate'); const t = O.tools.rotate; t.pivot = { x: 0, y: 0 };
      t.down(ev(100, 10, { alt: true })); t.move(ev(90, 40, { alt: true })); t.move(ev(80, 60, { alt: true })); t.up(ev(80, 60, { alt: true }));
      const c1 = count(); ops.duplicateCmd(); const c2 = count(); O.setTool('select');
      return c1 === 2 && c2 === 3 ? 'copies chained' : 'c1=' + c1 + ' c2=' + c2 && false;
    });
    for (const k of ['reflect', 'scale', 'shear']) {
      await step(k + ' tool', () => {
        fresh(); const a = mkRect(0, 0, 100, 50); O.select([a.id]); const before = JSON.stringify(a);
        O.setTool(k); const t = O.tools[k]; t.pivot = { x: 0, y: 0 };
        t.down(ev(100, 50)); t.move(ev(140, 70)); t.move(ev(160, 90)); t.up(ev(160, 90)); O.setTool('select');
        const n = model.get(a.id);
        const b = model.worldBounds(n);
        if (JSON.stringify(n) === before) throw new Error('node unchanged');
        return `${n.type}, bounds ${O.fmt(b.w)}×${O.fmt(b.h)}`;
      });
    }
    await step('select tool: move, resize, rotate', () => {
      fresh(); const a = mkRect(0, 0, 100, 100); O.select([a.id]); O.setTool('select'); O.requestRender(); O.flushRender();
      const t = O.tools.select;
      t.down(ev(50, 50)); t.move(ev(70, 60)); t.move(ev(90, 70)); t.up(ev(90, 70));
      const moved = Math.abs(a.m[4] - 40) < 1;
      const box = O.selBox(); void box;
      t.down(ev(140, 170, { h: 'se' })); t.move(ev(170, 200, { h: 'se' })); t.move(ev(190, 220, { h: 'se' })); t.up(ev(190, 220, { h: 'se' }));
      const resized = Math.abs(a.w - 150) < 1;
      t.down(ev(200, 230, { h: 'rot-se' })); t.move(ev(150, 260, { h: 'rot-se' })); t.up(ev(150, 260, { h: 'rot-se' }));
      const rotated = Math.abs(M.decompose(a.m).rot) > 0.05;
      if (!(moved && resized && rotated)) throw new Error(`moved=${moved}(${a.m[4]}) resized=${resized}(${a.w}) rotated=${rotated}`);
      return `w=${O.fmt(a.w)}, rot=${O.fmt(O.deg(M.decompose(a.m).rot), 1)}°`;
    });
    await step('alt-drag duplicates', () => { const t = O.tools.select; const n0 = count(); const c = R => R; void c; const a = model.page().children[0]; O.select([a.id]); const b = model.worldBounds(a); const cx = b.x + b.w / 2, cy = b.y + b.h / 2; t.down(ev(cx, cy, { alt: true })); t.move(ev(cx + 50, cy, { alt: true })); t.move(ev(cx + 300, cy, { alt: true })); t.up(ev(cx + 300, cy, { alt: true })); return count() === n0 + 1; });
    await step('align & distribute', () => { fresh(); const a = mkRect(0, 0, 10, 10), b = mkRect(50, 30, 10, 10), c = mkRect(200, 60, 10, 10); O.select([a.id, b.id, c.id]); ops.align('top'); const top = [a, b, c].every(n => Math.abs(model.worldBounds(n).y) < 1e-6); ops.distribute('h'); return top && Math.abs(model.worldBounds(b).x - 100) < 1e-6; });
    await step('gradient tool', () => { fresh(); const a = mkRect(0, 0, 100, 100); O.select([a.id]); drag('gradient', [[0, 50], [50, 50], [100, 50]]); return a.fills[0].type === 'linear' && Math.abs(a.fills[0].to.x - 1) < 0.01; });
    await step('eyedropper copies appearance', () => { fresh(); const a = mkRect(0, 0, 50, 50, '#FF0000'), b = mkRect(100, 0, 50, 50, '#00FF00'); b.sw = 4; b.strokes = [O.paint.solid('#000000')]; O.flushRender(); O.select([a.id]); O.setTool('eyedropper'); O.tools.eyedropper.down(ev(125, 25)); O.setTool('select'); return a.fills[0].color === '#00FF00' && a.sw === 4; });
    await step('shape builder merges regions', () => {
      fresh(); const a = mkRect(0, 0, 100, 100), b = mkRect(50, 0, 100, 100); O.select([a.id, b.id]); O.setTool('shapebuilder');
      const t = O.tools.shapebuilder; const n0 = t.regions.length;
      O.flushRender();
      t.down(ev(25, 50)); t.move(ev(75, 50)); t.up(ev(75, 50));
      const n1 = t.regions.length; O.setTool('select');
      return n0 === 3 && n1 === 2 ? '3 regions → 2' : `regions ${n0} → ${n1}` && false;
    });
    await step('double-click boolean selects operand', () => {
      fresh(); const a = mkRect(0, 0, 100, 100), b = mkRect(50, 50, 100, 100); O.select([a.id, b.id]); ops.boolean('union'); O.flushRender();
      O.setTool('select'); O.tools.select.dblclick(ev(20, 20));
      return O.sel()[0] && O.sel()[0].id === a.id;
    });
    await step('shortcuts work in Ukrainian layout (Ctrl+G via key «п»)', () => {
      fresh(); const a = mkRect(0, 0, 50, 50), b = mkRect(100, 0, 50, 50); O.select([a.id, b.id]);
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'п', code: 'KeyG', ctrlKey: true, bubbles: true }));
      const g = O.sel()[0];
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'к', code: 'KeyR', bubbles: true }));
      const tool = O.state.tool; O.setTool('select');
      return g && g.type === 'group' && tool === 'rect' ? 'Ctrl+G grouped, R → rectangle tool' : false;
    });
    await step('real pointer events: draw, then resize by handle', () => {
      fresh(); O.setTool('rect');
      const cv = V.el, r = cv.getBoundingClientRect();
      const pe = (type, wx, wy, target) => {
        const s = V.toScreen({ x: wx, y: wy });
        const x = r.left + s.x, y = r.top + s.y;
        const e = new PointerEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, pointerId: 7, button: 0, buttons: type === 'pointerup' ? 0 : 1, pointerType: 'mouse', isPrimary: true });
        (target || document.elementFromPoint(x, y) || cv).dispatchEvent(e);
      };
      pe('pointerdown', 10, 10); pe('pointermove', 60, 40); pe('pointermove', 110, 90); pe('pointerup', 110, 90);
      const n = O.sel()[0];
      if (!n || n.type !== 'rect') throw new Error('rectangle not drawn');
      if (O.state.tool !== 'rect') throw new Error('shape tool should stay active');
      O.setTool('select');
      O.requestOverlay(); O.flushRender();
      const handle = O.$('#overlay [data-h="se"]');
      if (!handle) throw new Error('no resize handle in overlay');
      pe('pointerdown', 110, 90, handle); pe('pointermove', 150, 120); pe('pointermove', 210, 190); pe('pointerup', 210, 190);
      if (!(Math.abs(n.w - 200) < 1 && Math.abs(n.h - 180) < 1)) throw new Error(`size ${n.w}×${n.h}`);
      return `${O.fmt(n.w)}×${O.fmt(n.h)}`;
    });
    await step('copy / paste', () => { fresh(); const a = mkRect(0, 0, 50, 50); O.select([a.id]); const clip = ops.copy(); ops.paste(clip); return count() === 2; });
    await step('export SVG markup', () => { const { svg } = O.render.svg(null, {}); return svg.startsWith('<svg') && svg.includes('<rect') ? svg.length + ' chars' : false; });
    await step('export PNG (canvas render)', async () => { const { blob } = await O.io.renderImage(model.page().children, { scale: 2, type: 'image/png' }); return blob && blob.size > 100 ? blob.size + ' bytes' : false; });
    await step('import SVG (gradients, transforms, arcs, text, clip)', () => {
      fresh();
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="400" height="400">
        <defs><linearGradient id="g1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff0"/><stop offset="1" stop-color="red"/></linearGradient>
        <clipPath id="cp"><circle cx="150" cy="150" r="30"/></clipPath><style>.st0{fill:#0a0;stroke:#000;stroke-width:2}</style></defs>
        <rect x="10" y="10" width="80" height="60" rx="8" fill="url(#g1)"/>
        <g transform="translate(100 0) rotate(15)"><circle class="st0" cx="40" cy="40" r="30"/></g>
        <path d="M10 120 a30 30 0 1 0 60 0 q20 -40 40 0 t40 0" fill="none" stroke="blue" stroke-width="3"/>
        <polygon points="10,190 50,150 90,190" fill="purple"/>
        <text x="110" y="100" font-size="16" font-family="Arial">Текст</text>
        <rect x="110" y="110" width="80" height="80" fill="orange" clip-path="url(#cp)"/>
      </svg>`;
      const g = O.io.importSVG(svg, {});
      if (!g) return false;
      const leaves = []; model.walk([g], n => { if (!n.children) leaves.push(n); });
      const b = model.worldBounds(g);
      const hasGrad = leaves.some(n => (n.fills || []).some(f => f.type === 'linear'));
      const hasClass = leaves.some(n => n.type === 'ellipse' && (n.fills[0] || {}).color === '#00AA00');
      const hasText = leaves.some(n => n.type === 'text');
      const clipped = (function f(n) { return n.mask || (n.children || []).some(f); })(g);
      return hasGrad && hasClass && hasText && clipped && Math.abs(b.w - 360) < 30 ? `${leaves.length} objects, ${O.fmt(b.w)}×${O.fmt(b.h)}` : `grad=${hasGrad} class=${hasClass} text=${hasText} clip=${clipped} w=${b.w}` && false;
    });
    await step('image import + image trace', async () => {
      fresh();
      const cv = document.createElement('canvas'); cv.width = 120; cv.height = 80;
      const c = cv.getContext('2d'); c.fillStyle = '#fff'; c.fillRect(0, 0, 120, 80); c.fillStyle = '#e33'; c.beginPath(); c.arc(40, 40, 25, 0, 7); c.fill(); c.fillStyle = '#33e'; c.fillRect(70, 15, 40, 50);
      const blob = await new Promise(r => cv.toBlob(r, 'image/png'));
      const n = await O.io.importImage(blob);
      if (!n || n.fills[0].type !== 'image') return false;
      O.select([n.id]);
      await ops.imageTrace('poster');
      const g = O.sel()[0];
      return g && g.type === 'group' && g.children.length > 0 ? 'traced ' + g.children.length + ' shapes' : false;
    });
    await step('rasterize', async () => { fresh(); const a = mkRect(0, 0, 60, 40); O.select([a.id]); await ops.rasterize(2); const n = O.sel()[0]; return n && n.fills[0].type === 'image' && S.doc.assets[n.fills[0].asset]; });
    await step('effects render as SVG filters', () => { fresh(); const a = mkRect(0, 0, 60, 40); a.effects = [{ type: 'shadow', x: 0, y: 4, blur: 8, spread: 2, color: '#000000', opacity: 0.3, visible: true }, { type: 'inner', x: 0, y: 2, blur: 4, color: '#000000', opacity: 0.3, visible: true }, { type: 'blur', blur: 2, visible: true }]; a.sa = 'inside'; a.sw = 4; a.strokes = [O.paint.solid('#000')]; O.requestRender(); O.flushRender(); return O.$$('#doc-defs filter').length === 1 && O.$$('#doc-defs clipPath').length >= 1; });
    await step('arrowheads on lines', () => { fresh(); drag('arrow', [[0, 0], [50, 0], [150, 0]]); O.flushRender(); return O.$$('#doc-defs marker').length === 1; });
    await step('shapes: polygon, star, spiral, arc, grid, polar, line, frame', () => {
      fresh(); let i = 0;
      for (const t of ['polygon', 'star', 'spiral', 'arc', 'grid', 'polar', 'line', 'frame']) { drag(t, [[i * 160, 0], [i * 160 + 60, 50], [i * 160 + 120, 100]]); i++; }
      return count() === 8 ? '' : 'count=' + count() && false;
    });
    await step('frame nesting on drop', () => {
      fresh(); drag('frame', [[0, 0], [200, 200], [400, 300]]); const f = O.sel()[0];
      const r = mkRect(500, 50, 50, 50); O.select([r.id]); const t = O.tools.select;
      O.requestRender(); O.flushRender();
      t.down(ev(525, 75)); t.move(ev(400, 75)); t.move(ev(225, 75)); t.up(ev(225, 75));
      if (model.parent(r) !== f) throw new Error('parent is ' + (model.parent(r).name || 'page'));
      return 'rectangle moved into frame';
    });
    await step('history depth', () => O.history.stack.length > 1 ? O.history.stack.length + ' snapshots' : false);
    await step('panels render for many selections', () => {
      O.run('sample');
      const all = []; model.walk(model.page().children, n => { all.push(n); });
      for (const n of all) { O.select([n.id]); O.panels.buildProps(); }
      O.select(all.slice(0, 4).map(n => n.id)); O.panels.buildProps();
      O.select([]); O.panels.buildProps(); O.panels.renderLayers();
      O.setTool('frame'); O.panels.buildProps(); O.setTool('select');
      return all.length + ' nodes inspected';
    });
    await step('inspect CSS for nodes', () => { const all = []; model.walk(model.page().children, n => { all.push(n); }); return all.every(n => typeof O.panels.cssFor(n) === 'string'); });
    await step('menus reference existing commands', () => {
      const missing = [];
      const walk = items => items.forEach(it => { if (it === '-') return; if (typeof it === 'string') { if (!O.cmds.has(it)) missing.push(it); } else if (it.items) walk(it.items); });
      O.MENUS.forEach(([, items]) => walk(items));
      O.MENUS.forEach(([, items], i) => { const el = O.ui.menu(items, 10, 10); void el; void i; O.ui.closeMenus(); });
      return missing.length ? 'missing: ' + missing.join(', ') && false : O.cmds.size + ' commands';
    });
    await step('context menu, palette, color picker, dialogs', () => {
      const n = model.page().children[0]; O.select([n.id]);
      O.showContextMenu(200, 200); O.ui.closeMenus();
      O.ui.palette(); const pal = O.$('.pal-back'); if (pal) pal.remove();
      const btn = document.createElement('button'); document.body.appendChild(btn);
      O.ui.picker.open(btn, O.paint.linear('#FF0000', '#0000FF'), { onChange: () => {} }); O.ui.picker.setType('radial'); O.ui.picker.setType('image'); O.ui.picker.setType('solid'); O.ui.picker.setColor('#123456'); O.ui.picker.close(); btn.remove();
      const d = O.ui.dialog({ title: 'T', fields: [{ key: 'a', label: 'A', type: 'number', value: 1 }], preview: true, apply: () => {} }); d.close();
      O.ops.transformDialog('rotate'); const back = O.$('.dlg-back'); if (back) back.remove();
      return true;
    });
    await step('sample document renders', () => {
      O.run('sample'); O.flushRender();
      const inst = []; model.walk(model.page().children, n => { if (n.type === 'instance') inst.push(n); });
      const comp = model.get(inst[0].ref);
      return O.$$('#doc-root [data-id]').length > 20 && Math.abs(inst[0].w - comp.w) < 0.01 && O.$$('#doc-root textPath').length === 1 ? O.$$('#doc-root [data-id]').length + ' rendered elements' : false;
    });
    await step('document serialize / load roundtrip', () => { const json = O.io.serialize(); const before = model.page().children.length; O.io.loadJSON(json, 'x.obrys'); return model.page().children.length === before; });
    await step('present mode', () => { O.run('present'); const el = O.$('.present'); const ok = el && el.querySelector('svg'); if (el) el.remove(); return !!ok; });
    await step('export selected objects (png, jpg, webp, svg)', async () => {
      O.run('sample');
      const pick = name => { let f = null; model.walk(model.page().children, n => { if (!f && n.name === name) f = n; }); return f; };
      const nested = pick('Сонце') || model.page().children[0].children[0];
      const top = model.page().children.find(n => n.type === 'frame');
      const got = [];
      const other = model.page().children.find(n => n !== nested && !model.isAncestor(n, nested));
      const orig = O.download;
      O.download = (blob, name) => got.push({ blob, name });
      try {
        for (const ids of [[nested.id], [top.id], [nested.id, other.id]]) {
          O.select(ids);
          for (const fmt of ['png', 'jpg', 'webp', 'svg']) { document.title = 'SELFTEST running: export ' + fmt + ' ' + ids.map(i => model.get(i).name).join('+') + ' files=' + got.length; await O.io.export(fmt, 1); }
        }
      } finally { O.download = orig; }
      if (got.length !== 12) throw new Error('files=' + got.length + ' ' + got.map(g => g.name).join(','));
      // several objects → one ZIP with one file per object
      const zips = got.filter(g => /\.zip$/.test(g.name));
      if (zips.length !== 4) throw new Error('zips=' + zips.length);
      const all = got.filter(g => !/\.zip$/.test(g.name));
      for (const z of zips) {
        const entries = O.interop.unzip(new Uint8Array(await z.blob.arrayBuffer()));
        const names = Object.keys(entries);
        if (names.length !== 2) throw new Error('zip entries ' + names.join(','));
        names.forEach(nm => all.push({ name: nm, blob: new Blob([entries[nm].data]) }));
      }
      const bad = [];
      for (const g of all) {
        if (!g.blob || g.blob.size < 60) { bad.push(g.name + ':' + (g.blob ? g.blob.size : 'null')); continue; }
        if (/\.(png|jpg|webp)$/.test(g.name)) {
          document.title = 'SELFTEST running: decode ' + g.name;
          let img;
          img = await O.io.loadImage(await O.io.blobToData(g.blob), 20000);
          const cv = document.createElement('canvas'); cv.width = img.naturalWidth; cv.height = img.naturalHeight;
          const c = cv.getContext('2d'); c.drawImage(img, 0, 0);
          const d = c.getImageData(0, 0, cv.width, cv.height).data;
          let ink = 0; for (let i = 3; i < d.length; i += 4 * 7) if (d[i] > 10 && (d[i - 1] < 240 || d[i - 2] < 240 || d[i - 3] < 240)) ink++;
          if (!ink) bad.push(g.name + ':blank');
        }
      }
      if (bad.length) throw new Error('bad: ' + bad.join(', '));
      // PDF pages (print HTML) and "all in one file"
      O.select([nested.id, other.id]);
      const html = await O.io.exportPDF(O.io.exportTargets(), { noWindow: true });
      if (!/<svg/.test(html) || (html.match(/class="pg"/g) || []).length !== 2) throw new Error('pdf html');
      const one = await O.io.exportFile(O.io.exportTargets({ together: true })[0], 'png', 1);
      if (!one.blob || one.blob.size < 100) throw new Error('together');
      return all.length + ' images (4 ZIPs), e.g. ' + got[0].name + ' ' + got[0].blob.size + ' B';
    });
    await step('fonts: Google Fonts catalogue + picker search', async () => {
      const F = O.fonts;
      if (F.google.length < 1500) throw new Error('catalogue ' + F.google.length);
      const g = F.get('montserrat');
      if (!g || !g.cyr || !/family=Montserrat:ital,wght@0,100;/.test(F.cssURL(g))) throw new Error('montserrat ' + (g && F.cssURL(g)));
      if (F.nearest(F.get('Buda'), 700, false).w !== 300) throw new Error('nearest');
      const btn = document.createElement('button'); document.body.appendChild(btn);
      const el = F.picker(btn, 'Inter', () => {});
      const q = el.querySelector('.fp-q'); q.value = 'Playfair'; q.dispatchEvent(new Event('input'));
      const names = Array.from(el.querySelectorAll('.fp-row')).map(r => r.dataset.fam);
      F.closePicker(); btn.remove();
      if (!names.includes('Playfair Display')) throw new Error('rows ' + names.join(','));
      return F.google.length + ' families; «Playfair» → ' + names.length + ' rows';
    });
    await step('animation: keyframes, interpolation, Lottie JSON, presets', async () => {
      fresh();
      const A = O.anim;
      const r = mkRect(0, 0, 100, 50, '#FF0000');
      O.select([r.id]);
      A.recordKey(r, 0);
      r.m = M.translate(200, 0); r.fills[0].color = '#0000FF';
      A.recordKey(r, 1);
      A.applyAt(0.5, true);
      const x = model.worldBounds(r).x;
      if (Math.abs(x - 100) > 1) throw new Error('mid x=' + x);
      if (r.fills[0].color.toUpperCase() === '#FF0000' || r.fills[0].color.toUpperCase() === '#0000FF') throw new Error('color not interpolated ' + r.fills[0].color);
      const { json } = await A.lottie(A.rootForExport(), {});
      const L = json.layers[0];
      if (!L || L.ty !== 4 || L.ks.p.a !== 1 || L.ks.p.k.length !== 2) throw new Error('lottie ' + JSON.stringify(L && L.ks.p).slice(0, 160));
      const fl = L.shapes.find(s => s.ty === 'fl');
      if (!fl || fl.c.a !== 1) throw new Error('fill not animated');
      A.applyAt(2);
      A.applyPreset('pop');
      const pk = r.anim.filter(k => k.t >= 2 - 1e-6).length;
      if (pk !== 3 || r.anim.length !== 5) throw new Error('preset keys ' + pk + '/' + r.anim.length);
      let keys = 0;
      try { A.toggle(true); A.render(); const tl = O.$('#timeline'); keys = tl ? tl.querySelectorAll('.tl-key').length : 0; } finally { A.toggle(false); }
      return `lottie ${json.w}×${json.h}, ${json.op} frames; timeline keys ${keys}`;
    });
    await step('HTML + CSS export builds', () => {
      O.run('sample');
      const f = model.page().children.find(n => n.type === 'frame');
      const res = O.html.build([f], {});
      if (!/<html/i.test(res.htmlInline) || res.css.length < 50) throw new Error('html ' + res.htmlInline.slice(0, 80));
      return res.css.length + ' B css, ' + res.htmlInline.length + ' B html';
    });
    await step('PSD export → import (ag-psd)', async () => {
      fresh();
      const f = model.create('frame', { name: 'PSD', w: 120, h: 80, m: M.translate(0, 0), fills: [O.paint.solid('#FFFFFF')] });
      model.insert(f, model.page());
      const r = model.create('rect', { w: 40, h: 30, m: M.translate(10, 10), fills: [O.paint.solid('#FF0000')] });
      model.insert(r, f);
      model.reindex();
      O.select([f.id]);
      const got = []; const orig = O.download; O.download = (b, n) => got.push({ b, n });
      try { await O.interop.exportPSD(); } finally { O.download = orig; }
      if (!got.length) throw new Error('no psd');
      await O.interop.importPSD(new File([got[0].b], 'test.psd'), { x: 500, y: 500 });
      const fr = O.sel()[0];
      if (!fr || fr.type !== 'frame' || fr.children.length < 2) throw new Error('import ' + (fr && fr.type) + ' ' + (fr && fr.children && fr.children.length));
      return got[0].b.size + ' B, layers ' + fr.children.length;
    });
    await step('animation pen: click 3 objects → CSS @keyframes', () => {
      fresh();
      const f = model.create('frame', { name: 'Екран', w: 400, h: 300, m: M.translate(0, 0) }); model.insert(f, model.page());
      const mk = (type, name, x, y, w, c) => { const n = model.create(type, { name, w, h: w, m: M.translate(x, y), fills: [O.paint.solid(c)] }); model.insert(n, f); return n; };
      const a = mk('rect', 'Кулька', 20, 20, 40, '#FF0000'), b = mk('rect', 'Кулька 2', 300, 200, 80, '#0000FF'), c = mk('ellipse', 'Кулька 3', 300, 20, 40, '#00FF00');
      model.reindex(); O.requestRender(); O.flushRender();
      O.setTool('animpen');
      const tl = O.tools.animpen;
      const click = n => { const r = model.worldBounds(n); tl.down(ev(r.x + r.w / 2, r.y + r.h / 2)); };
      click(a); click(b); click(c);
      tl.key({ key: 'Escape' });
      const l = (S.doc.links || [])[0];
      if (!l || l.ids.join() !== [a.id, b.id, c.id].join()) throw new Error('link ' + JSON.stringify(S.doc.links || []));
      O.flushRender();
      const arrows = O.$$('#overlay path[fill="#FF3D9A"]').length;
      const res = O.html.build([f], {});
      if (!/@keyframes obrys-kulka/.test(res.css) || !/animation: obrys-kulka/.test(res.css)) throw new Error('no keyframes ' + res.css.slice(-400));
      if (/class="kulka-2"|class="kulka-3"/.test(res.htmlInline)) throw new Error('states exported as elements');
      O.panels.buildProps();
      O.setTool('select');
      return `chain of 3, ${arrows} arrows, css ${res.css.length} B`;
    });
    await step('adaptation pen + website frames → one responsive page (@media)', () => {
      fresh();
      const devs = [{ group: 'Десктоп', name: 'Десктоп', w: 1440, h: 1024 }, { group: 'Планшет', name: 'iPad вертикально', w: 768, h: 1024 }, { group: 'Мобільний', name: 'iPhone 14/15', w: 390, h: 844 }];
      const frames = O.site.makeFrames(model.page().children, devs, { content: true, grids: true, name: 'Головна' });
      model.reindex(); O.requestRender(); O.flushRender();
      const l = (S.doc.links || []).find(x => x.kind === 'adapt');
      if (!l || l.ids.length !== 3) throw new Error('no link');
      if (frames[0].name !== O.t('Десктоп') + ' — 1440×1024' || frames[2].name !== O.t('iPhone 14/15') + ' — 390×844') throw new Error('names ' + frames.map(f => f.name).join(', '));
      const res = O.html.buildSite(l, {});
      const mq = res.css.match(/@media \(max-width: \d+px\)/g) || [];
      if (mq.length !== 2 || !/max-width: 1023px/.test(res.css) || !/max-width: 767px/.test(res.css)) throw new Error('media ' + mq.join(','));
      if (!/class="site"/.test(res.htmlInline) || !/class="zaholovok"/.test(res.htmlInline)) throw new Error('html ' + res.htmlInline.slice(0, 300));
      const grids = O.$('#overlay').innerHTML.split('fill-opacity="0.1"').length - 1;
      if (grids < 24) throw new Error('layout grid columns drawn: ' + grids);
      // the pen: link two new frames by clicking them
      const f1 = model.create('frame', { name: 'A', w: 600, h: 400, m: M.translate(0, 2000) }); model.insert(f1, model.page());
      const f2 = model.create('frame', { name: 'B', w: 300, h: 400, m: M.translate(800, 2000) }); model.insert(f2, model.page());
      model.reindex();
      O.setTool('adaptpen');
      const tl = O.tools.adaptpen;
      tl.down(ev(300, 2200)); tl.down(ev(950, 2200)); tl.key({ key: 'Escape' });
      const l2 = S.doc.links.find(x => x.kind === 'adapt' && x.ids.includes(f1.id));
      O.setTool('select');
      if (!l2 || !l2.ids.includes(f2.id)) throw new Error('pen did not link frames');
      const doc = O.site.siteDoc({ devs, content: true, grids: true, name: 'Про нас' });
      if (doc.pages[0].children.length !== 3 || (doc.links || []).length !== 1) throw new Error('template doc');
      return `${mq.join(' ')}; html ${res.htmlInline.length} B; grid stripes ${grids}`;
    });
    await step('vector PDF: save (bleed, marks, editable) → read with pdf.js → import as vectors', async () => {
      O.run('sample');
      const frames = model.page().children.filter(n => n.type === 'frame');
      const count0 = model.page().children.length;
      const res = await O.pdf.build(frames.map(f => [f]), { bleed: 3 * 72 / 25.4, marks: true, editable: true });
      const head = String.fromCharCode.apply(null, Array.from(res.bytes.slice(0, 5)));
      if (head !== '%PDF-') throw new Error('header ' + head);
      if (model.page().children.length !== count0 || !model.page().children.some(n => n.type === 'frame')) throw new Error('document changed by export');
      const back = await O.pdf.extractDoc(res.bytes);
      if (!back || !back.pages || back.pages[0].children.length !== count0) throw new Error('embedded document');
      const lib = await O.pdf.loadReader();
      const pdf = await lib.getDocument({ data: res.bytes.slice(), isEvalSupported: false }).promise;
      if (pdf.numPages !== frames.length) throw new Error('pages ' + pdf.numPages);
      fresh();
      const made = await O.pdf.open(new File([res.bytes], 'test.pdf', { type: 'application/pdf' }), { auto: true, target: 'page', mode: 'vector', ignoreEmbedded: true });
      if (!made || made.length !== frames.length) throw new Error('import ' + (made && made.length) + ' ' + O.pdf.lastErrors.join(' || ').slice(0, 900));
      let paths = 0, texts = 0, images = 0;
      model.walk(made, n => { if (n.type === 'path') paths++; if (n.type === 'text') texts++; if ((n.fills || []).some(f => f.type === 'image')) images++; });
      if (paths < 5) throw new Error('paths ' + paths);
      return `${res.bytes.length} B, ${pdf.numPages} pages, rasterised ${res.rastered}; import: ${paths} paths, ${texts} texts, ${images} images`;
    });
    await step('workspace areas: split, swap editors, close, maximise, workspaces', () => {
      const L = O.layout;
      if (!L || !L.active || L.mobile) return 'phone layout';
      L.resetSpace();
      const n0 = L.areas().length;
      const c = L.areas().find(a => a.area === 'canvas');
      L.split(c.id, 'v', 'history');
      if (L.areas().length !== n0 + 1 || !L.visible('history') || !O.$('#ws #ed-history')) throw new Error('split');
      const h = L.areas().find(a => a.area === 'history');
      L.setType(h.id, 'design');
      if (L.areas().filter(a => a.area === 'design').length !== 1 || !L.visible('history') || !L.visible('design')) throw new Error('swap');
      L.close(L.areas().find(a => a.area === 'history').id);
      if (L.areas().length !== n0) throw new Error('close');
      L.close(c.id);
      if (!L.visible('canvas')) throw new Error('canvas closed');
      L.toggleMax(c.id);
      if (O.$$('#ws .ws-area').length !== 1 || !O.$('#ws #canvas')) throw new Error('maximise');
      L.toggleMax();
      L.switchTo('anim');
      if (!L.visible('timeline') || !O.$('#ws #timeline')) throw new Error('animation workspace');
      L.switchTo('web');
      if (!L.visible('webview')) throw new Error('web workspace');
      L.switchTo('design'); L.resetSpace();
      const w = O.$('#canvas').clientWidth;
      if (w < 300 || !O.$('#ws #props') || !O.$('#ws #lp-layers')) throw new Error('design layout ' + w);
      return `${L.areas().length} areas, canvas ${w}px`;
    });
    // ---------- InDesign-style text (typeset.js / typeui.js) ----------
    const TS = O.typeset, TU = O.typeui;
    const LONG = 'Типографіка — це мистецтво впорядкування тексту. Добре зверстаний текст легко читати, а погано зверстаний втомлює очі. '.repeat(6).trim();
    const mkText = (props) => { const n = model.create('text', Object.assign({ text: LONG, font: 'Arial', size: 12, width: 420, m: M.translate(0, 0) }, props)); model.insert(n, model.page()); return n; };
    await step('text columns: 3 balanced columns', () => {
      fresh(); const n = mkText({ cols: 3, colGap: 12 }); const L = O.text.layout(n);
      const cols = new Set(L.lines.map(l => l.col));
      if (cols.size !== 3) throw new Error('columns used: ' + cols.size + ' L.cols=' + L.cols + ' colH=' + L.colH + ' lines=' + L.lines.length + ' h=' + L.h + ' w=' + L.w);
      if (Math.abs(L.colW - (420 - 24) / 3) > 0.01) throw new Error('colW ' + L.colW);
      const per = [0, 1, 2].map(c => L.lines.filter(l => l.col === c).length);
      if (Math.max(...per) - Math.min(...per) > 2) throw new Error('unbalanced ' + per);
      return per.join('/') + ' lines, h=' + O.fmt(L.h);
    });
    await step('text columns: +/− in the Design panel', () => {
      fresh(); const n = mkText({ width: null, text: 'Колонки' }); O.select([n.id]); O.flushRender();
      const html = O.panels.buildProps();
      if (!/data-sec="ty-char"/.test(html) || !/data-f="ty-colstep"/.test(html) || !/data-sec="ty-para"/.test(html)) throw new Error('sections missing');
      O.panels.applyField('ty-colstep', '1'); O.panels.applyField('ty-colstep', '1');
      if (n.cols !== 3 || !n.width) throw new Error('cols ' + n.cols);
      O.panels.applyField('ty-colstep', '-1');
      return n.cols === 2 ? 'cols 1→3→2, width ' + O.fmt(n.width) : false;
    });
    await step('text: fixed-height columns overset + threading', () => {
      fresh(); const a = mkText({ cols: 2, boxH: 60, text: LONG + '\n' + LONG }); const b = mkText({ boxH: 400, text: '', m: M.translate(0, 120) });
      if (!O.print.overset(a)) throw new Error('no overset');
      const story = a.text;
      O.select([a.id, b.id]); O.print.thread();
      if (!a.text || !b.text || O.print.story([a, b]) !== story) throw new Error('story split wrong');
      const La = O.text.layout(a);
      if (La.overset) throw new Error('first frame still overset');
      return `${a.text.length} + ${b.text.length} chars`;
    });
    await step('text: character formatting of a selection while editing', () => {
      fresh(); const n = mkText({ text: 'Звичайний жирний текст', width: null }); O.select([n.id]);
      O.textEdit.start(n, { selectAll: false });
      const ta = O.$('#text-editor'); ta.value = n.text; ta.setSelectionRange(10, 16);
      TU.setChar({ weight: 700, color: '#FF0000' }); O.history.commit('t');
      if (!n.runs || n.runs[0].s !== 10 || n.runs[0].e !== 16) throw new Error('runs ' + JSON.stringify(n.runs));
      // typing before the bold word shifts it
      ta.value = 'Дуже ' + ta.value; ta.setSelectionRange(5, 5); O.textEdit.input({});
      if (n.runs[0].s !== 15 || n.runs[0].e !== 21) throw new Error('shift ' + JSON.stringify(n.runs));
      O.textEdit.end(true); O.flushRender();
      const svg = O.render.svg([n]).svg;
      if (!/font-weight="700"/.test(svg) || !/fill="#FF0000"/.test(svg)) throw new Error('markup');
      return 'run ' + n.runs[0].s + '–' + n.runs[0].e;
    });
    await step('text: indents, drop cap, bullets, numbering', () => {
      fresh(); const n = mkText({ text: 'Перший абзац з буквицею і достатньо довгим текстом для кількох рядків у колонці.\nДругий\nТретій', li: 20, dcl: 3, dcc: 1 });
      let L = O.text.layout(n);
      const dc = L.frags.find(f => f.dc);
      if (!dc || dc.st.size < 24) throw new Error('drop cap');
      if (L.lines[1].x < 20 + dc.w - 1) throw new Error('drop cap indent ' + L.lines[1].x);
      delete n.dcl; n.list = { t: 'num', style: 'arabic', suf: '.' };
      L = O.text.layout(n);
      const labels = L.frags.filter(f => f.label).map(f => f.str).join(' ');
      if (labels !== '1. 2. 3.') throw new Error('labels ' + labels);
      n.list = { t: 'bullet', ch: '•' }; L = O.text.layout(n);
      return L.frags.filter(f => f.label && f.str === '•').length === 3 ? 'drop cap ' + O.fmt(dc.st.size) + 'px, 3 numbers, 3 bullets' : false;
    });
    await step('text: justification, tabs with leaders, hyphenation, composer', () => {
      fresh(); const n = mkText({ align: 'justify', width: 200, hyph: true, lang: 'uk' });
      let L = O.text.layout(n);
      const full = L.lines.filter(l => !l.last);
      if (!full.length) throw new Error('no lines');
      const hy = L.lines.some(l => /-$/.test(l.t));
      n.composer = 'para'; const Lp = O.text.layout(n);
      const t2 = mkText({ text: 'Зміст\tстор. 5', width: 300, tabs: [{ x: 280, a: 'right', l: '.' }] });
      L = O.text.layout(t2);
      const leader = L.frags.find(f => f.leader);
      const last = L.frags.filter(f => f.str && !f.leader).pop();
      if (!leader || Math.abs(last.ax + last.w - 280) > 1.5) throw new Error('right tab ' + (last && last.ax + last.w));
      return `${L.frags.length} frags; hyphenated: ${hy}; composer lines ${Lp.lines.length}`;
    });
    await step('text: footnotes, endnotes, special characters', () => {
      fresh(); const n = mkText({ text: 'Текст із виноскою', width: 300, boxH: 200 }); O.select([n.id]);
      O.textEdit.start(n, { selectAll: false }); const ta = O.$('#text-editor'); ta.setSelectionRange(5, 5);
      TU.insert(O.typeset.CH.footnote, { notes: [{ text: 'Пояснення' }] });
      TU.insert(O.typeset.CH.endnote, { notes: [{ text: 'Джерело' }] });
      O.run('tyIns:emDash');
      O.textEdit.end(true);
      const L = O.text.layout(n);
      if (!n.fnotes || n.fnotes[0].text !== 'Пояснення' || !n.enotes) throw new Error('notes');
      if (!L.rule || !L.frags.some(f => f.str.includes('Пояснення'))) throw new Error('footnote area');
      if (!L.lines.some(l => l.t.includes('Джерело'))) throw new Error('endnotes');
      if (n.text.indexOf('—') < 0) throw new Error('em dash');
      return n.text.length + ' chars';
    });
    await step('text: tracked changes keep and accept deletions', () => {
      fresh(); S.settings.showChanges = false; const n = mkText({ text: 'Один два три', width: null, track: true });
      const old = n.text; const res = TS.textChanged(n, old, 'Один три', { caret: 5, inputType: 'deleteContentBackward' });
      if (!res || res.text !== old) throw new Error('deleted text should stay ' + JSON.stringify(res));
      n.text = res.text;
      if (!n.runs.some(r => r.del)) throw new Error('no del mark');
      if (O.text.layout(n).lines[0].t !== 'Один три') throw new Error('hidden: ' + O.text.layout(n).lines[0].t);
      TS.acceptChanges(n, true);
      return n.text === 'Один три' && !n.runs ? 'accepted' : false;
    });
    await step('text: caret, hit test and selection geometry', () => {
      fresh(); const n = mkText({ cols: 2, text: LONG });
      let bad = 0;
      for (const i of [0, 7, 40, 120, n.text.length]) { const c = TS.caret(n, i); if (!c) { bad++; continue; } const j = TS.hitIndex(n, { x: c.x + 0.1, y: c.y + c.h / 2 }); if (Math.abs(j - i) > 1) bad++; }
      const rects = TS.rangeRects(n, 10, 300);
      if (bad) throw new Error('roundtrip failures ' + bad);
      return rects.length + ' selection rects';
    });
    await step('text: paragraph styles per paragraph and placeholder fill', () => {
      fresh(); const n = mkText({ text: 'Заголовок\nТекст абзацу', width: 300 }); O.select([n.id]);
      S.doc.pstyles = [{ id: 'h1', name: 'H1', props: { size: 30, weight: 800, spb: 0, align: 'center' } }];
      O.textEdit.start(n, { selectAll: false }); O.$('#text-editor').setSelectionRange(2, 2);
      TU.applyPStyle('h1'); O.textEdit.end(true);
      const L = O.text.layout(n);
      if (L.lines[0].x < 50 || L.frags[0].st.size !== 30 || L.frags[L.frags.length - 1].st.size !== 12) throw new Error('style ' + L.lines[0].x);
      const f = mkText({ text: '', width: 200, boxH: 120, cols: 2, m: M.translate(0, 200) }); O.select([f.id]);
      O.run('tyPlaceholder');
      return f.text.length > 100 && !O.print.overset(f) ? f.text.length + ' placeholder chars' : false;
    });
    await step('text: every Text menu command and dialog opens without errors', async () => {
      fresh(); const n = mkText({ text: 'Перший абзац тексту\nДругий абзац', width: 300, boxH: 200 }); O.select([n.id]);
      const ids = [];
      const walk = items => items.forEach(it => { if (it === '-') return; if (typeof it === 'string') ids.push(it); else if (it.items) walk(it.items); });
      walk(O.MENUS.find(m => m[0] === 'Текст')[1]);
      const skip = new Set(['createOutlines', 'uploadFont', 'localFonts', 'googleFonts', 'tyLinkOpen', 'textOnPath', 'releaseTextPath', 'tyFontPick']);
      let ran = 0;
      const set0 = JSON.stringify(S.settings), doc0 = { trackAll: S.doc.trackAll };
      for (const id of ids) {
        if (skip.has(id)) continue;
        O.select([n.id]);
        O.run(id); ran++;
        await new Promise(r => setTimeout(r, 0));
        O.$$('.dlg-back').forEach(d => { const b = d.querySelector('[data-b="cancel"]'); if (b) b.click(); else d.remove(); });
        O.ui.closeMenus();
        if (S.textEdit) O.textEdit.end(true);
      }
      Object.assign(S.settings, JSON.parse(set0)); O.saveSettings(); S.doc.trackAll = doc0.trackAll;
      // a few dialogs confirmed with OK
      O.select([n.id]); O.run('tyFrameOptions'); let d = O.$('.dlg-back'); d.querySelector('[data-k="cols"]').value = '2'; d.querySelector('[data-b="ok"]').click();
      if (model.get(n.id).cols !== 2) throw new Error('frame options cols ' + model.get(n.id).cols);
      O.select([n.id]); O.run('tyListOptions'); d = O.$('.dlg-back'); d.querySelector('[data-k="t"]').value = 'num'; d.querySelector('[data-b="ok"]').click();
      if (!model.get(n.id).list || model.get(n.id).list.t !== 'num') throw new Error('list options');
      O.select([n.id]); O.run('tyTabs'); d = O.$('.dlg-back'); d.querySelector('[data-tk="add"]').click(); d.querySelector('[data-b="ok"]').click();
      if (!model.get(n.id).tabs || model.get(n.id).tabs.length !== 1) throw new Error('tabs ' + JSON.stringify(model.get(n.id).tabs));
      return ran + ' commands';
    });
    // ---------- VIBSma additions ----------
    const wait = ms => new Promise(r => setTimeout(r, ms));
    await step('modes: design → video → music → design', async () => {
      O.setMode('video'); await wait(50); const v = O.video.isOpen();
      O.setMode('music'); await wait(50); const m = O.studio.isOpen() && !O.video.isOpen();
      O.setMode('design'); await wait(50); const d = !O.studio.isOpen() && !O.video.isOpen();
      return v && m && d && O.$$('.mode-sw').length === 0;
    });
    await step('W opens and closes presentation mode', async () => {
      fresh(); mkRect(0, 0, 100, 60);
      const key = () => document.dispatchEvent(new KeyboardEvent('keydown', { key: 'w', code: 'KeyW', bubbles: true }));
      const blocker = O.$$('.dlg-back, .pal-back, .present').map(x => x.className).join(',');
      key(); await wait(30); const open = !!O.$('.present');
      key(); await wait(30); const closed = !O.$('.present');
      if (!(open && closed)) throw new Error(`open=${open} closed=${closed} blocker=${blocker} tool=${O.state.tool} cmdKeys=${(O.cmds.get('present').keys || []).join('/')}`);
      return true;
    });
    await step('scale tool scales strokes, glass lens and image tiles', () => {
      fresh(); const n = mkRect(0, 0, 100, 100); n.strokes = [O.paint.solid('#000000')]; n.sw = 2;
      n.effects = [Object.assign({}, O.glass.DEFAULT, { refract: 30, depth: 20, rim: 2 })];
      model.applyWorld(n, M.scale(2, 2), 'scale');
      const e = n.effects[0];
      return n.w === 200 && n.sw === 4 && e.refract === 60 && e.depth === 40 && e.rim === 4 && e.blur === 16 ? 'sw 4, lens ×2' : false;
    });
    await step('Liquid Glass: rim colours, rainbow, tint render', () => {
      fresh(); mkRect(0, 0, 300, 200, '#FF8800'); const n = mkRect(40, 40, 200, 100, '#FFFFFF');
      n.effects = [Object.assign({}, O.glass.DEFAULT, { rimColor: '#FF0000', rimColor2: '#00FF00', tint: '#0000FF', tintOp: 0.3 })];
      model.reindex();
      const a = O.render.svg([n], {}).svg; n.effects[0].rainbow = true; const b = O.render.svg([n], {}).svg;
      return /#FF0000/i.test(a) && /#00FF00/i.test(a) && /#0000FF/i.test(a) && /#5BFF8C/i.test(b);
    });
    await step('graphic styles: capture, apply, preview', () => {
      fresh(); const a = mkRect(0, 0, 80, 80, '#123456'); a.effects = [{ type: 'shadow', x: 0, y: 4, blur: 8, spread: 0, color: '#000000', opacity: 0.3, visible: true }]; a.radius = 12;
      const b = mkRect(200, 0, 80, 80, '#FFFFFF');
      const st = Object.assign({ id: 'test-style', name: 'Test' }, O.gstyles.capture(a));
      O.gstyles.applyTo(b, st);
      const pv = O.gstyles.preview(O.gstyles.BUILTIN[7]);
      return b.fills[0].color === '#123456' && b.effects.length === 1 && b.radius === 12 && /<svg/.test(pv) ? 'preview ' + pv.length + ' chars' : false;
    });
    await step('filters: every filter runs on pixels', () => {
      const im = new ImageData(48, 36);
      for (let i = 0; i < im.data.length; i += 4) { const j = i / 4; im.data[i] = (j * 7) % 255; im.data[i + 1] = (j * 3) % 255; im.data[i + 2] = 255 - (j % 255); im.data[i + 3] = 255; }
      const bad = [];
      let n = 0;
      for (const f of Object.values(O.filters.defs)) {
        const p = {}; for (const pr of f.params) p[pr.k] = pr.v;
        try { const out = f.run(new ImageData(new Uint8ClampedArray(im.data), 48, 36), p); if (!out || !out.data || !out.width) bad.push(f.id); n++; } catch (e) { bad.push(f.id + ': ' + e.message); }
      }
      return bad.length ? bad.slice(0, 4).join(' | ') && false : n + ' filters';
    });
    await step('filters: photo → blur, smart filter on/off, restore', async () => {
      fresh();
      const cv = document.createElement('canvas'); cv.width = 64; cv.height = 48; const g = cv.getContext('2d'); g.fillStyle = '#E33'; g.fillRect(0, 0, 32, 48); g.fillStyle = '#33E'; g.fillRect(32, 0, 32, 48);
      const a = await O.io.addAsset(cv.toDataURL('image/png'), 'test');
      const n = model.create('rect', { w: 64, h: 48, fills: [O.paint.image(a.id)] }); model.insert(n, model.page()); O.select([n.id]);
      await O.filters.apply('gaussBlur', { radius: 3 });
      const f = n.fills[0]; const blurred = f.asset !== a.id && f.origAsset === a.id;
      O.filters.restore();
      O.filters.convertSmart();
      await O.filters.apply('mosaic', { cell: 8 });
      const smart = f.sfSrc === a.id && f.sf.length === 1 && f.asset !== a.id;
      f.sf[0].on = false; await O.filters.rerun(O.filters.targets()[0]);
      return blurred && smart && f.asset === a.id ? 'blur, smart mosaic, off' : false;
    });
    await step('templates: every category and layout builds', () => {
      const st = (O.gallery.STYLES[3] || O.gallery.STYLES[0]).k;
      let frames = 0, layers = 0; const bad = [];
      // the board's 1000 have a step of their own
      for (const c of O.templates.CATS.filter(x => !(x[7] && x[7].kt))) for (const lay of c[4]) {
        fresh();
        try { const fs = O.templates.make(c[0], lay, st, { x: 0, y: 0 }); frames += fs.length; layers += fs.reduce((a, f) => a + f.children.length, 0); if (!fs.length || fs.some(f => f.children.length < 2)) bad.push(c[0] + '/' + lay); } catch (e) { bad.push(c[0] + '/' + lay + ': ' + e.message); }
      }
      return bad.length ? bad.slice(0, 4).join(' | ') && false : frames + ' frames, ' + layers + ' layers';
    });
    await step('templates: 1000 ideas (50 kinds × 20 styles)', () => {
      const TP = O.templates, all = TP.items('ideas', 'all', '');
      const groups = TP.IDEA_GROUPS.map(g => TP.items('ideas:' + g, 'all', '').length);
      if (all.length !== 1000 || new Set(all.map(x => x.key)).size !== 1000 || groups.reduce((a, b) => a + b, 0) !== 1000) throw new Error('ideas ' + all.length + ' unique ' + new Set(all.map(x => x.key)).size + ' groups ' + groups.join(','));
      return '1000 ideas: ' + groups.join(' + ');
    });
    await step('templates: 1000 Pinterest-style pins (50 kinds × 20 styles), each builds with photos and a title', () => {
      const TP = O.templates, all = TP.items('pins', 'all', '');
      const groups = TP.PIN_GROUPS.map(g => TP.items('pins:' + g, 'all', '').length);
      if (all.length !== 1000 || new Set(all.map(x => x.key)).size !== 1000 || groups.reduce((a, b) => a + b, 0) !== 1000) throw new Error('pins ' + all.length + ' groups ' + groups.join(','));
      const bad = [];
      for (const it of all) {
        const { svg, W, H } = TP.svg(it.cat, it.lay, it.st, 0, { idp: 'stp', thumb: true });
        const title = O.esc(O.t(TP.cat(it.cat)[5].title)).split(' ')[0];
        // the typographic quote and the paper checklist have no photo by design
        const needsPhoto = !/^p-(quote|checklist)$/.test(it.lay);
        if (W !== 1000 || H !== 1500 || (needsPhoto && !/<image /.test(svg)) || !svg.toLowerCase().includes(title.toLowerCase())) bad.push(it.key);
      }
      if (bad.length) throw new Error(bad.length + ' bad, e.g. ' + bad.slice(0, 3).join(', '));
      return '1000 pins: ' + groups.join(' + ');
    });
    await step('templates: 1000 of the «VIBSma Templates» board (10 formats, 22 layouts), each builds; texts stay on the page', () => {
      const TP = O.templates, all = TP.items('kt', 'all', '');
      const fm = Object.keys(TP.KFORMATS).map(f => TP.items('kt:' + f, 'all', '').length);
      if (all.length !== 1000 || new Set(all.map(x => x.key)).size !== 1000 || fm.reduce((a, b) => a + b, 0) !== 1000) throw new Error('kt ' + all.length + ' formats ' + fm.join(','));
      if (!TP.items('kt', 'all', 'wedding').length || !TP.items('kt', 'all', '', { sty: 'luxe', nic: 'food' }).every(x => TP.cat(x.cat)[7].kt.style === 'luxe')) throw new Error('search / filters');
      const bad = [];
      for (const it of all) {
        const cat = TP.cat(it.cat), { svg, W, H } = TP.svg(it.cat, it.lay, it.st, 0, { idp: 'skt', thumb: true });
        if (W !== cat[2] || H !== cat[3] || !/<text /.test(svg) || /NaN|undefined|Infinity/.test(svg)) bad.push(it.key);
      }
      // the first template of every layout becomes a frame of layers; the line breaks are fixed, so heights are known
      const lays = new Set();
      for (const it of all) {
        if (lays.has(it.lay)) continue;
        lays.add(it.lay); fresh();
        const [f] = TP.make(it.cat, it.lay, it.st, { x: 0, y: 0 });
        if (!f || f.children.length < 3) { bad.push(it.key + ' layers'); continue; }
        // (a tight line height lets the text box, not the letters, reach a little past the edge)
        const tol = f.h * 0.02;
        model.walk(f.children, n => { if (n.type !== 'text') return; const bb = model.worldBounds(n); if (bb.y < -tol || bb.y + bb.h > f.h + tol) bad.push(it.key + ' «' + n.name + '» ' + Math.round(bb.y) + '…' + Math.round(bb.y + bb.h) + ' of ' + f.h); });
      }
      if (bad.length) throw new Error(bad.length + ' bad, e.g. ' + bad.slice(0, 4).join(' | '));
      return '1000 board templates: ' + fm.join(' + ') + ', ' + lays.size + ' layouts as frames';
    });
    await step('templates: 100 Pinterest-style + 100 premium résumés, text stays on the A4 page', () => {
      const TP = O.templates, a = TP.items('cvpin', 'all', ''), b = TP.items('cvpro', 'all', '');
      if (a.length !== 100 || b.length !== 100 || new Set(a.concat(b).map(x => x.key)).size !== 200 || b.some(x => !x.prem)) throw new Error('cv ' + a.length + '/' + b.length);
      if (TP.items('resume', 'all', '').length < 200) throw new Error('resume list');
      const over = [];
      for (const [id, , , lay] of TP.CVS) for (const si of [0, 7, 15]) {
        fresh();
        const st = (O.gallery.STYLES[si] || O.gallery.STYLES[0]).k;
        const [f] = TP.make('cvk-' + id, 'cvx-' + lay, st, { x: 0, y: 0 });
        if (!f.resume) over.push(id + ': not a résumé');
        model.walk(f.children, n => { if (n.type !== 'text') return; const bb = model.worldBounds(n); if (bb.y + bb.h > f.h + 3 || bb.x + bb.w > f.w + 3) over.push(id + '/' + st + ' «' + n.name + '» ' + Math.round(bb.y + bb.h) + '×' + Math.round(bb.x + bb.w)); });
      }
      if (over.length) throw new Error(over.length + ' overflow: ' + over.slice(0, 4).join(' | '));
      return '100 + 100, 20 layouts × 3 styles fit A4';
    });
    await step('ATS check: ATS template scores high, two columns warned', () => {
      fresh(); const st = O.gallery.STYLES[0].k;
      const [a] = O.templates.make('resume', 'cv-ats', st, { x: 0, y: 0 });
      const ra = O.ats.analyze(a, 'Marketing manager with Google Analytics, SEO, Meta Ads and Figma. Email marketing and team management.');
      const [b] = O.templates.make('resume', 'cv-modern', st, { x: 800, y: 0 });
      const rb = O.ats.analyze(b, '');
      const single = ['cv-ats', 'cv-classic', 'cv-minimal', 'cv-elegant', 'cv-bold'].filter(l => { const [f] = O.templates.make('resume', l, st, { x: 0, y: 2000 }); return O.ats.analyze(f, '').checks.find(c => c.id === 'columns').level !== 'ok'; });
      const colWarn = rb.checks.find(c => c.id === 'columns').level === 'warn' && !single.length;
      if (single.length) throw new Error('single-column layouts flagged as columns: ' + single.join(', '));
      if (!(ra.score >= 75 && colWarn)) throw new Error(`scores ${ra.score}/${rb.score} cols=${colWarn} :: ` + ra.checks.filter(c => c.level !== 'ok').map(c => c.id + ':' + c.level).join(', ') + ' :: kw ' + (ra.kw ? ra.kw.missing.join('/') : ''));
      return 'ATS ' + ra.score + ', modern ' + rb.score + ', keywords ' + Math.round(ra.kw.share * 100) + '%';
    });
    await step('Photoshop-like tooltip on a tool', async () => {
      O.tips.hide();
      const b = O.$('#toolbar [data-tool="pen"]') || O.$('#toolbar [data-tool]');
      b.dispatchEvent(new PointerEvent('pointerover', { bubbles: true }));
      await wait(700);
      const tip = O.$('.ps-tip');
      const ok = tip && !tip.hidden && tip.classList.contains('rich') && tip.textContent.length > 20;
      O.tips.hide();
      return ok ? tip.textContent.slice(0, 40) : false;
    });
    await step('gallery: 10 000 new styles (50 aesthetics × 10 moods × 20 colours) besides the 100: readable, named in every language, they build', () => {
      const GL = O.gallery, xs = GL.STYLES.filter(s => s.x), lum = O.color.luminance, bad = [];
      if (GL.CORE.length !== 100 || xs.length !== 10000 || new Set(GL.STYLES.map(s => s.k)).size !== GL.STYLES.length || new Set(xs.map(s => s.x.a + '|' + s.x.m)).size !== 500) throw new Error('styles ' + GL.CORE.length + ' + ' + xs.length);
      for (const s of xs) if (Math.abs(lum(s.pal[2]) - lum(s.pal[0])) < 0.45 || Math.abs(lum(s.pal[3]) - lum(s.pal[0])) < 0.18 || ['en', 'ru', 'de'].some(l => O.tIn(l, s.n) === s.n) || !O.fonts.get(s.f[0]) || !O.fonts.get(s.f[1])) bad.push(s.k);
      // every base style (aesthetic × mood) renders; one style of every aesthetic becomes a frame of layers
      const bases = new Map();
      xs.forEach(s => { const b = s.x.a + '|' + s.x.m; if (!bases.has(b)) bases.set(b, s); });
      for (const s of bases.values()) { const { svg } = GL.svg(s, 1080, 1350); if (!/<text /.test(svg) || /NaN|undefined/.test(svg)) bad.push(s.k + ' svg'); }
      const aes = new Set();
      for (const s of xs) { if (aes.has(s.x.a)) continue; aes.add(s.x.a); fresh(); const fs = GL.make(s.k, 'post', { x: 0, y: 0 }); if (!fs.length || fs[0].children.length < 3) bad.push(s.k + ' frame'); }
      if (GL.search('гуцул', Infinity).length !== 200 || GL.search('', Infinity).length !== 10100) bad.push('search');
      if (O.templates.items('all', 'all', '').some(it => it.st.startsWith('x-'))) bad.push('the template catalogue picks new styles');
      if (bad.length) throw new Error(bad.length + ' bad, e.g. ' + bad.slice(0, 4).join(' | '));
      return xs.length + ' new + ' + GL.CORE.length + ' styles, ' + bases.size + ' bases render, ' + aes.size + ' aesthetics as frames';
    });
    await step('design styles: 1000 apply to shapes and text, previews render', () => {
      const GS = O.gstyles; const bad = []; fresh();
      const r = mkRect(0, 0, 120, 80), tx = model.create('text', { text: 'Стиль', size: 40 }); model.insert(tx, model.page());
      for (const st of GS.BUILTIN) { try { GS.applyTo(r, st); GS.applyTo(tx, st); O.render.svg([r, tx], {}); if (!/<svg/.test(GS.preview(st)) || !st.cat) bad.push(st.id); } catch (e) { bad.push(st.id + ': ' + e.message); } }
      if (GS.BUILTIN.length !== 1000 || bad.length) throw new Error(`styles ${GS.BUILTIN.length} :: ${bad.slice(0, 4).join(' | ')}`);
      return GS.BUILTIN.length + ' styles in ' + new Set(GS.BUILTIN.map(s => s.cat)).size + ' categories';
    });
    await step('backgrounds: 100, valid SVG, insert into a frame', () => {
      const BG = O.backgrounds; const bad = [];
      for (const b of BG.LIST) { const doc = new DOMParser().parseFromString(BG.svg(b.id, 400, 250), 'image/svg+xml'); if (doc.getElementsByTagName('parsererror').length) bad.push(b.id); }
      fresh(); const f = model.create('frame', { w: 800, h: 500, fills: [O.paint.solid('#FFFFFF')] }); model.insert(f, model.page()); O.select([f.id]);
      BG.insert('aurora-2'); const g = f.children[0];
      if (BG.LIST.length !== 100 || bad.length || !g || !g.bgOf || !g.children.length) throw new Error(`count ${BG.LIST.length} bad ${bad.join(',')} group ${!!(g && g.bgOf)}`);
      return '100 backgrounds, ' + g.children.length + ' layers in «aurora-2»';
    });
    await step('video: 100 effects render', async () => {
      const VE = O.video; fresh(); delete O.state.doc.video;
      const cv = document.createElement('canvas'); cv.width = 64; cv.height = 36; const g = cv.getContext('2d'); g.fillStyle = '#E44'; g.fillRect(0, 0, 32, 36); g.fillStyle = '#44E'; g.fillRect(32, 0, 32, 36);
      const a = await O.io.addAsset(cv.toDataURL('image/png'), 'v'); const c = VE.addAsset(a.id, {});
      VE.addText(0);
      await wait(100);
      const out = document.createElement('canvas'); out.width = 320; out.height = 180; const ctx = out.getContext('2d');
      const bad = [];
      for (const [id] of VE.EFFECTS) { VE.doc().clips.forEach(x => { x.fx = [id]; }); try { VE.renderAt(ctx, 1.2, 320, 180); } catch (e) { bad.push(id + ': ' + e.message); } }
      if (VE.EFFECTS.length !== 100 || bad.length) throw new Error(`effects ${VE.EFFECTS.length} :: ${bad.slice(0, 3).join(' | ')}`);
      void c; return '100 effects';
    });
    await step('video: 100 templates apply and render', () => {
      const VE = O.video; fresh(); delete O.state.doc.video;
      const out = document.createElement('canvas'); out.width = 320; out.height = 180; const ctx = out.getContext('2d');
      let clips = 0; const bad = [];
      for (const tp of VE.TEMPLATES) { try { VE.applyTemplate(tp.id, 'replace'); const v = VE.doc(); if (v.clips.length < 2 || !v.clips.some(x => x.kind === 'text')) bad.push(tp.id); clips += v.clips.length; VE.renderAt(ctx, 0.8, 320, 180); } catch (e) { bad.push(tp.id + ': ' + e.message); } }
      if (VE.TEMPLATES.length !== 100 || bad.length) throw new Error(`templates ${VE.TEMPLATES.length} :: ${bad.slice(0, 3).join(' | ')}`);
      return '100 templates, ' + clips + ' clips';
    });
    await step('audio: 100 track templates build', () => {
      const ST = O.studio; let notes = 0; const bad = [];
      for (const tp of ST.TEMPLATES) { try { const s = ST.buildTemplate(tp.id); const n = s.patterns.reduce((a, p) => a + Object.values(p.notes).reduce((b, l) => b + l.length, 0) + Object.values(p.steps).reduce((b, l) => b + l.filter(Boolean).length, 0), 0); if (s.patterns.length !== 2 || s.channels.length < 4 || n < 20 || s.patterns.some(p => Object.values(p.steps).some(l => l.length !== p.len))) bad.push(tp.id); notes += n; } catch (e) { bad.push(tp.id + ': ' + e.message); } }
      if (ST.TEMPLATES.length !== 100 || bad.length) throw new Error(`templates ${ST.TEMPLATES.length} :: ${bad.slice(0, 3).join(' | ')}`);
      ST.load(ST.buildTemplate(ST.TEMPLATES[7].id));
      return '100 templates, ' + notes + ' notes and hits';
    });
    await step('animation: 100 templates apply', () => {
      const A = O.anim; const bad = [];
      for (const tp of A.TEMPLATES) { fresh(); A.time = 0; const n = mkRect(0, 0, 80, 80); n.strokes = [O.paint.solid('#000000')]; n.sw = 2; O.select([n.id]); try { A.applyTemplate(tp.id); const mid = A.stateAt(n, tp.keys[tp.keys.length - 1][0] / 2); if (!n.anim || n.anim.length < 2 || !mid) bad.push(tp.id); } catch (e) { bad.push(tp.id + ': ' + e.message); } }
      if (A.TEMPLATES.length !== 100 || bad.length) throw new Error(`templates ${A.TEMPLATES.length} :: ${bad.slice(0, 3).join(' | ')}`);
      return '100 templates';
    });
    await step('join and unite: open paths chain, closed shapes unite, lines never vanish', () => {
      const mk = (pts, closed, fill) => { const n = model.create('path', { subpaths: [{ closed: !!closed, pts: pts.map(([x, y]) => ({ x, y })) }], fills: fill ? [O.paint.solid(fill)] : [], strokes: [O.paint.solid('#000000')], sw: 4 }); model.insert(n, model.page()); return n; };
      const run = (make, cmd) => { fresh(); const ns = make(); O.select(ns.map(n => n.id)); O.run(cmd); return model.page().children; };
      const three = () => [mk([[0, 0], [100, 0]]), mk([[110, 0], [200, 50]]), mk([[300, 0], [210, 50]])];
      const closed = () => [mk([[0, 0], [100, 0], [100, 100]], true, '#FF0000'), mk([[50, 50], [150, 50], [150, 150]], true, '#00FF00')];
      const out = [];
      for (const cmd of ['join', 'pfUnite', 'boolUnion']) {
        const a = run(three, cmd);
        if (a.length !== 1 || a[0].type !== 'path' || a[0].subpaths.length !== 1 || a[0].subpaths[0].pts.length !== 6) throw new Error(cmd + ' lines → ' + a.map(n => n.type + (n.subpaths ? n.subpaths.map(s => s.pts.length).join('+') : '')).join(','));
        out.push(cmd + ' 3 lines → 1');
      }
      const c = run(closed, 'join');
      if (c.length !== 1 || c[0].subpaths[0].pts.length < 5) throw new Error('closed join ' + c.length);
      // a line and a square: Unite keeps the line as a band painted with its stroke colour
      fresh(); const sq = model.create('rect', { w: 80, h: 80, fills: [O.paint.solid('#3366FF')] }); model.insert(sq, model.page()); const ln = mk([[40, 40], [200, 40]]);
      O.select([sq.id, ln.id]); O.run('pfUnite');
      const u = model.page().children;
      if (u.length !== 1 || model.worldBounds(u[0]).w < 195) throw new Error('line+square ' + u.length + ' w=' + (u[0] && model.worldBounds(u[0]).w));
      return out.join(', ') + ', closed → united, line+square w=' + Math.round(model.worldBounds(u[0]).w);
    });
    await step('Illustrator Object menu: distribute, ungroup all, repeat, intertwine, live paint, envelope, graph, mesh, wrap', async () => {
      const OM = O.objmenu, done = [];
      fresh();
      const r = (x, y, c, w = 40) => { const n = model.create('rect', { w, h: w, m: M.translate(x, y), fills: [O.paint.solid(c)] }); model.insert(n, model.page()); return n; };
      const a = r(0, 0, '#F00'), b = r(37, 80, '#0F0'), c = r(300, 10, '#00F');
      O.select([a.id, b.id, c.id]); O.run('distLeft');
      if (Math.abs(model.worldBounds(b).x - 150) > 0.5) throw new Error('distribute x=' + model.worldBounds(b).x);
      done.push('distribute');
      O.select([a.id, b.id]); ops.group(); const g1 = O.sel()[0]; O.select([g1.id, c.id]); ops.group();
      O.select([]); O.run('ungroupAll');
      if (model.page().children.some(n => n.type === 'group')) throw new Error('ungroup all');
      done.push('ungroup all');
      O.select([a.id]); OM.repeat('radial', { count: 6 });
      const rg = O.sel()[0]; if (!rg.repeat || rg.children.length !== 6) throw new Error('repeat ' + rg.children.length);
      OM.repeatRelease(rg);
      if (model.page().children.filter(n => n.type === 'rect').length !== 3) throw new Error('repeat release');
      done.push('repeat');
      fresh();
      const ring = (x) => { const n = model.create('ellipse', { w: 100, h: 100, m: M.translate(x, 0), fills: [], strokes: [O.paint.solid('#222')], sw: 10 }); model.insert(n, model.page()); return n; };
      const e1 = ring(0), e2 = ring(60);
      O.select([e1.id, e2.id]); OM.intertwine(0);
      const tw = O.sel()[0]; if (!tw.intertwine || !tw.children.some(n => n.twPiece)) throw new Error('intertwine');
      done.push('intertwine');
      fresh();
      const sq = r(0, 0, '#FC0', 100), ln = model.create('path', { subpaths: [{ closed: false, pts: [{ x: -10, y: 50 }, { x: 110, y: 50 }] }], fills: [], strokes: [O.paint.solid('#000')], sw: 2 }); model.insert(ln, model.page());
      O.select([sq.id, ln.id]); OM.livePaint();
      const lp = O.sel()[0]; if (!lp.livePaint || lp.children.filter(n => n.name.startsWith(O.t('Грань'))).length !== 2) throw new Error('live paint faces ' + (lp.children || []).length);
      done.push('live paint 2 faces');
      fresh();
      const er = r(0, 0, '#09F', 200); O.select([er.id]);
      const before = model.worldBounds(er).h;
      await new Promise(res => { const d = O.ui.dialog; O.ui.dialog = spec => { O.ui.dialog = d; Promise.resolve(spec.apply({ style: 'arc', dir: 'h', bend: 60, hd: 0, vd: 0 })).then(res); return { el: document.createElement('div'), close() {} }; }; OM.envWarpDialog(); });
      const warped = O.sel()[0] || model.page().children[0];
      if (warped.type !== 'path' || !warped.envSrc || Math.abs(model.worldBounds(warped).h - before) < 5) throw new Error('envelope h=' + model.worldBounds(warped).h);
      O.select([warped.id]); OM.envRelease();
      if (model.page().children[0].type !== 'rect') throw new Error('envelope release');
      done.push('envelope');
      fresh();
      const gr = model.create('group', { name: 'g', graph: { type: 'column', w: 300, h: 200, data: 'A, 1\nB, 3\nC, 2' } }); OM.buildGraph(gr, gr.graph); model.insert(gr, model.page());
      if (gr.children.filter(n => n.type === 'rect').length !== 3) throw new Error('graph bars');
      gr.graph.type = 'pie'; OM.buildGraph(gr, gr.graph); model.reindex();
      if (gr.children.filter(n => n.type === 'path').length !== 3) throw new Error('pie slices');
      done.push('graph');
      fresh();
      const ms = r(0, 0, '#3A7BD5', 120);
      await OM.mesh(ms, { rows: 3, cols: 3, look: 'center', hi: 80, hc: '#FFFFFF' });
      if (ms.fills[0].type !== 'image' || !ms.mesh) throw new Error('mesh');
      done.push('mesh');
      fresh();
      const tx = model.create('text', { text: 'Lorem ipsum dolor sit amet '.repeat(30), width: 400, size: 14, m: M.translate(0, 0) }); model.insert(tx, model.page());
      const ob = r(0, 60, '#F0A', 120);
      O.select([tx.id, ob.id]); OM.wrapMake(10);
      if (!tx.wrap || !tx.next) throw new Error('wrap');
      const parts = tx.wrap.parts.length;
      OM.wrapRelease(tx);
      if (tx.wrap || tx.next || model.page().children.length !== 2) throw new Error('wrap release');
      done.push('text wrap ' + (parts + 1) + ' frames');
      fresh(); r(0, 0, '#000', 50); O.select([model.page().children[0].id]); OM.trimMarks();
      if (O.sel()[0].children.length !== 8) throw new Error('trim marks');
      done.push('trim marks');
      return done.join(', ');
    });
    await step('Photoshop Image menu: adjustments, image size, canvas size, rotation, trim; print photos as TIFF 300 dpi', async () => {
      const IM = O.imagemenu, FLx = O.filters, done = [];
      fresh();
      const cv = document.createElement('canvas'); cv.width = 300; cv.height = 200; const g = cv.getContext('2d');
      g.fillStyle = '#2050A0'; g.fillRect(0, 0, 300, 200); g.fillStyle = '#F0C040'; g.fillRect(50, 40, 120, 80);
      const a = await O.io.addAsset(cv.toDataURL('image/png'), 'test');
      const n = model.create('rect', { name: 'Фото', w: 300, h: 200, fills: [Object.assign(O.paint.image(a.id), { mode: 'stretch' })] }); model.insert(n, model.page()); O.select([n.id]);
      const im = await FLx.load(a.id);
      for (const id of Object.keys(FLx.defs).filter(k => /^(adj|mode)/.test(k))) { const f = FLx.defs[id]; const p = {}; f.params.forEach(pr => { p[pr.k] = pr.v; }); const out = f.run(H2(im), p); if (!out || out.width !== im.width) throw new Error(id); }
      function H2(x) { return new ImageData(new Uint8ClampedArray(x.data), x.width, x.height); }
      done.push(Object.keys(FLx.defs).filter(k => /^(adj|mode)/.test(k)).length + ' adjustments & modes');
      await FLx.apply('adjInvert', {});
      if (n.fills[0].asset === a.id) throw new Error('invert did not change the photo');
      await IM.rotate('cw');
      const rn = O.sel()[0], ra = O.state.doc.assets[rn.fills[0].asset];
      if (ra.w !== 200 || ra.h !== 300) throw new Error('rotate ' + ra.w + '×' + ra.h);
      done.push('rotate 90°');
      // TIFF encoder: header, size and 300 dpi
      const tif = IM.tiff(new ImageData(new Uint8ClampedArray(4 * 4 * 4).fill(255), 4, 4), 300, true);
      const dv = new DataView(await tif.arrayBuffer());
      if (dv.getUint16(0, true) !== 0x4949 || dv.getUint16(2, true) !== 42) throw new Error('tiff header');
      done.push('TIFF ' + tif.size + ' B (CMYK)');
      // a print document: photos become TIFF, sized at 300 dpi
      fresh();
      O.state.doc.printImages = { fmt: 'tiff', dpi: 300, ppi: 72, color: 'rgb' };
      const big = document.createElement('canvas'); big.width = 1500; big.height = 1000; big.getContext('2d').fillStyle = '#C33'; big.getContext('2d').fillRect(0, 0, 1500, 1000);
      const blob = await new Promise(r => big.toBlob(r, 'image/jpeg', 0.9));
      const pn = await O.io.importImage(new File([blob], 'photo.jpg', { type: 'image/jpeg' }));
      const pa = O.state.doc.assets[pn.fills[0].asset];
      if (pa.fmt !== 'tiff' || !/\.tif$/.test(pa.name) || Math.abs(pn.w - 360) > 1) throw new Error('print import ' + pa.fmt + ' ' + pa.name + ' w=' + pn.w);
      // shrink the photo on the page: more than 300 ppi → resampled to 300
      model.applyWorld(pn, M.scale(0.5, 0.5), 'resize'); O.history.commit('scale');
      await IM.print.normalize();
      const na = O.state.doc.assets[pn.fills[0].asset];
      if (Math.abs(na.w - 750) > 2 || na.dpi !== 300) throw new Error('normalize ' + na.w + ' dpi ' + na.dpi);
      delete O.state.doc.printImages;
      done.push('print import 1500 px → 360 pt (300 dpi), resampled to 750 px when halved');
      return done.join(', ');
    });
    await step('account dialog (sign in / sign up tabs)', async () => {
      O.account.dialog({ mode: 'up' }); await wait(30);
      const d = O.$('.acct-dlg'); const ok = d && d.querySelector('.acct-tabs') && !d.querySelector('.acct-name').closest('label').hidden && d.querySelector('.acct-pw');
      O.$$('.dlg-back').forEach(x => x.remove());
      return !!ok;
    });
    await step('feature guide lists every command, search and «Show where»', async () => {
      O.guide.open({ sec: 'ui', q: '' }); await wait(30);
      const n = O.$$('.gd-nav button').reduce((a, b) => a + (+b.querySelector('i').textContent || 0), 0);
      const inp = O.$('.gd-q input'); inp.value = 'злити'; inp.dispatchEvent(new Event('input'));
      const hit = O.$('.gd-it[data-k="cmd:pfMerge"]');
      if (!hit) throw new Error('search «злити» found nothing');
      hit.querySelector('[data-ga="show"]').click(); await wait(30);
      const lit = O.$('.gd-spot.pass') && O.$('.menu .mi[data-cmd="pfMerge"]');
      O.guide.closeSpot(); O.ui.closeMenus();
      if (O.$('.gd-back')) throw new Error('guide still open after «Show where»');
      return n > 600 && lit ? n + ' entries, menu path opened to «Злити»' : 'entries=' + n + ' lit=' + !!lit && false;
    });
    await step('spotlight tour walks every step', async () => {
      O.guide.tour(); await wait(20);
      let steps = 0;
      while (O.$('.gd-spot') && steps < 40) { steps++; const b = O.$('.gd-card [data-gb="next"], .gd-card [data-gb="done"]'); b.click(); await wait(5); }
      return !O.$('.gd-spot') && steps >= 8 ? steps + ' steps' : false;
    });
    await step('no runtime errors overall', () => errors.length === 0 ? '' : errors.slice(0, 5).join(' || ') && false);

    // leave the UI in a nice state
    O.run('sample');
    O.select([]);
    setTimeout(() => O.view.fit(null, 80, 1), 0);
    const pre = document.createElement('pre');
    pre.id = 'selftest-out';
    pre.textContent = `SELFTEST pass=${pass} fail=${fail}\n` + out.join('\n') + (errors.length ? '\n\nERRORS:\n' + errors.join('\n') : '');
    pre.style.cssText = 'position:fixed;left:8px;top:52px;z-index:5000;max-height:80vh;overflow:auto;background:rgba(0,0,0,.85);color:#9f9;font:11px monospace;padding:8px;border-radius:6px;max-width:60vw;white-space:pre-wrap;';
    document.body.appendChild(pre);
    document.title = `SELFTEST ${fail ? 'FAIL' : 'OK'} ${pass}/${pass + fail}`;
    return { pass, fail, out };
  };

  // visual scenarios for screenshots: index.html?fresh&shot=select&theme=light
  const params = new URLSearchParams(location.search);
  if (params.has('shot')) {
    window.addEventListener('load', () => setTimeout(() => {
      const theme = params.get('theme');
      if (theme) document.documentElement.dataset.theme = theme;
      const { model } = O;
      const find = name => { let f = null; model.walk(model.page().children, n => { if (!f && n.name === name) f = n; }); return f; };
      const shot = params.get('shot');
      // screenshots of the VIBSma additions: ?shot=run&cmd=…, ?shot=photo&cmd=fl:…, ?shot=tpl&cat=…&lay=…
      if (shot === 'run' && params.get('cmd')) setTimeout(() => O.run(params.get('cmd')), 600);
      // feature guide and tour: ?shot=guide&sec=m:2&q=…, ?shot=tour&step=7, ?shot=guideshow&q=злити
      if (shot === 'guide') setTimeout(() => O.guide.open({ sec: params.get('sec') || 'ui', q: params.get('q') || '' }), 600);
      if (shot === 'tour') setTimeout(() => O.guide.tour(+params.get('step') || 0), 600);
      if (shot === 'guideshow') setTimeout(() => { O.guide.open({ q: params.get('q') || '' }); setTimeout(() => { const b = O.$('.gd-it [data-ga="show"]'); if (b) b.click(); }, 100); }, 600);
      if (shot === 'tplg') setTimeout(() => O.templates.open({ cat: params.get('cat') || 'ideas' }), 600);
      // the style gallery: ?shot=gal&sec=x (a section) or &style=<key> (a style's page)
      if (shot === 'gal') setTimeout(() => O.gallery.open({ sec: params.get('sec') || 'all', style: params.get('style') || null, fmt: params.get('fmt') || undefined }), 600);
      if (shot === 'tplone') { model.load(model.newDoc()); setTimeout(() => { const fs = O.templates.make(params.get('cat'), params.get('lay'), O.gallery.STYLES[+params.get('si') || 0].k, { x: 0, y: 0 }); O.select(fs.map(f => f.id)); setTimeout(() => O.view.fit(model.selBounds(fs), 40, 1), 300); }, 600); }
      if (shot === 'vtpl') setTimeout(() => { O.setMode('video'); setTimeout(() => { O.video.applyTemplate(params.get('id') || 'intro-1', 'replace'); O.video.showBin(params.get('tab') || 'vtpl'); setTimeout(() => O.video.seek(+params.get('at') || 1.5), 400); }, 200); }, 600);
      if (shot === 'photo') {
        model.load(model.newDoc());
        const cv = document.createElement('canvas'); cv.width = 900; cv.height = 600; const g = cv.getContext('2d');
        const gr = g.createLinearGradient(0, 0, 900, 600); gr.addColorStop(0, '#1E5BB8'); gr.addColorStop(0.55, '#F2A65A'); gr.addColorStop(1, '#2C1A4D'); g.fillStyle = gr; g.fillRect(0, 0, 900, 600);
        g.fillStyle = '#FFE9B0'; g.beginPath(); g.arc(640, 210, 90, 0, 7); g.fill(); g.fillStyle = '#122033'; g.beginPath(); g.moveTo(0, 600); g.lineTo(260, 330); g.lineTo(470, 520); g.lineTo(700, 300); g.lineTo(900, 600); g.fill();
        g.fillStyle = '#fff'; g.font = 'bold 64px Arial'; g.fillText('VIBSma', 60, 120);
        O.io.addAsset(cv.toDataURL('image/png'), 'photo').then(a => { const n = model.create('rect', { name: 'Фото', w: 900, h: 600, fills: [O.paint.image(a.id)] }); model.insert(n, model.page()); O.select([n.id]); O.history.commit('photo'); setTimeout(() => { O.view.fit(null, 60, 1); if (params.get('cmd')) O.run(params.get('cmd')); }, 300); });
      }
      if (shot === 'tpl') { model.load(model.newDoc()); const fs = O.templates.make(params.get('cat') || 'insta', params.get('lay') || 'hero', params.get('st') || O.gallery.STYLES[+params.get('si') || 0].k, { x: 0, y: 0 }); O.select(fs.map(f => f.id)); setTimeout(() => { O.view.fit(null, 60, 1); if (params.get('cmd')) O.run(params.get('cmd')); }, 500); }
      if (shot === 'select') { const n = find('VIBSma'); O.select([n.id]); }
      if (shot === 'sun') { const n = find('Сонце'); O.select([n.id]); }
      if (shot === 'picker') { const n = find('Сонце'); O.select([n.id]); setTimeout(() => { O.panels.refresh(true); const b = O.$('[data-a="fill-pick"]'); if (b) b.click(); }, 300); }
      if (shot === 'code') { const n = find('VIBSma'); O.select([n.id]); setTimeout(() => { const L = O.layout; const a = L && L.active && L.areas().find(x => x.area === 'design'); if (a) L.setType(a.id, 'code'); else O.$('[data-rt="code"]').click(); }, 300); }
      if (shot === 'ws-anim') { O.layout.switchTo('anim'); const n = find('Сонце'); if (n) O.select([n.id]); }
      if (shot === 'ws-web') { O.layout.switchTo('web'); const f = model.page().children.find(x => x.type === 'frame'); if (f) O.select([f.id]); }
      if (shot === 'ws-split') { const L = O.layout; const c = L.areas().find(x => x.area === 'canvas'); L.split(c.id, 'v', 'history'); }
      if (shot === 'menu') { const b = O.$$('.mb-item')[2]; b.click(); setTimeout(() => { const subs = O.$$('.menu .mi.sub'); const pf = subs.find(s => s.textContent.includes('Обробка контурів')); if (pf) pf.dispatchEvent(new PointerEvent('pointerover', { bubbles: true })); }, 100); }
      if (shot === 'path') { const n = find('Близькі гори'); O.select([n.id]); O.state.edit = { id: n.id, sel: new Set(['0:1']) }; O.setTool('direct'); }
      if (shot === 'multi') { O.select(['Перо та криві', 'Обробка контурів', 'Текст по контуру'].map(find).filter(Boolean).map(n => model.parent(n).id)); }
      if (shot === 'pen') O.setTool('brush');
      if (shot === 'textedit') { const n = find('Привіт'); O.select([n.id]); O.view.setZoom(2, O.view.toScreen({ x: 700, y: 90 })); O.textEdit.start(n, { selectAll: false }); }
      if (shot === 'typeset' || shot === 'typeedit' || shot === 'typemenu') {
        // InDesign-style text: columns, drop cap, styles, list, tabs, footnote
        model.load(model.newDoc());
        const TSx = O.typeset;
        const body = 'Типографіка — мистецтво впорядкування тексту, щоб він був читабельним і гарним. Колонки, буквиці, переноси та відступи роблять верстку схожою на журнальну. Добре зверстаний текст легко читати, а погано зверстаний втомлює очі. ';
        const n = model.create('text', { name: 'Стаття', font: 'Georgia', size: 13, lh: 1.45, width: 640, cols: 3, colGap: 20, align: 'justify', hyph: true, lang: 'uk', fills: [O.paint.solid('#1E1E24')], m: O.M.translate(40, 40),
          text: 'Верстка як в InDesign\n' + body + body + '\nПереваги:\nКолонки з балансуванням\nСтилі абзаців і символів\nВиноски та кінцеві виноски' + TSx.CH.footnote + '\n' + body + body });
        n.fnotes = [{ text: 'Виноска внизу текстового фрейма.' }];
        n.pars = [{ s: 0, e: 22, align: 'left', ps: null }, { s: 22, e: 23 + body.length * 2, dcl: 3, dcc: 1 }, { s: n.text.indexOf('Колонки з'), e: n.text.indexOf('Виноски та') + 30, list: { t: 'bullet', ch: '•' }, align: 'left' }];
        n.runs = [{ s: 0, e: 21, size: 26, weight: 700, color: '#C2410C' }, { s: n.text.indexOf('Переваги'), e: n.text.indexOf('Переваги') + 9, weight: 700, smcaps: true }];
        model.insert(n, model.page());
        O.select([n.id]);
        setTimeout(() => { O.view.fit(null, 60, 1); O.panels.refresh(true, true); }, 50);
        if (params.get('cmd')) setTimeout(() => O.run(params.get('cmd')), 400);
        if (shot === 'typeedit') setTimeout(() => { O.textEdit.start(n, { selectAll: false }); setTimeout(() => O.$('#text-editor').setSelectionRange(40, 90), 30); }, 200);
        if (shot === 'typemenu') setTimeout(() => { const b = O.$$('.mb-item').find(x => x.textContent === O.t('Текст')); if (b) b.click(); setTimeout(() => { const s = O.$$('.menu .mi.sub').find(x => x.textContent.includes(O.t('Вставити символ розриву'))); if (s) s.dispatchEvent(new PointerEvent('pointerover', { bubbles: true })); }, 100); }, 300);
      }
      if (shot === 'cmdsweep') {
        // run every menu command on the sample document (with a selection and without) and report runtime errors
        setTimeout(async () => {
          const report = [];
          const skip = /^(open|save|saveAs|placeImage|importSVG|uploadFont|localFonts|present|export|exportPNG|exportJPG|exportSVG|exportPDF|copySVG|lang:|themeSystem|toggleUI|palette|new|sample|tyLinkOpen|videoEditor|studio|collab|protoPlay|animExport|pdf|pub(Export|PlaceText)|ibis|figma|account|login|signin|share)/i;
          const ids = [];
          const walk = items => items.forEach(it => { if (it === '-') return; if (typeof it === 'string') ids.push(it); else if (it.items) walk(it.items); });
          O.MENUS.forEach(([, items]) => walk(items));
          const uniq = Array.from(new Set(ids)).filter(id => !skip.test(id));
          const close = () => { O.$$('.dlg-back').forEach(d => { const b = d.querySelector('[data-b="cancel"]'); if (b) b.click(); else d.remove(); }); O.ui.closeMenus(); if (O.state.textEdit) O.textEdit.end(true); O.$$('.present, .pal-back').forEach(x => x.remove()); };
          O.run('sample');
          await new Promise(r => setTimeout(r, 800));
          const base = JSON.stringify(O.state.doc);
          for (const mode of ['sel', 'none']) {
            for (const id of uniq) {
              model.load(JSON.parse(base));
              await new Promise(r => setTimeout(r, 0));
              const page = model.page();
              if (mode === 'sel') { const ids2 = page.children.slice(0, 3).map(n => n.id); O.select(ids2); }
              else O.select([]);
              const before = errors.length;
              try { const c = O.cmds.get(id); if (c && (!c.enabled || c.enabled())) { const r = c.run(); if (r && r.then) await Promise.race([r, new Promise(res => setTimeout(res, 400))]); } }
              catch (e) { report.push(`${mode} ${id}: ${e.message}`); }
              await new Promise(r => setTimeout(r, 30));
              close();
              if (errors.length > before) report.push(`${mode} ${id}: ` + errors.slice(before).join(' | ').slice(0, 300));
            }
          }
          const pre = document.createElement('pre'); pre.id = 'sweep-out'; pre.textContent = `commands ${uniq.length}\n` + report.join('\n'); document.body.appendChild(pre);
          document.title = 'SWEEP ' + report.length;
        }, 1500);
      }
      // ?shot=openmenu&m=Зображення&sub=Коригування — a menu (and a submenu) open for a screenshot
      if (shot === 'openmenu') setTimeout(() => {
        const b = O.$$('.mb-item').find(x => x.textContent === O.t(params.get('m') || 'Об’єкт'));
        if (b) b.click();
        const s = params.get('sub');
        if (s) setTimeout(() => { const it = O.$$('.menu .mi.sub').find(x => x.textContent.trim() === O.t(s)); if (it) it.dispatchEvent(new PointerEvent('pointerover', { bubbles: true })); }, 150);
      }, 900);
      if (shot === 'menudump') {
        // the whole menu tree as text: «  label [id]»
        setTimeout(() => {
          const lines = [];
          const walk = (items, d) => items.forEach(it => { if (it === '-') return lines.push(' '.repeat(d * 2) + '—'); if (typeof it === 'string') { const c = O.cmds.get(it); lines.push(' '.repeat(d * 2) + (c ? O.cmdLabel(c) : '??') + ' [' + it + ']' + (c && c.keys && c.keys.length ? ' ' + c.keys.join(',') : '')); } else { lines.push(' '.repeat(d * 2) + '▸ ' + it.label); walk(it.items || [], d + 1); } });
          O.MENUS.forEach(([l, items]) => { lines.push('## ' + l); walk(items, 1); });
          const pre = document.createElement('pre'); pre.id = 'sweep-out'; pre.textContent = lines.join('\n'); document.body.appendChild(pre);
          document.title = 'MENUS ' + lines.length;
        }, 1500);
      }
      if (shot === 'l10n') {
        // untranslated strings of the text UI (panel sections + every menu label)
        setTimeout(() => {
          O.missing.clear();
          const n = model.create('text', { text: 'A\nB', width: 300, cols: 2, fnotes: [{ text: 'x' }], notes: [{ text: 'y' }] });
          n.text = 'A' + O.typeset.CH.footnote + O.typeset.CH.note + '\nB'; model.insert(n, model.page()); O.select([n.id]);
          O.panels.buildProps(); O.typeui.styleTab = 'c'; O.panels.buildProps(); O.typeui.styleTab = 'p';
          const walk = items => items.forEach(it => { if (it === '-') return; if (typeof it === 'string') { const c = O.cmds.get(it); if (c) O.cmdLabel(c); } else { O.t(it.label); if (it.items) walk(it.items); } });
          O.MENUS.forEach(([l, items]) => { O.t(l); walk(items); });
          const pre = document.createElement('pre'); pre.id = 'l10n-out'; pre.textContent = Array.from(O.missing).join('\n'); document.body.appendChild(pre);
          document.title = 'L10N ' + O.missing.size;
        }, 1500);
      }
      if (shot === 'zoomtext') { const n = find('Привіт'); O.select([n.id]); O.view.setZoom(2, O.view.toScreen({ x: 700, y: 90 })); }
      if (shot === 'site' || shot === 'sitehtml') {
        const devs = [{ group: 'Десктоп', name: 'Десктоп', w: 1440, h: 1024 }, { group: 'Планшет', name: 'iPad вертикально', w: 768, h: 1024 }, { group: 'Мобільний', name: 'iPhone 14/15', w: 390, h: 844 }];
        model.load(O.site.siteDoc({ devs, content: true, grids: true, name: 'Головна' }));
        if (shot === 'site') { O.setTool('adaptpen'); setTimeout(() => O.view.fit(null, 60, 1), 50); }
        else {
          const l = O.state.doc.links[0];
          const fr = document.createElement('iframe');
          const fw = +params.get('fw') || 0;
          fr.style.cssText = `position:fixed;left:0;top:0;width:${fw ? fw + 'px' : '100%'};height:100%;border:0;z-index:99999;background:#fff;box-shadow:0 0 0 1px #f0f`;
          document.body.appendChild(fr);
          fr.srcdoc = O.html.buildSite(l, {}).htmlInline;
        }
      }
      if (shot === 'pdfview') {
        (async () => {
          const frames = model.page().children.filter(n => n.type === 'frame');
          const res = await O.pdf.build(frames.map(f => [f]), { bleed: 3 * 72 / 25.4, marks: true });
          const lib = await O.pdf.loadReader();
          const pdf = await lib.getDocument({ data: res.bytes.slice(), isEvalSupported: false }).promise;
          const box = document.createElement('div');
          box.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#555;display:flex;gap:16px;padding:16px;align-items:flex-start;overflow:hidden';
          document.body.appendChild(box);
          for (let i = 1; i <= Math.min(3, pdf.numPages); i++) {
            const page = await pdf.getPage(i);
            const vp0 = page.getViewport({ scale: 1 });
            const vp = page.getViewport({ scale: Math.min(1.1, 900 / vp0.height) });
            const cv = document.createElement('canvas'); cv.width = vp.width; cv.height = vp.height;
            await page.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise;
            box.appendChild(cv);
          }
          const tag = document.createElement('div'); tag.style.cssText = 'position:fixed;left:16px;bottom:8px;color:#fff;font:12px monospace;z-index:100000'; tag.textContent = `PDF ${res.bytes.length} B, pages ${res.pages}, rasterised ${res.rastered}`; document.body.appendChild(tag);
          window.__shotReady = true;
        })().catch(e => { window.__shotReady = 'error: ' + e.message; });
      }
      if (shot === 'animpen') {
        model.load(model.newDoc());
        const f = model.create('frame', { name: 'Екран', w: 600, h: 400, m: O.M.translate(0, 0) }); model.insert(f, model.page());
        const mk = (type, name, x, y, w, c) => { const n = model.create(type, { name, w, h: w, m: O.M.translate(x, y), fills: [O.paint.solid(c)], radius: 12 }); model.insert(n, f); return n; };
        const a = mk('rect', 'Кулька', 40, 40, 60, '#FF3D9A'), b = mk('rect', 'Кулька 2', 420, 240, 120, '#0D99FF'), c = mk('ellipse', 'Кулька 3', 460, 40, 60, '#14AE5C');
        model.reindex();
        O.links.create('anim', [a.id, b.id, c.id]);
        O.setTool('animpen');
        O.links.sel = O.state.doc.links[0].id;
        setTimeout(() => O.view.fit(null, 120, 1.4), 50);
      }
      O.requestRender();
    }, 400));
  }
})();
