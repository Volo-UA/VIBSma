'use strict';
/* VIBSma — site settings. Filled once by the owner of the site, never by visitors.
   Firebase: console.firebase.google.com → your project → Project settings → «Your apps» → Web app → SDK config.
   Step-by-step instructions: FIREBASE.md. Without these values the editor works as before, offline, in the browser. */
window.VIBSMA_CONFIG = {
  firebase: {
    apiKey: '',
    authDomain: '',
    projectId: '',
    appId: '',
    messagingSenderId: ''
  },
  // the public address of the site (https://…), used in share links when the editor is opened from a file
  siteUrl: ''
};
