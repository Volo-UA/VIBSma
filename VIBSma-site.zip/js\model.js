'use strict';
/* VIBSma — document model, node tree, transforms, bounds, text layout, auto layout, history */
(function () {
  const O = window.O, M = O.M, G = O.G, R = O.R;

  const S = O.state = {
    doc: null, pageId: null, sel: [], hover: null,
    tool: 'select', edit: null, textEdit: null, enteredGroup: null,
    settings: Object.assign({
      snapPixel: true, smart: true, grid: false, gridSize: 10, snapGrid: false, rulers: true, guides: true,
      outline: false, pixelPreview: false, scaleStrokes: false, theme: 'system', snapGuides: true, returnToSelect: false
    }, O.ls.get('settings', {}))
  };
  O.saveSettings = () => O.ls.set('settings', S.settings);

  const model = O.model = {};
  const SHAPES = new Set(['rect', 'ellipse', 'polygon', 'star']);
  const CONTAINERS = new Set(['group', 'frame', 'bool']);
  model.SHAPES = SHAPES;
  model.TYPE_NAMES = {
    rect: 'Прямокутник', ellipse: 'Еліпс', polygon: 'Багатокутник', star: 'Зірка', path: 'Контур', text: 'Текст',
    group: 'Група', frame: 'Фрейм', bool: 'Булева група', instance: 'Екземпляр',
    line: 'Лінія', arrow: 'Стрілка', arc: 'Дуга', spiral: 'Спіраль', grid: 'Сітка', polar: 'Полярна сітка', component: 'Компонент', raster: 'Растровий шар'
  };
  model.isContainer = n => CONTAINERS.has(n.type);

  O.paint = {
    solid: (color, opacity = 1) => ({ type: 'solid', color: O.color.norm(color) || '#000000', opacity, visible: true }),
    linear: (a = '#FFFFFF', b = '#000000') => ({ type: 'linear', visible: true, opacity: 1, from: { x: 0, y: 0.5 }, to: { x: 1, y: 0.5 }, stops: [{ o: 0, color: a, a: 1 }, { o: 1, color: b, a: 1 }] }),
    radial: (a = '#FFFFFF', b = '#000000') => ({ type: 'radial', visible: true, opacity: 1, from: { x: 0.5, y: 0.5 }, to: { x: 1, y: 0.5 }, stops: [{ o: 0, color: a, a: 1 }, { o: 1, color: b, a: 1 }] }),
    image: asset => ({ type: 'image', visible: true, opacity: 1, asset, mode: 'fill', scale: 1 })
  };

  // ---------- document ----------
  const defaultSwatches = () => ['#000000', '#FFFFFF', '#F24822', '#FFA629', '#FFCD29', '#14AE5C', '#0D99FF', '#9747FF', '#E05A9C', '#8F8F8F']
    .map((c, i) => ({ id: O.uid(), name: O.t('Колір {n}', { n: i + 1 }), color: c }));
  model.newPage = name => ({ id: O.uid(), name, children: [], bg: null, guides: [] });
  model.newDoc = () => ({ format: 'obrys', version: 1, name: O.t('Без назви'), pages: [model.newPage(O.t('Сторінка {n}', { n: 1 }))], assets: {}, swatches: defaultSwatches(), counters: {}, fonts: [] });
  model.page = () => S.doc.pages.find(p => p.id === S.pageId) || S.doc.pages[0];
  model.isPage = x => !!x && x.type === undefined && Array.isArray(x.children) && 'guides' in x;

  // ---------- index ----------
  let index = new Map();
  model.reindex = () => {
    index = new Map();
    for (const pg of S.doc.pages) {
      const walk = (list, parent) => {
        for (const n of list) { index.set(n.id, { node: n, parent, page: pg }); if (n.children) walk(n.children, n); }
      };
      walk(pg.children, pg);
    }
  };
  model.get = id => { const e = index.get(id); return e ? e.node : null; };
  model.parent = n => { const e = index.get(typeof n === 'string' ? n : n.id); return e ? e.parent : null; };
  model.pageOf = n => { const e = index.get(typeof n === 'string' ? n : n.id); return e ? e.page : null; };
  model.exists = id => index.has(id);
  model.ancestors = n => {
    const out = [];
    let p = model.parent(n);
    while (p && !model.isPage(p)) { out.push(p); p = model.parent(p); }
    return out;
  };
  model.isAncestor = (a, n) => model.ancestors(n).includes(a);
  model.topLevel = n => { const a = model.ancestors(n); return a.length ? a[a.length - 1] : n; };
  model.worldMatrix = n => {
    let m = n.m;
    let p = model.parent(n);
    while (p && !model.isPage(p)) { m = M.mul(p.m, m); p = model.parent(p); }
    return m;
  };
  model.parentMatrix = n => { const p = model.parent(n); return p && !model.isPage(p) ? model.worldMatrix(p) : M.id(); };
  model.containerMatrix = c => (c && !model.isPage(c)) ? model.worldMatrix(c) : M.id();
  model.walk = (list, fn, parent) => {
    for (const n of list) {
      if (fn(n, parent) === false) continue;
      if (n.children) model.walk(n.children, fn, n);
    }
  };
  model.indexIn = n => { const p = model.parent(n); return p ? p.children.indexOf(n) : -1; };

  // ---------- creation ----------
  model.autoName = type => {
    const c = S.doc.counters || (S.doc.counters = {});
    c[type] = (c[type] || 0) + 1;
    return O.t(model.TYPE_NAMES[type] || type) + ' ' + c[type];
  };
  model.create = (type, props = {}) => {
    const n = {
      id: O.uid(), type, name: '', visible: true, locked: false, opacity: 1, blend: 'normal', m: M.id(),
      fills: [], strokes: [], sw: 1, sa: 'center', dash: [], cap: 'butt', join: 'miter', miter: 4, ms: 'none', me: 'none', effects: []
    };
    const gray = () => [O.paint.solid('#D9D9D9')];
    switch (type) {
      case 'rect': Object.assign(n, { w: 100, h: 100, radius: 0, fills: gray() }); break;
      case 'ellipse': Object.assign(n, { w: 100, h: 100, fills: gray() }); break;
      case 'polygon': Object.assign(n, { w: 100, h: 100, sides: 3, fills: gray() }); break;
      case 'star': Object.assign(n, { w: 100, h: 100, points: 5, inner: 0.382, fills: gray() }); break;
      case 'path': Object.assign(n, { subpaths: [], fillRule: 'nonzero', strokes: [O.paint.solid('#000000')] }); break;
      case 'text': Object.assign(n, {
        text: '', font: 'Arial', size: 24, weight: 400, italic: false, lh: null, ls: 0, align: 'left', width: null,
        deco: 'none', tcase: 'none', fills: [O.paint.solid('#000000')], path: null, pathOffset: 0
      }); break;
      case 'group': Object.assign(n, { children: [], mask: false }); break;
      case 'frame': Object.assign(n, { w: 100, h: 100, children: [], clip: true, radius: 0, fills: [O.paint.solid('#FFFFFF')], layout: null, component: false }); break;
      case 'bool': Object.assign(n, { op: 'union', children: [], fills: gray() }); break;
      case 'instance': Object.assign(n, { ref: null, w: 100, h: 100 }); break;
      case 'raster': Object.assign(n, { w: 100, h: 100, pw: 100, ph: 100, asset: null }); break;
    }
    Object.assign(n, props);
    if (!n.name) n.name = type === 'text' ? O.t('Текст') : model.autoName(type);
    return n;
  };

  // ---------- tree operations ----------
  model.insert = (n, parent, idx) => {
    parent = parent || model.page();
    const list = parent.children;
    if (idx === undefined || idx === null || idx > list.length || idx < 0) idx = list.length;
    list.splice(idx, 0, n);
    model.reindex();
    return n;
  };
  model.remove = n => {
    const p = model.parent(n);
    if (!p) return;
    const i = p.children.indexOf(n);
    if (i >= 0) p.children.splice(i, 1);
    model.reindex();
  };
  // move node into new parent keeping its visual (world) position
  model.reparent = (n, newParent, idx) => {
    const W = model.worldMatrix(n);
    model.remove(n);
    const P = model.containerMatrix(newParent);
    n.m = M.mul(M.inv(P), W);
    model.insert(n, newParent, idx);
  };
  model.cloneNode = (n, keepIds) => {
    const c = O.clone(n);
    if (!keepIds) {
      const re = x => { x.id = O.uid(); if (x.children) x.children.forEach(re); };
      re(c);
    }
    return c;
  };

  // ---------- geometry ----------
  model.localBounds = n => {
    switch (n.type) {
      case 'rect': case 'ellipse': case 'polygon': case 'star': case 'frame': case 'instance': case 'raster':
        return { x: 0, y: 0, w: n.w, h: n.h };
      case 'path': return G.pathBounds(n.subpaths) || { x: 0, y: 0, w: 0, h: 0 };
      case 'text': {
        if (n.path) { const b = G.pathBounds(n.path) || { x: 0, y: 0, w: 0, h: 0 }; return R.expand(b, n.size * 0.6); }
        // boxH: fixed height of a text frame (threaded text, InDesign style)
        const L = O.text.layout(n); return { x: 0, y: 0, w: L.w, h: n.boxH ? n.boxH : L.h };
      }
      case 'bool': {
        const r = model.boolResult(n);
        if (r && r.length) return G.pathBounds(r) || { x: 0, y: 0, w: 0, h: 0 };
        return model.childrenBounds(n, M.id()) || { x: 0, y: 0, w: 0, h: 0 };
      }
      case 'group': return model.childrenBounds(n, M.id()) || { x: 0, y: 0, w: 0, h: 0 };
    }
    return { x: 0, y: 0, w: 0, h: 0 };
  };
  model.childrenBounds = (n, m) => {
    if (n.mask && n.children.length) { const c = n.children[0]; return model.boundsIn(c, M.mul(m, c.m)); }
    let b = null;
    for (const c of n.children) if (c.visible !== false) b = R.union(b, model.boundsIn(c, M.mul(m, c.m)));
    return b;
  };
  model.boundsIn = (n, m) => {
    switch (n.type) {
      case 'path': return G.pathBounds(n.subpaths, m) || R.transform({ x: 0, y: 0, w: 0, h: 0 }, m);
      case 'ellipse': case 'polygon': case 'star': return G.pathBounds(G.shapeSubs(n), m);
      case 'bool': {
        const r = model.boolResult(n);
        if (r && r.length) return G.pathBounds(r, m);
        return model.childrenBounds(n, m) || R.transform({ x: 0, y: 0, w: 0, h: 0 }, m);
      }
      case 'group': return model.childrenBounds(n, m) || R.transform({ x: 0, y: 0, w: 0, h: 0 }, m);
      default: return R.transform(model.localBounds(n), m);
    }
  };
  model.worldBounds = n => model.boundsIn(n, model.worldMatrix(n));
  model.selBounds = nodes => { let b = null; for (const n of nodes) b = R.union(b, model.worldBounds(n)); return b; };
  // geometry of a node as subpaths in a target space (m maps node-local -> target)
  model.subsIn = (n, m) => {
    switch (n.type) {
      case 'rect': case 'ellipse': case 'polygon': case 'star': case 'frame': case 'path': case 'instance':
        return G.transformSubs(G.shapeSubs(n), m);
      case 'raster': return G.transformSubs(G.rectSub(n.w, n.h, 0), m);
      case 'bool': return G.transformSubs(model.boolResult(n) || [], m);
      case 'group': {
        if (n.mask && n.children.length) return model.subsIn(n.children[0], M.mul(m, n.children[0].m));
        return n.children.filter(c => c.visible !== false).flatMap(c => model.subsIn(c, M.mul(m, c.m)));
      }
      case 'text': {
        if (n._outline) return G.transformSubs(n._outline, m);
        return G.transformSubs(G.rectSub(model.localBounds(n).w, model.localBounds(n).h, 0), m);
      }
    }
    return [];
  };

  // ---------- boolean groups ----------
  const boolCache = new Map();
  model.boolResult = n => {
    const key = n.op + '|' + JSON.stringify(n.children.map(c => [c.m, c.visible, c.type, c.subpaths, c.w, c.h, c.radius, c.sides, c.points, c.inner, c.op, c.children, c.fillRule]));
    const hit = boolCache.get(n.id);
    if (hit && hit.key === key) return hit.subs;
    let subs = [];
    try {
      const kids = n.children.filter(c => c.visible !== false);
      let acc = null;
      for (const c of kids) {
        const it = G.toPaper(model.subsIn(c, c.m), c.fillRule);
        acc = acc ? G.boolPaper(n.op, acc, it) : it;
      }
      subs = acc ? G.fromPaper(acc) : [];
    } catch (e) { console.warn('bool failed', e); subs = []; }
    boolCache.set(n.id, { key, subs });
    if (boolCache.size > 500) boolCache.delete(boolCache.keys().next().value);
    return subs;
  };

  // ---------- transforms ----------
  const scaleRadius = (n, s) => { if (Array.isArray(n.radius)) n.radius = n.radius.map(r => r * s); else if (n.radius) n.radius *= s; };
  // everything that has a size in the style grows with the object: strokes, dashes, every effect
  // (shadows, glows, blur, Liquid Glass lens), image tiles and pattern sizes
  const scaleStyle = (n, s) => {
    if (n.sw !== undefined) n.sw *= s;
    for (const e of n.effects || []) {
      for (const k of ['x', 'y', 'blur', 'spread', 'refract', 'depth', 'rim']) if (typeof e[k] === 'number') e[k] *= s;
    }
    if (n.dash && n.dash.length) n.dash = n.dash.map(d => d * s);
    for (const p of (n.fills || []).concat(n.strokes || [])) if (p.type === 'image' && p.mode === 'tile') p.scale = (p.scale || 1) * s;
  };
  model.scaleStyle = scaleStyle;
  model.toPath = n => {
    if (n.type === 'path') return n;
    const subs = G.shapeSubs(n);
    if (!subs || !SHAPES.has(n.type)) return n;
    n.subpaths = G.cloneSubs(subs);
    n.type = 'path'; n.fillRule = 'nonzero';
    delete n.w; delete n.h; delete n.radius; delete n.sides; delete n.points; delete n.inner;
    return n;
  };
  // fold scale/skew from node matrix into geometry. mode: 'resize' | 'scale'
  model.normalize = (n, mode = 'resize', top = true) => {
    const d = M.decompose(n.m);
    const hasSkew = Math.abs(d.skew) > 1e-6;
    const sx = d.sx, sy = d.sy, ay = Math.abs(sy), fy = sy < 0 ? -1 : 1;
    if (!hasSkew && Math.abs(sx - 1) < 1e-9 && Math.abs(sy - 1) < 1e-9) return n;
    const TR = M.mul(M.translate(d.tx, d.ty), M.rotate(d.rot));
    const L = [sx, 0, Math.tan(d.skew) * sy, sy, 0, 0];
    const s = Math.sqrt(Math.abs(sx * sy));
    const scaling = mode === 'scale';
    // «Масштабувати обведення» (Design panel, nothing selected): resizing by the handles scales strokes and effects too
    const styling = scaling || (mode === 'resize' && !!(O.state && O.state.settings && O.state.settings.scaleStrokes));
    if (hasSkew && SHAPES.has(n.type)) model.toPath(n);
    switch (n.type) {
      case 'path':
        n.subpaths = G.transformSubs(n.subpaths, L);
        n.m = TR;
        if (styling) scaleStyle(n, s);
        break;
      case 'rect': case 'ellipse': case 'polygon': case 'star': case 'frame': case 'instance': case 'raster':
        if (hasSkew) break;
        n.w = Math.max(n.w * sx, 0); n.h = Math.max(n.h * ay, 0);
        n.m = M.mul(TR, M.scale(1, fy));
        if (n.type === 'instance') n.autoSize = false;
        if (scaling) scaleRadius(n, s);
        if (styling) scaleStyle(n, s);
        if (n.type === 'frame' && (scaling || !top)) {
          const Lc = M.scale(sx, ay);
          for (const c of n.children) { c.m = M.mul(Lc, c.m); model.normalize(c, mode, false); }
        }
        break;
      case 'text':
        if (hasSkew) break;
        if (scaling) {
          if (Math.abs(sx - ay) < 1e-3 * Math.max(sx, ay)) {
            n.size *= sx; n.ls *= sx;
            if (n.width !== null && n.width !== undefined) n.width *= sx;
            if (n.path) n.path = G.transformSubs(n.path, M.scale(sx, sx));
            if (n.boxH) n.boxH *= sx;
            n.m = M.mul(TR, M.scale(1, fy));
            scaleStyle(n, sx);
          }
        } else if (n.path) {
          n.path = G.transformSubs(n.path, M.scale(sx, ay));
          n.m = M.mul(TR, M.scale(1, fy));
        } else {
          if (Math.abs(sx - 1) > 1e-6 && (top || (n.width !== null && n.width !== undefined))) {
            n.width = Math.max(1, O.text.layout(n).w * sx);
          }
          if (n.boxH && Math.abs(ay - 1) > 1e-6) n.boxH = Math.max(4, n.boxH * ay);
          n.m = M.mul(TR, M.scale(1, fy));
          if (styling) scaleStyle(n, s);
        }
        break;
      case 'group': case 'bool':
        for (const c of n.children) { c.m = M.mul(L, c.m); model.normalize(c, mode, false); }
        n.m = TR;
        // a boolean group paints its own fill, stroke and effects
        if (n.type === 'bool' && styling) scaleStyle(n, s);
        break;
    }
    return n;
  };
  model.applyParent = (n, Gp, mode) => { n.m = M.mul(Gp, n.m); model.normalize(n, mode); };
  model.applyWorld = (n, Gw, mode) => {
    const P = model.parentMatrix(n);
    model.applyParent(n, M.mul(M.inv(P), M.mul(Gw, P)), mode);
  };
  model.applyLocal = (n, L, mode) => { n.m = M.mul(n.m, L); model.normalize(n, mode); };
  model.rotation = n => -O.deg(M.decompose(model.worldMatrix(n)).rot);

  // ---------- auto layout ----------
  model.layoutFrame = f => {
    const L = f.layout;
    if (!L) return;
    // layoutAbs: absolute position inside an auto layout frame (Figma: «Ignore auto layout»)
    const kids = f.children.filter(c => c.visible !== false && !c.layoutAbs);
    const pad = L.pad || [0, 0, 0, 0];
    const h = L.dir !== 'v';
    const boxes = kids.map(c => model.boundsIn(c, c.m));
    const sizes = boxes.map(b => h ? b.w : b.h);
    const crossSizes = boxes.map(b => h ? b.h : b.w);
    const n = kids.length;
    let gap = L.gap || 0;
    const sum = sizes.reduce((a, b) => a + b, 0);
    const total = sum + gap * Math.max(0, n - 1);
    const cross = crossSizes.reduce((a, b) => Math.max(a, b), 0);
    if (h) {
      if (L.wMode === 'hug') f.w = pad[3] + total + pad[1];
      if (L.hMode === 'hug') f.h = pad[0] + cross + pad[2];
    } else {
      if (L.hMode === 'hug') f.h = pad[0] + total + pad[2];
      if (L.wMode === 'hug') f.w = pad[3] + cross + pad[1];
    }
    const innerMain = h ? f.w - pad[3] - pad[1] : f.h - pad[0] - pad[2];
    const innerCross = h ? f.h - pad[0] - pad[2] : f.w - pad[3] - pad[1];
    let pos = 0;
    if (L.justify === 'center') pos = (innerMain - total) / 2;
    else if (L.justify === 'end') pos = innerMain - total;
    else if (L.justify === 'between' && n > 1) gap = (innerMain - sum) / (n - 1);
    kids.forEach((c, i) => {
      const b = boxes[i];
      let cp = 0;
      if (L.align === 'center') cp = (innerCross - crossSizes[i]) / 2;
      else if (L.align === 'end') cp = innerCross - crossSizes[i];
      const tx = h ? pad[3] + pos : pad[3] + cp;
      const ty = h ? pad[0] + cp : pad[0] + pos;
      c.m = c.m.slice(); c.m[4] += tx - b.x; c.m[5] += ty - b.y;
      pos += sizes[i] + gap;
    });
  };
  model.layoutAll = () => {
    if (O.freezeLayout) return;
    const visit = list => {
      for (const n of list) {
        if (n.children) visit(n.children);
        if (n.type === 'frame' && n.layout) model.layoutFrame(n);
      }
    };
    for (const pg of S.doc.pages) visit(pg.children);
    // instances follow their component's size unless resized by hand
    for (const pg of S.doc.pages) model.walk(pg.children, n => {
      if (n.type !== 'instance' || n.autoSize === false) return;
      const c = model.get(n.ref);
      if (c && c.type === 'frame') { n.w = c.w; n.h = c.h; }
    });
  };

  // ---------- text layout ----------
  const mctx = document.createElement('canvas').getContext('2d');
  const tcache = new Map();
  const GENERIC = new Set(['serif', 'sans-serif', 'monospace', 'cursive', 'fantasy', 'system-ui']);
  O.text = {
    family(f) { f = String(f || 'Arial').replace(/["']/g, ''); return GENERIC.has(f) ? f : `"${f}", sans-serif`; },
    css(n, size) { return `${n.italic ? 'italic ' : ''}${n.weight || 400} ${size || n.size}px ${O.text.family(n.font)}`; },
    content(n) {
      const t = n.text || '';
      if (n.tcase === 'upper') return t.toUpperCase();
      if (n.tcase === 'lower') return t.toLowerCase();
      if (n.tcase === 'title') return t.replace(/(^|\s)(\S)/g, (m, a, b) => a + b.toUpperCase());
      return t;
    },
    measure(n, s) {
      mctx.font = O.text.css(n);
      return mctx.measureText(s).width + (n.ls || 0) * s.length;
    },
    metrics(n) {
      mctx.font = O.text.css(n);
      const mt = mctx.measureText('Hgjy');
      const asc = mt.fontBoundingBoxAscent || mt.actualBoundingBoxAscent || n.size * 0.8;
      const desc = mt.fontBoundingBoxDescent || mt.actualBoundingBoxDescent || n.size * 0.2;
      return { asc, desc };
    },
    lineHeight(n) { return n.lh ? n.size * n.lh : n.size * 1.2; },
    // forget cached line breaks (after a web font finishes loading the metrics change)
    reset() { tcache.clear(); },
    layout(n) {
      const key = [n.text, n.font, n.size, n.weight, n.italic, n.lh, n.ls, n.align, n.width, n.tcase].join('\u0001');
      const hit = tcache.get(n.id);
      if (hit && hit.key === key) return hit.L;
      const content = O.text.content(n);
      const width = n.width;
      const lines = [];
      for (const para of content.split('\n')) {
        if (width === null || width === undefined) { lines.push({ t: para, last: true }); continue; }
        const tokens = para.split(/(\s+)/).filter(t => t.length);
        let line = '';
        const flush = (last) => { lines.push({ t: line.replace(/\s+$/, ''), last }); line = ''; };
        for (const tok of tokens) {
          const test = line + tok;
          if (O.text.measure(n, test.replace(/\s+$/, '')) <= width + 0.01 || line === '') {
            if (line === '' && tok.trim() && O.text.measure(n, tok) > width) {
              for (const ch of tok) {
                if (line && O.text.measure(n, line + ch) > width) flush(false);
                line += ch;
              }
            } else line = test;
          } else {
            flush(false);
            line = tok.replace(/^\s+/, '');
          }
        }
        flush(true);
      }
      const lh = O.text.lineHeight(n);
      const { asc, desc } = O.text.metrics(n);
      let maxW = 0;
      lines.forEach((l, i) => {
        l.w = O.text.measure(n, l.t);
        maxW = Math.max(maxW, l.w);
        l.y = i * lh + (lh - (asc + desc)) / 2 + asc;
      });
      const w = (width === null || width === undefined) ? Math.max(maxW, 1) : width;
      const L = { lines, w, h: Math.max(lines.length, 1) * lh, lh, asc };
      tcache.set(n.id, { key, L });
      if (tcache.size > 3000) tcache.delete(tcache.keys().next().value);
      return L;
    }
  };

  // ---------- history ----------
  const H = O.history = {
    stack: [], labels: [], idx: -1, max: 150,
    // every document field except the (append-only) asset store
    snapshot() {
      const doc = {};
      for (const k of Object.keys(S.doc)) if (k !== 'assets') doc[k] = S.doc[k];
      return JSON.stringify({ doc, pageId: S.pageId, sel: S.sel });
    },
    // fold the current state into the last undo step (used for automatic keyframes)
    amend() { model.reindex(); if (H.idx >= 0) H.stack[H.idx] = H.snapshot(); },
    reset() { H.stack = [H.snapshot()]; H.labels = [null]; H.idx = 0; },
    // label of the action that undo / redo would revert / repeat
    undoLabel() { return H.idx > 0 ? H.labels[H.idx] : null; },
    redoLabel() { return H.idx < H.stack.length - 1 ? H.labels[H.idx + 1] : null; },
    commit(label) {
      model.reindex();
      if (O.suspendCommit) { O.emit('change'); return; }
      const snap = H.snapshot();
      if (H.stack[H.idx] === snap) return;
      H.stack.length = H.idx + 1;
      H.labels.length = H.idx + 1;
      H.stack.push(snap);
      H.labels.push(label || null);
      if (H.stack.length > H.max) { H.stack.shift(); H.labels.shift(); }
      H.idx = H.stack.length - 1;
      O.emit('commit', label);
      O.emit('change');
    },
    restore(snap) {
      const s = JSON.parse(snap);
      const doc = s.doc || { pages: s.pages, swatches: s.swatches, name: s.name, counters: s.counters, fonts: s.fonts || [] };
      for (const k of Object.keys(S.doc)) if (k !== 'assets' && !(k in doc)) delete S.doc[k];
      Object.assign(S.doc, doc);
      S.pageId = s.pageId;
      model.reindex();
      S.sel = (s.sel || []).filter(id => model.exists(id));
      S.edit = null;
      O.emit('change');
      O.emit('selection');
    },
    revert() { H.restore(H.stack[H.idx]); },
    undo() { if (H.idx > 0) { H.idx--; H.restore(H.stack[H.idx]); } },
    redo() { if (H.idx < H.stack.length - 1) { H.idx++; H.restore(H.stack[H.idx]); } }
  };

  // ---------- selection helpers ----------
  O.sel = () => S.sel.map(model.get).filter(Boolean);
  O.select = (ids, add) => {
    ids = (ids || []).filter(Boolean);
    S.sel = add ? Array.from(new Set(S.sel.concat(ids))) : ids.slice();
    if (S.edit && !S.sel.includes(S.edit.id)) S.edit = null;
    O.emit('selection');
  };
  model.load = doc => {
    S.doc = doc;
    doc.pages = doc.pages && doc.pages.length ? doc.pages : [model.newPage(O.t('Сторінка {n}', { n: 1 }))];
    doc.assets = doc.assets || {}; doc.swatches = doc.swatches || defaultSwatches(); doc.counters = doc.counters || {}; doc.fonts = doc.fonts || [];
    for (const pg of doc.pages) { pg.guides = pg.guides || []; pg.children = pg.children || []; }
    S.pageId = doc.pages[0].id;
    S.sel = []; S.edit = null; S.enteredGroup = null;
    model.reindex();
    H.reset();
    O.emit('docload');
    O.emit('change');
    O.emit('selection');
  };
})();
