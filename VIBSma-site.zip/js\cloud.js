'use strict';
/* VIBSma — the account in the cloud (Firebase: Authentication + Cloud Firestore).
   · Sign up with e-mail and password (with a confirmation letter), sign in, reset the password, Google, Apple.
   · Progress is saved in the account: every project (and its photos, videos and sounds) is copied to Firestore
     after each save and comes back on any computer after signing in. Saved styles travel too.
   · Share link: «Поділитися» makes a link; everyone who opens it (and signs in) edits the project together in real
     time — changes, cursors and selections go through Firestore, so no server of our own is needed.
   Data layout (Firestore only, no Storage bucket and no CORS setup):
     users/{uid}                       profile, saved styles
     users/{uid}/projects/{pid}        project card (name, time, thumbnail, number of parts)
     users/{uid}/projects/{pid}/parts  the project JSON, compressed, in ≤ 900 KB parts
     assets/{assetId}(/parts)          photos / video / audio, written once, read by id
     shares/{shareId}(/parts, /msgs)   a shared project: snapshot + live messages */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui, idb = O.idb;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const CL = O.cloud = { user: null, status: 'off', lastSync: 0 };
  const CFG = (window.VIBSMA_CONFIG && window.VIBSMA_CONFIG.firebase) || {};
  const SDK = 'https://www.gstatic.com/firebasejs/10.12.2/';
  const PART = 900 * 1024;
  CL.configured = () => !!(CFG.apiKey && CFG.projectId && CFG.authDomain);
  const webOrigin = () => /^https?:$/.test(location.protocol);

  // ======================================================================
  // START
  // ======================================================================
  let fb = null, auth = null, db = null, boot = null;
  CL.ready = () => boot || (boot = (async () => {
    if (!CL.configured()) throw new Error(t('Вхід ще не підключено: власник сайту має вписати налаштування Firebase у js/config.js'));
    for (const f of ['firebase-app-compat.js', 'firebase-auth-compat.js', 'firebase-firestore-compat.js']) await O.loadScript(SDK + f);
    fb = window.firebase;
    if (!fb.apps.length) fb.initializeApp(CFG);
    auth = fb.auth(); db = fb.firestore();
    auth.languageCode = O.lang;
    try { await auth.setPersistence(fb.auth.Auth.Persistence.LOCAL); } catch (e) { /* file:// keeps the session in memory */ }
    await new Promise(res => { let first = true; auth.onAuthStateChanged(u => { onUser(u); if (first) { first = false; res(); } }); });
    try { await auth.getRedirectResult(); } catch (e) { console.warn(e); }
    return { fb, auth, db };
  })().catch(e => { boot = null; throw e; }));
  O.on('lang', () => { if (auth) auth.languageCode = O.lang; });

  const setStatus = (st, msg) => { CL.status = st; CL.statusMsg = msg || ''; if (st === 'ok') CL.lastSync = Date.now(); O.emit('cloud-status', st); };
  CL.profile = u => u && ({ uid: u.uid, email: u.email || '', name: u.displayName || (u.email || '').split('@')[0], picture: u.photoURL || '', verified: !!u.emailVerified, via: ((u.providerData || [])[0] || {}).providerId === 'google.com' ? 'google' : ((u.providerData || [])[0] || {}).providerId === 'apple.com' ? 'apple' : 'email', cloud: true });
  const onUser = u => {
    const was = CL.user && CL.user.uid;
    CL.user = u || null;
    if (O.account && O.account.setUser) O.account.setUser(u ? CL.profile(u) : (O.account.user() && O.account.user().cloud ? null : O.account.user()));
    O.emit('cloud-user', CL.user);
    if (u && u.uid !== was) {
      setTimeout(() => CL.syncAll().catch(e => console.warn(e)), 300);
      if (CL.afterLogin) { const fn = CL.afterLogin; CL.afterLogin = null; setTimeout(fn, 400); }
    }
    if (!u) setStatus('off');
  };

  // ======================================================================
  // AUTH
  // ======================================================================
  const ERR = {
    'auth/email-already-in-use': 'Цю адресу вже зареєстровано. Увійдіть або відновіть пароль.',
    'auth/invalid-email': 'Неправильна адреса e-mail.',
    'auth/weak-password': 'Пароль надто простий: щонайменше 6 символів.',
    'auth/wrong-password': 'Неправильний e-mail або пароль.',
    'auth/invalid-credential': 'Неправильний e-mail або пароль.',
    'auth/invalid-login-credentials': 'Неправильний e-mail або пароль.',
    'auth/user-not-found': 'Обліковий запис з такою адресою не знайдено.',
    'auth/user-disabled': 'Цей обліковий запис вимкнено.',
    'auth/too-many-requests': 'Забагато спроб. Спробуйте пізніше або відновіть пароль.',
    'auth/network-request-failed': 'Немає з’єднання з інтернетом.',
    'auth/popup-closed-by-user': 'Вікно входу закрито.',
    'auth/cancelled-popup-request': 'Вікно входу закрито.',
    'auth/popup-blocked': 'Браузер заблокував вікно входу. Дозвольте спливні вікна для сайту.',
    'auth/operation-not-allowed': 'Цей спосіб входу ще не ввімкнено на сайті.',
    'auth/unauthorized-domain': 'Цей сайт не додано до дозволених доменів входу.',
    'auth/operation-not-supported-in-this-environment': 'Вхід через Google і Apple працює, коли редактор відкрито з інтернет-адреси (https://…), а не з файлу.',
    'auth/requires-recent-login': 'Увійдіть ще раз і повторіть дію.'
  };
  CL.err = e => t(ERR[e && e.code] || 'Помилка: {msg}', { msg: (e && (e.message || e.code)) || String(e) });
  CL.signUp = async (name, email, pass) => {
    await CL.ready();
    const cred = await auth.createUserWithEmailAndPassword(email, pass);
    if (name) await cred.user.updateProfile({ displayName: name });
    try { await cred.user.sendEmailVerification(); } catch (e) { console.warn(e); }
    await cred.user.reload();
    onUser(auth.currentUser);
    return cred.user;
  };
  CL.signIn = async (email, pass) => { await CL.ready(); const c = await auth.signInWithEmailAndPassword(email, pass); return c.user; };
  const popup = async provider => {
    await CL.ready();
    try { return (await auth.signInWithPopup(provider)).user; }
    catch (e) { if (e.code === 'auth/popup-blocked' || e.code === 'auth/operation-not-supported-in-this-environment' && webOrigin()) { await auth.signInWithRedirect(provider); return null; } throw e; }
  };
  CL.google = async () => { await CL.ready(); const p = new fb.auth.GoogleAuthProvider(); p.setCustomParameters({ prompt: 'select_account' }); return popup(p); };
  CL.apple = async () => { await CL.ready(); const p = new fb.auth.OAuthProvider('apple.com'); p.addScope('email'); p.addScope('name'); p.setCustomParameters({ locale: { uk: 'uk_UA', ru: 'ru_RU', de: 'de_DE' }[O.lang] || 'en_US' }); return popup(p); };
  CL.reset = async email => { await CL.ready(); await auth.sendPasswordResetEmail(email); };
  CL.resendVerify = async () => { await CL.ready(); if (auth.currentUser) await auth.currentUser.sendEmailVerification(); };
  CL.refreshUser = async () => { await CL.ready(); if (auth.currentUser) { await auth.currentUser.reload(); onUser(auth.currentUser); } };
  CL.rename = async name => { await CL.ready(); if (auth.currentUser) { await auth.currentUser.updateProfile({ displayName: name }); onUser(auth.currentUser); } };
  CL.signOut = async () => { await CL.ready(); CL.leaveRoom(); await auth.signOut(); };

  // ======================================================================
  // BYTES: compression, parts
  // ======================================================================
  const enc = new TextEncoder(), dec = new TextDecoder();
  const pipe = async (u8, stream) => new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(stream)).arrayBuffer());
  const zip = async str => (window.CompressionStream ? { z: 1, b: await pipe(enc.encode(str), new CompressionStream('deflate-raw')) } : { z: 0, b: enc.encode(str) });
  const unzip = async (u8, z) => dec.decode(z ? await pipe(u8, new DecompressionStream('deflate-raw')) : u8);
  const dataToBytes = data => { const i = data.indexOf(','); const head = data.slice(5, i), b64 = /;base64$/.test(head); const raw = b64 ? atob(data.slice(i + 1)) : decodeURIComponent(data.slice(i + 1)); const u8 = new Uint8Array(raw.length); for (let k = 0; k < raw.length; k++) u8[k] = raw.charCodeAt(k) & 255; return { mime: head.replace(/;base64$/, '') || 'application/octet-stream', u8 }; };
  const bytesToData = (u8, mime) => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return `data:${mime};base64,${btoa(s)}`; };
  const writeParts = async (col, u8) => {
    const n = Math.max(1, Math.ceil(u8.length / PART));
    for (let i = 0; i < n; i += 8) {
      const batch = db.batch();
      for (let k = i; k < Math.min(n, i + 8); k++) batch.set(col.doc(String(k)), { b: fb.firestore.Blob.fromUint8Array(u8.subarray(k * PART, (k + 1) * PART)) });
      await batch.commit();
    }
    return n;
  };
  const readParts = async (col, n) => {
    const docs = await Promise.all(Array.from({ length: n }, (_, k) => col.doc(String(k)).get()));
    const arr = docs.map(d => { if (!d.exists) throw new Error(t('Дані в хмарі неповні')); return d.data().b.toUint8Array(); });
    const out = new Uint8Array(arr.reduce((a, b) => a + b.length, 0));
    let o = 0; for (const a of arr) { out.set(a, o); o += a.length; }
    return out;
  };

  // ---------- assets: written once, shared by projects and share links ----------
  const known = new Set(O.ls.get('cloudAssets', []));
  const remember = id => { known.add(id); if (known.size % 20 === 0 || known.size < 20) O.ls.set('cloudAssets', Array.from(known).slice(-6000)); };
  CL.putAsset = async (aid, a) => {
    if (!a || typeof a.data !== 'string' || known.has(aid)) return;
    const ref = db.collection('assets').doc(aid);
    const ex = await ref.get().catch(() => null);
    if (ex && ex.exists) { remember(aid); return; }
    const { mime, u8 } = dataToBytes(a.data);
    const meta = Object.assign({}, a); delete meta.data; delete meta.ext;
    const n = await writeParts(ref.collection('parts'), u8);
    await ref.set({ owner: CL.user.uid, n, size: u8.length, mime, m: JSON.stringify(meta), at: Date.now() });
    remember(aid);
  };
  CL.getAsset = async aid => {
    await CL.ready();
    const ref = db.collection('assets').doc(aid), d = await ref.get();
    if (!d.exists) return null;
    const v = d.data(), u8 = await readParts(ref.collection('parts'), v.n);
    remember(aid);
    return Object.assign(JSON.parse(v.m || '{}'), { data: bytesToData(u8, v.mime) });
  };
  // a document with every asset's data (from memory, the project store or the cloud)
  const fullAssets = async (doc, pid) => {
    const out = {};
    for (const [id, a] of Object.entries(doc.assets || {})) {
      if (!a) continue;
      if (typeof a.data === 'string') { out[id] = a; continue; }
      let data = pid ? await idb.get('adata', pid + '/' + id).catch(() => null) : null;
      out[id] = data ? Object.assign({}, a, { data }) : a;
    }
    return out;
  };
  const lite = doc => { const assets = {}; for (const [id, a] of Object.entries(doc.assets || {})) { if (!a) continue; const m = Object.assign({}, a); if (typeof m.data === 'string' && m.data.length > 2048) { delete m.data; m.ext = true; m.cloud = true; } assets[id] = m; } return JSON.stringify(Object.assign({}, doc, { assets })); };
  // ext / cloud assets back into a document: local store first, then the cloud
  const hydrate = async (doc, pid) => {
    for (const [id, a] of Object.entries(doc.assets || {})) {
      if (!a || !(a.ext || a.cloud) || a.data) continue;
      let data = pid ? await idb.get('adata', pid + '/' + id).catch(() => null) : null;
      if (!data) { const got = await CL.getAsset(id).catch(() => null); data = got && got.data; }
      if (data) { a.data = data; delete a.ext; delete a.cloud; }
    }
    return doc;
  };

  // ======================================================================
  // PROJECTS IN THE ACCOUNT
  // ======================================================================
  const P = () => O.projects;
  const pushedKey = pid => 'cloudPushed:' + pid;
  const projCol = () => db.collection('users').doc(CL.user.uid).collection('projects');
  CL.pushProject = async pid => {
    if (!CL.user || !pid || (P() && P().disabled)) return;
    await CL.ready();
    const localMeta = await idb.get('projects', pid);
    if (!localMeta) return;
    let doc = pid === S.projectId && S.doc ? S.doc : await P().readDoc(pid);
    if (!doc) return;
    const assets = await fullAssets(doc, pid);
    for (const [id, a] of Object.entries(assets)) if (typeof a.data === 'string' && a.data.length > 2048) await CL.putAsset(id, a);
    const { z, b } = await zip(lite(Object.assign({}, doc, { assets })));
    const ref = projCol().doc(pid);
    const n = await writeParts(ref.collection('parts'), b);
    const thumb = localMeta.thumb && localMeta.thumb.length < 120000 ? localMeta.thumb : '';
    await ref.set({ name: localMeta.name || doc.name || '', updated: localMeta.updated || Date.now(), created: localMeta.created || Date.now(), size: localMeta.size || 0, pages: (doc.pages || []).length, n, z, thumb });
    O.ls.set(pushedKey(pid), localMeta.updated || Date.now());
  };
  CL.pullProject = async (pid, meta, asCopy) => {
    const ref = projCol().doc(pid);
    const json = await unzip(await readParts(ref.collection('parts'), meta.n), meta.z);
    const doc = await hydrate(JSON.parse(json), pid);
    const id = asCopy ? O.uid() : pid;
    if (asCopy) doc.name = (doc.name || meta.name) + ' (' + t('з облікового запису') + ')';
    const pk = P().pack(doc, id);
    await P().writeAssets(pk.pending);
    await idb.put('pdata', pk.json, id);
    await idb.put('projects', { id, name: doc.name || meta.name, created: meta.created || Date.now(), updated: asCopy ? Date.now() : meta.updated, size: meta.size || pk.json.length, pages: (doc.pages || []).length, thumb: meta.thumb || '' });
    if (!asCopy) O.ls.set(pushedKey(id), meta.updated);
    return id;
  };
  let syncing = null;
  CL.syncAll = () => syncing || (syncing = (async () => {
    if (!CL.user || (P() && P().disabled)) return;
    setStatus('sync');
    try {
      await CL.ready();
      if (P() && P().saveNow) await P().saveNow().catch(() => {});
      const snap = await projCol().get();
      const cloud = new Map(snap.docs.map(d => [d.id, d.data()]));
      const local = new Map((await P().list()).map(p => [p.id, p]));
      let pulled = 0, reload = false;
      for (const [pid, cm] of cloud) {
        const lm = local.get(pid), pushed = O.ls.get(pushedKey(pid), 0);
        if (!lm) { await CL.pullProject(pid, cm); pulled++; continue; }
        if ((cm.updated || 0) > (lm.updated || 0) + 1000) {
          // changed in the cloud; changed here too since the last sync → keep both
          const localChanged = (lm.updated || 0) > pushed + 1000;
          await CL.pullProject(pid, cm, localChanged);
          pulled++;
          if (!localChanged && pid === S.projectId) reload = true;
        }
      }
      for (const [pid, lm] of local) {
        const cm = cloud.get(pid), pushed = O.ls.get(pushedKey(pid), 0);
        if (!cm || (lm.updated || 0) > Math.max(pushed, cm.updated || 0) + 500) await CL.pushProject(pid);
      }
      await CL.syncStyles();
      if (reload) { await P().openDirect(S.projectId); O.toast('Завантажено новішу версію проєкту з облікового запису'); }
      if (pulled) O.toast('З облікового запису завантажено проєктів: {n}', { n: pulled });
      setStatus('ok');
    } catch (e) { console.warn(e); setStatus('error', CL.err(e)); } finally { syncing = null; }
  })());
  // after every save of the open project
  const pushSoon = O.debounce(() => { if (CL.user && S.projectId) { setStatus('sync'); CL.pushProject(S.projectId).then(() => setStatus('ok')).catch(e => { console.warn(e); setStatus('error', CL.err(e)); }); } }, 5000);
  O.on('saved', pushSoon);
  window.addEventListener('online', () => { if (CL.user) CL.syncAll(); });
  // deleting a project deletes its copy in the account
  if (P() && P().remove) {
    const orig = P().remove;
    P().remove = async id => {
      await orig(id);
      if (!CL.user || !db) return;
      try {
        const ref = projCol().doc(id), m = await ref.get();
        if (!m.exists) return;
        const n = m.data().n || 1, batch = db.batch();
        for (let i = 0; i < n; i++) batch.delete(ref.collection('parts').doc(String(i)));
        batch.delete(ref);
        await batch.commit();
      } catch (e) { console.warn(e); }
    };
  }
  // saved styles: the union of both sides
  CL.syncStyles = async () => {
    if (!CL.user || !O.gstyles) return;
    const ref = db.collection('users').doc(CL.user.uid);
    const d = await ref.get();
    const remote = d.exists && d.data().gstyles ? JSON.parse(d.data().gstyles) : [];
    const mine = O.gstyles.list(), ids = new Set(mine.map(s => s.id));
    const merged = mine.concat(remote.filter(s => !ids.has(s.id)));
    if (merged.length !== mine.length) { O.ls.set('graphicStyles', merged); O.emit('gstyles', merged); }
    await ref.set({ name: CL.user.displayName || '', email: CL.user.email || '', gstyles: JSON.stringify(merged), updated: Date.now() }, { merge: true });
  };
  O.on('gstyles', O.debounce(() => { if (CL.user && db) CL.syncStyles().catch(e => console.warn(e)); }, 3000));

  // ======================================================================
  // SHARE LINK + LIVE EDITING THROUGH FIRESTORE
  // ======================================================================
  const shareCol = () => db.collection('shares');
  CL.baseUrl = () => { const site = (window.VIBSMA_CONFIG && window.VIBSMA_CONFIG.siteUrl) || ''; return site ? site.replace(/\/?$/, '/') : webOrigin() ? location.origin + location.pathname : ''; };
  CL.linkOf = sid => (CL.baseUrl() || 'https://…/') + '?share=' + sid;
  const shareMap = () => O.ls.get('shareProjects', {});
  // the shared snapshot: what someone who opens the link receives
  CL.uploadShare = async sid => {
    if (!CL.user || !S.doc) return;
    const assets = await fullAssets(S.doc, S.projectId);
    for (const [id, a] of Object.entries(assets)) if (typeof a.data === 'string' && a.data.length > 2048) await CL.putAsset(id, a);
    const { z, b } = await zip(lite(Object.assign({}, S.doc, { assets })));
    const ref = shareCol().doc(sid);
    const n = await writeParts(ref.collection('parts'), b);
    await ref.set({ name: S.doc.name || '', updated: Date.now(), n, z, by: CL.user.displayName || CL.user.email || '' }, { merge: true });
  };
  CL.share = async () => {
    if (!CL.configured()) return ui.alert('Поділитися посиланням', esc(t('Посилання для спільного редагування працюють через обліковий запис. Власник сайту має один раз підключити Firebase (інструкція у файлі FIREBASE.md). Поки що можна запросити учасника кодом — «Інші способи».')) + `<p><button type="button" class="btn" data-cb-old="1">${esc(t('Інші способи (код запрошення)…'))}</button></p>`);
    await CL.ready();
    if (!CL.user) { CL.afterLogin = () => CL.share(); return O.account.dialog({ reason: t('Увійдіть, щоб створити посилання на проєкт') }); }
    if (P() && P().saveNow) await P().saveNow().catch(() => {});
    let sid = S.doc.shareId;
    try {
      if (!sid) {
        sid = O.uid() + O.uid().slice(0, 6);
        await shareCol().doc(sid).set({ owner: CL.user.uid, ownerName: CL.user.displayName || CL.user.email || '', name: S.doc.name || '', created: Date.now(), updated: Date.now(), n: 0, z: 1 });
        S.doc.shareId = sid;
        O.history.commit('Спільний доступ');
        const m = shareMap(); m[sid] = S.projectId; O.ls.set('shareProjects', m);
      }
      O.toast('Готую посилання…');
      await CL.uploadShare(sid);
      CL.joinRoom(sid);
      CL.shareDialog(sid);
    } catch (e) { console.warn(e); O.toast(CL.err(e)); }
  };
  CL.shareDialog = sid => {
    const link = CL.linkOf(sid), people = O.collab ? O.collab.peers().filter(p => p.name !== '…') : [];
    const d = ui.dialog({
      title: 'Поділитися',
      body: `<div class="sh"><p class="dlg-text">${esc(t('Будь-хто з цим посиланням може відкрити проєкт і редагувати його разом з вами в реальному часі (потрібен вхід в обліковий запис).'))}</p>
        <div class="sh-link"><input type="text" readonly value="${esc(link)}" aria-label="${esc(t('Посилання'))}"><button type="button" class="btn primary" data-sh="copy">${esc(t('Копіювати посилання'))}</button></div>
        ${!CL.baseUrl() ? `<p class="dlg-text small warn">${esc(t('Редактор відкрито з файлу. Щоб посилання працювало в інших, розмістіть сайт в інтернеті й укажіть його адресу в js/config.js (siteUrl).'))}</p>` : ''}
        <div class="sh-people">${[`<span class="cb-p"><span class="cav" style="--c:${O.collab ? O.collab.me.color : '#0D99FF'}">${esc((CL.user.displayName || CL.user.email || '?').slice(0, 2).toUpperCase())}</span>${esc(CL.user.displayName || CL.user.email)} <em>${esc(t('ви'))}</em></span>`].concat(people.map(p => `<span class="cb-p"><span class="cav" style="--c:${p.color}">${esc(String(p.name).slice(0, 2).toUpperCase())}</span>${esc(p.name)} <em>${esc(t('онлайн'))}</em></span>`)).join('')}</div>
        <div class="row"><button type="button" class="link" data-sh="stop">${esc(t('Закрити доступ за посиланням'))}</button><span class="sp"></span><button type="button" class="link" data-cb-old="1">${esc(t('Інші способи (код запрошення без сервера)…'))}</button></div></div>`,
      buttons: [{ id: 'ok', label: 'Готово', primary: true }]
    });
    d.el.querySelector('.dlg').classList.add('wide');
    d.el.addEventListener('click', async e => {
      const b = e.target.closest('[data-sh]');
      if (!b) return;
      e.stopPropagation();
      if (b.dataset.sh === 'copy') { await O.copyText(link); O.toast('Посилання скопійовано'); }
      if (b.dataset.sh === 'stop') {
        try { await shareCol().doc(sid).delete(); } catch (err) { O.toast(CL.err(err)); return; }
        delete S.doc.shareId; O.history.commit('Спільний доступ');
        CL.leaveRoom(); d.close(); O.toast('Доступ за посиланням закрито');
      }
    });
  };
  // opening a link: sign in, take the snapshot (or the copy made before), join the room
  CL.openShare = async sid => {
    try {
      await CL.ready();
      if (!CL.user) { CL.afterLogin = () => CL.openShare(sid); return O.account.dialog({ reason: t('Увійдіть або зареєструйтеся, щоб відкрити спільний проєкт') }); }
      const ref = shareCol().doc(sid), m = await ref.get();
      if (!m.exists) return O.toast('Посилання недійсне або доступ до проєкту закрито');
      const meta = m.data();
      const mapped = shareMap()[sid];
      const local = mapped && (await idb.get('projects', mapped));
      if (local && mapped === S.projectId && S.doc && S.doc.shareId === sid) { /* already open */ }
      else if (local && (local.updated || 0) >= (meta.updated || 0)) await P().open(mapped);
      else {
        if (!meta.n) return O.toast('Власник ще готує проєкт. Спробуйте за хвилину.');
        O.toast('Відкриваю спільний проєкт…');
        const doc = await hydrate(JSON.parse(await unzip(await readParts(ref.collection('parts'), meta.n), meta.z)), null);
        doc.shareId = sid;
        if (local) { await P().open(mapped); model.load(doc); await P().saveNow(); }
        else { await P().createFrom(doc); const mm = shareMap(); mm[sid] = S.projectId; O.ls.set('shareProjects', mm); }
      }
      CL.joinRoom(sid);
      O.toast('Ви редагуєте спільний проєкт «{name}»', { name: meta.name || S.doc.name });
    } catch (e) { console.warn(e); O.toast(CL.err(e)); }
  };

  // ---------- the room: messages of the collaboration module through Firestore ----------
  let room = null;
  const CHUNK = 280000;
  CL.joinRoom = sid => {
    if (!db || !CL.user || !O.collab || !O.collab.attachLink) return;
    if (room && room.sid === sid) return;
    CL.leaveRoom();
    const col = shareCol().doc(sid).collection('msgs'), me = O.collab.me.id, parts = new Map();
    let lastCur = 0;
    const link = {
      kind: 'cloud', sid,
      send: async s => {
        try {
          // cursor moves are many: at most ~3 per second through the cloud
          if (s.startsWith('{"t":"cur"')) { const now = Date.now(); if (now - lastCur < 330) return; lastCur = now; }
          // photos and clips go to the asset store once; the message carries only the id
          if (s.startsWith('{"t":"asset"')) { const m = JSON.parse(s); await CL.putAsset(m.id, m.a); const meta = Object.assign({}, m.a); delete meta.data; meta.cloud = true; s = JSON.stringify(Object.assign({}, m, { a: meta })); }
          const c = O.uid(), n = Math.max(1, Math.ceil(s.length / CHUNK));
          for (let i = 0; i < n; i++) await col.add({ f: me, c, i, n, d: s.slice(i * CHUNK, (i + 1) * CHUNK), at: Date.now() });
        } catch (e) { console.warn(e); }
      },
      close: () => {}
    };
    const deliver = async str => {
      try {
        if (str.startsWith('{"t":"asset"')) { const m = JSON.parse(str); if (m.a && m.a.cloud && S.doc && !S.doc.assets[m.id]) { const a = await CL.getAsset(m.id); if (a) { m.a = a; str = JSON.stringify(m); } } }
        O.collab.receive(str, link);
        O.requestRender();
      } catch (e) { console.warn(e); }
    };
    const unsub = col.where('at', '>', Date.now() - 20000).orderBy('at').onSnapshot(snap => {
      snap.docChanges().forEach(ch => {
        if (ch.type !== 'added') return;
        const m = ch.doc.data();
        if (!m || m.f === me) return;
        if (m.n === 1) return deliver(m.d);
        const arr = parts.get(m.c) || []; arr[m.i] = m.d; parts.set(m.c, arr);
        if (arr.filter(x => x !== undefined).length === m.n) { parts.delete(m.c); deliver(arr.join('')); }
      });
    }, e => { console.warn(e); O.toast(CL.err(e)); });
    // tidy up: messages older than 30 minutes are not needed (newcomers start from the snapshot)
    const tidy = setInterval(async () => { try { const old = await col.where('at', '<', Date.now() - 30 * 60000).limit(200).get(); if (!old.empty) { const b = db.batch(); old.docs.forEach(d => b.delete(d.ref)); await b.commit(); } } catch (e) { /* not allowed or offline */ } }, 5 * 60000);
    room = { sid, link, unsub, tidy };
    O.collab.attachLink(link);
  };
  CL.leaveRoom = () => { if (!room) return; try { room.unsub(); } catch (e) { /* closed */ } clearInterval(room.tidy); if (O.collab && O.collab.detachLink) O.collab.detachLink(room.link); room = null; };
  CL.room = () => room;
  // the snapshot follows the edits, so people who join later get the current state
  const shareSoon = O.debounce(() => { if (room && S.doc && S.doc.shareId === room.sid && CL.user) CL.uploadShare(room.sid).catch(e => console.warn(e)); }, 12000);
  O.on('saved', shareSoon);
  O.on('docload', () => {
    if (!S.doc) return;
    if (room && S.doc.shareId !== room.sid) CL.leaveRoom();
    if (S.doc.shareId && CL.user && db) setTimeout(() => CL.joinRoom(S.doc.shareId), 200);
  });
  O.on('cloud-user', u => { if (u && S.doc && S.doc.shareId) setTimeout(() => CL.joinRoom(S.doc.shareId), 300); if (!u) CL.leaveRoom(); });

  // the «Поділитися» button opens the link dialog; the old invite codes stay one click away
  window.addEventListener('load', () => setTimeout(() => {
    if (!O.collab) return;
    const oldDialog = O.collab.dialog;
    O.collab.codeDialog = oldDialog;
    O.collab.dialog = () => (S.doc && S.doc.shareId && room ? CL.shareDialog(S.doc.shareId) : CL.share());
    document.addEventListener('click', e => { if (e.target.closest && e.target.closest('[data-cb-old]')) { e.preventDefault(); O.$$('.dlg-back').forEach(x => { const c = x.querySelector('[data-b="cancel"]'); if (c) c.click(); }); oldDialog(); } }, true);
  }, 0));
  O.cmd('shareLink', 'Поділитися посиланням…', () => CL.share(), { group: 'Спільна робота', keys: ['Ctrl+Alt+Shift+L'] });
  O.cmd('syncNow', 'Синхронізувати з обліковим записом', () => (CL.user ? CL.syncAll().then(() => O.toast(CL.status === 'ok' ? 'Синхронізовано' : CL.statusMsg)) : O.account.dialog()), { group: 'Файл' });
  const cm = O.MENUS.find(m => m[0] === 'Спільна робота');
  if (cm) cm[1].unshift('shareLink');

  // start: an existing session signs in by itself; a ?share= link opens the shared project
  window.addEventListener('load', () => setTimeout(() => {
    const sid = new URLSearchParams(location.search).get('share');
    if (!CL.configured()) { if (sid) O.toast('Спільні посилання ще не підключено на цьому сайті'); return; }
    CL.ready().then(() => {
      if (sid) { CL.openShare(sid); try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) { /* file:// */ } }
    }).catch(e => console.warn(e));
  }, 400));
})();
