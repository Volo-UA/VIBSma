'use strict';
/* VIBSma — link pens.
   «Перо анімації»: click objects one after another. The first one becomes an animated element that moves through the
   states of the next ones (position, size, rotation, colour, opacity) — exported as CSS @keyframes.
   «Перо адаптації»: click frames one after another (Desktop → Tablet → Mobile …). They become one responsive page —
   the widest frame is the base, narrower frames are CSS @media overrides. Both chains are unlimited. */
(function () {
  const O = window.O, M = O.M, model = O.model, S = O.state, V = O.view, panels = O.panels;
  const t = (s, v) => O.t(s, v), esc = O.esc, n_ = O.n;
  const LK = O.links = { sel: null };
  const COL = { anim: '#FF3D9A', adapt: '#14AE5C' };
  const TOOL = { anim: 'animpen', adapt: 'adaptpen' };
  const NAME = { anim: 'Перо анімації', adapt: 'Перо адаптації' };
  LK.COL = COL;

  // ---------- model ----------
  LK.all = () => (S.doc && S.doc.links) || [];
  LK.get = id => LK.all().find(l => l.id === id);
  LK.alive = l => l.ids.filter(id => model.exists(id));
  LK.of = (n, kind) => LK.all().filter(l => (!kind || l.kind === kind) && l.ids.includes(n.id));
  const onPage = l => LK.alive(l).some(id => model.pageOf(model.get(id)) === model.page());
  LK.siteName = f => String(f.name || '').replace(/\s*[—–-]?\s*(десктоп|desktop|планшет|tablet|мобільний|mobile|телефон|phone)\b.*$/i, '').replace(/\s*\d+\s*[×x]\s*\d+.*$/, '').trim() || t('Головна');
  LK.create = (kind, ids) => {
    S.doc.links = S.doc.links || [];
    const first = model.get(ids[0]);
    const l = kind === 'anim'
      ? { id: O.uid(), kind, ids, step: 0.8, delay: 0, ease: 'ease-in-out', repeat: 'pingpong', trigger: 'load' }
      : { id: O.uid(), kind, ids, name: first ? LK.siteName(first) : t('Головна'), mins: {} };
    S.doc.links.push(l);
    return l;
  };
  LK.remove = id => {
    if (!S.doc.links) return;
    // frames of a removed adaptation chain are not joined automatically again
    const gone = S.doc.links.find(l => l.id === id);
    if (gone && gone.kind === 'adapt') S.doc.noAutoAdapt = Array.from(new Set((S.doc.noAutoAdapt || []).concat(gone.ids)));
    S.doc.links = S.doc.links.filter(l => l.id !== id);
    if (LK.sel === id) LK.sel = null;
    O.history.commit('Видалення зв’язку');
  };
  // deleted objects leave their chains (after every edit)
  O.on('commit', () => {
    if (!S.doc || !S.doc.links || !S.doc.links.length) return;
    let changed = false;
    S.doc.links = S.doc.links.filter(l => {
      const a = LK.alive(l);
      if (a.length !== l.ids.length) { l.ids = a; changed = true; }
      if (l.ids.length < 2) { changed = true; return false; }
      return true;
    });
    if (changed) O.history.amend();
  });
  O.on('docload', () => { LK.sel = null; });

  // ---------- geometry for the overlay ----------
  const centerOf = n => { const b = model.worldBounds(n); return b ? { x: b.x + b.w / 2, y: b.y + b.h / 2 } : null; };
  const curve = (a, b, bend) => {
    const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) || 1;
    const nx = -dy / d, ny = dx / d, k = Math.min(90, d * 0.2) * bend;
    const c1 = { x: a.x + dx / 3 + nx * k, y: a.y + dy / 3 + ny * k }, c2 = { x: a.x + dx * 2 / 3 + nx * k, y: a.y + dy * 2 / 3 + ny * k };
    return { d: `M${n_(a.x)} ${n_(a.y)} C${n_(c1.x)} ${n_(c1.y)} ${n_(c2.x)} ${n_(c2.y)} ${n_(b.x)} ${n_(b.y)}`, c2 };
  };
  const arrowHead = (tip, from, col) => {
    const dx = tip.x - from.x, dy = tip.y - from.y, d = Math.hypot(dx, dy) || 1, ux = dx / d, uy = dy / d;
    const L = 10, W = 5;
    return `<path d="M${n_(tip.x)} ${n_(tip.y)} L${n_(tip.x - ux * L - uy * W)} ${n_(tip.y - uy * L + ux * W)} L${n_(tip.x - ux * L + uy * W)} ${n_(tip.y - uy * L - ux * W)}Z" fill="${col}" pointer-events="none"/>`;
  };
  const pill = (x, y, text, col, anchor) => {
    const w = text.length * 6.3 + 12;
    const x0 = anchor === 'end' ? x - w : anchor === 'middle' ? x - w / 2 : x;
    return `<g pointer-events="none"><rect x="${n_(x0)}" y="${n_(y)}" width="${n_(w)}" height="18" rx="9" fill="${col}"/><text x="${n_(x0 + w / 2)}" y="${n_(y + 12.5)}" fill="#fff" font-size="10.5" font-weight="600" text-anchor="middle" font-family="system-ui,sans-serif">${esc(text)}</text></g>`;
  };
  const badge = (p, label, col) => `<g pointer-events="none"><circle cx="${n_(p.x)}" cy="${n_(p.y)}" r="10" fill="${col}" stroke="#fff" stroke-width="1.5"/><text x="${n_(p.x)}" y="${n_(p.y + 3.8)}" fill="#fff" font-size="10.5" font-weight="700" text-anchor="middle" font-family="system-ui,sans-serif">${label}</text></g>`;
  // anchor of a frame for adaptation links: above its title
  const frameTop = (f, Vm) => { const b = model.worldBounds(f); const p = M.apply(Vm, { x: b.x + b.w / 2, y: b.y }); return { x: p.x, y: p.y - 54 }; };
  const drawLink = (l, Vm, interactive) => {
    const nodes = LK.alive(l).map(model.get).filter(n => model.pageOf(n) === model.page() && n.visible !== false);
    if (nodes.length < 2) return '';
    const col = COL[l.kind];
    const on = LK.sel === l.id;
    let s = '';
    const pts = nodes.map(n => (l.kind === 'adapt' ? frameTop(n, Vm) : M.apply(Vm, centerOf(n))));
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1];
      const cv = curve(a, b, l.kind === 'adapt' ? (b.x >= a.x ? -1 : 1) : 1);
      // stop the arrow at the target badge
      const dx = b.x - cv.c2.x, dy = b.y - cv.c2.y, d = Math.hypot(dx, dy) || 1;
      const tip = { x: b.x - dx / d * 12, y: b.y - dy / d * 12 };
      s += `<path d="${cv.d}" fill="none" stroke="${col}" stroke-width="${on ? 3 : 2}" stroke-linecap="round"${l.kind === 'adapt' ? ' stroke-dasharray="6 4"' : ''} pointer-events="none"/>`;
      s += arrowHead(tip, cv.c2, col);
      if (interactive) s += `<path d="${cv.d}" fill="none" stroke="transparent" stroke-width="14" data-h="lk:${l.id}" style="cursor:pointer"/>`;
    }
    if (l.kind === 'anim') pts.forEach((p, i) => { s += badge(p, String(i + 1), col); });
    else {
      const levels = O.html.siteLevels(l);
      for (const lv of levels) {
        if (model.pageOf(lv.f) !== model.page()) continue;
        const b = model.worldBounds(lv.f);
        const p = M.apply(Vm, { x: b.x + b.w, y: b.y });
        s += pill(p.x, p.y - 44, t(O.html.deviceOf(lv.f.w)) + ' · ' + O.html.rangeLabel(lv), col, 'end');
      }
      pts.forEach(p => { s += `<circle cx="${n_(p.x)}" cy="${n_(p.y)}" r="5" fill="${col}" stroke="#fff" stroke-width="1.5" pointer-events="none"/>`; });
    }
    return s;
  };
  O.overlayHooks.push(Vm => {
    const pen = S.tool === 'animpen' || S.tool === 'adaptpen';
    const selIds = new Set(S.sel);
    let s = '';
    for (const l of LK.all()) {
      const mine = S.tool === TOOL[l.kind];
      const visible = mine || LK.sel === l.id || S.settings.showLinks || l.ids.some(id => selIds.has(id));
      if (!visible || (pen && !mine && !S.settings.showLinks)) continue;
      s += drawLink(l, Vm, mine);
    }
    return s;
  });

  // ---------- automatic adaptation chains ----------
  // Website formats (frames named «Device — W×H» with a known device width) that stand in one row are joined right away:
  // widest first, like clicking them with «Перо адаптації». A frame that joins a row with a chain is appended to it.
  LK.deviceWidths = () => {
    const w = new Set();
    for (const [g, list] of (O.FRAME_PRESETS || []).slice(0, 3)) if (/Десктоп|Планшет|Мобільний/.test(g)) for (const d of list) w.add(d[1]);
    (O.site ? O.site.DEVICES : []).forEach(([, list]) => list.forEach(d => w.add(d[1])));
    return w;
  };
  LK.isSiteFrame = f => f && f.type === 'frame' && /\d+\s*[×x]\s*\d+\s*$/.test(String(f.name || '')) && LK.deviceWidths().has(Math.round(f.w));
  LK.autoAdapt = (page, opts = {}) => {
    page = page || model.page();
    if (!S.doc || S.settings.autoAdapt === false) return 0;
    const skip = new Set(S.doc.noAutoAdapt || []);
    const frames = page.children.filter(n => LK.isSiteFrame(n) && n.visible !== false && !skip.has(n.id));
    if (frames.length < 2 && !LK.all().some(l => l.kind === 'adapt')) return 0;
    const inChain = id => LK.all().some(l => l.kind === 'adapt' && l.ids.includes(id));
    const top = f => (model.worldBounds(f) || { y: 0 }).y;
    // rows: frames whose tops are within 40 px of each other
    const rows = [];
    for (const f of frames.slice().sort((a, b) => top(a) - top(b))) {
      const r = rows.find(row => Math.abs(top(row[0]) - top(f)) < 40);
      if (r) r.push(f); else rows.push([f]);
    }
    let made = 0;
    for (const row of rows) {
      const free = row.filter(f => !inChain(f.id));
      if (!free.length) continue;
      const chain = LK.all().find(l => l.kind === 'adapt' && row.some(f => l.ids.includes(f.id)));
      if (chain) {
        // one frame per width in a chain
        const widths = new Set(LK.alive(chain).map(id => Math.round(model.get(id).w)));
        for (const f of free) if (!widths.has(Math.round(f.w))) { chain.ids.push(f.id); widths.add(Math.round(f.w)); made++; }
        chain.ids.sort((a, b) => model.get(b).w - model.get(a).w);
        continue;
      }
      const seen = new Set(), pick = [];
      for (const f of free.slice().sort((a, b) => b.w - a.w)) { const w = Math.round(f.w); if (!seen.has(w)) { seen.add(w); pick.push(f); } }
      if (pick.length < 2) continue;
      const l = LK.create('adapt', pick.map(f => f.id));
      if (opts.name) l.name = opts.name;
      made += pick.length;
    }
    return made;
  };
  // after an edit (a frame drawn from a device preset, a pasted or duplicated website frame, a template)
  let autoBusy = false;
  O.on('commit', label => {
    if (autoBusy || !S.doc || S.settings.autoAdapt === false || /зв’язку|Перо адаптації/.test(label || '')) return;
    autoBusy = true;
    try { if (LK.autoAdapt()) { O.history.amend(); O.requestOverlay(); } } catch (e) { console.error(e); } finally { autoBusy = false; }
  });
  O.cmd('autoAdapt', 'Автоматично з’єднувати формати сайту (Перо адаптації)', () => { S.settings.autoAdapt = S.settings.autoAdapt === false; O.saveSettings(); if (S.settings.autoAdapt !== false && LK.autoAdapt()) O.history.commit('Перо адаптації'); O.requestOverlay(); }, { group: 'Вигляд', check: () => S.settings.autoAdapt !== false });

  // ---------- tools ----------
  const topFrameAt = p => {
    const list = model.page().children;
    for (let i = list.length - 1; i >= 0; i--) { const f = list[i]; if (f.type === 'frame' && f.visible !== false && V.containsWorld(f, p)) return f; }
    return null;
  };
  const penTool = kind => ({
    cursor: 'crosshair', noHandles: true, hideBox: true,
    chain: null, hoverId: null, mouse: null,
    activate() {
      this.chain = null; this.hoverId = null; O.select([]);
      if (kind === 'adapt' && S.settings.autoAdapt !== false) {
        // website formats on the page are joined at once; the pen then only adds or reorders frames
        S.doc.noAutoAdapt = [];
        const n = LK.autoAdapt();
        if (n) { O.history.commit('Перо адаптації'); return O.toast('Формати сайту з’єднано автоматично: {n}. Клацайте інші фрейми, щоб додати їх', { n }); }
      }
      O.toast(kind === 'anim' ? 'Клацніть перший об’єкт, потім наступні — кожен стане кадром анімації' : 'Клацніть перший фрейм, потім наступні — вони стануть адаптивною сторінкою'); },
    deactivate() { this.chain = null; this.hoverId = null; },
    target(ev) {
      if (ev.h && ev.h.startsWith('frame:')) { const f = model.get(ev.h.slice(6)); if (f) return f; }
      if (kind === 'adapt') return topFrameAt(ev.p);
      const id = V.hitLeaf(ev.clientX, ev.clientY);
      return id ? V.pick(id, ev.ctrl) : null;
    },
    lastId() { const l = this.chain && this.chain.link && LK.get(this.chain.link); return l ? l.ids[l.ids.length - 1] : (this.chain && this.chain.start); },
    down(ev) {
      if (ev.h && ev.h.startsWith('lk:')) { LK.sel = ev.h.slice(3); this.chain = null; panels.refresh(true); O.requestOverlay(); return; }
      const n = this.target(ev);
      if (!n) { this.chain = null; LK.sel = null; panels.refresh(true); O.requestOverlay(); return; }
      if (!this.chain) {
        // clicking the end of an existing chain continues it
        const ex = LK.all().find(l => l.kind === kind && LK.alive(l).slice(-1)[0] === n.id);
        this.chain = ex ? { link: ex.id } : { start: n.id };
        LK.sel = ex ? ex.id : null;
        panels.refresh(true);
        O.requestOverlay();
        return;
      }
      const last = this.lastId();
      if (n.id === last) return;
      const link = this.chain.link && LK.get(this.chain.link);
      if ((link && link.ids.includes(n.id)) || n.id === this.chain.start) return O.toast('Цей об’єкт уже є в ланцюжку');
      if (kind === 'adapt' && LK.all().some(l => l.kind === 'adapt' && l !== link && l.ids.includes(n.id))) return O.toast('Цей фрейм уже належить іншій адаптивній сторінці');
      if (link) link.ids.push(n.id);
      else { const l = LK.create(kind, [this.chain.start, n.id]); this.chain = { link: l.id }; }
      LK.sel = this.chain.link;
      O.history.commit(NAME[kind]);
      panels.refresh(true);
    },
    hover(ev) {
      this.mouse = ev.s;
      const n = this.target(ev);
      const id = n ? n.id : null;
      if (id !== this.hoverId || this.chain) { this.hoverId = id; O.requestOverlay(); }
    },
    move(ev) { this.mouse = ev.s; O.requestOverlay(); },
    key(e) {
      if (e.key === 'Escape' || e.key === 'Enter') {
        if (this.chain) { this.chain = null; O.requestOverlay(); return true; }
        if (e.key === 'Escape') { O.setTool('select'); return true; }
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && LK.sel) { LK.remove(LK.sel); panels.refresh(true); return true; }
      return false;
    },
    overlay(Vm) {
      let s = '';
      const col = COL[kind];
      const hov = this.hoverId && model.get(this.hoverId);
      if (hov) {
        const b = model.worldBounds(hov);
        const a = M.apply(Vm, { x: b.x, y: b.y }), c = M.apply(Vm, { x: b.x + b.w, y: b.y + b.h });
        s += `<rect x="${n_(a.x)}" y="${n_(a.y)}" width="${n_(c.x - a.x)}" height="${n_(c.y - a.y)}" fill="none" stroke="${col}" stroke-width="2" pointer-events="none"/>`;
      }
      const last = this.chain && model.get(this.lastId());
      if (last && this.mouse) {
        const a = kind === 'adapt' ? frameTop(last, Vm) : M.apply(Vm, centerOf(last));
        s += `<line x1="${n_(a.x)}" y1="${n_(a.y)}" x2="${n_(this.mouse.x)}" y2="${n_(this.mouse.y)}" stroke="${col}" stroke-width="2" stroke-dasharray="5 4" pointer-events="none"/>`;
        s += `<circle cx="${n_(a.x)}" cy="${n_(a.y)}" r="5" fill="${col}" pointer-events="none"/>`;
      }
      return s;
    }
  });
  O.tools.animpen = penTool('anim');
  O.tools.adaptpen = penTool('adapt');
  O.ICONS.animpen = '<path d="M3 21l1.2-4.2L14.5 6.5l3 3L7.2 19.8z"/><path d="M12.6 8.4l3 3"/><path d="M16.5 3.2a5.5 5.5 0 0 1 4.3 4.3"/><circle cx="19.6" cy="17.6" r="1.6"/><circle cx="14.6" cy="20.6" r="1.1"/>';
  O.ICONS.adaptpen = '<rect x="12.5" y="2.5" width="9" height="6.5" rx="1"/><rect x="17" y="11.5" width="4.5" height="9" rx="1"/><path d="M3 21l1.1-3.9 6.4-6.4 2.8 2.8-6.4 6.4z"/>';
  O.ui.TOOLS.animpen = { label: 'Перо анімації', key: 'Shift+W', icon: 'animpen' };
  O.ui.TOOLS.adaptpen = { label: 'Перо адаптації', key: 'Shift+R', icon: 'adaptpen' };
  const penGroup = O.ui.TOOL_GROUPS.find(g => g.includes('pen'));
  penGroup.splice(1, 0, 'animpen', 'adaptpen');
  O.cmd('tool:animpen', 'Перо анімації', () => O.setTool('animpen'), { keys: ['Shift+W'], group: 'Інструмент' });
  O.cmd('tool:adaptpen', 'Перо адаптації', () => O.setTool('adaptpen'), { keys: ['Shift+R'], group: 'Інструмент' });
  O.ui.TOOL_OPTIONS.animpen = () => `<span class="to-hint">${esc(t('Клік — наступний кадр. Esc — завершити ланцюжок. Delete — видалити вибраний зв’язок'))}</span>`;
  O.ui.TOOL_OPTIONS.adaptpen = () => `<span class="to-hint">${esc(t('Клацайте фрейми: Десктоп → Планшет → Мобільний… Esc — завершити'))}</span>`;

  // ---------- panel ----------
  const EASES = [['ease-in-out', 'Плавно'], ['ease-out', 'Гальмування'], ['ease-in', 'Розгін'], ['linear', 'Лінійно'], ['spring', 'Пружина'], ['smooth', 'Дуже плавно'], ['ease', 'Стандартно']];
  const REPEATS = [['pingpong', 'Туди й назад без кінця'], ['loop', 'По колу без кінця'], ['once', 'Один раз']];
  const TRIGGERS = [['load', 'Одразу після завантаження'], ['hover', 'При наведенні'], ['click', 'При кліку'], ['scroll', 'Коли з’являється на екрані']];
  const opt = (list, v) => list.map(([k, l]) => `<option value="${k}"${String(v) === k ? ' selected' : ''}>${esc(t(l))}</option>`).join('');
  const field = (label, html) => `<label class="lk-f"><span>${esc(t(label))}</span>${html}</label>`;
  const numIn = (l, f, v, step, unit) => `<span class="lk-in"><input type="number" data-lk="${f}" data-lid="${l.id}" value="${v}" step="${step}" min="0">${unit ? `<em>${unit}</em>` : ''}</span>`;
  const chain = l => LK.alive(l).map((id, i) => `<span class="lk-n"><b>${i + 1}</b>${esc(model.get(id).name)}</span>`).join('<span class="lk-ar">→</span>');
  LK.settingsHTML = l => {
    if (l.kind === 'anim') {
      return `<div class="lk-chain">${chain(l)}</div>
        <div class="lk-grid">${field('Тривалість кроку', numIn(l, 'step', l.step, 0.1, 's'))}${field('Затримка', numIn(l, 'delay', l.delay || 0, 0.1, 's'))}</div>
        <div class="lk-grid1">${field('Плавність', `<select data-lk="ease" data-lid="${l.id}">${opt(EASES, l.ease)}</select>`)}${field('Повтор', `<select data-lk="repeat" data-lid="${l.id}">${opt(REPEATS, l.repeat)}</select>`)}${field('Запуск', `<select data-lk="trigger" data-lid="${l.id}">${opt(TRIGGERS, l.trigger)}</select>`)}</div>
        <div class="lk-btns"><button type="button" class="btn" data-lka="play" data-lid="${l.id}">${O.icon('play', 13)} ${esc(t('Переглянути'))}</button><button type="button" class="btn" data-lka="css" data-lid="${l.id}">${esc(t('Копіювати CSS'))}</button><button type="button" class="btn" data-lka="keys" data-lid="${l.id}" title="${esc(t('Створити ключові кадри на таймлайні (для Lottie)'))}">${esc(t('У таймлайн'))}</button><span class="sp"></span><button type="button" class="ib" data-lka="del" data-lid="${l.id}" title="${esc(t('Видалити зв’язок'))}" aria-label="${esc(t('Видалити зв’язок'))}">${O.icon('trash', 14)}</button></div>`;
    }
    const levels = O.html.siteLevels(l);
    return `<div class="lk-grid1">${field('Назва сторінки', `<input type="text" data-lk="name" data-lid="${l.id}" value="${esc(l.name || '')}" spellcheck="false">`)}</div>
      <div class="lk-levels">${levels.map(lv => `<div class="lk-lv"><span class="lk-dev">${esc(t(O.html.deviceOf(lv.f.w)))}</span><span class="lk-fn" title="${esc(lv.f.name)}">${esc(lv.f.name)}</span><span class="lk-in"><em>${esc(t('від'))}</em><input type="number" data-lk="min" data-fid="${lv.f.id}" data-lid="${l.id}" value="${lv.min}" min="0" step="1" aria-label="${esc(t('Мінімальна ширина екрана'))}"><em>px</em></span><span class="lk-rng">${esc(O.html.rangeLabel(lv))}</span></div>`).join('')}</div>
      <div class="lk-btns"><button type="button" class="btn" data-lka="site" data-lid="${l.id}">${O.icon('play', 13)} ${esc(t('Переглянути сайт'))}</button><button type="button" class="btn" data-lka="export" data-lid="${l.id}">${O.icon('download', 13)} ${esc(t('HTML + CSS'))}</button><button type="button" class="btn" data-lka="sitecss" data-lid="${l.id}">${esc(t('Копіювати CSS'))}</button><span class="sp"></span><button type="button" class="ib" data-lka="del" data-lid="${l.id}" title="${esc(t('Видалити зв’язок'))}" aria-label="${esc(t('Видалити зв’язок'))}">${O.icon('trash', 14)}</button></div>`;
  };
  const section = (l, title) => `<section class="ps lk${LK.sel === l.id ? ' on' : ''}" data-link="${l.id}"><div class="ps-h"><button type="button" class="lk-title" data-lka="sel" data-lid="${l.id}"><span class="lk-dot" style="background:${COL[l.kind]}"></span>${esc(title)}</button></div>${LK.settingsHTML(l)}</section>`;
  const penPanel = kind => () => {
    const list = LK.all().filter(l => l.kind === kind && onPage(l));
    const hint = kind === 'anim'
      ? 'Клацайте об’єкти по черзі: перший оживе й пройде через стани наступних — позицію, розмір, поворот, колір і прозорість. Кроків скільки завгодно. В HTML це стане CSS-анімацією @keyframes.'
      : 'Клацайте фрейми по черзі, наприклад Десктоп → Планшет → Мобільний. Вони стануть однією адаптивною сторінкою: найширший фрейм — основа, вужчі — медіазапити @media. Фреймів скільки завгодно.';
    let h = `<section class="ps"><div class="ps-h"><span>${esc(t(NAME[kind]))}</span></div><p class="lk-hint">${esc(t(hint))}</p>${kind === 'adapt' ? `<div class="lk-btns"><button type="button" class="btn" data-lka="newsite">${O.icon('plus', 13)} ${esc(t('Додати фрейми сайту'))}</button></div>` : ''}</section>`;
    if (!list.length) h += `<section class="ps"><p class="lk-hint">${esc(t('На цій сторінці ще немає зв’язків.'))}</p></section>`;
    list.forEach((l, i) => { h += section(l, kind === 'anim' ? t('Анімація {n}', { n: i + 1 }) : (l.name || t('Сайт'))); });
    return h;
  };
  panels.toolProps.animpen = penPanel('anim');
  panels.toolProps.adaptpen = penPanel('adapt');
  // selected objects / frames that belong to links show their settings
  panels.extraSections.push(nodes => {
    if (!nodes.length) return '';
    const seen = new Set();
    let h = '';
    for (const n of nodes) for (const l of LK.of(n)) {
      if (seen.has(l.id)) continue;
      seen.add(l.id);
      h += section(l, l.kind === 'anim' ? t('Анімація (Перо анімації)') : t('Адаптивна сторінка «{name}»', { name: l.name || t('Сайт') }));
    }
    return h;
  });
  const props = () => O.$('#props');
  const setField = (el) => {
    const l = LK.get(el.dataset.lid);
    if (!l) return;
    const f = el.dataset.lk, v = el.value;
    if (f === 'step' || f === 'delay') l[f] = Math.max(f === 'step' ? 0.05 : 0, parseFloat(v) || 0);
    else if (f === 'min') { l.mins = l.mins || {}; if (v === '') delete l.mins[el.dataset.fid]; else l.mins[el.dataset.fid] = Math.max(0, Math.round(+v || 0)); }
    else l[f] = v;
    O.history.commit(l.kind === 'anim' ? 'Налаштування анімації' : 'Брейкпоінт');
    O.requestOverlay();
  };
  document.addEventListener('change', e => { const el = e.target; if (el.dataset && el.dataset.lk && props() && props().contains(el)) setField(el); });
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('[data-lka]');
    if (!b || !props() || !props().contains(b)) return;
    const l = LK.get(b.dataset.lid);
    const a = b.dataset.lka;
    if (a === 'newsite') return O.run('siteFrames');
    if (!l) return;
    if (a === 'sel') { LK.sel = LK.sel === l.id ? null : l.id; panels.refresh(true); O.requestOverlay(); }
    if (a === 'del') { LK.remove(l.id); panels.refresh(true); }
    if (a === 'play') LK.previewAnim(l);
    if (a === 'css') { O.copyText(LK.animCSS(l)); O.toast('CSS скопійовано'); }
    if (a === 'keys') LK.toTimeline(l);
    if (a === 'site') O.html.previewHTML(O.html.buildSite(l, {}).htmlInline, { title: l.name });
    if (a === 'export') O.html.exportDialog(LK.alive(l).map(model.get));
    if (a === 'sitecss') { O.copyText(O.html.buildSite(l, {}).css); O.toast('CSS скопійовано'); }
  });

  // ---------- animation helpers ----------
  LK.actorFrame = l => { const a = model.get(LK.alive(l)[0]); return a ? (O.html.topFrameOf(a) || null) : null; };
  LK.animCSS = l => {
    const actor = model.get(LK.alive(l)[0]);
    const cont = O.html.topFrameOf(actor) || model.parent(actor);
    const a = O.html.animFor(l, actor, cont, false);
    return `${a.keyframes}\n.${O.html.slug(actor.name)} {\n  transform-origin: 50% 50%;\n  animation: ${a.anim};\n}\n`;
  };
  LK.previewAnim = l => {
    const frame = LK.actorFrame(l);
    if (!frame) return O.toast('Покладіть об’єкти анімації у фрейм, щоб переглянути її як вебсторінку');
    const group = O.html.links('adapt').find(g => g.ids.includes(frame.id));
    const html = group ? O.html.buildSite(group, {}).htmlInline : O.html.build([frame], { fit: true }).htmlInline;
    O.html.previewHTML(html, { title: t('Анімація') });
  };
  // the chain as keyframes on the timeline (so it also goes to Lottie)
  LK.toTimeline = l => {
    if (!O.anim) return;
    const ids = LK.alive(l);
    const actor = model.get(ids[0]);
    const A = O.anim;
    let time = 0;
    actor.anim = [];
    ids.forEach((id, i) => {
      const st = model.get(id);
      const W = M.mul(M.inv(model.parentMatrix(actor)), model.worldMatrix(st));
      const ghost = Object.assign(O.clone(st), { m: W });
      const snap = A.snap(ghost);
      if (i > 0) time += Math.max(0.05, +l.step || 0.8);
      actor.anim.push({ t: time, s: snap, e: l.ease === 'linear' ? 'linear' : l.ease === 'spring' ? 'back' : 'inout' });
    });
    ids.slice(1).forEach(id => { const n = model.get(id); if (n) n.visible = false; });
    const set = A.settings();
    set.duration = Math.max(set.duration, Math.ceil((time + (l.delay || 0)) * 10) / 10);
    set.loop = l.repeat !== 'once';
    O.history.commit('Ключові кадри зі зв’язку');
    A.toggle(true);
    O.toast('Створено ключових кадрів: {n}. Стани приховано.', { n: ids.length });
  };
  O.cmd('showLinks', 'Показувати зв’язки пер', () => { S.settings.showLinks = !S.settings.showLinks; O.saveSettings(); O.requestOverlay(); }, { group: 'Вигляд', check: () => !!S.settings.showLinks });
  const view = O.MENUS.find(m => m[0] === 'Вигляд');
  if (view) view[1].splice(view[1].indexOf('smartGuides') + 1, 0, 'showLinks', 'autoAdapt');
})();
