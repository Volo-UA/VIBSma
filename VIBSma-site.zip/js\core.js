'use strict';
/* VIBSma — core: namespace, matrix math, rects, colors, events, DOM helpers */
(function () {
  const O = window.O = window.O || {};

  // ---------- numbers ----------
  O.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  O.lerp = (a, b, t) => a + (b - a) * t;
  O.n = v => { // compact number for SVG output
    if (!isFinite(v)) return '0';
    const r = Math.round(v * 1000) / 1000;
    return (r === 0 ? 0 : r).toString();
  };
  O.fmt = (v, d = 2) => {
    if (v === null || v === undefined || !isFinite(v)) return '';
    const p = Math.pow(10, d);
    const r = Math.round(v * p) / p;
    return (r === 0 ? 0 : r).toString();
  };
  O.deg = r => r * 180 / Math.PI;
  O.rad = d => d * Math.PI / 180;
  let uidCounter = 0;
  O.uid = () => (Date.now().toString(36).slice(-4) + (uidCounter++).toString(36) + Math.random().toString(36).slice(2, 6));
  O.clone = o => JSON.parse(JSON.stringify(o));

  // ---------- points ----------
  const P = O.P = {
    add: (a, b) => ({ x: a.x + b.x, y: a.y + b.y }),
    sub: (a, b) => ({ x: a.x - b.x, y: a.y - b.y }),
    mul: (a, s) => ({ x: a.x * s, y: a.y * s }),
    len: a => Math.hypot(a.x, a.y),
    dist: (a, b) => Math.hypot(a.x - b.x, a.y - b.y),
    lerp: (a, b, t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t }),
    norm: a => { const l = Math.hypot(a.x, a.y) || 1; return { x: a.x / l, y: a.y / l }; },
    rot: (a, ang, c) => {
      c = c || { x: 0, y: 0 };
      const s = Math.sin(ang), co = Math.cos(ang), dx = a.x - c.x, dy = a.y - c.y;
      return { x: c.x + dx * co - dy * s, y: c.y + dx * s + dy * co };
    },
    angle: (a, b) => Math.atan2(b.y - a.y, b.x - a.x),
    // constrain vector to multiples of 45 degrees
    snap45: (o, p) => {
      const ang = Math.atan2(p.y - o.y, p.x - o.x);
      const a = Math.round(ang / (Math.PI / 4)) * (Math.PI / 4);
      const d = Math.hypot(p.x - o.x, p.y - o.y);
      const len = Math.abs(Math.cos(ang - a)) * d;
      return { x: o.x + Math.cos(a) * len, y: o.y + Math.sin(a) * len };
    }
  };

  // ---------- 2D affine matrices [a,b,c,d,e,f] ----------
  const M = O.M = {
    id: () => [1, 0, 0, 1, 0, 0],
    mul(m, n) {
      return [
        m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1],
        m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3],
        m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]
      ];
    },
    chain(...ms) { return ms.reduce((acc, m) => M.mul(acc, m), M.id()); },
    det: m => m[0] * m[3] - m[1] * m[2],
    inv(m) {
      const det = m[0] * m[3] - m[1] * m[2];
      if (Math.abs(det) < 1e-12) return M.id();
      return [m[3] / det, -m[1] / det, -m[2] / det, m[0] / det,
        (m[2] * m[5] - m[3] * m[4]) / det, (m[1] * m[4] - m[0] * m[5]) / det];
    },
    apply: (m, p) => ({ x: m[0] * p.x + m[2] * p.y + m[4], y: m[1] * p.x + m[3] * p.y + m[5] }),
    applyV: (m, v) => ({ x: m[0] * v.x + m[2] * v.y, y: m[1] * v.x + m[3] * v.y }),
    translate: (x, y) => [1, 0, 0, 1, x, y],
    scale: (sx, sy) => [sx, 0, 0, sy === undefined ? sx : sy, 0, 0],
    rotate(a) { const c = Math.cos(a), s = Math.sin(a); return [c, s, -s, c, 0, 0]; },
    skewX: a => [1, 0, Math.tan(a), 1, 0, 0],
    skewY: a => [1, Math.tan(a), 0, 1, 0, 0],
    about: (m, p) => M.mul(M.translate(p.x, p.y), M.mul(m, M.translate(-p.x, -p.y))),
    // m = T * R * SkewX * S
    decompose(m) {
      const [a, b, c, d, e, f] = m;
      const sx = Math.hypot(a, b);
      const rot = Math.atan2(b, a);
      const co = Math.cos(rot), si = Math.sin(rot);
      const c2 = c * co + d * si;
      const sy = -c * si + d * co;
      const skew = Math.abs(sy) > 1e-12 ? Math.atan(c2 / sy) : 0;
      return { tx: e, ty: f, rot, sx, sy, skew };
    },
    compose(d) {
      return M.chain(M.translate(d.tx, d.ty), M.rotate(d.rot), M.skewX(d.skew || 0), M.scale(d.sx, d.sy));
    },
    isId: m => Math.abs(m[0] - 1) < 1e-9 && Math.abs(m[1]) < 1e-9 && Math.abs(m[2]) < 1e-9 && Math.abs(m[3] - 1) < 1e-9 && Math.abs(m[4]) < 1e-9 && Math.abs(m[5]) < 1e-9,
    str: m => 'matrix(' + m.map(O.n).join(' ') + ')',
    css: m => 'matrix(' + m.join(',') + ')'
  };

  // ---------- rects {x,y,w,h} ----------
  const R = O.R = {
    fromPts(pts) {
      if (!pts.length) return null;
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      for (const p of pts) { if (p.x < x0) x0 = p.x; if (p.y < y0) y0 = p.y; if (p.x > x1) x1 = p.x; if (p.y > y1) y1 = p.y; }
      return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
    },
    union(a, b) {
      if (!a) return b ? { ...b } : null;
      if (!b) return { ...a };
      const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y);
      return { x, y, w: Math.max(a.x + a.w, b.x + b.w) - x, h: Math.max(a.y + a.h, b.y + b.h) - y };
    },
    contains: (r, p) => p.x >= r.x && p.y >= r.y && p.x <= r.x + r.w && p.y <= r.y + r.h,
    containsRect: (r, s) => s.x >= r.x && s.y >= r.y && s.x + s.w <= r.x + r.w && s.y + s.h <= r.y + r.h,
    intersects: (a, b) => a.x <= b.x + b.w && b.x <= a.x + a.w && a.y <= b.y + b.h && b.y <= a.y + a.h,
    expand: (r, d) => ({ x: r.x - d, y: r.y - d, w: r.w + 2 * d, h: r.h + 2 * d }),
    center: r => ({ x: r.x + r.w / 2, y: r.y + r.h / 2 }),
    corners: r => [{ x: r.x, y: r.y }, { x: r.x + r.w, y: r.y }, { x: r.x + r.w, y: r.y + r.h }, { x: r.x, y: r.y + r.h }],
    transform(r, m) { return R.fromPts(R.corners(r).map(p => M.apply(m, p))); },
    norm(a, b) { return { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(b.x - a.x), h: Math.abs(b.y - a.y) }; }
  };

  // ---------- colors ----------
  let colorCtx = null;
  // HEX typed with a Ukrainian / Russian keyboard layout: the keys A–F give ф и с в у а
  const CYR_HEX = { 'ф': 'a', 'и': 'b', 'с': 'c', 'в': 'd', 'у': 'e', 'а': 'f', 'Ф': 'A', 'И': 'B', 'С': 'C', 'В': 'D', 'У': 'E', 'А': 'F' };
  const C = O.color = {
    latinHex(str) { return String(str).replace(/[фисвуаФИСВУА]/g, c => CYR_HEX[c]); },
    parse(str) {
      if (str === null || str === undefined) return null;
      str = String(str).trim();
      if (!str || str === 'none' || str === 'transparent') return null;
      if (/^#?[0-9a-fфисвуа]{3,8}$/i.test(str)) str = C.latinHex(str);
      let m = /^#?([0-9a-f]{3,8})$/i.exec(str);
      if (m) {
        let h = m[1];
        if (h.length === 3 || h.length === 4) h = h.split('').map(c => c + c).join('');
        if (h.length !== 6 && h.length !== 8) return null;
        return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1 };
      }
      m = /^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+%?))?\s*\)$/i.exec(str);
      if (m) {
        let a = m[4] === undefined ? 1 : (m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]));
        return { r: +m[1], g: +m[2], b: +m[3], a };
      }
      if (!colorCtx) colorCtx = document.createElement('canvas').getContext('2d');
      colorCtx.fillStyle = '#000001';
      colorCtx.fillStyle = str;
      const v = colorCtx.fillStyle;
      if (v === '#000001') return null;
      return C.parse(v);
    },
    hex(c) {
      const h = v => O.clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0');
      return ('#' + h(c.r) + h(c.g) + h(c.b)).toUpperCase();
    },
    norm(str) { const c = C.parse(str); return c ? C.hex(c) : null; },
    // a HEX field value: «F00», «#FF0000», «ff0000cc» (alpha → opacity), CSS names, rgb(…)
    field(str) {
      const s = C.latinHex(String(str || '').trim());
      const c = C.parse(/^[0-9a-f]{3,8}$/i.test(s) ? '#' + s : s);
      return c ? { hex: C.hex(c), a: c.a === undefined || c.a === 1 ? null : c.a } : null;
    },
    rgba(hex, a = 1) { const c = C.parse(hex) || { r: 0, g: 0, b: 0 }; return `rgba(${c.r},${c.g},${c.b},${O.n(a)})`; },
    toHsv({ r, g, b }) {
      r /= 255; g /= 255; b /= 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
      let h = 0;
      if (d) {
        if (max === r) h = ((g - b) / d) % 6; else if (max === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
        h *= 60; if (h < 0) h += 360;
      }
      return { h, s: max ? d / max : 0, v: max };
    },
    fromHsv({ h, s, v }) {
      const c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c;
      let r = 0, g = 0, b = 0;
      if (h < 60) [r, g, b] = [c, x, 0]; else if (h < 120) [r, g, b] = [x, c, 0]; else if (h < 180) [r, g, b] = [0, c, x];
      else if (h < 240) [r, g, b] = [0, x, c]; else if (h < 300) [r, g, b] = [x, 0, c]; else [r, g, b] = [c, 0, x];
      return { r: (r + m) * 255, g: (g + m) * 255, b: (b + m) * 255 };
    },
    toHsl({ r, g, b }) {
      r /= 255; g /= 255; b /= 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2, d = max - min;
      let h = 0, s = 0;
      if (d) {
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)); else if (max === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
        h *= 60;
      }
      return { h, s, l };
    },
    fromHsl({ h, s, l }) {
      const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
      let r = 0, g = 0, b = 0;
      if (h < 60) [r, g, b] = [c, x, 0]; else if (h < 120) [r, g, b] = [x, c, 0]; else if (h < 180) [r, g, b] = [0, c, x];
      else if (h < 240) [r, g, b] = [0, x, c]; else if (h < 300) [r, g, b] = [x, 0, c]; else [r, g, b] = [c, 0, x];
      return { r: (r + m) * 255, g: (g + m) * 255, b: (b + m) * 255 };
    },
    toCmyk({ r, g, b }) {
      r /= 255; g /= 255; b /= 255;
      const k = 1 - Math.max(r, g, b);
      if (k >= 1) return { c: 0, m: 0, y: 0, k: 1 };
      return { c: (1 - r - k) / (1 - k), m: (1 - g - k) / (1 - k), y: (1 - b - k) / (1 - k), k };
    },
    fromCmyk({ c, m, y, k }) {
      return { r: 255 * (1 - c) * (1 - k), g: 255 * (1 - m) * (1 - k), b: 255 * (1 - y) * (1 - k) };
    },
    mix(a, b, t) {
      const x = C.parse(a) || { r: 0, g: 0, b: 0 }, y = C.parse(b) || { r: 0, g: 0, b: 0 };
      return C.hex({ r: O.lerp(x.r, y.r, t), g: O.lerp(x.g, y.g, t), b: O.lerp(x.b, y.b, t) });
    },
    luminance(hex) { const c = C.parse(hex) || { r: 0, g: 0, b: 0 }; return (0.299 * c.r + 0.587 * c.g + 0.114 * c.b) / 255; }
  };

  // ---------- events ----------
  const handlers = {};
  O.on = (ev, fn) => { (handlers[ev] = handlers[ev] || []).push(fn); };
  O.emit = (ev, ...args) => { (handlers[ev] || []).slice().forEach(fn => { try { fn(...args); } catch (err) { console.error(err); } }); };

  // ---------- brand (Images/VIBma_Logo.svg) ----------
  // mark: the blue sign, 323×897 units; word: the «VIBSma» lettering to its right (painted with currentColor)
  O.BRAND = {
    mark: '<g fill="#0009ff"><path d="M0,288.59c0-.61.43-1.12,1.03-1.24,6.7-1.29,45.93-11.75,107.25-86.2,89.03-108.09,21-179.14-2.77-198.92-1.12-.93-.03-2.7,1.3-2.12,36.67,15.76,172.67,84.49,74.45,202.08-.26.31-.65.83-.87,1.16-3.63,5.46-21.24,31.11-47.28,56.24-2.34,2.25-2.38,5.97-.08,8.27l2.62,2.62c2.43,2.43,2.22,6.42-.44,8.59l-59.15,48.12c-1.78,1.44-4.23,1.71-6.28.67L3.51,294.29C1.36,293.21,0,291,0,288.59h0Z"/><path d="M323.14,373.88l-45.03-23.54c-2.95-1.54-6.56-.97-8.88,1.41l-46.1,47.22c-3.37,3.45-2.67,9.13,1.43,11.67l56.5,34.96c2.15,1.33,3.49,3.66,3.57,6.19l5.57,194.81s4.55,97.73-45.45,151.14c0,0,77.27,82.95,78.41,98.86V373.88Z"/><path d="M323.14,84.11S246.84,271.5,51.86,386.47c-2.3,1.36-3.73,3.82-3.730,6.5v199.02c0,3.8,2.82,7.01,6.59,7.48,26.08,3.22,121.12,24.03,130.91,156.24,0,0,61.83-88.57-54.75-209.1-1.3-1.34-2.06-3.11-2.13-4.98l-4.33-117.45c-.1-2.64,1.19-5.13,3.39-6.58,15.3-10.03,75.98-50.49,101-77.8,35.31-38.55,73.86-64.77,94.32-106.82V84.11Z"/></g>',
    word: '<g fill="currentColor"><path d="M407.11,456.03l28.22-82.4h32.37l-43.99,117.71h-33.2l-43.99-117.71h32.37l28.22,82.4Z"/><path d="M530.78,491.34h-59.76v-23.54h14.94v-70.63h-14.94v-23.54h59.76v23.54h-14.94v70.63h14.94v23.54Z"/><path d="M358.14,575.42h66.4c10.84,0,18.81,2.5,23.9,7.48,5.09,4.99,7.64,12.59,7.64,22.79,0,6.73-1.44,12.19-4.32,16.4-2.88,4.2-6.42,7.15-10.62,8.83,8.96,2.47,15.05,8.52,18.26,18.16,1.11,3.48,1.66,7.51,1.66,12.11,0,10.99-2.55,19.06-7.64,24.22-5.09,5.16-13.06,7.74-23.9,7.74h-71.38v-117.71ZM426.2,609.06c0-6.73-3.32-10.09-9.96-10.09h-28.22v23.54h28.22c6.64,0,9.96-3.36,9.96-10.09v-3.36ZM431.18,656.14c0-6.73-3.32-10.09-9.96-10.09h-33.2v23.540h33.2c6.64,0,9.96-3.36,9.96-10.09v-3.36Z"/><path d="M472.51,668.75c30.32,1.68,50.85,2.52,61.59,2.52,2.54,0,4.57-.76,6.06-2.27s2.24-3.56,2.24-6.14v-15.13h-38.18c-11.62,0-20.06-2.66-25.31-7.99-5.26-5.32-7.88-13.87-7.88-25.64v-5.05c0-11.77,2.63-20.32,7.88-25.64s13.69-7.99,25.31-7.99h58.27v23.54h-51.63c-6.64,0-9.96,3.36-9.96,10.09v3.36c0,6.73,3.32,10.09,9.96,10.09h29.88c10.84,0,18.81,2.58,23.9,7.74,5.09,5.16,7.64,13.23,7.64,24.22v8.41c0,10.99-2.55,19.06-7.64,24.22-5.09,5.16-13.06,7.74-23.9,7.74-5.64,0-11.62-.11-17.93-.34l-15.27-.67c-11.29-.56-22.96-1.350-35.03-2.35v-22.7Z"/><path d="M415.41,804.12c8.96,0,15.88,3.36,20.75,10.09,5.09-3.47,10.59-6.03,16.52-7.65,5.92-1.62,11.21-2.44,15.85-2.44h1.66c7.52,0,13.55,2.3,18.09,6.89,4.54,4.6,6.81,10.71,6.81,18.33v65.58h-29.05v-60.54c0-1.68-.56-3.08-1.66-4.2-1.11-1.12-2.49-1.68-4.15-1.68h-.83c-4.98,0-11.34,1.12-19.09,3.36v63.06h-29.05v-60.54c0-1.68-.55-3.08-1.66-4.2-1.11-1.12-2.49-1.68-4.15-1.68h-.83c-4.98,0-11.35,1.12-19.09,3.36v63.06h-29.05v-89.13h25.73l1.66,8.41c5.2-3.47,10.54-6.03,16.02-7.65,5.48-1.62,10.1-2.44,13.86-2.44h1.66Z"/><path d="M514.18,807.48c20.25-2.24,38.51-3.36,54.78-3.36,7.52,0,13.55,2.3,18.09,6.89,4.54,4.6,6.81,10.71,6.81,18.33v65.58h-25.73l-1.66-8.41c-5.2,3.48-10.54,6.03-16.02,7.65-5.48,1.62-10.1,2.44-13.86,2.44h-5.81c-7.53,0-13.56-2.3-18.09-6.9-4.54-4.6-6.81-10.7-6.81-18.33v-7.57c0-7.62,2.27-13.73,6.81-18.33,4.54-4.6,10.57-6.9,18.09-6.9h34.03v-6.73c0-1.68-.55-3.08-1.66-4.2-1.11-1.12-2.49-1.68-4.15-1.68-7.19,0-15.13.34-23.82,1.01-8.69.67-15.69,1.18-21,1.51v-21.020ZM544.89,873.07c5.86,0,12.5-1.12,19.92-3.36v-10.09h-24.07c-1.66,0-3.04.56-4.15,1.68s-1.66,2.52-1.66,4.2v1.68c0,1.68.55,3.08,1.66,4.2,1.1,1.12,2.49,1.68,4.15,1.68h4.15Z"/></g>'
  };
  O.logo = (h, word) => word
    ? `<svg viewBox="0 0 593.86 896.61" height="${h}" width="${Math.round(h * 593.86 / 896.61)}" role="img" aria-label="VIBSma">${O.BRAND.mark}${O.BRAND.word}</svg>`
    : `<svg viewBox="0 0 323.14 896.61" height="${h}" width="${Math.round(h * 323.14 / 896.61)}" aria-hidden="true">${O.BRAND.mark}</svg>`;

  // ---------- DOM ----------
  O.esc =s => String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  O.$ = (sel, root) => (root || document).querySelector(sel);
  O.$$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  O.h = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
  O.debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  O.download = (blob, name) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  };
  O.ls = {
    get(k, d) { try { const v = localStorage.getItem('obrys.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('obrys.' + k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } }
  };
  O.isMac = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
  O.keyLabel = k => O.isMac ? k.replace(/Ctrl\+/g, '⌘').replace(/Alt\+/g, '⌥').replace(/Shift\+/g, '⇧') : k;
})();
