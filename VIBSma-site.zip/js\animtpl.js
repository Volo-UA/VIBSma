'use strict';
/* VIBSma — 100 animation templates for the timeline: 30 entrances, 25 exits, 25 emphasis moves and 20 loops.
   A template adds ordinary keyframes to the selected objects at the playhead (everything stays editable on the
   timeline and exports to Lottie / HTML). With nothing selected a small demo title is created. The gallery plays
   every template live. */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui, V = O.view, M = O.M;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const A = O.anim;
  if (!A || !A.snap) return;
  // a template: [id, name, category, keys]; key = [time, change(state) | null, easing]
  const T = [];
  const add = (id, name, cat, keys) => T.push({ id, name, cat, keys });
  const IN = 'Поява', OUT = 'Зникнення', EMP = 'Акцент', LOOP = 'Цикл';
  const mv = (dx, dy) => s => { s.p[0] += dx; s.p[1] += dy; };
  const DIRS = [['Up', 'знизу', 0, 1], ['Down', 'згори', 0, -1], ['Left', 'справа', 1, 0], ['Right', 'зліва', -1, 0], ['UL', 'знизу справа', 1, 1], ['UR', 'знизу зліва', -1, 1], ['DL', 'згори справа', 1, -1], ['DR', 'згори зліва', -1, -1]];

  // ---------- entrances (30) ----------
  add('inFade', 'Поява', IN, [[0, s => { s.op = 0; }, 'out'], [0.6, null]]);
  DIRS.forEach(([k, l, dx, dy]) => add('inSlide' + k, t('Виїзд') + ' ' + t(l), IN, [[0, s => { mv(dx * 80, dy * 80)(s); s.op = 0; }, 'out'], [0.7, null]]));
  DIRS.slice(0, 4).forEach(([k, l, dx, dy]) => add('inFly' + k, t('Політ') + ' ' + t(l), IN, [[0, mv(dx * 600, dy * 400), 'out'], [0.9, null]]));
  add('inZoom', 'Збільшення', IN, [[0, s => { s.sx *= 0.2; s.sy *= 0.2; s.op = 0; }, 'out'], [0.6, null]]);
  add('inZoomBig', 'Наїзд із великого', IN, [[0, s => { s.sx *= 2.5; s.sy *= 2.5; s.op = 0; }, 'out'], [0.6, null]]);
  add('inPop', 'Поп', IN, [[0, s => { s.sx *= 0.3; s.sy *= 0.3; s.op = 0; }, 'out'], [0.35, s => { s.sx *= 1.12; s.sy *= 1.12; }, 'inout'], [0.55, null]]);
  add('inDrop', 'Падіння згори', IN, [[0, s => { s.p[1] -= 300; s.op = 0; }, 'in'], [0.5, null, 'out'], [0.65, mv(0, -25), 'in'], [0.8, null]]);
  add('inBounce', 'Падіння з відскоком', IN, [[0, s => { s.p[1] -= 260; }, 'in'], [0.45, null, 'out'], [0.6, mv(0, -60), 'in'], [0.75, null, 'out'], [0.85, mv(0, -18), 'in'], [0.95, null]]);
  add('inRotCW', 'Обертання за годинниковою', IN, [[0, s => { s.rot -= 180; s.op = 0; }, 'out'], [0.7, null]]);
  add('inRotCCW', 'Обертання проти годинникової', IN, [[0, s => { s.rot += 180; s.op = 0; }, 'out'], [0.7, null]]);
  add('inSpinZoom', 'Вихор', IN, [[0, s => { s.rot -= 360; s.sx *= 0.1; s.sy *= 0.1; s.op = 0; }, 'out'], [0.9, null]]);
  add('inFlipX', 'Переворот по горизонталі', IN, [[0, s => { s.sx *= 0.01; }, 'out'], [0.6, null]]);
  add('inFlipY', 'Переворот по вертикалі', IN, [[0, s => { s.sy *= 0.01; }, 'out'], [0.6, null]]);
  add('inSkew', 'Нахил', IN, [[0, s => { s.sk += 40; s.p[0] += 120; s.op = 0; }, 'out'], [0.6, null]]);
  add('inSwing', 'Розгойдування', IN, [[0, s => { s.rot -= 35; s.op = 0; }, 'back'], [0.7, null]]);
  add('inElasticL', 'Пружина зліва', IN, [[0, mv(-300, 0), 'back'], [0.7, null]]);
  add('inElasticR', 'Пружина справа', IN, [[0, mv(300, 0), 'back'], [0.7, null]]);
  add('inDraw', 'Малювання лінії', IN, [[0, s => { s.ts = 0; s.te = 0; }, 'inout'], [1.2, s => { s.ts = 0; s.te = 1; }]]);
  add('inColor', 'Проявлення кольору', IN, [[0, s => { s.fills = s.fills.map(c => (c ? '#FFFFFF' : c)); s.op = 0.2; }, 'out'], [0.8, null]]);
  add('inRise', 'Підйом', IN, [[0, s => { mv(0, 40)(s); s.sx *= 0.9; s.sy *= 0.9; s.op = 0; }, 'out'], [0.9, null]]);
  // ---------- exits (25) ----------
  add('outFade', 'Зникнення', OUT, [[0, null, 'in'], [0.6, s => { s.op = 0; }]]);
  // an exit keeps the direction of the matching entrance: «from below» comes in moving up and leaves upwards
  DIRS.forEach(([k, l, dx, dy]) => add('outSlide' + k, t('Відліт') + ' ' + t(l.replace('знизу', 'вгору').replace('згори', 'вниз').replace('справа', 'ліворуч').replace('зліва', 'праворуч')), OUT, [[0, null, 'in'], [0.7, s => { mv(-dx * 80, -dy * 80)(s); s.op = 0; }]]));
  add('outSqueeze', 'Стискання', OUT, [[0, null, 'in'], [0.5, s => { s.sx *= 0.01; s.sy *= 1.3; s.op = 0; }]]);
  add('outDissolveUp', 'Розчинення вгору', OUT, [[0, null, 'inout'], [1.2, s => { mv(0, -30)(s); s.op = 0; }]]);
  add('outZoom', 'Зменшення', OUT, [[0, null, 'in'], [0.6, s => { s.sx *= 0.2; s.sy *= 0.2; s.op = 0; }]]);
  add('outBlow', 'Вибух', OUT, [[0, null, 'in'], [0.5, s => { s.sx *= 2.5; s.sy *= 2.5; s.op = 0; }]]);
  add('outPop', 'Поп назовні', OUT, [[0, null, 'inout'], [0.2, s => { s.sx *= 1.12; s.sy *= 1.12; }, 'in'], [0.5, s => { s.sx *= 0.2; s.sy *= 0.2; s.op = 0; }]]);
  add('outRotCW', 'Відкручування', OUT, [[0, null, 'in'], [0.7, s => { s.rot += 180; s.op = 0; }]]);
  add('outRotCCW', 'Відкручування назад', OUT, [[0, null, 'in'], [0.7, s => { s.rot -= 180; s.op = 0; }]]);
  add('outSpin', 'Вир назовні', OUT, [[0, null, 'in'], [0.9, s => { s.rot += 360; s.sx *= 0.1; s.sy *= 0.1; s.op = 0; }]]);
  add('outFlipX', 'Згортання по горизонталі', OUT, [[0, null, 'in'], [0.6, s => { s.sx *= 0.01; }]]);
  add('outFlipY', 'Згортання по вертикалі', OUT, [[0, null, 'in'], [0.6, s => { s.sy *= 0.01; }]]);
  add('outSkew', 'Нахил назовні', OUT, [[0, null, 'in'], [0.6, s => { s.sk -= 40; s.p[0] -= 120; s.op = 0; }]]);
  add('outFall', 'Падіння вниз', OUT, [[0, null, 'in'], [0.8, s => { s.p[1] += 500; s.rot += 25; s.op = 0; }]]);
  add('outFlyUp', 'Злет угору', OUT, [[0, null, 'in'], [0.8, s => { s.p[1] -= 500; s.op = 0; }]]);
  add('outErase', 'Стирання лінії', OUT, [[0, null, 'inout'], [1, s => { s.ts = 1; s.te = 1; }]]);
  add('outColor', 'Вицвітання кольору', OUT, [[0, null, 'in'], [0.8, s => { s.fills = s.fills.map(c => (c ? '#FFFFFF' : c)); s.op = 0; }]]);
  add('outSink', 'Занурення', OUT, [[0, null, 'in'], [0.8, s => { mv(0, 40)(s); s.sx *= 0.9; s.sy *= 0.9; s.op = 0; }]]);
  // ---------- emphasis (25) ----------
  const pulse = k => [[0, null, 'inout'], [0.3, s => { s.sx *= k; s.sy *= k; }, 'inout'], [0.6, null]];
  add('emPulse', 'Пульс', EMP, pulse(1.1));
  add('emHeart', 'Серцебиття', EMP, [[0, null, 'out'], [0.15, s => { s.sx *= 1.15; s.sy *= 1.15; }, 'in'], [0.3, null, 'out'], [0.45, s => { s.sx *= 1.1; s.sy *= 1.1; }, 'in'], [0.7, null]]);
  add('emShakeX', 'Тремтіння', EMP, [0, 0.08, 0.16, 0.24, 0.32, 0.4].map((tt, i, a) => [tt, i === 0 || i === a.length - 1 ? null : mv(i % 2 ? -12 : 12, 0), 'linear']));
  add('emShakeY', 'Тремтіння вертикальне', EMP, [0, 0.08, 0.16, 0.24, 0.32, 0.4].map((tt, i, a) => [tt, i === 0 || i === a.length - 1 ? null : mv(0, i % 2 ? -10 : 10), 'linear']));
  add('emWobble', 'Похитування', EMP, [[0, null], [0.15, s => { s.rot -= 8; }], [0.3, s => { s.rot += 6; }], [0.45, s => { s.rot -= 4; }], [0.6, null]]);
  add('emJello', 'Желе', EMP, [[0, null], [0.12, s => { s.sk += 12; }], [0.24, s => { s.sk -= 8; }], [0.36, s => { s.sk += 4; }], [0.5, null]]);
  add('emRubber', 'Гумка', EMP, [[0, null], [0.15, s => { s.sx *= 1.25; s.sy *= 0.75; }], [0.3, s => { s.sx *= 0.75; s.sy *= 1.25; }], [0.45, s => { s.sx *= 1.12; s.sy *= 0.88; }], [0.6, null]]);
  add('emTada', 'Та-да!', EMP, [[0, null], [0.1, s => { s.sx *= 0.9; s.sy *= 0.9; s.rot -= 3; }], [0.25, s => { s.sx *= 1.1; s.sy *= 1.1; s.rot += 3; }], [0.4, s => { s.sx *= 1.1; s.sy *= 1.1; s.rot -= 3; }], [0.55, s => { s.sx *= 1.1; s.sy *= 1.1; s.rot += 3; }], [0.7, null]]);
  add('emFlash', 'Блимання', EMP, [[0, null, 'hold'], [0.15, s => { s.op = 0; }, 'hold'], [0.3, null, 'hold'], [0.45, s => { s.op = 0; }, 'hold'], [0.6, null]]);
  add('emJump', 'Підстрибування', EMP, [[0, null, 'out'], [0.3, mv(0, -40), 'in'], [0.6, null]]);
  add('emSwing', 'Гойдання', EMP, [[0, null], [0.2, s => { s.rot += 15; }], [0.4, s => { s.rot -= 10; }], [0.6, s => { s.rot += 5; }], [0.8, null]]);
  add('emSpin', 'Оберт', EMP, [[0, null, 'inout'], [0.8, s => { s.rot += 360; }]]);
  add('emFlip', 'Переворот', EMP, [[0, null], [0.3, s => { s.sx *= -1; }], [0.6, null]]);
  add('emGrow', 'Зростання', EMP, [[0, null, 'out'], [0.5, s => { s.sx *= 1.2; s.sy *= 1.2; }]]);
  add('emShrink', 'Зменшення', EMP, [[0, null, 'out'], [0.5, s => { s.sx *= 0.8; s.sy *= 0.8; }]]);
  add('emTilt', 'Нахил', EMP, [[0, null, 'out'], [0.4, s => { s.rot -= 12; }]]);
  add('emNod', 'Кивок', EMP, [[0, null], [0.15, mv(0, 10)], [0.3, null], [0.45, mv(0, 10)], [0.6, null]]);
  add('emColor', 'Кольоровий імпульс', EMP, [[0, null], [0.3, s => { s.fills = s.fills.map(c => (c ? '#FF3B5C' : c)); }], [0.6, null]]);
  add('emFloat', 'Спливання', EMP, [[0, null], [0.5, mv(0, -20)], [1, null]]);
  add('emPunch', 'Ривок', EMP, [[0, null, 'out'], [0.08, s => { s.sx *= 1.25; s.sy *= 1.25; }, 'out'], [0.4, null]]);
  add('emWiggle', 'Звивання', EMP, [[0, null], [0.1, s => { s.rot += 6; mv(4, 0)(s); }], [0.2, s => { s.rot -= 6; mv(-4, 0)(s); }], [0.3, s => { s.rot += 4; }], [0.4, null]]);
  add('emSwell', 'Повільне наростання', EMP, [[0, null, 'inout'], [1.2, s => { s.sx *= 1.08; s.sy *= 1.08; }, 'inout'], [2.4, null]]);
  add('emBlink3', 'Три спалахи', EMP, [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6].map((tt, i) => [tt, i % 2 ? (s => { s.op = 0.15; }) : null, 'hold']));
  add('emHeadShake', 'Заперечення', EMP, [[0, null], [0.1, s => { mv(-10, 0)(s); s.rot -= 4; }], [0.25, s => { mv(8, 0)(s); s.rot += 3; }], [0.4, s => { mv(-5, 0)(s); s.rot -= 2; }], [0.5, null]]);
  add('emLift', 'Підняття', EMP, [[0, null, 'out'], [0.4, s => { mv(0, -12)(s); s.sx *= 1.05; s.sy *= 1.05; }]]);
  // ---------- loops (20) — they end where they began ----------
  add('lpSpin', 'Безперервне обертання', LOOP, [[0, null, 'linear'], [2, s => { s.rot += 360; }]]);
  add('lpRock', 'Гойдалка', LOOP, [[0, null], [0.75, s => { s.rot += 12; }], [1.5, s => { s.rot -= 12; }], [2.25, null]]);
  add('lpFloat', 'Плавання', LOOP, [[0, null], [1, mv(0, -18)], [2, null]]);
  add('lpPulse', 'Пульсація', LOOP, [[0, null], [0.5, s => { s.sx *= 1.08; s.sy *= 1.08; }], [1, null]]);
  add('lpBounce', 'М’ячик', LOOP, [[0, null, 'out'], [0.35, mv(0, -50), 'in'], [0.7, null]]);
  add('lpSway', 'Колихання', LOOP, [[0, null], [1, mv(20, 0)], [2, mv(-20, 0)], [3, null]]);
  add('lpOrbit', 'Орбіта', LOOP, [0, 0.5, 1, 1.5, 2].map((tt, i) => [tt, i === 0 || i === 4 ? null : mv([0, 40, 0, -40][i] - [0, 0, 40, 0][i] * 0, [0, -40, -80, -40][i]), 'inout']));
  add('lpEight', 'Вісімка', LOOP, [0, 0.4, 0.8, 1.2, 1.6, 2].map((tt, i) => [tt, [null, mv(30, -20), mv(0, 0), mv(-30, 20), mv(0, 0), null][i], 'inout']));
  add('lpBreathe', 'Дихання', LOOP, [[0, null], [1.2, s => { s.op = 0.4; }], [2.4, null]]);
  add('lpBlink', 'Мерехтіння', LOOP, [[0, null, 'hold'], [0.5, s => { s.op = 0.2; }, 'hold'], [1, null]]);
  add('lpPendulum', 'Маятник', LOOP, [[0, s => { s.rot -= 20; }], [0.8, s => { s.rot += 20; }], [1.6, s => { s.rot -= 20; }]]);
  add('lpZigzag', 'Зигзаг', LOOP, [[0, null, 'linear'], [0.3, mv(20, -15), 'linear'], [0.6, mv(40, 0), 'linear'], [0.9, mv(20, 15), 'linear'], [1.2, null]]);
  add('lpWave', 'Хвиля', LOOP, [[0, null], [0.4, s => { s.sy *= 1.15; s.sx *= 0.92; }], [0.8, s => { s.sy *= 0.9; s.sx *= 1.06; }], [1.2, null]]);
  add('lpHeart', 'Серце, що б’ється', LOOP, [[0, null, 'out'], [0.12, s => { s.sx *= 1.15; s.sy *= 1.15; }, 'in'], [0.25, null, 'out'], [0.37, s => { s.sx *= 1.1; s.sy *= 1.1; }, 'in'], [1, null]]);
  add('lpShake', 'Дрижання', LOOP, [0, 0.05, 0.1, 0.15, 0.2].map((tt, i) => [tt, [null, mv(3, -2), mv(-3, 2), mv(2, 3), null][i], 'linear']));
  add('lpPingPong', 'Пінг-понг', LOOP, [[0, null, 'inout'], [1, mv(120, 0), 'inout'], [2, null]]);
  add('lpUpDown', 'Ліфт', LOOP, [[0, null, 'inout'], [1, mv(0, -80), 'inout'], [2, null]]);
  add('lpZoom', 'Наближення й віддалення', LOOP, [[0, null], [1, s => { s.sx *= 1.3; s.sy *= 1.3; }], [2, null]]);
  add('lpFlicker', 'Вогник', LOOP, [0, 0.07, 0.15, 0.22, 0.4, 0.47, 0.6].map((tt, i) => [tt, [null, s => { s.op = 0.6; }, null, s => { s.op = 0.85; }, null, s => { s.op = 0.5; }, null][i], 'linear']));
  add('lpTilt', 'Хитання головою', LOOP, [[0, null], [0.6, s => { s.rot += 8; s.sk += 4; }], [1.2, s => { s.rot -= 8; s.sk -= 4; }], [1.8, null]]);
  A.TEMPLATES = T;

  // ---------- applying ----------
  const demo = () => {
    const vr = V.viewRect(), cx = Math.round(vr.x + vr.w / 2), cy = Math.round(vr.y + vr.h / 2);
    const n = model.create('rect', { name: t('Анімована фігура'), w: 160, h: 160, radius: 32, m: M.translate(cx - 80, cy - 80), fills: [O.paint.solid('#7B61FF')] });
    model.insert(n, model.page());
    return [n];
  };
  A.applyTemplate = id => {
    const tp = T.find(x => x.id === id);
    if (!tp) return;
    let nodes = O.topSel();
    if (!nodes.length) { nodes = demo(); O.select(nodes.map(n => n.id)); }
    const t0 = A.time || 0, last = tp.keys[tp.keys.length - 1][0];
    for (const n of nodes) {
      const base = A.stateAt(n, t0) || A.snap(n);
      n.anim = (n.anim || []).filter(k => k.t < t0 - 1e-4 || k.t > t0 + last + 1e-4);
      for (const [dt, fn, ease] of tp.keys) { const s = O.clone(base); if (fn) fn(s); n.anim.push({ t: t0 + dt, s, e: ease || 'inout' }); }
      n.anim.sort((a, b) => a.t - b.t);
    }
    const set = A.settings();
    if (t0 + last > set.duration) set.duration = Math.ceil((t0 + last) * 10) / 10;
    if (tp.cat === LOOP) set.loop = true;
    O.history.commit('Шаблон анімації');
    if (!A.open && A.toggle) A.toggle(true);
    A.render();
    A.applyAt(t0);
    O.toast('Анімація «{name}» додана', { name: t(tp.name) });
  };

  // ---------- gallery with live previews (Web Animations) ----------
  const base = () => ({ p: [0, 0], a: [0, 0], rot: 0, sx: 1, sy: 1, sk: 0, op: 1, fills: ['#7B61FF'], strokes: [], sw: 1, ts: 0, te: 1 });
  const EASE = { linear: 'linear', inout: 'ease-in-out', in: 'ease-in', out: 'ease-out', back: 'cubic-bezier(.34,1.56,.64,1)', hold: 'steps(1, end)' };
  const frames = tp => {
    const last = tp.keys[tp.keys.length - 1][0] || 1, k = 0.3;
    return tp.keys.map(([dt, fn, ease]) => { const s = base(); if (fn) fn(s); return { offset: dt / last, transform: `translate(${(s.p[0] * k).toFixed(1)}px, ${(s.p[1] * k).toFixed(1)}px) rotate(${s.rot}deg) skewX(${s.sk || 0}deg) scale(${s.sx}, ${s.sy})`, opacity: Math.max(0, Math.min(1, s.op)), backgroundColor: s.fills[0] || '#7B61FF', strokeDashoffset: (1 - (s.te - s.ts)) * 100, easing: EASE[ease || 'inout'] || 'ease-in-out' }; });
  };
  A.templatesDialog = () => {
    let cat = 'all';
    const usesTrim = tp => /Draw|Erase/.test(tp.id);
    const d = ui.dialog({
      title: 'Шаблони анімації',
      body: `<div class="an-head"><div class="bg-chips">${[['all', 'Усі'], [IN, IN], [OUT, OUT], [EMP, EMP], [LOOP, LOOP]].map(([k, l]) => `<button type="button" data-anc="${esc(k)}" class="${k === cat ? 'on' : ''}">${esc(t(l))}</button>`).join('')}</div><span class="dlg-text small">${esc(t('{n} шаблонів. Клік додає анімацію виділеним об’єктам від позиції курсора часу (без виділення — створить фігуру для прикладу).', { n: T.length }))}</span></div><div class="an-grid"></div>`,
      buttons: [{ id: 'ok', label: 'Закрити', primary: true }]
    });
    d.el.querySelector('.dlg').classList.add('wide', 'an-wide');
    const grid = d.el.querySelector('.an-grid');
    const render = () => {
      grid.innerHTML = T.filter(x => cat === 'all' || x.cat === cat).map(x => `<button type="button" class="an-card" data-ant="${x.id}"><span class="an-stage">${usesTrim(x) ? '<svg viewBox="0 0 40 40" width="40" height="40"><circle class="an-line" cx="20" cy="20" r="15" fill="none" stroke="#7B61FF" stroke-width="4" pathLength="100" stroke-dasharray="100"/></svg>' : '<i class="an-box"></i>'}</span><b>${esc(t(x.name))}</b><em>${esc(t(x.cat))}</em></button>`).join('');
      grid.querySelectorAll('[data-ant]').forEach(b => {
        const tp = T.find(x => x.id === b.dataset.ant), el = b.querySelector('.an-box, .an-line');
        const dur = Math.max(300, tp.keys[tp.keys.length - 1][0] * 1000);
        try { el.animate(frames(tp).map(f => (usesTrim(tp) ? { offset: f.offset, strokeDashoffset: f.strokeDashoffset, easing: f.easing } : { offset: f.offset, transform: f.transform, opacity: f.opacity, backgroundColor: f.backgroundColor, easing: f.easing })), { duration: dur, iterations: Infinity, endDelay: tp.cat === LOOP ? 0 : 700 }); } catch (e) { /* preview only */ }
      });
    };
    render();
    d.el.addEventListener('click', e => {
      const c = e.target.closest('[data-anc]');
      if (c) { e.preventDefault(); cat = c.dataset.anc; d.el.querySelectorAll('[data-anc]').forEach(x => x.classList.toggle('on', x === c)); render(); return; }
      const b = e.target.closest('[data-ant]');
      if (b) { e.preventDefault(); A.applyTemplate(b.dataset.ant); }
    });
  };
  O.cmd('animTemplates', 'Шаблони анімації…', () => A.templatesDialog(), { group: 'Анімація', keys: ['Ctrl+Alt+Shift+Y'] });
  const am = O.MENUS.find(m => m[0] === 'Анімація');
  if (am) am[1].splice(am[1].indexOf('animKey'), 0, 'animTemplates', '-');
})();
