'use strict';
/* VIBSma — PDF like in Illustrator.
   · Open / place PDF (and PDF-compatible .ai) pages: choose pages, import them as editable vectors (pdf.js SVG back-end,
     embedded fonts are kept) or as images; each page becomes a frame (artboard).
   · Save as PDF (jsPDF + svg2pdf): one page per artboard, text as outlines (exact look, any script), bleed, crop marks,
     metadata, and «Зберегти можливість редагування»: the whole VIBSma document travels inside the PDF, so opening the
     PDF in VIBSma again restores every layer. 1 px = 1 pt, like Illustrator. */
(function () {
  const O = window.O, M = O.M, model = O.model, S = O.state, V = O.view, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const PDF = O.pdf = { lastErrors: [] };
  const MM = 72 / 25.4;

  // ---------- libraries (loaded on first use) ----------
  PDF.loadReader = async () => {
    // the worker script defines window.pdfjsWorker → pdf.js runs in this thread (works from file:// too)
    if (!window.pdfjsWorker) await O.loadScript('vendor/pdf.worker.min.js');
    await O.loadScript('vendor/pdf.min.js');
    window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'vendor/pdf.worker.min.js';
    return window.pdfjsLib;
  };
  PDF.loadWriter = async () => {
    await O.loadScript('vendor/jspdf.umd.min.js');
    await O.loadScript('vendor/svg2pdf.umd.min.js');
    return window.jspdf.jsPDF;
  };

  // ---------- the VIBSma document inside a PDF ----------
  const MARK_A = '%OBRYS-DOC-BEGIN', MARK_B = '%OBRYS-DOC-END';
  const latin1 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return s; };
  const b64 = u8 => btoa(latin1(u8));
  const unb64 = s => { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };
  const gzip = async str => new Uint8Array(await new Response(new Blob([str]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());
  const gunzip = async u8 => new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
  // PDF comments placed right before the last «startxref» keep every byte offset of the file valid
  PDF.embedDoc = async (u8, json) => {
    if (!window.CompressionStream) return u8;
    const enc = b64(await gzip(json));
    const lines = [MARK_A];
    for (let i = 0; i < enc.length; i += 76) lines.push('%' + enc.slice(i, i + 76));
    lines.push(MARK_B, '');
    const block = new TextEncoder().encode(lines.join('\n'));
    const tailLen = Math.min(4096, u8.length);
    const k = latin1(u8.subarray(u8.length - tailLen)).lastIndexOf('startxref');
    if (k < 0) return u8;
    const at = u8.length - tailLen + k;
    const out = new Uint8Array(u8.length + block.length);
    out.set(u8.subarray(0, at), 0); out.set(block, at); out.set(u8.subarray(at), at + block.length);
    return out;
  };
  PDF.extractDoc = async u8 => {
    if (!window.DecompressionStream) return null;
    const s = latin1(u8);
    const a = s.lastIndexOf(MARK_A);
    if (a < 0) return null;
    const b = s.indexOf(MARK_B, a);
    if (b < 0) return null;
    try { return JSON.parse(await gunzip(unb64(s.slice(a + MARK_A.length, b).split('\n').map(l => l.replace(/^%/, '').trim()).join('')))); } catch (e) { console.warn(e); return null; }
  };

  // ---------- save vector PDF ----------
  const walkAll = (groups, fn) => {
    const seen = new Set();
    const walk = n => { if (!n || seen.has(n.id)) return; seen.add(n.id); fn(n); if (n.type === 'instance') walk(model.get(n.ref)); (n.children || []).forEach(walk); };
    groups.forEach(g => g.forEach(walk));
  };
  // swap nodes for PDF-friendly versions while exporting; the document is restored afterwards
  const prepare = async (groups, opts, fn) => {
    const texts = [], fx = [];
    const hasFx = n => opts.rasterFx !== false && (n.effects || []).some(e => e.visible !== false);
    walkAll(groups, n => {
      if (n.visible === false) return;
      if (n.type === 'text') texts.push(n);
      else if (hasFx(n)) fx.push(n);
    });
    const touched = texts.concat(fx);
    const snap = O.snapshotNodes(touched);
    const tmpAssets = [];
    let rastered = 0;
    // render the node where it is, then put the picture in its place (absolute, so auto layout does not move it)
    const toImage = async n => {
      const r = await O.io.renderImage([n], { scale: opts.rasterScale || 4, type: 'image/png', embedFonts: true });
      const id = 'pdf-' + O.uid();
      S.doc.assets[id] = { data: await O.io.blobToData(r.blob), w: r.canvas.width, h: r.canvas.height };
      tmpAssets.push(id);
      const b = r.bounds, P = model.parentMatrix(n), name = n.name, keepId = n.id;
      for (const k of Object.keys(n)) delete n[k];
      Object.assign(n, model.create('rect', { w: b.w, h: b.h, m: M.mul(M.inv(P), M.translate(b.x, b.y)), fills: [Object.assign(O.paint.image(id), { mode: 'stretch' })] }), { id: keepId, name, layoutAbs: true });
      rastered++;
    };
    // auto layout must not move things while they are swapped for pictures
    model.layoutAll();
    O.freezeLayout = true;
    try {
      for (const n of texts) {
        const subs = n.path || hasFx(n) ? null : await O.ops.textSubs(n);
        if (!subs) { await toImage(n); continue; }
        const keep = { id: n.id, name: n.name, m: n.m, fills: n.fills, strokes: n.strokes, sw: n.sw, opacity: n.opacity, blend: n.blend, effects: n.effects, visible: n.visible };
        for (const k of Object.keys(n)) delete n[k];
        Object.assign(n, keep, { type: 'path', subpaths: subs, fillRule: 'nonzero', sa: 'center', dash: [], cap: 'butt', join: 'miter', miter: 4, ms: 'none', me: 'none' });
      }
      for (const n of fx) await toImage(n);
      model.reindex();
      return await fn(rastered);
    } finally {
      O.freezeLayout = false;
      O.restoreNodes(snap);
      tmpAssets.forEach(id => { delete S.doc.assets[id]; });
      O.requestRender();
    }
  };
  const cropMarks = (pdf, x, y, w, h, bleed) => {
    const off = bleed + 6, len = 14;
    pdf.setDrawColor(0, 0, 0); pdf.setLineWidth(0.3);
    const L = (x1, y1, x2, y2) => pdf.line(x1, y1, x2, y2);
    L(x - off - len, y, x - off, y); L(x, y - off - len, x, y - off);
    L(x + w + off, y, x + w + off + len, y); L(x + w, y - off - len, x + w, y - off);
    L(x - off - len, y + h, x - off, y + h); L(x, y + h + off, x, y + h + off + len);
    L(x + w + off, y + h, x + w + off + len, y + h); L(x + w, y + h + off, x + w, y + h + off + len);
  };
  PDF.build = async (groups, opts = {}) => {
    const JsPDF = await PDF.loadWriter();
    const bleed = Math.max(0, opts.bleed || 0);
    const slug = opts.marks ? 24 : 0;
    let pdf = null;
    const host = document.createElement('div');
    host.style.cssText = 'position:absolute;left:-100000px;top:0;width:10px;height:10px;overflow:hidden;';
    document.body.appendChild(host);
    let rastered = 0;
    try {
      rastered = await prepare(groups, opts, async r => {
        for (const nodes of groups) {
          const frame = nodes.length === 1 && nodes[0].type === 'frame' ? nodes[0] : null;
          const { svg, bounds } = O.render.svg(nodes, {});
          const W = bounds.w + 2 * (bleed + slug), H = bounds.h + 2 * (bleed + slug);
          const orient = W > H ? 'l' : 'p';
          if (!pdf) pdf = new JsPDF({ unit: 'pt', format: [W, H], orientation: orient, compress: true });
          else pdf.addPage([W, H], orient);
          const ox = slug + bleed, oy = slug + bleed;
          if (bleed && frame) {
            const f = (frame.fills || []).find(p => p.visible !== false && p.type === 'solid');
            if (f) { pdf.setFillColor(f.color); pdf.rect(slug, slug, bounds.w + 2 * bleed, bounds.h + 2 * bleed, 'F'); }
          }
          const el = new DOMParser().parseFromString(svg, 'image/svg+xml').documentElement;
          host.innerHTML = '';
          host.appendChild(document.importNode(el, true));
          await pdf.svg(host.firstElementChild, { x: ox, y: oy, width: bounds.w, height: bounds.h });
          if (opts.marks) cropMarks(pdf, ox, oy, bounds.w, bounds.h, bleed);
        }
        return r;
      });
    } finally { host.remove(); }
    pdf.setProperties({ title: opts.title || S.doc.name || 'VIBSma', creator: 'VIBSma', subject: opts.subject || '' });
    let u8 = new Uint8Array(pdf.output('arraybuffer'));
    if (opts.editable !== false) u8 = await PDF.embedDoc(u8, O.io.serialize());
    return { bytes: u8, pages: groups.length, rastered };
  };
  const parseRange = (str, max) => {
    const s = String(str || '').trim();
    if (!s) return null;
    const out = new Set();
    for (const part of s.split(/[,;\s]+/)) {
      const m = /^(\d+)(?:\s*[-–]\s*(\d+))?$/.exec(part);
      if (!m) continue;
      const a = +m[1], b = m[2] ? +m[2] : a;
      for (let i = Math.min(a, b); i <= Math.max(a, b); i++) if (i >= 1 && i <= max) out.add(i - 1);
    }
    return Array.from(out).sort((x, y) => x - y);
  };
  const PRESETS = { print: { bleed: 0, marks: false }, press: { bleed: 3, marks: true }, small: { bleed: 0, marks: false } };
  PDF.save = async (groups, opts = {}) => {
    groups = (groups || O.io.exportTargets()).filter(g => g && g.length);
    if (!groups.length) return O.toast('Немає що експортувати');
    O.toast('Створюю PDF…');
    try {
      const o = Object.assign({ bleed: (O.ls.get('pdfBleed', 0) || 0) * MM, marks: O.ls.get('pdfMarks', false), editable: O.ls.get('pdfEditable', true), rasterFx: O.ls.get('pdfFx', true) }, opts);
      const res = await PDF.build(groups, o);
      O.download(new Blob([res.bytes], { type: 'application/pdf' }), String(o.name || S.doc.name || 'obrys').replace(/[\\/:*?"<>|]+/g, '_') + '.pdf');
      O.toast(res.rastered ? 'PDF збережено: сторінок {n}. Растеризовано об’єктів з ефектами або без доступного шрифту: {r}' : 'PDF збережено: сторінок {n}', { n: res.pages, r: res.rastered });
      return res;
    } catch (e) { console.error(e); O.toast('Не вдалося створити PDF: {msg}', { msg: e.message }); return null; }
  };
  PDF.saveDialog = groups => {
    groups = (groups || O.io.exportTargets()).filter(g => g && g.length);
    if (!groups.length) return O.toast('Немає що експортувати');
    const names = groups.map((g, i) => `${i + 1}. ${g.length === 1 ? g[0].name : t('{n} об’єктів', { n: g.length })}`);
    const d = ui.dialog({
      title: 'Зберегти як Adobe PDF',
      body: `<div class="dlg-text">${esc(t('Кожен артборд (фрейм) стане сторінкою PDF. Текст перетворюється на криві, тож кирилиця й будь-які шрифти виглядатимуть точно. Сторінок: {n}.', { n: groups.length }))}</div><div class="dlg-text small">${esc(names.slice(0, 12).join(' · '))}${names.length > 12 ? ' …' : ''}</div>`,
      fields: [
        { key: 'preset', label: 'Набір параметрів', type: 'select', value: O.ls.get('pdfPreset', 'print'), options: [['print', 'Висока якість друку'], ['press', 'Друкарня: виліт 3 мм і мітки обрізу'], ['small', 'Найменший розмір файлу']] },
        { key: 'range', label: 'Сторінки (напр. 1-3, 5; порожньо — усі)', type: 'text', value: '' },
        { key: 'bleed', label: 'Виліт', type: 'number', value: O.ls.get('pdfBleed', 0), unit: 'мм', step: 0.5, min: 0 },
        { key: 'marks', label: 'Мітки обрізу', type: 'checkbox', value: O.ls.get('pdfMarks', false) },
        { key: 'fx', label: 'Растеризувати тіні й розмиття (як в Illustrator)', type: 'checkbox', value: O.ls.get('pdfFx', true) },
        { key: 'editable', label: 'Зберегти можливість редагування в VIBSma', type: 'checkbox', value: O.ls.get('pdfEditable', true) }
      ],
      buttons: [{ id: 'print', label: 'Друк через браузер' }, { id: 'ok', label: 'Зберегти PDF', primary: true }],
      onOpen: wrap => {
        const sel = wrap.querySelector('[data-k="preset"]');
        sel.addEventListener('change', () => {
          const p = PRESETS[sel.value] || PRESETS.print;
          wrap.querySelector('[data-k="bleed"]').value = p.bleed;
          wrap.querySelector('[data-k="marks"]').checked = p.marks;
        });
      },
      onOk: (v, btn) => {
        const idx = parseRange(v.range, groups.length);
        const pick = idx ? idx.map(i => groups[i]) : groups;
        if (!pick.length) return O.toast('Немає сторінок у вказаному діапазоні');
        O.ls.set('pdfPreset', v.preset); O.ls.set('pdfBleed', Math.max(0, v.bleed || 0)); O.ls.set('pdfMarks', !!v.marks); O.ls.set('pdfFx', !!v.fx); O.ls.set('pdfEditable', !!v.editable);
        if (btn === 'print') return O.io.exportPDF(pick);
        PDF.save(pick, { bleed: Math.max(0, v.bleed || 0) * MM, marks: !!v.marks, rasterFx: !!v.fx, editable: !!v.editable, rasterScale: v.preset === 'small' ? 2 : 4 });
      }
    });
    return d;
  };

  // ---------- open / place PDF ----------
  const cleanFont = name => String(name || 'PDF').replace(/^[A-Z]{6}\+/, '').replace(/[",;]/g, '').trim() || 'PDF';
  // one page → SVG markup with embedded fonts renamed to their real names
  PDF.pageSVG = async (lib, page) => {
    const vp = page.getViewport({ scale: 1 });
    const opList = await page.getOperatorList();
    const gfx = new lib.SVGGraphics(page.commonObjs, page.objs, true);
    gfx.embedFonts = true;
    const el = await gfx.getSVG(opList, vp);
    // pdf.js puts font and colour on the <tspan>; VIBSma reads them from <text>. Per-glyph x lists → the first x
    // (the text stays editable, spacing comes from the embedded font).
    el.querySelectorAll('text').forEach(tx => {
      const ts = tx.querySelectorAll('tspan');
      if (ts.length !== 1) return;
      for (const a of ['font-family', 'font-size', 'font-style', 'font-weight', 'fill', 'fill-opacity', 'stroke', 'stroke-opacity', 'stroke-width', 'letter-spacing', 'word-spacing']) {
        const v = ts[0].getAttribute(a);
        if (v !== null) tx.setAttribute(a, v);
      }
      const xs = String(ts[0].getAttribute('x') || '0').trim().split(/\s+/);
      ts[0].setAttribute('x', xs[0] || '0');
    });
    let svg = new XMLSerializer().serializeToString(el);
    const fonts = [];
    svg = svg.replace(/@font-face\s*\{\s*font-family:\s*"([^"]+)";\s*src:\s*url\(([^)]+)\);\s*\}/g, (m, fam, url) => { fonts.push({ fam, url }); return ''; });
    for (const f of fonts) {
      let real = f.fam;
      try { const obj = page.commonObjs.get(f.fam); if (obj && obj.name) real = cleanFont(obj.name); } catch (e) { /* not resolved */ }
      f.real = real;
      svg = svg.split(`"${f.fam}"`).join(`"${real}"`).split(`'${f.fam}'`).join(`'${real}'`).split(`font-family="${f.fam}"`).join(`font-family="${real}"`);
    }
    return { svg, w: vp.width, h: vp.height, fonts };
  };
  const addFonts = async fonts => {
    S.doc.fonts = S.doc.fonts || [];
    for (const f of fonts) if (!S.doc.fonts.some(x => x.family === f.real)) S.doc.fonts.push({ family: f.real, data: f.url, file: f.real + '.otf' });
    await O.io.registerFonts();
  };
  const thumbs = async (lib, pdf, box, count) => {
    for (let i = 1; i <= count; i++) {
      const cell = box.querySelector(`[data-pg="${i}"] .pp-th`);
      if (!cell) continue;
      try {
        const page = await pdf.getPage(i);
        const vp0 = page.getViewport({ scale: 1 });
        const vp = page.getViewport({ scale: 110 / Math.max(vp0.width, vp0.height) });
        const cv = document.createElement('canvas');
        cv.width = Math.ceil(vp.width); cv.height = Math.ceil(vp.height);
        await page.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise;
        cell.innerHTML = '';
        cell.appendChild(cv);
      } catch (e) { cell.textContent = '—'; }
      if (!document.body.contains(box)) return;
    }
  };
  const ask = (title, text, buttons) => new Promise(res => { ui.dialog({ title, body: `<div class="dlg-text">${esc(text)}</div>`, buttons, onOk: (v, b) => res(b), onCancel: () => res(null) }); });
  PDF.open = async (file, opts = {}) => {
    const name = String(file.name || 'PDF').replace(/\.(pdf|ai)$/i, '');
    const u8 = new Uint8Array(await file.arrayBuffer());
    const doc = opts.ignoreEmbedded ? null : await PDF.extractDoc(u8);
    if (doc && doc.pages) {
      const b = await ask('PDF з VIBSma', t('Цей PDF збережено з можливістю редагування. Відкрити всі шари як документ VIBSma чи імпортувати сторінки як графіку?'), [{ id: 'graphics', label: 'Як графіку' }, { id: 'doc', label: 'Відкрити для редагування', primary: true }]);
      if (!b) return;
      if (b === 'doc') {
        doc.name = doc.name || name;
        if (O.projects && !O.projects.disabled) await O.projects.createFrom(doc);
        else { O.io.loadJSON(JSON.stringify(doc), file.name); setTimeout(() => V.fit(null, 80, 1), 0); }
        O.toast('Відкрито документ «{name}» з усіма шарами', { name: doc.name });
        return 'doc';
      }
    }
    O.toast('Відкриваю PDF…');
    let lib, pdf;
    try {
      lib = await PDF.loadReader();
      // raw pixels instead of ImageBitmaps: the SVG back-end needs them to embed images
      pdf = await lib.getDocument({ data: u8.slice(), isEvalSupported: false, fontExtraProperties: true, isOffscreenCanvasSupported: false }).promise;
    } catch (e) {
      console.warn(e);
      if (e && e.name === 'PasswordException') return O.toast('PDF захищено паролем');
      return O.toast(/\.ai$/i.test(file.name || '') ? 'Цей файл .ai збережено без PDF-сумісності. В Illustrator: «Зберегти як» → увімкніть «Створити PDF-сумісний файл».' : 'Не вдалося відкрити PDF: {msg}', { msg: e && e.message });
    }
    const n = pdf.numPages;
    const opt = opts.auto ? { pages: Array.from({ length: n }, (_, i) => i + 1), mode: opts.mode || 'vector', target: opts.target || 'new' } : await new Promise(res => {
      const max = Math.min(n, 200);
      const grid = Array.from({ length: max }, (_, i) => `<label class="pp" data-pg="${i + 1}"><span class="pp-th">${i + 1}</span><span class="pp-n"><input type="checkbox" data-pgc="${i + 1}"${i < 30 ? ' checked' : ''}> ${i + 1}</span></label>`).join('');
      const d = ui.dialog({
        title: opts.target === 'place' ? 'Помістити PDF' : 'Відкрити PDF',
        body: `<div class="dlg-text">${esc(t('«{name}»: сторінок {n}. Кожна сторінка стане фреймом (артбордом).', { name, n }))}</div><div class="pp-tools"><button type="button" class="btn" data-ppa="all">${esc(t('Усі'))}</button><button type="button" class="btn" data-ppa="none">${esc(t('Жодної'))}</button></div><div class="pp-grid">${grid}</div>`,
        fields: [
          { key: 'mode', label: 'Як імпортувати', type: 'select', value: O.ls.get('pdfMode', 'vector'), options: [['vector', 'Редаговані вектори й текст'], ['image', 'Зображення (растр 2×)']] },
          { key: 'target', label: 'Куди', type: 'select', value: opts.target === 'place' ? 'page' : 'new', options: [['new', 'Новий проєкт'], ['page', 'Поточна сторінка'], ['pages', 'Окремі сторінки документа']] }
        ],
        buttons: [{ id: 'ok', label: 'Імпортувати', primary: true }],
        onOpen: wrap => {
          wrap.querySelector('.dlg').classList.add('wide');
          wrap.addEventListener('click', e => { const b = e.target.closest('[data-ppa]'); if (b) wrap.querySelectorAll('[data-pgc]').forEach(c => { c.checked = b.dataset.ppa === 'all'; }); });
          setTimeout(() => thumbs(lib, pdf, wrap, max), 30);
        },
        onOk: v => { O.ls.set('pdfMode', v.mode); res({ pages: Array.from(d.el.querySelectorAll('[data-pgc]:checked')).map(c => +c.dataset.pgc), mode: v.mode, target: v.target }); },
        onCancel: () => res(null)
      });
    });
    if (!opt || !opt.pages.length) return null;
    // destination
    if (opt.target === 'new') {
      const nd = model.newDoc();
      nd.name = name;
      if (O.projects && !O.projects.disabled) await O.projects.createFrom(nd); else model.load(nd);
    }
    let x = 0, y = 0;
    const page0 = model.page();
    if (opt.target === 'page' && page0.children.length) { const b = model.selBounds(page0.children); x = Math.round(b.x + b.w + 200); y = Math.round(b.y); }
    const made = [];
    PDF.lastErrors = [];
    O.toast('Імпорт сторінок: {n}…', { n: opt.pages.length });
    for (const i of opt.pages) {
      try {
        const page = await pdf.getPage(i);
        const vp = page.getViewport({ scale: 1 });
        if (opt.target === 'pages') {
          const pg = model.newPage(opt.pages.length > 1 ? t('Сторінка {n}', { n: i }) : name);
          S.doc.pages.push(pg); S.pageId = pg.id; model.reindex(); O.emit('page');
          x = 0; y = 0;
        }
        const f = model.create('frame', { name: opt.pages.length > 1 || n > 1 ? `${name} — ${t('сторінка {n}', { n: i })}` : name, w: Math.round(vp.width * 100) / 100, h: Math.round(vp.height * 100) / 100, m: M.translate(x, y), fills: [O.paint.solid('#FFFFFF')], clip: true });
        model.insert(f, model.page());
        model.reindex();
        if (opt.mode === 'image') {
          const k = 2;
          const vpi = page.getViewport({ scale: k });
          const cv = document.createElement('canvas');
          cv.width = Math.ceil(vpi.width); cv.height = Math.ceil(vpi.height);
          const cx = cv.getContext('2d');
          cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height);
          await page.render({ canvasContext: cx, viewport: vpi }).promise;
          const id = O.uid();
          S.doc.assets[id] = { data: cv.toDataURL('image/png'), w: cv.width, h: cv.height, name: f.name };
          const r = model.create('rect', { name: t('Сторінка {n}', { n: i }), w: f.w, h: f.h, fills: [Object.assign(O.paint.image(id), { mode: 'stretch' })] });
          model.insert(r, f);
        } else {
          const res = await PDF.pageSVG(lib, page);
          await addFonts(res.fonts);
          O.io.importSVG(res.svg, { container: f, at: { x: x + f.w / 2, y: y + f.h / 2 }, noCenter: true, noCommit: true, name: t('Сторінка {n}', { n: i }) });
        }
        made.push(f);
        x += Math.ceil(f.w) + 120;
      } catch (e) { console.warn('pdf page', i, e); PDF.lastErrors.push(i + ': ' + (e && (e.stack || e.message) || e)); }
    }
    model.reindex();
    O.select(made.map(f => f.id));
    O.history.commit('Імпорт PDF');
    setTimeout(() => V.fit(model.selBounds(made), 80, 1), 30);
    O.toast('Імпортовано сторінок PDF: {n}', { n: made.length });
    return made;
  };

  // ---------- hooks & commands ----------
  O.io.openHooks.push({ test: f => /\.(pdf|ai)$/i.test(f.name || '') || f.type === 'application/pdf', open: f => PDF.open(f, { target: 'new' }) });
  O.cmd('openPDF', 'Відкрити PDF / AI…', async () => { const f = await O.io.pickFiles('.pdf,.ai,application/pdf'); if (f[0]) PDF.open(f[0], { target: 'new' }); }, { group: 'Файл' });
  O.cmd('placePDF', 'Помістити PDF…', async () => { const f = await O.io.pickFiles('.pdf,.ai,application/pdf'); if (f[0]) PDF.open(f[0], { target: 'place' }); }, { group: 'Файл' });
  O.cmd('savePDF', 'Зберегти як Adobe PDF…', () => PDF.saveDialog(), { keys: ['Ctrl+Alt+P'], group: 'Файл' });
  const fm = O.MENUS.find(m => m[0] === 'Файл')[1];
  fm.splice(fm.indexOf('importSVG') + 1, 0, 'openPDF', 'placePDF');
  fm.splice(fm.indexOf('exportDialog') + 1, 0, 'savePDF');
})();
