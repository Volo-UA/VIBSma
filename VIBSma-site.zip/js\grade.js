'use strict';
/* VIBSma — colour grading in the spirit of DaVinci Resolve's Color page.
   A grade is a list of serial nodes. Each node: Lift / Gamma / Gain / Offset wheels (colour + master),
   temperature, tint, exposure, contrast + pivot, shadows, highlights, saturation, hue, custom curves (Y, R, G, B),
   a 3D LUT (.cube) and a key mix. Rendered on the GPU (WebGL2), one pass per node.
   Also: scopes (waveform, RGB parade, vectorscope, histogram) and the UI widgets (colour wheels, curve editor). */
(function () {
  const O = window.O;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const GR = O.grade = {};

  // ---------- model ----------
  const wheel = () => ({ r: 0, g: 0, b: 0, y: 0 });
  GR.newNode = (name) => ({ id: O.uid(), name: name || t('Вузол'), on: true, mix: 1, lift: wheel(), gamma: wheel(), gain: wheel(), offset: wheel(), temp: 0, tint: 0, exposure: 0, contrast: 1, pivot: 0.435, shadows: 0, highlights: 0, sat: 1, hue: 0, curves: { y: [[0, 0], [1, 1]], r: [[0, 0], [1, 1]], g: [[0, 0], [1, 1]], b: [[0, 0], [1, 1]] }, lut: null });
  GR.newGrade = () => ({ nodes: [GR.newNode(t('Вузол {n}', { n: 1 }))] });
  const isIdentityCurve = c => c.length === 2 && c[0][0] === 0 && c[0][1] === 0 && c[1][0] === 1 && c[1][1] === 1;
  const wheelZero = w => !w.r && !w.g && !w.b && !w.y;
  GR.isNeutral = n => !n || !n.on || (wheelZero(n.lift) && wheelZero(n.gamma) && wheelZero(n.gain) && wheelZero(n.offset) && !n.temp && !n.tint && !n.exposure && n.contrast === 1 && !n.shadows && !n.highlights && n.sat === 1 && !n.hue && ['y', 'r', 'g', 'b'].every(k => isIdentityCurve(n.curves[k])) && !n.lut) || n.mix === 0;
  GR.active = g => !!(g && g.nodes && g.nodes.some(n => !GR.isNeutral(n)));
  // looks (CapCut «Filters», also starting points on the Color page)
  GR.PRESETS = [
    ['Нейтральний', () => ({})],
    ['Teal & Orange', () => ({ lift: { r: -0.04, g: 0.01, b: 0.05, y: 0 }, gain: { r: 0.06, g: 0.02, b: -0.05, y: 0 }, sat: 1.15, contrast: 1.1 })],
    ['Кіно', () => ({ contrast: 1.18, sat: 0.85, lift: { r: 0, g: 0.01, b: 0.03, y: 0.02 }, curves: { y: [[0, 0.04], [0.25, 0.2], [0.75, 0.8], [1, 0.96]], r: [[0, 0], [1, 1]], g: [[0, 0], [1, 1]], b: [[0, 0], [1, 1]] } })],
    ['Теплий', () => ({ temp: 0.35, sat: 1.08 })],
    ['Холодний', () => ({ temp: -0.35, tint: 0.05 })],
    ['Вінтаж', () => ({ sat: 0.7, contrast: 0.9, lift: { r: 0.05, g: 0.03, b: 0, y: 0.04 }, gain: { r: 0.02, g: 0, b: -0.06, y: -0.03 } })],
    ['Чорно-білий', () => ({ sat: 0, contrast: 1.15 })],
    ['Нуар', () => ({ sat: 0, contrast: 1.45, pivot: 0.4, gamma: { r: 0, g: 0, b: 0, y: -0.1 } })],
    ['Яскравий', () => ({ sat: 1.4, contrast: 1.12, exposure: 0.1 })],
    ['Пастель', () => ({ sat: 0.75, lift: { r: 0.03, g: 0.03, b: 0.04, y: 0.08 }, contrast: 0.85 })],
    ['Матовий', () => ({ curves: { y: [[0, 0.1], [0.5, 0.5], [1, 0.93]], r: [[0, 0], [1, 1]], g: [[0, 0], [1, 1]], b: [[0, 0], [1, 1]] }, sat: 0.9 })],
    ['Блокбастер', () => ({ lift: { r: -0.02, g: 0.02, b: 0.06, y: -0.02 }, gain: { r: 0.08, g: 0.03, b: -0.04, y: 0.02 }, contrast: 1.25, sat: 1.1 })],
    ['Сутінки', () => ({ temp: -0.2, tint: 0.15, exposure: -0.15, sat: 1.1 })]
  ];
  GR.applyPreset = (node, i) => {
    const fresh = GR.newNode(node.name);
    const p = GR.PRESETS[i][1]();
    Object.assign(node, { lift: fresh.lift, gamma: fresh.gamma, gain: fresh.gain, offset: fresh.offset, temp: 0, tint: 0, exposure: 0, contrast: 1, pivot: 0.435, shadows: 0, highlights: 0, sat: 1, hue: 0, curves: fresh.curves }, O.clone(p));
  };

  // ---------- curves: monotone cubic spline → 256 values ----------
  GR.sampleCurve = pts => {
    const p = pts.slice().sort((a, b) => a[0] - b[0]);
    const n = p.length, out = new Float32Array(256);
    if (n < 2) { for (let i = 0; i < 256; i++) out[i] = i / 255; return out; }
    const dx = [], dy = [], m = [];
    for (let i = 0; i < n - 1; i++) { dx.push(Math.max(1e-6, p[i + 1][0] - p[i][0])); dy.push((p[i + 1][1] - p[i][1]) / dx[i]); }
    m.push(dy[0]);
    for (let i = 1; i < n - 1; i++) m.push(dy[i - 1] * dy[i] <= 0 ? 0 : (dy[i - 1] + dy[i]) / 2);
    m.push(dy[n - 2]);
    for (let i = 0; i < n - 1; i++) { if (dy[i] === 0) { m[i] = m[i + 1] = 0; continue; } const a = m[i] / dy[i], b = m[i + 1] / dy[i], s = a * a + b * b; if (s > 9) { const k = 3 / Math.sqrt(s); m[i] = k * a * dy[i]; m[i + 1] = k * b * dy[i]; } }
    let seg = 0;
    for (let i = 0; i < 256; i++) {
      const x = i / 255;
      if (x <= p[0][0]) { out[i] = p[0][1]; continue; }
      if (x >= p[n - 1][0]) { out[i] = p[n - 1][1]; continue; }
      while (seg < n - 2 && x > p[seg + 1][0]) seg++;
      const h = dx[seg], tt = (x - p[seg][0]) / h, t2 = tt * tt, t3 = t2 * tt;
      out[i] = (2 * t3 - 3 * t2 + 1) * p[seg][1] + (t3 - 2 * t2 + tt) * h * m[seg] + (-2 * t3 + 3 * t2) * p[seg + 1][1] + (t3 - t2) * h * m[seg + 1];
    }
    for (let i = 0; i < 256; i++) out[i] = Math.min(1, Math.max(0, out[i]));
    return out;
  };

  // ---------- .cube LUT ----------
  const lutCache = new Map();
  GR.parseCube = text => {
    let size = 0; const data = [];
    let dmin = [0, 0, 0], dmax = [1, 1, 1];
    for (const raw of String(text).split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line[0] === '#') continue;
      const m = /^LUT_3D_SIZE\s+(\d+)/i.exec(line);
      if (m) { size = +m[1]; continue; }
      if (/^DOMAIN_MIN/i.test(line)) { dmin = line.split(/\s+/).slice(1).map(Number); continue; }
      if (/^DOMAIN_MAX/i.test(line)) { dmax = line.split(/\s+/).slice(1).map(Number); continue; }
      if (/^[A-Z_]/i.test(line)) continue;
      const v = line.split(/\s+/).map(Number);
      if (v.length >= 3 && v.every(x => isFinite(x))) data.push(v[0], v[1], v[2]);
    }
    if (!size || data.length < size * size * size * 3) throw new Error(t('Це не 3D LUT у форматі .cube'));
    const u8 = new Uint8Array(size * size * size * 4);
    for (let i = 0; i < size * size * size; i++) for (let c = 0; c < 3; c++) u8[i * 4 + c] = Math.round(Math.min(1, Math.max(0, (data[i * 3 + c] - dmin[c]) / ((dmax[c] - dmin[c]) || 1))) * 255);
    for (let i = 0; i < size * size * size; i++) u8[i * 4 + 3] = 255;
    return { size, data: u8 };
  };
  GR.lutOf = assetId => {
    if (!assetId) return null;
    if (lutCache.has(assetId)) return lutCache.get(assetId);
    const a = O.state.doc.assets[assetId];
    if (!a || !a.data) return null;
    let text = a.data;
    if (/^data:/.test(text)) { const b64 = text.split(',')[1] || ''; try { text = decodeURIComponent(escape(atob(b64))); } catch (e) { text = atob(b64); } }
    let lut = null;
    try { lut = GR.parseCube(text); } catch (e) { console.warn(e); }
    lutCache.set(assetId, lut);
    return lut;
  };

  // ---------- GPU renderer ----------
  const VS = `#version 300 es
in vec2 p; out vec2 uv;
void main(){ uv = p * 0.5 + 0.5; gl_Position = vec4(p, 0.0, 1.0); }`;
  const FS = `#version 300 es
precision highp float; precision highp sampler3D;
in vec2 uv; out vec4 o;
uniform sampler2D src; uniform sampler2D curve; uniform sampler3D lut;
uniform vec4 lift, gamma, gain, offs; uniform float temp, tint, expo, contrast, pivot, shadows, highlights, sat, hue, mixv, useLut, lutSize, flipY;
float luma(vec3 c){ return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
void main(){
  vec2 st = vec2(uv.x, flipY > 0.5 ? 1.0 - uv.y : uv.y);
  vec4 s = texture(src, st);
  vec3 c = s.rgb;
  vec3 orig = c;
  // white balance and exposure
  c *= vec3(1.0 + temp * 0.18 + tint * 0.04, 1.0 - tint * 0.12, 1.0 - temp * 0.18 + tint * 0.04);
  c *= exp2(expo);
  // offset, lift (shadows), gain (highlights), gamma (midtones)
  c += offs.rgb + offs.a;
  vec3 L = lift.rgb + lift.a, G = gain.rgb + gain.a, M = gamma.rgb + gamma.a;
  c = c * (1.0 + G) + L * (1.0 - clamp(c, 0.0, 1.0));
  c = pow(max(c, vec3(0.0)), 1.0 / max(vec3(0.05), 1.0 + M * 1.5));
  // contrast around the pivot
  c = (c - pivot) * contrast + pivot;
  // shadows / highlights
  float y = luma(clamp(c, 0.0, 1.0));
  c += shadows * 0.5 * (1.0 - smoothstep(0.0, 0.5, y)) + highlights * 0.5 * smoothstep(0.5, 1.0, y);
  // saturation and hue rotation
  y = luma(c);
  vec3 ch = c - y;
  float a = radians(hue), cs = cos(a), sn = sin(a);
  c = y + ch * sat;
  if (hue != 0.0) {
    // the CSS hue-rotate matrix, row by row
    vec3 r0 = vec3(0.213 + cs * 0.787 - sn * 0.213, 0.715 - cs * 0.715 - sn * 0.715, 0.072 - cs * 0.072 + sn * 0.928);
    vec3 r1 = vec3(0.213 - cs * 0.213 + sn * 0.143, 0.715 + cs * 0.285 + sn * 0.140, 0.072 - cs * 0.072 - sn * 0.283);
    vec3 r2 = vec3(0.213 - cs * 0.213 - sn * 0.787, 0.715 - cs * 0.715 + sn * 0.715, 0.072 + cs * 0.928 + sn * 0.072);
    c = vec3(dot(r0, c), dot(r1, c), dot(r2, c));
  }
  c = clamp(c, 0.0, 1.0);
  // curves (baked: red/green/blue already include the master Y curve)
  c = vec3(texture(curve, vec2(c.r * 0.996 + 0.002, 0.5)).r, texture(curve, vec2(c.g * 0.996 + 0.002, 0.5)).g, texture(curve, vec2(c.b * 0.996 + 0.002, 0.5)).b);
  // 3D LUT
  if (useLut > 0.5) { vec3 q = c * (lutSize - 1.0) / lutSize + 0.5 / lutSize; c = texture(lut, q).rgb; }
  o = vec4(mix(orig, c, mixv), s.a);
}`;
  let R = null;
  const init = () => {
    if (R) return R;
    const cv = document.createElement('canvas');
    const gl = cv.getContext('webgl2', { premultipliedAlpha: false, preserveDrawingBuffer: true, antialias: false });
    if (!gl) { R = { ok: false }; return R; }
    const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
    const pr = gl.createProgram();
    gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr);
    if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(pr));
    gl.useProgram(pr);
    const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const U = {}; for (const k of ['src', 'curve', 'lut', 'lift', 'gamma', 'gain', 'offs', 'temp', 'tint', 'expo', 'contrast', 'pivot', 'shadows', 'highlights', 'sat', 'hue', 'mixv', 'useLut', 'lutSize', 'flipY']) U[k] = gl.getUniformLocation(pr, k);
    gl.uniform1i(U.src, 0); gl.uniform1i(U.curve, 1); gl.uniform1i(U.lut, 2);
    const tex = (target) => { const x = gl.createTexture(); gl.bindTexture(target, x); gl.texParameteri(target, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(target, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.texParameteri(target, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(target, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); if (target === gl.TEXTURE_3D) gl.texParameteri(target, gl.TEXTURE_WRAP_R, gl.CLAMP_TO_EDGE); return x; };
    const ping = [0, 1].map(() => { const tx = tex(gl.TEXTURE_2D); const fb = gl.createFramebuffer(); return { tx, fb, w: 0, h: 0 }; });
    const srcTex = tex(gl.TEXTURE_2D), curveTex = tex(gl.TEXTURE_2D), lutTex = tex(gl.TEXTURE_3D);
    gl.bindTexture(gl.TEXTURE_3D, lutTex);
    gl.texImage3D(gl.TEXTURE_3D, 0, gl.RGBA, 2, 2, 2, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array(32));
    R = { ok: true, cv, gl, U, ping, srcTex, curveTex, lutTex, lutFor: null };
    return R;
  };
  GR.supported = () => { try { return init().ok; } catch (e) { console.warn(e); return false; } };
  const curveData = n => {
    const Y = GR.sampleCurve(n.curves.y), Rc = GR.sampleCurve(n.curves.r), Gc = GR.sampleCurve(n.curves.g), Bc = GR.sampleCurve(n.curves.b);
    const u8 = new Uint8Array(256 * 4);
    const at = (arr, v) => arr[Math.round(Math.min(1, Math.max(0, v)) * 255)];
    for (let i = 0; i < 256; i++) { const y = Y[i]; u8[i * 4] = at(Rc, y) * 255; u8[i * 4 + 1] = at(Gc, y) * 255; u8[i * 4 + 2] = at(Bc, y) * 255; u8[i * 4 + 3] = 255; }
    return u8;
  };
  // grade a source (video, image, canvas) into a canvas of w×h; returns that canvas (reused between calls)
  GR.apply = (source, grade, w, h) => {
    const r = init();
    if (!r.ok) return null;
    const { gl, U, ping } = r;
    w = Math.max(1, Math.round(w)); h = Math.max(1, Math.round(h));
    if (r.cv.width !== w || r.cv.height !== h) { r.cv.width = w; r.cv.height = h; }
    for (const p of ping) if (p.w !== w || p.h !== h) { gl.bindTexture(gl.TEXTURE_2D, p.tx); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null); gl.bindFramebuffer(gl.FRAMEBUFFER, p.fb); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, p.tx, 0); p.w = w; p.h = h; }
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, r.srcTex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source); } catch (e) { return null; }
    const nodes = (grade && grade.nodes || []).filter(n => !GR.isNeutral(n));
    const passes = nodes.length ? nodes : [GR.newNode()];
    let input = r.srcTex;
    gl.viewport(0, 0, w, h);
    passes.forEach((n, i) => {
      const last = i === passes.length - 1;
      const target = last ? null : ping[i % 2];
      gl.bindFramebuffer(gl.FRAMEBUFFER, target ? target.fb : null);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, input);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, r.curveTex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 256, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, curveData(n));
      const lut = n.lut ? GR.lutOf(n.lut) : null;
      gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_3D, r.lutTex);
      if (lut && r.lutFor !== n.lut) { gl.texImage3D(gl.TEXTURE_3D, 0, gl.RGBA, lut.size, lut.size, lut.size, 0, gl.RGBA, gl.UNSIGNED_BYTE, lut.data); r.lutFor = n.lut; }
      const w4 = (u, v) => gl.uniform4f(u, v.r, v.g, v.b, v.y);
      w4(U.lift, n.lift); w4(U.gamma, n.gamma); w4(U.gain, n.gain); w4(U.offs, n.offset);
      gl.uniform1f(U.temp, n.temp); gl.uniform1f(U.tint, n.tint); gl.uniform1f(U.expo, n.exposure); gl.uniform1f(U.contrast, n.contrast); gl.uniform1f(U.pivot, n.pivot);
      gl.uniform1f(U.shadows, n.shadows); gl.uniform1f(U.highlights, n.highlights); gl.uniform1f(U.sat, n.sat); gl.uniform1f(U.hue, n.hue); gl.uniform1f(U.mixv, n.mix === undefined ? 1 : n.mix);
      gl.uniform1f(U.useLut, lut ? 1 : 0); gl.uniform1f(U.lutSize, lut ? lut.size : 2);
      // images uploaded from the DOM are top-down; framebuffer passes are bottom-up
      gl.uniform1f(U.flipY, i === 0 ? 1 : 0);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      if (target) input = target.tx;
    });
    // the default framebuffer is bottom-up: one final flip happened in pass 0 only when there was a single pass
    return r.cv;
  };

  // ---------- scopes ----------
  const sc = document.createElement('canvas'); sc.width = 256; sc.height = 144;
  const scx = sc.getContext('2d', { willReadFrequently: true });
  GR.scope = (source, target, kind) => {
    const c = target.getContext('2d');
    const W = target.width, H = target.height;
    c.fillStyle = '#0c0c0e'; c.fillRect(0, 0, W, H);
    if (!source || !source.width) return;
    scx.drawImage(source, 0, 0, sc.width, sc.height);
    const d = scx.getImageData(0, 0, sc.width, sc.height).data;
    // graticule
    c.strokeStyle = 'rgba(255,255,255,.08)'; c.lineWidth = 1;
    if (kind !== 'vector') for (let i = 0; i <= 4; i++) { const y = Math.round(H - 8 - (H - 16) * i / 4) + 0.5; c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
    const img = c.getImageData(0, 0, W, H), px = img.data;
    const plot = (x, y, r, g, b) => { x |= 0; y |= 0; if (x < 0 || y < 0 || x >= W || y >= H) return; const i = (y * W + x) * 4; px[i] = Math.min(255, px[i] + r); px[i + 1] = Math.min(255, px[i + 1] + g); px[i + 2] = Math.min(255, px[i + 2] + b); px[i + 3] = 255; };
    const yOf = v => H - 8 - (H - 16) * v / 255;
    if (kind === 'waveform') {
      for (let y = 0; y < sc.height; y++) for (let x = 0; x < sc.width; x++) { const i = (y * sc.width + x) * 4; const l = 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]; plot(x / sc.width * W, yOf(l), 30, 60, 30); }
    } else if (kind === 'parade') {
      const third = W / 3;
      for (let y = 0; y < sc.height; y++) for (let x = 0; x < sc.width; x++) { const i = (y * sc.width + x) * 4; const xx = x / sc.width * (third - 4); plot(xx, yOf(d[i]), 70, 12, 12); plot(third + xx, yOf(d[i + 1]), 12, 70, 12); plot(2 * third + xx, yOf(d[i + 2]), 16, 24, 80); }
    } else if (kind === 'vector') {
      const cx = W / 2, cy = H / 2, rad = Math.min(W, H) / 2 - 6;
      for (let i = 0; i < d.length; i += 4) { const r = d[i] / 255, g = d[i + 1] / 255, b = d[i + 2] / 255; const cb = -0.1146 * r - 0.3854 * g + 0.5 * b, cr = 0.5 * r - 0.4542 * g - 0.0458 * b; plot(cx + cb * 2 * rad, cy - cr * 2 * rad, 40, 55, 40); }
      img.data.set(px);
    } else if (kind === 'histogram') {
      const hr = new Uint32Array(256), hg = new Uint32Array(256), hb = new Uint32Array(256);
      for (let i = 0; i < d.length; i += 4) { hr[d[i]]++; hg[d[i + 1]]++; hb[d[i + 2]]++; }
      const mx = Math.max(1, ...hr, ...hg, ...hb);
      c.putImageData(img, 0, 0);
      c.globalCompositeOperation = 'lighter';
      for (const [hh, col] of [[hr, 'rgba(255,60,60,.7)'], [hg, 'rgba(60,255,60,.7)'], [hb, 'rgba(70,110,255,.7)']]) {
        c.fillStyle = col; c.beginPath(); c.moveTo(0, H);
        for (let i = 0; i < 256; i++) c.lineTo(i / 255 * W, H - Math.sqrt(hh[i] / mx) * (H - 6));
        c.lineTo(W, H); c.closePath(); c.fill();
      }
      c.globalCompositeOperation = 'source-over';
      return;
    }
    c.putImageData(img, 0, 0);
    if (kind === 'vector') {
      const cx = W / 2, cy = H / 2, rad = Math.min(W, H) / 2 - 6;
      c.strokeStyle = 'rgba(255,255,255,.18)'; c.beginPath(); c.arc(cx, cy, rad, 0, Math.PI * 2); c.stroke();
      // skin tone line and colour targets
      c.strokeStyle = 'rgba(255,200,150,.35)'; c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.cos(-2.15) * rad, cy + Math.sin(-2.15) * rad); c.stroke();
      const T = [['R', 1, 0, 0], ['G', 0, 1, 0], ['B', 0, 0, 1], ['C', 0, 1, 1], ['M', 1, 0, 1], ['Y', 1, 1, 0]];
      c.font = '9px system-ui'; c.fillStyle = 'rgba(255,255,255,.45)';
      for (const [l, r, g, b] of T) { const cb = -0.1146 * r - 0.3854 * g + 0.5 * b, cr = 0.5 * r - 0.4542 * g - 0.0458 * b; const x = cx + cb * 2 * rad * 0.75, y = cy - cr * 2 * rad * 0.75; c.strokeRect(x - 4, y - 4, 8, 8); c.fillText(l, x + 6, y + 3); }
    }
  };

  // ---------- widgets ----------
  // colour wheel: drag the puck to push the colour, the slider below is the master (Y)
  GR.wheelWidget = (label, value, onChange, onEnd) => {
    const el = O.h(`<div class="gw"><div class="gw-l">${esc(t(label))}</div><canvas width="132" height="132" class="gw-c" aria-label="${esc(t(label))}"></canvas><input type="range" min="-100" max="100" step="1" class="gw-y" aria-label="${esc(t(label))} Y"><div class="gw-v"></div></div>`);
    const cv = el.querySelector('canvas'), yIn = el.querySelector('.gw-y'), vEl = el.querySelector('.gw-v');
    const c = cv.getContext('2d'), R0 = 60, cx = 66, cy = 66;
    const bg = c.createImageData(132, 132);
    for (let y = 0; y < 132; y++) for (let x = 0; x < 132; x++) {
      const dx = x - cx, dy = y - cy, r = Math.hypot(dx, dy) / R0;
      const i = (y * 132 + x) * 4;
      if (r > 1) { bg.data[i + 3] = 0; continue; }
      const hh = (Math.atan2(-dy, dx) / (2 * Math.PI) + 1) % 1;
      const col = O.color.fromHsv({ h: hh * 360, s: Math.min(1, r) * 0.65, v: 0.55 });
      bg.data[i] = col.r; bg.data[i + 1] = col.g; bg.data[i + 2] = col.b; bg.data[i + 3] = 255;
    }
    const SCALE = 0.25;
    const toXY = v => { const l = (v.r + v.g + v.b) / 3; const vr = v.r - l, vg = v.g - l, vb = v.b - l; const x = vr - 0.5 * vg - 0.5 * vb, y = 0.866 * (vg - vb); return { x: cx + x / SCALE * R0 / 1.5, y: cy - y / SCALE * R0 / 1.5 }; };
    const fromXY = (x, y) => { let X = (x - cx) / R0 * 1.5 * SCALE, Y = -(y - cy) / R0 * 1.5 * SCALE; const len = Math.hypot(X, Y), mx = SCALE * 1.5; if (len > mx) { X *= mx / len; Y *= mx / len; } return { r: X * 2 / 3, g: -X / 3 + Y / 1.732, b: -X / 3 - Y / 1.732 }; };
    const draw = () => {
      c.clearRect(0, 0, 132, 132); c.putImageData(bg, 0, 0);
      c.strokeStyle = 'rgba(255,255,255,.25)'; c.beginPath(); c.moveTo(cx - 6, cy); c.lineTo(cx + 6, cy); c.moveTo(cx, cy - 6); c.lineTo(cx, cy + 6); c.stroke();
      const p = toXY(value);
      c.fillStyle = '#fff'; c.strokeStyle = '#000'; c.lineWidth = 1.5; c.beginPath(); c.arc(p.x, p.y, 5, 0, Math.PI * 2); c.fill(); c.stroke();
      yIn.value = Math.round(value.y * 200);
      vEl.textContent = [value.r, value.g, value.b, value.y].map(v => (v >= 0 ? '+' : '') + v.toFixed(2)).join(' ');
    };
    let dragging = false;
    const set = e => { const r = cv.getBoundingClientRect(); const v = fromXY((e.clientX - r.left) * 132 / r.width, (e.clientY - r.top) * 132 / r.height); value.r = v.r; value.g = v.g; value.b = v.b; draw(); onChange(); };
    cv.addEventListener('pointerdown', e => { dragging = true; cv.setPointerCapture(e.pointerId); set(e); });
    cv.addEventListener('pointermove', e => { if (dragging) set(e); });
    cv.addEventListener('pointerup', () => { if (dragging) { dragging = false; onEnd(); } });
    cv.addEventListener('dblclick', () => { value.r = value.g = value.b = 0; draw(); onChange(); onEnd(); });
    yIn.addEventListener('input', () => { value.y = +yIn.value / 200; draw(); onChange(); });
    yIn.addEventListener('change', onEnd);
    yIn.addEventListener('dblclick', () => { value.y = 0; draw(); onChange(); onEnd(); });
    draw();
    el.redraw = draw;
    return el;
  };
  // curve editor: click to add a point, drag to move, double-click a point to remove it
  GR.curveWidget = (node, onChange, onEnd) => {
    const el = O.h(`<div class="gcv"><div class="gcv-tabs">${['y', 'r', 'g', 'b'].map(k => `<button type="button" data-ch="${k}" class="${k === 'y' ? 'on' : ''}">${k.toUpperCase()}</button>`).join('')}<button type="button" data-ch="reset" title="${esc(t('Скинути криву'))}">↺</button></div><canvas width="240" height="240" aria-label="${esc(t('Криві'))}"></canvas></div>`);
    const cv = el.querySelector('canvas'), c = cv.getContext('2d');
    let ch = 'y', drag = -1;
    const COL = { y: '#ddd', r: '#ff5a5a', g: '#4fdc6a', b: '#5a8cff' };
    const P = () => node.curves[ch];
    const draw = () => {
      c.fillStyle = '#121214'; c.fillRect(0, 0, 240, 240);
      c.strokeStyle = 'rgba(255,255,255,.08)';
      for (let i = 1; i < 4; i++) { c.beginPath(); c.moveTo(i * 60 + 0.5, 0); c.lineTo(i * 60 + 0.5, 240); c.moveTo(0, i * 60 + 0.5); c.lineTo(240, i * 60 + 0.5); c.stroke(); }
      c.strokeStyle = 'rgba(255,255,255,.15)'; c.beginPath(); c.moveTo(0, 240); c.lineTo(240, 0); c.stroke();
      for (const k of ['y', 'r', 'g', 'b']) {
        if (k !== ch && isIdentityCurve(node.curves[k])) continue;
        const s = GR.sampleCurve(node.curves[k]);
        c.strokeStyle = COL[k]; c.globalAlpha = k === ch ? 1 : 0.35; c.lineWidth = k === ch ? 2 : 1;
        c.beginPath(); for (let i = 0; i < 256; i++) { const x = i / 255 * 240, y = 240 - s[i] * 240; if (i) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke();
      }
      c.globalAlpha = 1;
      for (const p of P()) { c.fillStyle = '#fff'; c.strokeStyle = COL[ch]; c.lineWidth = 2; c.beginPath(); c.arc(p[0] * 240, 240 - p[1] * 240, 4.5, 0, Math.PI * 2); c.fill(); c.stroke(); }
    };
    const pos = e => { const r = cv.getBoundingClientRect(); return [Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, 1 - (e.clientY - r.top) / r.height))]; };
    const hit = q => P().findIndex(p => Math.hypot(p[0] - q[0], p[1] - q[1]) < 0.04);
    cv.addEventListener('pointerdown', e => {
      const q = pos(e);
      drag = hit(q);
      if (drag < 0) { P().push(q); P().sort((a, b) => a[0] - b[0]); drag = hit(q); }
      cv.setPointerCapture(e.pointerId); draw(); onChange();
    });
    cv.addEventListener('pointermove', e => {
      if (drag < 0) return;
      const q = pos(e), pts = P();
      const lo = drag > 0 ? pts[drag - 1][0] + 0.01 : 0, hi = drag < pts.length - 1 ? pts[drag + 1][0] - 0.01 : 1;
      pts[drag] = [Math.min(hi, Math.max(lo, q[0])), q[1]];
      draw(); onChange();
    });
    cv.addEventListener('pointerup', () => { if (drag >= 0) { drag = -1; onEnd(); } });
    cv.addEventListener('dblclick', e => { const i = hit(pos(e)); if (i > 0 && i < P().length - 1) { P().splice(i, 1); draw(); onChange(); onEnd(); } });
    el.querySelector('.gcv-tabs').addEventListener('click', e => {
      const b = e.target.closest('[data-ch]'); if (!b) return;
      if (b.dataset.ch === 'reset') { node.curves[ch] = [[0, 0], [1, 1]]; draw(); onChange(); onEnd(); return; }
      ch = b.dataset.ch; el.querySelectorAll('[data-ch]').forEach(x => x.classList.toggle('on', x === b)); draw();
    });
    draw();
    el.redraw = draw;
    return el;
  };
})();
