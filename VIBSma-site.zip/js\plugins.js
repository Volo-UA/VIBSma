'use strict';
/* VIBSma — plugins (Figma: Plugins).
   A plugin is a JavaScript file that calls  obrys.plugin({ id, name, description, run(api) { … } }).
   Installed plugins are kept in the browser; built-in ones cover common chores (contrast check,
   batch rename, placeholder text, find & replace, palettes, grid arrange, photo placeholders, SVG sprite…).
   Plugins run with full access to the editor — install only code you trust. */
(function () {
  const O = window.O, M = O.M, R = O.R, model = O.model, S = O.state, ui = O.ui, V = O.view;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const PL = O.plugins = {};
  const registry = new Map();     // id → { id, name, description, run, builtin, source }
  let last = O.ls.get('pluginLast', null);

  // ---------- API given to plugins ----------
  const api = {
    version: 1,
    get doc() { return S.doc; },
    page: () => model.page(),
    selection: () => O.sel(),
    select: ids => O.select((ids || []).map(x => (typeof x === 'string' ? x : x.id))),
    walk: (fn, list) => model.walk(list || model.page().children, fn),
    find: pred => { const out = []; model.walk(model.page().children, n => { if (pred(n)) out.push(n); }); return out; },
    get: id => model.get(id),
    parent: n => model.parent(n),
    worldBounds: n => model.worldBounds(n),
    create: (type, props = {}, parent) => { const n = model.create(type, props); model.insert(n, parent || V.containerAt(R.center(V.viewRect()))); return n; },
    remove: n => model.remove(n),
    move: (n, dx, dy) => model.applyWorld(n, M.translate(dx, dy), 'resize'),
    paint: O.paint, color: O.color, matrix: M,
    commit: label => O.history.commit(label || t('Плагін')),
    render: () => { O.requestRender(); O.flushRender(); },
    toast: (msg, vars) => O.toast(msg, vars),
    dialog: spec => new Promise(res => ui.dialog(Object.assign({}, spec, { onOk: (v, b) => res(Object.assign({}, v, { _button: b })), onCancel: () => res(null) }))),
    html: (title, html) => ui.dialog({ title, body: html, buttons: [{ id: 'ok', label: 'Закрити', primary: true }] }),
    exportPNG: async (nodes, scale = 1) => (await O.io.renderImage(nodes || O.sel(), { scale, type: 'image/png' })).blob,
    svg: nodes => O.render.svg(nodes || O.sel(), {}).svg,
    download: (blob, name) => O.download(blob, name),
    addImage: async (blobOrFile, at) => O.io.importImage(blobOrFile, at),
    fonts: { load: (fam, w) => (O.fonts ? O.fonts.load(fam, w) : Promise.resolve(false)) },
    command: id => O.run(id)
  };
  PL.api = api;
  const obrys = { plugin: def => PL.register(def), api };
  window.obrys = obrys;

  PL.register = (def, source) => {
    if (!def || !def.id || typeof def.run !== 'function') throw new Error(t('Плагін має містити id і run(api)'));
    const p = Object.assign({ name: def.id, description: '' }, def, { source: source || def.source || null });
    registry.set(p.id, p);
    O.cmd('plugin:' + p.id, p.name, () => PL.run(p.id), { group: 'Плагіни', raw: !p.builtin });
    return p;
  };
  PL.run = async id => {
    const p = registry.get(id);
    if (!p) return;
    last = id; O.ls.set('pluginLast', id);
    try { await p.run(api); } catch (e) { console.error(e); O.toast('Плагін «{name}»: {msg}', { name: p.name, msg: e.message }); }
  };
  // installed (user) plugins: code kept in localStorage
  const stored = () => O.ls.get('plugins', []);
  const loadCode = (code, source) => {
    const before = new Set(registry.keys());
    // eslint-disable-next-line no-new-func
    new Function('obrys', 'api', String(code))(obrys, api);
    const added = Array.from(registry.keys()).filter(k => !before.has(k));
    added.forEach(k => { registry.get(k).source = source; });
    return added;
  };
  PL.install = (code, source) => {
    const ids = loadCode(code, source);
    if (!ids.length) throw new Error(t('Файл не викликав obrys.plugin({...})'));
    const list = stored().filter(x => x.source !== source);
    list.push({ source, code, added: Date.now() });
    O.ls.set('plugins', list);
    return ids;
  };
  PL.uninstall = id => {
    const p = registry.get(id);
    if (!p || p.builtin) return;
    registry.delete(id); O.cmds.delete('plugin:' + id);
    O.ls.set('plugins', stored().filter(x => x.source !== p.source));
  };
  PL.list = () => Array.from(registry.values());

  // ---------- manager ----------
  const TEMPLATE = `// Плагін для VIBSma. Встановлення: Плагіни → Керування плагінами → «Встановити з файлу».
obrys.plugin({
  id: 'hello-world',
  name: 'Привіт, світе',
  description: 'Створює текст і фарбує виділене',
  async run(api) {
    const sel = api.selection();
    sel.forEach(n => { n.fills = [api.paint.solid('#FF3D9A')]; });
    if (!sel.length) api.create('text', { text: 'Привіт зі світу плагінів!', size: 32, font: 'Inter' });
    api.commit('Привіт, світе');
    api.toast('Готово');
  }
});
`;
  PL.manager = () => {
    const list = PL.list();
    const d = ui.dialog({
      title: 'Плагіни',
      body: `<div class="dlg-text">${esc(t('Плагіни автоматизують рутину. Вбудовані вже готові; власні можна встановити з файлу .js. Увага: плагін має повний доступ до редактора — встановлюйте лише перевірений код.'))}</div>
        <div class="pl-list">${list.map(p => `<div class="pl-it"><div><b>${esc(p.builtin ? t(p.name) : p.name)}</b><span>${esc(p.builtin ? t(p.description) : p.description)}</span>${p.builtin ? '' : `<em>${esc(p.source || '')}</em>`}</div><button type="button" class="btn primary" data-pl="run" data-id="${esc(p.id)}">${esc(t('Запустити'))}</button>${p.builtin ? '' : `<button type="button" class="ib" data-pl="del" data-id="${esc(p.id)}" title="${esc(t('Видалити'))}" aria-label="${esc(t('Видалити'))}">${O.icon('trash', 15)}</button>`}</div>`).join('')}</div>
        <textarea class="pl-code" rows="5" spellcheck="false" placeholder="${esc(t('…або вставте сюди код плагіна'))}"></textarea>`,
      buttons: [{ id: 'tpl', label: 'Шаблон плагіна' }, { id: 'paste', label: 'Встановити код' }, { id: 'file', label: 'Встановити з файлу…' }, { id: 'ok', label: 'Закрити', primary: true }],
      onOk: async (v, btn) => {
        try {
          if (btn === 'tpl') O.download(new Blob([TEMPLATE], { type: 'text/javascript' }), 'obrys-plugin.js');
          if (btn === 'file') {
            const files = await O.io.pickFiles('.js,text/javascript', true);
            for (const f of files) { const ids = PL.install(await f.text(), f.name); O.toast('Встановлено: {list}', { list: ids.map(i => registry.get(i).name).join(', ') }); }
            if (files.length) PL.manager();
          }
          if (btn === 'paste') { const code = d.el.querySelector('.pl-code').value; if (code.trim()) { const ids = PL.install(code, t('вставлений код') + ' ' + new Date().toLocaleString(O.lang)); O.toast('Встановлено: {list}', { list: ids.map(i => registry.get(i).name).join(', ') }); } }
        } catch (e) { O.toast('Помилка плагіна: {msg}', { msg: e.message }); }
      }
    });
    d.el.querySelector('.dlg').classList.add('wide');
    d.el.addEventListener('click', e => {
      const b = e.target.closest('[data-pl]');
      if (!b) return;
      e.stopPropagation();
      if (b.dataset.pl === 'run') { d.close(); PL.run(b.dataset.id); }
      if (b.dataset.pl === 'del') { PL.uninstall(b.dataset.id); b.closest('.pl-it').remove(); }
    });
  };

  // ======================================================================
  // BUILT-IN PLUGINS
  // ======================================================================
  const B = def => PL.register(Object.assign({ builtin: true }, def));
  const lum = hex => { const c = O.color.parse(hex) || { r: 0, g: 0, b: 0 }; const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); };
  PL.contrast = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  // colour under a point: topmost solid fill painted below the text
  const bgUnder = n => {
    const b = model.worldBounds(n), p = { x: b.x + b.w / 2, y: b.y + b.h / 2 };
    let child = n, parent = model.parent(n);
    while (parent) {
      const below = parent.children.slice(0, parent.children.indexOf(child)).reverse();
      for (const c of below) {
        if (c.visible === false || c.type === 'text') continue;
        if (!R.contains(model.worldBounds(c), p)) continue;
        const f = (c.fills || []).filter(x => x.visible !== false).reverse().find(x => x.type === 'solid' && (x.opacity === undefined || x.opacity > 0.5));
        if (f) return f.color;
      }
      if (model.isPage(parent)) return parent.bg || '#FFFFFF';
      const f = (parent.fills || []).filter(x => x.visible !== false).reverse().find(x => x.type === 'solid');
      if (f) return f.color;
      child = parent; parent = model.parent(parent);
    }
    return '#FFFFFF';
  };
  B({
    id: 'contrast', name: 'Перевірка контрасту (WCAG)', description: 'Контраст тексту з тлом: AA / AAA для звичайного й великого тексту',
    run(a) {
      let texts = a.selection().filter(n => n.type === 'text');
      if (!texts.length) texts = a.find(n => n.type === 'text' && n.visible !== false);
      if (!texts.length) return a.toast('Немає текстів');
      const rows = texts.slice(0, 300).map(n => {
        const fg = ((n.fills || []).find(f => f.type === 'solid') || { color: '#000000' }).color, bg = bgUnder(n);
        const r = PL.contrast(fg, bg), big = n.size >= 24 || (n.size >= 18.66 && (n.weight || 400) >= 700);
        const aa = r >= (big ? 3 : 4.5), aaa = r >= (big ? 4.5 : 7);
        return { n, fg, bg, r, aa, aaa, big };
      }).sort((x, y) => x.r - y.r);
      const bad = rows.filter(x => !x.aa).length;
      const d = ui.dialog({ title: t('Контраст (WCAG 2.1)') + ` · ${t('не проходять AA')}: ${bad}`, body: `<div class="pf-list">${rows.map((x, i) => `<button type="button" class="pf-it ct-it" data-ct="${i}"><b><i class="ct-sw" style="background:${x.bg};color:${x.fg}">${esc(t('Аа'))}</i> ${esc(x.n.name)} · ${O.fmt(x.r, 2)}:1</b><span class="${x.aa ? 'ok' : ''}">${x.aa ? '✓ AA' : '✗ AA'} · ${x.aaa ? '✓ AAA' : '✗ AAA'} · ${esc(t(x.big ? 'великий текст' : 'звичайний текст'))} · ${x.fg} / ${x.bg}</span></button>`).join('')}</div>`, buttons: [{ id: 'ok', label: 'Закрити', primary: true }] });
      d.el.addEventListener('click', e => { const b = e.target.closest('[data-ct]'); if (b) { const n = rows[+b.dataset.ct].n; O.select([n.id]); V.fit(model.worldBounds(n), 120, 4); } });
      return rows;
    }
  });
  B({
    id: 'rename', name: 'Перейменування шарів', description: 'Шаблон з номером: «Кнопка {n}», пошук і заміна в назвах',
    async run(a) {
      const sel = a.selection();
      if (!sel.length) return a.toast('Виділіть шари');
      const v = await a.dialog({ title: 'Перейменування шарів', body: `<div class="dlg-text">${esc(t('Змінні: {n} — номер, {name} — стара назва, {w} {h} — розмір, {type} — тип.'))}</div>`, fields: [{ key: 'pat', label: 'Нова назва', type: 'text', value: '{name}' }, { key: 'start', label: 'Почати з номера', type: 'number', value: 1 }, { key: 'find', label: 'Знайти в назві', type: 'text', value: '' }, { key: 'rep', label: 'Замінити на', type: 'text', value: '' }] });
      if (!v) return;
      const order = sel.slice().sort((p, q) => { const A = model.worldBounds(p), Bq = model.worldBounds(q); return Math.abs(A.y - Bq.y) > 8 ? A.y - Bq.y : A.x - Bq.x; });
      order.forEach((n, i) => { const b = model.worldBounds(n); let nm = v.pat.replace(/\{n\}/g, String(v.start + i)).replace(/\{name\}/g, n.name).replace(/\{w\}/g, Math.round(b.w)).replace(/\{h\}/g, Math.round(b.h)).replace(/\{type\}/g, t(model.TYPE_NAMES[n.type] || n.type)); if (v.find) nm = nm.split(v.find).join(v.rep); n.name = nm; });
      a.commit('Перейменування шарів');
      a.toast('Перейменовано: {n}', { n: order.length });
    }
  });
  const LOREM = { uk: 'Дизайн — це не лише те, як річ виглядає, а й те, як вона працює. Гарний інтерфейс непомітний: людина просто досягає мети. Кожен відступ, колір і шрифт мають причину. Простота вимагає більше роботи, ніж складність, але результат того вартий.', en: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.' };
  B({
    id: 'lorem', name: 'Текст-заповнювач', description: 'Заповнює виділені тексти українським або латинським «lorem ipsum» тієї ж довжини',
    async run(a) {
      const texts = a.selection().filter(n => n.type === 'text');
      if (!texts.length) return a.toast('Виділіть текстові шари');
      const v = await a.dialog({ title: 'Текст-заповнювач', fields: [{ key: 'lang', label: 'Мова', type: 'select', value: 'uk', options: [['uk', 'Українська'], ['en', 'Lorem ipsum']] }, { key: 'len', label: 'Довжина', type: 'select', value: 'same', options: [['same', 'Як зараз'], ['short', 'Коротко'], ['para', 'Абзац']] }] });
      if (!v) return;
      const src = LOREM[v.lang];
      texts.forEach(n => { const len = v.len === 'short' ? 40 : v.len === 'para' ? src.length : Math.max(8, (n.text || '').length); let s = ''; while (s.length < len) s += (s ? ' ' : '') + src; s = s.slice(0, len).replace(/\s+\S*$/, '') || s.slice(0, len); n.text = s.replace(/[,\s]+$/, '') + (len > 20 ? '.' : ''); });
      a.commit('Текст-заповнювач');
    }
  });
  B({
    id: 'replace', name: 'Пошук і заміна тексту', description: 'У всіх текстах сторінки або документа',
    async run(a) {
      const v = await a.dialog({ title: 'Пошук і заміна', fields: [{ key: 'f', label: 'Знайти', type: 'text', value: '' }, { key: 'r', label: 'Замінити на', type: 'text', value: '' }, { key: 'all', label: 'В усьому документі (усі сторінки)', type: 'checkbox', value: false }, { key: 'case', label: 'З урахуванням регістру', type: 'checkbox', value: false }] });
      if (!v || !v.f) return;
      const re = new RegExp(v.f.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), v.case ? 'g' : 'gi');
      let k = 0;
      const pages = v.all ? S.doc.pages : [model.page()];
      pages.forEach(pg => model.walk(pg.children, n => { if (n.type === 'text' && re.test(n.text)) { re.lastIndex = 0; n.text = n.text.replace(re, v.r); k++; } re.lastIndex = 0; }));
      a.commit('Пошук і заміна');
      a.toast('Замінено в текстах: {n}', { n: k });
    }
  });
  B({
    id: 'fontswap', name: 'Заміна шрифту в документі', description: 'Один шрифт на інший у всіх текстах (наприклад Arial → Inter)',
    async run(a) {
      const fams = Array.from(new Set(S.doc.pages.flatMap(pg => { const o = []; model.walk(pg.children, n => { if (n.type === 'text') o.push(n.font); }); return o; })));
      if (!fams.length) return a.toast('Немає текстів');
      const v = await a.dialog({ title: 'Заміна шрифту', fields: [{ key: 'from', label: 'Шрифт у документі', type: 'select', value: fams[0], options: fams.map(f => [f, f]) }, { key: 'to', label: 'Новий шрифт (будь-який Google Font)', type: 'text', value: 'Inter' }] });
      if (!v || !v.to.trim()) return;
      let k = 0;
      S.doc.pages.forEach(pg => model.walk(pg.children, n => { if (n.type === 'text' && n.font === v.from) { n.font = v.to.trim(); k++; } }));
      if (O.fonts) await O.fonts.load(v.to.trim());
      a.commit('Заміна шрифту');
      a.toast('Змінено текстів: {n}', { n: k });
    }
  });
  B({
    id: 'palette', name: 'Палітра із зображення', description: 'Головні кольори виділеного фото → кольорові стилі',
    async run(a) {
      const n = a.selection().find(x => (x.fills || []).some(f => f.type === 'image'));
      if (!n) return a.toast('Виділіть зображення');
      const asset = S.doc.assets[n.fills.find(f => f.type === 'image').asset];
      const img = await O.io.loadImage(O.assetURL(n.fills.find(f => f.type === 'image').asset));
      const cv = document.createElement('canvas'); cv.width = 64; cv.height = Math.max(1, Math.round(64 * img.naturalHeight / img.naturalWidth));
      const c = cv.getContext('2d'); c.drawImage(img, 0, 0, cv.width, cv.height);
      const d = c.getImageData(0, 0, cv.width, cv.height).data;
      // coarse buckets, then keep distinct popular colours
      const bins = new Map();
      for (let i = 0; i < d.length; i += 4) { if (d[i + 3] < 128) continue; const k = (d[i] >> 4) << 8 | (d[i + 1] >> 4) << 4 | (d[i + 2] >> 4); const b = bins.get(k) || { n: 0, r: 0, g: 0, b: 0 }; b.n++; b.r += d[i]; b.g += d[i + 1]; b.b += d[i + 2]; bins.set(k, b); }
      const cols = Array.from(bins.values()).sort((x, y) => y.n - x.n).map(b => O.color.hex({ r: b.r / b.n, g: b.g / b.n, b: b.b / b.n }));
      const pick = [];
      for (const col of cols) { const cc = O.color.parse(col); if (pick.every(p => { const q = O.color.parse(p); return Math.hypot(cc.r - q.r, cc.g - q.g, cc.b - q.b) > 48; })) pick.push(col); if (pick.length === 6) break; }
      const base = (asset && asset.name) || t('Фото');
      pick.forEach((col, i) => S.doc.swatches.push({ id: O.uid(), name: `${base}/${i + 1}`, color: col }));
      a.commit('Палітра із зображення');
      a.toast('Додано кольорів: {n} (вкладка «Ресурси»)', { n: pick.length });
      return pick;
    }
  });
  B({
    id: 'shades', name: 'Кольорова шкала 50–900', description: 'З одного кольору — 10 відтінків як у Tailwind / Material',
    async run(a) {
      const f = a.selection().map(n => (n.fills || []).find(p => p.type === 'solid')).find(Boolean);
      const v = await a.dialog({ title: 'Кольорова шкала', fields: [{ key: 'c', label: 'Базовий колір', type: 'text', value: f ? f.color : '#0D99FF' }, { key: 'n', label: 'Назва', type: 'text', value: t('Основний') }] });
      if (!v) return;
      const base = O.color.parse(v.c);
      if (!base) return a.toast('Невірний колір');
      const hsl = O.color.toHsl(base);
      const L = { 50: 0.97, 100: 0.93, 200: 0.85, 300: 0.74, 400: 0.62, 500: hsl.l, 600: hsl.l * 0.84, 700: hsl.l * 0.68, 800: hsl.l * 0.52, 900: hsl.l * 0.38 };
      for (const [k, l] of Object.entries(L)) S.doc.swatches.push({ id: O.uid(), name: `${v.n}/${k}`, color: O.color.hex(O.color.fromHsl({ h: hsl.h, s: hsl.s, l: Math.max(0, Math.min(1, l)) })) });
      a.commit('Кольорова шкала');
      a.toast('Додано 10 відтінків «{n}»', { n: v.n });
    }
  });
  B({
    id: 'arrange', name: 'Розкласти сіткою', description: 'Виділені об’єкти в рівну сітку з проміжком',
    async run(a) {
      const sel = O.topSel();
      if (sel.length < 2) return a.toast('Виділіть кілька об’єктів');
      const v = await a.dialog({ title: 'Розкласти сіткою', fields: [{ key: 'cols', label: 'Колонок', type: 'number', value: Math.ceil(Math.sqrt(sel.length)) }, { key: 'gap', label: 'Проміжок', type: 'number', value: 24, unit: 'px' }] });
      if (!v) return;
      const b0 = model.selBounds(sel), cols = Math.max(1, Math.round(v.cols));
      const ws = sel.map(n => model.worldBounds(n));
      const cw = Math.max(...ws.map(b => b.w)), chh = Math.max(...ws.map(b => b.h));
      sel.forEach((n, i) => { const b = ws[i]; const x = b0.x + (i % cols) * (cw + v.gap), y = b0.y + Math.floor(i / cols) * (chh + v.gap); model.applyWorld(n, M.translate(x - b.x, y - b.y), 'resize'); });
      a.commit('Розкласти сіткою');
    }
  });
  B({
    id: 'photos', name: 'Фото-заповнювачі', description: 'Випадкові фото (picsum.photos) у виділені прямокутники й фрейми',
    async run(a) {
      const sel = a.selection().filter(n => ['rect', 'frame', 'ellipse', 'polygon', 'star'].includes(n.type));
      if (!sel.length) return a.toast('Виділіть прямокутники або фрейми');
      a.toast('Завантаження фото…');
      for (const n of sel) {
        try {
          const w = Math.min(1600, Math.max(64, Math.round(n.w))), h = Math.min(1600, Math.max(64, Math.round(n.h)));
          const r = await fetch(`https://picsum.photos/${w}/${h}?random=${O.uid()}`);
          const blob = await r.blob();
          const asset = await O.io.addAsset(await O.io.blobToData(blob), t('Фото'));
          n.fills = [Object.assign(O.paint.image(asset.id), { mode: 'fill' })];
        } catch (e) { a.toast('Немає інтернету або сервіс недоступний'); break; }
      }
      a.commit('Фото-заповнювачі');
    }
  });
  B({
    id: 'sprite', name: 'SVG-спрайт іконок', description: 'Виділені іконки → один sprite.svg з <symbol> і прикладом <use>',
    run(a) {
      const sel = O.topSel();
      if (!sel.length) return a.toast('Виділіть іконки');
      const syms = sel.map(n => {
        const { svg } = O.render.svg([n], {});
        const vb = /viewBox="([^"]+)"/.exec(svg)[1];
        const inner = svg.replace(/^<svg[^>]*>/, '').replace(/<\/svg>$/, '');
        const id = String(n.name).toLowerCase().replace(/[^a-z0-9а-яіїєґ]+/gi, '-').replace(/^-|-$/g, '') || 'icon';
        return { id, sym: `<symbol id="${esc(id)}" viewBox="${vb}">${inner}</symbol>` };
      });
      const sprite = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="display:none">\n${syms.map(s => s.sym).join('\n')}\n</svg>\n<!-- ${syms.map(s => `<svg width="24" height="24"><use href="#${s.id}"/></svg>`).join(' ')} -->\n`;
      a.download(new Blob([sprite], { type: 'image/svg+xml' }), 'sprite.svg');
      a.toast('Спрайт: {n} іконок', { n: syms.length });
    }
  });
  B({
    id: 'a11y-names', name: 'Перевірка назв шарів', description: 'Знаходить шари з назвами за замовчуванням («Прямокутник 12») для порядку в дизайн-системі',
    run(a) {
      const re = new RegExp('^(' + Object.values(model.TYPE_NAMES).map(s => t(s)).join('|') + ') \\d+$');
      const bad = a.find(n => re.test(n.name));
      if (!bad.length) return a.toast('Усі шари мають осмислені назви');
      a.select(bad.map(n => n.id));
      a.toast('Шарів з назвою за замовчуванням: {n} — виділено', { n: bad.length });
    }
  });

  // ---------- commands & menu ----------
  for (const s of stored()) { try { loadCode(s.code, s.source); } catch (e) { console.warn('plugin', s.source, e); } }
  O.cmd('pluginsManage', 'Керування плагінами…', () => PL.manager(), { group: 'Плагіни' });
  O.cmd('pluginLast', 'Запустити останній плагін', () => { if (last && registry.has(last)) PL.run(last); else PL.manager(); }, { keys: ['Ctrl+Alt+Shift+P'], group: 'Плагіни' });
  const menu = () => ['pluginLast', '-'].concat(PL.list().filter(p => p.builtin).map(p => 'plugin:' + p.id), PL.list().some(p => !p.builtin) ? ['-'].concat(PL.list().filter(p => !p.builtin).map(p => 'plugin:' + p.id)) : [], ['-', 'pluginsManage']);
  const entry = ['Плагіни', menu()];
  O.MENUS.splice(O.MENUS.findIndex(m => m[0] === 'Вигляд'), 0, entry);
  // keep the menu in sync with installed plugins
  const origReg = PL.register;
  PL.register = (def, src) => { const p = origReg(def, src); entry[1] = menu(); return p; };
  const origUn = PL.uninstall;
  PL.uninstall = id => { origUn(id); entry[1] = menu(); };
})();
