'use strict';
/* VIBSma — the «Object» and «Select» menus of Adobe Illustrator:
   Object: distribute, ungroup all, lock / hide (selection, artwork above, other layers), expand, expand appearance,
   crop image, rasterize options, gradient mesh, object mosaic, trim marks, flatten transparency, pixel perfect,
   generative recolour, slices, divide objects below, shape, pattern, intertwine, repeat, objects on path,
   envelope distort, perspective, live paint, mockups, text wrap, artboards, graphs, collect for export.
   Select: all on artboard, reselect, next object above / below, same …, object kinds, global edit, saved selections. */
(function () {
  const O = window.O, S = O.state, model = O.model, ops = O.ops, ui = O.ui, G = O.G, M = O.M, R = O.R, P = O.P;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const toast = (m, v) => O.toast(m, v);
  const OM = O.objmenu = {};
  const C = (id, label, run, opts) => O.cmd(id, label, run, Object.assign({ group: 'Об’єкт' }, opts || {}));
  const has = n => () => O.topSel().length >= n;
  const commit = l => O.history.commit(l);
  const round = Math.round, clamp = O.clamp;
  const worldSubs = n => model.subsIn(n, model.worldMatrix(n));
  const toParent = (subs, cont) => G.transformSubs(subs, M.inv(model.containerMatrix(cont)));
  const newPath = (subs, style, name) => model.create('path', Object.assign({ subpaths: subs }, O.clone(style || {}), name ? { name } : {}));
  const imgFill = n => (n.fills || []).find(f => f.type === 'image' && f.asset && f.visible !== false);
  const isImage = n => !!n && ((n.type === 'raster' && !!n.asset) || !!imgFill(n));
  const hasFill = n => (n.fills || []).some(f => f.visible !== false);
  const hasStroke = n => n.sw > 0 && (n.strokes || []).some(s => s.visible !== false);
  const fillOf = n => { const f = (n.fills || []).find(x => x.visible !== false); return f ? O.paintColor(f) : null; };
  const GEOM = new Set(['path', 'rect', 'ellipse', 'polygon', 'star', 'bool']);
  const insertAbove = (n, ref) => { const par = model.parent(ref); model.insert(n, par, par.children.indexOf(ref) + 1); return n; };
  const lineStyle = (strokeColor, sw = 1) => ({ fills: [], strokes: [O.paint.solid(strokeColor)], sw });
  // geometry that paints: a stroke-only object counts as the band of its stroke
  const areaSubs = n => {
    const subs = worldSubs(n);
    if (hasFill(n) || !hasStroke(n)) return subs;
    const sc = Math.sqrt(Math.abs(M.det(model.worldMatrix(n)))) || 1;
    return G.outlineStroke(subs, n.sw * sc, n.cap, n.join, n.miter);
  };
  const paintStyle = n => {
    const st = ops.styleOf(n);
    if (!hasFill(n) && hasStroke(n)) { st.fills = O.clone(st.strokes.filter(s => s.visible !== false).slice(0, 1)); st.strokes = []; }
    return st;
  };
  // pixels per document unit of the frame an object lives in (print documents are laid out at their ppi)
  O.ppiOf = n => {
    let p = n;
    while (p && !model.isPage(p)) { if (p.type === 'frame' && p.print && p.print.ppi) return p.print.ppi; p = model.parent(p); }
    return (S.doc && S.doc.printImages && S.doc.printImages.ppi) || 72;
  };
  // the leaves that carry geometry (groups and frames are opened)
  const leaves = (list, pred) => {
    const out = [];
    const walk = arr => arr.forEach(n => {
      if (n.visible === false || n.locked) return;
      if (n.type === 'group' || (n.type === 'frame' && !n.component)) return walk(n.children);
      if (!pred || pred(n)) out.push(n);
    });
    walk(list);
    return out;
  };
  const newAsset = (data, w, h, name) => { const id = O.uid(); S.doc.assets[id] = { data, w: round(w), h: round(h), name: name || t('Зображення') }; return id; };
  const imageRect = (assetId, bounds, par, name, mode) => {
    const lb = R.transform(bounds, M.inv(model.containerMatrix(par)));
    return model.create('rect', { name: name || t('Зображення'), w: lb.w, h: lb.h, m: M.translate(lb.x, lb.y), fills: [Object.assign(O.paint.image(assetId), { mode: mode || 'stretch' })] });
  };
  // render a region of the page (everything visible there) into an image
  OM.renderRegion = async (b, scale, opts = {}) => {
    const page = model.page();
    const fr = model.create('frame', { name: '·', w: b.w, h: b.h, m: M.translate(b.x, b.y), fills: opts.bg ? [O.paint.solid(opts.bg)] : [], clip: true });
    for (const n of page.children) {
      if (n.visible === false || (opts.skip && opts.skip(n))) continue;
      const wb = model.worldBounds(n);
      if (!wb || !R.intersects(wb, b)) continue;
      const c = model.cloneNode(n, true);
      c.m = M.mul(M.translate(-b.x, -b.y), n.m);
      fr.children.push(c);
    }
    page.children.push(fr);
    model.reindex();
    try { return await O.io.renderImage([fr], { scale, type: opts.type || 'image/png' }); }
    finally { page.children.splice(page.children.indexOf(fr), 1); model.reindex(); }
  };
  const blobData = blob => O.io.blobToData(blob);

  // ======================================================================
  // DISTRIBUTE (by edges and centres, as the Align panel of Illustrator)
  // ======================================================================
  const DIST = { left: ['x', 0], hcenter: ['x', 0.5], right: ['x', 1], top: ['y', 0], vcenter: ['y', 0.5], bottom: ['y', 1] };
  OM.distribute = edge => {
    const ns = O.topSel();
    if (ns.length < 3) return toast('Виділіть щонайменше 3 об’єкти');
    const [ax, k] = DIST[edge], sz = ax === 'x' ? 'w' : 'h';
    const items = ns.map(n => { const b = model.worldBounds(n); return { n, v: b[ax] + b[sz] * k }; }).sort((a, b) => a.v - b.v);
    const a = items[0].v, step = (items[items.length - 1].v - a) / (items.length - 1);
    items.forEach((it, i) => { const d = a + step * i - it.v; if (Math.abs(d) > 1e-6) model.applyWorld(it.n, ax === 'x' ? M.translate(d, 0) : M.translate(0, d), 'resize'); });
    commit('Розподіл об’єктів');
  };

  // ======================================================================
  // GROUPS, LOCK, HIDE
  // ======================================================================
  OM.ungroupAll = () => {
    const picked = O.topSel();
    const roots = picked.length ? picked : model.page().children.slice();
    const groups = [];
    model.walk(roots, n => { if (n.type === 'group' && !n.mask) groups.push(n); });
    if (!groups.length) return toast('Немає груп для розгрупування');
    const out = new Set(roots.map(n => n.id));
    for (const g of groups.reverse()) {
      const par = model.parent(g);
      if (!par) continue;
      let i = par.children.indexOf(g);
      for (const c of g.children.slice()) { model.reparent(c, par, i++); out.add(c.id); }
      out.delete(g.id);
      model.remove(g);
    }
    if (picked.length) O.select(Array.from(out).filter(id => model.exists(id)));
    commit('Розгрупувати все');
  };
  // objects higher in the stacking order that overlap the selection
  const artworkAbove = ns => {
    const flat = [];
    model.walk(model.page().children, n => { flat.push(n); });
    const last = Math.max(...ns.map(n => flat.indexOf(n)));
    const sb = model.selBounds(ns);
    const out = [];
    flat.slice(last + 1).forEach(n => {
      if (ns.some(s => model.isAncestor(n, s) || model.isAncestor(s, n))) return;
      if (out.some(o => model.isAncestor(o, n))) return;
      const b = model.worldBounds(n);
      if (b && sb && R.intersects(b, sb)) out.push(n);
    });
    return out;
  };
  const otherLayers = ns => model.page().children.filter(c => !ns.some(n => n === c || model.isAncestor(c, n)));
  const markAll = (list, key, val, label, empty) => {
    if (!list.length) return toast(empty);
    list.forEach(n => { n[key] = val; });
    commit(label);
    toast('Змінено об’єктів: {n}', { n: list.length });
  };
  OM.lockAbove = () => { const ns = O.topSel(); if (!ns.length) return toast('Спершу виділіть об’єкт'); markAll(artworkAbove(ns), 'locked', true, 'Заблокувати вище', 'Над виділеним немає інших об’єктів'); };
  OM.lockOthers = () => { const ns = O.sel(); if (!ns.length) return toast('Спершу виділіть об’єкт'); markAll(otherLayers(ns), 'locked', true, 'Заблокувати інші шари', 'Інших шарів немає'); };
  OM.hideAbove = () => { const ns = O.topSel(); if (!ns.length) return toast('Спершу виділіть об’єкт'); markAll(artworkAbove(ns), 'visible', false, 'Сховати вище', 'Над виділеним немає інших об’єктів'); };
  OM.hideOthers = () => { const ns = O.sel(); if (!ns.length) return toast('Спершу виділіть об’єкт'); markAll(otherLayers(ns), 'visible', false, 'Сховати інші шари', 'Інших шарів немає'); };

  // ======================================================================
  // EXPAND / EXPAND APPEARANCE
  // ======================================================================
  // the stroke becomes its own filled shape above the fill; both are grouped like in Illustrator
  const strokeToShape = n => {
    if (!GEOM.has(n.type) || !hasStroke(n)) return null;
    const geom = model.subsIn(n, n.m);
    const open = geom.some(sp => !sp.closed);
    const sa = open ? 'center' : (n.sa || 'center');
    let subs = G.outlineStroke(geom, sa === 'center' ? n.sw : n.sw * 2, n.cap, n.join, n.miter);
    if (sa !== 'center') {
      try {
        const band = G.toPaper(subs), area = G.toPaper(geom, n.fillRule);
        subs = G.fromPaper(sa === 'inside' ? band.intersect(area) : band.subtract(area));
      } catch (e) { console.warn(e); }
    }
    const st = n.strokes.filter(s => s.visible !== false);
    const sp = newPath(subs, { fills: O.clone(st.slice(-1)), strokes: [], opacity: 1 }, t('Обведення'));
    return sp;
  };
  const splitStroke = n => {
    const sp = strokeToShape(n);
    if (!sp) return [n];
    const par = model.parent(n), i = par.children.indexOf(n);
    n.strokes = [];
    const g = model.create('group', { name: n.name, opacity: n.opacity, blend: n.blend });
    n.opacity = 1; n.blend = 'normal';
    model.insert(g, par, i + 1);
    model.reparent(n, g);
    model.insert(sp, g);
    if (!hasFill(n)) model.remove(n);
    return [g];
  };
  OM.expandDialog = () => {
    if (!O.topSel().length) return toast('Спершу виділіть об’єкт');
    ui.dialog({
      title: 'Розгорнути',
      body: `<div class="dlg-text small">${esc(t('Перетворює фігури, текст і булеві групи на звичайні контури, а обведення — на окремі зафарбовані фігури.'))}</div>`,
      fields: [{ key: 'obj', label: 'Об’єкт', type: 'checkbox', value: true }, { key: 'fill', label: 'Заливка', type: 'checkbox', value: true }, { key: 'stroke', label: 'Обведення', type: 'checkbox', value: true }],
      onOk: v => OM.expand(v)
    });
  };
  OM.expand = async (v = { obj: true, fill: true, stroke: true }) => {
    let ns = O.topSel();
    if (!ns.length) return;
    if (v.obj) {
      const texts = [];
      model.walk(ns, n => { if (n.type === 'text' && !n.path) texts.push(n); });
      if (texts.length) await ops.createOutlines(texts);
      O.suspendCommit = true;
      try { ops.expand(O.topSel()); } finally { O.suspendCommit = false; }
      ns = O.topSel();
    }
    if (v.stroke) {
      const out = [];
      for (const n of ns) {
        if (n.type === 'group' || n.type === 'frame') { leaves(n.children, x => GEOM.has(x.type)).forEach(splitStroke); out.push(n); }
        else out.push(...splitStroke(n));
      }
      O.select(out.filter(n => model.exists(n.id)).map(n => n.id));
    }
    commit('Розгорнути');
  };
  OM.expandAppearance = async () => {
    const ns = O.topSel();
    if (!ns.length) return toast('Спершу виділіть об’єкт');
    const out = [];
    for (const n of ns) {
      const par = model.parent(n);
      if (n.type === 'bool' || model.SHAPES.has(n.type)) { O.suspendCommit = true; try { ops.expand([n]); } finally { O.suspendCommit = false; } }
      const parts = [];
      // live effects (shadows, glows, blur) are baked into an image under the vectors
      if ((n.effects || []).some(e => e.visible !== false)) {
        const { blob, bounds } = await O.io.renderImage([n], { scale: 2, type: 'image/png' });
        const img = imageRect(newAsset(await blobData(blob), bounds.w * 2, bounds.h * 2, t('Ефекти')), bounds, par, t('Ефекти'));
        model.insert(img, par, par.children.indexOf(n));
        parts.push(img);
        n.effects = [];
      }
      // several fills become stacked copies; the stroke becomes a filled shape
      const fills = (n.fills || []).filter(f => f.visible !== false);
      if (fills.length > 1 && GEOM.has(n.type)) {
        fills.slice(0, -1).forEach((f, k) => { const c = model.cloneNode(n); c.fills = [f]; c.strokes = []; c.effects = []; c.name = n.name + ' · ' + t('Заливка') + ' ' + (k + 1); model.insert(c, par, par.children.indexOf(n)); parts.push(c); });
        n.fills = [fills[fills.length - 1]];
      }
      const res = GEOM.has(n.type) ? splitStroke(n) : [n];
      if (parts.length) {
        const g = model.create('group', { name: n.name });
        model.insert(g, par, par.children.indexOf(res[0]) + 1);
        parts.concat(res).forEach(x => model.reparent(x, g));
        out.push(g);
      } else out.push(...res);
    }
    O.select(out.filter(n => model.exists(n.id)).map(n => n.id));
    commit('Розгорнути вигляд');
  };

  // ======================================================================
  // IMAGES: crop, rasterize, mosaic
  // ======================================================================
  // image pixels per document unit of a photo object
  OM.density = n => {
    const wb = model.worldBounds(n);
    if (!wb || !wb.w) return 1;
    if (n.type === 'raster') { const a = S.doc.assets[n.asset]; return a ? a.w / wb.w : 1; }
    const f = imgFill(n), a = f && S.doc.assets[f.asset];
    if (!a) return 1;
    if (f.mode === 'tile') return 1 / (f.scale || 1);
    if (f.mode === 'stretch') return Math.max(a.w / wb.w, a.h / wb.h);
    const k = f.mode === 'fit' ? Math.min(wb.w / a.w, wb.h / a.h) : Math.max(wb.w / a.w, wb.h / a.h) * ((f.mode === 'crop' && f.crop && f.crop.z) || 1);
    return 1 / (k || 1);
  };
  const photoParts = n => {
    const gf = O.photo && O.photo.frameOf && O.photo.frameOf(n);
    if (gf) return { holder: gf, content: O.photo.contentOf(gf) };
    return isImage(n) ? { holder: n, content: n } : null;
  };
  // only the visible part of a photo stays (Object › Crop Image)
  OM.cropImage = async (nodes, area) => {
    const list = (nodes || O.topSel()).map(photoParts).filter(Boolean);
    if (!list.length) return toast('Виділіть зображення');
    const out = [];
    for (const { holder, content } of list) {
      const dens = clamp(OM.density(content), 0.25, 4);
      const keep = { strokes: holder.strokes, effects: holder.effects, opacity: holder.opacity, radius: holder.radius, fills: holder.fills, blend: holder.blend };
      holder.strokes = []; holder.effects = []; holder.opacity = 1; holder.blend = 'normal';
      if (holder !== content) holder.fills = [];
      let res;
      try {
        if (area) res = await OM.renderRegion(area, dens, { skip: x => x !== model.topLevel(holder) });
        else res = await O.io.renderImage([holder], { scale: dens, type: 'image/png' });
      } finally { Object.assign(holder, keep); }
      const par = model.parent(holder);
      const b = res.bounds;
      const id = newAsset(await blobData(res.blob), b.w * dens, b.h * dens, (holder.name || t('Зображення')) + ' · ' + t('кадр'));
      const r = imageRect(id, b, par, holder.name);
      r.strokes = O.clone(holder.strokes || []); r.sw = holder.sw; r.effects = O.clone(holder.effects || []); r.opacity = holder.opacity;
      model.insert(r, par, par.children.indexOf(holder) + 1);
      model.remove(holder);
      out.push(r.id);
    }
    O.select(out);
    commit('Кадрування зображення');
  };
  OM.rasterizeDialog = () => {
    if (!O.topSel().length) return toast('Спершу виділіть об’єкт');
    ui.dialog({
      title: 'Растеризувати',
      fields: [
        { key: 'res', label: 'Роздільна здатність', type: 'select', value: String(O.ls.get('rasRes', 150)), options: [['72', 'Екран (72 ppi)'], ['150', 'Середня (150 ppi)'], ['300', 'Висока (300 ppi)'], ['600', '600 ppi']] },
        { key: 'bg', label: 'Фон', type: 'select', value: O.ls.get('rasBg', 'none'), options: [['none', 'Прозорий'], ['#FFFFFF', 'Білий']] }
      ],
      buttons: [{ id: 'ok', label: 'Растеризувати', primary: true }],
      onOk: v => { O.ls.set('rasRes', +v.res); O.ls.set('rasBg', v.bg); OM.rasterize(O.topSel(), +v.res, v.bg === 'none' ? null : v.bg); }
    });
  };
  OM.rasterize = async (ns, ppi, bg, label) => {
    ns = ops.zsort(ns);
    if (!ns.length) return null;
    const top = ns[ns.length - 1], par = model.parent(top);
    const scale = clamp(ppi / O.ppiOf(top), 0.1, 8);
    const { blob, bounds } = await O.io.renderImage(ns, { scale, type: 'image/png', bg });
    const id = newAsset(await blobData(blob), bounds.w * scale, bounds.h * scale, t('Растр'));
    const r = imageRect(id, bounds, par, ns.length === 1 ? top.name : t('Растр'));
    model.insert(r, par, par.children.indexOf(top) + 1);
    ns.forEach(n => model.remove(n));
    O.select([r.id]);
    commit(label || 'Растеризація');
    return r;
  };
  OM.mosaicDialog = () => {
    const n = O.topSel().find(isImage);
    if (!n) return toast('Виділіть зображення');
    const b = model.worldBounds(n);
    ui.dialog({
      title: 'Створити фрагментацію об’єкта',
      fields: [
        { key: 'cols', label: 'Фрагментів по горизонталі', type: 'number', value: 24, min: 1, max: 200 },
        { key: 'rows', label: 'Фрагментів по вертикалі', type: 'number', value: Math.max(1, round(24 * b.h / b.w)), min: 1, max: 200 },
        { key: 'gap', label: 'Проміжок', type: 'number', value: 1, unit: 'px', min: 0 },
        { key: 'gray', label: 'Відтінки сірого', type: 'checkbox', value: false },
        { key: 'del', label: 'Видалити растр', type: 'checkbox', value: false }
      ],
      buttons: [{ id: 'ok', label: 'Створити', primary: true }],
      onOk: v => OM.mosaic(n, v)
    });
  };
  OM.mosaic = async (n, v) => {
    const cols = clamp(round(v.cols), 1, 200), rows = clamp(round(v.rows), 1, 200);
    const b = model.worldBounds(n);
    const res = await O.io.renderImage([n], { scale: Math.min(4, Math.max(cols * 4, 64) / b.w), type: 'image/png' });
    const cv = res.canvas, W = cv.width, H = cv.height;
    const d = cv.getContext('2d').getImageData(0, 0, W, H).data;
    const par = model.parent(n);
    const lb = R.transform(res.bounds, M.inv(model.containerMatrix(par)));
    const tw = lb.w / cols, th = lb.h / rows, gap = Math.max(0, v.gap || 0);
    const g = model.create('group', { name: t('Фрагментація') });
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      const x0 = Math.floor(c * W / cols), x1 = Math.max(x0 + 1, Math.floor((c + 1) * W / cols)), y0 = Math.floor(r * H / rows), y1 = Math.max(y0 + 1, Math.floor((r + 1) * H / rows));
      let R0 = 0, G0 = 0, B0 = 0, A0 = 0;
      for (let y = y0; y < y1; y += 2) for (let x = x0; x < x1; x += 2) { const i = (y * W + x) * 4, a = d[i + 3]; R0 += d[i] * a; G0 += d[i + 1] * a; B0 += d[i + 2] * a; A0 += a; }
      if (A0 < 1) continue;
      let col = { r: R0 / A0, g: G0 / A0, b: B0 / A0 };
      if (v.gray) { const l = 0.299 * col.r + 0.587 * col.g + 0.114 * col.b; col = { r: l, g: l, b: l }; }
      g.children.push(model.create('rect', { name: t('Фрагмент') + ' ' + (r * cols + c + 1), w: Math.max(0.5, tw - gap), h: Math.max(0.5, th - gap), m: M.translate(gap / 2 + c * tw, gap / 2 + r * th), fills: [O.paint.solid(O.color.hex(col))] }));
    }
    g.m = M.translate(lb.x, lb.y);
    model.insert(g, par, par.children.indexOf(n) + 1);
    if (v.del) model.remove(n);
    O.select([g.id]);
    commit('Фрагментація об’єкта');
  };

  // ======================================================================
  // GRADIENT MESH (smooth colour from control points, kept editable in its dialog)
  // ======================================================================
  OM.meshDialog = () => {
    const ns = O.topSel().filter(n => GEOM.has(n.type));
    if (!ns.length) return toast('Виділіть фігуру');
    const m0 = ns[0].mesh || {};
    ui.dialog({
      title: 'Створити сітчастий градієнт',
      fields: [
        { key: 'rows', label: 'Рядків', type: 'number', value: m0.rows || 4, min: 1, max: 50 },
        { key: 'cols', label: 'Стовпців', type: 'number', value: m0.cols || 4, min: 1, max: 50 },
        { key: 'look', label: 'Вигляд', type: 'select', value: m0.look || 'center', options: [['flat', 'Плоский'], ['center', 'До центру'], ['edge', 'До краю']] },
        { key: 'hi', label: 'Світлі ділянки', type: 'number', value: m0.hi === undefined ? 100 : m0.hi, unit: '%', min: 0, max: 100 },
        { key: 'hc', type: 'html', html: `<label class="dlg-row"><span>${esc(t('Колір світла'))}</span><input type="color" data-k="hc" value="${esc(m0.hc || '#FFFFFF')}"></label>` }
      ],
      buttons: [{ id: 'ok', label: 'Створити', primary: true }],
      onOk: async v => { for (const n of ns) await OM.mesh(n, v); commit('Сітчастий градієнт'); }
    });
  };
  OM.mesh = async (n, v) => {
    const base = (n.mesh && n.mesh.base) || fillOf(n) || '#3A7BD5';
    const b = model.localBounds(n);
    const k = Math.min(2, 700 / Math.max(b.w, b.h, 1));
    const W = Math.max(8, round(b.w * k)), H = Math.max(8, round(b.h * k));
    const rows = clamp(round(v.rows), 1, 50), cols = clamp(round(v.cols), 1, 50), hi = clamp(v.hi, 0, 100) / 100;
    const c0 = O.color.parse(base), c1 = O.color.parse(v.hc || '#FFFFFF') || { r: 255, g: 255, b: 255 };
    const ctl = [];
    for (let i = 0; i <= rows; i++) { const row = []; for (let j = 0; j <= cols; j++) { const u = j / cols * 2 - 1, w = i / rows * 2 - 1, e = Math.max(Math.abs(u), Math.abs(w)); row.push(v.look === 'flat' ? 0 : v.look === 'edge' ? hi * e * 0.9 : hi * (1 - e)); } ctl.push(row); }
    const sm = x => x * x * (3 - 2 * x);
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const g = cv.getContext('2d'), im = g.createImageData(W, H), d = im.data;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const gx = x / (W - 1) * cols, gy = y / (H - 1) * rows, i0 = Math.min(rows - 1, Math.floor(gy)), j0 = Math.min(cols - 1, Math.floor(gx));
      const fx = sm(gx - j0), fy = sm(gy - i0);
      const a = ctl[i0][j0] + (ctl[i0][j0 + 1] - ctl[i0][j0]) * fx, c = ctl[i0 + 1][j0] + (ctl[i0 + 1][j0 + 1] - ctl[i0 + 1][j0]) * fx, s = a + (c - a) * fy;
      const o = (y * W + x) * 4;
      d[o] = c0.r + (c1.r - c0.r) * s; d[o + 1] = c0.g + (c1.g - c0.g) * s; d[o + 2] = c0.b + (c1.b - c0.b) * s; d[o + 3] = 255;
    }
    g.putImageData(im, 0, 0);
    const id = newAsset(cv.toDataURL('image/png'), W, H, t('Сітчастий градієнт'));
    n.fills = [Object.assign(O.paint.image(id), { mode: 'stretch' })];
    n.mesh = { rows, cols, look: v.look, hi: round(hi * 100), hc: v.hc || '#FFFFFF', base };
  };

  // ======================================================================
  // PRINT HELPERS: trim marks, flatten transparency, pixel perfect
  // ======================================================================
  OM.trimMarks = () => {
    const ns = O.topSel();
    if (!ns.length) return toast('Спершу виділіть об’єкт');
    const b = model.selBounds(ns), off = 9, len = 18;
    const g = model.create('group', { name: t('Мітки обрізки') });
    const L = (x1, y1, x2, y2) => g.children.push(newPath([{ closed: false, pts: [G.pt(x1, y1), G.pt(x2, y2)] }], lineStyle('#000000', 0.3), t('Мітка обрізки')));
    const x0 = b.x, y0 = b.y, x1 = b.x + b.w, y1 = b.y + b.h;
    L(x0 - off - len, y0, x0 - off, y0); L(x0, y0 - off - len, x0, y0 - off);
    L(x1 + off, y0, x1 + off + len, y0); L(x1, y0 - off - len, x1, y0 - off);
    L(x0 - off - len, y1, x0 - off, y1); L(x0, y1 + off, x0, y1 + off + len);
    L(x1 + off, y1, x1 + off + len, y1); L(x1, y1 + off, x1, y1 + off + len);
    model.insert(g, model.page());
    O.select([g.id]);
    commit('Мітки обрізки');
  };
  const isTransparent = n => (n.opacity !== undefined && n.opacity < 1) || (n.blend && n.blend !== 'normal') || (n.effects || []).some(e => e.visible !== false)
    || (n.fills || []).concat(n.strokes || []).some(p => p.visible !== false && ((p.opacity !== undefined && p.opacity < 1) || (p.stops || []).some(s => s.a !== undefined && s.a < 1)));
  OM.flattenDialog = () => ui.dialog({
    title: 'Звести області з прозорістю',
    body: `<div class="dlg-text small">${esc(t('Об’єкти з прозорістю, режимами накладання й ефектами стають зображенням разом із тим, що під ними, — як у друкарні. Решта лишається векторною.'))}</div>`,
    fields: [
      { key: 'res', label: 'Роздільна здатність растру', type: 'select', value: '300', options: [['150', '150 ppi'], ['300', '300 ppi'], ['600', '600 ppi']] },
      { key: 'text', label: 'Перетворити весь текст на криві', type: 'checkbox', value: false }
    ],
    buttons: [{ id: 'ok', label: 'Звести', primary: true }],
    onOk: v => OM.flattenTransparency(v)
  });
  OM.flattenTransparency = async v => {
    const roots = O.topSel().length ? O.topSel() : model.page().children.slice();
    if (v.text) { const texts = []; model.walk(roots, n => { if (n.type === 'text' && !n.path) texts.push(n); }); if (texts.length) await ops.createOutlines(texts); }
    const list = O.topSel().length ? O.topSel() : model.page().children.slice();
    const targets = [];
    model.walk(list, n => { if (n.visible !== false && isTransparent(n)) { targets.push(n); return false; } });
    if (!targets.length) return toast('Немає об’єктів із прозорістю');
    for (const n of targets) {
      const par = model.parent(n), wb = model.worldBounds(n);
      if (!wb || wb.w < 0.5 || wb.h < 0.5) continue;
      const pad = Math.max(0, ...(n.effects || []).map(e => (e.blur || 0) * 2 + Math.abs(e.x || 0) + Math.abs(e.y || 0) + (e.spread || 0)));
      const b = R.expand(wb, pad);
      const scale = clamp(v.res / O.ppiOf(n), 0.1, 8);
      const res = await OM.renderRegion(b, scale);
      const img = imageRect(newAsset(await blobData(res.blob), b.w * scale, b.h * scale, t('Зведено')), b, par, t('Зведено'));
      // the composite shows only where the object painted (its outline plus effects) — the rest stays vector
      const maskSubs = pad > 0 || n.type === 'text' || n.type === 'group' || n.type === 'frame' ? G.transformSubs(G.rectSub(b.w, b.h, 0), M.translate(b.x, b.y)) : areaSubs(n);
      const mask = newPath(toParent(maskSubs, par), { fills: [O.paint.solid('#000000')], strokes: [] }, t('Маска'));
      const g = model.create('group', { name: n.name + ' · ' + t('зведено'), mask: true });
      model.insert(g, par, par.children.indexOf(n) + 1);
      g.children.push(mask, img);
      model.remove(n);
    }
    model.reindex();
    commit('Зведення прозорості');
    toast('Зведено об’єктів з прозорістю: {n}', { n: targets.length });
  };
  OM.pixelPerfect = () => {
    const roots = O.topSel().length ? O.topSel() : model.page().children;
    let k = 0;
    const rp = p => { if (!p) return; p.x = round(p.x); p.y = round(p.y); };
    model.walk(roots, n => {
      const m = n.m;
      if (!m || Math.abs(m[1]) > 1e-6 || Math.abs(m[2]) > 1e-6) return;
      m[4] = round(m[4]); m[5] = round(m[5]);
      if (Math.abs(m[0] - 1) < 1e-6 && Math.abs(m[3] - 1) < 1e-6) {
        if (n.w !== undefined && n.type !== 'text') { n.w = Math.max(1, round(n.w)); n.h = Math.max(1, round(n.h)); }
        if (n.type === 'path') n.subpaths.forEach(sp => sp.pts.forEach(p => { rp(p); rp(p.i); rp(p.o); }));
      }
      if (hasStroke(n)) n.sw = Math.max(1, round(n.sw));
      k++;
    });
    commit('Бездоганне піксельне зображення');
    toast('Вирівняно за піксельною сіткою: {n}', { n: k });
  };

  // ======================================================================
  // GENERATIVE: recolour with a palette (works offline), vectors with Claude
  // ======================================================================
  OM.PALETTES = [
    ['Пастель', ['#FFB5A7', '#FCD5CE', '#F9DCC4', '#FEC89A', '#B5E2FA', '#CDB4DB', '#A2D2FF']],
    ['Неон', ['#0B0B1A', '#FF2079', '#00F0FF', '#B4FF39', '#FFE600', '#9D4EDD', '#FFFFFF']],
    ['Ретро', ['#2B2D42', '#EF8354', '#F4D35E', '#EE964B', '#0D3B66', '#FAF0CA', '#BF4342']],
    ['Океан', ['#03045E', '#023E8A', '#0077B6', '#00B4D8', '#48CAE4', '#90E0EF', '#CAF0F8']],
    ['Захід сонця', ['#3D0C45', '#7B2D5B', '#C44569', '#F8B195', '#F67280', '#FFD3B6', '#FFF1E6']],
    ['Ліс', ['#132A13', '#31572C', '#4F772D', '#90A955', '#ECF39E', '#A47148', '#F1E3C8']],
    ['Земля', ['#3E2723', '#6D4C41', '#A1887F', '#D7CCC8', '#C2A878', '#8D6E63', '#F5EBE0']],
    ['Монохром', ['#111111', '#333333', '#555555', '#888888', '#BBBBBB', '#DDDDDD', '#F5F5F5']],
    ['Бренд VIBSma', ['#1A1033', '#5B3DF5', '#8C6CFF', '#FF6B9A', '#FFC857', '#E9E4FF', '#FFFFFF']],
    ['Скандинавія', ['#2E3440', '#4C566A', '#D8DEE9', '#ECEFF4', '#88C0D0', '#BF616A', '#EBCB8B']]
  ];
  const colorSlots = roots => {
    const slots = [];
    model.walk(roots, n => {
      ['fills', 'strokes'].forEach(k => (n[k] || []).forEach(p => {
        if (p.visible === false) return;
        if (p.type === 'solid') slots.push({ get: () => p.color, set: c => { p.color = c; } });
        else if (p.stops) p.stops.forEach(s => slots.push({ get: () => s.color, set: c => { s.color = c; } }));
      }));
      (n.effects || []).forEach(e => { if (e.color && (e.type === 'glow' || e.type === 'innerglow')) slots.push({ get: () => e.color, set: c => { e.color = c; } }); });
    });
    return slots;
  };
  const lumOf = hex => { const c = O.color.parse(hex) || { r: 0, g: 0, b: 0 }; return 0.299 * c.r + 0.587 * c.g + 0.114 * c.b; };
  OM.recolor = (roots, pal, seed) => {
    const slots = colorSlots(roots);
    const uniq = Array.from(new Set(slots.map(s => O.color.norm(s.get())).filter(Boolean))).sort((a, b) => lumOf(a) - lumOf(b));
    if (!uniq.length) return 0;
    let p = pal.slice().sort((a, b) => lumOf(a) - lumOf(b));
    if (seed) { let s = seed >>> 0; const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; const mid = p.slice(1, -1); for (let i = mid.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [mid[i], mid[j]] = [mid[j], mid[i]]; } p = [p[0]].concat(mid, [p[p.length - 1]]); }
    const map = new Map(uniq.map((c, i) => [c, p[uniq.length === 1 ? Math.floor(p.length / 2) : round(i * (p.length - 1) / (uniq.length - 1))]]));
    slots.forEach(s => { const c = O.color.norm(s.get()); if (map.has(c)) s.set(map.get(c)); });
    return uniq.length;
  };
  OM.recolorDialog = () => {
    const roots = O.topSel();
    if (!roots.length) return toast('Спершу виділіть об’єкт');
    const sw = OM.PALETTES.map(([n, cs], i) => `<button type="button" class="om-pal" data-pal="${i}" title="${esc(t(n))}"><span>${cs.map(c => `<i style="background:${c}"></i>`).join('')}</span><b>${esc(t(n))}</b></button>`).join('');
    ui.dialog({
      title: 'Генеративне перефарбування',
      body: `<div class="dlg-text small">${esc(t('Оберіть палітру: кольори виділеного замінюються від найтемнішого до найсвітлішого, тож контраст зберігається.'))}</div><div class="om-pals">${sw}</div>`,
      fields: [{ key: 'pal', type: 'html', html: '<input type="hidden" data-k="pal" value="0">' }, { key: 'mix', label: 'Варіант (перемішати кольори)', type: 'number', value: 0, min: 0, max: 99 }],
      preview: true,
      apply: v => OM.recolor(roots, OM.PALETTES[+v.pal || 0][1], v.mix ? v.mix * 7919 : 0),
      label: 'Перефарбування',
      onOpen: el => {
        const mark = i => el.querySelectorAll('.om-pal').forEach(b => b.classList.toggle('on', +b.dataset.pal === i));
        mark(0);
        el.addEventListener('click', e => { const b = e.target.closest('[data-pal]'); if (!b) return; e.preventDefault(); el.querySelector('[data-k="pal"]').value = b.dataset.pal; mark(+b.dataset.pal); el.querySelector('[data-k="pal"]').dispatchEvent(new Event('change', { bubbles: true })); });
      }
    });
  };

  // ======================================================================
  // SLICES (web export regions of the page)
  // ======================================================================
  const slicesOf = () => { const pg = model.page(); return pg.slices || (pg.slices = []); };
  OM.sliceMake = union => {
    const ns = O.topSel();
    if (!ns.length) return toast('Спершу виділіть об’єкт');
    const list = slicesOf();
    const add = b => list.push({ id: O.uid(), name: t('Фрагмент') + ' ' + (list.length + 1), x: Math.floor(b.x), y: Math.floor(b.y), w: Math.ceil(b.w), h: Math.ceil(b.h) });
    if (union) add(model.selBounds(ns)); else ns.forEach(n => add(model.worldBounds(n)));
    S.settings.showSlices = true;
    O.requestOverlay();
    commit('Фрагмент');
    toast('Фрагментів на сторінці: {n}', { n: list.length });
  };
  OM.sliceOptions = () => {
    const list = slicesOf();
    if (!list.length) return toast('На сторінці немає фрагментів');
    const rows = list.map((s, i) => `<div class="om-row"><input type="text" data-sn="${i}" value="${esc(s.name)}" aria-label="${esc(t('Назва'))}"><span class="om-dim">${s.w} × ${s.h}</span><label class="chk"><input type="checkbox" data-sd="${i}"><span>${esc(t('Видалити'))}</span></label></div>`).join('');
    ui.dialog({
      title: 'Параметри фрагментів', body: `<div class="om-list">${rows}</div>`,
      onOk: () => {
        const el = O.$('.dlg-back:last-of-type');
        const names = Array.from(el.querySelectorAll('[data-sn]')).map(i => i.value.trim());
        const del = new Set(Array.from(el.querySelectorAll('[data-sd]')).filter(i => i.checked).map(i => +i.dataset.sd));
        const pg = model.page();
        pg.slices = list.map((s, i) => Object.assign(s, { name: names[i] || s.name })).filter((_, i) => !del.has(i));
        O.requestOverlay(); commit('Фрагменти');
      }
    });
  };
  OM.sliceDeleteAll = () => { const pg = model.page(); if (!(pg.slices || []).length) return toast('На сторінці немає фрагментів'); pg.slices = []; O.requestOverlay(); commit('Видалити фрагменти'); };
  OM.sliceExport = () => {
    const list = slicesOf();
    if (!list.length) return toast('На сторінці немає фрагментів');
    ui.dialog({
      title: 'Експорт фрагментів',
      fields: [{ key: 'fmt', label: 'Формат', type: 'select', value: 'png', options: [['png', 'PNG'], ['jpg', 'JPG'], ['webp', 'WEBP']] }, { key: 'scale', label: 'Масштаб', type: 'select', value: '1', options: [['1', '1×'], ['2', '2×'], ['3', '3×']] }],
      buttons: [{ id: 'ok', label: 'Експортувати', primary: true }],
      onOk: async v => {
        const type = v.fmt === 'jpg' ? 'image/jpeg' : v.fmt === 'webp' ? 'image/webp' : 'image/png';
        const files = [];
        for (const s of list) { const r = await OM.renderRegion(s, +v.scale, { type, bg: v.fmt === 'jpg' ? '#FFFFFF' : null }); files.push({ name: s.name.replace(/[\\/:*?"<>|]+/g, '_') + '.' + v.fmt, blob: r.blob }); }
        if (files.length === 1) O.download(files[0].blob, files[0].name);
        else O.download(await O.io.zip(files), (S.doc.name || 'VIBSma') + ' — ' + t('фрагменти') + '.zip');
        toast('Експортовано фрагментів: {n}', { n: files.length });
      }
    });
  };
  if (O.overlayHooks) O.overlayHooks.push(Vm => {
    if (!S.doc || !S.settings.showSlices) return '';
    const list = model.page().slices || [];
    return list.map((s, i) => {
      const a = M.apply(Vm, { x: s.x, y: s.y }), b = M.apply(Vm, { x: s.x + s.w, y: s.y + s.h });
      return `<g pointer-events="none"><rect x="${O.n(a.x)}" y="${O.n(a.y)}" width="${O.n(b.x - a.x)}" height="${O.n(b.y - a.y)}" fill="none" stroke="#E5484D" stroke-width="1" stroke-dasharray="4 3"/><rect x="${O.n(a.x)}" y="${O.n(a.y)}" width="18" height="14" fill="#E5484D"/><text x="${O.n(a.x + 9)}" y="${O.n(a.y + 11)}" font-size="10" font-family="Inter, Arial, sans-serif" fill="#FFFFFF" text-anchor="middle">${i + 1}</text></g>`;
    }).join('');
  });

  // ======================================================================
  // PATH › DIVIDE OBJECTS BELOW
  // ======================================================================
  OM.divideBelow = () => {
    const ns = O.topSel();
    if (ns.length !== 1 || !GEOM.has(ns[0].type)) return toast('Виділіть один контур — він розріже об’єкти під собою');
    const cut = ns[0];
    const flat = []; model.walk(model.page().children, n => { flat.push(n); });
    const below = flat.slice(0, flat.indexOf(cut)).filter(n => !model.isAncestor(n, cut));
    const cb = model.worldBounds(cut);
    const cs = worldSubs(cut), open = cs.some(sp => !sp.closed);
    let pieces = 0;
    for (const n of below) {
      if (!GEOM.has(n.type) || n.visible === false || n.locked || model.ancestors(n).some(a => a.type === 'bool')) continue;
      const b = model.worldBounds(n);
      if (!b || !R.intersects(b, cb)) continue;
      const geom = worldSubs(n), par = model.parent(n), st = ops.styleOf(n);
      let parts = [];
      try {
        if (open) parts = ops.cutWithLine(geom, G.flatten(cs, 1)[0].pts, n.fillRule) || [];
        else {
          const A = G.toPaper(geom, n.fillRule), K = G.toPaper(cs, cut.fillRule);
          for (const it of [A.intersect(K), A.subtract(K)]) if (!G.isEmptyItem(it)) parts.push(...G.splitParts(G.fromPaper(it)));
        }
      } catch (e) { console.warn(e); continue; }
      if (parts.length < 2) continue;
      let i = par.children.indexOf(n);
      parts.forEach(sub => { model.insert(newPath(toParent(sub, par), st, n.name), par, ++i); pieces++; });
      model.remove(n);
    }
    model.remove(cut);
    O.select([]);
    commit('Розділити нижні об’єкти');
    toast(pieces ? 'Утворено частин: {n}' : 'Контур не перетинає об’єкти під ним', { n: pieces });
  };

  // ======================================================================
  // SHAPE: convert a drawn path into a live rectangle / ellipse, or expand
  // ======================================================================
  OM.shapeConvert = () => {
    const ns = O.topSel().filter(n => n.type === 'path');
    if (!ns.length) return toast('Виділіть контур');
    let done = 0;
    for (const n of ns) {
      const flat = G.flatten(n.subpaths, 2);
      if (flat.length !== 1 || !flat[0].closed) continue;
      const pts = flat[0].pts, b = R.fromPts(pts);
      if (!b || b.w < 1 || b.h < 1) continue;
      const tol = Math.max(b.w, b.h) * 0.04;
      const onRect = pts.every(p => Math.min(Math.abs(p.x - b.x), Math.abs(p.x - b.x - b.w), Math.abs(p.y - b.y), Math.abs(p.y - b.y - b.h)) < tol);
      const cx = b.x + b.w / 2, cy = b.y + b.h / 2;
      const onEll = pts.every(p => Math.abs(Math.hypot((p.x - cx) / (b.w / 2), (p.y - cy) / (b.h / 2)) - 1) < 0.06);
      const type = onEll && !onRect ? 'ellipse' : onRect ? 'rect' : (onEll ? 'ellipse' : null);
      if (!type) continue;
      const s = model.create(type, Object.assign(ops.styleOf(n), { name: n.name, w: b.w, h: b.h, m: M.mul(n.m, M.translate(b.x, b.y)) }));
      const par = model.parent(n);
      model.insert(s, par, par.children.indexOf(n) + 1);
      model.remove(n);
      done++;
    }
    if (!done) return toast('Контур не схожий на прямокутник чи еліпс');
    commit('Перетворити на фігуру');
  };
  OM.shapeExpand = () => {
    const ns = O.topSel().filter(n => model.SHAPES.has(n.type));
    if (!ns.length) return toast('Виділіть фігуру');
    ns.forEach(n => model.toPath(n));
    commit('Розгорнути фігуру');
  };

  // ======================================================================
  // PATTERN: make a swatch from the selection, fill shapes with it
  // ======================================================================
  OM.patternMake = async () => {
    const ns = O.topSel();
    if (!ns.length) return toast('Спершу виділіть об’єкт');
    const { blob, bounds } = await O.io.renderImage(ns, { scale: 2, type: 'image/png' });
    const asset = newAsset(await blobData(blob), bounds.w * 2, bounds.h * 2, t('Візерунок'));
    const list = S.doc.patterns || (S.doc.patterns = []);
    list.push({ id: O.uid(), name: t('Візерунок') + ' ' + (list.length + 1), asset, w: bounds.w, h: bounds.h });
    commit('Візерунок');
    toast('Візерунок «{name}» збережено. Застосуйте його: Об’єкт → Візерунок → Застосувати', { name: list[list.length - 1].name });
  };
  OM.patternApply = () => {
    const list = S.doc.patterns || [];
    if (!list.length) return toast('Спершу створіть візерунок: виділіть малюнок → Об’єкт → Візерунок → Створити');
    const ns = O.topSel().filter(n => GEOM.has(n.type) || n.type === 'frame' || n.type === 'text');
    if (!ns.length) return toast('Виділіть фігуру, яку треба заповнити');
    ui.dialog({
      title: 'Застосувати візерунок',
      fields: [{ key: 'p', label: 'Візерунок', type: 'select', value: String(list.length - 1), options: list.map((p, i) => [String(i), p.name]) }, { key: 's', label: 'Масштаб', type: 'number', value: 100, unit: '%', min: 1 }],
      preview: true, label: 'Візерунок',
      apply: v => { const p = list[+v.p] || list[0], a = S.doc.assets[p.asset]; if (!a) return; const sc = p.w / a.w * Math.max(0.01, v.s / 100); ns.forEach(n => { n.fills = [Object.assign(O.paint.image(p.asset), { mode: 'tile', scale: sc })]; }); }
    });
  };

  // ======================================================================
  // INTERTWINE: every other overlap of two objects comes to the front
  // ======================================================================
  OM.intertwine = (parity = 0) => {
    let ns = ops.zsort(O.topSel());
    const old = ns.length === 1 && ns[0].intertwine ? ns[0] : null;
    if (old) { parity = ((old.intertwine.parity || 0) + 1) % 2; ns = OM.intertwineRelease(old, true); }
    ns = ns.filter(n => GEOM.has(n.type));
    if (ns.length !== 2) return toast('Виділіть 2 об’єкти, що перетинаються');
    const [lo, hi] = ns, par = model.parent(hi);
    let parts = [];
    try { const it = G.toPaper(areaSubs(lo), lo.fillRule).intersect(G.toPaper(areaSubs(hi), hi.fillRule)); if (!G.isEmptyItem(it)) parts = G.splitParts(G.fromPaper(it)); } catch (e) { console.warn(e); }
    if (!parts.length) return toast('Об’єкти не перетинаються');
    const g = model.create('group', { name: t('Переплетення'), intertwine: { parity } });
    model.insert(g, par, par.children.indexOf(hi) + 1);
    model.reparent(lo, g); model.reparent(hi, g);
    const st = paintStyle(lo);
    parts.forEach((sub, i) => { if (i % 2 !== parity) return; const pc = newPath(toParent(sub, g), st, t('Переплетення')); pc.twPiece = true; g.children.push(pc); });
    model.reindex();
    O.select([g.id]);
    commit('Переплетення');
  };
  OM.intertwineRelease = (g, quiet) => {
    g = g || O.topSel().find(n => n.intertwine);
    if (!g) { toast('Виділіть переплетення'); return []; }
    const par = model.parent(g);
    let i = par.children.indexOf(g);
    const out = [];
    for (const c of g.children.slice()) { if (c.twPiece) continue; model.reparent(c, par, i++); out.push(c); }
    model.remove(g);
    if (!quiet) { O.select(out.map(n => n.id)); commit('Звільнити переплетення'); }
    return out;
  };

  // ======================================================================
  // REPEAT: radial, grid, mirror (copies kept in one group, released at will)
  // ======================================================================
  const REP_DEF = { radial: { count: 8, radius: 0 }, grid: { rows: 3, cols: 3, gx: 20, gy: 20 }, mirror: { gap: 20 } };
  const REP_NAME = { radial: 'Повторення: радіальне', grid: 'Повторення: сітка', mirror: 'Повторення: дзеркало' };
  OM.repeat = (kind, p) => {
    let ns = ops.zsort(O.topSel());
    if (ns.length === 1 && ns[0].repeat) ns = OM.repeatRelease(ns[0], true);
    if (!ns.length) return toast('Спершу виділіть об’єкт');
    p = Object.assign({}, REP_DEF[kind], p || {});
    const b = model.selBounds(ns), c = R.center(b);
    const top = ns[ns.length - 1], par = model.parent(top);
    const g = model.create('group', { name: t(REP_NAME[kind]), repeat: { kind, p } });
    model.insert(g, par, par.children.indexOf(top) + 1);
    ns.forEach(n => model.reparent(n, g));
    const copy = mtx => { const d = ops.duplicate(ns); d.forEach(n => { n.repeatCopy = true; model.applyWorld(n, mtx, 'resize'); }); };
    if (kind === 'radial') {
      const N = clamp(round(p.count), 2, 200), rad = p.radius > 0 ? p.radius : Math.max(b.w, b.h) * 1.1;
      const cc = { x: c.x, y: c.y + rad };
      for (let i = 1; i < N; i++) copy(M.about(M.rotate(i * 2 * Math.PI / N), cc));
      p.radius = round(rad);
    } else if (kind === 'grid') {
      for (let r = 0; r < clamp(round(p.rows), 1, 100); r++) for (let k = 0; k < clamp(round(p.cols), 1, 100); k++) if (r || k) copy(M.translate(k * (b.w + p.gx), r * (b.h + p.gy)));
    } else {
      const ax = b.x + b.w + p.gap / 2;
      copy(M.about(M.scale(-1, 1), { x: ax, y: 0 }));
    }
    g.repeat.p = p;
    model.reindex();
    O.select([g.id]);
    commit(REP_NAME[kind]);
    return g;
  };
  OM.repeatRelease = (g, quiet) => {
    g = g || O.topSel().find(n => n.repeat);
    if (!g) { toast('Виділіть повторення'); return []; }
    const par = model.parent(g);
    let i = par.children.indexOf(g);
    const out = [];
    for (const c of g.children.slice()) { if (c.repeatCopy) continue; model.reparent(c, par, i++); out.push(c); }
    model.remove(g);
    if (!quiet) { O.select(out.map(n => n.id)); commit('Звільнити повторення'); }
    return out;
  };
  OM.repeatOptions = () => {
    const g = O.topSel().find(n => n.repeat);
    const kind = g ? g.repeat.kind : 'radial';
    const p = Object.assign({}, REP_DEF[kind], g ? g.repeat.p : {});
    const F = {
      radial: [{ key: 'count', label: 'Кількість копій', type: 'number', value: p.count, min: 2, max: 200 }, { key: 'radius', label: 'Радіус', type: 'number', value: p.radius, unit: 'px', min: 0 }],
      grid: [{ key: 'rows', label: 'Рядків', type: 'number', value: p.rows, min: 1 }, { key: 'cols', label: 'Стовпців', type: 'number', value: p.cols, min: 1 }, { key: 'gx', label: 'Проміжок по горизонталі', type: 'number', value: p.gx, unit: 'px' }, { key: 'gy', label: 'Проміжок по вертикалі', type: 'number', value: p.gy, unit: 'px' }],
      mirror: [{ key: 'gap', label: 'Відстань до осі', type: 'number', value: p.gap, unit: 'px' }]
    }[kind];
    if (!g && !O.topSel().length) return toast('Спершу виділіть об’єкт');
    ui.dialog({ title: 'Параметри повторення', fields: F, preview: true, label: 'Параметри повторення', apply: v => OM.repeat(kind, v) });
  };

  // ======================================================================
  // OBJECTS ON PATH: copies of the objects spread evenly along a path
  // ======================================================================
  const pointAt = (pts, closed, L) => {
    const seq = closed ? pts.concat([pts[0]]) : pts;
    let acc = 0;
    for (let i = 1; i < seq.length; i++) {
      const d = P.dist(seq[i - 1], seq[i]);
      if (acc + d >= L || i === seq.length - 1) { const k = d ? clamp((L - acc) / d, 0, 1) : 0; return { p: P.lerp(seq[i - 1], seq[i], k), a: Math.atan2(seq[i].y - seq[i - 1].y, seq[i].x - seq[i - 1].x) }; }
      acc += d;
    }
    return { p: seq[0], a: 0 };
  };
  OM.onPathDialog = () => {
    const ns = O.topSel();
    if (ns.length < 2) return toast('Виділіть контур і об’єкти, які треба розмістити на ньому');
    ui.dialog({
      title: 'Об’єкти за контуром',
      fields: [{ key: 'rot', label: 'Повертати за напрямком контуру', type: 'checkbox', value: true }, { key: 'copies', label: 'Кількість копій (0 — як виділено)', type: 'number', value: 0, min: 0, max: 500 }],
      preview: true, label: 'Об’єкти за контуром',
      apply: v => OM.onPath(ns, v)
    });
  };
  OM.onPath = (ns, v) => {
    const cand = ns.filter(n => GEOM.has(n.type) && n.type !== 'bool');
    const len = n => G.flatten(worldSubs(n), 2).reduce((s, f) => s + G.polyLength(f.pts, f.closed), 0);
    const track = cand.sort((a, b) => len(b) - len(a))[0];
    let objs = ns.filter(n => n !== track);
    if (!track || !objs.length) return;
    const f = G.flatten(worldSubs(track), 1)[0];
    const L = G.polyLength(f.pts, f.closed);
    if (v.copies > 0) {
      const src = objs.slice(), out = [];
      for (let i = 0; i < round(v.copies); i++) out.push(i < src.length ? src[i] : ops.duplicate([src[i % src.length]])[0]);
      objs = out;
    }
    const K = objs.length;
    objs.forEach((n, i) => {
      const at = f.closed ? i * L / K : K === 1 ? L / 2 : i * L / (K - 1);
      const { p, a } = pointAt(f.pts, f.closed, at);
      const c = R.center(model.worldBounds(n));
      let m = M.translate(p.x - c.x, p.y - c.y);
      if (v.rot) m = M.mul(M.about(M.rotate(a), p), m);
      model.applyWorld(n, m, 'resize');
    });
  };

  // ======================================================================
  // ENVELOPE DISTORT (warp styles of Illustrator) and PERSPECTIVE
  // ======================================================================
  const WARPS = [['arc', 'Дуга'], ['arcLower', 'Дуга знизу'], ['arcUpper', 'Дуга згори'], ['arch', 'Арка'], ['bulge', 'Опуклість'], ['shellLower', 'Мушля знизу'], ['shellUpper', 'Мушля згори'], ['flag', 'Прапор'], ['wave', 'Хвиля'], ['fish', 'Риба'], ['rise', 'Підйом'], ['fisheye', 'Риб’яче око'], ['inflate', 'Надування'], ['squeeze', 'Стискання'], ['twist', 'Скручування']];
  // (u, v) ∈ [-1, 1]² → displaced (u, v)
  const warpFn = (style, bend, hd, vd) => (u, v) => {
    let x = u, y = v;
    const b = bend;
    switch (style) {
      case 'arc': y = v - b * (1 - u * u) * 0.9; break;
      case 'arcLower': y = v - b * (1 - u * u) * 0.9 * (v + 1) / 2; break;
      case 'arcUpper': y = v - b * (1 - u * u) * 0.9 * (1 - v) / 2; break;
      case 'arch': y = v - b * Math.cos(u * Math.PI / 2) * 0.9; break;
      case 'bulge': y = v * (1 + b * (1 - u * u) * 0.8); break;
      case 'shellLower': y = v + (v > 0 ? b * (1 - u * u) * 0.8 * v : 0); break;
      case 'shellUpper': y = v + (v < 0 ? b * (1 - u * u) * 0.8 * v : 0); break;
      case 'flag': y = v + b * Math.sin(u * Math.PI) * 0.45; break;
      case 'wave': y = v + b * Math.sin(u * Math.PI) * 0.45 * (1 - v * 0.5); x = u + b * Math.sin(v * Math.PI) * 0.12; break;
      case 'fish': y = v * (1 + b * 0.6 * Math.cos(u * Math.PI / 2) - b * 0.5 * Math.max(0, u)); break;
      case 'rise': y = v - b * (u + 1) * 0.45; break;
      case 'fisheye': { const r = Math.min(1, Math.hypot(u, v)); const k = 1 + b * (1 - r * r) * 0.6; x = u * k; y = v * k; break; }
      case 'inflate': x = u * (1 + b * 0.5 * (1 - v * v)); y = v * (1 + b * 0.5 * (1 - u * u)); break;
      case 'squeeze': x = u * (1 - b * 0.5 * (1 - v * v)); y = v * (1 + b * 0.3 * (1 - u * u)); break;
      case 'twist': { const r = Math.min(1.5, Math.hypot(u, v)), a = b * Math.PI / 2 * Math.max(0, 1 - r / 1.5); x = u * Math.cos(a) - v * Math.sin(a); y = u * Math.sin(a) + v * Math.cos(a); break; }
    }
    // horizontal / vertical distortion: perspective-like taper
    if (hd) y *= 1 + hd * x * 0.5;
    if (vd) x *= 1 + vd * y * 0.5;
    return [x, y];
  };
  // apply a point map (world space) to every anchor and handle of the selection's paths
  const distortNodes = async (ns, fn, label) => {
    const texts = [];
    model.walk(ns, n => { if (n.type === 'text' && !n.path) texts.push(n); });
    if (texts.length) { await ops.createOutlines(texts); ns = O.topSel(); }
    const b = model.selBounds(ns);
    if (!b || b.w < 1 || b.h < 1) return;
    const targets = [];
    const walk = arr => arr.forEach(n => {
      if (n.type === 'group' || n.type === 'frame') return walk(n.children);
      if (GEOM.has(n.type) || n.type === 'path') targets.push(n);
    });
    walk(ns);
    for (const n of targets) {
      if (!n.envSrc) { const src = O.clone(n); delete src.envSrc; n.envSrc = src; }
      if (n.type !== 'path') { if (n.type === 'bool') ops.expand([n]); else model.toPath(n); }
      // finer anchors bend smoothly
      n.subpaths.forEach(sp => { for (let pass = 0; pass < 2; pass++) { const cnt = sp.closed ? sp.pts.length : sp.pts.length - 1; if (sp.pts.length > 400) break; for (let k = cnt - 1; k >= 0; k--) G.insertAt(sp, k, 0.5); } });
      const W = model.worldMatrix(n), Wi = M.inv(W);
      const map = q => { if (!q) return q; const w = M.apply(W, q); const u = (w.x - b.x) / b.w * 2 - 1, v = (w.y - b.y) / b.h * 2 - 1; const [x, y] = fn(u, v); return M.apply(Wi, { x: b.x + (x + 1) / 2 * b.w, y: b.y + (y + 1) / 2 * b.h }); };
      n.subpaths.forEach(sp => sp.pts.forEach(p => { const q = map(p); const i = p.i && map(p.i), o = p.o && map(p.o); p.x = q.x; p.y = q.y; if (i) p.i = i; if (o) p.o = o; }));
    }
    model.reindex();
    commit(label);
  };
  OM.envWarpDialog = () => {
    const ns = O.topSel();
    if (!ns.length) return toast('Спершу виділіть об’єкт');
    ui.dialog({
      title: 'Параметри деформації',
      fields: [
        { key: 'style', label: 'Стиль деформації', type: 'select', value: O.ls.get('warpStyle', 'arc'), options: WARPS },
        { key: 'dir', label: 'Орієнтація', type: 'select', value: 'h', options: [['h', 'Горизонтальна'], ['v', 'Вертикальна']] },
        { key: 'bend', label: 'Вигин', type: 'number', value: 50, unit: '%', min: -100, max: 100 },
        { key: 'hd', label: 'Спотворення по горизонталі', type: 'number', value: 0, unit: '%', min: -100, max: 100 },
        { key: 'vd', label: 'Спотворення по вертикалі', type: 'number', value: 0, unit: '%', min: -100, max: 100 }
      ],
      preview: true, label: 'Деформація за конвертом',
      apply: v => {
        O.ls.set('warpStyle', v.style);
        const f = warpFn(v.style, clamp(v.bend, -100, 100) / 100, clamp(v.hd, -100, 100) / 100, clamp(v.vd, -100, 100) / 100);
        const fn = v.dir === 'v' ? (u, w) => { const [y, x] = f(w, u); return [x, y]; } : f;
        return distortNodes(O.topSel(), fn, 'Деформація за конвертом');
      }
    });
  };
  OM.envRelease = () => {
    const found = [];
    model.walk(O.topSel(), n => { if (n.envSrc) found.push(n); });
    if (!found.length) return toast('У виділеному немає деформованих об’єктів');
    found.forEach(n => { const src = n.envSrc, id = n.id, m = n.m; Object.keys(n).forEach(k => delete n[k]); Object.assign(n, src, { id, m: src.m || m }); });
    model.reindex();
    commit('Звільнити деформацію');
  };
  OM.envExpand = () => { let k = 0; model.walk(O.topSel(), n => { if (n.envSrc) { delete n.envSrc; k++; } }); if (!k) return toast('У виділеному немає деформованих об’єктів'); commit('Розгорнути деформацію'); };
  OM.perspectiveDialog = () => {
    if (!O.topSel().length) return toast('Спершу виділіть об’єкт');
    ui.dialog({
      title: 'Спотворити в перспективі',
      fields: [
        { key: 'h', label: 'Нахил ліворуч / праворуч', type: 'number', value: 30, unit: '%', min: -90, max: 90 },
        { key: 'v', label: 'Нахил угору / вниз', type: 'number', value: 0, unit: '%', min: -90, max: 90 }
      ],
      preview: true, label: 'Перспектива',
      // the far side shrinks towards the vanishing point (bilinear map of the four corners)
      apply: v => {
        const h = clamp(v.h, -90, 90) / 100, w = clamp(v.v, -90, 90) / 100;
        const c = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([x, y]) => [x * (1 - Math.max(0, w * y)), y * (1 - Math.max(0, h * x))]);
        const fn = (u, y) => { const s = (u + 1) / 2, q = (y + 1) / 2; const top = [c[0][0] + (c[1][0] - c[0][0]) * s, c[0][1] + (c[1][1] - c[0][1]) * s], bot = [c[3][0] + (c[2][0] - c[3][0]) * s, c[3][1] + (c[2][1] - c[3][1]) * s]; return [top[0] + (bot[0] - top[0]) * q, top[1] + (bot[1] - top[1]) * q]; };
        return distortNodes(O.topSel(), fn, 'Перспектива');
      }
    });
  };
  if (O.overlayHooks) O.overlayHooks.push(Vm => {
    if (!S.doc || !S.settings.perspGrid) return '';
    // two-point perspective grid over the visible canvas
    const el = O.view && O.view.el, W = el ? el.clientWidth : 1200, H = el ? el.clientHeight : 800;
    const hy = H * 0.42, vl = { x: -W * 0.15, y: hy }, vr = { x: W * 1.15, y: hy };
    let d = `M0 ${O.n(hy)}H${W}`;
    for (let i = -8; i <= 8; i++) { const y = hy + i * H * 0.12; d += `M${O.n(vl.x)} ${O.n(vl.y)}L${W} ${O.n(y + (y - hy) * 0.6)}M${O.n(vr.x)} ${O.n(vr.y)}L0 ${O.n(y + (y - hy) * 0.6)}`; }
    return `<path d="${d}" stroke="#E5484D" stroke-opacity="0.35" stroke-width="1" fill="none" pointer-events="none"/><circle cx="${O.n(W / 2)}" cy="${O.n(hy)}" r="3" fill="#E5484D" pointer-events="none"/>`;
  });

  // ======================================================================
  // LIVE PAINT: overlapping shapes and lines become separate paintable faces
  // ======================================================================
  OM.livePaint = () => {
    const ns = ops.zsort(O.topSel()).filter(n => GEOM.has(n.type));
    if (ns.length < 2) return toast('Виділіть щонайменше 2 фігури або лінії');
    const areas = ns.filter(n => !n.subpaths || n.subpaths.some(sp => sp.closed) || n.type !== 'path');
    const lines = ns.filter(n => !areas.includes(n));
    const top = ns[ns.length - 1], par = model.parent(top);
    let faces = [];
    try {
      if (areas.length) {
        // pathfinder divide of the closed shapes
        let regions = [];
        for (const n of areas) {
          const it = G.toPaper(worldSubs(n), n.fillRule), st = ops.styleOf(n);
          const next = []; let rest = it;
          for (const r of regions) { const a = r.it.intersect(it), b = r.it.subtract(it); if (!G.isEmptyItem(a)) next.push({ it: a, st }); if (!G.isEmptyItem(b)) next.push({ it: b, st: r.st }); rest = rest.subtract(r.it); }
          if (!G.isEmptyItem(rest)) next.push({ it: rest, st });
          regions = next;
        }
        regions.forEach(r => G.splitParts(G.fromPaper(r.it)).forEach(sub => faces.push({ sub, st: r.st })));
      } else {
        // only lines: the faces they enclose inside their common bounds
        const b = R.expand(model.selBounds(lines), 2);
        faces = [{ sub: G.transformSubs(G.rectSub(b.w, b.h, 0), M.translate(b.x, b.y)), st: { fills: [], strokes: [] }, outer: b }];
      }
      // lines cut the faces
      for (const ln of lines) {
        const pts = G.flatten(worldSubs(ln), 1)[0].pts;
        const next = [];
        for (const f of faces) { const cut = ops.cutWithLine(f.sub, pts, 'nonzero'); if (cut && cut.length > 1) cut.forEach(sub => next.push({ sub, st: f.st, outer: f.outer })); else next.push(f); }
        faces = next;
      }
      if (!areas.length) {
        const ob = faces[0] && faces[0].outer;
        faces = faces.filter(f => { const fb = G.pathBounds(f.sub); return ob && fb && fb.x > ob.x + 1 && fb.y > ob.y + 1 && fb.x + fb.w < ob.x + ob.w - 1 && fb.y + fb.h < ob.y + ob.h - 1; });
      }
    } catch (e) { console.error(e); return toast('Не вдалося створити швидку заливку'); }
    const g = model.create('group', { name: t('Швидка заливка'), livePaint: true });
    model.insert(g, par, par.children.indexOf(top) + 1);
    faces.forEach((f, i) => { const st = Object.assign(O.clone(f.st), { strokes: [] }); if (!st.fills || !st.fills.length) st.fills = [O.paint.solid('#FFFFFF', 0)]; g.children.push(newPath(toParent(f.sub, g), st, t('Грань') + ' ' + (i + 1))); });
    // edges stay on top as strokes
    ns.forEach(n => { if (hasStroke(n)) { const e = newPath(toParent(worldSubs(n), g), { fills: [], strokes: O.clone(n.strokes), sw: n.sw, cap: n.cap, join: n.join }, t('Край')); g.children.push(e); } });
    ns.forEach(n => model.remove(n));
    model.reindex();
    O.select([g.id]);
    commit('Швидка заливка');
    toast('Граней: {n}. Подвійний клік — увійти в групу й зафарбувати будь-яку грань', { n: faces.length });
  };
  OM.livePaintRelease = expand => {
    const gs = O.topSel().filter(n => n.livePaint);
    if (!gs.length) return toast('Виділіть групу швидкої заливки');
    gs.forEach(g => { delete g.livePaint; if (!expand) model.walk(g.children, n => { n.fills = []; n.strokes = [O.paint.solid('#000000')]; n.sw = 0.5; }); });
    commit(expand ? 'Розгорнути швидку заливку' : 'Звільнити швидку заливку');
  };

  // ======================================================================
  // MOCKUP: the selection printed on a product
  // ======================================================================
  const MOCKUPS = [
    ['tshirt', 'Футболка', 620, 660, [190, 170, 240, 270], 'multiply'],
    ['poster', 'Постер на стіні', 820, 620, [246, 92, 328, 436], 'normal'],
    ['phone', 'Телефон', 420, 820, [26, 26, 368, 768], 'normal'],
    ['mug', 'Чашка', 620, 520, [150, 150, 230, 230], 'multiply'],
    ['card', 'Візитка', 900, 560, [208, 148, 484, 264], 'normal'],
    ['tote', 'Сумка-шопер', 560, 680, [130, 260, 300, 300], 'multiply']
  ];
  const mockScene = (kind, color) => {
    const S2 = [];
    const R2 = (x, y, w, h, fill, extra) => S2.push(model.create('rect', Object.assign({ name: t('Фон'), w, h, m: M.translate(x, y), fills: [O.paint.solid(fill)] }, extra || {})));
    const D = (d, fill, name, extra) => S2.push(newPath(G.parseD(d), Object.assign({ fills: [O.paint.solid(fill)], strokes: [] }, extra || {}), name));
    const shadow = [{ type: 'shadow', x: 0, y: 14, blur: 30, spread: 0, color: '#000000', opacity: 0.25, visible: true }];
    if (kind === 'tshirt') { R2(0, 0, 620, 660, '#ECEAE6'); D('M200 40 L250 70 Q310 100 370 70 L420 40 L560 110 L520 230 L470 210 L470 620 L150 620 L150 210 L100 230 L60 110 Z', color, t('Футболка'), { effects: shadow }); D('M250 70 Q310 112 370 70 Q310 92 250 70 Z', '#000000', t('Комір'), { opacity: 0.15 }); }
    if (kind === 'poster') { R2(0, 0, 820, 620, '#E9E2D8'); R2(0, 540, 820, 80, '#CDBFAE'); R2(230, 76, 360, 468, '#FFFFFF', { effects: shadow }); }
    if (kind === 'phone') { R2(0, 0, 420, 820, '#1C1C22', { radius: 56, effects: shadow }); R2(26, 26, 368, 768, '#000000', { radius: 40 }); R2(170, 40, 80, 20, '#1C1C22', { radius: 10 }); }
    if (kind === 'mug') { R2(0, 0, 620, 520, '#F1ECE4'); D('M440 180 C560 180 560 340 440 340 L440 310 C520 310 520 210 440 210 Z', color, t('Ручка')); R2(110, 110, 340, 340, color, { radius: 24, effects: shadow }); R2(110, 110, 340, 30, '#000000', { radius: 14, opacity: 0.08 }); }
    if (kind === 'card') { R2(0, 0, 900, 560, '#D9D3CC'); R2(230, 190, 484, 264, '#FFFFFF', { effects: shadow, opacity: 0.9 }); R2(208, 148, 484, 264, color, { effects: shadow }); }
    if (kind === 'tote') { R2(0, 0, 560, 680, '#EFEAE3'); D('M180 220 C180 60 380 60 380 220 L360 220 C360 90 200 90 200 220 Z', '#C9B79C', t('Ручки')); R2(100, 210, 360, 420, color, { effects: shadow }); }
    return S2;
  };
  OM.mockupDialog = () => {
    if (!O.topSel().length) return toast('Виділіть малюнок, який треба показати на продукті');
    ui.dialog({
      title: 'Створити макет',
      fields: [
        { key: 'kind', label: 'Продукт', type: 'select', value: O.ls.get('mockKind', 'tshirt'), options: MOCKUPS.map(m => [m[0], m[1]]) },
        { key: 'color', type: 'html', html: `<label class="dlg-row"><span>${esc(t('Колір продукту'))}</span><input type="color" data-k="color" value="${esc(O.ls.get('mockColor', '#FFFFFF'))}"></label>` }
      ],
      buttons: [{ id: 'ok', label: 'Створити', primary: true }],
      onOk: v => { O.ls.set('mockKind', v.kind); O.ls.set('mockColor', v.color); OM.mockup(v.kind, v.color); }
    });
  };
  OM.mockup = async (kind, color) => {
    const ns = O.topSel();
    if (!ns.length) return;
    const mk = MOCKUPS.find(m => m[0] === kind) || MOCKUPS[0];
    const b = model.selBounds(ns);
    const { blob, bounds } = await O.io.renderImage(ns, { scale: 2, type: 'image/png' });
    const id = newAsset(await blobData(blob), bounds.w * 2, bounds.h * 2, t('Макет'));
    const g = model.create('group', { name: t('Макет') + ': ' + t(mk[1]), mockup: kind, m: M.translate(round(b.x + b.w + 120), round(b.y)) });
    mockScene(kind, color || '#FFFFFF').forEach(n => g.children.push(n));
    const [ax, ay, aw, ah] = mk[4];
    g.children.push(model.create('rect', { name: t('Друк'), w: aw, h: ah, m: M.translate(ax, ay), fills: [Object.assign(O.paint.image(id), { mode: 'fit' })], blend: mk[5], opacity: mk[5] === 'multiply' ? 0.94 : 1 }));
    model.insert(g, model.page());
    O.select([g.id]);
    commit('Макет');
    setTimeout(() => O.view && O.view.fit(model.selBounds([g]), 80, 1), 0);
  };

  // ======================================================================
  // TEXT WRAP: the text flows around objects through threaded frames
  // ======================================================================
  OM.wrapMake = (offset) => {
    const ns = O.topSel();
    const T = ns.find(n => n.type === 'text' && !n.path);
    const obs = ns.filter(n => n !== T);
    if (!T || !obs.length) return toast('Виділіть текстовий фрейм і об’єкт, який він має обтікати');
    if (T.wrap) OM.wrapRelease(T, true);
    if (T.next) return toast('Текстовий фрейм уже зв’язаний з іншими — спершу розірвіть зв’язок');
    if (Math.abs(T.m[1]) > 1e-6 || Math.abs(T.m[2]) > 1e-6) return toast('Обтікання працює з неповернутим текстовим фреймом');
    offset = offset === undefined ? O.ls.get('wrapOff', 12) : offset;
    const L = O.text.layout(T);
    const W = T.width || L.w, H = T.boxH || Math.max(L.h, O.text.lineHeight(T) * 3);
    const src = { width: T.width || null, boxH: T.boxH || null, m: T.m.slice() };
    const Wi = M.inv(model.worldMatrix(T));
    let E = null;
    obs.forEach(o => { E = R.union(E, R.transform(R.expand(model.worldBounds(o), offset), Wi)); });
    const ex = { x0: clamp(E.x, 0, W), y0: clamp(E.y, 0, H), x1: clamp(E.x + E.w, 0, W), y1: clamp(E.y + E.h, 0, H) };
    if (ex.x1 - ex.x0 < 1 || ex.y1 - ex.y0 < 1) return toast('Об’єкт не перекриває текстовий фрейм');
    const lh = O.text.lineHeight(T), minW = T.size * 3;
    const parts = [];
    if (ex.y0 >= lh) parts.push([0, 0, W, ex.y0]);
    if (ex.x0 >= minW) parts.push([0, ex.y0, ex.x0, ex.y1 - ex.y0]);
    if (W - ex.x1 >= minW) parts.push([ex.x1, ex.y0, W - ex.x1, ex.y1 - ex.y0]);
    if (H - ex.y1 >= lh) parts.push([0, ex.y1, W, H - ex.y1]);
    if (!parts.length) return toast('Для тексту не лишилося місця: зменште відступ або об’єкт');
    const par = model.parent(T);
    const made = [];
    parts.forEach(([x, y, w, h], i) => {
      if (i === 0) { T.m = M.mul(src.m, M.translate(x, y)); T.width = w; T.boxH = h; return; }
      const c = model.cloneNode(T);
      ['runs', 'pars', 'fnotes', 'enotes', 'notes', 'wrap', 'next'].forEach(k => delete c[k]);
      Object.assign(c, { text: '', width: w, boxH: h, m: M.mul(src.m, M.translate(x, y)), name: T.name + ' · ' + (i + 1), wrapPart: T.id });
      model.insert(c, par, par.children.indexOf(T) + i);
      made.push(c);
    });
    [T].concat(made).forEach((n, i, a) => { if (a[i + 1]) n.next = a[i + 1].id; });
    T.wrap = { src, obs: obs.map(o => o.id), offset, parts: made.map(c => c.id) };
    model.reindex();
    if (O.print && O.print.flowAll) O.print.flowAll();
    O.select([T.id]);
    commit('Обтікання текстом');
  };
  OM.wrapRelease = (T, quiet) => {
    T = T || O.topSel().find(n => n.wrap) || O.topSel().map(n => n.wrapPart && model.get(n.wrapPart)).find(Boolean);
    if (!T || !T.wrap) { if (!quiet) toast('Виділіть текст з обтіканням'); return; }
    const keep = S.sel.slice();
    O.select([T.id]);
    O.suspendCommit = true;
    try { if (O.print && O.print.unthread) O.print.unthread(); } finally { O.suspendCommit = false; }
    T.wrap.parts.map(model.get).filter(Boolean).forEach(n => model.remove(n));
    const s = T.wrap.src;
    T.m = s.m; if (s.width) T.width = s.width; else delete T.width; if (s.boxH) T.boxH = s.boxH; else delete T.boxH;
    delete T.wrap; delete T.next;
    model.reindex();
    O.select(quiet ? keep.filter(id => model.exists(id)) : [T.id]);
    if (!quiet) commit('Звільнити обтікання');
  };
  OM.wrapOptions = () => {
    const T = O.topSel().find(n => n.wrap);
    ui.dialog({
      title: 'Параметри обтікання текстом',
      fields: [{ key: 'off', label: 'Відступ', type: 'number', value: T ? T.wrap.offset : O.ls.get('wrapOff', 12), unit: 'px', min: 0 }],
      onOk: v => {
        O.ls.set('wrapOff', Math.max(0, v.off));
        if (T) { const ids = [T.id].concat(T.wrap.obs); OM.wrapRelease(T, true); O.select(ids.filter(id => model.exists(id))); OM.wrapMake(Math.max(0, v.off)); }
      }
    });
  };

  // ======================================================================
  // ARTBOARDS (frames)
  // ======================================================================
  OM.abConvert = () => {
    const ns = O.topSel().filter(n => n.type === 'rect' || n.type === 'ellipse' || n.type === 'path' || n.type === 'polygon');
    if (!ns.length) return toast('Виділіть прямокутники, з яких зробити монтажні області');
    const out = [];
    ns.forEach(n => {
      const b = model.worldBounds(n);
      const f = model.create('frame', { name: n.name, w: round(b.w), h: round(b.h), m: M.translate(round(b.x), round(b.y)), fills: hasFill(n) ? O.clone(n.fills) : [O.paint.solid('#FFFFFF')] });
      model.insert(f, model.page());
      model.remove(n);
      out.push(f.id);
    });
    O.select(out);
    commit('Перетворити на монтажні області');
  };
  OM.abRearrange = () => {
    const frames = model.page().children.filter(n => n.type === 'frame');
    if (!frames.length) return toast('На сторінці немає монтажних областей');
    ui.dialog({
      title: 'Упорядкувати всі монтажні області',
      fields: [
        { key: 'cols', label: 'Стовпців', type: 'number', value: Math.ceil(Math.sqrt(frames.length)), min: 1 },
        { key: 'gap', label: 'Проміжок', type: 'number', value: 80, unit: 'px', min: 0 },
        { key: 'order', label: 'Порядок', type: 'select', value: 'row', options: [['row', 'Рядками'], ['col', 'Стовпцями']] }
      ],
      preview: true, label: 'Упорядкувати монтажні області',
      apply: v => {
        const cols = Math.max(1, round(v.cols)), rows = Math.ceil(frames.length / cols);
        const cell = (i) => v.order === 'col' ? [Math.floor(i / rows), i % rows] : [i % cols, Math.floor(i / cols)];
        const colW = [], rowH = [];
        frames.forEach((f, i) => { const [c, r] = cell(i); colW[c] = Math.max(colW[c] || 0, f.w); rowH[r] = Math.max(rowH[r] || 0, f.h); });
        const x0 = frames[0].m[4], y0 = frames[0].m[5];
        frames.forEach((f, i) => { const [c, r] = cell(i); let x = x0, y = y0; for (let k = 0; k < c; k++) x += colW[k] + v.gap; for (let k = 0; k < r; k++) y += rowH[k] + v.gap; f.m = [f.m[0], f.m[1], f.m[2], f.m[3], x, y]; });
      }
    });
  };
  const fitFrameTo = (f, b) => {
    // b in world space; the children keep their place
    const W = model.worldMatrix(f), lb = R.transform(b, M.inv(W));
    f.children.forEach(c => { c.m = M.mul(M.translate(-lb.x, -lb.y), c.m); });
    f.m = M.mul(f.m, M.translate(lb.x, lb.y));
    f.w = Math.max(1, round(lb.w)); f.h = Math.max(1, round(lb.h));
  };
  OM.abFitArtwork = () => {
    const frames = O.topSel().filter(n => n.type === 'frame');
    const list = frames.length ? frames : model.page().children.filter(n => n.type === 'frame');
    let k = 0;
    list.forEach(f => { const b = f.children.length ? model.selBounds(f.children.filter(c => c.visible !== false)) : null; if (b) { fitFrameTo(f, b); k++; } });
    if (!k) return toast('У монтажних областях немає ілюстрацій');
    commit('Підігнати до меж ілюстрації');
  };
  OM.abFitSelection = () => {
    const ns = O.topSel();
    if (!ns.length) return toast('Спершу виділіть об’єкт');
    const f = ns.map(n => model.ancestors(n).find(a => a.type === 'frame')).find(Boolean);
    if (!f) { ops.frameSelection(ns, { fill: true, name: t('Монтажна область') }); return; }
    fitFrameTo(f, model.selBounds(ns));
    commit('Підігнати до виділених об’єктів');
  };

  // ======================================================================
  // GRAPHS (data kept on the group: Data… and Type… rebuild it)
  // ======================================================================
  const GRAPH_TYPES = [['column', 'Стовпчиковий'], ['bar', 'Горизонтальний'], ['line', 'Лінійний'], ['area', 'Площинний'], ['pie', 'Круговий']];
  const GRAPH_COLORS = ['#5B3DF5', '#FF6B9A', '#FFC857', '#2EC4B6', '#3A86FF', '#FB5607', '#8AC926', '#6A4C93'];
  const parseData = s => String(s || '').split(/\n+/).map(l => l.split(/[;,\t]/).map(x => x.trim())).filter(r => r[0] !== '' || r.length > 1).map(r => ({ label: r[0], v: Math.max(0, parseFloat(String(r[1] || '0').replace(',', '.')) || 0) }));
  const txt = (s, x, y, w, size, color, align, weight) => model.create('text', { text: String(s), size, width: w, align: align || 'center', weight: weight || 400, font: 'Inter', fills: [O.paint.solid(color || '#333344')], m: M.translate(x, y) });
  OM.buildGraph = (g, spec) => {
    g.children = [];
    const W = spec.w, H = spec.h, data = parseData(spec.data);
    const max = Math.max(1, ...data.map(d => d.v));
    const pad = 36, cw = W - pad - 10, chh = H - pad - 10;
    const col = i => O.paint.solid(GRAPH_COLORS[i % GRAPH_COLORS.length]);
    if (spec.title) g.children.push(txt(spec.title, 0, -30, W, 16, '#1A1A2E', 'left', 700));
    if (spec.type === 'pie') {
      const total = data.reduce((s, d) => s + d.v, 0) || 1, cx = W / 2, cy = H / 2, r = Math.min(W, H) / 2 - 4;
      let a0 = -Math.PI / 2;
      data.forEach((d, i) => {
        const a1 = a0 + d.v / total * Math.PI * 2;
        const arc = []; const N = Math.max(2, Math.ceil((a1 - a0) / 0.1));
        arc.push(G.pt(cx, cy)); for (let k = 0; k <= N; k++) { const a = a0 + (a1 - a0) * k / N; arc.push(G.pt(cx + Math.cos(a) * r, cy + Math.sin(a) * r)); }
        g.children.push(newPath([{ closed: true, pts: arc }], { fills: [col(i)], strokes: [O.paint.solid('#FFFFFF')], sw: 2 }, d.label));
        const am = (a0 + a1) / 2;
        g.children.push(txt(d.label + ' · ' + round(d.v / total * 100) + '%', cx + Math.cos(am) * (r + 26) - 50, cy + Math.sin(am) * (r + 26) - 7, 100, 11, '#333344'));
        a0 = a1;
      });
      return g;
    }
    // axes and grid
    const ax = newPath([{ closed: false, pts: [G.pt(pad, 0), G.pt(pad, chh), G.pt(pad + cw, chh)] }], lineStyle('#8C8CA1', 1), t('Осі'));
    for (let k = 0; k <= 4; k++) {
      const y = chh - chh * k / 4;
      if (k) g.children.push(newPath([{ closed: false, pts: [G.pt(pad, y), G.pt(pad + cw, y)] }], Object.assign(lineStyle('#D8D8E3', 0.5)), t('Сітка')));
      if (spec.type !== 'bar') g.children.push(txt(O.fmt(max * k / 4, 1), 0, y - 7, pad - 6, 10, '#6B6B80', 'right'));
    }
    g.children.push(ax);
    const n = Math.max(1, data.length), slot = (spec.type === 'bar' ? chh : cw) / n;
    if (spec.type === 'column' || spec.type === 'bar') {
      data.forEach((d, i) => {
        if (spec.type === 'column') { const h = chh * d.v / max, w = slot * 0.62; g.children.push(model.create('rect', { name: d.label, w, h: Math.max(0.5, h), radius: 3, m: M.translate(pad + i * slot + (slot - w) / 2, chh - h), fills: [col(i)] })); g.children.push(txt(d.label, pad + i * slot, chh + 6, slot, 10, '#444455')); }
        else { const w = cw * d.v / max, h = slot * 0.62; g.children.push(model.create('rect', { name: d.label, w: Math.max(0.5, w), h, radius: 3, m: M.translate(pad, i * slot + (slot - h) / 2), fills: [col(i)] })); g.children.push(txt(d.label, 0, i * slot + slot / 2 - 7, pad - 6, 10, '#444455', 'right')); }
      });
    } else {
      const pts = data.map((d, i) => G.pt(pad + slot * (i + 0.5), chh - chh * d.v / max));
      if (spec.type === 'area' && pts.length) g.children.push(newPath([{ closed: true, pts: [G.pt(pts[0].x, chh)].concat(pts.map(p => G.pt(p.x, p.y)), [G.pt(pts[pts.length - 1].x, chh)]) }], { fills: [O.paint.solid(GRAPH_COLORS[0], 0.35)], strokes: [] }, t('Площа')));
      if (pts.length > 1) g.children.push(newPath([{ closed: false, pts: pts.map(p => G.pt(p.x, p.y)) }], Object.assign(lineStyle(GRAPH_COLORS[0], 3), { join: 'round', cap: 'round' }), t('Лінія')));
      pts.forEach((p, i) => { g.children.push(model.create('ellipse', { name: data[i].label, w: 9, h: 9, m: M.translate(p.x - 4.5, p.y - 4.5), fills: [O.paint.solid('#FFFFFF')], strokes: [O.paint.solid(GRAPH_COLORS[0])], sw: 2 })); g.children.push(txt(data[i].label, pad + slot * i, chh + 6, slot, 10, '#444455')); });
    }
    return g;
  };
  const graphDialog = (g) => {
    const spec = g ? g.graph : { type: O.ls.get('graphType', 'column'), w: 420, h: 260, title: t('Продажі за квартал'), data: [t('Січень') + ', 42', t('Лютий') + ', 58', t('Березень') + ', 35', t('Квітень') + ', 71', t('Травень') + ', 64'].join('\n') };
    ui.dialog({
      title: g ? 'Дані графіка' : 'Створити графік',
      fields: [
        { key: 'type', label: 'Тип', type: 'select', value: spec.type, options: GRAPH_TYPES },
        { key: 'title', label: 'Заголовок', type: 'text', value: spec.title || '' },
        { key: 'w', label: 'Ширина', type: 'number', value: spec.w, unit: 'px', min: 60 },
        { key: 'h', label: 'Висота', type: 'number', value: spec.h, unit: 'px', min: 60 },
        { key: 'data', type: 'html', html: `<label class="dlg-row col"><span>${esc(t('Дані: «мітка, значення» в кожному рядку'))}</span><textarea data-k="data" rows="7" spellcheck="false">${esc(spec.data)}</textarea></label>` }
      ],
      onOk: v => {
        O.ls.set('graphType', v.type);
        const sp = { type: v.type, title: v.title, w: Math.max(60, v.w), h: Math.max(60, v.h), data: v.data };
        if (g) { g.graph = sp; OM.buildGraph(g, sp); model.reindex(); O.select([g.id]); commit('Дані графіка'); return; }
        const vr = O.view.viewRect(), c = R.center(vr);
        const ng = model.create('group', { name: t('Графік'), graph: sp, m: M.translate(round(c.x - sp.w / 2), round(c.y - sp.h / 2)) });
        OM.buildGraph(ng, sp);
        model.insert(ng, O.view.containerAt ? O.view.containerAt(c) : model.page());
        O.select([ng.id]);
        commit('Графік');
      }
    });
  };
  OM.graphMake = () => graphDialog(null);
  OM.graphData = () => { const g = O.topSel().find(n => n.graph); if (!g) return toast('Виділіть графік'); graphDialog(g); };
  OM.graphType = () => {
    const g = O.topSel().find(n => n.graph);
    if (!g) return toast('Виділіть графік');
    ui.dialog({ title: 'Тип графіка', fields: [{ key: 'type', label: 'Тип', type: 'select', value: g.graph.type, options: GRAPH_TYPES }], onOk: v => { g.graph.type = v.type; OM.buildGraph(g, g.graph); model.reindex(); O.select([g.id]); commit('Тип графіка'); } });
  };

  // ======================================================================
  // COLLECT FOR EXPORT (Asset Export panel)
  // ======================================================================
  const assetsList = () => S.doc.exportAssets || (S.doc.exportAssets = []);
  OM.collect = multi => {
    const ns = O.topSel();
    if (!ns.length) return toast('Спершу виділіть об’єкт');
    const list = assetsList();
    if (multi) ns.forEach(n => list.push({ id: O.uid(), name: n.name, ids: [n.id] }));
    else list.push({ id: O.uid(), name: ns.length === 1 ? ns[0].name : t('Ресурс') + ' ' + (list.length + 1), ids: ns.map(n => n.id) });
    commit('Зібрати для експорту');
    toast('Ресурсів для експорту: {n}. Файл → … або Об’єкт → Зібрати для експорту → Експорт ресурсів', { n: list.length });
  };
  OM.assetExport = () => {
    const list = assetsList().filter(a => a.ids.some(id => model.exists(id)));
    S.doc.exportAssets = list;
    if (!list.length) return toast('Ресурсів ще немає: виділіть об’єкти → Об’єкт → Зібрати для експорту');
    const rows = list.map((a, i) => `<div class="om-row"><input type="text" data-an="${i}" value="${esc(a.name)}" aria-label="${esc(t('Назва'))}"><span class="om-dim">${a.ids.length}</span><label class="chk"><input type="checkbox" data-ad="${i}"><span>${esc(t('Прибрати'))}</span></label></div>`).join('');
    ui.dialog({
      title: 'Експорт ресурсів',
      body: `<div class="om-list">${rows}</div>`,
      fields: [{ key: 'fmt', label: 'Формат', type: 'select', value: O.ls.get('assetFmt', 'png'), options: [['png', 'PNG'], ['jpg', 'JPG'], ['webp', 'WEBP'], ['svg', 'SVG'], ['pdf', 'PDF']] }, { key: 'scale', label: 'Масштаб', type: 'select', value: '1', options: [['1', '1×'], ['2', '2×'], ['3', '3×'], ['4', '4×']] }],
      buttons: [{ id: 'save', label: 'Зберегти список' }, { id: 'ok', label: 'Експортувати', primary: true }],
      onOk: (v, btn) => {
        const el = O.$$('.dlg-back').slice(-1)[0];
        const names = Array.from(el.querySelectorAll('[data-an]')).map(i => i.value.trim());
        const del = new Set(Array.from(el.querySelectorAll('[data-ad]')).filter(i => i.checked).map(i => +i.dataset.ad));
        list.forEach((a, i) => { if (names[i]) a.name = names[i]; });
        S.doc.exportAssets = list.filter((_, i) => !del.has(i));
        commit('Ресурси для експорту');
        if (btn !== 'ok') return;
        O.ls.set('assetFmt', v.fmt);
        const groups = S.doc.exportAssets.map(a => a.ids.map(model.get).filter(Boolean)).filter(g => g.length);
        O.io.export(v.fmt, +v.scale, groups, { together: false });
      }
    });
  };

  // ======================================================================
  // SELECT MENU
  // ======================================================================
  let lastSelectCmd = null;
  const remember = id => { lastSelectCmd = id; };
  const selectWhere = (pred, id) => {
    const out = [];
    model.walk(model.page().children, n => { if (n.visible === false || n.locked) return false; if (pred(n)) out.push(n.id); });
    remember(id);
    O.select(out);
    if (!out.length) toast('Нічого не знайдено');
    return out;
  };
  OM.selectArtboard = () => {
    const n = O.sel()[0];
    let f = n ? (n.type === 'frame' && !model.ancestors(n).some(a => a.type === 'frame') ? n : model.ancestors(n).reverse().find(a => a.type === 'frame')) : null;
    if (!f) { const c = R.center(O.view.viewRect()); f = model.page().children.find(x => x.type === 'frame' && R.contains(model.worldBounds(x), c)) || model.page().children.find(x => x.type === 'frame'); }
    if (!f) return ops.selectAll();
    O.select(f.children.filter(c => c.visible !== false && !c.locked).map(c => c.id));
  };
  OM.selectStep = dir => {
    const n = O.sel()[0];
    if (!n) return toast('Спершу виділіть об’єкт');
    const par = model.parent(n), i = par.children.indexOf(n), j = i + dir;
    if (j < 0 || j >= par.children.length) return toast(dir > 0 ? 'Вище немає об’єктів' : 'Нижче немає об’єктів');
    O.select([par.children[j].id]);
  };
  const SAME = {
    sameFillStroke: n => JSON.stringify([fillOf(n), (n.strokes || []).filter(s => s.visible !== false).map(s => O.paintColor(s))]),
    sameBlendOpacity: n => (n.blend || 'normal') + '|' + (n.opacity === undefined ? 1 : n.opacity),
    sameStyle: n => JSON.stringify([(n.effects || []).filter(e => e.visible !== false).map(e => [e.type, e.x, e.y, e.blur, e.color]), n.sw, n.dash]),
    sameInstance: n => n.type === 'instance' ? n.ref : null,
    sameTextStyle: n => n.type === 'text' ? [n.font, n.weight, n.size, fillOf(n)].join('|') : null
  };
  OM.selectSame = id => {
    const ref = O.sel()[0];
    if (!ref) return toast('Спершу виділіть зразок');
    const k = SAME[id](ref);
    if (k === null || k === undefined) return toast('Для цього об’єкта немає зразка');
    selectWhere(n => SAME[id](n) === k, id);
  };
  const KIND = {
    selSameLayer: null,
    selClipMasks: n => n.type === 'group' && n.mask,
    selStray: n => n.type === 'path' && n.subpaths.reduce((s, sp) => s + sp.pts.length, 0) === 1,
    selAllText: n => n.type === 'text',
    selPointText: n => n.type === 'text' && !n.width && !n.path,
    selAreaText: n => n.type === 'text' && !!n.width && !n.path,
    selPathText: n => n.type === 'text' && !!n.path,
    selImages: n => isImage(n),
    selOpenPaths: n => n.type === 'path' && n.subpaths.some(sp => !sp.closed),
    selGroups: n => n.type === 'group' && !n.mask,
    selInstances: n => n.type === 'instance'
  };
  OM.selectKind = id => {
    if (id === 'selSameLayer') {
      const n = O.sel()[0];
      if (!n) return toast('Спершу виділіть об’єкт');
      const top = model.topLevel(n);
      const out = [];
      model.walk(top.children ? top.children : [top], x => { if (x.visible === false || x.locked) return false; out.push(x.id); return false; });
      remember(id);
      return O.select(out);
    }
    selectWhere(KIND[id], id);
  };
  OM.global = null;
  OM.globalEdit = () => {
    if (OM.global) { OM.global = null; toast('Глобальне редагування завершено'); return; }
    const ref = O.sel()[0];
    if (!ref) return toast('Виділіть об’єкт: знайдемо всі такі самі й редагуватимемо їх разом');
    const sig = n => n.type + '|' + round(model.localBounds(n).w) + '×' + round(model.localBounds(n).h) + '|' + (n.type === 'path' ? n.subpaths.reduce((s, sp) => s + sp.pts.length, 0) : '') + '|' + (n.type === 'text' ? n.text : '') + '|' + fillOf(n);
    const k = sig(ref);
    const ids = selectWhere(n => n.type !== 'group' && n.type !== 'frame' && sig(n) === k, 'globalEdit');
    OM.global = ids;
    toast('Знайдено однакових об’єктів: {n}. Змінюйте будь-який — зміни застосуються до всіх', { n: ids.length });
  };
  const saved = () => S.doc.savedSel || (S.doc.savedSel = []);
  let lastSaved = -1;
  OM.selSave = () => {
    if (!S.sel.length) return toast('Спершу виділіть об’єкти');
    ui.dialog({
      title: 'Зберегти виділення', fields: [{ key: 'name', label: 'Назва', type: 'text', value: t('Виділення') + ' ' + (saved().length + 1) }],
      onOk: v => { saved().push({ name: v.name.trim() || t('Виділення'), ids: S.sel.slice() }); lastSaved = saved().length - 1; commit('Зберегти виділення'); toast('Виділення збережено: воно внизу меню «Виділення»'); }
    });
  };
  OM.selEdit = () => {
    const list = saved();
    if (!list.length) return toast('Збережених виділень немає');
    const rows = list.map((s, i) => `<div class="om-row"><input type="text" data-sn="${i}" value="${esc(s.name)}" aria-label="${esc(t('Назва'))}"><span class="om-dim">${s.ids.filter(id => model.exists(id)).length}</span><label class="chk"><input type="checkbox" data-sd="${i}"><span>${esc(t('Видалити'))}</span></label></div>`).join('');
    ui.dialog({
      title: 'Редагувати виділення', body: `<div class="om-list">${rows}</div>`,
      onOk: () => {
        const el = O.$$('.dlg-back').slice(-1)[0];
        const names = Array.from(el.querySelectorAll('[data-sn]')).map(i => i.value.trim());
        const del = new Set(Array.from(el.querySelectorAll('[data-sd]')).filter(i => i.checked).map(i => +i.dataset.sd));
        S.doc.savedSel = list.map((s, i) => Object.assign(s, { name: names[i] || s.name })).filter((_, i) => !del.has(i));
        lastSaved = -1;
        commit('Редагувати виділення');
      }
    });
  };
  OM.selUpdate = () => {
    const s = saved()[lastSaved];
    if (!s) return toast('Спершу відкрийте збережене виділення');
    if (!S.sel.length) return toast('Спершу виділіть об’єкти');
    s.ids = S.sel.slice();
    commit('Оновити виділення');
    toast('Виділення «{name}» оновлено', { name: s.name });
  };
  OM.selLoad = i => { const s = saved()[i]; if (!s) return; lastSaved = i; O.select(s.ids.filter(id => model.exists(id))); };

  // ======================================================================
  // COMMANDS
  // ======================================================================
  [['distLeft', 'left', 'Розподілити ліві краї'], ['distHCenter', 'hcenter', 'Розподілити центри по горизонталі'], ['distRight', 'right', 'Розподілити праві краї'],
    ['distTop', 'top', 'Розподілити верхні краї'], ['distVCenter', 'vcenter', 'Розподілити центри по вертикалі'], ['distBottom', 'bottom', 'Розподілити нижні краї']]
    .forEach(([id, e, l]) => C(id, l, () => OM.distribute(e), { group: 'Вирівнювання', enabled: has(3) }));
  C('ungroupAll', 'Розгрупувати все', () => OM.ungroupAll(), { keys: ['Alt+Shift+G'] });
  C('lockAbove', 'Усі графічні об’єкти вище', () => OM.lockAbove(), { enabled: has(1) });
  C('lockOthers', 'Інші шари', () => OM.lockOthers(), { enabled: has(1) });
  C('hideAbove', 'Усі графічні об’єкти вище', () => OM.hideAbove(), { enabled: has(1) });
  C('hideOthers', 'Інші шари', () => OM.hideOthers(), { enabled: has(1) });
  C('expandDlg', 'Розгорнути…', () => OM.expandDialog(), { enabled: has(1) });
  C('expandAppearance', 'Розгорнути вигляд', () => OM.expandAppearance(), { enabled: has(1) });
  C('cropImage', 'Кадрування зображення', () => OM.cropImage(), { enabled: () => O.sel().some(n => isImage(n) || (O.photo && O.photo.frameOf && O.photo.frameOf(n))) });
  C('rasterizeDlg', 'Растеризувати…', () => OM.rasterizeDialog(), { enabled: has(1) });
  C('meshDlg', 'Створити сітчастий градієнт…', () => OM.meshDialog(), { enabled: () => O.topSel().some(n => GEOM.has(n.type)) });
  C('mosaicDlg', 'Створити фрагментацію об’єкта…', () => OM.mosaicDialog(), { enabled: () => O.topSel().some(isImage) });
  C('trimMarks', 'Створити мітки обрізки', () => OM.trimMarks(), { enabled: has(1) });
  C('flattenTransp', 'Звести області з прозорістю…', () => OM.flattenDialog());
  C('pixelPerfect', 'Створити бездоганне піксельне зображення', () => OM.pixelPerfect());
  C('genRecolor', 'Генеративне перефарбування…', () => OM.recolorDialog(), { enabled: has(1) });
  C('genVectors', 'Генерувати вектори (Claude)…', () => { if (O.cmds.get('claudeDesign')) O.run('claudeDesign'); else toast('Модуль «Дизайн з Claude» недоступний'); });
  C('sliceMake', 'Створити', () => OM.sliceMake(false), { enabled: has(1) });
  C('sliceFromSel', 'Створити з виділеного', () => OM.sliceMake(true), { enabled: has(1) });
  C('sliceOptions', 'Параметри фрагментів…', () => OM.sliceOptions());
  C('sliceDeleteAll', 'Видалити всі', () => OM.sliceDeleteAll());
  C('sliceShow', 'Показувати фрагменти', () => { S.settings.showSlices = !S.settings.showSlices; O.saveSettings(); O.requestOverlay(); }, { check: () => !!S.settings.showSlices });
  C('sliceExport', 'Експортувати фрагменти…', () => OM.sliceExport());
  C('divideBelow', 'Розділити нижні об’єкти', () => OM.divideBelow(), { group: 'Контур', enabled: has(1) });
  C('shapeConvert', 'Перетворити на фігуру', () => OM.shapeConvert(), { enabled: () => O.topSel().some(n => n.type === 'path') });
  C('shapeExpand', 'Розгорнути фігуру', () => OM.shapeExpand(), { enabled: () => O.topSel().some(n => model.SHAPES.has(n.type)) });
  C('patternMake', 'Створити візерунок', () => OM.patternMake(), { enabled: has(1) });
  C('patternApply', 'Застосувати візерунок…', () => OM.patternApply());
  C('twMake', 'Створити переплетення', () => OM.intertwine(0), { enabled: has(2) });
  C('twEdit', 'Змінити переплетення', () => OM.intertwine(), { enabled: () => O.topSel().some(n => n.intertwine) });
  C('twRelease', 'Звільнити переплетення', () => OM.intertwineRelease(), { enabled: () => O.topSel().some(n => n.intertwine) });
  C('repRadial', 'Радіальне', () => OM.repeat('radial'), { enabled: has(1) });
  C('repGrid', 'Сітка', () => OM.repeat('grid'), { enabled: has(1) });
  C('repMirror', 'Дзеркало', () => OM.repeat('mirror'), { enabled: has(1) });
  C('repRelease', 'Звільнити', () => OM.repeatRelease(), { enabled: () => O.topSel().some(n => n.repeat) });
  C('repOptions', 'Параметри повторення…', () => OM.repeatOptions(), { enabled: has(1) });
  C('onPath', 'Прикріпити до контуру…', () => OM.onPathDialog(), { enabled: has(2) });
  C('blendRelease', 'Звільнити перехід', () => { const g = O.topSel().find(n => n.type === 'group' && n.children.length > 2); if (!g) return toast('Виділіть перехід'); const kids = g.children; const keep = [kids[0], kids[kids.length - 1]]; kids.slice(1, -1).forEach(k => model.remove(k)); O.select([g.id]); ops.ungroup([g]); O.select(keep.map(k => k.id)); }, { group: 'Перехід', enabled: has(1) });
  C('blendExpand', 'Розгорнути перехід', () => { const g = O.topSel().find(n => n.type === 'group'); if (!g) return toast('Виділіть перехід'); ops.ungroup([g]); }, { group: 'Перехід', enabled: has(1) });
  C('envWarp', 'Створити з деформацією…', () => OM.envWarpDialog(), { enabled: has(1) });
  C('envRelease', 'Звільнити', () => OM.envRelease(), { enabled: has(1) });
  C('envExpand', 'Розгорнути', () => OM.envExpand(), { enabled: has(1) });
  C('perspDistort', 'Спотворити в перспективі…', () => OM.perspectiveDialog(), { enabled: has(1) });
  C('perspRelease', 'Звільнити з перспективи', () => OM.envRelease(), { enabled: has(1) });
  C('perspGrid', 'Показати сітку перспективи', () => { S.settings.perspGrid = !S.settings.perspGrid; O.saveSettings(); O.requestOverlay(); }, { check: () => !!S.settings.perspGrid });
  C('lpMake', 'Створити швидку заливку', () => OM.livePaint(), { enabled: has(2) });
  C('lpRelease', 'Звільнити швидку заливку', () => OM.livePaintRelease(false), { enabled: () => O.topSel().some(n => n.livePaint) });
  C('lpExpand', 'Розгорнути швидку заливку', () => OM.livePaintRelease(true), { enabled: () => O.topSel().some(n => n.livePaint) });
  C('mockupMake', 'Створити макет…', () => OM.mockupDialog(), { enabled: has(1) });
  C('mockupRelease', 'Звільнити макет', () => { const g = O.topSel().find(n => n.mockup); if (!g) return toast('Виділіть макет'); ops.ungroup([g]); }, { enabled: () => O.topSel().some(n => n.mockup) });
  C('traceDlg', 'Параметри трасування…', () => ui.dialog({ title: 'Трасування зображення', fields: [{ key: 'p', label: 'Набір', type: 'select', value: 'default', options: [['default', 'За замовчуванням'], ['photo', 'Фото (детально)'], ['poster', 'Постер (4 кольори)'], ['bw', 'Чорно-біле'], ['sketch', 'Ескіз']] }], buttons: [{ id: 'ok', label: 'Трасувати', primary: true }], onOk: v => ops.imageTrace(v.p) }), { group: 'Трасування зображення', enabled: () => O.sel().some(isImage) });
  C('wrapMake', 'Створити обтікання', () => OM.wrapMake(), { enabled: has(2) });
  C('wrapRelease', 'Звільнити обтікання', () => OM.wrapRelease(), { enabled: () => O.topSel().some(n => n.wrap || n.wrapPart) });
  C('wrapOptions', 'Параметри обтікання текстом…', () => OM.wrapOptions());
  C('clipEditMask', 'Редагувати маску', () => { const g = O.sel().map(n => (n.mask ? n : model.parent(n))).find(p => p && p.mask); if (!g) return toast('Виділіть обтравочну групу'); O.select([g.children[0].id]); }, { group: 'Маска', enabled: has(1) });
  C('clipEditContents', 'Редагувати вміст', () => { const g = O.sel().map(n => (n.mask ? n : model.parent(n))).find(p => p && p.mask); if (!g) return toast('Виділіть обтравочну групу'); O.select(g.children.slice(1).map(c => c.id)); }, { group: 'Маска', enabled: has(1) });
  C('abConvert', 'Перетворити на монтажні області', () => OM.abConvert(), { enabled: has(1) });
  C('abRearrange', 'Упорядкувати все…', () => OM.abRearrange());
  C('abFitArt', 'Підігнати до меж ілюстрації', () => OM.abFitArtwork());
  C('abFitSel', 'Підігнати до виділених об’єктів', () => OM.abFitSelection(), { enabled: has(1) });
  C('graphMake', 'Створити графік…', () => OM.graphMake());
  C('graphData', 'Дані…', () => OM.graphData(), { enabled: () => O.topSel().some(n => n.graph) });
  C('graphType', 'Тип…', () => OM.graphType(), { enabled: () => O.topSel().some(n => n.graph) });
  C('collectSingle', 'Як окремий ресурс', () => OM.collect(false), { enabled: has(1) });
  C('collectMulti', 'Як кілька ресурсів', () => OM.collect(true), { enabled: has(1) });
  C('assetExport', 'Експорт ресурсів…', () => OM.assetExport());
  // Select
  const CS = (id, label, run, opts) => O.cmd(id, label, run, Object.assign({ group: 'Виділення' }, opts || {}));
  CS('selArtboard', 'Усе в активній монтажній області', () => OM.selectArtboard(), { keys: ['Ctrl+Alt+A'] });
  CS('reselect', 'Повторно виділити', () => { if (lastSelectCmd) { if (O.cmds.get(lastSelectCmd)) O.run(lastSelectCmd); } }, { keys: ['Ctrl+6'], enabled: () => !!lastSelectCmd });
  CS('selAbove', 'Наступний об’єкт вище', () => OM.selectStep(1), { keys: ['Ctrl+Alt+]'], enabled: has(1) });
  CS('selBelow', 'Наступний об’єкт нижче', () => OM.selectStep(-1), { keys: ['Ctrl+Alt+['], enabled: has(1) });
  [['sameFillStroke', 'Заливка й обведення'], ['sameBlendOpacity', 'Режим накладання й непрозорість'], ['sameStyle', 'Стиль графіки'], ['sameInstance', 'Екземпляр компонента'], ['sameTextStyle', 'Оформлення тексту']]
    .forEach(([id, l]) => CS(id, l, () => OM.selectSame(id), { group: 'Виділити схоже', enabled: has(1) }));
  [['selSameLayer', 'Усе на тому ж шарі'], ['selClipMasks', 'Обтравочні маски'], ['selStray', 'Окремі вузли'], ['selAllText', 'Усі текстові об’єкти'], ['selPointText', 'Точковий текст'], ['selAreaText', 'Текст в області'], ['selPathText', 'Текст за контуром'], ['selImages', 'Зображення'], ['selOpenPaths', 'Відкриті контури'], ['selGroups', 'Групи'], ['selInstances', 'Екземпляри компонентів']]
    .forEach(([id, l]) => CS(id, l, () => OM.selectKind(id)));
  // the same-… commands of app.js become repeatable with Ctrl+6
  ['sameFill', 'sameStroke', 'sameSW', 'sameOpacity', 'sameBlend', 'sameFont', 'sameType'].forEach(id => { const c = O.cmds.get(id); if (c && !c._rem) { const run = c.run; c.run = () => { remember(id); return run(); }; c._rem = true; } });
  CS('globalEdit', () => t(OM.global ? 'Зупинити глобальне редагування' : 'Почати глобальне редагування'), () => OM.globalEdit());
  CS('selSave', 'Зберегти виділення…', () => OM.selSave(), { enabled: () => S.sel.length > 0 });
  CS('selEdit', 'Редагувати виділення…', () => OM.selEdit(), { enabled: () => !!(S.doc.savedSel || []).length });
  CS('selUpdate', 'Оновити виділення', () => OM.selUpdate(), { enabled: () => lastSaved >= 0 && !!(S.doc.savedSel || [])[lastSaved] && S.sel.length > 0 });
  const SAVED_MAX = 20;
  for (let i = 0; i < SAVED_MAX; i++) CS('selLoad:' + i, () => ((S.doc.savedSel || [])[i] || {}).name || '', () => OM.selLoad(i), { hidden: () => !(S.doc && (S.doc.savedSel || [])[i]) });

  // ======================================================================
  // MENUS (Illustrator order; VIBSma extras follow below)
  // ======================================================================
  const sub = (label, items) => ({ label, items });
  const objIdx = O.MENUS.findIndex(m => m[0] === 'Об’єкт');
  if (objIdx >= 0) {
    const old = O.MENUS[objIdx][1];
    const subOf = label => (old.find(x => x && x.label === label) || { items: [] }).items;
    const ill = [
      sub('Трансформувати', subOf('Трансформація')),
      sub('Упорядкувати', subOf('Порядок')),
      sub('Вирівняти', subOf('Вирівнювання').filter(x => x !== 'distH' && x !== 'distV' && x !== '-')),
      sub('Розподілити об’єкти', ['distLeft', 'distHCenter', 'distRight', '-', 'distTop', 'distVCenter', 'distBottom', '-', 'distH', 'distV']),
      '-',
      'group', 'ungroup', 'ungroupAll',
      sub('Заблокувати', ['lock', 'lockAbove', 'lockOthers']), 'unlockAll',
      sub('Сховати', ['hide', 'hideAbove', 'hideOthers']), 'showAll',
      '-',
      'expandDlg', 'expandAppearance', 'removeBg', 'cropImage', 'rasterizeDlg', 'meshDlg', 'mosaicDlg', 'trimMarks', 'flattenTransp',
      '-', 'pixelPerfect',
      '-', sub('Генеративний', ['genRecolor', 'genVectors']),
      '-', sub('Фрагменти для вебу', ['sliceMake', 'sliceFromSel', '-', 'sliceOptions', 'sliceDeleteAll', '-', 'sliceShow', 'sliceExport']),
      '-',
      sub('Контур', subOf('Контур').concat(['-', 'divideBelow'])),
      sub('Фігура', ['shapeConvert', 'shapeExpand']),
      sub('Візерунок', ['patternMake', 'patternApply']),
      sub('Переплетення', ['twMake', 'twEdit', 'twRelease']),
      sub('Повторення', ['repRadial', 'repGrid', 'repMirror', '-', 'repRelease', 'repOptions']),
      sub('Об’єкти за контуром', ['onPath']),
      sub('Перехід', subOf('Перехід').concat(['-', 'blendRelease', 'blendExpand'])),
      sub('Деформація за конвертом', ['envWarp', '-', 'envRelease', 'envExpand']),
      sub('Перспектива', ['perspDistort', 'perspRelease', '-', 'perspGrid']),
      sub('Швидка заливка', ['lpMake', 'lpRelease', 'lpExpand']),
      sub('Макет', ['mockupMake', 'mockupRelease']),
      sub('Трасування зображення', subOf('Трасування зображення').concat(['-', 'traceDlg'])),
      sub('Обтікання текстом', ['wrapMake', 'wrapRelease', '-', 'wrapOptions']),
      '-',
      sub('Відсічна маска', subOf('Обтравочна маска').concat(['-', 'clipEditMask', 'clipEditContents'])),
      sub('Складений шлях', subOf('Складений контур')),
      sub('Монтажні області', ['abConvert', 'abRearrange', 'abFitArt', 'abFitSel']),
      sub('Графік', ['graphMake', 'graphData', 'graphType']),
      '-',
      sub('Зібрати для експорту', ['collectSingle', 'collectMulti', '-', 'assetExport'])
    ];
    // everything else the menu had (Figma and InDesign extras, other modules) stays, below
    const used = new Set(['Трансформація', 'Порядок', 'Вирівнювання', 'Контур', 'Перехід', 'Трасування зображення', 'Обтравочна маска', 'Складений контур']);
    const usedIds = new Set(['group', 'ungroup', 'lock', 'unlockAll', 'hide', 'showAll', 'removeBg']);
    const rest = old.filter(x => x === '-' || (typeof x === 'string' ? !usedIds.has(x) : !used.has(x.label)));
    const extra = [];
    rest.forEach(x => { if (x === '-' && (!extra.length || extra[extra.length - 1] === '-')) return; extra.push(x); });
    while (extra[extra.length - 1] === '-') extra.pop();
    O.MENUS[objIdx][1] = ill.concat(['-'], extra);
  }
  const selIdx = O.MENUS.findIndex(m => m[0] === 'Виділення');
  if (selIdx >= 0) {
    const oldSame = (O.MENUS[selIdx][1].find(x => x && x.label === 'Схоже') || { items: [] }).items;
    O.MENUS[selIdx][1] = ['selectAll', 'selArtboard', 'deselect', 'reselect', 'selectInverse', '-', 'selAbove', 'selBelow', '-',
      sub('Таке саме', oldSame.concat(['-', 'sameFillStroke', 'sameBlendOpacity', 'sameStyle', 'sameInstance', 'sameTextStyle'])),
      sub('Об’єкт', ['selSameLayer', '-', 'selClipMasks', 'selStray', 'selOpenPaths', 'selGroups', 'selInstances', 'selImages', '-', 'selAllText', 'selPointText', 'selAreaText', 'selPathText']),
      'globalEdit', '-', 'selSave', 'selEdit', 'selUpdate', '-'].concat(Array.from({ length: SAVED_MAX }, (_, i) => 'selLoad:' + i));
  }
})();
