'use strict';
/* VIBSma — image tools like Figma's: remove background.
   First an AI model that runs in the browser (@imgly/background-removal, downloaded once from the CDN; the photo
   itself is not uploaded anywhere). Offline, or when the model cannot load, a local method removes a plain
   background: the colour along the edges is flood-filled away and the cut edge is softened. */
(function () {
  const O = window.O, S = O.state, io = O.io;
  const t = (s, v) => O.t(s, v);
  const IF = O.imgfx = {};
  IF.AI_URL = 'https://cdn.jsdelivr.net/npm/@imgly/background-removal@1.7.0/+esm';
  let aiMod = null, aiBroken = 0;

  // ---------- AI (in the browser) ----------
  IF.aiRemove = async (blob, say) => {
    if (!aiMod) aiMod = await import(IF.AI_URL);
    return aiMod.removeBackground(blob, {
      output: { format: 'image/png' },
      progress: (key, cur, total) => {
        if (/^fetch/.test(key) && total) say(t('Завантажую AI-модель… {p}%', { p: Math.round(cur / total * 100) }));
        else if (/compute/.test(key)) say(t('AI відокремлює об’єкт від фону…'));
      }
    });
  };

  // ---------- local: plain background from the edges ----------
  IF.localRemove = async img => {
    const k = Math.min(1, 4096 / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.max(1, Math.round(img.naturalWidth * k)), h = Math.max(1, Math.round(img.naturalHeight * k));
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    const cx = cv.getContext('2d', { willReadFrequently: true });
    cx.drawImage(img, 0, 0, w, h);
    const im = cx.getImageData(0, 0, w, h), d = im.data;
    // the background colour: median of the opaque edge pixels
    const edge = [];
    for (let x = 0; x < w; x++) edge.push(x, (h - 1) * w + x);
    for (let y = 1; y < h - 1; y++) edge.push(y * w, y * w + w - 1);
    const opaque = edge.filter(i => d[i * 4 + 3] > 10);
    if (opaque.length < edge.length * 0.3) return null; // the edges are already transparent
    const med = c => { const v = opaque.map(i => d[i * 4 + c]).sort((a, b) => a - b); return v[v.length >> 1]; };
    const bg = [med(0), med(1), med(2)];
    const dist = i => Math.hypot(d[i * 4] - bg[0], d[i * 4 + 1] - bg[1], d[i * 4 + 2] - bg[2]);
    // how even the background is decides the tolerance; a busy edge means it is not a plain background
    const ed = opaque.map(dist).sort((a, b) => a - b);
    const p80 = ed[Math.floor(ed.length * 0.8)];
    if (p80 > 60) return null;
    const tol = O.clamp(p80 * 1.6 + 16, 22, 80);
    // flood fill from the edges through similar colours (and through pixels that are already transparent)
    const bgMask = new Uint8Array(w * h), q = new Int32Array(w * h);
    let qh = 0, qt = 0;
    const visit = i => { if (bgMask[i]) return; if (d[i * 4 + 3] > 10 && dist(i) > tol) return; bgMask[i] = 1; q[qt++] = i; };
    edge.forEach(visit);
    while (qh < qt) {
      const i = q[qh++], x = i % w;
      if (x > 0) visit(i - 1);
      if (x < w - 1) visit(i + 1);
      if (i >= w) visit(i - w);
      if (i < w * (h - 1)) visit(i + w);
    }
    const share = qt / (w * h);
    if (share < 0.02 || share > 0.97) return null;
    // soft edge: object pixels next to the background become partly transparent when close to its colour
    for (let i = 0; i < w * h; i++) {
      if (bgMask[i]) { d[i * 4 + 3] = 0; continue; }
      const x = i % w;
      const nearBg = (x > 0 && bgMask[i - 1]) || (x < w - 1 && bgMask[i + 1]) || (i >= w && bgMask[i - w]) || (i < w * (h - 1) && bgMask[i + w]);
      if (nearBg) d[i * 4 + 3] = Math.round(d[i * 4 + 3] * O.clamp((dist(i) - tol * 0.5) / tol, 0.25, 1));
    }
    cx.putImageData(im, 0, 0);
    return new Promise(res => cv.toBlob(res, 'image/png'));
  };

  // the share of visible pixels (on a small copy)
  IF.opaqueShare = async blob => {
    const img = await io.loadImage(URL.createObjectURL(blob));
    const k = Math.min(1, 128 / Math.max(img.naturalWidth, img.naturalHeight, 1));
    const cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(img.naturalWidth * k)); cv.height = Math.max(1, Math.round(img.naturalHeight * k));
    const cx = cv.getContext('2d', { willReadFrequently: true });
    cx.drawImage(img, 0, 0, cv.width, cv.height);
    const d = cx.getImageData(0, 0, cv.width, cv.height).data;
    let n = 0;
    for (let i = 3; i < d.length; i += 4) if (d[i] > 40) n++;
    URL.revokeObjectURL(img.src);
    return n / (d.length / 4);
  };
  // a new asset with the background removed (the original stays, for «Restore original»); null when it failed
  let busy = false;
  IF.removeBg = async (assetId, progress) => {
    const a = S.doc.assets[assetId];
    if (!a || busy) return null;
    busy = true;
    let last = '';
    const say = msg => { if (msg === last) return; last = msg; if (progress) progress(msg); };
    if (!progress) O.toast('Видаляю фон…');
    try {
      let out = null, how = 'ai';
      // a failed AI load is retried after a minute (the connection may come back)
      if (navigator.onLine !== false && Date.now() - aiBroken > 60000) {
        try {
          say(t('Завантажую AI-модель…'));
          const blob = await (await fetch(O.assetURL(assetId))).blob();
          out = await IF.aiRemove(blob, say);
          // the model found no object (it returns an almost empty picture): try the plain-background method
          if (await IF.opaqueShare(out) < 0.01) out = null;
        } catch (e) { console.warn('AI background removal failed, using the local method', e); aiBroken = Date.now(); out = null; }
      }
      if (!out) {
        how = 'local';
        say(t('Прибираю однотонний фон…'));
        out = await IF.localRemove(await io.loadImage(O.assetURL(assetId)));
      }
      if (!out) { say(''); O.toast('Не вдалося знайти фон: він не однотонний. З інтернетом працює AI-видалення фону для будь-яких фото.'); return null; }
      const added = await io.addAsset(await io.blobToData(out), (a.name || t('Зображення')) + ' — ' + t('без фону'));
      say('');
      O.toast(how === 'ai' ? 'Фон видалено (AI)' : 'Фон видалено');
      return added.id;
    } catch (e) {
      console.warn(e);
      O.toast('Не вдалося видалити фон: {msg}', { msg: e.message });
      return null;
    } finally { busy = false; }
  };

  // ---------- command: for every selected image (also photos inside graphic frames) ----------
  const imageFills = () => {
    const out = [];
    for (const n of O.sel()) {
      const gf = O.photo && O.photo.frameOf(n);
      const c = gf ? O.photo.contentOf(gf) : n;
      const f = (c && c.fills || []).find(p => p.type === 'image' && p.asset);
      if (f && !out.includes(f)) out.push(f);
    }
    return out;
  };
  IF.removeBgSelection = async () => {
    const list = imageFills();
    if (!list.length) return O.toast('Виділіть зображення');
    let done = 0;
    for (const f of list) {
      const id = await IF.removeBg(f.asset);
      if (!id) continue;
      if (!f.origAsset) f.origAsset = f.asset;
      f.asset = id;
      done++;
    }
    if (done) O.history.commit('Видалити фон');
  };
  IF.restoreSelection = () => {
    const list = imageFills().filter(f => f.origAsset);
    if (!list.length) return O.toast('Немає змінених зображень');
    list.forEach(f => { f.asset = f.origAsset; delete f.origAsset; });
    O.history.commit('Повернути оригінал');
  };
  O.cmd('removeBg', 'Видалити фон зображення', () => IF.removeBgSelection(), { group: 'Фото' });
  O.cmd('restoreImage', 'Повернути оригінал зображення', () => IF.restoreSelection(), { group: 'Фото' });
  const objMenu = O.MENUS.find(m => m[0] === 'Об’єкт');
  const photoSub = objMenu && objMenu[1].find(x => x && x.label === 'Фото (InDesign)');
  if (photoSub) photoSub.items.push('-', 'removeBg', 'restoreImage');
})();
