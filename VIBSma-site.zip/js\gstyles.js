'use strict';
/* VIBSma — graphic styles (Photoshop: Styles panel, Illustrator: Graphic Styles).
   A style is the whole look of an object: fills, strokes and their settings, every effect (shadows, glows, blur,
   Liquid Glass), opacity, blend mode, corner radius and — for text — the font. Styles are saved in this browser for
   every project (and in the account when signed in), can be applied with one click, updated, renamed, exported and
   imported as a .vibstyles file. */
(function () {
  const O = window.O, model = O.model, S = O.state, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const GS = O.gstyles = {};
  const KEY = 'graphicStyles';
  const LOOK = ['fills', 'strokes', 'sw', 'sa', 'cap', 'join', 'dash', 'miter', 'ms', 'me', 'effects', 'opacity', 'blend'];
  const TEXT = ['font', 'size', 'weight', 'italic', 'ls', 'lh', 'align', 'deco', 'tcase'];

  // ---------- built-in styles ----------
  const sh = (x, y, blur, color, opacity, spread = 0) => ({ type: 'shadow', x, y, blur, spread, color, opacity, visible: true });
  const solid = (c, op) => O.paint.solid(c, op);
  const lin = (a, b) => ({ type: 'linear', from: { x: 0, y: 0 }, to: { x: 0, y: 1 }, stops: [{ o: 0, color: a }, { o: 1, color: b }], visible: true });
  GS.BUILTIN = [
    { id: 'b-soft', name: 'М’яка тінь', fills: [solid('#FFFFFF')], strokes: [], effects: [sh(0, 8, 24, '#14142B', 0.14)], radius: 16 },
    { id: 'b-float', name: 'Плаваюча картка', fills: [solid('#FFFFFF')], strokes: [solid('#E6E6EE')], sw: 1, effects: [sh(0, 2, 6, '#14142B', 0.08), sh(0, 18, 40, '#14142B', 0.16)], radius: 20 },
    { id: 'b-neon', name: 'Неон', fills: [solid('#0B0B14')], strokes: [solid('#34F5FF')], sw: 3, effects: [{ type: 'glow', x: 0, y: 0, blur: 18, spread: 2, color: '#34F5FF', opacity: 0.9, visible: true }, { type: 'innerglow', x: 0, y: 0, blur: 12, spread: 0, color: '#34F5FF', opacity: 0.5, visible: true }], radius: 14 },
    { id: 'b-emboss', name: 'Тиснення', fills: [solid('#E9E9EF')], strokes: [], effects: [sh(-6, -6, 14, '#FFFFFF', 0.9), sh(6, 6, 14, '#A3A3B5', 0.55)], radius: 18 },
    { id: 'b-gold', name: 'Золото', fills: [lin('#FFE9A6', '#B8862B')], strokes: [solid('#7A5512')], sw: 1.5, effects: [sh(0, 6, 14, '#5C3D00', 0.35), { type: 'inner', x: 0, y: 2, blur: 3, spread: 0, color: '#FFFFFF', opacity: 0.6, visible: true }], radius: 10 },
    { id: 'b-chrome', name: 'Хром', fills: [lin('#FAFAFC', '#7C808C')], strokes: [solid('#4A4D57')], sw: 1, effects: [{ type: 'inner', x: 0, y: -3, blur: 4, spread: 0, color: '#000000', opacity: 0.25, visible: true }, sh(0, 4, 10, '#000000', 0.3)], radius: 12 },
    { id: 'b-glossy', name: 'Глянцева кнопка', fills: [lin('#5AB2FF', '#0D63D6')], strokes: [], effects: [{ type: 'inner', x: 0, y: 2, blur: 2, spread: 0, color: '#FFFFFF', opacity: 0.55, visible: true }, sh(0, 6, 14, '#0D63D6', 0.4)], radius: 999 },
    { id: 'b-glass', name: 'Liquid Glass', fills: [solid('#FFFFFF', 0.12)], strokes: [], effects: [{ type: 'glass', visible: true, blur: 8, refract: 36, depth: 22, light: 0.7, sat: 1.6, x: 0, y: 0, rimColor: '#FFFFFF', rimColor2: '#FFFFFF', rim: 0, sheen: 0.15, tintOp: 0 }, sh(0, 8, 24, '#000000', 0.18)], radius: 28 },
    { id: 'b-retro', name: 'Ретро-тінь', fills: [solid('#FFD84D')], strokes: [solid('#1B1B1B')], sw: 3, effects: [sh(8, 8, 0, '#1B1B1B', 1)], radius: 6 },
    { id: 'b-dashed', name: 'Пунктирна рамка', fills: [solid('#F4F7FF')], strokes: [solid('#3D6BFF')], sw: 2, dash: [8, 6], cap: 'round', effects: [], radius: 12 },
    { id: 'b-sunset', name: 'Захід сонця', fills: [{ type: 'linear', from: { x: 0, y: 0 }, to: { x: 1, y: 1 }, stops: [{ o: 0, color: '#FF5F6D' }, { o: 1, color: '#FFC371' }], visible: true }], strokes: [], effects: [sh(0, 12, 30, '#FF5F6D', 0.35)], radius: 24 },
    { id: 'b-title', name: 'Заголовок з тінню', text: { font: 'Inter', weight: 800, size: 48, ls: -1 }, fills: [solid('#1B1B2F')], strokes: [], effects: [sh(0, 4, 0, '#FF5FA2', 1)] }
  ];
  // ---------- 88 more: 100 ready-made styles in 12 categories ----------
  {
    const B = GS.BUILTIN;
    const CAT = { 'b-soft': 'Тіні', 'b-float': 'Тіні', 'b-neon': 'Неон', 'b-emboss': 'Об’єм', 'b-gold': 'Метал', 'b-chrome': 'Метал', 'b-glossy': 'Кнопки', 'b-glass': 'Скло', 'b-retro': 'Ретро', 'b-dashed': 'Контури', 'b-sunset': 'Градієнти', 'b-title': 'Текст' };
    B.forEach(s => { s.cat = CAT[s.id]; });
    const fx = (type, o) => Object.assign({ type, x: 0, y: 0, blur: 8, spread: 0, color: '#000000', opacity: 0.5, visible: true }, o);
    const grad = (stops, diag = true) => ({ type: 'linear', from: { x: 0, y: 0 }, to: diag ? { x: 1, y: 1 } : { x: 0, y: 1 }, stops: stops.map((c, i) => ({ o: i / (stops.length - 1), color: c })), visible: true });
    const add = (cat, id, name, st) => B.push(Object.assign({ id: 'b-' + id, name, cat, strokes: [], effects: [] }, st));
    // neon
    [['pink', 'Неон рожевий', '#FF3DCB'], ['green', 'Неон зелений', '#39FF88'], ['yellow', 'Неон жовтий', '#FFE53D'], ['purple', 'Неон фіолетовий', '#B46BFF'], ['red', 'Неон червоний', '#FF3B3B'], ['orange', 'Неон помаранчевий', '#FF9A3D'], ['white', 'Неон білий', '#F4F4FF']].forEach(([k, n, c]) => add('Неон', 'neon-' + k, n, { fills: [solid('#0B0B14')], strokes: [solid(c)], sw: 3, effects: [fx('glow', { blur: 18, spread: 2, color: c, opacity: 0.9 }), fx('innerglow', { blur: 12, color: c, opacity: 0.5 })], radius: 14 }));
    // metals
    [['silver', 'Срібло', ['#FFFFFF', '#C9CDD6', '#8A909C'], '#5C616B'], ['bronze', 'Бронза', ['#F3C79A', '#B7773F', '#7A4A1E'], '#5A3414'], ['rosegold', 'Рожеве золото', ['#FFE3D8', '#E8A18C', '#B66C5A'], '#8A4A3C'], ['copper', 'Мідь', ['#FFC9A3', '#D2733A', '#8C3F14'], '#6B2E0C'], ['steel', 'Шліфована сталь', ['#E9ECF1', '#AEB4BF', '#E9ECF1', '#8D939E'], '#4F555F']].forEach(([k, n, st, edge]) => add('Метал', k, n, { fills: [grad(st, false)], strokes: [solid(edge)], sw: 1, effects: [fx('inner', { y: 2, blur: 3, color: '#FFFFFF', opacity: 0.6 }), sh(0, 5, 12, '#000000', 0.3)], radius: 10 }));
    // glass (the Liquid Glass looks)
    const glass = (o, tint) => ({ fills: [solid(tint || '#FFFFFF', 0.12)], effects: [Object.assign({ type: 'glass', visible: true, blur: 8, refract: 36, depth: 22, light: 0.7, sat: 1.6, x: 0, y: 0, rimColor: '#FFFFFF', rimColor2: '#FFFFFF', rim: 0, sheen: 0.15, tint: '#FFFFFF', tintOp: 0, rainbow: false }, o), sh(0, 8, 24, '#000000', 0.18)], radius: 28 });
    add('Скло', 'glass-frost', 'Матове скло', glass({ blur: 22, refract: 18, tintOp: 0.18 }));
    add('Скло', 'glass-blue', 'Блакитне скло', glass({ blur: 10, refract: 30, rimColor: '#BFE3FF', rimColor2: '#6FB8FF', tint: '#2E8BFF', tintOp: 0.22 }));
    add('Скло', 'glass-dark', 'Темне скло', glass({ blur: 14, refract: 26, light: 0.35, rimColor2: '#7A7A88', tint: '#0B0B10', tintOp: 0.45 }));
    add('Скло', 'glass-gold', 'Золоте скло', glass({ rimColor: '#FFE7A3', rimColor2: '#C9902B', tint: '#F5C451', tintOp: 0.14 }));
    add('Скло', 'glass-rainbow', 'Райдужне скло', glass({ refract: 46, rainbow: true }));
    add('Скло', 'glass-crystal', 'Кришталь', glass({ blur: 0, refract: 64, depth: 34, light: 0.95, sat: 2, rimColor2: '#DDEBFF', sheen: 0.24 }));
    add('Скло', 'glass-pink', 'Рожеве скло', glass({ rimColor: '#FFD6EC', rimColor2: '#FF7AB8', tint: '#FF5FA2', tintOp: 0.18 }));
    // gradients
    [['ocean', 'Океан', ['#2193B0', '#6DD5ED']], ['peach', 'Персик', ['#FFB88C', '#DE6262']], ['mojito', 'Мохіто', ['#1D976C', '#93F9B9']], ['aurora', 'Північне сяйво', ['#00C9FF', '#92FE9D']], ['fire', 'Вогонь', ['#F12711', '#F5AF19']], ['berry', 'Ягоди', ['#8E2DE2', '#FF6A88']], ['lavender', 'Лаванда', ['#B993D6', '#8CA6DB']], ['mint', 'М’ята', ['#A8FF78', '#78FFD6']], ['night', 'Нічне небо', ['#0F2027', '#203A43', '#2C5364']], ['candy', 'Цукерка', ['#FF9A9E', '#FAD0C4', '#FBC2EB']], ['citrus', 'Цитрус', ['#F7971E', '#FFD200']], ['royal', 'Королівський', ['#141E30', '#243B55', '#4B6CB7']], ['ice', 'Лід', ['#E0EAFC', '#CFDEF3', '#A1C4FD']]].forEach(([k, n, st]) => add('Градієнти', 'grad-' + k, n, { fills: [grad(st)], effects: [sh(0, 10, 26, st[0], 0.3)], radius: 20 }));
    // shadows / elevation
    [1, 2, 3, 4].forEach(l => add('Тіні', 'elev-' + l, 'Висота ' + l, { fills: [solid('#FFFFFF')], effects: [sh(0, l, l * 2, '#14142B', 0.12), sh(0, l * 4, l * 8, '#14142B', 0.08 + l * 0.02)], radius: 12 }));
    add('Тіні', 'dark-card', 'Глибока тінь', { fills: [solid('#1E1E26')], effects: [sh(0, 20, 50, '#000000', 0.55)], radius: 18 });
    add('Тіні', 'blue-shadow', 'Кольорова тінь (синя)', { fills: [solid('#3D6BFF')], effects: [sh(0, 14, 30, '#3D6BFF', 0.5)], radius: 16 });
    add('Тіні', 'purple-shadow', 'Кольорова тінь (фіолетова)', { fills: [solid('#8E44FF')], effects: [sh(0, 14, 30, '#8E44FF', 0.5)], radius: 16 });
    // depth: neumorphism, insets
    add('Об’єм', 'neu-light', 'Неоморфізм (світлий)', { fills: [solid('#E6E9EF')], effects: [sh(-8, -8, 16, '#FFFFFF', 1), sh(8, 8, 16, '#A3B1C6', 0.6)], radius: 22 });
    add('Об’єм', 'neu-pressed', 'Неоморфізм (натиснутий)', { fills: [solid('#E6E9EF')], effects: [fx('inner', { x: 6, y: 6, blur: 10, color: '#A3B1C6', opacity: 0.7 }), fx('inner', { x: -6, y: -6, blur: 10, color: '#FFFFFF', opacity: 1 })], radius: 22 });
    add('Об’єм', 'neu-dark', 'Неоморфізм (темний)', { fills: [solid('#2B2D34')], effects: [sh(-8, -8, 16, '#3A3D46', 1), sh(8, 8, 16, '#16171B', 0.9)], radius: 22 });
    add('Об’єм', 'neu-dark-pressed', 'Неоморфізм темний (натиснутий)', { fills: [solid('#2B2D34')], effects: [fx('inner', { x: 6, y: 6, blur: 10, color: '#16171B', opacity: 0.9 }), fx('inner', { x: -6, y: -6, blur: 10, color: '#3A3D46', opacity: 1 })], radius: 22 });
    add('Об’єм', 'inner-warm', 'Тепле світіння всередині', { fills: [solid('#2A1A12')], effects: [fx('innerglow', { blur: 24, color: '#FF9A3D', opacity: 0.8 })], radius: 18 });
    add('Об’єм', 'magic', 'Магія', { fills: [solid('#1A0F2E')], strokes: [solid('#C77DFF')], sw: 1.5, effects: [fx('innerglow', { blur: 20, color: '#C77DFF', opacity: 0.7 }), fx('glow', { blur: 26, spread: 1, color: '#7B2CBF', opacity: 0.8 })], radius: 18 });
    // retro offset shadows
    [['pink', 'Ретро рожевий', '#FF8FB1'], ['mint', 'Ретро м’ятний', '#7DE2C3'], ['blue', 'Ретро синій', '#6EA8FF'], ['orange', 'Ретро помаранчевий', '#FFB067'], ['mono', 'Ретро чорно-білий', '#FFFFFF']].forEach(([k, n, c]) => add('Ретро', 'retro-' + k, n, { fills: [solid(c)], strokes: [solid('#1B1B1B')], sw: 3, effects: [sh(8, 8, 0, '#1B1B1B', 1)], radius: 6 }));
    // outlines
    add('Контури', 'line-thin', 'Тонкий контур', { fills: [solid('#FFFFFF', 0)], strokes: [solid('#1B1B2F')], sw: 1, radius: 8 });
    add('Контури', 'line-thick', 'Товстий контур', { fills: [solid('#FFFFFF', 0)], strokes: [solid('#1B1B2F')], sw: 6, join: 'round', radius: 14 });
    add('Контури', 'line-dots', 'Крапковий контур', { fills: [solid('#FFFFFF', 0)], strokes: [solid('#FF3B5C')], sw: 4, dash: [0.1, 10], cap: 'round', radius: 16 });
    add('Контури', 'line-grad', 'Градієнтний контур', { fills: [solid('#FFFFFF')], strokes: [grad(['#FF5F6D', '#7F00FF'])], sw: 4, radius: 16 });
    add('Контури', 'line-sketch', 'Ескіз', { fills: [solid('#FFFDF5')], strokes: [solid('#2B2B2B')], sw: 2, dash: [14, 4, 2, 4], cap: 'round', radius: 4 });
    // buttons
    [['primary', 'Кнопка основна', '#2563EB'], ['success', 'Кнопка «успіх»', '#16A34A'], ['danger', 'Кнопка «небезпека»', '#DC2626'], ['warning', 'Кнопка «увага»', '#F59E0B']].forEach(([k, n, c]) => add('Кнопки', 'btn-' + k, n, { fills: [solid(c)], effects: [sh(0, 4, 10, c, 0.35)], radius: 10 }));
    add('Кнопки', 'btn-ghost', 'Кнопка-контур', { fills: [solid('#FFFFFF', 0)], strokes: [solid('#2563EB')], sw: 2, radius: 10 });
    add('Кнопки', 'btn-pill', 'Кнопка-таблетка', { fills: [solid('#111827')], effects: [sh(0, 6, 16, '#111827', 0.3)], radius: 999 });
    add('Кнопки', 'btn-grad', 'Градієнтна кнопка', { fills: [grad(['#8E2DE2', '#4A00E0'])], effects: [sh(0, 8, 20, '#6A00F4', 0.45)], radius: 999 });
    add('Кнопки', 'btn-3d', 'Об’ємна кнопка', { fills: [solid('#FF5A5F')], effects: [sh(0, 6, 0, '#B8282D', 1), sh(0, 10, 14, '#000000', 0.25)], radius: 12 });
    add('Кнопки', 'btn-soft', 'М’яка кнопка', { fills: [solid('#E8EEFF')], effects: [], radius: 12 });
    // cards
    add('Картки', 'card-white', 'Біла картка', { fills: [solid('#FFFFFF')], strokes: [solid('#ECECF2')], sw: 1, effects: [sh(0, 4, 14, '#14142B', 0.08)], radius: 16 });
    add('Картки', 'card-dark', 'Темна картка', { fills: [solid('#16161D')], strokes: [solid('#2A2A35')], sw: 1, effects: [sh(0, 10, 30, '#000000', 0.4)], radius: 16 });
    add('Картки', 'card-tint', 'Тонована картка', { fills: [solid('#F1F5FF')], strokes: [solid('#D6E0FF')], sw: 1, radius: 16 });
    add('Картки', 'card-border', 'Картка з рамкою', { fills: [solid('#FFFFFF')], strokes: [solid('#1B1B2F')], sw: 2, radius: 12 });
    add('Картки', 'card-photo', 'Картка-фото', { fills: [solid('#FFFFFF')], strokes: [solid('#FFFFFF')], sw: 10, effects: [sh(0, 12, 28, '#14142B', 0.22)], radius: 4 });
    // text styles (the font, the colour and the effects; the size stays as it is)
    const tx = (id, name, text, st) => add('Текст', 'tx-' + id, name, Object.assign({ text, effects: [] }, st));
    tx('grad', 'Градієнтний заголовок', { font: 'Inter', weight: 900, ls: -1 }, { fills: [grad(['#FF5F6D', '#7F00FF'])] });
    tx('outline', 'Контурний текст', { font: 'Inter', weight: 900 }, { fills: [solid('#FFFFFF', 0)], strokes: [solid('#1B1B2F')], sw: 2 });
    tx('neonpink', 'Неоновий текст рожевий', { font: 'Inter', weight: 700 }, { fills: [solid('#FFE6F6')], effects: [fx('glow', { blur: 16, spread: 1, color: '#FF3DCB', opacity: 0.95 })] });
    tx('neoncyan', 'Неоновий текст блакитний', { font: 'Inter', weight: 700 }, { fills: [solid('#E6FFFF')], effects: [fx('glow', { blur: 16, spread: 1, color: '#34F5FF', opacity: 0.95 })] });
    tx('3d', 'Об’ємний 3D-текст', { font: 'Inter', weight: 900 }, { fills: [solid('#FFD84D')], effects: [sh(2, 2, 0, '#E0A800', 1), sh(4, 4, 0, '#C08A00', 1), sh(6, 6, 0, '#9A6E00', 1), sh(8, 8, 6, '#000000', 0.4)] });
    tx('long', 'Довга тінь', { font: 'Inter', weight: 900 }, { fills: [solid('#FFFFFF')], effects: [sh(10, 10, 0, '#2A2A3A', 1)] });
    tx('glitch', 'Глітч-текст', { font: 'Inter', weight: 900 }, { fills: [solid('#FFFFFF')], effects: [sh(-3, 0, 0, '#FF2D55', 0.9), sh(3, 0, 0, '#00E5FF', 0.9)] });
    tx('sunset', 'Ретро-захід', { font: 'Inter', weight: 900, italic: true }, { fills: [grad(['#FFE45E', '#FF6B9A', '#7F3DFF'], false)], strokes: [solid('#2B1B5A')], sw: 2 });
    tx('gold', 'Золотий текст', { font: 'Playfair Display', weight: 700 }, { fills: [grad(['#FFF1B5', '#D4A23C', '#8A5A12'], false)], effects: [sh(0, 2, 2, '#5C3D00', 0.5)] });
    tx('chrome', 'Хромований текст', { font: 'Inter', weight: 900 }, { fills: [grad(['#FFFFFF', '#9AA0AC', '#FFFFFF', '#5E636E'], false)], strokes: [solid('#3A3D46')], sw: 1 });
    tx('serif', 'Елегантний із засічками', { font: 'Playfair Display', weight: 600, italic: true }, { fills: [solid('#2B2420')] });
    tx('hand', 'Рукописний', { font: 'Caveat', weight: 600 }, { fills: [solid('#1E3A8A')] });
    tx('comic', 'Комікс', { font: 'Bangers', weight: 400, ls: 1 }, { fills: [solid('#FFE14D')], strokes: [solid('#111111')], sw: 2, effects: [sh(4, 4, 0, '#111111', 1)] });
    tx('stamp', 'Штамп', { font: 'Oswald', weight: 700, tcase: 'upper', ls: 2 }, { fills: [solid('#D7263D')], effects: [] });
    tx('pastel', 'Пастельний', { font: 'Nunito', weight: 800 }, { fills: [solid('#8E7DFF')], effects: [sh(0, 4, 0, '#FFC6E7', 1)] });
    tx('condensed', 'Вузький заголовок', { font: 'Oswald', weight: 700, tcase: 'upper', ls: 1 }, { fills: [solid('#111827')] });
    tx('mono', 'Код', { font: 'JetBrains Mono', weight: 500 }, { fills: [solid('#22C55E')] });
    tx('emboss', 'Тиснений текст', { font: 'Inter', weight: 900 }, { fills: [solid('#D9DDE6')], effects: [sh(-1, -1, 0, '#FFFFFF', 1), sh(1, 1, 1, '#7C8494', 0.8)] });
    tx('glow', 'Біле сяйво', { font: 'Inter', weight: 800 }, { fills: [solid('#FFFFFF')], effects: [fx('glow', { blur: 22, spread: 2, color: '#FFFFFF', opacity: 0.8 })] });
  }
  // ---------- 900 more: 30 recipes × 30 colours (1000 in all) ----------
  {
    const B = GS.BUILTIN, mix = (a, b, k) => O.color.mix(a, b, k);
    GS.COLORS = [['red', 'Червоний', '#E53935'], ['coral', 'Кораловий', '#FF6F61'], ['orange', 'Помаранчевий', '#FB8C00'], ['amber', 'Бурштиновий', '#FFB300'], ['yellow', 'Жовтий', '#FDD835'], ['lime', 'Лаймовий', '#C0CA33'], ['green', 'Зелений', '#43A047'], ['emerald', 'Смарагдовий', '#00A676'], ['teal', 'Бірюзовий', '#00ACC1'], ['sky', 'Небесний', '#29B6F6'], ['blue', 'Синій', '#1E88E5'], ['indigo', 'Індиго', '#3949AB'], ['violet', 'Фіолетовий', '#7E57C2'], ['purple', 'Пурпуровий', '#9C27B0'], ['pink', 'Рожевий', '#EC407A'], ['raspberry', 'Малиновий', '#D81B60'], ['cherry', 'Вишневий', '#B71C1C'], ['burgundy', 'Бордовий', '#7B1F3A'], ['brown', 'Коричневий', '#795548'], ['sand', 'Пісочний', '#D7B98E'], ['olive', 'Оливковий', '#7C8A2E'], ['khaki', 'Хакі', '#A1946B'], ['mint', 'М’ятний', '#4DD0B5'], ['lavender', 'Лавандовий', '#A58BE0'], ['peach', 'Персиковий', '#FFAB91'], ['navy', 'Темно-синій', '#1A2A5E'], ['graphite', 'Графітовий', '#37474F'], ['gray', 'Сірий', '#9E9E9E'], ['black', 'Чорний', '#111111'], ['white', 'Білий', '#F5F5F7']];
    const sh = (x, y, blur, color, opacity, spread = 0) => ({ type: 'shadow', x, y, blur, spread, color, opacity, visible: true });
    const fx = (type, o) => Object.assign({ type, x: 0, y: 0, blur: 8, spread: 0, color: '#000000', opacity: 0.5, visible: true }, o);
    const sol = c => O.paint.solid(c);
    const gr = (stops, diag = true) => ({ type: 'linear', from: { x: 0, y: 0 }, to: diag ? { x: 1, y: 1 } : { x: 0, y: 1 }, stops: stops.map((c, i) => ({ o: i / (stops.length - 1), color: c })), visible: true });
    const on = c => (O.color.luminance(c) > 0.6 ? '#141414' : '#FFFFFF');
    const L = (c, k) => mix(c, '#FFFFFF', k), D = (c, k) => mix(c, '#000000', k);
    // [id, recipe name, category, (c, next colour) → style]
    const R = [
      ['flat', 'Плаский', 'Кнопки', c => ({ fills: [sol(c)], radius: 12 })],
      ['softc', 'М’яка кольорова тінь', 'Тіні', c => ({ fills: [sol(c)], effects: [sh(0, 12, 28, c, 0.45)], radius: 18 })],
      ['glight', 'Світлий градієнт', 'Градієнти', c => ({ fills: [gr([L(c, 0.55), c])], radius: 18 })],
      ['gdeep', 'Глибокий градієнт', 'Градієнти', c => ({ fills: [gr([c, D(c, 0.55)])], effects: [sh(0, 10, 24, D(c, 0.4), 0.35)], radius: 18 })],
      ['gduo', 'Двоколірний градієнт', 'Градієнти', (c, n) => ({ fills: [gr([c, n])], effects: [sh(0, 10, 26, c, 0.3)], radius: 20 })],
      ['neon', 'Неонова рамка', 'Неон', c => ({ fills: [sol('#0B0B14')], strokes: [sol(c)], sw: 3, effects: [fx('glow', { blur: 18, spread: 2, color: c, opacity: 0.9 }), fx('innerglow', { blur: 12, color: c, opacity: 0.45 })], radius: 14 })],
      ['tneon', 'Неоновий текст', 'Текст', c => ({ text: { font: 'Inter', weight: 700 }, fills: [sol(L(c, 0.8))], effects: [fx('glow', { blur: 16, spread: 1, color: c, opacity: 0.95 })] })],
      ['line', 'Контур', 'Контури', c => ({ fills: [O.paint.solid('#FFFFFF', 0)], strokes: [sol(c)], sw: 3, radius: 12 })],
      ['dash', 'Пунктир', 'Контури', c => ({ fills: [sol(L(c, 0.88))], strokes: [sol(c)], sw: 2, dash: [8, 6], cap: 'round', radius: 12 })],
      ['retro', 'Ретро-тінь', 'Ретро', c => ({ fills: [sol(c)], strokes: [sol('#1B1B1B')], sw: 3, effects: [sh(8, 8, 0, '#1B1B1B', 1)], radius: 6 })],
      ['retroc', 'Кольорова ретро-тінь', 'Ретро', c => ({ fills: [sol('#FFFFFF')], strokes: [sol(D(c, 0.3))], sw: 3, effects: [sh(8, 8, 0, c, 1)], radius: 6 })],
      ['btn', 'Кнопка', 'Кнопки', c => ({ fills: [sol(c)], effects: [sh(0, 4, 10, c, 0.35)], radius: 10 })],
      ['btnline', 'Кнопка-контур', 'Кнопки', c => ({ fills: [O.paint.solid('#FFFFFF', 0)], strokes: [sol(c)], sw: 2, radius: 10 })],
      ['btn3d', 'Об’ємна кнопка', 'Кнопки', c => ({ fills: [sol(c)], effects: [sh(0, 6, 0, D(c, 0.35), 1), sh(0, 10, 14, '#000000', 0.22)], radius: 12 })],
      ['pill', 'Кнопка-таблетка', 'Кнопки', c => ({ fills: [gr([L(c, 0.15), D(c, 0.15)], false)], effects: [sh(0, 8, 18, c, 0.4)], radius: 999 })],
      ['cardac', 'Картка з акцентом', 'Картки', c => ({ fills: [sol('#FFFFFF')], strokes: [sol(L(c, 0.6))], sw: 1.5, effects: [sh(0, 10, 26, c, 0.18)], radius: 16 })],
      ['cardt', 'Тонована картка', 'Картки', c => ({ fills: [sol(L(c, 0.9))], strokes: [sol(L(c, 0.7))], sw: 1, radius: 16 })],
      ['glass', 'Кольорове скло', 'Скло', c => ({ fills: [O.paint.solid(c, 0.12)], effects: [{ type: 'glass', visible: true, blur: 10, refract: 30, depth: 22, light: 0.65, sat: 1.7, x: 0, y: 0, rimColor: L(c, 0.7), rimColor2: c, rim: 0, sheen: 0.14, tint: c, tintOp: 0.2, rainbow: false }, sh(0, 8, 24, '#000000', 0.18)], radius: 28 })],
      ['metal', 'Кольоровий метал', 'Метал', c => ({ fills: [gr([L(c, 0.6), c, D(c, 0.45)], false)], strokes: [sol(D(c, 0.55))], sw: 1, effects: [fx('inner', { y: 2, blur: 3, color: '#FFFFFF', opacity: 0.55 }), sh(0, 5, 12, '#000000', 0.3)], radius: 10 })],
      ['neu', 'Кольоровий неоморфізм', 'Об’єм', c => ({ fills: [sol(L(c, 0.85))], effects: [sh(-8, -8, 16, '#FFFFFF', 0.9), sh(8, 8, 16, D(L(c, 0.6), 0.25), 0.55)], radius: 22 })],
      ['inglow', 'Світіння всередині', 'Об’єм', c => ({ fills: [sol(D(c, 0.8))], effects: [fx('innerglow', { blur: 24, color: c, opacity: 0.85 })], radius: 18 })],
      ['aura', 'Аура', 'Неон', c => ({ fills: [sol(c)], effects: [fx('glow', { blur: 30, spread: 4, color: c, opacity: 0.75 })], radius: 20 })],
      ['emboss', 'Тиснення', 'Об’єм', c => ({ fills: [sol(c)], effects: [fx('inner', { x: -3, y: -3, blur: 4, color: '#FFFFFF', opacity: 0.45 }), fx('inner', { x: 3, y: 3, blur: 4, color: '#000000', opacity: 0.35 })], radius: 16 })],
      ['gloss', 'Глянець', 'Кнопки', c => ({ fills: [gr([L(c, 0.35), D(c, 0.2)], false)], effects: [fx('inner', { y: 2, blur: 2, color: '#FFFFFF', opacity: 0.6 }), sh(0, 6, 14, c, 0.4)], radius: 999 })],
      ['double', 'Подвійна тінь', 'Тіні', c => ({ fills: [sol('#FFFFFF')], effects: [sh(0, 3, 6, c, 0.25), sh(0, 18, 36, c, 0.22)], radius: 18 })],
      ['tgrad', 'Градієнтний текст', 'Текст', (c, n) => ({ text: { font: 'Inter', weight: 900, ls: -1 }, fills: [gr([c, n])] })],
      ['t3d', 'Об’ємний текст', 'Текст', c => ({ text: { font: 'Inter', weight: 900 }, fills: [sol(c)], effects: [sh(2, 2, 0, D(c, 0.2), 1), sh(4, 4, 0, D(c, 0.35), 1), sh(6, 6, 0, D(c, 0.5), 1), sh(8, 8, 6, '#000000', 0.35)] })],
      ['tline', 'Контурний текст', 'Текст', c => ({ text: { font: 'Inter', weight: 900 }, fills: [O.paint.solid('#FFFFFF', 0)], strokes: [sol(c)], sw: 2 })],
      ['tshadow', 'Текст з кольоровою тінню', 'Текст', c => ({ text: { font: 'Inter', weight: 800 }, fills: [sol(on(c) === '#FFFFFF' ? '#1B1B2F' : '#1B1B2F')], effects: [sh(4, 4, 0, c, 1)] })],
      ['pastel', 'Пастельна плашка', 'Картки', c => ({ fills: [sol(L(c, 0.75))], effects: [sh(0, 8, 20, L(c, 0.3), 0.35)], radius: 28 })]
    ];
    GS.RECIPES = R.map(r => [r[0], r[1], r[2]]);
    R.forEach(([rid, rname, cat, make]) => GS.COLORS.forEach(([cid, cname, c], i) => {
      const next = GS.COLORS[(i + 3) % GS.COLORS.length][2];
      B.push(Object.assign({ id: 'g-' + rid + '-' + cid, name: rname, sub: cname, cat, color: cid, strokes: [], effects: [] }, make(c, next)));
    }));
  }
  GS.label = st => t(st.name) + (st.sub ? ' · ' + t(st.sub) : '');
  GS.CATS = ['Тіні', 'Неон', 'Метал', 'Скло', 'Градієнти', 'Об’єм', 'Ретро', 'Контури', 'Кнопки', 'Картки', 'Текст'];

  // ---------- storage ----------
  GS.list = () => O.ls.get(KEY, []);
  const store = list => { O.ls.set(KEY, list); O.emit('gstyles', list); };
  GS.all = () => GS.list().concat(GS.BUILTIN.map(s => Object.assign({ builtin: true }, s)));
  GS.find = id => GS.all().find(s => s.id === id);

  // ---------- capture & apply ----------
  GS.capture = n => {
    const st = {};
    for (const k of LOOK) if (n[k] !== undefined) st[k] = O.clone(n[k]);
    if (n.radius !== undefined && ['rect', 'frame', 'instance', 'polygon', 'star'].includes(n.type)) st.radius = O.clone(n.radius);
    if (n.type === 'text') { st.text = {}; for (const k of TEXT) if (n[k] !== undefined) st.text[k] = O.clone(n[k]); }
    return st;
  };
  GS.applyTo = (n, st) => {
    for (const k of LOOK) {
      if (st[k] !== undefined) n[k] = O.clone(st[k]);
      else if (k === 'effects' || k === 'strokes') n[k] = [];
    }
    if (st.radius !== undefined && ['rect', 'frame', 'instance'].includes(n.type)) n.radius = Array.isArray(st.radius) ? st.radius.slice() : Math.min(st.radius, Math.min(n.w || 0, n.h || 0) / 2 || st.radius);
    if (st.text && n.type === 'text') { for (const [k, v] of Object.entries(st.text)) n[k] = O.clone(v); if (st.text.font && O.fonts) O.fonts.load(st.text.font, st.text.weight || 400).then(() => O.requestRender()).catch(() => {}); }
    n.gstyle = st.id;
  };
  GS.apply = id => {
    const st = GS.find(id);
    const nodes = O.topSel();
    if (!st) return;
    if (!nodes.length) return O.toast('Виділіть об’єкт, до якого застосувати стиль');
    nodes.forEach(n => GS.applyTo(n, st));
    O.history.commit('Графічний стиль');
    O.toast('Стиль «{name}» застосовано', { name: GS.label(st) });
  };
  GS.save = () => {
    const n = O.sel()[0];
    if (!n) return O.toast('Виділіть об’єкт, стиль і ефекти якого зберегти');
    ui.dialog({
      title: 'Зберегти стиль і ефекти',
      body: `<div class="dlg-text">${esc(t('Збережуться заливки, обведення, усі ефекти (тіні, світіння, розмиття, Liquid Glass), непрозорість, режим накладання, заокруглення, а для тексту — шрифт. Стиль буде доступний у всіх проєктах.'))}</div>`,
      fields: [{ key: 'n', label: 'Назва', type: 'text', value: t('Мій стиль {n}', { n: GS.list().length + 1 }) }],
      onOk: v => {
        const st = Object.assign({ id: O.uid(), name: v.n.trim() || t('Стиль'), created: Date.now() }, GS.capture(n));
        store(GS.list().concat([st]));
        n.gstyle = st.id;
        O.history.commit('Зберегти стиль');
        O.toast('Стиль «{name}» збережено', { name: st.name });
      }
    });
  };
  GS.update = id => {
    const n = O.sel()[0];
    if (!n) return O.toast('Виділіть об’єкт');
    const list = GS.list(), st = list.find(s => s.id === id);
    if (!st) return;
    for (const k of LOOK.concat(['radius', 'text'])) delete st[k];
    Object.assign(st, GS.capture(n));
    store(list);
    // every object with this style in the open document follows
    for (const pg of S.doc.pages) model.walk(pg.children, x => { if (x.gstyle === id && x !== n) GS.applyTo(x, st); });
    O.history.commit('Оновити стиль');
  };
  GS.rename = id => {
    const list = GS.list(), st = list.find(s => s.id === id);
    if (!st) return;
    ui.dialog({ title: 'Перейменувати стиль', fields: [{ key: 'n', label: 'Назва', type: 'text', value: st.name }], onOk: v => { if (v.n.trim()) { st.name = v.n.trim(); store(list); } } });
  };
  GS.remove = id => { store(GS.list().filter(s => s.id !== id)); };
  GS.export = () => {
    const list = GS.list();
    if (!list.length) return O.toast('Збережених стилів ще немає');
    O.download(new Blob([JSON.stringify({ vibsmaStyles: 1, styles: list }, null, 1)], { type: 'application/json' }), 'VIBSma styles.vibstyles');
  };
  GS.import = async () => {
    const fs = await O.io.pickFiles('.vibstyles,.json', true);
    let added = 0;
    const list = GS.list();
    for (const f of fs) {
      try {
        const d = JSON.parse(await f.text());
        for (const s of (d && d.styles) || []) if (s && s.name) { list.push(Object.assign({}, s, { id: O.uid() })); added++; }
      } catch (e) { O.toast('«{name}» — це не файл стилів', { name: f.name }); }
    }
    if (added) store(list);
    O.toast('Імпортовано стилів: {n}', { n: added });
  };

  // ---------- previews ----------
  const prevCache = new Map();
  GS.preview = st => {
    const key = st.id + '|' + JSON.stringify(st).length;
    if (prevCache.has(key)) return prevCache.get(key);
    let out = '';
    try {
      const W = 64, H = 44;
      const tmp = st.text
        ? Object.assign(model.create('text', { text: 'Aa', size: 26, m: O.M.translate(10, 8) }), { id: 'gsprev' + st.id.replace(/\W/g, '') })
        : Object.assign(model.create('rect', { w: 44, h: 28, m: O.M.translate(10, 8) }), { id: 'gsprev' + st.id.replace(/\W/g, '') });
      GS.applyTo(tmp, st);
      if (st.text) tmp.size = 26;
      if (!st.text && tmp.radius > 14) tmp.radius = 14;
      // Liquid Glass needs something underneath to show: a striped backdrop
      const ctx = O.render.newCtx({ hit: false, exp: true, pfx: 'gsp' + O.uid().slice(0, 5) });
      const body = O.render.nodeMarkup(tmp, ctx);
      const back = (st.effects || []).some(e => e.type === 'glass') ? '<rect width="64" height="44" fill="#FF8A3D"/><rect y="0" width="22" height="44" fill="#7B61FF"/><rect x="42" width="22" height="44" fill="#19C3B6"/>' : '';
      out = `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" aria-hidden="true"><defs>${ctx.defs.join('')}</defs>${back}${body}</svg>`;
    } catch (e) {
      const f = (st.fills || [])[0];
      out = `<span class="gs-fallback" style="background:${f && f.type === 'solid' ? esc(f.color) : '#ccc'}"></span>`;
    }
    prevCache.set(key, out);
    return out;
  };
  const chip = st => `<button type="button" class="gs-chip" data-gs="${esc(st.id)}" title="${esc(GS.label(st))}${st.builtin ? '' : ' — ' + esc(t('права кнопка: змінити'))}">${GS.preview(st)}<span>${esc(GS.label(st))}</span></button>`;

  // ---------- Design panel section ----------
  O.panels.extraSections.push(nodes => {
    if (!nodes.length) return '';
    const mine = GS.list();
    const cur = nodes.length === 1 && nodes[0].gstyle && GS.find(nodes[0].gstyle);
    return O.ph.sec('Стиль і ефекти', `${cur ? `<div class="gs-cur">${esc(t('Стиль'))}: <b>${esc(t(cur.name))}</b></div>` : ''}<div class="gs-grid">${mine.concat(GS.BUILTIN.filter((s, i, a) => a.findIndex(x => x.cat === s.cat) === i).map(s => Object.assign({ builtin: true }, s))).slice(0, 18).map(chip).join('')}</div>
      <div class="row"><button type="button" class="btn" data-gsa="save">${esc(t('Зберегти стиль…'))}</button><button type="button" class="btn" data-gsa="lib">${esc(t('Усі стилі…'))}</button></div>`,
      O.ph.ib('data-gsa="save"', 'plus', 'Зберегти стиль і ефекти виділеного'));
  });
  const menuFor = (id, x, y) => {
    const st = GS.find(id);
    if (!st) return;
    const items = [{ id: 'apply', label: 'Застосувати' }];
    if (!st.builtin) items.push({ id: 'upd', label: 'Оновити з виділеного' }, { id: 'ren', label: 'Перейменувати…' }, '-', { id: 'del', label: 'Видалити стиль' });
    ui.menu(items, x, y, { onPick: a => { if (a === 'apply') GS.apply(id); if (a === 'upd') GS.update(id); if (a === 'ren') GS.rename(id); if (a === 'del') { GS.remove(id); O.panels.refresh(true); } } });
  };
  document.addEventListener('click', e => {
    const c = e.target.closest && e.target.closest('[data-gs]');
    if (c && !c.closest('.gs-lib')) { e.stopPropagation(); GS.apply(c.dataset.gs); return; }
    const a = e.target.closest && e.target.closest('[data-gsa]');
    if (!a) return;
    e.stopPropagation();
    if (a.dataset.gsa === 'save') GS.save();
    if (a.dataset.gsa === 'lib') GS.library();
  }, true);
  document.addEventListener('contextmenu', e => {
    const c = e.target.closest && e.target.closest('[data-gs]');
    if (!c) return;
    e.preventDefault(); e.stopPropagation();
    menuFor(c.dataset.gs, e.clientX, e.clientY);
  }, true);
  O.on('gstyles', () => { if (O.panels.refresh) O.panels.refresh(true); });

  // ---------- library dialog ----------
  GS.library = () => {
    // 1000 styles: filter by category, colour and words; previews are drawn 120 at a time while scrolling
    let cat = 'all', color = 'all', q = '', shown = 0;
    const PAGE = 120;
    const list = () => GS.BUILTIN.filter(s => (cat === 'all' || s.cat === cat) && (color === 'all' || s.color === color) && (!q || GS.label(s).toLowerCase().includes(q)));
    const render = () => { shown = PAGE; const L = list(); return `<div class="gs-lib">${cat === 'all' && color === 'all' && !q ? `<h4>${esc(t('Мої стилі'))}</h4><div class="gs-grid big">${GS.list().map(chip).join('') || `<div class="as-empty">${esc(t('Ще немає. Виділіть об’єкт і натисніть «Зберегти стиль…»'))}</div>`}</div>` : ''}<h4>${esc(t('Готові стилі'))} · ${L.length}</h4><div class="gs-grid big gs-all">${L.slice(0, PAGE).map(s => chip(Object.assign({ builtin: true }, s))).join('')}</div></div>`; };
    const more = () => { const L = list(), g = d.el.querySelector('.gs-all'); if (!g || shown >= L.length) return; g.insertAdjacentHTML('beforeend', L.slice(shown, shown + PAGE).map(s => chip(Object.assign({ builtin: true }, s))).join('')); shown += PAGE; };
    const colorChips = `<div class="gs-colors"><button type="button" data-gscol="all" class="on" title="${esc(t('Усі кольори'))}">${esc(t('Усі'))}</button>${GS.COLORS.map(([id, n, c]) => `<button type="button" data-gscol="${id}" title="${esc(t(n))}" aria-label="${esc(t(n))}" style="--c:${c}"></button>`).join('')}</div>`;
    const d = ui.dialog({
      title: 'Стилі та ефекти',
      body: `<div class="dlg-text small">${esc(t('{n} готових стилів. Клік — застосувати до виділеного, права кнопка — оновити, перейменувати або видалити. Стилі доступні в усіх проєктах.', { n: GS.BUILTIN.length }))}</div><input type="search" class="gs-q" placeholder="${esc(t('Пошук стилів: неон, золото, кнопка…'))}" aria-label="${esc(t('Пошук стилів'))}"><div class="bg-chips gs-cats">${[['all', 'Усі']].concat(GS.CATS.map(c => [c, c])).map(([k, l]) => `<button type="button" data-gsc="${esc(k)}" class="${k === cat ? 'on' : ''}">${esc(t(l))}</button>`).join('')}</div>${colorChips}<div class="gs-wrap">${render()}</div>`,
      buttons: [{ id: 'imp', label: 'Імпортувати…' }, { id: 'exp', label: 'Експорт…' }, { id: 'save', label: 'Зберегти стиль виділеного…' }, { id: 'ok', label: 'Готово', primary: true }],
      onOk: (v, b) => { if (b === 'imp') GS.import(); if (b === 'exp') GS.export(); if (b === 'save') GS.save(); }
    });
    d.el.querySelector('.dlg').classList.add('wide');
    d.el.addEventListener('click', e => {
      const k = e.target.closest('[data-gsc]');
      if (k) { e.preventDefault(); cat = k.dataset.gsc; d.el.querySelectorAll('[data-gsc]').forEach(x => x.classList.toggle('on', x === k)); d.el.querySelector('.gs-wrap').innerHTML = render(); return; }
      const cc = e.target.closest('[data-gscol]');
      if (cc) { e.preventDefault(); color = cc.dataset.gscol; d.el.querySelectorAll('[data-gscol]').forEach(x => x.classList.toggle('on', x === cc)); d.el.querySelector('.gs-wrap').innerHTML = render(); return; }
      const c = e.target.closest('[data-gs]'); if (c) { e.stopPropagation(); GS.apply(c.dataset.gs); }
    });
    d.el.querySelector('.gs-q').addEventListener('input', O.debounce(e => { q = e.target.value.trim().toLowerCase(); d.el.querySelector('.gs-wrap').innerHTML = render(); }, 200));
    d.el.querySelector('.gs-wrap').addEventListener('scroll', e => { const w = e.target; if (w.scrollTop + w.clientHeight > w.scrollHeight - 300) more(); });
    const upd = () => { const w = d.el.querySelector('.gs-wrap'); if (w && w.isConnected) w.innerHTML = render(); };
    O.on('gstyles', upd);
  };

  O.cmd('saveGStyle', 'Зберегти стиль і ефекти…', () => GS.save(), { group: 'Ефект', keys: ['Ctrl+Alt+Shift+S'] });
  O.cmd('gstyleLib', 'Стилі та ефекти…', () => GS.library(), { group: 'Ефект' });
  const fx = O.MENUS.find(m => m[0] === 'Ефект');
  if (fx) fx[1].unshift('gstyleLib', 'saveGStyle', '-');
})();
