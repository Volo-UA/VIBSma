'use strict';
/* VIBSma — fonts: the whole Google Fonts catalogue (loaded on demand), font picker,
   @font-face embedding for exports, font files (TTF) for "Create outlines" */
(function () {
  const O = window.O, S = O.state, model = O.model;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const F = O.fonts = {};
  F.CATS = { s: 'Без засічок', r: 'Із засічками', d: 'Декоративні', h: 'Рукописні', m: 'Моноширинні' };
  F.SYSTEM = ['Arial', 'Helvetica', 'Segoe UI', 'Verdana', 'Tahoma', 'Trebuchet MS', 'Georgia', 'Times New Roman', 'Palatino Linotype', 'Garamond', 'Courier New', 'Consolas', 'Impact', 'Comic Sans MS', 'Calibri', 'Cambria', 'system-ui', 'serif', 'sans-serif', 'monospace'];

  // ---------- catalogue ----------
  // style token: "4" = 400 normal, "7i" = 700 italic ("0.01" = weight 1, "10" = 1000)
  const tok = s => ({ w: O.clamp(Math.round(parseFloat(s) * 100), 1, 1000), i: /i$/.test(s) ? 1 : 0 });
  F.google = String(O.GFONTS_RAW || '').split('\n').filter(Boolean).map((row, rank) => {
    const [family, cat, ws, axes, sub] = row.split('|');
    const styles = (ws || '4').split(',').filter(Boolean).map(tok).sort((a, b) => a.i - b.i || a.w - b.w);
    const [vmin, vmax] = axes ? axes.split('-').map(Number) : [0, 0];
    return { family, cat: cat || 's', styles, vmin, vmax, cyr: /c/.test(sub || ''), sub: sub || '', rank };
  });
  const byName = new Map(F.google.map(g => [g.family.toLowerCase(), g]));
  // families published after this catalogue was built (fetched with «Update catalogue», kept in the browser)
  const CAT = { 'sans-serif': 's', serif: 'r', display: 'd', handwriting: 'h', monospace: 'm' };
  const addExtra = (list) => {
    let added = 0;
    for (const x of list) {
      if (!x || !x.family || byName.has(x.family.toLowerCase())) continue;
      const g = { family: x.family, cat: x.cat || 's', styles: (x.styles || [{ w: 400, i: 0 }]), vmin: 0, vmax: 0, cyr: !!x.cyr, sub: x.sub || '', rank: F.google.length };
      F.google.push(g); byName.set(g.family.toLowerCase(), g); added++;
    }
    return added;
  };
  addExtra(O.ls.get('gfExtra', []));
  F.refreshCatalogue = async () => {
    const r = await fetch('https://api.fontsource.org/v1/fonts?type=google');
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const data = await r.json();
    const list = data.map(f => ({
      family: f.family, cat: CAT[f.category] || 's',
      styles: (f.weights || [400]).flatMap(w => (f.styles || ['normal']).map(s => ({ w: +w, i: s === 'italic' ? 1 : 0 }))).sort((a, b) => a.i - b.i || a.w - b.w),
      cyr: (f.subsets || []).includes('cyrillic'), sub: (f.subsets || []).map(s => ({ cyrillic: 'c', 'cyrillic-ext': 'e', greek: 'g', 'latin-ext': 'l', vietnamese: 'v' }[s] || '')).join('')
    }));
    const fresh = list.filter(x => !byName.has(x.family.toLowerCase()));
    const n = addExtra(fresh);
    O.ls.set('gfExtra', O.ls.get('gfExtra', []).concat(fresh));
    return { added: n, total: F.google.length };
  };
  const clean = fam => String(fam || '').replace(/["']/g, '').split(',')[0].trim();
  F.get = fam => byName.get(clean(fam).toLowerCase());
  F.isGoogle = fam => !!F.get(fam);
  // nearest available style of a family
  F.nearest = (g, weight, italic) => {
    const want = italic ? 1 : 0;
    let list = g.styles.filter(s => s.i === want);
    if (!list.length) list = g.styles;
    let best = list[0];
    for (const s of list) if (Math.abs(s.w - weight) < Math.abs(best.w - weight)) best = s;
    return best;
  };
  const famParam = g => g.family.replace(/ /g, '+');
  const styleSpec = styles => {
    const it = styles.some(s => s.i);
    return it ? 'ital,wght@' + styles.map(s => s.i + ',' + s.w).join(';') : 'wght@' + styles.map(s => s.w).join(';');
  };
  F.cssURL = g => `https://fonts.googleapis.com/css2?family=${famParam(g)}:${styleSpec(g.styles)}&display=swap`;
  F.cssURLs = families => {
    const gs = families.map(F.get).filter(Boolean);
    return gs.length ? `https://fonts.googleapis.com/css2?${gs.map(g => 'family=' + famParam(g) + ':' + styleSpec(g.styles)).join('&')}&display=swap` : '';
  };

  // ---------- loading ----------
  const links = new Map();
  F.load = (fam, weight = 400, italic = false) => {
    const g = F.get(fam);
    if (!g) return Promise.resolve(false);
    let p = links.get(g.family);
    if (!p) {
      p = new Promise(res => {
        const l = document.createElement('link');
        l.rel = 'stylesheet'; l.href = F.cssURL(g); l.dataset.gfont = g.family;
        l.onload = () => res(true);
        l.onerror = () => { links.delete(g.family); l.remove(); res(false); };
        document.head.appendChild(l);
      });
      links.set(g.family, p);
    }
    const st = F.nearest(g, weight, italic);
    return p.then(ok => ok && document.fonts ? document.fonts.load(`${st.i ? 'italic ' : ''}${st.w} 24px "${g.family}"`, 'AaЯяЇї').then(() => true, () => false) : ok);
  };
  F.isLoaded = fam => { const g = F.get(fam); return !!(g && links.has(g.family)); };
  const textNodes = (nodes, out = [], seen = new Set()) => {
    for (const n of nodes) {
      if (!n || seen.has(n.id)) continue;
      seen.add(n.id);
      if (n.type === 'text') out.push(n);
      if (n.type === 'instance') { const c = model.get(n.ref); if (c) textNodes([c], out, seen); }
      if (n.children) textNodes(n.children, out, seen);
    }
    return out;
  };
  F.textNodes = textNodes;
  F.ensure = nodes => {
    const jobs = textNodes(nodes).filter(n => F.isGoogle(n.font)).map(n => F.load(n.font, n.weight || 400, !!n.italic));
    if (!jobs.length) return Promise.resolve();
    return Promise.all(jobs).then(() => { O.text.reset(); O.requestRender(); O.emit('fonts'); });
  };
  F.ensureDoc = () => { if (S.doc) return F.ensure(S.doc.pages.reduce((a, p) => a.concat(p.children), [])); return Promise.resolve(); };
  O.on('docload', () => F.ensureDoc());
  // any font finishing loading changes text metrics: drop cached line breaks and redraw
  if (document.fonts && document.fonts.addEventListener) {
    const again = O.debounce(() => { if (!S.doc) return; O.text.reset(); O.requestRender(); O.emit('change-soft'); }, 60);
    document.fonts.addEventListener('loadingdone', again);
  }

  // ---------- embedding for export (SVG / PNG / JPG / PDF keep their fonts) ----------
  const subsetCache = new Map();
  const fetchText = async url => { const r = await fetch(url); if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); };
  const inlineURLs = async css => {
    const urls = Array.from(new Set(Array.from(css.matchAll(/url\((https:[^)\s]+)\)/g)).map(m => m[1])));
    for (const u of urls) {
      const r = await fetch(u);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      css = css.split(u).join(await O.io.blobToData(await r.blob()));
    }
    return css;
  };
  const subsetCSS = (g, st, text) => {
    const key = g.family + '|' + st.w + '|' + st.i + '|' + text;
    if (!subsetCache.has(key)) {
      const url = `https://fonts.googleapis.com/css2?family=${famParam(g)}:${st.i ? 'ital,wght@1,' + st.w : 'wght@' + st.w}&text=${encodeURIComponent(text)}`;
      subsetCache.set(key, fetchText(url).then(inlineURLs).catch(e => { subsetCache.delete(key); console.warn('font embed', g.family, e); return ''; }));
    }
    return subsetCache.get(key);
  };
  F.embedCSS = async nodes => {
    const want = new Map();
    const custom = new Set();
    for (const n of textNodes(nodes)) {
      if (n.visible === false) continue;
      const fam = clean(n.font);
      if ((S.doc.fonts || []).some(f => f.family === fam)) { custom.add(fam); continue; }
      const g = F.get(fam);
      if (!g) continue;
      const st = F.nearest(g, n.weight || 400, !!n.italic);
      const k = g.family + '|' + st.w + '|' + st.i;
      if (!want.has(k)) want.set(k, { g, st, chars: new Set() });
      for (const ch of O.text.content(n) + ' ') want.get(k).chars.add(ch);
    }
    const parts = [];
    for (const fam of custom) for (const f of (S.doc.fonts || []).filter(x => x.family === fam)) parts.push(`@font-face{font-family:"${fam.replace(/"/g, '')}";src:url(${f.data});}`);
    const jobs = Array.from(want.values()).map(({ g, st, chars }) => subsetCSS(g, st, Array.from(chars).filter(c => c !== '\n').sort().join('')));
    return parts.concat(await Promise.all(jobs)).join('\n');
  };
  // <link> tags for HTML export
  F.linkTags = nodes => {
    const fams = Array.from(new Set(textNodes(nodes).map(n => clean(n.font)).filter(F.isGoogle)));
    const url = F.cssURLs(fams);
    return url ? `<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n<link rel="stylesheet" href="${url.replace(/&/g, '&amp;')}">` : '';
  };

  // open fonts with the same metrics as common system fonts (used for outlines when the system file is not readable)
  const CLONES = { arial: 'Arimo', helvetica: 'Arimo', 'helvetica neue': 'Arimo', 'liberation sans': 'Arimo', 'times new roman': 'Tinos', times: 'Tinos', 'liberation serif': 'Tinos', 'courier new': 'Cousine', courier: 'Cousine', calibri: 'Carlito', cambria: 'Caladea', georgia: 'Gelasio', 'segoe ui': 'Noto Sans', tahoma: 'PT Sans', verdana: 'PT Sans', 'trebuchet ms': 'Fira Sans', 'palatino linotype': 'Tinos', garamond: 'EB Garamond', consolas: 'Inconsolata', 'comic sans ms': 'Comic Neue', impact: 'Anton', 'system-ui': 'Noto Sans', 'sans-serif': 'Arimo', serif: 'Tinos', monospace: 'Cousine' };
  F.cloneOf = fam => { const g = CLONES[clean(fam).toLowerCase()]; return g && F.get(g) ? g : null; };

  // ---------- font files for outlines (opentype.js needs TTF/OTF/WOFF) ----------
  const ttfCache = new Map();
  // [fontsource subset, catalogue flag, characters that need it]
  const SUBSETS = [['cyrillic', 'c', /[Ѐ-џҐ-ґҰ-ұ№]/], ['cyrillic-ext', 'e', /[Ѡ-ҏҒ-үҲ-ԯᲀ-᲏ⷠ-ⷿꙀ-ꚟ]/], ['greek', 'g', /[Ͱ-Ͽ]/], ['latin-ext', 'l', /[Ā-ɏḀ-ẟỲ-ỿ₠-₫₭-⃏]/], ['vietnamese', 'v', /[Ă-ăĐ-đĨ-ĩŨ-ũƠ-ơƯ-ưẠ-ỹ₫]/]];
  F.otFonts = async (fam, weight, italic, text) => {
    const g = F.get(fam);
    if (!g || !window.opentype) return null;
    const st = F.nearest(g, weight || 400, !!italic);
    const id = g.family.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const subsets = ['latin'];
    for (const [name, flag, re] of SUBSETS) if (re.test(text) && g.sub.includes(flag)) subsets.unshift(name);
    const fonts = await Promise.all(subsets.map(sub => {
      const url = `https://cdn.jsdelivr.net/fontsource/fonts/${id}@latest/${sub}-${st.w}-${st.i ? 'italic' : 'normal'}.ttf`;
      if (!ttfCache.has(url)) ttfCache.set(url, fetch(url).then(r => (r.ok ? r.arrayBuffer() : null)).then(b => (b ? window.opentype.parse(b) : null)).catch(() => null));
      return ttfCache.get(url);
    }));
    const ok = fonts.filter(Boolean);
    return ok.length ? ok : null;
  };

  // ---------- picker ----------
  let pickerEl = null;
  const previewDone = new Set();
  let previewStyle = null;
  const previewQueue = [];
  let previewBusy = false;
  const firstStyle = g => g.styles.find(s => !s.i && s.w === 400) || g.styles.find(s => !s.i) || g.styles[0];
  const pumpPreviews = async () => {
    if (previewBusy || !previewQueue.length) return;
    previewBusy = true;
    const batch = previewQueue.splice(0, 24);
    const text = Array.from(new Set(batch.map(g => g.family).join('').split(''))).sort().join('');
    const spec = g => { const s = firstStyle(g); return famParam(g) + (s.i ? ':ital,wght@1,' + s.w : s.w !== 400 ? ':wght@' + s.w : ''); };
    const fetchCSS = gs => fetchText(`https://fonts.googleapis.com/css2?${gs.map(g => 'family=' + spec(g)).join('&')}&text=${encodeURIComponent(text)}&display=block`);
    let css = '';
    try { css = await fetchCSS(batch); } catch (e) {
      // one unknown family fails the whole request: retry one by one
      for (const g of batch) { try { css += await fetchCSS([g]); } catch (e2) { /* skip */ } }
    }
    if (css) {
      if (!previewStyle) { previewStyle = document.createElement('style'); previewStyle.id = 'gf-previews'; document.head.appendChild(previewStyle); }
      previewStyle.textContent += css.replace(/font-family:\s*'([^']+)'/g, (m, f) => `font-family: 'gfp ${f}'`);
    }
    previewBusy = false;
    pumpPreviews();
  };
  const wantPreview = g => { if (previewDone.has(g.family)) return; previewDone.add(g.family); previewQueue.push(g); pumpPreviews(); };

  F.closePicker = () => {
    if (!pickerEl) return;
    pickerEl.remove(); pickerEl = null;
    document.removeEventListener('pointerdown', outside, true);
  };
  let anchorEl = null;
  const outside = e => { if (pickerEl && !pickerEl.contains(e.target) && !(anchorEl && anchorEl.contains(e.target))) F.closePicker(); };
  O.on('lang', () => F.closePicker());

  F.docFamilies = () => {
    const out = new Set();
    if (S.doc) textNodes(S.doc.pages.reduce((a, p) => a.concat(p.children), [])).forEach(n => out.add(clean(n.font)));
    return Array.from(out).filter(Boolean).sort();
  };

  F.picker = (anchor, current, onPick) => {
    F.closePicker();
    anchorEl = anchor;
    const st = { q: '', cat: O.ls.get('fpCat', 'all'), cyr: O.ls.get('fpCyr', O.lang === 'uk' || O.lang === 'ru'), limit: 80, hi: -1, items: [] };
    const el = pickerEl = O.h(`<div class="fpick" role="dialog" aria-label="${esc(t('Шрифти'))}">
      <div class="fp-top"><input type="search" class="fp-q" placeholder="${esc(t('Пошук серед {n} шрифтів', { n: F.google.length + F.SYSTEM.length }))}" aria-label="${esc(t('Пошук шрифту'))}" spellcheck="false" autocomplete="off"><button type="button" class="ib" data-a="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 14)}</button></div>
      <div class="fp-cats" role="group" aria-label="${esc(t('Категорія'))}">${[['all', 'Усі']].concat(Object.entries(F.CATS)).map(([k, l]) => `<button type="button" data-cat="${k}" class="${st.cat === k ? 'on' : ''}">${esc(t(l))}</button>`).join('')}</div>
      <label class="chk fp-cyr"><input type="checkbox" data-a="cyr"${st.cyr ? ' checked' : ''}><span>${esc(t('Лише з кирилицею'))}</span></label>
      <div class="fp-list" role="listbox" tabindex="-1" aria-label="${esc(t('Шрифти'))}"></div>
      <div class="fp-foot">${esc(t('Google Fonts завантажуються з інтернету, коли ви їх обираєте'))} · <button type="button" class="link" data-a="refresh">${esc(t('Оновити каталог'))}</button></div></div>`);
    document.body.appendChild(el);
    const r = anchor.getBoundingClientRect();
    const w = 300;
    let x = r.left - w - 12;
    if (x < 8) x = Math.min(window.innerWidth - w - 8, r.right + 12);
    el.style.left = Math.max(8, x) + 'px';
    el.style.top = Math.max(8, Math.min(window.innerHeight - 520, r.top - 60)) + 'px';
    const list = el.querySelector('.fp-list');
    const q = el.querySelector('.fp-q');
    const cur = clean(current);
    const build = () => {
      const qq = st.q.trim().toLowerCase();
      const match = f => !qq || f.toLowerCase().includes(qq);
      const items = [];
      const head = label => items.push({ head: label });
      const docF = F.docFamilies().filter(match);
      const up = (S.doc && S.doc.fonts ? Array.from(new Set(S.doc.fonts.map(f => f.family))) : []).filter(match);
      const sys = Array.from(new Set(F.SYSTEM.concat(O.io.localFonts || []))).filter(f => match(f) && !F.isGoogle(f));
      const goo = F.google.filter(g => match(g.family) && (st.cat === 'all' || g.cat === st.cat) && (!st.cyr || g.cyr));
      if (st.cat === 'all') {
        if (docF.length) { head(t('У документі')); docF.forEach(f => items.push({ fam: f, src: F.isGoogle(f) ? 'g' : 's' })); }
        if (up.length) { head(t('Завантажені')); up.forEach(f => items.push({ fam: f, src: 'u' })); }
        if (sys.length) { head(t('Системні')); sys.forEach(f => items.push({ fam: f, src: 's' })); }
      }
      head(t('Google Fonts') + ' · ' + goo.length);
      goo.forEach(g => items.push({ fam: g.family, src: 'g', g }));
      st.items = items;
      render();
    };
    const row = (it, i) => {
      if (it.head) return `<div class="fp-h">${esc(it.head)}</div>`;
      const g = it.g || F.get(it.fam);
      const ff = it.src === 'g' ? `'gfp ${it.fam}', '${it.fam}', var(--font)` : `'${it.fam}', var(--font)`;
      return `<button type="button" class="fp-row${it.fam.toLowerCase() === cur.toLowerCase() ? ' cur' : ''}${i === st.hi ? ' hi' : ''}" role="option" data-i="${i}" data-fam="${esc(it.fam)}" aria-selected="${it.fam.toLowerCase() === cur.toLowerCase()}"><span class="fp-n" style="font-family:${esc(ff)}">${esc(it.fam)}</span><em>${g ? esc(t(F.CATS[g.cat])) + (g.cyr ? ' · ' + esc(t('Кир')) : '') : it.src === 'u' ? esc(t('файл')) : esc(t('система'))}</em></button>`;
    };
    const render = () => {
      const shown = st.items.slice(0, st.limit);
      list.innerHTML = shown.map(row).join('') + (st.items.length > st.limit ? `<div class="fp-more">${esc(t('Прокрутіть, щоб побачити більше'))}</div>` : '') + (st.items.filter(i => !i.head).length ? '' : `<div class="fp-empty">${esc(t('Нічого не знайдено'))}</div>`);
      shown.forEach(it => { if (it.src === 'g' && !it.head) { const g = it.g || F.get(it.fam); if (g) wantPreview(g); } });
    };
    const pick = fam => { if (!fam) return; O.ls.set('fpCat', st.cat); O.ls.set('fpCyr', st.cyr); F.closePicker(); onPick(fam); };
    list.addEventListener('scroll', () => {
      if (list.scrollTop + list.clientHeight > list.scrollHeight - 200 && st.limit < st.items.length) { st.limit += 80; const top = list.scrollTop; render(); list.scrollTop = top; }
    });
    el.addEventListener('click', e => {
      const c = e.target.closest('[data-cat]');
      if (c) { st.cat = c.dataset.cat; el.querySelectorAll('[data-cat]').forEach(b => b.classList.toggle('on', b === c)); st.limit = 80; st.hi = -1; build(); list.scrollTop = 0; return; }
      if (e.target.closest('[data-a="close"]')) { F.closePicker(); return; }
      const rf = e.target.closest('[data-a="refresh"]');
      if (rf) {
        rf.disabled = true; rf.textContent = t('Оновлення…');
        F.refreshCatalogue().then(r => { O.toast('Каталог Google Fonts: {total} шрифтів, нових: {added}', r); build(); q.placeholder = t('Пошук серед {n} шрифтів', { n: F.google.length + F.SYSTEM.length }); }, () => O.toast('Не вдалося оновити каталог. Перевірте інтернет.')).finally(() => { rf.disabled = false; rf.textContent = t('Оновити каталог'); });
        return;
      }
      const rw = e.target.closest('.fp-row');
      if (rw) pick(rw.dataset.fam);
    });
    el.addEventListener('change', e => { if (e.target.dataset.a === 'cyr') { st.cyr = e.target.checked; st.limit = 80; build(); } });
    q.addEventListener('input', () => { st.q = q.value; st.limit = 80; st.hi = -1; build(); list.scrollTop = 0; });
    el.addEventListener('keydown', e => {
      e.stopPropagation();
      const rows = st.items.map((it, i) => (it.head ? -1 : i)).filter(i => i >= 0);
      if (e.key === 'Escape') { F.closePicker(); return; }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const pos = rows.indexOf(st.hi);
        st.hi = rows[O.clamp(pos + (e.key === 'ArrowDown' ? 1 : -1), 0, rows.length - 1)];
        if (st.hi >= st.limit) st.limit = st.hi + 40;
        render();
        const h = list.querySelector('.fp-row.hi');
        if (h) h.scrollIntoView({ block: 'nearest' });
      }
      if (e.key === 'Enter') { e.preventDefault(); const it = st.items[st.hi] || st.items.find(i => !i.head); if (it) pick(it.fam); }
    });
    setTimeout(() => document.addEventListener('pointerdown', outside, true), 0);
    build();
    // scroll to the current font
    const curRow = list.querySelector('.fp-row.cur');
    if (curRow) curRow.scrollIntoView({ block: 'center' });
    q.focus();
    return el;
  };

  // apply a family to the selected texts (or just load it)
  F.apply = fam => {
    const texts = O.sel().filter(n => n.type === 'text');
    const g = F.get(fam);
    if (texts.length) {
      texts.forEach(n => {
        n.font = g ? g.family : fam;
        if (g) { const s = F.nearest(g, n.weight || 400, !!n.italic); n.weight = s.w; }
      });
      O.history.commit('Шрифт');
    }
    if (g) {
      O.toast('Завантаження шрифту «{name}»…', { name: g.family });
      F.load(g.family, texts[0] ? texts[0].weight : 400, texts[0] ? texts[0].italic : false).then(ok => {
        O.text.reset(); O.requestRender(); O.emit('fonts');
        O.toast(ok ? 'Шрифт «{name}» готовий' : 'Не вдалося завантажити «{name}». Перевірте інтернет.', { name: g.family });
      });
    }
  };
  O.cmd('googleFonts', 'Google Fonts…', () => {
    const a = O.$('[data-a="font-pick"]') || O.$('#btn-palette');
    const n = O.sel().find(x => x.type === 'text');
    F.picker(a, n ? n.font : 'Inter', F.apply);
  }, { group: 'Текст' });
  const ti = O.MENUS.find(m => m[0] === 'Текст');
  if (ti) ti[1].splice(ti[1].indexOf('uploadFont'), 0, 'googleFonts');
})();
