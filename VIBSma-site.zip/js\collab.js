'use strict';
/* VIBSma — collaboration (Figma: comments, real-time multiplayer).
   · Comments: pins on the canvas (attached to a frame so they move with it), threads with replies, resolve.
   · Real time: tabs of this browser with the same project sync automatically (BroadcastChannel);
     other computers connect peer-to-peer (WebRTC) by exchanging an invite code and an answer code
     through any messenger — no server. Changes travel per top-level layer; photos and clips are sent once.
     Everyone sees the others' cursors and selections. */
(function () {
  const O = window.O, M = O.M, R = O.R, model = O.model, S = O.state, ui = O.ui, V = O.view;
  const t = (s, v) => O.t(s, v), esc = O.esc, n_ = O.n;
  const CB = O.collab = {};
  const COLORS = ['#F24822', '#0D99FF', '#14AE5C', '#9747FF', '#FF3D9A', '#FFA629', '#00B4D8', '#E5484D'];
  const colorOf = s => { let h = 0; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; };
  CB.me = { id: O.uid(), name: O.ls.get('collabName', '') };
  CB.me.color = colorOf(CB.me.id);
  const myName = () => CB.me.name || t('Гість');
  const initials = s => String(s || '?').trim().split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase();
  const ago = ts => new Date(ts).toLocaleString(O.lang, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  CB.askName = () => new Promise(res => {
    if (CB.me.name) return res(CB.me.name);
    ui.dialog({ title: 'Як вас звати?', body: `<div class="dlg-text">${esc(t('Ім’я бачать інші учасники біля курсора та в коментарях.'))}</div>`, fields: [{ key: 'n', label: 'Ім’я', type: 'text', value: '' }], onOk: v => { CB.me.name = v.n.trim().slice(0, 40) || t('Гість'); O.ls.set('collabName', CB.me.name); res(CB.me.name); CB.hello(); }, onCancel: () => res(null) });
  });

  // ======================================================================
  // COMMENTS
  // ======================================================================
  const comments = pg => ((pg || model.page()).comments = (pg || model.page()).comments || []);
  const posOf = c => {
    if (c.frame) { const f = model.get(c.frame); if (f) { const b = model.worldBounds(f); return { x: b.x + c.rx, y: b.y + c.ry }; } }
    return { x: c.x, y: c.y };
  };
  const frameAt = p => { const list = model.page().children; for (let i = list.length - 1; i >= 0; i--) { const f = list[i]; if (f.type === 'frame' && f.visible !== false && V.containsWorld(f, p)) return f; } return null; };
  let layer = null, pop = null, openId = null;
  const ensureLayer = () => {
    if (layer && layer.isConnected) return layer;
    layer = O.h('<div id="cm-layer" aria-label="Коментарі"></div>');
    V.el.appendChild(layer);
    layer.addEventListener('click', e => { const p = e.target.closest('[data-cm]'); if (p) { e.stopPropagation(); CB.openThread(p.dataset.cm); } });
    layer.addEventListener('pointerdown', e => { if (e.target.closest('[data-cm]')) e.stopPropagation(); });
    return layer;
  };
  const drawPins = () => {
    if (!S.doc || !V.el) return;
    const L = ensureLayer();
    const show = S.settings.showComments !== false;
    const list = show ? comments().filter(c => !c.resolved || S.settings.showResolved) : [];
    L.innerHTML = list.map((c, i) => {
      const s = V.toScreen(posOf(c));
      return `<button type="button" class="cm-pin${c.resolved ? ' res' : ''}${openId === c.id ? ' on' : ''}" data-cm="${c.id}" style="left:${n_(s.x)}px;top:${n_(s.y)}px;--c:${c.color || '#0D99FF'}" title="${esc(c.author)}: ${esc(String(c.text).slice(0, 80))}"><span>${esc(initials(c.author))}</span>${(c.replies || []).length ? `<em>${c.replies.length + 1}</em>` : ''}</button>`;
    }).join('');
    if (pop && openId) placePop();
  };
  O.overlayHooks.push(() => { try { drawPins(); } catch (e) { console.error(e); } return ''; });
  const placePop = () => {
    const c = comments().find(x => x.id === openId) || (pop && pop._draft);
    if (!c || !pop) return;
    const s = V.toScreen(posOf(c)), r = V.el.getBoundingClientRect();
    const x = Math.min(window.innerWidth - 340, r.left + s.x + 22), y = Math.max(8, Math.min(window.innerHeight - pop.offsetHeight - 8, r.top + s.y - 20));
    pop.style.left = x + 'px'; pop.style.top = y + 'px';
  };
  CB.closeThread = () => { if (pop) pop.remove(); pop = null; openId = null; drawPins(); };
  const threadHTML = c => {
    const msgs = [{ author: c.author, color: c.color, text: c.text, time: c.time }].concat(c.replies || []);
    return `<div class="cm-h"><b>${esc(t('Коментар'))}</b><span class="sp"></span>${c.id ? `<button type="button" class="ib" data-cma="resolve" title="${esc(t(c.resolved ? 'Відкрити знову' : 'Позначити як розв’язаний'))}" aria-label="${esc(t('Розв’язати'))}">${O.icon('check', 15)}</button><button type="button" class="ib" data-cma="del" title="${esc(t('Видалити'))}" aria-label="${esc(t('Видалити'))}">${O.icon('trash', 15)}</button>` : ''}<button type="button" class="ib" data-cma="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 14)}</button></div>
      ${c.id ? `<div class="cm-msgs">${msgs.map(m => `<div class="cm-msg"><span class="cm-av" style="--c:${m.color || colorOf(m.author)}">${esc(initials(m.author))}</span><div><div class="cm-meta"><b>${esc(m.author)}</b> · ${esc(ago(m.time))}</div><div class="cm-text">${esc(m.text)}</div></div></div>`).join('')}</div>` : ''}
      <textarea class="cm-in" rows="2" placeholder="${esc(t(c.id ? 'Відповісти…' : 'Напишіть коментар… (@ім’я, Ctrl+Enter — надіслати)'))}"></textarea>
      <div class="cm-f"><span class="sp"></span><button type="button" class="btn primary" data-cma="send">${esc(t(c.id ? 'Відповісти' : 'Коментувати'))}</button></div>`;
  };
  CB.openThread = (id, draft) => {
    if (pop) pop.remove();
    const c = draft || comments().find(x => x.id === id);
    if (!c) return;
    openId = c.id || null;
    pop = O.h(`<div class="cm-pop" role="dialog" aria-label="${esc(t('Коментар'))}">${threadHTML(c)}</div>`);
    pop._draft = draft || null;
    document.body.appendChild(pop);
    placePop();
    const ta = pop.querySelector('textarea');
    setTimeout(() => ta.focus(), 0);
    ta.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) pop.querySelector('[data-cma="send"]').click(); if (e.key === 'Escape') CB.closeThread(); });
    pop.addEventListener('click', async e => {
      const b = e.target.closest('[data-cma]');
      if (!b) return;
      const a = b.dataset.cma;
      if (a === 'close') return CB.closeThread();
      if (a === 'send') {
        const text = ta.value.trim();
        if (!text) return;
        if (!(await CB.askName())) return;
        if (draft) {
          const nc = Object.assign({}, draft, { id: O.uid(), author: myName(), color: CB.me.color, text, time: Date.now(), replies: [] });
          comments().push(nc);
          O.history.commit('Коментар');
          CB.openThread(nc.id);
        } else {
          c.replies = (c.replies || []).concat([{ author: myName(), color: CB.me.color, text, time: Date.now() }]);
          O.history.commit('Відповідь');
          CB.openThread(c.id);
        }
        drawPins();
      }
      if (a === 'resolve') { c.resolved = !c.resolved; O.history.commit('Коментар'); CB.closeThread(); }
      if (a === 'del') { const pg = model.page(); pg.comments = comments().filter(x => x !== c); O.history.commit('Видалення коментаря'); CB.closeThread(); }
    });
    drawPins();
  };
  document.addEventListener('pointerdown', e => { if (pop && !pop.contains(e.target) && !e.target.closest('[data-cm]') && S.tool !== 'comment') CB.closeThread(); }, true);
  // comment tool: click on the canvas → new thread there
  O.tools.comment = {
    cursor: 'crosshair', noHandles: true, hideBox: true,
    activate() { S.settings.showComments = true; drawPins(); O.toast('Клацніть, щоб залишити коментар'); },
    deactivate() {},
    down(ev) {
      const f = frameAt(ev.p);
      const draft = f ? { frame: f.id, rx: ev.p.x - model.worldBounds(f).x, ry: ev.p.y - model.worldBounds(f).y } : { x: ev.p.x, y: ev.p.y };
      CB.openThread(null, draft);
    },
    move() {}, up() {}
  };
  ui.TOOLS.comment = { label: 'Коментар', key: 'Shift+C', icon: 'comment' };
  ui.TOOL_GROUPS.push(['comment']);
  O.cmd('tool:comment', 'Коментар', () => O.setTool('comment'), { keys: ['Shift+C'], group: 'Інструмент' });
  CB.listDialog = () => {
    const all = [];
    for (const pg of S.doc.pages) for (const c of pg.comments || []) all.push({ pg, c });
    all.sort((a, b) => (a.c.resolved - b.c.resolved) || (b.c.time - a.c.time));
    const d = ui.dialog({
      title: t('Коментарі') + ` · ${all.filter(x => !x.c.resolved).length}`,
      body: all.length ? `<div class="pf-list">${all.map((x, i) => `<button type="button" class="pf-it cm-li${x.c.resolved ? ' res' : ''}" data-ci="${i}"><b>${esc(x.c.author)} · ${esc(x.pg.name)}${x.c.resolved ? ' · ✓' : ''}</b><span>${esc(String(x.c.text).slice(0, 140))}${(x.c.replies || []).length ? ` (+${x.c.replies.length})` : ''}</span></button>`).join('')}</div>` : `<div class="dlg-text">${esc(t('Коментарів ще немає. Інструмент «Коментар» — Shift+C.'))}</div>`,
      fields: [{ key: 'res', label: 'Показувати розв’язані на полотні', type: 'checkbox', value: !!S.settings.showResolved }],
      buttons: [{ id: 'ok', label: 'Закрити', primary: true }],
      onOk: v => { S.settings.showResolved = v.res; O.saveSettings(); drawPins(); }
    });
    d.el.addEventListener('click', e => {
      const b = e.target.closest('[data-ci]');
      if (!b) return;
      const x = all[+b.dataset.ci];
      d.close();
      if (x.pg.id !== S.pageId) { S.pageId = x.pg.id; O.emit('page'); }
      const p = posOf(x.c);
      V.fit({ x: p.x - 300, y: p.y - 200, w: 600, h: 400 }, 40, 2);
      setTimeout(() => CB.openThread(x.c.id), 60);
    });
  };
  O.cmd('comments', 'Усі коментарі…', () => CB.listDialog(), { group: 'Спільна робота' });
  O.cmd('showComments', 'Показувати коментарі', () => { S.settings.showComments = S.settings.showComments === false; O.saveSettings(); drawPins(); }, { group: 'Вигляд', check: () => S.settings.showComments !== false });

  // ======================================================================
  // REAL TIME
  // ======================================================================
  const links = new Set();          // transport links: { kind, send(str), close() }
  const peers = new Map();          // people: id → { id, name, color, cursor, page, sel, link, seen }
  const seen = new Set();
  let applying = false;
  CB.peers = () => Array.from(peers.values());
  CB.links = () => Array.from(links);
  const post = (msg, except) => {
    msg.mid = msg.mid || O.uid(); msg.from = msg.from || CB.me.id;
    seen.add(msg.mid);
    const s = JSON.stringify(msg);
    for (const l of links) if (l !== except) { try { l.send(s); } catch (e) { console.warn(e); } }
  };
  CB.post = post;
  // other transports (the cloud room of a share link) plug in here
  CB.attachLink = link => { links.add(link); shadow = snapshot(); CB.hello(); renderBar(); };
  CB.detachLink = link => { links.delete(link); peers.forEach((p, id) => { if (p.link === link) peers.delete(id); }); renderBar(); O.requestOverlay(); };
  const receive = (str, link) => {
    let msg;
    try { msg = typeof str === 'string' ? JSON.parse(str) : str; } catch (e) { return; }
    if (!msg || !msg.mid || seen.has(msg.mid) || msg.from === CB.me.id) return;
    seen.add(msg.mid);
    if (seen.size > 5000) seen.clear();
    // flood to the other links (host relays between guests); duplicates are dropped by message id
    const s = JSON.stringify(msg);
    for (const l of links) if (l !== link) { try { l.send(s); } catch (e) { /* closed */ } }
    try { handle(msg, link); } catch (e) { console.error(e); }
  };
  CB.receive = receive;

  // ---------- document diff per top-level layer ----------
  let shadow = null;
  const metaOf = o => { const m = {}; for (const k of Object.keys(o)) if (k !== 'children') m[k] = o[k]; return JSON.stringify(m); };
  const docMeta = () => { const m = {}; for (const k of Object.keys(S.doc)) if (k !== 'pages' && k !== 'assets' && k !== 'savedAt') m[k] = S.doc[k]; return m; };
  const snapshot = () => {
    const pages = new Map();
    for (const pg of S.doc.pages) pages.set(pg.id, { meta: metaOf(pg), nodes: new Map(pg.children.map(n => [n.id, JSON.stringify(n)])), order: pg.children.map(n => n.id).join(',') });
    return { pages, order: S.doc.pages.map(p => p.id).join(','), meta: JSON.stringify(docMeta()), assets: new Set(Object.keys(S.doc.assets || {})) };
  };
  const diff = () => {
    if (!shadow) { shadow = snapshot(); return null; }
    const out = { t: 'ops', pages: [], newAssets: [] };
    for (const pg of S.doc.pages) {
      const old = shadow.pages.get(pg.id);
      const op = { id: pg.id, upserts: [], deletes: [] };
      const mm = metaOf(pg);
      if (!old || old.meta !== mm) op.meta = JSON.parse(mm);
      const ids = new Set();
      for (const n of pg.children) { ids.add(n.id); const j = JSON.stringify(n); if (!old || old.nodes.get(n.id) !== j) op.upserts.push(n); }
      if (old) for (const id of old.nodes.keys()) if (!ids.has(id)) op.deletes.push(id);
      const ord = pg.children.map(n => n.id).join(',');
      if (!old || old.order !== ord) op.order = pg.children.map(n => n.id);
      if (op.meta || op.upserts.length || op.deletes.length || op.order) out.pages.push(op);
    }
    const order = S.doc.pages.map(p => p.id).join(',');
    if (order !== shadow.order) out.pageOrder = S.doc.pages.map(p => p.id);
    const meta = JSON.stringify(docMeta());
    if (meta !== shadow.meta) out.meta = JSON.parse(meta);
    for (const id of Object.keys(S.doc.assets || {})) if (!shadow.assets.has(id)) out.newAssets.push(id);
    shadow = snapshot();
    return out.pages.length || out.pageOrder || out.meta || out.newAssets.length ? out : null;
  };
  const sendAssets = ids => { for (const id of ids) { const a = S.doc.assets[id]; if (a) post({ t: 'asset', id, a }); } };
  const broadcastChanges = () => {
    if (applying || !links.size || !S.doc) { if (S.doc && !links.size) shadow = null; return; }
    const ops = diff();
    if (!ops) return;
    if (ops.newAssets.length) sendAssets(ops.newAssets);
    delete ops.newAssets;
    post(ops);
  };
  {
    const H = O.history;
    for (const k of ['commit', 'undo', 'redo']) {
      const orig = H[k];
      H[k] = function (...a) { const r = orig.apply(this, a); try { broadcastChanges(); } catch (e) { console.error(e); } return r; };
    }
  }
  const applyOps = msg => {
    applying = true;
    try {
      if (msg.meta) { for (const [k, v] of Object.entries(msg.meta)) S.doc[k] = v; }
      for (const op of msg.pages || []) {
        let pg = S.doc.pages.find(p => p.id === op.id);
        if (!pg) { pg = Object.assign({ id: op.id, children: [], guides: [] }, op.meta || {}); pg.children = []; S.doc.pages.push(pg); }
        else if (op.meta) { for (const k of Object.keys(pg)) if (k !== 'children' && k !== 'id' && !(k in op.meta)) delete pg[k]; Object.assign(pg, op.meta); }
        for (const n of op.upserts || []) { const i = pg.children.findIndex(c => c.id === n.id); if (i >= 0) pg.children[i] = n; else pg.children.push(n); }
        if (op.deletes && op.deletes.length) { const del = new Set(op.deletes); pg.children = pg.children.filter(c => !del.has(c.id)); }
        if (op.order) { const pos = new Map(op.order.map((id, i) => [id, i])); pg.children.sort((a, b) => (pos.has(a.id) ? pos.get(a.id) : 1e9) - (pos.has(b.id) ? pos.get(b.id) : 1e9)); }
      }
      if (msg.pageOrder) {
        const keep = new Set(msg.pageOrder);
        S.doc.pages = S.doc.pages.filter(p => keep.has(p.id));
        const pos = new Map(msg.pageOrder.map((id, i) => [id, i]));
        S.doc.pages.sort((a, b) => pos.get(a.id) - pos.get(b.id));
        if (!S.doc.pages.some(p => p.id === S.pageId)) S.pageId = S.doc.pages[0].id;
      }
      model.reindex();
      S.sel = S.sel.filter(id => model.exists(id));
      if (O.text && O.text.reset) O.text.reset();
      O.history.commit('Зміни учасника');
      shadow = snapshot();
      O.emit('selection');
    } finally { applying = false; }
  };
  const loadFull = async msg => {
    applying = true;
    try {
      const doc = msg.doc;
      doc.name = doc.name || t('Спільний проєкт');
      if (O.projects && !O.projects.disabled) await O.projects.createFrom(doc); else model.load(doc);
      shadow = snapshot();
      O.toast('Ви приєдналися до проєкту «{name}»', { name: doc.name });
    } finally { applying = false; }
  };

  // ---------- messages ----------
  const handle = (msg, link) => {
    const p = msg.from && msg.t !== 'bye' ? (peers.get(msg.from) || (peers.set(msg.from, { id: msg.from, name: '…', color: colorOf(msg.from), link }), peers.get(msg.from))) : null;
    if (p) p.seen = Date.now();
    switch (msg.t) {
      case 'hello':
        Object.assign(p, { name: msg.name, color: msg.color, page: msg.page });
        if (!msg.re) CB.hello(true);
        renderBar();
        break;
      case 'bye': peers.delete(msg.from); renderBar(); O.requestOverlay(); break;
      case 'cur': Object.assign(p, { cursor: { x: msg.x, y: msg.y }, page: msg.page }); O.requestOverlay(); break;
      case 'sel': Object.assign(p, { sel: msg.ids, page: msg.page }); O.requestOverlay(); break;
      case 'asset': if (S.doc && !S.doc.assets[msg.id]) S.doc.assets[msg.id] = msg.a; break;
      case 'ops': if (S.doc) applyOps(msg); break;
      case 'full': if (msg.to === CB.me.id) loadFull(msg); break;
      case 'need-full': if (msg.to === CB.me.id) sendFull(msg.from); break;
    }
  };
  const sendFull = to => {
    for (const id of Object.keys(S.doc.assets || {})) post({ t: 'asset', id, a: S.doc.assets[id] });
    const doc = Object.assign({}, S.doc); delete doc.assets;
    doc.assets = {};
    for (const [id, a] of Object.entries(S.doc.assets || {})) { const m = Object.assign({}, a); doc.assets[id] = m; }
    post({ t: 'full', to, doc: JSON.parse(JSON.stringify(Object.assign({}, S.doc))) });
    shadow = snapshot();
  };
  CB.hello = re => { if (links.size) post({ t: 'hello', name: myName(), color: CB.me.color, page: S.pageId, re: !!re }); };
  window.addEventListener('beforeunload', () => { try { post({ t: 'bye' }); } catch (e) { /* closing */ } });
  // drop people that went silent (closed laptop)
  setInterval(() => { const now = Date.now(); let ch = false; for (const [id, p] of peers) if (now - (p.seen || 0) > 60000) { peers.delete(id); ch = true; } if (ch) { renderBar(); O.requestOverlay(); } if (links.size) post({ t: 'hello', name: myName(), color: CB.me.color, page: S.pageId, re: true }); }, 20000);

  // ---------- presence: cursors and selections ----------
  let lastCur = 0;
  const onMove = e => {
    if (!links.size || !S.doc) return;
    const now = performance.now();
    if (now - lastCur < 45) return;
    lastCur = now;
    const p = V.toWorld(V.local(e));
    post({ t: 'cur', x: Math.round(p.x * 10) / 10, y: Math.round(p.y * 10) / 10, page: S.pageId });
  };
  O.on('selection', () => { if (links.size && !applying) post({ t: 'sel', ids: S.sel.slice(0, 200), page: S.pageId }); });
  O.overlayHooks.push(Vm => {
    let s = '';
    for (const p of peers.values()) {
      if (p.page !== S.pageId) continue;
      for (const id of p.sel || []) { const n = model.get(id); if (n && model.pageOf(n) === model.page()) s += `<g fill="none" stroke="${p.color}" stroke-width="2" pointer-events="none">${O.outlineOf(n, M.mul(Vm, model.worldMatrix(n)))}</g>`; }
      if (p.cursor) {
        const c = M.apply(Vm, p.cursor);
        const w = String(p.name).length * 6.6 + 14;
        s += `<g pointer-events="none" transform="translate(${n_(c.x)} ${n_(c.y)})"><path d="M0 0L0 15L4.2 11.2L7 17.5L9.6 16.4L6.9 10.2L12.3 10.2Z" fill="${p.color}" stroke="#fff" stroke-width="1.2"/><rect x="12" y="16" width="${n_(w)}" height="18" rx="9" fill="${p.color}"/><text x="${n_(12 + w / 2)}" y="29" fill="#fff" font-size="11" font-weight="600" text-anchor="middle" font-family="system-ui,sans-serif">${esc(p.name)}</text></g>`;
      }
    }
    return s;
  });

  // ---------- transport 1: tabs of this browser (same project) ----------
  let bc = null, bcLink = null;
  const openBC = () => {
    if (bcLink) { links.delete(bcLink); try { bc.close(); } catch (e) { /* closed */ } bc = null; bcLink = null; }
    if (!window.BroadcastChannel || !S.projectId || (O.projects && O.projects.disabled)) return;
    bc = new BroadcastChannel('obrys-collab:' + S.projectId);
    bcLink = { kind: 'tab', send: s => bc.postMessage(s), close: () => bc.close() };
    bc.onmessage = e => { if (!links.has(bcLink)) { links.add(bcLink); shadow = snapshot(); } receive(e.data, bcLink); };
    // announce; a tab that answers makes the link active (only then are changes sent)
    bc.postMessage(JSON.stringify({ t: 'hello', mid: O.uid(), from: CB.me.id, name: myName(), color: CB.me.color, page: S.pageId }));
  };
  O.on('docload', () => { peers.forEach((p, id) => { if (p.link === bcLink) peers.delete(id); }); setTimeout(openBC, 50); renderBar(); });

  // ---------- transport 2: WebRTC with copy-paste codes ----------
  const ICE = [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }];
  const b64 = u8 => btoa(String.fromCharCode(...u8)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const unb64 = s => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
  const pack = async obj => {
    const data = new TextEncoder().encode(JSON.stringify(obj));
    if (window.CompressionStream) { const z = new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer()); return 'OBRYS-Z' + b64(z); }
    let s = ''; for (let i = 0; i < data.length; i += 8192) s += String.fromCharCode(...data.subarray(i, i + 8192));
    return 'OBRYS-J' + btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  };
  const unpack = async code => {
    code = String(code || '').replace(/\s+/g, '');
    const kind = code.slice(0, 7), body = code.slice(7);
    if (kind === 'OBRYS-Z') return JSON.parse(new TextDecoder().decode(new Uint8Array(await new Response(new Blob([unb64(body)]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer())));
    if (kind === 'OBRYS-J') return JSON.parse(new TextDecoder().decode(unb64(body)));
    throw new Error(t('Це не код VIBSma'));
  };
  const gathered = pc => new Promise(res => {
    if (pc.iceGatheringState === 'complete') return res();
    const done = () => { if (pc.iceGatheringState === 'complete') res(); };
    pc.addEventListener('icegatheringstatechange', done);
    setTimeout(res, 4000);
  });
  // a data channel as a link: big messages are split, sending waits when the buffer is full
  const CHUNK = 60000;
  const rtcLink = (pc, dc, role) => {
    const parts = new Map();
    const queue = [];
    let pumping = false;
    const pump = async () => {
      if (pumping) return; pumping = true;
      while (queue.length && dc.readyState === 'open') {
        if (dc.bufferedAmount > 4e6) { await new Promise(r => { dc.onbufferedamountlow = r; setTimeout(r, 500); }); continue; }
        dc.send(queue.shift());
      }
      pumping = false;
    };
    const link = {
      kind: 'rtc', role, pc,
      send: s => {
        if (s.length <= CHUNK) queue.push(s);
        else { const id = O.uid(), n = Math.ceil(s.length / CHUNK); for (let i = 0; i < n; i++) queue.push(JSON.stringify({ _c: id, i, n, d: s.slice(i * CHUNK, (i + 1) * CHUNK) })); }
        pump();
      },
      close: () => { try { dc.close(); pc.close(); } catch (e) { /* closed */ } }
    };
    dc.bufferedAmountLowThreshold = 1e6;
    dc.onmessage = e => {
      const s = e.data;
      if (s.startsWith('{"_c"')) {
        const c = JSON.parse(s);
        const arr = parts.get(c._c) || []; arr[c.i] = c.d; parts.set(c._c, arr);
        if (arr.filter(x => x !== undefined).length === c.n) { parts.delete(c._c); receive(arr.join(''), link); }
        return;
      }
      receive(s, link);
    };
    dc.onopen = () => {
      links.add(link);
      shadow = snapshot();
      CB.hello();
      // the inviter shares the document with whoever joins
      if (role === 'host') setTimeout(() => { const g = Array.from(peers.values()).find(p => p.link === link); post({ t: 'hello', name: myName(), color: CB.me.color, page: S.pageId }); if (g) sendFull(g.id); else link._pendingFull = true; }, 300);
      renderBar(); O.toast('З’єднано: спільна робота увімкнена');
      if (CB.onlink) CB.onlink(link);
    };
    dc.onclose = () => { links.delete(link); peers.forEach((p, id) => { if (p.link === link) peers.delete(id); }); renderBar(); O.requestOverlay(); O.toast('Учасник від’єднався'); };
    return link;
  };
  // host side waits for the guest's hello to know whom to send the document to
  const origHandle = handle;
  void origHandle;
  const pendingFull = () => { for (const l of links) if (l._pendingFull) { const g = Array.from(peers.values()).find(p => p.link === l && p.name !== '…'); if (g) { l._pendingFull = false; sendFull(g.id); } } };
  setInterval(pendingFull, 400);
  let hostPc = null;
  CB.invite = async () => {
    const pc = new RTCPeerConnection({ iceServers: ICE });
    const dc = pc.createDataChannel('obrys', { ordered: true });
    rtcLink(pc, dc, 'host');
    await pc.setLocalDescription(await pc.createOffer());
    await gathered(pc);
    hostPc = pc;
    return pack({ v: 1, type: 'offer', sdp: pc.localDescription.sdp, name: myName() });
  };
  CB.accept = async code => {
    const a = await unpack(code);
    if (a.type !== 'answer') throw new Error(t('Потрібен код-відповідь від учасника'));
    if (!hostPc) throw new Error(t('Спершу створіть запрошення'));
    await hostPc.setRemoteDescription({ type: 'answer', sdp: a.sdp });
    hostPc = null;
  };
  CB.join = async code => {
    const o = await unpack(code);
    if (o.type !== 'offer') throw new Error(t('Потрібен код запрошення'));
    const pc = new RTCPeerConnection({ iceServers: ICE });
    pc.ondatachannel = e => rtcLink(pc, e.channel, 'guest');
    await pc.setRemoteDescription({ type: 'offer', sdp: o.sdp });
    await pc.setLocalDescription(await pc.createAnswer());
    await gathered(pc);
    return pack({ v: 1, type: 'answer', sdp: pc.localDescription.sdp, name: myName() });
  };
  CB.leave = () => { post({ t: 'bye' }); for (const l of Array.from(links)) if (l.kind === 'rtc') { l.close(); links.delete(l); } peers.forEach((p, id) => { if (p.link && p.link.kind === 'rtc') peers.delete(id); }); renderBar(); O.requestOverlay(); };

  // ---------- UI: top bar avatars + dialog ----------
  let bar = null;
  const renderBar = () => {
    if (!bar) {
      const tb = O.$('#topbar .tb-r');
      if (!tb) return;
      bar = O.h(`<button type="button" id="btn-collab" class="collab-bar" title="${esc(t('Спільна робота'))}" aria-label="${esc(t('Спільна робота'))}"></button>`);
      tb.insertBefore(bar, tb.firstChild);
      bar.addEventListener('click', () => CB.dialog());
    }
    const ps = CB.peers().filter(p => p.name !== '…');
    bar.innerHTML = `<span class="cav" style="--c:${CB.me.color}" title="${esc(myName())} (${esc(t('ви'))})">${esc(initials(myName()))}</span>${ps.slice(0, 4).map(p => `<span class="cav" style="--c:${p.color}" title="${esc(p.name)}">${esc(initials(p.name))}</span>`).join('')}${ps.length > 4 ? `<span class="cav more">+${ps.length - 4}</span>` : ''}<span class="lbl">${esc(ps.length ? t('Онлайн: {n}', { n: ps.length + 1 }) : t('Поділитися'))}</span>`;
  };
  CB.dialog = async () => {
    if (!(await CB.askName())) return;
    const ps = CB.peers().filter(p => p.name !== '…');
    const d = ui.dialog({
      title: 'Спільна робота',
      body: `<div class="dlg-text">${esc(t('Редагуйте проєкт разом у реальному часі: зміни, курсори й виділення інших видно одразу. Без сервера: обміняйтеся кодами через будь-який месенджер. Вкладки цього браузера з тим самим проєктом з’єднуються самі.'))}</div>
        ${ps.length ? `<div class="cb-people">${ps.map(p => `<span class="cb-p"><span class="cav" style="--c:${p.color}">${esc(initials(p.name))}</span>${esc(p.name)} <em>${esc(p.link && p.link.kind === 'tab' ? t('вкладка') : t('онлайн'))}</em></span>`).join('')}</div>` : ''}
        <div class="cb-cols">
          <div class="cb-col"><h4>${esc(t('1. Запросити'))}</h4><button type="button" class="btn primary" data-cb="invite">${esc(t('Створити код запрошення'))}</button>
            <textarea class="cb-code" data-cb-out="invite" rows="3" readonly placeholder="${esc(t('Тут з’явиться код — надішліть його учаснику'))}"></textarea><button type="button" class="btn" data-cb="copy-invite">${esc(t('Копіювати'))}</button>
            <textarea class="cb-code" data-cb-in="answer" rows="3" placeholder="${esc(t('Вставте код-відповідь від учасника'))}"></textarea><button type="button" class="btn" data-cb="accept">${esc(t('Підключити'))}</button></div>
          <div class="cb-col"><h4>${esc(t('2. Приєднатися'))}</h4><textarea class="cb-code" data-cb-in="invite" rows="3" placeholder="${esc(t('Вставте код запрошення'))}"></textarea><button type="button" class="btn primary" data-cb="join">${esc(t('Створити код-відповідь'))}</button>
            <textarea class="cb-code" data-cb-out="answer" rows="3" readonly placeholder="${esc(t('Надішліть цей код тому, хто запросив'))}"></textarea><button type="button" class="btn" data-cb="copy-answer">${esc(t('Копіювати'))}</button></div>
        </div><div class="cb-st dlg-text small"></div>`,
      fields: [{ key: 'name', label: 'Ваше ім’я', type: 'text', value: myName() }],
      buttons: (links.size ? [{ id: 'leave', label: 'Від’єднатися' }] : []).concat([{ id: 'ok', label: 'Готово', primary: true }]),
      onOk: (v, btn) => { if (v.name.trim() && v.name.trim() !== CB.me.name) { CB.me.name = v.name.trim(); O.ls.set('collabName', CB.me.name); CB.hello(); renderBar(); } if (btn === 'leave') CB.leave(); }
    });
    d.el.querySelector('.dlg').classList.add('wide');
    const st = s => { d.el.querySelector('.cb-st').textContent = s; };
    const q = s => d.el.querySelector(s);
    CB.onlink = () => { st(t('З’єднано! Можна закрити це вікно.')); renderBar(); };
    d.el.addEventListener('click', async e => {
      const b = e.target.closest('[data-cb]');
      if (!b) return;
      e.stopPropagation();
      try {
        if (b.dataset.cb === 'invite') { st(t('Створюю код…')); q('[data-cb-out="invite"]').value = await CB.invite(); st(t('Надішліть код учаснику й вставте його відповідь нижче.')); }
        if (b.dataset.cb === 'copy-invite') { await O.copyText(q('[data-cb-out="invite"]').value); O.toast('Код скопійовано'); }
        if (b.dataset.cb === 'accept') { await CB.accept(q('[data-cb-in="answer"]').value); st(t('Підключення…')); }
        if (b.dataset.cb === 'join') { st(t('Створюю відповідь…')); q('[data-cb-out="answer"]').value = await CB.join(q('[data-cb-in="invite"]').value); st(t('Надішліть код-відповідь. Після підключення відкриється спільний проєкт.')); }
        if (b.dataset.cb === 'copy-answer') { await O.copyText(q('[data-cb-out="answer"]').value); O.toast('Код скопійовано'); }
      } catch (err) { console.warn(err); st(t('Помилка: {msg}', { msg: err.message })); }
    });
  };
  O.cmd('collab', 'Спільна робота…', () => CB.dialog(), { group: 'Спільна робота' });
  O.cmd('collabName', 'Змінити своє ім’я…', () => { CB.me.name = ''; CB.askName().then(renderBar); }, { group: 'Спільна робота' });
  O.MENUS.splice(O.MENUS.findIndex(m => m[0] === 'Вигляд'), 0, ['Спільна робота', ['collab', 'tool:comment', 'comments', 'showComments', '-', 'collabName']]);
  window.addEventListener('load', () => setTimeout(() => {
    renderBar();
    if (V.el) V.el.addEventListener('pointermove', onMove);
    openBC();
  }, 0));
})();
