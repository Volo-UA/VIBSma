'use strict';
/* VIBSma — formats for other programs.
   Export hub: one dialog «Export for…» listing the programs and the format each of them opens:
   Photoshop / ibisPaint X / Procreate / Krita / GIMP / Photopea / Affinity (PSD, ORA), Illustrator (AI = PDF-compatible),
   Figma / Sketch / Inkscape / CorelDRAW / Canva (SVG, PDF, «copy for Figma»), web (HTML, Lottie), print (PDF, TIFF),
   images (PNG, JPG, WEBP, BMP, ICO), plotters & Cricut (DXF, SVG), video (MP4 slideshow).
   Import: Figma by link (REST API with a personal token), .ai (PDF-compatible), .ora (OpenRaster), .kra (Krita),
   ibisPaint (.ipv is a closed format: explained, PSD is the way). */
(function () {
  const O = window.O, M = O.M, R = O.R, G = O.G, model = O.model, S = O.state, ui = O.ui, V = O.view, io = O.io;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const FX = O.formats = {};
  const safe = s => String(s || 'obrys').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 80) || 'obrys';
  const targets = () => { const sel = O.topSel(); if (sel.length) return sel; const fr = model.page().children.filter(n => n.type === 'frame' && n.visible !== false); return fr.length ? fr : model.page().children.filter(n => n.visible !== false); };
  const baseName = () => { const s = O.topSel(); return safe(s.length === 1 ? s[0].name : S.doc.name); };

  // ======================================================================
  // WRITERS
  // ======================================================================
  const rgba = async (nodes, scale = 1, bg) => {
    const { canvas } = await io.renderImage(nodes, { scale, type: 'image/png', bg });
    return { canvas, data: canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height) };
  };
  // baseline TIFF, uncompressed RGBA, with the resolution tag (for print shops)
  FX.tiff = async (nodes, ppi = 300) => {
    const scale = ppi / 72;
    const { data } = await rgba(nodes, scale);
    const W = data.width, H = data.height, px = data.data;
    const entries = 13, ifdSize = 2 + entries * 12 + 4;
    const bpsOff = 8 + ifdSize, xresOff = bpsOff + 8, yresOff = xresOff + 8, dataOff = yresOff + 8;
    const buf = new ArrayBuffer(dataOff + W * H * 4);
    const v = new DataView(buf);
    v.setUint16(0, 0x4949, true); v.setUint16(2, 42, true); v.setUint32(4, 8, true);
    let p = 8;
    v.setUint16(p, entries, true); p += 2;
    const ent = (tag, type, count, value) => { v.setUint16(p, tag, true); v.setUint16(p + 2, type, true); v.setUint32(p + 4, count, true); if (type === 3 && count === 1) v.setUint16(p + 8, value, true); else v.setUint32(p + 8, value, true); p += 12; };
    ent(256, 4, 1, W); ent(257, 4, 1, H); ent(258, 3, 4, bpsOff); ent(259, 3, 1, 1); ent(262, 3, 1, 2); ent(273, 4, 1, dataOff); ent(277, 3, 1, 4);
    ent(278, 4, 1, H); ent(279, 4, 1, W * H * 4); ent(282, 5, 1, xresOff); ent(283, 5, 1, yresOff); ent(296, 3, 1, 2); ent(338, 3, 1, 2);
    v.setUint32(p, 0, true);
    for (let i = 0; i < 4; i++) v.setUint16(bpsOff + i * 2, 8, true);
    v.setUint32(xresOff, Math.round(ppi), true); v.setUint32(xresOff + 4, 1, true);
    v.setUint32(yresOff, Math.round(ppi), true); v.setUint32(yresOff + 4, 1, true);
    new Uint8Array(buf, dataOff).set(px);
    return new Blob([buf], { type: 'image/tiff' });
  };
  // 24-bit BMP on white
  FX.bmp = async nodes => {
    const { data } = await rgba(nodes, 1, '#FFFFFF');
    const W = data.width, H = data.height, row = Math.ceil(W * 3 / 4) * 4;
    const buf = new ArrayBuffer(54 + row * H), v = new DataView(buf), u8 = new Uint8Array(buf);
    v.setUint16(0, 0x4D42, true); v.setUint32(2, buf.byteLength, true); v.setUint32(10, 54, true); v.setUint32(14, 40, true);
    v.setInt32(18, W, true); v.setInt32(22, H, true); v.setUint16(26, 1, true); v.setUint16(28, 24, true); v.setUint32(34, row * H, true); v.setInt32(38, 2835, true); v.setInt32(42, 2835, true);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const s = ((H - 1 - y) * W + x) * 4, d = 54 + y * row + x * 3; u8[d] = data.data[s + 2]; u8[d + 1] = data.data[s + 1]; u8[d + 2] = data.data[s]; }
    return new Blob([buf], { type: 'image/bmp' });
  };
  // favicon: PNG images 16 … 256 in one .ico
  FX.ico = async nodes => {
    const b = model.selBounds(nodes);
    const sizes = [16, 32, 48, 64, 128, 256];
    const pngs = [];
    for (const s of sizes) {
      const k = s / Math.max(b.w, b.h);
      const { canvas } = await io.renderImage(nodes, { scale: k, type: 'image/png' });
      const sq = document.createElement('canvas'); sq.width = sq.height = s;
      sq.getContext('2d').drawImage(canvas, Math.round((s - canvas.width) / 2), Math.round((s - canvas.height) / 2));
      pngs.push(new Uint8Array(await (await io.canvasToBlob(sq, 'image/png')).arrayBuffer()));
    }
    const head = 6 + 16 * sizes.length;
    const total = head + pngs.reduce((a, p) => a + p.length, 0);
    const out = new Uint8Array(total), v = new DataView(out.buffer);
    v.setUint16(2, 1, true); v.setUint16(4, sizes.length, true);
    let off = head;
    sizes.forEach((s, i) => { const e = 6 + i * 16; out[e] = s >= 256 ? 0 : s; out[e + 1] = s >= 256 ? 0 : s; v.setUint16(e + 4, 1, true); v.setUint16(e + 6, 32, true); v.setUint32(e + 8, pngs[i].length, true); v.setUint32(e + 12, off, true); out.set(pngs[i], off); off += pngs[i].length; });
    return new Blob([out], { type: 'image/x-icon' });
  };
  // DXF R12 polylines in millimetres (plotters, laser, Cricut Design Space, CAD)
  FX.dxf = nodes => {
    const k = 25.4 / 72;
    const lines = ['0', 'SECTION', '2', 'HEADER', '9', '$ACADVER', '1', 'AC1009', '9', '$INSUNITS', '70', '4', '0', 'ENDSEC', '0', 'SECTION', '2', 'ENTITIES'];
    const b = model.selBounds(nodes) || { x: 0, y: 0, h: 0 };
    let count = 0;
    // every shape's outline; frames and groups only contribute their children
    const add = n => {
      if (n.visible === false) return;
      if ((n.type === 'frame' || n.type === 'group') && !(n.type === 'group' && n.mask)) { n.children.forEach(add); return; }
      if (n.type === 'raster') return;
      const subs = model.subsIn(n, model.worldMatrix(n));
      for (const poly of G.flatten(subs, 0.5)) {
        const pts = poly.pts;
        if (!pts || pts.length < 2) continue;
        const closed = !!poly.closed;
        lines.push('0', 'POLYLINE', '8', safe(n.name).replace(/\s+/g, '_').slice(0, 30) || '0', '66', '1', '70', closed ? '1' : '0');
        for (const p of pts) lines.push('0', 'VERTEX', '8', '0', '10', ((p.x - b.x) * k).toFixed(3), '20', ((b.y + b.h - p.y) * k).toFixed(3));
        lines.push('0', 'SEQEND');
        count++;
      }
    };
    nodes.forEach(add);
    lines.push('0', 'ENDSEC', '0', 'EOF');
    return { blob: new Blob([lines.join('\r\n') + '\r\n'], { type: 'application/dxf' }), count };
  };
  // OpenRaster (.ora): layered image read by Krita, GIMP, MyPaint, Pinta
  FX.ora = async nodes => {
    const frame = nodes.length === 1 && nodes[0].type === 'frame' ? nodes[0] : null;
    const items = frame ? frame.children.filter(n => n.visible !== false) : nodes;
    const area = frame ? model.worldBounds(frame) : model.selBounds(items);
    const W = Math.ceil(area.w), H = Math.ceil(area.h);
    const files = [{ name: 'mimetype', blob: new Blob(['image/openraster']) }];
    const stack = [];
    let i = 0;
    const layer = async (list, name, x, y, op) => { const r = await io.renderImage(list, { scale: 1, type: 'image/png' }); const nm = `data/layer${i++}.png`; files.push({ name: nm, blob: r.blob }); stack.unshift(`<layer name="${esc(name)}" src="${nm}" x="${Math.round(r.bounds.x - area.x)}" y="${Math.round(r.bounds.y - area.y)}" opacity="${op}"/>`); void x; void y; };
    if (frame && (frame.fills || []).some(f => f.visible !== false)) await layer([Object.assign({}, frame, { children: [], effects: [] })], t('Тло'), 0, 0, 1);
    for (const n of items) await layer([Object.assign({}, n, { opacity: 1 })], n.name, 0, 0, n.opacity === undefined ? 1 : n.opacity);
    const merged = await io.renderImage(frame ? [frame] : items, { scale: 1, type: 'image/png' });
    files.push({ name: 'mergedimage.png', blob: merged.blob });
    const th = await io.renderImage(frame ? [frame] : items, { scale: Math.min(1, 256 / Math.max(W, H)), type: 'image/png' });
    files.push({ name: 'Thumbnails/thumbnail.png', blob: th.blob });
    files.push({ name: 'stack.xml', blob: new Blob([`<?xml version="1.0" encoding="UTF-8"?>\n<image version="0.0.3" w="${W}" h="${H}"><stack>${stack.join('')}</stack></image>`], { type: 'text/xml' }) });
    return io.zip(files);
  };
  FX.ai = async nodes => {
    if (!O.pdf || !O.pdf.build) throw new Error('PDF');
    const groups = nodes.every(n => n.type === 'frame') ? nodes.map(n => [n]) : [nodes];
    const res = await O.pdf.build(groups, { editable: true, rasterFx: true, title: S.doc.name });
    return new Blob([res.bytes], { type: 'application/postscript' });
  };
  // Figma pastes SVG markup as editable vector layers
  FX.copyForFigma = async () => {
    const nodes = targets();
    const fontCSS = O.fonts ? await O.fonts.embedCSS(nodes).catch(() => '') : '';
    const { svg } = O.render.svg(nodes, { fontCSS });
    await O.copyText(svg);
    O.toast('Скопійовано. У Figma натисніть Ctrl+V — шари вставляться як вектори');
  };

  // ======================================================================
  // EXPORT HUB
  // ======================================================================
  const save = (blob, name) => { O.download(blob, name); O.toast('Збережено «{name}»', { name }); };
  // several selected objects → one file (as in the Design panel)
  const together = () => !!(O.panels && O.panels.exportTogether && O.panels.exportTogether());
  const F = {
    obrys: { label: '.obrys — проєкт VIBSma (усе, з фото й відео)', run: async () => { const id = O.projects && S.projectId; if (O.projects && !O.projects.disabled) return O.projects.download(id); save(new Blob([io.serialize()], { type: 'application/json' }), safe(S.doc.name) + '.obrys'); } },
    psd: { label: 'PSD — шари Photoshop', run: () => O.interop.exportPSD() },
    ora: { label: 'ORA — шари OpenRaster', run: async () => save(await FX.ora(targets()), baseName() + '.ora') },
    ai: { label: 'AI — Adobe Illustrator (PDF-сумісний)', run: async () => { O.toast('Створюю AI…'); save(await FX.ai(targets()), baseName() + '.ai'); } },
    pdf: { label: 'PDF — векторний, для друку', run: () => (O.pdf && O.pdf.saveDialog ? O.pdf.saveDialog() : io.export('pdf', 1)) },
    svg: { label: 'SVG — вектор (редагується всюди)', run: () => io.export('svg', 1, null, { embedFonts: true, together: together() }) },
    figma: { label: 'Копіювати для Figma (Ctrl+V у Figma)', run: () => FX.copyForFigma() },
    html: { label: 'HTML + CSS — сайт', run: () => (O.html ? O.html.exportDialog() : null) },
    lottie: { label: 'Lottie JSON — анімація', run: () => (O.anim && O.anim.exportDialog ? O.anim.exportDialog() : O.run('animExport')) },
    png: { label: 'PNG — прозоре тло', run: () => io.export('png', O.ls.get('expScale', 2), null, { together: together() }) },
    jpg: { label: 'JPG — фото', run: () => io.export('jpg', O.ls.get('expScale', 2), null, { together: together() }) },
    webp: { label: 'WEBP — для вебу', run: () => io.export('webp', O.ls.get('expScale', 2), null, { together: together() }) },
    tiff: { label: 'TIFF 300 ppi — друкарня', run: async () => { O.toast('Створюю TIFF…'); save(await FX.tiff(targets(), 300), baseName() + '.tif'); } },
    bmp: { label: 'BMP', run: async () => save(await FX.bmp(targets()), baseName() + '.bmp') },
    ico: { label: 'ICO — фавікон 16…256 px', run: async () => save(await FX.ico(targets()), baseName() + '.ico') },
    dxf: { label: 'DXF — контури в мм (CAD, лазер, плотер)', run: () => { const r = FX.dxf(targets()); save(r.blob, baseName() + '.dxf'); } },
    mp4: { label: 'MP4 / WebM — слайд-шоу з музикою', run: () => (O.media ? O.media.slideshow() : null) },
    pptx: { label: 'PDF для презентації (Keynote, PowerPoint, Google Slides)', run: () => O.pdf && O.pdf.save ? O.pdf.save(model.page().children.filter(n => n.type === 'frame').map(f => [f])) : io.export('pdf', 1) }
  };
  FX.APPS = [
    ['VIBSma', 'Ваш редактор', ['obrys']],
    ['Adobe Photoshop', 'Шари, режими накладання, непрозорість', ['psd', 'png', 'tiff']],
    ['ibisPaint X', 'Відкривайте PSD: «Мої роботи» → «+» → імпорт PSD; шари збережуться', ['psd', 'png']],
    ['Procreate', 'PSD відкривається з шарами («Імпортувати»)', ['psd', 'png']],
    ['Krita · GIMP · MyPaint', 'OpenRaster або PSD', ['ora', 'psd']],
    ['Photopea · Affinity Photo', 'PSD з шарами', ['psd']],
    ['Adobe Illustrator', 'AI (PDF-сумісний) або SVG', ['ai', 'svg', 'pdf']],
    ['Figma', 'Вставка векторів через буфер або перетягування SVG', ['figma', 'svg']],
    ['Sketch · Inkscape · CorelDRAW · Affinity Designer', 'SVG або PDF', ['svg', 'pdf']],
    ['Canva', 'Завантажте SVG, PDF або PNG', ['svg', 'pdf', 'png']],
    ['Adobe InDesign · друкарня', 'PDF з вилітом і мітками, TIFF 300 ppi', ['pdf', 'tiff']],
    ['Keynote · PowerPoint · Google Slides', 'PDF (кожен фрейм — слайд) або PNG', ['pptx', 'png']],
    ['Вебсайт', 'HTML + CSS, зображення WEBP, анімація Lottie', ['html', 'webp', 'lottie']],
    ['Cricut · лазер · CAD', 'DXF у міліметрах або SVG', ['dxf', 'svg']],
    ['Іконка сайту', 'ICO з усіма розмірами', ['ico']],
    ['Відео · соцмережі', 'MP4 / WebM слайд-шоу, PNG, JPG', ['mp4', 'png', 'jpg']],
    ['Інше', 'Растрові формати', ['jpg', 'bmp']]
  ];
  // small marks for the programs (brand colours + initials, Figma's five shapes, Canva's circle …)
  const tile = (bg, fg, txt, o = {}) => `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="${o.round ? 20 : 9}" fill="${bg}"/>${o.ring ? `<rect x="2.5" y="2.5" width="35" height="35" rx="7" fill="none" stroke="${fg}" stroke-width="2"/>` : ''}<text x="20" y="${o.y || 26.5}" text-anchor="middle" font-family="Inter,Segoe UI,Arial,sans-serif" font-weight="${o.w || 700}" font-size="${o.fs || 17}" fill="${fg}">${txt}</text></svg>`;
  FX.LOGOS = {
    'VIBSma': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#fff" stroke="#E4E4EA"/><g transform="translate(14.6 4.6) scale(.0344)">${O.BRAND.mark}</g></svg>`,
    'Adobe Photoshop': tile('#001E36', '#31A8FF', 'Ps', { ring: true }),
    'ibisPaint X': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#fff" stroke="#E4E4EA"/><path d="M11 29c3-1 4-4 6-6l9-11c1-1 3 0 2 2l-9 12c-2 2-4 4-8 3z" fill="#FF4F8B"/><circle cx="12" cy="29" r="3" fill="#2D9CDB"/></svg>`,
    'Procreate': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#111"/><defs><linearGradient id="xh-pc" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFB13B"/><stop offset=".5" stop-color="#FF3B8D"/><stop offset="1" stop-color="#4C6FFF"/></linearGradient></defs><path d="M12 28c2-9 8-16 16-17-2 6-7 13-16 17z" fill="url(#xh-pc)"/></svg>`,
    'Krita · GIMP · MyPaint': tile('#3B2B5C', '#F7C6FF', 'Kr', { fs: 16 }),
    'Photopea · Affinity Photo': tile('#18A497', '#FFFFFF', 'Pp'),
    'Adobe Illustrator': tile('#330000', '#FF9A00', 'Ai', { ring: true }),
    'Figma': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#1E1E1E"/><path d="M15.5 8h4.5v8h-4.5a4 4 0 0 1 0-8z" fill="#F24E1E"/><path d="M20 8h4.5a4 4 0 0 1 0 8H20z" fill="#FF7262"/><path d="M15.5 16H20v8h-4.5a4 4 0 0 1 0-8z" fill="#A259FF"/><circle cx="24.5" cy="20" r="4" fill="#1ABCFE"/><path d="M15.5 24H20v4a4 4 0 1 1-4.5-4z" fill="#0ACF83"/></svg>`,
    'Sketch · Inkscape · CorelDRAW · Affinity Designer': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#FFF7E0"/><path d="M13 10h14l6 7-13 15L7 17z" fill="#FDB300"/><path d="M7 17h26L20 32z" fill="#EA6C00"/><path d="M13 10l7 22 7-22z" fill="#FDAD00" opacity=".8"/></svg>`,
    'Canva': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><defs><linearGradient id="xh-cv" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#00C4CC"/><stop offset=".6" stop-color="#6A5CFF"/><stop offset="1" stop-color="#7D2AE8"/></linearGradient></defs><circle cx="20" cy="20" r="20" fill="url(#xh-cv)"/><text x="20" y="26.5" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-weight="700" font-size="17" fill="#fff">C</text></svg>`,
    'Adobe InDesign · друкарня': tile('#49021F', '#FF3366', 'Id', { ring: true }),
    'Keynote · PowerPoint · Google Slides': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#F4B400"/><rect x="9" y="11" width="22" height="15" rx="2" fill="#fff"/><path d="M20 26v5M15 31h10" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/><rect x="12" y="15" width="10" height="2.5" rx="1" fill="#F4B400"/></svg>`,
    'Вебсайт': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#E44D26"/><path d="M14 13l-5 7 5 7M26 13l5 7-5 7M22 11l-4 18" stroke="#fff" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    'Cricut · лазер · CAD': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#00A15C"/><circle cx="14" cy="27" r="4" fill="none" stroke="#fff" stroke-width="2.4"/><circle cx="26" cy="27" r="4" fill="none" stroke="#fff" stroke-width="2.4"/><path d="M16.5 24 28 9M23.5 24 12 9" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/></svg>`,
    'Іконка сайту': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#ECEEF5"/><rect x="8" y="10" width="24" height="20" rx="3" fill="#fff" stroke="#9AA3B8" stroke-width="1.6"/><path d="M8 15h24" stroke="#9AA3B8" stroke-width="1.6"/><rect x="11" y="18" width="7" height="7" rx="1.5" fill="#0D99FF"/></svg>`,
    'Відео · соцмережі': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#FF0033"/><path d="M16 13l12 7-12 7z" fill="#fff"/></svg>`,
    'Інше': `<svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#5B6478"/><path d="M9 29l8-9 6 6 4-4 5 7z" fill="#fff"/><circle cx="26" cy="14" r="3" fill="#fff"/></svg>`
  };
  FX.hub = () => {
    const d = ui.dialog({
      title: 'Експорт для програм',
      body: `<div class="dlg-text">${esc(t('Оберіть програму — кнопка збереже файл у форматі, який вона відкриває. Експортується виділене, а без виділення — фрейми сторінки.'))}</div>
        <div class="xh-grid">${FX.APPS.map(([app, note, fmts]) => `<div class="xh-app">${FX.LOGOS[app] ? `<span class="xh-logo">${FX.LOGOS[app]}</span>` : ''}<b>${esc(t(app))}</b><span>${esc(t(note))}</span><div class="xh-btns">${fmts.map(f => `<button type="button" class="btn${f === fmts[0] ? ' primary' : ''}" data-xf="${f}" title="${esc(t(F[f].label))}">${esc(f === 'figma' ? t('Копіювати') : f === 'pptx' ? 'PDF' : f.toUpperCase())}</button>`).join('')}</div></div>`).join('')}</div>`,
      buttons: [{ id: 'all', label: 'Усі формати одним ZIP' }, { id: 'ok', label: 'Закрити', primary: true }],
      onOk: (v, btn) => { if (btn === 'all') FX.exportAll(); }
    });
    d.el.querySelector('.dlg').classList.add('wide', 'xh-dlg');
    d.el.addEventListener('click', async e => {
      const b = e.target.closest('[data-xf]');
      if (!b) return;
      e.stopPropagation();
      try { await F[b.dataset.xf].run(); } catch (err) { console.error(err); O.toast('Помилка експорту: {msg}', { msg: err.message }); }
    });
  };
  // the selection (or the page's frames) in every file format at once
  FX.exportAll = async () => {
    const nodes = targets();
    if (!nodes.length) return O.toast('Немає що експортувати');
    O.toast('Готую всі формати…');
    const real = O.download;
    const files = [];
    O.download = (blob, name) => files.push({ name, blob });
    const base = baseName();
    try {
      const add = async (name, fn) => { try { const b = await fn(); if (b) files.push({ name, blob: b }); } catch (e) { console.warn(name, e); } };
      await add(base + '.svg', async () => new Blob(['<?xml version="1.0" encoding="UTF-8"?>\n' + O.render.svg(nodes, { fontCSS: O.fonts ? await O.fonts.embedCSS(nodes).catch(() => '') : '' }).svg], { type: 'image/svg+xml' }));
      await add(base + '.png', async () => (await io.renderImage(nodes, { scale: 2, type: 'image/png' })).blob);
      await add(base + '.jpg', async () => (await io.renderImage(nodes, { scale: 2, type: 'image/jpeg' })).blob);
      await add(base + '.webp', async () => (await io.renderImage(nodes, { scale: 2, type: 'image/webp' })).blob);
      await add(base + '.tif', () => FX.tiff(nodes, 300));
      await add(base + '.ora', () => FX.ora(nodes));
      await add(base + '.dxf', () => FX.dxf(nodes).blob);
      await add(base + '.ico', () => FX.ico(nodes));
      await add(base + '.ai', () => FX.ai(nodes));
      if (O.pdf && O.pdf.build) await add(base + '.pdf', async () => new Blob([(await O.pdf.build(nodes.every(n => n.type === 'frame') ? nodes.map(n => [n]) : [nodes], { editable: false })).bytes], { type: 'application/pdf' }));
      if (O.interop && O.interop.exportPSD) { const prev = S.sel.slice(); try { await O.interop.exportPSD(); } finally { S.sel = prev; } }
      const frs = nodes.filter(n => n.type === 'frame');
      if (O.html && frs.length) await add(base + '.html', () => new Blob([O.html.build(frs, { fit: true }).htmlInline], { type: 'text/html' }));
      files.push({ name: safe(S.doc.name) + '.obrys', blob: new Blob([io.serialize()], { type: 'application/json' }) });
    } finally { O.download = real; }
    O.download(await io.zip(files), base + ' — ' + t('усі формати') + '.zip');
    O.toast('Збережено форматів: {n}', { n: files.length });
  };

  // ======================================================================
  // IMPORT: Figma by link (REST API)
  // ======================================================================
  FX.parseFigmaURL = url => {
    url = String(url || '').trim();
    const com = /figma\.com\/community\/file\/(\d+)/.exec(url);
    if (com) return { key: com[1], node: null, community: true };
    const m = /figma\.com\/(?:file|design|proto|board|slides|deck)\/([A-Za-z0-9]+)(?:\/[^/?#]*\/branch\/([A-Za-z0-9]+))?/.exec(url) || /figma\.com\/(?:file|design|proto|board|slides|deck)\/[A-Za-z0-9]+\/branch\/([A-Za-z0-9]+)/.exec(url);
    if (!m) return null;
    // branch links (…/KEY/branch/BRANCHKEY/…) load the branch
    const br = /\/branch\/([A-Za-z0-9]+)/.exec(url);
    const q = /[?&]node-id=([^&#]+)/.exec(url);
    return { key: br ? br[1] : m[1], node: q ? decodeURIComponent(q[1]).replace('-', ':') : null };
  };
  const hex = c => O.color.hex({ r: (c.r || 0) * 255, g: (c.g || 0) * 255, b: (c.b || 0) * 255 });
  const BLEND = { PASS_THROUGH: 'normal', NORMAL: 'normal', DARKEN: 'darken', MULTIPLY: 'multiply', COLOR_BURN: 'color-burn', LINEAR_BURN: 'color-burn', LIGHTEN: 'lighten', SCREEN: 'screen', COLOR_DODGE: 'color-dodge', LINEAR_DODGE: 'color-dodge', OVERLAY: 'overlay', SOFT_LIGHT: 'soft-light', HARD_LIGHT: 'hard-light', DIFFERENCE: 'difference', EXCLUSION: 'exclusion', HUE: 'hue', SATURATION: 'saturation', COLOR: 'color', LUMINOSITY: 'luminosity' };
  FX.figmaToDoc = (file, images) => {
    const idMap = new Map(), protoFix = [];
    const tf = n => n.relativeTransform ? [n.relativeTransform[0][0], n.relativeTransform[1][0], n.relativeTransform[0][1], n.relativeTransform[1][1], n.relativeTransform[0][2], n.relativeTransform[1][2]] : null;
    const paints = arr => (arr || []).map(p => {
      const vis = p.visible !== false, op = p.opacity === undefined ? 1 : p.opacity;
      if (p.type === 'SOLID') return { type: 'solid', color: hex(p.color || {}), opacity: op * (p.color && p.color.a !== undefined ? p.color.a : 1), visible: vis };
      if (p.type && p.type.indexOf('GRADIENT') === 0) {
        const h = p.gradientHandlePositions || [{ x: 0, y: 0.5 }, { x: 1, y: 0.5 }];
        const stops = (p.gradientStops || []).map(s => ({ o: s.position || 0, color: hex(s.color || {}), a: s.color && s.color.a !== undefined ? s.color.a : 1 }));
        return { type: p.type === 'GRADIENT_LINEAR' ? 'linear' : 'radial', visible: vis, opacity: op, from: { x: h[0].x, y: h[0].y }, to: { x: h[1].x, y: h[1].y }, stops: stops.length > 1 ? stops : [{ o: 0, color: '#FFFFFF', a: 1 }, { o: 1, color: '#000000', a: 1 }] };
      }
      if (p.type === 'IMAGE') { const asset = images[p.imageRef]; return asset ? { type: 'image', asset, mode: { FIT: 'fit', TILE: 'tile', STRETCH: 'stretch' }[p.scaleMode] || 'fill', scale: p.scalingFactor || 1, opacity: op, visible: vis } : { type: 'solid', color: '#D9D9D9', opacity: op, visible: vis }; }
      return null;
    }).filter(Boolean);
    const effects = arr => (arr || []).map(e => {
      const vis = e.visible !== false, c = e.color || { r: 0, g: 0, b: 0, a: 0.25 };
      const base = { x: e.offset ? e.offset.x : 0, y: e.offset ? e.offset.y : 0, blur: e.radius || 0, spread: e.spread || 0, color: hex(c), opacity: c.a === undefined ? 0.25 : c.a, visible: vis };
      if (e.type === 'DROP_SHADOW') return Object.assign({ type: 'shadow' }, base);
      if (e.type === 'INNER_SHADOW') return Object.assign({ type: 'inner' }, base);
      if (e.type === 'LAYER_BLUR') return { type: 'blur', blur: e.radius || 0, visible: vis };
      if (e.type === 'BACKGROUND_BLUR') return { type: 'glass', blur: e.radius || 0, refract: 0, depth: 1, light: 0, sat: 1, visible: vis };
      return null;
    }).filter(Boolean);
    const geom = arr => { let subs = [], rule = 'nonzero'; for (const g of arr || []) { try { subs = subs.concat(G.parseD(g.path)); } catch (e) { /* skip */ } if (g.windingRule === 'EVENODD') rule = 'evenodd'; } return { subs, rule }; };
    const grids = arr => (arr || []).map(g => g.pattern === 'GRID' ? { type: 'grid', size: g.sectionSize || 8, color: hex(g.color || { r: 1, g: 0.3, b: 0.3 }), opacity: g.color ? g.color.a : 0.1, visible: g.visible !== false } : { type: g.pattern === 'ROWS' ? 'rows' : 'columns', count: g.count > 0 ? g.count : 4, gutter: g.gutterSize || 0, margin: g.offset || 0, color: hex(g.color || { r: 1, g: 0.3, b: 0.3 }), opacity: g.color ? g.color.a : 0.1, visible: g.visible !== false });
    const ALIGN = { MIN: 'start', CENTER: 'center', MAX: 'end', SPACE_BETWEEN: 'between', BASELINE: 'start' };
    let count = 0;
    const conv = (fn, parentBox) => {
      if (!fn) return null;
      const box = fn.absoluteBoundingBox || { x: 0, y: 0, width: 0, height: 0 };
      const m = tf(fn) || M.translate(box.x - (parentBox ? parentBox.x : 0), box.y - (parentBox ? parentBox.y : 0));
      const w = fn.size ? fn.size.x : box.width, h = fn.size ? fn.size.y : box.height;
      const base = { name: fn.name || '', visible: fn.visible !== false, opacity: fn.opacity === undefined ? 1 : fn.opacity, blend: BLEND[fn.blendMode] || 'normal', m };
      const style = { fills: paints(fn.fills), strokes: paints(fn.strokes), sw: fn.strokeWeight === undefined ? 1 : fn.strokeWeight, sa: { INSIDE: 'inside', OUTSIDE: 'outside' }[fn.strokeAlign] || 'center', effects: effects(fn.effects), cap: { ROUND: 'round', SQUARE: 'square' }[fn.strokeCap] || 'butt', join: { ROUND: 'round', BEVEL: 'bevel' }[fn.strokeJoin] || 'miter', dash: fn.strokeDashes || [] };
      const radius = fn.rectangleCornerRadii || fn.cornerRadius || 0;
      // groups have no coordinate space of their own in Figma: children are relative to the group's parent
      const kids = (list, pb) => (list || []).map(c => conv(c, pb)).filter(Boolean);
      count++;
      let n = null;
      switch (fn.type) {
        case 'FRAME': case 'COMPONENT': case 'COMPONENT_SET': case 'INSTANCE': case 'SECTION': {
          n = model.create('frame', Object.assign({}, base, style, { w, h, clip: fn.clipsContent !== false && fn.type !== 'SECTION', radius, name: base.name || t('Фрейм'), component: fn.type === 'COMPONENT', componentSet: fn.type === 'COMPONENT_SET' || undefined }));
          n.children = kids(fn.children, box);
          if (fn.layoutMode && fn.layoutMode !== 'NONE') n.layout = { dir: fn.layoutMode === 'VERTICAL' ? 'v' : 'h', gap: fn.itemSpacing || 0, pad: [fn.paddingTop || 0, fn.paddingRight || 0, fn.paddingBottom || 0, fn.paddingLeft || 0], align: ALIGN[fn.counterAxisAlignItems] || 'start', justify: ALIGN[fn.primaryAxisAlignItems] || 'start', wMode: (fn.layoutMode === 'VERTICAL' ? fn.counterAxisSizingMode : fn.primaryAxisSizingMode) === 'AUTO' ? 'hug' : 'fixed', hMode: (fn.layoutMode === 'VERTICAL' ? fn.primaryAxisSizingMode : fn.counterAxisSizingMode) === 'AUTO' ? 'hug' : 'fixed' };
          if (fn.layoutGrids && fn.layoutGrids.length) n.grids = grids(fn.layoutGrids);
          if (fn.type === 'COMPONENT' && O.components && /=/.test(fn.name || '')) n.variant = O.components.parseName(fn.name, 0);
          break;
        }
        case 'GROUP': {
          const ch = kids(fn.children, parentBox);
          if (!ch.length) return null;
          n = model.create('group', Object.assign({}, base, { m: M.id(), children: ch, name: base.name || t('Група') }));
          break;
        }
        case 'BOOLEAN_OPERATION': {
          const ch = kids(fn.children, parentBox);
          if (!ch.length) return null;
          n = model.create('bool', Object.assign({}, base, style, { m: M.id(), op: { SUBTRACT: 'subtract', INTERSECT: 'intersect', EXCLUDE: 'exclude' }[fn.booleanOperation] || 'union', children: ch, name: base.name || t('Булева група') }));
          break;
        }
        case 'RECTANGLE': n = model.create('rect', Object.assign({}, base, style, { w, h, radius, name: base.name || model.autoName('rect') })); break;
        case 'ELLIPSE': if (!fn.arcData || (fn.arcData.endingAngle - fn.arcData.startingAngle >= 6.28 && !fn.arcData.innerRadius)) { n = model.create('ellipse', Object.assign({}, base, style, { w, h, name: base.name || model.autoName('ellipse') })); break; } // fallthrough to geometry
        // eslint-disable-next-line no-fallthrough
        case 'TEXT': if (fn.type === 'TEXT') {
          const st = fn.style || {};
          const size = st.fontSize || 16;
          n = model.create('text', Object.assign({}, base, style, {
            text: fn.characters || '', font: st.fontFamily || 'Inter', weight: st.fontWeight || 400, italic: !!st.italic, size, ls: st.letterSpacing || 0,
            lh: st.lineHeightPx && st.lineHeightUnit !== 'INTRINSIC_%' ? st.lineHeightPx / size : null,
            align: { CENTER: 'center', RIGHT: 'right', JUSTIFIED: 'justify' }[st.textAlignHorizontal] || 'left',
            tcase: { UPPER: 'upper', LOWER: 'lower', TITLE: 'title' }[st.textCase] || 'none', deco: { UNDERLINE: 'underline', STRIKETHROUGH: 'line-through' }[st.textDecoration] || 'none',
            width: st.textAutoResize === 'WIDTH_AND_HEIGHT' ? null : (w || null),
            fills: style.fills.length ? style.fills : [O.paint.solid('#000000')], name: base.name || (fn.characters || '').slice(0, 40) || t('Текст')
          }));
          break;
        }
        // eslint-disable-next-line no-fallthrough
        default: {
          const g1 = geom(fn.fillGeometry);
          if (g1.subs.length && style.fills.length) { n = model.create('path', Object.assign({}, base, style, { subpaths: g1.subs, fillRule: g1.rule, name: base.name || model.autoName('path') })); if (!g1.subs.length) n = null; }
          if (!n) { const g2 = geom(fn.strokeGeometry); if (g2.subs.length) n = model.create('path', Object.assign({}, base, style, { subpaths: g2.subs, fillRule: 'nonzero', fills: style.strokes, strokes: [], name: base.name || model.autoName('path') })); }
          if (!n && fn.type === 'LINE') n = model.create('path', Object.assign({}, base, style, { subpaths: [{ closed: false, pts: [G.pt(0, 0), G.pt(w, 0)] }], name: base.name || model.autoName('line') }));
          if (!n && w && h) n = model.create('rect', Object.assign({}, base, style, { w, h, name: base.name || model.autoName('rect') }));
        }
      }
      if (!n) return null;
      if (fn.layoutPositioning === 'ABSOLUTE') n.layoutAbs = true;
      idMap.set(fn.id, n.id);
      if (fn.interactions && fn.interactions.length) protoFix.push([n, fn.interactions]);
      return n;
    };
    const doc = model.newDoc();
    doc.name = file.name || 'Figma';
    doc.pages = [];
    const canvases = file.document ? file.document.children || [] : [];
    for (const cv of canvases) {
      if (cv.type !== 'CANVAS') continue;
      const pg = model.newPage(cv.name || t('Сторінка'));
      pg.bg = cv.backgroundColor ? hex(cv.backgroundColor) : null;
      pg.children = (cv.children || []).map(c => conv(c, null)).filter(Boolean);
      if (cv.flowStartingPoints && cv.flowStartingPoints[0]) pg.protoStartFig = cv.flowStartingPoints[0].nodeId;
      doc.pages.push(pg);
    }
    // nodes requested by link (node-id): one page with them
    if (file.nodes) {
      const pg = model.newPage(file.name || t('Сторінка'));
      for (const v of Object.values(file.nodes)) if (v && v.document) { const n = conv(v.document, v.document.absoluteBoundingBox ? { x: v.document.absoluteBoundingBox.x, y: v.document.absoluteBoundingBox.y } : null); if (n) { const b = v.document.absoluteBoundingBox; if (b) n.m = M.translate(b.x, b.y); pg.children.push(n); } }
      doc.pages.push(pg);
    }
    // prototype links (Figma interactions → VIBSma prototype)
    const TR = { DISSOLVE: 'dissolve', SMART_ANIMATE: 'smart', INSTANT: 'instant', MOVE_IN: 'move-left', MOVE_OUT: 'move-right', PUSH: 'push-left', SLIDE_IN: 'slide-up', SLIDE_OUT: 'slide-down' };
    for (const [n, list] of protoFix) {
      n.proto = [];
      for (const it of list) for (const a of it.actions || []) {
        const trig = { ON_CLICK: 'click', ON_HOVER: 'hover', ON_PRESS: 'press', AFTER_TIMEOUT: 'after', ON_KEY_DOWN: 'key' }[it.trigger && it.trigger.type] || 'click';
        if (a.type === 'BACK') n.proto.push({ trigger: trig, action: 'back', anim: 'dissolve', dur: 300, ease: 'ease-out' });
        else if (a.type === 'CLOSE') n.proto.push({ trigger: trig, action: 'close' });
        else if (a.type === 'URL') n.proto.push({ trigger: trig, action: 'url', url: a.url });
        else if (a.type === 'NODE' && a.destinationId && idMap.has(a.destinationId)) n.proto.push({ trigger: trig, action: { OVERLAY: 'overlay', SWAP: 'swap', SCROLL_TO: 'scroll' }[a.navigation] || 'navigate', target: idMap.get(a.destinationId), anim: TR[a.transition && a.transition.type] || 'instant', dur: a.transition ? Math.round((a.transition.duration || 0.3) * 1000) : 0, ease: 'ease-out', delay: it.trigger && it.trigger.timeout ? it.trigger.timeout * 1000 : 800 });
      }
      if (!n.proto.length) delete n.proto;
    }
    for (const pg of doc.pages) { if (pg.protoStartFig && idMap.has(pg.protoStartFig)) pg.protoStart = idMap.get(pg.protoStartFig); delete pg.protoStartFig; }
    if (!doc.pages.length) doc.pages.push(model.newPage(t('Сторінка {n}', { n: 1 })));
    return { doc, count };
  };
  // errors the person can act on, by HTTP status / Figma message
  // a copied token often carries spaces, line breaks, invisible characters or quotes
  FX.cleanToken = s => String(s || '').replace(/[\s ​-‍⁠﻿"'«»“”„`]+/g, '');
  FX.figmaError = (status, body) => {
    const msg = String((body && (body.err || body.message)) || '');
    // Figma's own words, so the reason is never hidden behind a guess
    const raw = msg ? ' ' + t('(Figma: «{msg}»)', { msg: msg.slice(0, 200) }) : '';
    if (status === 401 || status === 403) {
      if (/scope/i.test(msg)) return t('Токен справжній, але не має потрібного права. Створіть у Figma новий токен із правом «File content: Read only» (Settings → Security → Personal access tokens).') + raw;
      if (/expired/i.test(msg)) return t('Термін дії токена минув. Створіть у Figma новий: Settings → Security → Personal access tokens.') + raw;
      if (status === 401 || /invalid token|token.*invalid|unauthori[sz]ed|not authenticated/i.test(msg)) return t('Figma не приймає цей токен. Скопіюйте його ще раз повністю (він показується в Figma лише один раз, починається з «figd_») або створіть новий: Settings → Security → Personal access tokens.') + raw;
      return t('Немає доступу до цього файлу. Відкрийте його в Figma під тим самим акаунтом, що й токен, або попросіть власника дати вам доступ. Також перевірте, що токен має право «File content».') + raw;
    }
    if (status === 404) return t('Файл не знайдено. Перевірте посилання (скопіюйте його в Figma: Share → Copy link).');
    if (status === 429) return t('Figma тимчасово обмежила кількість запитів. Зачекайте хвилину й спробуйте знову.');
    if (status >= 500) return t('Сервер Figma зараз не відповідає ({s}). Спробуйте пізніше.', { s: status });
    return t('Figma повернула помилку {s}: {msg}', { s: status, msg: msg || '—' });
  };
  FX.importFigmaLink = async (url, token, progress = () => {}) => {
    const ref = FX.parseFigmaURL(url);
    if (!ref) throw new Error(t('Це не посилання на файл Figma'));
    if (ref.community) throw new Error(t('Це файл із Figma Community. Спершу натисніть у Figma «Open in Figma» (дублювати собі), потім скопіюйте посилання на свою копію.'));
    const hdr = { headers: { 'X-Figma-Token': FX.cleanToken(token) } };
    const get = async u => {
      let r;
      try { r = await fetch(u, hdr); } catch (e) { throw new Error(t('Немає зв’язку з Figma. Перевірте інтернет (або VPN / блокувальник реклами).')); }
      if (!r.ok) { let body = null; try { body = await r.json(); } catch (e) { /* not JSON */ } throw new Error(FX.figmaError(r.status, body)); }
      return r.json();
    };
    progress(t('Завантажую структуру файлу з Figma…'));
    const file = ref.node ? await get(`https://api.figma.com/v1/files/${ref.key}/nodes?ids=${encodeURIComponent(ref.node)}&geometry=paths`) : await get(`https://api.figma.com/v1/files/${ref.key}?geometry=paths`);
    if (ref.node && file.nodes && !Object.values(file.nodes).some(v => v && v.document)) throw new Error(t('Фрейм {id} не знайдено у файлі. Скопіюйте посилання на файл без node-id, щоб імпортувати всі сторінки.', { id: ref.node }));
    // image fills
    const images = {};
    let refs = {};
    progress(t('Отримую список зображень…'));
    try { refs = ((await get(`https://api.figma.com/v1/files/${ref.key}/images`)).meta || {}).images || {}; } catch (e) { console.warn(e); }
    const prev = S.doc;
    const tmp = model.newDoc();
    S.doc = tmp;
    try {
      const used = new Set();
      JSON.stringify(file, (k, v) => { if (k === 'imageRef' && v) used.add(v); return v; });
      let done = 0;
      for (const r of used) {
        done++;
        if (!refs[r]) continue;
        progress(t('Зображення: {a} із {b}', { a: done, b: used.size }));
        try { const blob = await (await fetch(refs[r])).blob(); const a = await io.addAsset(await io.blobToData(blob), t('Зображення')); images[r] = a.id; } catch (e) { console.warn('image', r, e); }
      }
      progress(t('Будую шари…'));
      const res = FX.figmaToDoc(file, images);
      res.doc.assets = tmp.assets;
      res.doc.name = file.name || res.doc.name;
      return res;
    } finally { S.doc = prev; if (prev) model.reindex(); }
  };
  // Figma's REST API answers only with a personal token (Figma's rule — a browser page cannot get the file
  // without it). So the dialog leads with the two ways that need no token: copy-paste and a local .fig copy.
  FX.figmaDialog = (opts = {}) => {
    const tok0 = O.ls.get('figmaToken', '');
    const way = (n, title, body, extra = '') => `<section class="fg-way"${extra}><div class="fg-wh"><span class="fg-n">${n}</span><b>${esc(t(title))}</b></div>${body}</section>`;
    const d = ui.dialog({
      title: 'Імпорт із Figma',
      body: `<label class="dlg-row" for="fg-url"><span>${esc(t('Посилання Figma'))}</span><span class="dlg-in"><input id="fg-url" type="text" value="${esc(opts.url || '')}" placeholder="https://www.figma.com/design/…" spellcheck="false" autocomplete="off"></span></label>
        <div class="dlg-text small fg-st"></div>
        <div class="fg-ways">
        ${way(1, 'Скопіювати шари — без токена', `<ol class="fg-steps"><li>${esc(t('Відкрийте файл у Figma'))} <button type="button" class="link" data-fg="open">${esc(t('Відкрити у Figma ↗'))}</button></li><li>${esc(t('Виділіть фрейми або все (Ctrl+A) і скопіюйте (Ctrl+C)'))}</li><li>${esc(t('Поверніться сюди й натисніть Ctrl+V — шари вставляться одразу'))}</li></ol><div class="dlg-text small">${esc(t('Фото Figma не кладе в буфер обміну — на їхньому місці будуть сірі заглушки. Щоб перенести й фото, скористайтеся способом 2.'))}</div>`)}
        ${way(2, 'Файл .fig — без токена, з фото й усіма сторінками', `<ol class="fg-steps"><li>${esc(t('У Figma: меню ☰ → File → Save local copy…'))}</li><li>${esc(t('Перетягніть збережений файл .fig сюди'))}</li></ol><button type="button" class="fg-drop" data-fg="pick">${O.icon('download', 16)} ${esc(t('Перетягніть .fig сюди або натисніть, щоб обрати'))}</button>`)}
        <details class="fg-way fg-tokway"${tok0 ? ' open' : ''}><summary class="fg-wh"><span class="fg-n">3</span><b>${esc(t('За посиланням — автоматично (потрібен токен Figma)'))}</b></summary>
          <div class="dlg-text small">${esc(t('Через свій API Figma віддає файли лише з особистим токеном — це правило Figma, обійти його з браузера неможливо. Токен створюється один раз (Figma → Settings → Security → Personal access tokens, право «File content: Read only») і зберігається лише в цьому браузері.'))}</div>`,
      fields: [{ key: 'token', label: 'Особистий токен (figd_…)', type: 'text', value: tok0 }, { type: 'html', key: '_tk', html: `<div class="dlg-text small fg-tk"><button type="button" class="link" data-fg="get">${esc(t('Отримати токен у Figma ↗'))}</button> · <button type="button" class="link" data-fg="show">${esc(t('Показати токен'))}</button></div>` }, { key: 'into', label: 'Додати сторінки в поточний проєкт', type: 'checkbox', value: !!opts.into }, { type: 'html', key: '_end', html: '</details></div>' }, { type: 'html', key: '_pr', html: '<div class="fg-progress" role="status" aria-live="polite"></div>' }],
      buttons: [{ id: 'ok', label: 'Імпортувати за посиланням', primary: true }],
      keepOpen: true,
      onOk: async v => {
        const pr = d.el.querySelector('.fg-progress'), btn = d.el.querySelector('.dlg-f [data-b="ok"]');
        const say = (msg, kind) => { pr.textContent = msg; pr.className = 'fg-progress' + (kind ? ' ' + kind : ''); };
        if (busy) return;
        const u = url.value.trim(), tok = FX.cleanToken(v.token);
        const tf = d.el.querySelector('[data-k="token"]'); if (tf && tf.value !== tok) tf.value = tok;
        if (!u) { say(t('Вставте посилання на файл Figma.'), 'err'); url.focus(); return; }
        if (!FX.parseFigmaURL(u)) { say(t('Це не посилання на файл Figma'), 'err'); return; }
        if (!tok) { d.el.querySelector('.fg-tokway').open = true; say(t('Для імпорту за посиланням потрібен токен Figma. Без токена скористайтеся способом 1 (Ctrl+C → Ctrl+V) або 2 (файл .fig).'), 'err'); d.el.querySelector('[data-k="token"]').focus(); return; }
        if (!/^fig[a-z]_/i.test(tok)) say(t('Токен зазвичай починається з «figd_». Перевірте, що скопіювали його повністю.'), 'warn');
        O.ls.set('figmaToken', tok);
        busy = true; btn.disabled = true;
        try {
          const { doc, count } = await FX.importFigmaLink(u, tok, msg => say('⏳ ' + msg));
          if (v.into) {
            Object.assign(S.doc.assets, doc.assets);
            for (const pg of doc.pages) { pg.name = 'Figma: ' + pg.name; S.doc.pages.push(pg); }
            S.pageId = doc.pages[0].id; model.reindex(); O.emit('page');
            O.history.commit('Імпорт із Figma');
            setTimeout(() => V.fit(null, 80, 1), 0);
          } else if (O.projects && !O.projects.disabled) await O.projects.createFrom(doc);
          else { model.load(doc); setTimeout(() => V.fit(null, 80, 1), 0); }
          d.close();
          O.toast('Імпортовано з Figma: шарів {n}', { n: count });
        } catch (e) { console.warn(e); say('✗ ' + e.message, 'err'); }
        finally { busy = false; btn.disabled = false; }
      }
    });
    let busy = false;
    const tokIn = d.el.querySelector('[data-k="token"]');
    tokIn.type = 'password'; tokIn.autocomplete = 'off'; tokIn.spellcheck = false;
    d.el.addEventListener('click', e => {
      const b = e.target.closest('[data-fg]');
      if (!b) return;
      e.stopPropagation();
      if (b.dataset.fg === 'get') window.open('https://www.figma.com/settings', '_blank', 'noopener');
      if (b.dataset.fg === 'show') { tokIn.type = tokIn.type === 'password' ? 'text' : 'password'; b.textContent = t(tokIn.type === 'password' ? 'Показати токен' : 'Сховати токен'); }
      if (b.dataset.fg === 'open') { const s = url.value.trim(); window.open(FX.parseFigmaURL(s) ? s : 'https://www.figma.com/files', '_blank', 'noopener'); }
      if (b.dataset.fg === 'pick') O.io.pickFiles('.fig').then(f => { if (f[0]) openFig(f[0]); });
    });
    d.el.querySelector('.dlg').classList.add('wide');
    const openFig = f => {
      if (!/\.fig$/i.test(f.name || '')) { d.el.querySelector('.fg-progress').textContent = t('Це не файл .fig. У Figma: File → Save local copy…'); return; }
      d.close();
      O.interop.importFigFile(f);
    };
    // way 1: Figma layers pasted while the dialog is open (also when the link field has the focus)
    const onPaste = e => {
      if (!d.el.isConnected) { document.removeEventListener('paste', onPaste, true); return; }
      const html = e.clipboardData && e.clipboardData.getData('text/html');
      if (!html || html.indexOf('(figma)') < 0) return;
      e.preventDefault(); e.stopImmediatePropagation();
      document.removeEventListener('paste', onPaste, true);
      d.close();
      O.interop.pasteFigma(html).catch(err => { console.warn(err); O.toast('Не вдалося прочитати дані Figma. У Figma натисніть правою кнопкою → Copy/Paste as → Copy as SVG і вставте ще раз.'); });
    };
    document.addEventListener('paste', onPaste, true);
    // way 2: a .fig dropped anywhere on the dialog
    const drop = d.el.querySelector('.fg-drop');
    d.el.addEventListener('dragover', e => { if (e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files')) { e.preventDefault(); e.stopPropagation(); drop.classList.add('on'); } });
    d.el.addEventListener('dragleave', e => { if (e.target === drop) drop.classList.remove('on'); });
    d.el.addEventListener('drop', e => {
      const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (!f) return;
      e.preventDefault(); e.stopPropagation();
      drop.classList.remove('on');
      openFig(f);
    });
    // check the link while it is typed or pasted
    const url = d.el.querySelector('#fg-url'), st = d.el.querySelector('.fg-st');
    const check = () => {
      const s = url.value.trim();
      if (!s) { st.textContent = t('Посилання необов’язкове: воно потрібне для кнопки «Відкрити у Figma» і способу 3.'); st.classList.remove('warn'); return; }
      const r = FX.parseFigmaURL(s);
      if (r && r.community) { st.textContent = t('Це файл із Figma Community. Спершу натисніть у Figma «Open in Figma» (дублювати собі), потім скопіюйте посилання на свою копію.'); st.classList.add('warn'); return; }
      st.textContent = r ? '✓ ' + t('Файл {key}', { key: r.key }) + (r.node ? ' · ' + t('фрейм {id}', { id: r.node }) : ' · ' + t('усі сторінки')) : t('Це не посилання на файл Figma');
      st.classList.toggle('warn', !r);
    };
    url.addEventListener('input', check);
    url.addEventListener('paste', () => setTimeout(check, 0));
    check();
    setTimeout(() => url.focus(), 30);
    return d;
  };
  // a Figma link pasted (Ctrl+V) or dropped onto the editor opens the import
  io.pasteHooks.unshift(async ({ text }) => {
    const s = String(text || '').trim();
    if (!/^https?:\/\/(www\.)?figma\.com\//i.test(s) || !FX.parseFigmaURL(s)) return false;
    if (O.projects && O.projects.closeManager) O.projects.closeManager();
    FX.figmaDialog({ url: s });
    return true;
  });
  if (O.projects) O.projects.templates.push({ id: 'figma', name: 'Імпорт із Figma за посиланням', icon: 'link', size: 'figma.com/design/…', make: () => { FX.figmaDialog(); return null; } });

  // ======================================================================
  // IMPORT: other files
  // ======================================================================
  const unzip = async f => (O.interop && O.interop.unzip ? O.interop.unzip(new Uint8Array(await f.arrayBuffer())) : {});
  const pngEntry = (e, name) => new File([e.data], name, { type: 'image/png' });
  // OpenRaster / Krita: layers from stack.xml, or the merged image
  FX.importORA = async (file, at) => {
    const z = await unzip(file);
    const stackE = z['stack.xml'];
    if (!stackE) { const mi = z['mergedimage.png']; if (mi) return io.importImage(pngEntry(mi, file.name.replace(/\.\w+$/, '.png')), at); throw new Error('stack.xml'); }
    const x = new DOMParser().parseFromString(new TextDecoder().decode(stackE.data), 'text/xml');
    const img = x.querySelector('image');
    const W = +img.getAttribute('w'), H = +img.getAttribute('h');
    const layers = Array.from(x.querySelectorAll('stack > layer')).reverse();
    const kids = [];
    for (const l of layers) {
      const e = z[l.getAttribute('src')];
      if (!e) continue;
      const data = await io.blobToData(new Blob([e.data], { type: 'image/png' }));
      const a = await io.addAsset(data, l.getAttribute('name') || t('Шар'));
      kids.push(model.create('raster', { name: l.getAttribute('name') || t('Шар'), w: a.w, h: a.h, pw: a.w, ph: a.h, asset: a.id, m: M.translate(+l.getAttribute('x') || 0, +l.getAttribute('y') || 0), opacity: l.hasAttribute('opacity') ? +l.getAttribute('opacity') : 1, visible: l.getAttribute('visibility') !== 'hidden' }));
    }
    const c = at || R.center(V.viewRect());
    const f = model.create('frame', { name: file.name.replace(/\.\w+$/, ''), w: W, h: H, fills: [], clip: true, m: M.translate(Math.round(c.x - W / 2), Math.round(c.y - H / 2)) });
    f.children = kids;
    model.insert(f, model.page());
    O.select([f.id]);
    O.history.commit('Імпорт OpenRaster');
    O.toast('Імпортовано шарів: {n}', { n: kids.length });
    return f;
  };
  FX.importKRA = async (file, at) => {
    const z = await unzip(file);
    const mi = z['mergedimage.png'] || z['preview.png'];
    if (!mi) throw new Error('mergedimage.png');
    return io.importImage(pngEntry(mi, file.name.replace(/\.kra$/i, '.png')), at);
  };
  const ibisInfo = () => ui.alert('ibisPaint X', [
    `<p>${esc(t('Файл .ipv — закритий формат ibisPaint, його не можуть відкрити інші програми. Збережіть роботу з шарами як PSD:'))}</p>`,
    `<p><b>ibisPaint → ${esc(t('Мої роботи'))}</b> → ${esc(t('виберіть роботу'))} → <b>${esc(t('Поділитися (↗)'))}</b> → <b>PSD</b>. ${esc(t('Перетягніть .psd у це вікно — усі шари, непрозорість і режими накладання збережуться.'))}</p>`,
    `<p>${esc(t('Назад в ibisPaint: Експорт для програм → ibisPaint X → PSD, потім в ibisPaint «Мої роботи» → «+» → Імпорт PSD (або просто PNG як новий шар).'))}</p>`
  ].join(''));
  io.openHooks.unshift(
    { test: f => /\.ora$/i.test(f.name || ''), open: (f, at) => FX.importORA(f, at).catch(e => O.toast('Не вдалося відкрити ORA: {msg}', { msg: e.message })) },
    { test: f => /\.kra$/i.test(f.name || ''), open: (f, at) => FX.importKRA(f, at).catch(e => O.toast('Не вдалося відкрити KRA: {msg}', { msg: e.message })) },
    { test: f => /\.ipv$/i.test(f.name || ''), open: () => ibisInfo() },
    // Illustrator .ai files saved with «PDF compatibility» (the default) are PDF inside
    { test: f => /\.ai$/i.test(f.name || ''), open: async (f, at) => { const head = new TextDecoder().decode(new Uint8Array(await f.slice(0, 8).arrayBuffer())); if (!/%PDF/.test(head)) return O.toast('Цей .ai збережено без PDF-сумісності. В Illustrator: Зберегти як → AI з «Create PDF Compatible File», або SVG.'); const pf = new File([f], f.name.replace(/\.ai$/i, '.pdf'), { type: 'application/pdf' }); return io.openFile(pf, at); } }
  );

  // ---------- commands & menus ----------
  O.cmd('exportHub', 'Експорт для програм (Photoshop, ibisPaint, Figma, Illustrator…)…', () => FX.hub(), { keys: ['Ctrl+Alt+E'], group: 'Файл' });
  O.cmd('exportAllFormats', 'Експорт в усі формати (ZIP)', () => FX.exportAll(), { group: 'Файл' });
  O.cmd('copyForFigma', 'Копіювати для Figma', () => FX.copyForFigma(), { group: 'Файл' });
  O.cmd('importFigmaLink', 'Імпорт із Figma за посиланням…', () => FX.figmaDialog(), { group: 'Файл' });
  O.cmd('ibisHelp', 'ibisPaint X: як перенести роботи', () => ibisInfo(), { group: 'Довідка' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл')[1];
  fileMenu.splice(fileMenu.indexOf('exportDialog') + 1, 0, 'exportHub', 'exportAllFormats', 'copyForFigma');
  const fi = fileMenu.indexOf('importFig');
  fileMenu.splice(fi >= 0 ? fi + 1 : fileMenu.indexOf('importSVG') + 1, 0, 'importFigmaLink');
  const help = O.MENUS.find(m => m[0] === 'Довідка'); if (help) help[1].push('ibisHelp');
  if (O.$('#btn-export')) O.$('#btn-export').title = t('Експорт (Ctrl+Shift+E). Для інших програм — Ctrl+Alt+E');
})();
