'use strict';
/* VIBSma — files: save/open/autosave, SVG & image import, PNG/JPG/SVG/PDF export, clipboard */
(function () {
  const O = window.O, M = O.M, G = O.G, R = O.R, model = O.model, S = O.state, V = O.view;
  const io = O.io = {};
  const toast = (m, v) => O.toast && O.toast(m, v);

  io.blobToData = blob => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(blob); });
  // ms > 0: give up after ms (error.timeout = true) instead of waiting forever
  io.loadImage = (src, ms = 0) => new Promise((res, rej) => {
    const img = new Image();
    let tm = 0;
    img.onload = () => { clearTimeout(tm); res(img); };
    img.onerror = () => { clearTimeout(tm); rej(new Error(O.t('Не вдалося завантажити зображення'))); };
    if (ms) tm = setTimeout(() => { img.onload = img.onerror = null; rej(Object.assign(new Error(O.t('Не вдалося завантажити зображення')), { timeout: true })); }, ms);
    img.src = src;
  });
  const safeName = s => String(s || 'obrys').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 80) || 'obrys';

  // ---------- document ----------
  io.serialize = () => JSON.stringify(Object.assign({}, S.doc, { savedAt: new Date().toISOString() }));
  io.newDoc = () => {
    model.load(model.newDoc());
    V.zoom = 1; V.x = V.el.clientWidth / 2 - 400; V.y = 80; V.apply();
    io.handle = null;
    toast('Новий документ');
  };
  io.loadJSON = (text, fileName) => {
    let doc;
    try { doc = JSON.parse(text); } catch (e) { return toast('Файл пошкоджений або це не документ VIBSma'); }
    if (!doc || !Array.isArray(doc.pages)) return toast('Це не документ VIBSma');
    if (fileName && (!doc.name || doc.name === 'Без назви' || doc.name === O.t('Без назви'))) doc.name = fileName.replace(/\.(obrys|json)$/i, '');
    model.load(doc);
    setTimeout(() => V.fit(null, 80, 1), 0);
  };
  io.save = async (saveAs) => {
    const json = io.serialize();
    const name = safeName(S.doc.name) + '.obrys';
    if (window.showSaveFilePicker && window.isSecureContext) {
      try {
        let handle = !saveAs && io.handle;
        if (!handle) handle = await window.showSaveFilePicker({ suggestedName: name, types: [{ description: O.t('Документ VIBSma'), accept: { 'application/json': ['.obrys'] } }] });
        const w = await handle.createWritable();
        await w.write(json); await w.close();
        io.handle = handle;
        toast('Збережено: {name}', { name: handle.name });
        return;
      } catch (e) { if (e && e.name === 'AbortError') return; console.warn(e); }
    }
    O.download(new Blob([json], { type: 'application/json' }), name);
    toast('Файл {name} завантажено', { name });
  };
  io.pickFiles = (accept, multiple) => new Promise(res => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = accept; inp.multiple = !!multiple;
    inp.style.display = 'none';
    inp.onchange = () => { res(Array.from(inp.files || [])); inp.remove(); };
    document.body.appendChild(inp);
    inp.click();
  });
  io.open = async () => {
    const files = await io.pickFiles('.obrys,.json,.svg,image/*,video/*,audio/*,' + io.EXTRA_MEDIA);
    if (files[0]) io.openFile(files[0]);
  };
  // other modules (PSD, Figma) register importers here: { test(file), open(file, at) }
  io.openHooks = [];
  io.pasteHooks = [];
  io.openFile = async (file, at) => {
    const name = file.name || '';
    for (const hk of io.openHooks) if (hk.test(file)) return hk.open(file, at);
    // a project file becomes a new project: loading it over the open one would overwrite that project on autosave
    if (/\.(obrys|json)$/i.test(name)) return O.projects && !O.projects.disabled ? O.projects.importDocFile(file) : io.loadJSON(await file.text(), name);
    if (/\.svg$/i.test(name) || file.type === 'image/svg+xml') return io.importSVG(await file.text(), { at, name: name.replace(/\.svg$/i, '') });
    if (/^image\//.test(file.type)) return io.importImage(file, at);
    toast('Непідтримуваний формат: {name}', { name });
  };
  // file types browsers often leave out of image/* video/* audio/*
  io.EXTRA_MEDIA = '.heic,.heif,.avif,.jxl,.tif,.tiff,.dng,.cr2,.cr3,.nef,.arw,.orf,.rw2,.raf,.bmp,.ico,.jfif,.mkv,.mov,.m4v,.avi,.wmv,.flv,.3gp,.ogv,.mpg,.mpeg,.ts,.mts,.mp3,.wav,.ogg,.oga,.opus,.m4a,.aac,.flac,.weba,.wma,.aiff,.aif,.mid,.midi';
  io.importImageDialog = async () => {
    const files = await io.pickFiles('image/*,video/*,audio/*,' + io.EXTRA_MEDIA, true);
    for (const f of files) await io.openFile(f);
  };
  io.importSVGDialog = async () => {
    const files = await io.pickFiles('.svg,image/svg+xml', true);
    for (const f of files) await io.openFile(f);
  };

  // ---------- IndexedDB (shared by autosave, projects, versions) ----------
  const idb = O.idb = {
    _p: null,
    open() {
      if (idb._p) return idb._p;
      idb._p = new Promise((res, rej) => {
        let r;
        try { r = indexedDB.open('obrys', 3); } catch (e) { idb._p = null; rej(e); return; }
        r.onupgradeneeded = () => {
          const d = r.result;
          if (!d.objectStoreNames.contains('docs')) d.createObjectStore('docs');
          if (!d.objectStoreNames.contains('projects')) d.createObjectStore('projects', { keyPath: 'id' });
          if (!d.objectStoreNames.contains('pdata')) d.createObjectStore('pdata');
          if (!d.objectStoreNames.contains('versions')) d.createObjectStore('versions', { keyPath: 'id' }).createIndex('project', 'projectId');
          // image / video / audio data of projects, written once per asset ("projectId/assetId")
          if (!d.objectStoreNames.contains('adata')) d.createObjectStore('adata');
        };
        r.onsuccess = () => { const d = r.result; d.onversionchange = () => { d.close(); idb._p = null; }; res(d); };
        r.onerror = () => { idb._p = null; rej(r.error); };
        r.onblocked = () => { idb._p = null; rej(new Error('IndexedDB blocked')); };
      });
      return idb._p;
    },
    async tx(store, mode, fn) {
      const d = await idb.open();
      return new Promise((res, rej) => {
        const tx = d.transaction(store, mode);
        const rq = fn(tx.objectStore(store));
        let out;
        if (rq) rq.onsuccess = () => { out = rq.result; };
        tx.oncomplete = () => res(out);
        tx.onerror = () => rej(tx.error);
        tx.onabort = () => rej(tx.error);
      });
    },
    get: (store, key) => idb.tx(store, 'readonly', st => st.get(key)),
    put: (store, val, key) => idb.tx(store, 'readwrite', st => (key === undefined ? st.put(val) : st.put(val, key))),
    del: (store, key) => idb.tx(store, 'readwrite', st => st.delete(key)),
    all: store => idb.tx(store, 'readonly', st => st.getAll()),
    keys: (store, range) => idb.tx(store, 'readonly', st => st.getAllKeys(range)),
    delRange: (store, range) => idb.tx(store, 'readwrite', st => st.delete(range)),
    byIndex: (store, index, value) => idb.tx(store, 'readonly', st => st.index(index).getAll(value))
  };
  // autosave goes to the current project (projects.js); legacy single-document slot as fallback
  io.autosave = O.debounce(async () => {
    try {
      if (O.projects && O.projects.save) await O.projects.saveNow();
      else { await idb.put('docs', io.serialize(), 'current'); O.emit('saved'); }
    } catch (e) { /* storage unavailable */ }
  }, 900);
  io.restore = async () => {
    try { const s = await idb.get('docs', 'current'); return s ? JSON.parse(s) : null; } catch (e) { return null; }
  };
  O.on('commit', () => io.autosave());

  // ---------- images ----------
  io.addAsset = async (data, name) => {
    const img = await io.loadImage(data);
    const id = O.uid();
    S.doc.assets[id] = { data, w: img.naturalWidth, h: img.naturalHeight, name: name || O.t('Зображення') };
    return { id, w: img.naturalWidth, h: img.naturalHeight };
  };
  io.importImage = async (fileOrBlob, at) => {
    let data;
    try { data = await io.blobToData(fileOrBlob); } catch (e) { return toast('Не вдалося прочитати файл'); }
    let a;
    try { a = await io.addAsset(data, fileOrBlob.name); } catch (e) { return toast('Не вдалося відкрити зображення'); }
    const vr = V.viewRect();
    let w = a.w, h = a.h;
    const maxW = vr.w * 0.8, maxH = vr.h * 0.8;
    if (w > maxW || h > maxH) { const k = Math.min(maxW / w, maxH / h); w *= k; h *= k; }
    const c = at || R.center(vr);
    const cont = V.containerAt(c);
    const lp = M.apply(M.inv(model.containerMatrix(cont)), c);
    const name = (fileOrBlob.name || O.t('Зображення')).replace(/\.[a-z0-9]+$/i, '');
    const n = model.create('rect', { name, w: Math.round(w), h: Math.round(h), m: M.translate(Math.round(lp.x - w / 2), Math.round(lp.y - h / 2)), fills: [O.paint.image(a.id)] });
    model.insert(n, cont);
    O.select([n.id]);
    O.history.commit('Зображення');
    return n;
  };

  // ---------- SVG import ----------
  const UNITS = { px: 1, pt: 4 / 3, pc: 16, mm: 3.7795275591, cm: 37.795275591, in: 96, em: 16, ex: 8 };
  const parseLen = v => {
    if (v === null || v === undefined || v === '') return null;
    const m = /^\s*([+-]?[\d.]+(?:e[+-]?\d+)?)\s*([a-z%]*)\s*$/i.exec(String(v));
    if (!m || m[2] === '%') return null;
    return parseFloat(m[1]) * (UNITS[m[2].toLowerCase()] || 1);
  };
  const num = (el, a, d = 0) => { const v = parseLen(el.getAttribute(a)); return v === null ? d : v; };
  const localM = el => {
    try {
      const t = el.transform && el.transform.baseVal && el.transform.baseVal.consolidate();
      if (t) { const m = t.matrix; return [m.a, m.b, m.c, m.d, m.e, m.f]; }
    } catch (e) { /* no transform */ }
    return M.id();
  };
  const SKIP = new Set(['defs', 'style', 'title', 'desc', 'metadata', 'clippath', 'mask', 'lineargradient', 'radialgradient', 'pattern', 'symbol', 'marker', 'script', 'filter', 'foreignobject', 'font', 'font-face']);
  io.importSVG = (text, opts = {}) => {
    const parsed = new DOMParser().parseFromString(text, 'image/svg+xml');
    const root = parsed.documentElement;
    if (!root || root.localName !== 'svg' || parsed.getElementsByTagName('parsererror').length) { toast('Не вдалося прочитати SVG'); return null; }
    const host = document.createElement('div');
    host.style.cssText = 'position:absolute;left:-100000px;top:0;width:10px;height:10px;overflow:hidden;';
    const live = document.importNode(root, true);
    host.appendChild(live);
    document.body.appendChild(host);
    const byId = id => { try { return live.querySelector('#' + CSS.escape(id)); } catch (e) { return null; } };
    const urlId = v => { const m = /url\(\s*["']?#([^"')]+)["']?\s*\)/.exec(v || ''); return m ? m[1] : null; };

    const gradPaint = (gid, el) => {
      let gEl = byId(gid);
      if (!gEl) return null;
      const tag = gEl.localName.toLowerCase();
      if (tag !== 'lineargradient' && tag !== 'radialgradient') return null;
      // stops (follow href chain)
      let stopsEl = gEl, guard = 0;
      while (stopsEl && !stopsEl.querySelector('stop') && guard++ < 5) {
        const h = stopsEl.getAttribute('href') || stopsEl.getAttribute('xlink:href');
        stopsEl = h ? byId(h.replace(/^#/, '')) : null;
      }
      const stops = stopsEl ? Array.from(stopsEl.querySelectorAll('stop')).map(st => {
        const cs = getComputedStyle(st);
        const c = O.color.parse(cs.stopColor || st.getAttribute('stop-color') || '#000') || { r: 0, g: 0, b: 0, a: 1 };
        let off = st.getAttribute('offset') || '0';
        off = off.trim().endsWith('%') ? parseFloat(off) / 100 : parseFloat(off);
        return { o: O.clamp(off || 0, 0, 1), color: O.color.hex(c), a: (parseFloat(cs.stopOpacity) || (cs.stopOpacity === '0' ? 0 : 1)) * (c.a === undefined ? 1 : c.a) };
      }) : [];
      if (!stops.length) return null;
      const units = gEl.getAttribute('gradientUnits') || 'objectBoundingBox';
      let bb = { x: 0, y: 0, width: 1, height: 1 };
      try { bb = el.getBBox(); } catch (e) { /* not rendered */ }
      const gt = localM(Object.assign(gEl, {}));
      let gtm = M.id();
      try { const t = gEl.gradientTransform && gEl.gradientTransform.baseVal.consolidate(); if (t) gtm = [t.matrix.a, t.matrix.b, t.matrix.c, t.matrix.d, t.matrix.e, t.matrix.f]; } catch (e) { /* none */ }
      void gt;
      const toFrac = p => {
        let q = M.apply(gtm, p);
        if (units === 'userSpaceOnUse') q = { x: (q.x - bb.x) / (bb.width || 1), y: (q.y - bb.y) / (bb.height || 1) };
        return q;
      };
      const pv = (a, d) => {
        const v = gEl.getAttribute(a);
        if (v === null) return d;
        if (v.trim().endsWith('%')) return parseFloat(v) / 100 * (units === 'userSpaceOnUse' ? (a.includes('x') ? bb.width : bb.height) : 1) + (units === 'userSpaceOnUse' ? (a.includes('x') ? bb.x : bb.y) : 0);
        return parseFloat(v);
      };
      if (tag === 'lineargradient') {
        const d = units === 'userSpaceOnUse' ? null : 1;
        const from = toFrac({ x: pv('x1', 0), y: pv('y1', 0) }), to = toFrac({ x: pv('x2', d === null ? bb.x + bb.width : 1), y: pv('y2', 0) });
        return { type: 'linear', visible: true, opacity: 1, from, to, stops };
      }
      const cx = pv('cx', units === 'userSpaceOnUse' ? bb.x + bb.width / 2 : 0.5), cy = pv('cy', units === 'userSpaceOnUse' ? bb.y + bb.height / 2 : 0.5);
      const r = pv('r', units === 'userSpaceOnUse' ? bb.width / 2 : 0.5);
      const from = toFrac({ x: cx, y: cy }), to = toFrac({ x: cx + r, y: cy });
      return { type: 'radial', visible: true, opacity: 1, from, to, stops };
    };
    const paintOf = (v, opacity, el) => {
      if (!v || v === 'none') return null;
      const gid = urlId(v);
      if (gid) { const g = gradPaint(gid, el); if (g) g.opacity = opacity; return g; }
      const c = O.color.parse(v);
      if (!c) return null;
      return { type: 'solid', color: O.color.hex(c), opacity: opacity * (c.a === undefined ? 1 : c.a), visible: true };
    };
    const style = (el, n) => {
      const cs = getComputedStyle(el);
      const f = paintOf(cs.fill, parseFloat(cs.fillOpacity), el);
      const s = paintOf(cs.stroke, parseFloat(cs.strokeOpacity), el);
      n.fills = f ? [f] : [];
      n.strokes = s ? [s] : [];
      n.sw = parseLen(cs.strokeWidth) || (s ? 1 : 0) || 1;
      n.cap = cs.strokeLinecap || 'butt';
      n.join = cs.strokeLinejoin === 'round' || cs.strokeLinejoin === 'bevel' ? cs.strokeLinejoin : 'miter';
      n.miter = parseFloat(cs.strokeMiterlimit) || 4;
      n.dash = cs.strokeDasharray && cs.strokeDasharray !== 'none' ? cs.strokeDasharray.split(/[\s,]+/).map(parseLen).filter(v => v !== null) : [];
      if (n.type === 'path') n.fillRule = cs.fillRule === 'evenodd' ? 'evenodd' : 'nonzero';
      n.opacity = parseFloat(cs.opacity);
      if (!isFinite(n.opacity)) n.opacity = 1;
      if (cs.mixBlendMode && cs.mixBlendMode !== 'normal') n.blend = cs.mixBlendMode;
      return n;
    };
    const nameOf = (el, fallback) => el.getAttribute('id') || el.getAttribute('inkscape:label') || el.getAttribute('data-name') || fallback;
    const wrapClip = (el, node) => {
      const cs = getComputedStyle(el);
      const cid = urlId(cs.clipPath) || urlId(el.getAttribute('clip-path'));
      if (!cid) return node;
      const cp = byId(cid);
      if (!cp) return node;
      const mg = model.create('group', { name: O.t('Маска') });
      convertChildren(cp, mg);
      if (!mg.children.length) return node;
      const maskNode = mg.children.length === 1 ? mg.children[0] : mg;
      maskNode.fills = [O.paint.solid('#000000')]; maskNode.strokes = [];
      const lm = localM(el);
      const g = model.create('group', { name: O.t('Обтравочна група'), mask: true, m: lm });
      node.m = M.mul(M.inv(lm), node.m);
      g.children = [maskNode, node];
      return g;
    };
    function convert(el) {
      const tag = (el.localName || '').toLowerCase();
      if (!tag || SKIP.has(tag)) return null;
      const cs = getComputedStyle(el);
      if (cs.display === 'none' || el.getAttribute('display') === 'none' || cs.visibility === 'hidden') return null;
      const lm = localM(el);
      let n = null;
      switch (tag) {
        case 'g': case 'a': case 'switch': {
          n = model.create('group', { name: nameOf(el, O.t('Група')), m: lm });
          convertChildren(el, n);
          if (!n.children.length) return null;
          const op = parseFloat(cs.opacity);
          n.opacity = isFinite(op) ? op : 1;
          break;
        }
        case 'svg': {
          const vb = el.viewBox && el.viewBox.baseVal;
          let m = M.mul(lm, M.translate(num(el, 'x'), num(el, 'y')));
          if (vb && vb.width && vb.height) {
            const w = parseLen(el.getAttribute('width')) || vb.width, h = parseLen(el.getAttribute('height')) || vb.height;
            const s = Math.min(w / vb.width, h / vb.height);
            m = M.chain(m, M.scale(s, s), M.translate(-vb.x, -vb.y));
          }
          n = model.create('group', { name: nameOf(el, 'SVG'), m });
          convertChildren(el, n);
          if (!n.children.length) return null;
          break;
        }
        case 'use': {
          const href = (el.getAttribute('href') || el.getAttribute('xlink:href') || '').replace(/^#/, '');
          const ref = href && byId(href);
          if (!ref) return null;
          n = model.create('group', { name: nameOf(el, href), m: M.mul(lm, M.translate(num(el, 'x'), num(el, 'y'))) });
          if (ref.localName.toLowerCase() === 'symbol') convertChildren(ref, n);
          else { const c = convert(ref); if (c) n.children.push(c); }
          if (!n.children.length) return null;
          break;
        }
        case 'rect': {
          const w = num(el, 'width'), h = num(el, 'height');
          if (w <= 0 || h <= 0) return null;
          let rx = parseLen(el.getAttribute('rx')), ry = parseLen(el.getAttribute('ry'));
          const r = rx !== null ? rx : (ry !== null ? ry : 0);
          n = style(el, model.create('rect', { name: nameOf(el, model.autoName('rect')), w, h, radius: r, m: M.mul(lm, M.translate(num(el, 'x'), num(el, 'y'))) }));
          break;
        }
        case 'circle': {
          const r = num(el, 'r');
          if (r <= 0) return null;
          n = style(el, model.create('ellipse', { name: nameOf(el, model.autoName('ellipse')), w: 2 * r, h: 2 * r, m: M.mul(lm, M.translate(num(el, 'cx') - r, num(el, 'cy') - r)) }));
          break;
        }
        case 'ellipse': {
          const rx = num(el, 'rx'), ry = num(el, 'ry');
          if (rx <= 0 || ry <= 0) return null;
          n = style(el, model.create('ellipse', { name: nameOf(el, model.autoName('ellipse')), w: 2 * rx, h: 2 * ry, m: M.mul(lm, M.translate(num(el, 'cx') - rx, num(el, 'cy') - ry)) }));
          break;
        }
        case 'line': {
          n = style(el, model.create('path', { name: nameOf(el, model.autoName('line')), m: lm, subpaths: [{ closed: false, pts: [G.pt(num(el, 'x1'), num(el, 'y1')), G.pt(num(el, 'x2'), num(el, 'y2'))] }] }));
          break;
        }
        case 'polyline': case 'polygon': {
          const v = (el.getAttribute('points') || '').trim().split(/[\s,]+/).map(parseFloat).filter(isFinite);
          const pts = [];
          for (let i = 0; i + 1 < v.length; i += 2) pts.push(G.pt(v[i], v[i + 1]));
          if (pts.length < 2) return null;
          n = style(el, model.create('path', { name: nameOf(el, model.autoName('path')), m: lm, subpaths: [{ closed: tag === 'polygon', pts }] }));
          break;
        }
        case 'path': {
          const subs = G.parseD(el.getAttribute('d'));
          if (!subs.length) return null;
          n = style(el, model.create('path', { name: nameOf(el, model.autoName('path')), m: lm, subpaths: subs }));
          break;
        }
        case 'text': {
          const tspans = Array.from(el.querySelectorAll('tspan'));
          const lines = [];
          if (tspans.length && tspans.some(t => t.getAttribute('y') || t.getAttribute('dy'))) tspans.forEach(t => lines.push(t.textContent));
          else lines.push(el.textContent);
          const content = lines.join('\n').replace(/\s+$/g, '');
          if (!content.trim()) return null;
          const first = tspans[0] || el;
          const x = parseLen(first.getAttribute('x')) ?? num(el, 'x'), y = parseLen(first.getAttribute('y')) ?? num(el, 'y');
          const fam = (cs.fontFamily || 'Arial').split(',')[0].replace(/["']/g, '').trim();
          const anchor = cs.textAnchor;
          n = style(el, model.create('text', {
            text: content, font: fam, size: parseLen(cs.fontSize) || 16, weight: parseInt(cs.fontWeight, 10) || 400,
            italic: cs.fontStyle === 'italic', ls: parseLen(cs.letterSpacing) || 0,
            align: anchor === 'middle' ? 'center' : anchor === 'end' ? 'right' : 'left'
          }));
          if (!n.fills.length && !n.strokes.length) n.fills = [O.paint.solid('#000000')];
          const lhAttr = parseFloat(el.getAttribute('data-lh'));
          if (isFinite(lhAttr) && lhAttr > 0) n.lh = lhAttr;
          const L = O.text.layout(n);
          const dx = n.align === 'center' ? L.w / 2 : n.align === 'right' ? L.w : 0;
          n.m = M.mul(lm, M.translate(x - dx, y - (L.lines[0] ? L.lines[0].y : n.size * 0.8)));
          // an id names the layer (templates, designs from Claude); otherwise the first line of the text
          n.name = el.getAttribute('id') || el.getAttribute('data-name') || content.split('\n')[0].slice(0, 40);
          break;
        }
        case 'image': {
          const href = el.getAttribute('href') || el.getAttribute('xlink:href');
          const w = num(el, 'width'), h = num(el, 'height');
          if (!href || w <= 0 || h <= 0) return null;
          const id = O.uid();
          S.doc.assets[id] = { data: href, w, h, name: O.t('Зображення') };
          io.loadImage(href).then(img => { S.doc.assets[id].w = img.naturalWidth; S.doc.assets[id].h = img.naturalHeight; }).catch(() => {});
          const par = el.getAttribute('preserveAspectRatio') || '';
          const mode = par.includes('none') ? 'stretch' : par.includes('slice') ? 'fill' : 'fit';
          n = model.create('rect', { name: nameOf(el, O.t('Зображення')), w, h, m: M.mul(lm, M.translate(num(el, 'x'), num(el, 'y'))), fills: [Object.assign(O.paint.image(id), { mode })] });
          break;
        }
        default: return null;
      }
      if (n && n.type !== 'group' && tag !== 'svg') { /* style applied */ }
      return n ? wrapClip(el, n) : null;
    }
    function convertChildren(el, parent) {
      for (const c of Array.from(el.children)) {
        const n = convert(c);
        if (n) parent.children.push(n);
      }
    }
    let g;
    try {
      const vb = live.viewBox && live.viewBox.baseVal;
      let rootM = M.id();
      if (vb && vb.width && vb.height) {
        const w = parseLen(live.getAttribute('width')), h = parseLen(live.getAttribute('height'));
        const s = (w && h) ? Math.min(w / vb.width, h / vb.height) : (w ? w / vb.width : (h ? h / vb.height : 1));
        rootM = M.mul(M.scale(s, s), M.translate(-vb.x, -vb.y));
      }
      g = model.create('group', { name: opts.name || (live.getAttribute('id') || 'SVG'), m: rootM });
      convertChildren(live, g);
    } catch (e) {
      console.error(e);
      toast('Помилка імпорту SVG: {msg}', { msg: e.message });
      host.remove();
      return null;
    }
    host.remove();
    if (!g.children.length) { toast('У SVG не знайдено графіки'); return null; }
    model.normalize(g, 'scale');
    const at = opts.at || R.center(V.viewRect());
    const cont = opts.container || V.containerAt(at);
    model.insert(g, cont);
    model.reindex();
    const b = model.worldBounds(g);
    // noCenter: keep the SVG's own coordinates inside the container (PDF pages placed into frames)
    if (b && !opts.noCenter) model.applyWorld(g, M.translate(Math.round(at.x - b.x - b.w / 2), Math.round(at.y - b.y - b.h / 2)), 'resize');
    if (g.children.length === 1 && g.children[0].type === 'group' && !opts.keepGroup) {
      // unwrap redundant root group
      const inner = g.children[0];
      model.reparent(inner, cont, cont.children.indexOf(g));
      model.remove(g);
      if (opts.name) inner.name = opts.name;
      g = inner;
    }
    O.select([g.id]);
    if (!opts.noCommit) O.history.commit('Імпорт SVG');
    return g;
  };

  // ---------- export ----------
  // canvas → Blob that never hangs: toBlob with a time limit, then the synchronous toDataURL fallback
  io.canvasToBlob = (cv, type = 'image/png', q = 0.92) => new Promise(res => {
    let done = false;
    const viaData = () => {
      if (done) return;
      done = true;
      try {
        const d = cv.toDataURL(type, q);
        res(d && d.length > 30 ? O.dataToBlob(d) : null);
      } catch (e) { res(null); }
    };
    try {
      cv.toBlob(b => { if (done) return; if (b) { done = true; res(b); } else viaData(); }, type, q);
    } catch (e) { viaData(); return; }
    setTimeout(viaData, 6000 + Math.round(cv.width * cv.height / 250000) * 1000);
  });
  // browsers refuse giant canvases (Safari ~16 Mpx, others ~268 Mpx): scale down instead of failing
  const MAX_SIDE = 16384, MAX_PIX = /^((?!chrome|android|crios|fxios|edg).)*safari/i.test(navigator.userAgent) ? 16e6 : 120e6;
  io.safeScale = (b, scale) => {
    const k = Math.min(1, MAX_SIDE / Math.max(1, b.w * scale), MAX_SIDE / Math.max(1, b.h * scale), Math.sqrt(MAX_PIX / Math.max(1, b.w * b.h * scale * scale)));
    return scale * k;
  };
  io.renderImage = async (nodes, opts = {}) => {
    let scale = opts.scale || 1;
    const bg = opts.type === 'image/jpeg' ? (opts.bg || '#FFFFFF') : opts.bg;
    let fontCSS = opts.fontCSS;
    if (fontCSS === undefined && opts.embedFonts !== false && O.fonts) { try { fontCSS = await O.fonts.embedCSS(nodes); } catch (e) { fontCSS = ''; } }
    const pre = O.render.svg(nodes, { scale: 1, assetURL: opts.assetURL });
    const safe = io.safeScale(pre.bounds, scale);
    const reduced = safe < scale - 1e-6;
    scale = safe;
    const { svg, bounds } = O.render.svg(nodes, { scale, bg, fontCSS, assetURL: opts.assetURL });
    let url = null;
    try {
      if (O.trace) O.trace('renderImage load ' + svg.length);
      let img;
      // data: URL first (decoded in-process), blob: URL as the fallback
      try { img = await io.loadImage('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg), 10000); } catch (e) {
        url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
        img = await io.loadImage(url, 20000);
      }
      if (O.trace) O.trace('renderImage decode');
      if (img.decode) await img.decode().catch(() => {});
      if (fontCSS) await new Promise(r => setTimeout(r, 60));
      if (O.trace) O.trace('renderImage draw');
      const cv = document.createElement('canvas');
      cv.width = Math.max(1, Math.round(bounds.w * scale)); cv.height = Math.max(1, Math.round(bounds.h * scale));
      const c = cv.getContext('2d');
      if (bg) { c.fillStyle = bg; c.fillRect(0, 0, cv.width, cv.height); }
      c.drawImage(img, 0, 0, cv.width, cv.height);
      const blob = await io.canvasToBlob(cv, opts.type || 'image/png', opts.quality || 0.92);
      if (!blob) throw new Error(O.t('Зображення завелике для браузера. Зменшіть масштаб експорту.'));
      return { blob, bounds, canvas: cv, scale, reduced };
    } finally { if (url) URL.revokeObjectURL(url); }
  };
  // what to export: the selection (locked layers too), else the page's frames, else the whole page
  io.exportTargets = (opts = {}) => {
    const all = O.sel();
    const sel = all.filter(n => !all.some(o => o !== n && model.isAncestor(o, n)));
    if (sel.length) return opts.together ? [O.ops.zsort(sel)] : sel.map(n => [n]);
    const frames = model.page().children.filter(n => n.type === 'frame' && n.visible !== false);
    if (frames.length && !opts.together) return frames.map(f => [f]);
    return [model.page().children.filter(n => n.visible !== false)];
  };
  // several files → one ZIP (browsers block a burst of separate downloads)
  const CRC = (() => { const tb = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; tb[n] = c >>> 0; } return tb; })();
  const crc32 = u8 => { let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  io.zip = async files => {
    const enc = new TextEncoder(), parts = [], central = [];
    const d = new Date();
    const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    const used = new Set();
    let offset = 0;
    for (const f of files) {
      let name = f.name, k = 2;
      while (used.has(name.toLowerCase())) name = f.name.replace(/(\.[^.]+)?$/, m => ` (${k})` + m), k++;
      used.add(name.toLowerCase());
      const data = new Uint8Array(await f.blob.arrayBuffer());
      const nm = enc.encode(name), crc = crc32(data);
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true);
      lh.setUint16(10, time, true); lh.setUint16(12, date, true); lh.setUint32(14, crc, true); lh.setUint32(18, data.length, true); lh.setUint32(22, data.length, true);
      lh.setUint16(26, nm.length, true); lh.setUint16(28, 0, true);
      parts.push(lh, nm, data);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, 0, true);
      ch.setUint16(12, time, true); ch.setUint16(14, date, true); ch.setUint32(16, crc, true); ch.setUint32(20, data.length, true); ch.setUint32(24, data.length, true);
      ch.setUint16(28, nm.length, true); ch.setUint32(42, offset, true);
      central.push(ch, nm);
      offset += 30 + nm.length + data.length;
    }
    const csize = central.reduce((s, p) => s + p.byteLength, 0);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, csize, true); end.setUint32(16, offset, true);
    return new Blob(parts.concat(central, [end]), { type: 'application/zip' });
  };
  // one exported file per group of nodes
  io.exportFile = async (nodes, fmt, scale = 1, opts = {}) => {
    const base = safeName(opts.name || (nodes.length === 1 ? nodes[0].name : (S.doc.name + ' ' + model.page().name)));
    if (O.trace) O.trace('exportFile fonts ' + base);
    const fontCSS = opts.embedFonts === false || !O.fonts ? '' : await O.fonts.embedCSS(nodes).catch(() => '');
    if (O.trace) O.trace('exportFile render ' + base + ' css=' + fontCSS.length);
    if (fmt === 'svg') {
      const { svg } = O.render.svg(nodes, { fontCSS });
      return { name: base + '.svg', blob: new Blob(['<?xml version="1.0" encoding="UTF-8"?>\n' + svg], { type: 'image/svg+xml' }) };
    }
    const type = fmt === 'jpg' ? 'image/jpeg' : fmt === 'webp' ? 'image/webp' : 'image/png';
    const r = await io.renderImage(nodes, { scale, type, fontCSS, bg: opts.bg, quality: opts.quality });
    const suffix = Math.abs(r.scale - 1) > 1e-6 ? '@' + O.fmt(r.scale, 2) + 'x' : '';
    return { name: base + suffix + '.' + fmt, blob: r.blob, reduced: r.reduced };
  };
  io.export = async (fmt, scale = 1, groups, opts = {}) => {
    groups = groups || io.exportTargets(opts);
    groups = groups.filter(g => g && g.length);
    if (!groups.length) return toast('Немає що експортувати');
    if (fmt === 'pdf') return O.pdf ? O.pdf.save(groups, { embedFonts: opts.embedFonts }) : io.exportPDF(groups);
    if (fmt === 'pdfprint') return io.exportPDF(groups);
    if (fmt === 'html' && O.html) return O.html.exportDialog(groups.map(g => g[0]));
    const files = [];
    let reduced = false;
    toast(groups.length > 1 ? 'Експорт {n} файлів…' : 'Експорт…', { n: groups.length });
    try {
      for (const nodes of groups) {
        const f = await io.exportFile(nodes, fmt, scale, opts);
        if (f.reduced) reduced = true;
        files.push(f);
      }
    } catch (e) { console.error(e); return toast('Помилка експорту: {msg}', { msg: e.message }); }
    if (O.trace) O.trace('export save ' + files.length);
    if (files.length === 1) O.download(files[0].blob, files[0].name);
    else if (opts.zip === false) { for (const f of files) { O.download(f.blob, f.name); await new Promise(r => setTimeout(r, 350)); } }
    else O.download(await io.zip(files), safeName(S.doc.name + ' — ' + fmt.toUpperCase()) + '.zip');
    if (reduced) toast('Масштаб зменшено: браузер не може створити таке велике зображення');
    else toast(files.length > 1 ? 'Експортовано файлів: {n} (ZIP-архів)' : 'Експортовано «{name}»', { n: files.length, name: files[0].name });
    return files;
  };
  // export several pages at once: frames of each page (or the whole page when it has no frames)
  io.exportPages = async (ids, fmt, scale = 1) => {
    const groups = [];
    for (const id of ids) {
      const pg = S.doc.pages.find(p => p.id === id);
      if (!pg) continue;
      const vis = pg.children.filter(n => n.visible !== false);
      const frames = vis.filter(n => n.type === 'frame');
      if (frames.length) frames.forEach(f => groups.push([f]));
      else if (vis.length) groups.push(vis);
    }
    if (!groups.length) return toast('Немає що експортувати');
    if (fmt === 'pdf') return O.pdf ? O.pdf.save(groups) : io.exportPDF(groups);
    return io.export(fmt, scale, groups);
  };
  io.exportPDF = async (groups, opts = {}) => {
    // open the window right away (still inside the click), fill it when the fonts are ready
    const w = opts.noWindow ? null : window.open('', '_blank');
    if (w) { try { w.document.write(`<!doctype html><title>${O.esc(S.doc.name)}</title><p style="font:14px system-ui;padding:24px">${O.esc(O.t('Підготовка PDF…'))}</p>`); } catch (e) { /* ignore */ } }
    const all = groups.reduce((a, g) => a.concat(g), []);
    const fontCSS = O.fonts ? await O.fonts.embedCSS(all).catch(() => '') : '';
    const pages = groups.map(nodes => O.render.svg(nodes, { fontCSS }));
    const sizes = pages.map(p => p.bounds);
    const same = sizes.every(b => Math.abs(b.w - sizes[0].w) < 0.5 && Math.abs(b.h - sizes[0].h) < 0.5);
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>${O.esc(S.doc.name)}</title><style>
      ${same ? `@page { size: ${sizes[0].w * 0.75}pt ${sizes[0].h * 0.75}pt; margin: 0; }` : '@page { margin: 0; }'} html, body { margin: 0; padding: 0; background: #fff; }
      .pg { page-break-after: always; break-after: page; display: flex; align-items: center; justify-content: center; }
      .pg:last-child { page-break-after: auto; break-after: auto; }
      .pg svg { max-width: 100vw; max-height: 100vh; width: auto; height: auto; }
      @media screen { body { background: #888; } .pg { margin: 16px auto; background: #fff; width: fit-content; box-shadow: 0 2px 12px rgba(0,0,0,.3); } }
    </style></head><body>${pages.map(p => `<div class="pg">${p.svg}</div>`).join('')}<script>window.onload=function(){setTimeout(function(){window.print();},300);};<\/script></body></html>`;
    if (opts.noWindow) return html;
    if (!w) {
      O.download(new Blob([html], { type: 'text/html' }), safeName(S.doc.name) + '-print.html');
      return toast('Спливне вікно заблоковано. Завантажено HTML-файл: відкрийте його та збережіть як PDF через друк.');
    }
    w.document.open(); w.document.write(html); w.document.close();
    toast('У вікні друку оберіть «Зберегти як PDF»');
  };
  io.copySVG = async () => {
    const nodes = O.topSel();
    if (!nodes.length) return toast('Виділіть об’єкти');
    const fontCSS = O.fonts ? await O.fonts.embedCSS(nodes).catch(() => '') : '';
    const { svg } = O.render.svg(nodes, { fontCSS });
    await O.copyText(svg);
    toast('SVG-код скопійовано');
  };

  // ---------- clipboard ----------
  const typing = () => { const a = document.activeElement; return a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA' || a.isContentEditable); };
  O.copyText = async text => {
    try { await navigator.clipboard.writeText(text); return true; }
    catch (e) {
      const ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e2) { /* ignore */ }
      ta.remove();
      return false;
    }
  };
  io.initClipboard = () => {
    document.addEventListener('copy', e => {
      if (typing()) return;
      const clip = O.ops.copy();
      if (!clip) return;
      e.clipboardData.setData('text/plain', 'OBRYS:' + JSON.stringify(clip));
      try { e.clipboardData.setData('text/html', O.render.svg(O.topSel(), {}).svg); } catch (err) { /* ignore */ }
      e.preventDefault();
      toast('Скопійовано');
    });
    document.addEventListener('cut', e => {
      if (typing()) return;
      const clip = O.ops.copy();
      if (!clip) return;
      e.clipboardData.setData('text/plain', 'OBRYS:' + JSON.stringify(clip));
      e.preventDefault();
      O.ops.del();
    });
    document.addEventListener('paste', async e => {
      if (typing()) return;
      const dt = e.clipboardData;
      if (!dt) return;
      e.preventDefault();
      const files = Array.from(dt.files || []);
      if (files.length) { for (const f of files) await io.openFile(f); return; }
      const text = dt.getData('text/plain');
      const html = dt.getData('text/html');
      if (text && text.startsWith('OBRYS:')) {
        try { O.ops.paste(JSON.parse(text.slice(6)), { inPlace: !!O.pasteInPlace }); } catch (err) { toast('Не вдалося вставити'); }
        O.pasteInPlace = false;
        return;
      }
      for (const hk of io.pasteHooks) { try { if (await hk({ text, html })) return; } catch (err) { console.warn(err); } }
      const svgText = text && /<svg[\s>]/i.test(text) ? text : (html && /<svg[\s>]/i.test(html) ? html.slice(html.search(/<svg[\s>]/i), html.lastIndexOf('</svg>') + 6) : null);
      if (svgText) { io.importSVG(svgText, {}); return; }
      if (text && text.trim()) {
        const c = R.center(V.viewRect());
        const cont = V.containerAt(c);
        const lp = M.apply(M.inv(model.containerMatrix(cont)), c);
        const n = model.create('text', { text: text.trim().slice(0, 5000) });
        n.name = n.text.split('\n')[0].slice(0, 40);
        const L = O.text.layout(n);
        n.m = M.translate(Math.round(lp.x - L.w / 2), Math.round(lp.y - L.h / 2));
        model.insert(n, cont);
        O.select([n.id]);
        O.history.commit('Вставлення тексту');
      } else if (S.clipboard) O.ops.paste(S.clipboard);
    });
  };

  // ---------- drag & drop ----------
  // the whole window accepts files: a drop outside the canvas no longer makes the browser open the file
  // instead of the editor. Projects (.obrys, .zip) become new projects, photos / clips are laid out in a row.
  const PROJECT_RE = /\.(obrys|json|zip)$/i;
  // files of dropped folders too
  const droppedFiles = async dt => {
    const items = Array.from(dt.items || []);
    const entries = items.map(it => (it.kind === 'file' && it.webkitGetAsEntry ? it.webkitGetAsEntry() : null));
    if (!entries.some(en => en && en.isDirectory)) return Array.from(dt.files || []);
    const out = [];
    const walk = async en => {
      if (!en) return;
      if (en.isFile) { out.push(await new Promise(r => en.file(r, () => r(null)))); return; }
      const rd = en.createReader();
      for (;;) { const batch = await new Promise(r => rd.readEntries(r, () => r([]))); if (!batch.length) break; for (const c of batch) await walk(c); }
    };
    for (const en of entries) await walk(en);
    return out.filter(f => f && !/^\./.test(f.name));
  };
  // open several files: projects as projects, the rest into the page, side by side from «at»
  io.openFiles = async (files, at) => {
    const placed = [];
    for (const f of files) {
      if (PROJECT_RE.test(f.name || '') && O.projects && !O.projects.disabled) {
        if (/\.zip$/i.test(f.name)) await O.projects.importZip(f); else await O.projects.importDocFile(f);
        continue;
      }
      if (/\.zip$/i.test(f.name || '')) { toast('Архів ZIP можна відкрити як проєкти в менеджері проєктів'); continue; }
      try { const n = await io.openFile(f, at); if (n && n.id && model.exists(n.id)) placed.push(n); } catch (e) { console.warn(e); toast('Не вдалося відкрити «{name}»', { name: f.name }); }
    }
    if (placed.length > 1) {
      // a row (wrapping after ~4000 px), aligned to the first one
      const b0 = model.worldBounds(placed[0]);
      let x = b0.x, y = b0.y, rowH = 0;
      for (const n of placed) {
        const b = model.worldBounds(n);
        if (x > b0.x && x + b.w > b0.x + 4000) { x = b0.x; y += rowH + 24; rowH = 0; }
        model.applyWorld(n, M.translate(Math.round(x - b.x), Math.round(y - b.y)), 'resize');
        x += b.w + 24; rowH = Math.max(rowH, b.h);
      }
      O.select(placed.map(n => n.id));
      O.history.commit('Розміщення файлів');
      toast('Додано файлів: {n}', { n: placed.length });
    }
    return placed;
  };
  // an image dragged from another website (no file, only its address)
  const openURL = async (url, at) => {
    if (O.formats && O.formats.parseFigmaURL(url)) return O.formats.figmaDialog({ url });
    try {
      const r = await fetch(url);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const blob = await r.blob();
      const name = decodeURIComponent((url.split(/[?#]/)[0].split('/').pop() || 'image')).slice(0, 80);
      return io.openFiles([new File([blob], /\.[a-z0-9]{2,5}$/i.test(name) ? name : name + '.' + ((blob.type.split('/')[1] || 'png').replace('jpeg', 'jpg')), { type: blob.type })], at);
    } catch (e) { toast('Сайт не дозволяє завантажити це зображення. Збережіть його на диск і перетягніть файл.'); return []; }
  };
  io.initDrop = el => {
    const accepts = e => { const ty = Array.from((e.dataTransfer && e.dataTransfer.types) || []); return ty.includes('Files') || ty.includes('text/uri-list'); };
    let depth = 0, hint = null;
    const show = on => {
      if (!on) { if (hint) { hint.remove(); hint = null; } return; }
      if (hint) return;
      const pm = !!O.$('.pm-back');
      hint = O.h(`<div id="drop-hint" aria-hidden="true"><div>${O.esc(O.t(pm ? 'Відпустіть, щоб імпортувати проєкти (.obrys, .zip) або створити проєкт із фото' : 'Відпустіть, щоб додати фото, відео, аудіо, SVG, PDF або відкрити проєкт .obrys'))}</div></div>`);
      document.body.appendChild(hint);
    };
    window.addEventListener('dragenter', e => { if (!accepts(e)) return; depth++; show(true); });
    window.addEventListener('dragleave', e => { if (!accepts(e)) return; depth = Math.max(0, depth - 1); if (!depth) show(false); });
    window.addEventListener('dragover', e => { if (!accepts(e)) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
    window.addEventListener('drop', async e => {
      depth = 0; show(false);
      if (!accepts(e)) return;
      e.preventDefault();
      const dt = e.dataTransfer;
      const files = await droppedFiles(dt);
      if (O.$('.pm-back') && O.projects && !O.projects.disabled) {
        if (files.length) { O.projects.closeManager(); await O.projects.importAny(files); }
        return;
      }
      const at = el.contains(e.target) ? V.toWorld(V.local(e)) : R.center(V.viewRect());
      // the first photo dropped on a frame goes into it (place.js), the rest are laid out as usual
      const into = io.dropTarget && io.dropTarget(e);
      if (into) { S.hover = null; O.requestOverlay(); }
      const pi = into ? files.findIndex(f => /^image\//.test(f.type) && !/svg/.test(f.type)) : -1;
      if (pi >= 0 && await io.dropInto(into, files[pi])) files.splice(pi, 1);
      if (files.length) { await io.openFiles(files, at); return; }
      if (pi >= 0) return;
      const url = (dt.getData('text/uri-list') || '').split('\n').find(s => s && !s.startsWith('#'));
      const html = dt.getData('text/html') || '';
      const img = (/<img[^>]+src="([^"]+)"/i.exec(html) || [])[1];
      const src = img || url;
      if (src && /^(https?:|data:image|blob:)/i.test(src)) await openURL(src.trim(), at);
    });
  };

  // ---------- fonts ----------
  io.uploadFont = async () => {
    const files = await io.pickFiles('.ttf,.otf,.woff,.woff2', true);
    for (const f of files) {
      try {
        const data = await io.blobToData(f);
        let family = f.name.replace(/\.(ttf|otf|woff2?)$/i, '').replace(/[-_](Regular|Bold|Italic|Light|Medium|SemiBold|Black|Thin).*$/i, '');
        if (window.opentype && !/\.woff2$/i.test(f.name)) {
          try { const font = window.opentype.parse(await f.arrayBuffer()); family = (font.names.fontFamily && (font.names.fontFamily.en || Object.values(font.names.fontFamily)[0])) || family; } catch (e) { /* keep file name */ }
        }
        S.doc.fonts = (S.doc.fonts || []).filter(x => x.family !== family).concat([{ family, data, file: f.name }]);
        await io.registerFonts();
        toast('Шрифт «{name}» додано', { name: family });
      } catch (e) { toast('Не вдалося завантажити шрифт {name}', { name: f.name }); }
    }
    O.history.commit('Шрифт');
    O.emit('fonts');
  };
  const registered = new Set();
  io.registerFonts = async () => {
    for (const f of S.doc.fonts || []) {
      if (registered.has(f.family + f.file)) continue;
      try {
        const ff = new FontFace(f.family, `url(${f.data})`);
        await ff.load();
        document.fonts.add(ff);
        registered.add(f.family + f.file);
      } catch (e) { console.warn('font', e); }
    }
    O.requestRender();
  };
  O.on('docload', () => { io.registerFonts(); });
  io.localFonts = null;
  io.queryLocalFonts = async () => {
    if (!window.queryLocalFonts) { toast('Ваш браузер не дає доступу до встановлених шрифтів (потрібен Chrome або Edge)'); return; }
    try {
      const list = await window.queryLocalFonts();
      io.localFonts = Array.from(new Set(list.map(f => f.family))).sort();
      O.emit('fonts');
      toast('Знайдено шрифтів: {n}', { n: io.localFonts.length });
    } catch (e) { toast('Доступ до шрифтів не надано'); }
  };
})();
