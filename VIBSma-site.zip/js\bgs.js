'use strict';
/* VIBSma — 100 backgrounds: 25 styles × 4 palettes (gradients, aurora, waves, mountains, low poly, Memphis, dots,
   stripes, blueprint, bokeh, confetti, terrazzo, topography, halftone, synthwave sun, neon grid, blobs, sky, space,
   checkerboard, art deco, isometric, leaves…). Every background is vector art: in a design it becomes an editable
   group at the bottom of the frame; in the video editor it becomes a picture clip. Any size. */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui, V = O.view, M = O.M;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const BG = O.backgrounds = {};

  const PAL = [
    ['#0F2027', '#203A43', '#2C5364', '#00D2FF', '#FFFFFF'], ['#FF5F6D', '#FFC371', '#FFE29F', '#7F00FF', '#FFFFFF'], ['#1A1A2E', '#16213E', '#0F3460', '#E94560', '#F5F5F5'], ['#F7F3E9', '#E8DCC4', '#C9A87C', '#5B4636', '#2E2A24'],
    ['#E0F7FA', '#B2EBF2', '#4DD0E1', '#00838F', '#004D40'], ['#FCE4EC', '#F8BBD0', '#F06292', '#880E4F', '#FFFFFF'], ['#0B0B0F', '#1F1F2E', '#7B2FF7', '#F107A3', '#00F5D4'], ['#FFF8E1', '#FFD54F', '#FF8F00', '#E65100', '#3E2723'],
    ['#E8F5E9', '#A5D6A7', '#43A047', '#1B5E20', '#FFFDE7'], ['#EDE7F6', '#B39DDB', '#7E57C2', '#311B92', '#FFFFFF'], ['#FAFAFA', '#E0E0E0', '#9E9E9E', '#212121', '#FF3D00'], ['#002B36', '#073642', '#B58900', '#CB4B16', '#EEE8D5'],
    ['#FFDEE9', '#B5FFFC', '#C1C8FF', '#FFF5B7', '#7A5CFA'], ['#14213D', '#FCA311', '#E5E5E5', '#FFFFFF', '#000000'], ['#2D132C', '#801336', '#C72C41', '#EE4540', '#FFD3B6'], ['#03045E', '#0077B6', '#00B4D8', '#90E0EF', '#CAF0F8'],
    ['#264653', '#2A9D8F', '#E9C46A', '#F4A261', '#E76F51'], ['#10002B', '#3C096C', '#7B2CBF', '#C77DFF', '#E0AAFF'], ['#FFFFFF', '#F1F3F5', '#4361EE', '#F72585', '#3A0CA3'], ['#1B1B1B', '#3D3D3D', '#D4AF37', '#F5E6B3', '#FFFFFF']
  ];
  const q = v => Math.round(v * 10) / 10;
  const rng = seed => { let s = (seed * 2654435761) >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; };
  const mix = (a, b, k) => O.color.mix(a, b, k);
  const A = o => Object.entries(o).filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v]) => `${k}="${typeof v === 'number' ? q(v) : esc(v)}"`).join(' ');
  const R = (x, y, w, h, o = {}) => `<rect ${A(Object.assign({ x, y, width: w, height: h }, o))}/>`;
  const C = (cx, cy, r, o = {}) => `<circle ${A(Object.assign({ cx, cy, r: Math.max(0.1, r) }, o))}/>`;
  const E = (cx, cy, rx, ry, o = {}) => `<ellipse ${A(Object.assign({ cx, cy, rx, ry }, o))}/>`;
  const P = (d, o = {}) => `<path ${A(Object.assign({ d }, o))}/>`;
  const PG = (pts, o = {}) => `<polygon ${A(Object.assign({ points: pts.map(p => q(p[0]) + ',' + q(p[1])).join(' ') }, o))}/>`;
  const L = (x1, y1, x2, y2, o = {}) => `<line ${A(Object.assign({ x1, y1, x2, y2 }, o))}/>`;
  // gradients get ids unique per background
  const lin = (c, stops, x1 = 0, y1 = 0, x2 = 0, y2 = 1) => { const id = c.idp + 'g' + (c.n++); c.defs.push(`<linearGradient id="${id}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}">${stops.map((s, i) => `<stop offset="${Array.isArray(s) ? s[1] : i / Math.max(1, stops.length - 1)}" stop-color="${Array.isArray(s) ? s[0] : s}"${Array.isArray(s) && s[2] !== undefined ? ` stop-opacity="${s[2]}"` : ''}/>`).join('')}</linearGradient>`); return `url(#${id})`; };
  const rad = (c, stops) => { const id = c.idp + 'g' + (c.n++); c.defs.push(`<radialGradient id="${id}" cx="0.5" cy="0.5" r="0.5">${stops.map((s, i) => `<stop offset="${Array.isArray(s) ? s[1] : i / Math.max(1, stops.length - 1)}" stop-color="${Array.isArray(s) ? s[0] : s}"${Array.isArray(s) && s[2] !== undefined ? ` stop-opacity="${s[2]}"` : ''}/>`).join('')}</radialGradient>`); return `url(#${id})`; };
  const wave = (W, y, amp, len, ph) => { let d = `M0 ${q(y)}`; for (let x = 0; x <= W + len / 4; x += len / 4) d += `L${q(x)} ${q(y + Math.sin(x / len * Math.PI * 2 + ph) * amp)}`; return d + `L${q(W)} ${q(9e3)}L0 ${q(9e3)}Z`; };
  const blob = (cx, cy, r, rnd, n = 8, k = 0.35) => {
    const pts = []; for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2, rr = r * (1 - k / 2 + rnd() * k); pts.push([cx + Math.cos(a) * rr, cy + Math.sin(a) * rr]); }
    let d = ''; for (let i = 0; i < n; i++) { const p0 = pts[(i - 1 + n) % n], p1 = pts[i], p2 = pts[(i + 1) % n], p3 = pts[(i + 2) % n]; if (!i) d += `M${q(p1[0])} ${q(p1[1])}`; d += `C${q(p1[0] + (p2[0] - p0[0]) / 6)} ${q(p1[1] + (p2[1] - p0[1]) / 6)} ${q(p2[0] - (p3[0] - p1[0]) / 6)} ${q(p2[1] - (p3[1] - p1[1]) / 6)} ${q(p2[0])} ${q(p2[1])}`; }
    return d + 'Z';
  };

  // ---------- 25 styles: (c) → markup; c = { W, H, p: palette, r: random, u, defs } ----------
  const STY = [
    ['grad', 'Градієнт', c => R(0, 0, c.W, c.H, { fill: lin(c, [c.p[0], c.p[2], c.p[3]], 0, 0, 1, 1) })],
    ['glow', 'Сяйво', c => R(0, 0, c.W, c.H, { fill: c.p[0] }) + E(c.W * 0.5, c.H * 0.55, c.W * 0.75, c.H * 0.75, { fill: rad(c, [[c.p[3], 0], [c.p[2], 0.45, 0.6], [c.p[0], 1, 0]]) })],
    ['mesh', 'Меш-градієнт', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[1] }); [[0.15, 0.2, 2], [0.85, 0.25, 3], [0.3, 0.85, 4], [0.8, 0.8, 0], [0.5, 0.5, 2]].forEach(([x, y, i]) => { s += E(c.W * x, c.H * y, c.W * 0.55, c.H * 0.55, { fill: rad(c, [[c.p[i], 0, 0.9], [c.p[i], 1, 0]]) }); }); return s; }],
    ['aurora', 'Аврора', c => { let s = R(0, 0, c.W, c.H, { fill: lin(c, [mix(c.p[0], '#000000', 0.5), c.p[0]]) }); for (let i = 0; i < 4; i++) s += P(wave(c.W, c.H * (0.25 + i * 0.12), c.H * 0.08, c.W * (0.6 + i * 0.15), i * 1.3), { fill: lin(c, [[c.p[3 - (i % 2)], 0, 0.55], [c.p[2 + (i % 3)], 0.4, 0.2], [c.p[0], 1, 0]]) }); return s; }],
    ['waves', 'Хвилі', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[4] === '#FFFFFF' ? mix(c.p[0], '#FFFFFF', 0.85) : c.p[4] }); for (let i = 0; i < 5; i++) s += P(wave(c.W, c.H * (0.45 + i * 0.11), c.H * 0.035, c.W * (0.5 + c.r() * 0.4), c.r() * 6), { fill: mix(c.p[1], c.p[3], i / 4) }); return s; }],
    ['mountains', 'Гори', c => { let s = R(0, 0, c.W, c.H, { fill: lin(c, [c.p[4] === '#FFFFFF' ? c.p[2] : c.p[4], c.p[1]]) }) + C(c.W * 0.7, c.H * 0.35, Math.min(c.W, c.H) * 0.12, { fill: c.p[3] }); for (let i = 0; i < 4; i++) { const pts = [[0, c.H]]; const n = 6; for (let k = 0; k <= n; k++) pts.push([c.W * k / n, c.H * (0.45 + i * 0.12) - c.r() * c.H * 0.18]); pts.push([c.W, c.H]); s += PG(pts, { fill: mix(c.p[2], c.p[0], i / 3) }); } return s; }],
    ['lowpoly', 'Низькополігональний', c => { let s = ''; const cols = 10, rows = Math.max(4, Math.round(10 * c.H / c.W)); const pt = (i, j) => [c.W * i / cols + (i > 0 && i < cols ? (c.r() - 0.5) * c.W / cols * 0.6 : 0), c.H * j / rows + (j > 0 && j < rows ? (c.r() - 0.5) * c.H / rows * 0.6 : 0)]; const G = []; for (let j = 0; j <= rows; j++) { G.push([]); for (let i = 0; i <= cols; i++) G[j].push(pt(i, j)); } for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) { const a = G[j][i], b = G[j][i + 1], cc = G[j + 1][i], d = G[j + 1][i + 1], k = (i / cols + j / rows) / 2; s += PG([a, b, d], { fill: mix(c.p[0], c.p[3], k + c.r() * 0.08) }) + PG([a, d, cc], { fill: mix(c.p[0], c.p[3], k + 0.04 + c.r() * 0.08) }); } return s; }],
    ['memphis', 'Мемфіс', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[4] === '#FFFFFF' ? '#FFF9EE' : c.p[4] }); const m = Math.min(c.W, c.H); for (let i = 0; i < 26; i++) { const x = c.r() * c.W, y = c.r() * c.H, z = m * (0.03 + c.r() * 0.05), col = c.p[1 + Math.floor(c.r() * 3)], k = i % 4; if (k === 0) s += C(x, y, z, { fill: col }); else if (k === 1) s += PG([[x, y - z], [x + z, y + z], [x - z, y + z]], { fill: col }); else if (k === 2) { let d = `M${q(x - z * 1.5)} ${q(y)}`; for (let j = 0; j < 6; j++) d += `L${q(x - z * 1.5 + (j + 1) * z / 2)} ${q(y + (j % 2 ? -z / 3 : z / 3))}`; s += P(d, { fill: 'none', stroke: col, 'stroke-width': m * 0.008, 'stroke-linecap': 'round' }); } else s += C(x, y, z * 0.7, { fill: 'none', stroke: col, 'stroke-width': m * 0.008 }); } return s; }],
    ['dots', 'Горошок', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[0] }); const st = Math.min(c.W, c.H) / 14; for (let y = st / 2, j = 0; y < c.H + st; y += st, j++) for (let x = (j % 2) * st / 2; x < c.W + st; x += st) s += C(x, y, st * 0.16, { fill: c.p[3], opacity: 0.85 }); return s; }],
    ['stripes', 'Діагональні смуги', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[0] }); const w = Math.max(c.W, c.H) / 12; for (let x = -c.H, i = 0; x < c.W; x += w * 2, i++) s += PG([[x, c.H], [x + w, c.H], [x + w + c.H, 0], [x + c.H, 0]], { fill: i % 2 ? c.p[2] : c.p[3], opacity: 0.85 }); return s; }],
    ['blueprint', 'Креслення', c => { const bg = mix(c.p[0], '#0A2A6B', 0.5); let s = R(0, 0, c.W, c.H, { fill: bg }); const st = Math.min(c.W, c.H) / 24; for (let x = 0; x <= c.W; x += st) s += L(x, 0, x, c.H, { stroke: '#FFFFFF', 'stroke-width': Math.round(x / st) % 5 ? 0.6 : 1.4, opacity: 0.25 }); for (let y = 0; y <= c.H; y += st) s += L(0, y, c.W, y, { stroke: '#FFFFFF', 'stroke-width': Math.round(y / st) % 5 ? 0.6 : 1.4, opacity: 0.25 }); s += C(c.W * 0.7, c.H * 0.4, Math.min(c.W, c.H) * 0.22, { fill: 'none', stroke: '#FFFFFF', 'stroke-width': 2, opacity: 0.6 }); return s; }],
    ['bokeh', 'Боке', c => { let s = R(0, 0, c.W, c.H, { fill: lin(c, [c.p[0], c.p[1]]) }); const m = Math.min(c.W, c.H); for (let i = 0; i < 40; i++) s += C(c.r() * c.W, c.r() * c.H, m * (0.02 + c.r() * 0.09), { fill: c.p[2 + (i % 3)], opacity: 0.12 + c.r() * 0.3 }); return s; }],
    ['confetti', 'Конфеті', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[4] === '#FFFFFF' ? '#FFFFFF' : c.p[0] }); const m = Math.min(c.W, c.H); for (let i = 0; i < 120; i++) { const x = c.r() * c.W, y = c.r() * c.H, w = m * (0.008 + c.r() * 0.012); s += R(x, y, w, w * 2.4, { fill: c.p[1 + (i % 4)], transform: `rotate(${Math.round(c.r() * 180)} ${q(x)} ${q(y)})` }); } return s; }],
    ['terrazzo', 'Тераццо', c => { let s = R(0, 0, c.W, c.H, { fill: '#F4EFE8' }); const m = Math.min(c.W, c.H); for (let i = 0; i < 90; i++) { const x = c.r() * c.W, y = c.r() * c.H, z = m * (0.008 + c.r() * 0.03), pts = []; const n = 3 + Math.floor(c.r() * 3); for (let k = 0; k < n; k++) { const a = k / n * Math.PI * 2 + c.r(), rr = z * (0.6 + c.r() * 0.6); pts.push([x + Math.cos(a) * rr, y + Math.sin(a) * rr]); } s += PG(pts, { fill: c.p[i % 5] }); } return s; }],
    ['topo', 'Топографія', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[0] }); const m = Math.min(c.W, c.H); [[0.3, 0.4], [0.75, 0.7]].forEach(([x, y]) => { for (let i = 1; i < 14; i++) { const rr = rng(i * 7 + x * 100); s += P(blob(c.W * x, c.H * y, m * 0.045 * i, rr, 10, 0.18), { fill: 'none', stroke: c.p[3], 'stroke-width': 1.4, opacity: 0.55 }); } }); return s; }],
    ['halftone', 'Півтон', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[4] === '#FFFFFF' ? '#FFFFFF' : c.p[0] }); const st = Math.min(c.W, c.H) / 22; for (let y = st / 2; y < c.H; y += st) for (let x = st / 2; x < c.W; x += st) { const k = Math.hypot(x / c.W - 0.1, y / c.H - 0.9) / 1.2; s += C(x, y, st * 0.46 * Math.max(0, 1 - k), { fill: c.p[3] }); } return s; }],
    ['synth', 'Ретро-сонце', c => { let s = R(0, 0, c.W, c.H, { fill: lin(c, ['#12002B', '#3A0055', '#FF2E88']) }); const r = Math.min(c.W, c.H) * 0.26, cy = c.H * 0.52; s += C(c.W / 2, cy, r, { fill: lin(c, ['#FFE45E', '#FF6B9A']) }); for (let i = 0; i < 6; i++) s += R(c.W / 2 - r, cy + r * (0.15 + i * 0.15), r * 2, r * 0.05 * (1 + i * 0.4), { fill: '#3A0055' }); s += R(0, c.H * 0.62, c.W, c.H * 0.38, { fill: '#12002B' }); for (let i = 0; i <= 16; i++) s += L(c.W / 2, c.H * 0.62, c.W * (i / 16 - 0.5) * 3 + c.W / 2, c.H, { stroke: c.p[3] === '#FFFFFF' ? '#FF2E88' : '#FF2E88', 'stroke-width': 1.5, opacity: 0.8 }); for (let k = 0; k < 8; k++) { const y = c.H * 0.62 + c.H * 0.38 * Math.pow(k / 8, 1.8); s += L(0, y, c.W, y, { stroke: '#FF2E88', 'stroke-width': 1.5, opacity: 0.8 }); } return s; }],
    ['neongrid', 'Неонова сітка', c => { let s = R(0, 0, c.W, c.H, { fill: '#07070C' }); const col = c.p[3] === '#FFFFFF' ? '#00F5D4' : c.p[3], hz = c.H * 0.45; for (let i = 0; i <= 20; i++) s += L(c.W / 2, hz, c.W * (i / 20 - 0.5) * 4 + c.W / 2, c.H, { stroke: col, 'stroke-width': 1.6, opacity: 0.7 }); for (let k = 1; k < 12; k++) { const y = hz + (c.H - hz) * Math.pow(k / 12, 2); s += L(0, y, c.W, y, { stroke: col, 'stroke-width': 1.6, opacity: 0.7 }); } s += E(c.W / 2, hz, c.W * 0.6, c.H * 0.12, { fill: rad(c, [[col, 0, 0.5], [col, 1, 0]]) }); return s; }],
    ['blobs', 'Органічні плями', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[4] === '#FFFFFF' ? mix(c.p[1], '#FFFFFF', 0.6) : c.p[4] }); const m = Math.min(c.W, c.H); [[0.1, 0.15, 0.35, 2], [0.9, 0.2, 0.28, 3], [0.8, 0.9, 0.4, 1], [0.2, 0.85, 0.22, 3]].forEach(([x, y, r, i]) => { s += P(blob(c.W * x, c.H * y, m * r, c.r, 8, 0.4), { fill: c.p[i], opacity: 0.9 }); }); return s; }],
    ['sky', 'Небо з хмарами', c => { let s = R(0, 0, c.W, c.H, { fill: lin(c, ['#5DADE2', '#D6EAF8']) }); const m = Math.min(c.W, c.H); for (let i = 0; i < 5; i++) { const x = c.r() * c.W, y = c.H * (0.15 + c.r() * 0.5), z = m * (0.06 + c.r() * 0.05); s += E(x, y, z * 2.2, z * 0.8, { fill: '#FFFFFF', opacity: 0.9 }) + C(x - z * 0.8, y - z * 0.3, z * 0.8, { fill: '#FFFFFF', opacity: 0.9 }) + C(x + z * 0.4, y - z * 0.55, z, { fill: '#FFFFFF', opacity: 0.9 }); } return s; }],
    ['space', 'Космос', c => { let s = R(0, 0, c.W, c.H, { fill: '#05030F' }) + E(c.W * 0.65, c.H * 0.4, c.W * 0.5, c.H * 0.35, { fill: rad(c, [[c.p[3], 0, 0.45], [c.p[2], 0.5, 0.15], ['#05030F', 1, 0]]) }); for (let i = 0; i < 160; i++) s += C(c.r() * c.W, c.r() * c.H, 0.4 + c.r() * 1.6, { fill: '#FFFFFF', opacity: 0.3 + c.r() * 0.7 }); return s; }],
    ['checker', 'Шахівниця', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[1] }); const st = Math.min(c.W, c.H) / 8; for (let y = 0, j = 0; y < c.H; y += st, j++) for (let x = 0, i = 0; x < c.W; x += st, i++) if ((i + j) % 2) s += R(x, y, st, st, { fill: c.p[3] }); return s; }],
    ['deco', 'Арт-деко', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[0] }); const r = Math.min(c.W, c.H) / 7; for (let y = 0, j = 0; y < c.H + r; y += r * 0.9, j++) for (let x = (j % 2) * r, i = 0; x < c.W + r * 2; x += r * 2, i++) for (let k = 4; k >= 1; k--) s += P(`M${q(x - r * k / 4)} ${q(y)}A${q(r * k / 4)} ${q(r * k / 4)} 0 0 1 ${q(x + r * k / 4)} ${q(y)}Z`, { fill: k % 2 ? c.p[3] : c.p[0], stroke: c.p[3], 'stroke-width': 1.2 }); return s; }],
    ['iso', 'Ізометрія', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[1] }); const a = Math.min(c.W, c.H) / 9, h = a * 0.577; for (let y = -a, j = 0; y < c.H + a; y += a * 1.5, j++) for (let x = (j % 2) * a, i = 0; x < c.W + a; x += a * 2, i++) { s += PG([[x, y - h * 1.15], [x + a, y - h * 0.6], [x, y], [x - a, y - h * 0.6]], { fill: mix(c.p[2], '#FFFFFF', 0.25) }) + PG([[x - a, y - h * 0.6], [x, y], [x, y + a * 1.15], [x - a, y + a * 0.55]], { fill: c.p[2] }) + PG([[x + a, y - h * 0.6], [x, y], [x, y + a * 1.15], [x + a, y + a * 0.55]], { fill: mix(c.p[2], '#000000', 0.25) }); } return s; }],
    ['leaves', 'Листя', c => { let s = R(0, 0, c.W, c.H, { fill: c.p[4] === '#FFFFFF' ? mix(c.p[0], '#FFFFFF', 0.85) : c.p[4] }); const m = Math.min(c.W, c.H); for (let i = 0; i < 22; i++) { const x = c.r() * c.W, y = c.r() * c.H, l = m * (0.08 + c.r() * 0.1), a = c.r() * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a), tx = x + ca * l, ty = y + sa * l, mx = (x + tx) / 2, my = (y + ty) / 2, px = -sa * l * 0.35, py = ca * l * 0.35; s += P(`M${q(x)} ${q(y)}Q${q(mx + px)} ${q(my + py)} ${q(tx)} ${q(ty)}Q${q(mx - px)} ${q(my - py)} ${q(x)} ${q(y)}Z`, { fill: mix(c.p[2], c.p[3], c.r()) }) + L(x, y, tx, ty, { stroke: mix(c.p[3], '#000000', 0.3), 'stroke-width': 1, opacity: 0.5 }); } return s; }]
  ];
  // 100 backgrounds: each style in 4 palettes
  BG.LIST = [];
  STY.forEach(([k, name], si) => { for (let v = 0; v < 4; v++) BG.LIST.push({ id: k + '-' + (v + 1), style: k, name, v: v + 1, pal: (si * 3 + v * 7) % PAL.length, i: BG.LIST.length }); });
  BG.STYLES = STY.map(s => [s[0], s[1]]);
  BG.svg = (id, W = 1920, H = 1080, idp = '') => {
    const b = BG.LIST.find(x => x.id === id) || BG.LIST[0];
    const st = STY.find(s => s[0] === b.style);
    const c = { W, H, p: PAL[b.pal], r: rng(b.i + 11), u: Math.min(W, H) / 100, defs: [], n: 0, idp: idp + b.id.replace(/\W/g, '') + '_' };
    let body = '';
    try { body = st[2](c); } catch (e) { console.error(b.id, e); body = R(0, 0, W, H, { fill: c.p[0] }); }
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><defs>${c.defs.join('')}</defs>${body}</svg>`;
  };
  BG.label = b => `${t(b.name)} ${b.v}`;
  // brightness of the base layer (0…1): the first full-size rectangle, a flat colour or the average of its gradient
  const lumCache = new Map();
  BG.lum = id => {
    if (lumCache.has(id)) return lumCache.get(id);
    const svg = BG.svg(id, 400, 250);
    let v = 0.5;
    const m = /<rect x="0" y="0" width="400" height="250" fill="([^"]+)"/.exec(svg);
    if (m) {
      const ref = /^url\(#([^)]+)\)$/.exec(m[1]);
      if (!ref) v = O.color.luminance(m[1]);
      else { const g = new RegExp(`id="${ref[1]}"[^>]*>([\\s\\S]*?)</(linear|radial)Gradient>`).exec(svg); const cs = g ? Array.from(g[1].matchAll(/stop-color="([^"]+)"/g)).map(x => O.color.luminance(x[1])) : []; if (cs.length) v = cs.reduce((a, b) => a + b, 0) / cs.length; }
    }
    lumCache.set(id, v);
    return v;
  };
  BG.dataURL = (id, W, H) => 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(BG.svg(id, W, H))));

  // ---------- into a design: the frame under the selection (or a new one) gets the background as its bottom layer ----------
  BG.insert = id => {
    let f = null;
    for (const n of O.sel()) { let x = n; while (x && x.type !== 'frame' && model.parent(x) && !model.isPage(model.parent(x))) x = model.parent(x); if (x && x.type === 'frame') { f = x; break; } }
    const pg = model.page();
    if (!f) {
      const vr = V.viewRect();
      f = model.create('frame', { name: t('Фон'), w: 1920, h: 1080, m: M.translate(Math.round(vr.x + vr.w / 2 - 960), Math.round(vr.y + vr.h / 2 - 540)), fills: [O.paint.solid('#FFFFFF')], clip: true });
      model.insert(f, pg);
    }
    const old = f.children.find(c => c.bgOf);
    if (old) model.remove(old);
    const g = O.io.importSVG(BG.svg(id, Math.round(f.w), Math.round(f.h)), { container: f, noCenter: true, noCommit: true, keepGroup: true, name: t('Фон') });
    if (g) { f.children.splice(f.children.indexOf(g), 1); f.children.unshift(g); g.name = t('Фон') + ': ' + BG.label(BG.LIST.find(b => b.id === id)); g.locked = true; g.bgOf = id; }
    model.reindex();
    O.select([f.id]);
    O.history.commit('Фон');
    return f;
  };

  // ---------- gallery ----------
  let thumbN = 0;
  const thumb = (b, w = 160, h = 100) => BG.svg(b.id, 320, 200, 'bt' + (thumbN++)).replace('<svg ', `<svg class="bg-svg" preserveAspectRatio="xMidYMid slice" style="width:100%;height:auto;aspect-ratio:${w}/${h}" `).replace(/ width="\d+" height="\d+"/, '');
  BG.thumb = thumb;
  BG.open = () => {
    let style = 'all';
    const back = O.h(`<div class="tp-back"><div class="tp bg-dlg" role="dialog" aria-modal="true" aria-label="${esc(t('Фони'))}"><div class="tp-h"><h2>${esc(t('Фони'))}</h2><span class="dlg-text small">${esc(t('{n} фонів у {s} стилях. Клік — фон для виділеного фрейма (або нового).', { n: BG.LIST.length, s: STY.length }))}</span><span class="sp"></span><button type="button" class="ib" data-bga="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 16)}</button></div>
      <div class="bg-chips">${[['all', 'Усі']].concat(BG.STYLES).map(([k, n]) => `<button type="button" data-bgs="${k}" class="${k === style ? 'on' : ''}">${esc(t(n))}</button>`).join('')}</div><div class="tp-body"><div class="tp-grid rows bg-grid"></div></div></div></div>`);
    document.body.appendChild(back);
    const grid = back.querySelector('.bg-grid');
    const render = () => { grid.innerHTML = BG.LIST.filter(b => style === 'all' || b.style === style).map(b => `<button type="button" class="tp-card" data-bg="${b.id}" title="${esc(BG.label(b))}">${thumb(b)}<span class="tp-cap">${esc(BG.label(b))}</span></button>`).join(''); };
    render();
    const close = () => back.remove();
    back.addEventListener('click', e => {
      if (e.target === back) return close();
      const b = e.target.closest('[data-bg],[data-bgs],[data-bga]');
      if (!b) return;
      if (b.dataset.bga) return close();
      if (b.dataset.bgs) { style = b.dataset.bgs; back.querySelectorAll('[data-bgs]').forEach(x => x.classList.toggle('on', x === b)); render(); return; }
      close(); const f = BG.insert(b.dataset.bg); setTimeout(() => V.fit(model.worldBounds(f), 80, 1), 0);
    });
    back.addEventListener('keydown', e => { if (e.key === 'Escape') { e.stopPropagation(); close(); } });
  };
  O.cmd('backgrounds', 'Фони…', () => BG.open(), { group: 'Об’єкт' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл');
  if (fileMenu) { const i = fileMenu[1].indexOf('canvaTemplates'); fileMenu[1].splice(i < 0 ? 2 : i + 1, 0, 'backgrounds'); }
  const objMenu = O.MENUS.find(m => m[0] === 'Об’єкт');
  if (objMenu) objMenu[1].push('-', 'backgrounds');
})();
