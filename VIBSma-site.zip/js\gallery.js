'use strict';
/* VIBSma — template gallery in the spirit of Canva + Pinterest.
   · 100 design styles in four big groups (historical, modern, ethnic, mixed), each with a palette, a font pair and a
     visual motif; every style becomes a fully editable template in any format (post, story, A4, slide, card, website).
     The website format makes Desktop / Tablet / Mobile frames that are joined by «Перо адаптації» right away.
   · Pinterest: a masonry wall, search, «Зберегти» on boards, «Схожі» (more like this).
   · Own templates: save the selection as a template, upload template files (.obrystpl, .obrys, SVG, images),
     download them to share. They are kept in this browser (IndexedDB). */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui, V = O.view, M = O.M;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const GL = O.gallery = {};

  // ======================================================================
  // STYLES: [key, name, group, motif, variant, palette [bg, surface, ink, accent, accent 2], fonts [heading, text], description]
  // ======================================================================
  const RAW = [
    // ---- historical ----
    ['classic', 'Класичний', 'hist', 'ornate', 'frame', ['#F4EFE6', '#E6DCCB', '#2B2420', '#8C6D3F', '#5A2E2E'], ['Playfair Display', 'Lora'], 'Симетрія, стримана розкіш, ліпнина й благородні матеріали.'],
    ['artdeco', 'Арт-деко', 'hist', 'deco', 'fan', ['#111214', '#1D1E22', '#E8D9B5', '#C9A85A', '#0F5944'], ['Poiret One', 'Raleway'], 'Гламур 1920-х: золото, віяла, геометрія й контраст.'],
    ['baroque', 'Бароко', 'hist', 'ornate', 'baroque', ['#3B0F17', '#5A1A24', '#F2E3C6', '#C9A24A', '#7A2433'], ['Cormorant SC', 'Cormorant Garamond'], 'Монументальність, позолота, різьблення й драматизм.'],
    ['rococo', 'Рококо', 'hist', 'ornate', 'rococo', ['#F7E8EA', '#E8F0EA', '#5B4A52', '#D8A7B1', '#C9B26B'], ['Marck Script', 'Cormorant Garamond'], 'Пастель, мушлі й завитки, легка грайлива розкіш.'],
    ['english', 'Англійський', 'hist', 'ornate', 'frame', ['#1F3A2E', '#2C4A3B', '#F1EAD8', '#B08D57', '#6B3A2A'], ['Old Standard TT', 'PT Serif'], 'Традиції, темне дерево, бібліотечний затишок.'],
    ['empire', 'Ампір', 'hist', 'ornate', 'empire', ['#F3EEE4', '#E4D9C4', '#1F2A4A', '#A3262A', '#C9A24A'], ['Prata', 'Cormorant Garamond'], 'Парадність, імперські мотиви, червоне, синє й золото.'],
    ['artnouveau', 'Модерн (ар-нуво)', 'hist', 'nouveau', 'vine', ['#EFE6D2', '#DCCFB1', '#3D3A2A', '#7A8B4F', '#C27A4E'], ['Forum', 'Lora'], 'Плавні рослинні лінії, батоги й квіткові рами.'],
    ['victorian', 'Вікторіанський', 'hist', 'ornate', 'frame', ['#2A1A2E', '#3D2742', '#EBDDC8', '#B8935A', '#7C3A4F'], ['Playfair Display SC', 'Lora'], 'Насичені кольори, орнаментні рамки, романтика XIX століття.'],
    ['gothic', 'Готика', 'hist', 'ornate', 'gothic', ['#141214', '#24202A', '#E6DED2', '#8E1B24', '#6E6A78'], ['Ruslan Display', 'EB Garamond'], 'Стрілчасті арки, вітражі, темна величність.'],
    ['renaissance', 'Ренесанс', 'hist', 'ornate', 'arch', ['#EAD9BF', '#D9C3A0', '#3A2A1E', '#A5512E', '#5E6B3A'], ['Cormorant SC', 'EB Garamond'], 'Гармонія пропорцій, арки, теплі земляні фарби.'],
    ['antique', 'Античний', 'hist', 'ornate', 'meander', ['#F5F1EA', '#E8E0D2', '#2A2724', '#B2502F', '#2A2724'], ['Forum', 'Alice'], 'Грецький меандр, колони, теракота й мармур.'],
    ['egyptian', 'Єгипетський', 'hist', 'ornate', 'meander', ['#E9D8A6', '#D9C285', '#1E2B4F', '#1F5FAF', '#C08A2D'], ['Kelly Slab', 'PT Sans'], 'Пісок, лазурит і золото, строгі фризи.'],
    ['medieval', 'Середньовічний', 'hist', 'ornate', 'medieval', ['#EDE0C4', '#DDCBA4', '#2F2418', '#A12A22', '#2B4C8C'], ['Ruslan Display', 'Old Standard TT'], 'Рукописи, буквиці, пергамент і геральдика.'],
    ['byzantine', 'Візантійський', 'hist', 'pattern', 'mosaic', ['#1B1A3A', '#2A2856', '#F1E3B8', '#D4AF37', '#8E2B3A'], ['Prata', 'Spectral'], 'Золота мозаїка, глибокий синій, сакральна велич.'],
    ['bauhaus', 'Баугауз', 'hist', 'geo', 'bauhaus', ['#F2EBDD', '#E3D9C5', '#161616', '#D7372B', '#F2C230'], ['Rubik Mono One', 'Rubik'], 'Коло, квадрат, трикутник і основні кольори.'],
    ['constructivism', 'Конструктивізм', 'hist', 'geo', 'construct', ['#EFE6D3', '#E0D3B8', '#141414', '#C8261E', '#141414'], ['Russo One', 'Roboto Condensed'], 'Діагоналі, червоне й чорне, агітаційна енергія.'],
    ['swiss', 'Швейцарський стиль', 'hist', 'swiss', 'swiss', ['#FFFFFF', '#F2F2F2', '#111111', '#E30613', '#111111'], ['Inter Tight', 'Inter'], 'Модульна сітка, гротеск, чистота й порядок.'],
    ['midcentury', 'Модерн середини століття', 'hist', 'retro', 'mid', ['#F1E6D0', '#E5D5B5', '#2A2522', '#D98E32', '#2E6E6A'], ['Comfortaa', 'Nunito'], 'Бумеранги, гірчичний і бірюзовий, оптимізм 1950-х.'],
    ['retro70', 'Ретро 70-х', 'hist', 'retro', 'sun', ['#F4E3C3', '#EBCF9E', '#3B2414', '#D8642B', '#E3A33A'], ['Lobster', 'Nunito'], 'Смуги-веселки, теплі відтінки, округлі шрифти.'],
    ['pop', 'Поп-арт', 'hist', 'pattern', 'dots', ['#FFE14D', '#FFFFFF', '#111111', '#E6332A', '#1F6FD1'], ['Rubik Mono One', 'Montserrat'], 'Комікси, растрові крапки, яскраві плоскі кольори.'],
    ['psychedelic', 'Психоделія 60-х', 'hist', 'organic', 'waves', ['#2B0F4A', '#4A1A73', '#FFE6F2', '#FF5FA2', '#FF9F1C'], ['Pacifico', 'Comfortaa'], 'Хвилі, кислотні кольори, текучі форми.'],
    ['artsandcrafts', 'Мистецтва і ремесла', 'hist', 'nouveau', 'floral', ['#E9E2CF', '#D6CCB0', '#2E3A26', '#7F8F4E', '#A4512E'], ['Cormorant Garamond', 'Lora'], 'Ручна робота, рослинні візерунки, природні фарби.'],
    ['destijl', 'Де Стейл', 'hist', 'geo', 'mondrian', ['#FFFFFF', '#F5F5F5', '#111111', '#E10600', '#0047AB'], ['Rubik Mono One', 'Inter'], 'Прямокутники Мондріана, чорні лінії, основні кольори.'],
    ['futurism', 'Футуризм', 'hist', 'geo', 'speed', ['#ECE8E1', '#D9D3C9', '#141414', '#D7262B', '#6E6E6E'], ['Russo One', 'Exo 2'], 'Швидкість, рух, динамічні лінії.'],
    ['streamline', 'Стрімлайн-модерн', 'hist', 'deco', 'stream', ['#F1E9DA', '#E1D6C2', '#22313A', '#2E7C83', '#C27B45'], ['Poiret One', 'Raleway'], 'Обтічні форми, горизонтальні смуги, хром 1930-х.'],
    // ---- modern ----
    ['minimal', 'Мінімалізм', 'modern', 'minimal', 'light', ['#F6F5F2', '#ECEAE5', '#1C1C1C', '#1C1C1C', '#BDB6AC'], ['Manrope', 'Manrope'], 'Прості форми, багато повітря, нейтральні кольори.'],
    ['scandi', 'Скандинавський', 'modern', 'organic', 'soft', ['#FBFAF7', '#EDE7DE', '#2E3134', '#A7B8A8', '#E2C9A0'], ['Nunito', 'Nunito Sans'], 'Світлі тони, натуральне дерево, затишок хюґе.'],
    ['loft', 'Лофт', 'modern', 'industrial', 'brick', ['#2B2B2D', '#3A3A3D', '#EDE7DF', '#B5582F', '#8C8C8C'], ['Oswald', 'Roboto'], 'Цегла, бетон, метал і відкритий простір.'],
    ['hitech', 'Хай-тек', 'modern', 'tech', 'circuit', ['#0E1116', '#171C24', '#E8EEF5', '#0DA2FF', '#6C7480'], ['Exo 2', 'Roboto'], 'Чітка геометрія, монохром, технології.'],
    ['contemporary', 'Контемпорарі', 'modern', 'organic', 'arch', ['#EEE9E2', '#DDD3C6', '#25231F', '#7B8B74', '#C8B9A6'], ['Onest', 'Onest'], 'Сучасний комфорт, м’які лінії, нейтральна база.'],
    ['eco', 'Еко-стиль', 'modern', 'organic', 'leaves', ['#EEF0E2', '#DCE3C8', '#26331F', '#5E8C4A', '#C9A37A'], ['Comfortaa', 'Nunito'], 'Природні фактури, зелень, земляні тони.'],
    ['wabisabi', 'Вабі-сабі', 'modern', 'organic', 'stone', ['#E8DFD1', '#D6C8B4', '#3A332B', '#8F7E69', '#B9A68C'], ['Cormorant Garamond', 'Manrope'], 'Краса неідеального: глина, тиша, спокій.'],
    ['japandi', 'Жапанді', 'modern', 'japanese', 'japandi', ['#F1ECE4', '#E2D9CC', '#2B2925', '#5E6B5A', '#C2A27C'], ['Spectral', 'Manrope'], 'Японська простота й скандинавський затишок.'],
    ['flat', 'Флет-дизайн', 'modern', 'geo', 'flat', ['#FFFFFF', '#F1F4FA', '#1B2340', '#3D7BFF', '#FFB020'], ['Rubik', 'Rubik'], 'Плоскі кольори, прості фігури, без тіней.'],
    ['material', 'Матеріал-дизайн', 'modern', 'cards', 'material', ['#F5F5F7', '#FFFFFF', '#1F1F24', '#6750A4', '#00897B'], ['Roboto', 'Roboto'], 'Картки, глибина, чіткі стани й тіні.'],
    ['neumorph', 'Неоморфізм', 'modern', 'soft', 'neu', ['#E6E9EF', '#E6E9EF', '#3B4252', '#5E81AC', '#A3BE8C'], ['Manrope', 'Manrope'], 'М’які опуклі форми з світла й тіні.'],
    ['glass', 'Глассморфізм', 'modern', 'glass', 'glass', ['#1A1B3A', '#FFFFFF', '#FFFFFF', '#7B61FF', '#00D1FF'], ['Unbounded', 'Manrope'], 'Матове скло над яскравими градієнтами.'],
    ['neobrutal', 'Необруталізм', 'modern', 'brutal', 'neo', ['#FFF4D6', '#FFFFFF', '#111111', '#FF6B6B', '#4D96FF'], ['Unbounded', 'Rubik'], 'Товсті контури, зсунуті тіні, сміливі кольори.'],
    ['brutalism', 'Бруталізм', 'modern', 'brutal', 'raw', ['#E9E9E4', '#FFFFFF', '#0A0A0A', '#0A0A0A', '#FF3B00'], ['Rubik Mono One', 'Roboto Mono'], 'Сира структура, моноширинний шрифт, чесність.'],
    ['cyberpunk', 'Кіберпанк', 'modern', 'neon', 'cyber', ['#0B0614', '#170C2A', '#F2F2FF', '#FF2E88', '#00F0FF'], ['Tektur', 'Jura'], 'Неон, глітч і нічне місто майбутнього.'],
    ['synthwave', 'Синтвейв', 'modern', 'neon', 'synth', ['#120A2A', '#24104A', '#FFFFFF', '#FF4FB3', '#FFB800'], ['Russo One', 'Exo 2'], 'Захід сонця 80-х, неонова сітка, ретрохвиля.'],
    ['vaporwave', 'Вейпорвейв', 'modern', 'neon', 'vapor', ['#FBD3E9', '#BBA7F0', '#2B1E4A', '#58C9E8', '#FF71CE'], ['Unbounded', 'Comfortaa'], 'Пастельний неон, шахова підлога, ностальгія.'],
    ['y2k', 'Y2K', 'modern', 'glass', 'y2k', ['#DCE6F5', '#FFFFFF', '#14172B', '#B7C3D9', '#FF5FD2'], ['Unbounded', 'Manrope'], 'Хром, бульбашки й оптимізм 2000-х.'],
    ['aurora', 'Аврора-градієнти', 'modern', 'glass', 'aurora', ['#07131F', '#FFFFFF', '#FFFFFF', '#2EE6A6', '#7B5CFF'], ['Inter Tight', 'Inter'], 'Сяйво кольорів, що перетікають у темряві.'],
    ['darkmode', 'Темний преміум', 'modern', 'minimal', 'dark', ['#0F0F11', '#1A1A1E', '#F4F4F6', '#8E8EFF', '#2A2A30'], ['Inter Tight', 'Inter'], 'Глибокий темний фон, тонкі акценти.'],
    ['luxury', 'Люкс', 'modern', 'minimal', 'lux', ['#0D0D0D', '#1A1A1A', '#F2EBDD', '#C8A96A', '#3A3A3A'], ['Tenor Sans', 'Cormorant Garamond'], 'Чорне й золото, простір і витончена типографіка.'],
    ['corporate', 'Корпоративний', 'modern', 'swiss', 'corp', ['#FFFFFF', '#EFF4FB', '#0F1E3A', '#1F5EFF', '#14B8A6'], ['Golos Text', 'Golos Text'], 'Надійність, сітка, синій і чіткі дані.'],
    ['startup', 'Стартап / SaaS', 'modern', 'glass', 'light', ['#F7F6FF', '#FFFFFF', '#16123A', '#6C4CFF', '#FF7AB6'], ['Onest', 'Inter'], 'Світлі градієнти, картки продукту, енергія.'],
    ['isometric', 'Ізометрія', 'modern', 'tech', 'iso', ['#F3F6FF', '#E3EAFB', '#1C2440', '#5B7CFA', '#FFB547'], ['Play', 'Rubik'], 'Об’ємні кубики під кутом 30°.'],
    ['lineart', 'Лайн-арт', 'modern', 'line', 'line', ['#FBF8F2', '#F1EADF', '#1E1E1E', '#1E1E1E', '#E07A5F'], ['Philosopher', 'Manrope'], 'Одна безперервна лінія, мінімум засобів.'],
    ['duotone', 'Дуотон', 'modern', 'duotone', 'duo', ['#1E2A78', '#FF5E5B', '#FFFFFF', '#FF5E5B', '#1E2A78'], ['Oswald', 'Montserrat'], 'Два кольори, сильний контраст, графічність.'],
    ['editorial', 'Едиторіал', 'modern', 'editorial', 'light', ['#F6F3EE', '#ECE6DD', '#141414', '#B23A2C', '#141414'], ['Playfair Display', 'Source Serif 4'], 'Журнальна верстка, колонки, великі заголовки.'],
    ['typographic', 'Типографічний', 'modern', 'type', 'type', ['#F2F0EB', '#E4E1D9', '#121212', '#FF4A1C', '#121212'], ['Unbounded', 'Inter'], 'Літери як головний образ.'],
    ['maximal', 'Максималізм', 'modern', 'collage', 'max', ['#7A1F3D', '#0F5944', '#FFF3D6', '#E2B34C', '#E05A9C'], ['Yeseva One', 'Montserrat'], '«Більше — це більше»: колір, шари, візерунки.'],
    ['pastel', 'Пастельний', 'modern', 'soft', 'pastel', ['#FFF4EC', '#FDE2E4', '#4A3F55', '#B8E0D2', '#F6C6EA'], ['Comfortaa', 'Nunito'], 'Ніжні відтінки, округлі форми, легкість.'],
    ['monochrome', 'Монохром', 'modern', 'minimal', 'mono', ['#FFFFFF', '#EDEDED', '#000000', '#000000', '#8A8A8A'], ['Inter Tight', 'Inter'], 'Лише чорне, біле й сірі.'],
    ['gradient', 'Яскраві градієнти', 'modern', 'glass', 'grad', ['#FF5F6D', '#FFFFFF', '#FFFFFF', '#FFC371', '#7F00FF'], ['Unbounded', 'Inter'], 'Соковиті переходи кольорів на весь фон.'],
    ['pixel', 'Піксель-арт', 'modern', 'pixel', 'pixel', ['#1B1C3A', '#2A2C5C', '#F8F8F8', '#FF4F79', '#52E3A4'], ['Press Start 2P', 'Roboto Mono'], '8-бітна графіка й ігрова ностальгія.'],
    ['claymorph', 'Клейморфізм', 'modern', 'soft', 'clay', ['#F3EDFF', '#FFFFFF', '#2D2459', '#8C6CFF', '#FF9EC4'], ['Rubik', 'Nunito'], 'Пухкі «пластилінові» об’ємні форми.'],
    ['organic', 'Органічний модерн', 'modern', 'organic', 'blob', ['#F2EADF', '#E3D5C2', '#2F2A24', '#C46B43', '#7A8C5E'], ['Spectral', 'Manrope'], 'Плавні природні форми й теплі тони.'],
    // ---- ethnic ----
    ['provence', 'Прованс', 'ethnic', 'nouveau', 'floral', ['#F6F1E7', '#EAE1F2', '#4E4459', '#9C86C4', '#C9D6C2'], ['Marck Script', 'Lora'], 'Лаванда, пастель, квіткові мотиви французького села.'],
    ['country', 'Кантрі', 'ethnic', 'pattern', 'plaid', ['#F3E9D4', '#E5D3AE', '#3A2A1C', '#8E2B24', '#1F3B2D'], ['Kelly Slab', 'PT Serif'], 'Клітинка, грубе дерево, заміський затишок.'],
    ['boho', 'Бохо', 'ethnic', 'organic', 'boho', ['#F1E4D0', '#E5CFAF', '#4A2C1D', '#C46B43', '#D9A441'], ['Amatic SC', 'Nunito'], 'Творчий мікс етніки, вінтажу й текстилю.'],
    ['japanese', 'Японський', 'ethnic', 'japanese', 'sun', ['#F5F1E8', '#E9E2D2', '#1F1D1A', '#C8102E', '#1F1D1A'], ['Spectral', 'Manrope'], 'Червоне сонце, тиша, мінімум речей.'],
    ['chinese', 'Китайський', 'ethnic', 'japanese', 'moon', ['#8E1414', '#A51E1E', '#F7E7C4', '#E3B341', '#1F1A17'], ['Prata', 'PT Sans'], 'Червоне й золото, місячна брама, символи щастя.'],
    ['moroccan', 'Марокканський', 'ethnic', 'pattern', 'zellige', ['#F4ECDD', '#E8D8BC', '#23364A', '#1F6F8B', '#C8553D'], ['Forum', 'Alice'], 'Арки, плитка зелліж, синій і теракота.'],
    ['indian', 'Індійський', 'ethnic', 'pattern', 'mandala', ['#FDF2E0', '#F7DDB1', '#4A1D1F', '#E2692B', '#B8235A'], ['Yeseva One', 'Philosopher'], 'Мандали, шафран і фуксія, святкове багатство.'],
    ['african', 'Африканський', 'ethnic', 'pattern', 'kente', ['#F2E2C4', '#E5C892', '#2A1A10', '#C2410C', '#166534'], ['Russo One', 'Ubuntu'], 'Кенте, земляні кольори, ритмічні орнаменти.'],
    ['mexican', 'Мексиканський', 'ethnic', 'pattern', 'fiesta', ['#FFF7EA', '#FFE3C2', '#2A1A3A', '#E83F6F', '#2BB3A3'], ['Lobster', 'Rubik'], 'Папель пікадо, яскраві кольори фієсти.'],
    ['ukrainian', 'Український (вишиванка)', 'ethnic', 'pattern', 'stitch', ['#FFFFFF', '#F6F1EA', '#141414', '#C1121F', '#141414'], ['Yeseva One', 'PT Serif'], 'Червоно-чорна вишивка хрестиком, ромби й обереги.'],
    ['petrykivka', 'Петриківський розпис', 'ethnic', 'nouveau', 'petryk', ['#141414', '#1F1F1F', '#F6EBD9', '#E23B2E', '#F2B705'], ['Marck Script', 'Lora'], 'Українські квіти-мазки на темному тлі.'],
    ['nordic', 'Нордичний фольклор', 'ethnic', 'pattern', 'knit', ['#F4F6F8', '#E3E9EF', '#1D2B3A', '#B3262E', '#1D2B3A'], ['Philosopher', 'Nunito'], 'В’язані зірки, сніжинки, червоне на білому.'],
    ['mediterranean', 'Середземноморський', 'ethnic', 'ornate', 'arch', ['#F8F6F0', '#E7EEF3', '#1E3A5F', '#2E7D8C', '#E8C766'], ['Forum', 'Manrope'], 'Білі стіни, арки, синє море й сонце.'],
    ['tropical', 'Тропічний', 'ethnic', 'organic', 'leaves', ['#F3F1E4', '#DDE8D2', '#14301F', '#2F7D4A', '#F28C38'], ['Pacifico', 'Nunito'], 'Пальмове листя, соковиті фрукти, літо.'],
    ['aztec', 'Ацтекський', 'ethnic', 'pattern', 'zigzag', ['#F1E1C6', '#E2C79A', '#2B1B12', '#B4432B', '#1E6E6A'], ['Russo One', 'PT Sans'], 'Ступінчасті зигзаги, теракота й бірюза.'],
    ['maori', 'Маорі та Полінезія', 'ethnic', 'pattern', 'koru', ['#F2EEE6', '#E1D8C9', '#141414', '#A33A2B', '#141414'], ['Philosopher', 'Ubuntu'], 'Спіралі кору, татау, сила ліній.'],
    ['arabic', 'Арабеска', 'ethnic', 'pattern', 'zellige', ['#0E3B43', '#14505B', '#F4E9D3', '#D4AF37', '#1B7F79'], ['Prata', 'Alice'], 'Нескінченні геометричні зірки й золото.'],
    ['turkish', 'Турецький (кілім)', 'ethnic', 'pattern', 'kilim', ['#F6EADA', '#ECD4B3', '#2E1A14', '#B33A3A', '#1F4E79'], ['Yeseva One', 'Alice'], 'Кілімні ромби, гранат і індиго.'],
    ['nautical', 'Морський', 'ethnic', 'pattern', 'stripes', ['#F7F5EF', '#E3EAF2', '#13294B', '#1F3A5F', '#D24A3C'], ['Lobster', 'PT Sans'], 'Тільняшка, синій і білий, морський бриз.'],
    ['chalet', 'Шале', 'ethnic', 'pattern', 'plaid', ['#3A2618', '#4E3423', '#F3E9DA', '#B5482F', '#E9E1D2'], ['Kelly Slab', 'PT Serif'], 'Гірський будиночок: дерево, вовна, камін.'],
    ['korean', 'Корейський', 'ethnic', 'japanese', 'korean', ['#FBF7F2', '#F1E6EF', '#2E2A33', '#E7A1B0', '#7FA8C9'], ['Manrope', 'Nunito'], 'Папір ханджі, ніжні кольори, ясність.'],
    ['safari', 'Сафарі', 'ethnic', 'organic', 'safari', ['#EADBC0', '#D8C29A', '#2C2218', '#B8742A', '#556B2F'], ['Oswald', 'PT Sans'], 'Савана, хакі, плями й трави.'],
    // ---- mixed ----
    ['eclectic', 'Еклектика', 'mixed', 'collage', 'eclectic', ['#F2E9DA', '#E3D2B8', '#1F1A17', '#2E5A73', '#C96F4A'], ['Yeseva One', 'Montserrat'], 'Поєднання епох, кольорів і фактур.'],
    ['fusion', 'Ф’южн', 'mixed', 'collage', 'fusion', ['#2E5A73', '#C96F4A', '#F1E4D0', '#E2B34C', '#7A1F3D'], ['Unbounded', 'Raleway'], 'Сміливий мікс культур і контрастів.'],
    ['transitional', 'Перехідний стиль', 'mixed', 'editorial', 'trans', ['#F3F0EA', '#E6E0D6', '#2A2724', '#8A7A64', '#A99B86'], ['Prata', 'Manrope'], 'Класика й сучасність у спокійному балансі.'],
    ['neoclassic', 'Неокласика', 'mixed', 'ornate', 'light', ['#F3EFE8', '#E4DCCF', '#3F3A35', '#C9A85A', '#8BA0A6'], ['Cormorant SC', 'Montserrat'], 'Класичні рами в легкому сучасному прочитанні.'],
    ['modernclassic', 'Сучасна класика', 'mixed', 'ornate', 'thin', ['#FFFFFF', '#F2EEE8', '#1E1E1E', '#B89B5E', '#1E1E1E'], ['Playfair Display', 'Manrope'], 'Тонкі лінії, серифи й багато білого.'],
    ['grunge', 'Гранж', 'mixed', 'collage', 'grunge', ['#1B1A17', '#2A2824', '#E8E2D5', '#8C6A3E', '#6B6B6B'], ['Oswald', 'Roboto Mono'], 'Потерті фактури, скотч, андеграунд 90-х.'],
    ['punk', 'Панк-зін', 'mixed', 'collage', 'punk', ['#F4F1EA', '#FFFFFF', '#0B0B0B', '#FF2D55', '#FFE600'], ['Rubik Mono One', 'Roboto Mono'], 'Вирізки, ксерокс, крик і бунт.'],
    ['dada', 'Дадаїзм', 'mixed', 'collage', 'dada', ['#EFE7D6', '#E0D4BB', '#141414', '#C8261E', '#2B4C8C'], ['Russo One', 'Old Standard TT'], 'Абсурдний колаж зі шрифтів і фігур.'],
    ['kitsch', 'Кітч', 'mixed', 'collage', 'kitsch', ['#FFD6E8', '#FFF3B0', '#3A1442', '#FF4FA3', '#3EC1D3'], ['Lobster', 'Comfortaa'], 'Навмисний надмір, рожевий і блиск.'],
    ['cottagecore', 'Котеджкор', 'mixed', 'nouveau', 'floral', ['#F6F0E1', '#EDE3CB', '#3F4A33', '#C98F8F', '#7E9C6C'], ['Bad Script', 'Lora'], 'Польові квіти, випічка, сільська ідилія.'],
    ['darkacademia', 'Темна академія', 'mixed', 'editorial', 'dark', ['#2A231C', '#3A3027', '#E9DEC8', '#9C7A4D', '#5C3A2E'], ['Old Standard TT', 'EB Garamond'], 'Старі бібліотеки, твід, свічки й поезія.'],
    ['steampunk', 'Стімпанк', 'mixed', 'gears', 'gears', ['#2B1F14', '#3E2D1D', '#F0DEC0', '#C08A3E', '#7A5230'], ['Kelly Slab', 'Old Standard TT'], 'Латунь, шестерні, вікторіанська механіка.'],
    ['solarpunk', 'Соларпанк', 'mixed', 'organic', 'sun', ['#EFF6E8', '#DCEBCF', '#1F3A24', '#3FA34D', '#F2B33D'], ['Comfortaa', 'Nunito'], 'Зелене майбутнє: сонце, рослини, оптимізм.'],
    ['afrofuturism', 'Афрофутуризм', 'mixed', 'neon', 'afro', ['#140B26', '#24123D', '#FFF3E0', '#F2A900', '#9B5DE5'], ['Unbounded', 'Ubuntu'], 'Космос і африканські орнаменти.'],
    ['retrofuturism', 'Ретрофутуризм', 'mixed', 'retro', 'space', ['#0F1B3A', '#1C2E5C', '#FFF4E0', '#FF7A3D', '#5FD3F3'], ['Russo One', 'Exo 2'], 'Майбутнє очима минулого: ракети й планети.'],
    ['memphis', 'Мемфіс', 'mixed', 'geo', 'memphis', ['#FFFBF0', '#FFFFFF', '#141414', '#FF5CA8', '#00C2D1'], ['Rubik Mono One', 'Rubik'], 'Конфеті-фігури, зигзаги, 80-ті.'],
    ['surreal', 'Сюрреалізм', 'mixed', 'glass', 'surreal', ['#BFD7EA', '#F2E9E4', '#1D2A3A', '#F28F3B', '#5C80BC'], ['Spectral', 'Manrope'], 'Сни, дивні простори й плаваючі об’єкти.'],
    ['softloft', 'М’який лофт', 'mixed', 'industrial', 'soft', ['#EDE8E2', '#DCD3C9', '#2A2826', '#A86B4C', '#7E7A74'], ['Oswald', 'Manrope'], 'Індустріальні лінії в теплих світлих тонах.']
  ];
  GL.GROUPS = { hist: 'Історичні', modern: 'Сучасні', ethnic: 'Етнічні', mixed: 'Змішані' };
  GL.STYLES = RAW.map(([k, n, g, m, v, pal, f, d], i) => ({ k, n, g, gname: GL.GROUPS[g], m, v, pal, f, d, i }));
  const byKey = new Map(GL.STYLES.map(s => [s.k, s]));
  GL.get = k => byKey.get(k);
  // the hand-made 100; the template catalogue picks its styles from these (xstyles.js adds 10 000 more)
  GL.CORE = GL.STYLES.slice();
  GL.addStyles = list => list.forEach(s => { s.i = GL.STYLES.length; s.gname = GL.GROUPS[s.g]; GL.STYLES.push(s); byKey.set(s.k, s); });
  const norm = s => String(s || '').toLowerCase().replace(/[’'`ʼ]/g, '');
  // the words a style is found by, per interface language
  const hayOf = s => {
    if (!s.hay || s.hay[0] !== O.lang) s.hay = [O.lang, [t(s.n), s.n, t(s.d), t(s.gname), O.tIn('en', s.n), s.k, s.f.join(' ')].map(norm)];
    return s.hay[1];
  };
  GL.search = (q, limit = 100) => {
    q = norm(q);
    const out = [];
    for (const s of GL.STYLES) {
      if (!q) { out.push(Object.assign({ sc: 1 }, s)); continue; }
      const hay = hayOf(s);
      let sc = 0;
      hay.forEach((h, i) => { if (h.startsWith(q)) sc = Math.max(sc, 100 - i * 5); else if (h.includes(q)) sc = Math.max(sc, 60 - i * 5); });
      if (sc) out.push(Object.assign({ sc }, s));
    }
    return out.sort((a, b) => b.sc - a.sc).slice(0, limit);
  };

  // ======================================================================
  // FORMATS
  // ======================================================================
  GL.FORMATS = [['post', 'Пост Instagram', 1080, 1350], ['square', 'Квадрат', 1080, 1080], ['story', 'Story / Reels', 1080, 1920], ['a4', 'Постер A4', 595, 842], ['slide', 'Презентація 16:9', 1920, 1080], ['card', 'Візитка', 1050, 600], ['web', 'Сайт: десктоп, планшет, мобільний', 1440, 1024]];
  GL.WEB = [['Десктоп', 1440, 1024], ['iPad вертикально', 768, 1024], ['iPhone 14/15', 390, 844]];
  const fmtOf = k => GL.FORMATS.find(f => f[0] === k) || GL.FORMATS[0];
  // Pinterest-like wall: a mix of formats
  const MIX = ['post', 'story', 'square', 'a4', 'post', 'slide', 'square', 'story'];
  GL.mixFormat = st => MIX[st.i % MIX.length];

  // ======================================================================
  // SVG GENERATOR
  // ======================================================================
  const q = v => Math.round(v * 10) / 10;
  const attrs = o => Object.entries(o).filter(([, v]) => v !== undefined && v !== null && v !== false && v !== '').map(([k, v]) => `${k}="${esc(typeof v === 'number' ? q(v) : v)}"`).join(' ');
  const rngOf = key => { let s = 7; for (const ch of key) s = (s * 31 + ch.charCodeAt(0)) >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; };
  const hexRgb = h => { const c = O.color.parse(h) || { r: 0, g: 0, b: 0 }; return c; };
  const mixC = (a, b, k) => O.color.mix(a, b, k);
  const lum = h => O.color.luminance(h);
  const onColor = h => (lum(h) > 0.62 ? '#151413' : '#FFFFFF');
  // average glyph width (in em) of the heading fonts, for wrapping and fitting
  const WIDTH = { 'Rubik Mono One': 0.8, 'Unbounded': 0.68, 'Russo One': 0.62, 'Press Start 2P': 1.0, 'Tektur': 0.58, 'Exo 2': 0.55, 'Oswald': 0.44, 'Amatic SC': 0.36, 'Poiret One': 0.52, 'Comfortaa': 0.6, 'Ruslan Display': 0.72, 'Yeseva One': 0.6, 'Kelly Slab': 0.56, 'Lobster': 0.48, 'Pacifico': 0.6, 'Marck Script': 0.44, 'Bad Script': 0.48, 'Cormorant SC': 0.6, 'Cormorant Garamond': 0.46, 'Playfair Display SC': 0.66, 'Tenor Sans': 0.58, 'Forum': 0.52, 'Prata': 0.6, 'Old Standard TT': 0.55, 'Roboto Condensed': 0.46, 'Roboto Mono': 0.6, 'Play': 0.55,
    'Dela Gothic One': 0.74, 'Rubik Glitch': 0.64, 'Rubik Spray Paint': 0.64, 'Montserrat Alternates': 0.64, 'Geologica': 0.58, 'Sofia Sans Condensed': 0.42, 'JetBrains Mono': 0.6, 'IBM Plex Mono': 0.6, 'Alegreya SC': 0.62, 'Oranienbaum': 0.48, 'Kurale': 0.55, 'Marmelad': 0.56, 'Pangolin': 0.55, 'El Messiri': 0.52, 'Neucha': 0.48, 'Literata': 0.56, 'Ysabeau': 0.5, 'Wix Madefor Display': 0.58, 'Commissioner': 0.56 };
  const gw = fam => WIDTH[fam] || 0.56;
  const wrap = (str, size, maxW, k) => {
    if (!maxW) return [str];
    const max = Math.max(3, Math.floor(maxW / (size * k)));
    const lines = [];
    let cur = '';
    for (const w of String(str).split(/\s+/)) { if (!cur) cur = w; else if ((cur + ' ' + w).length <= max) cur += ' ' + w; else { lines.push(cur); cur = w; } }
    if (cur) lines.push(cur);
    return lines;
  };

  const ctxOf = (st, W, H, opts = {}) => {
    const [bg, sf, ink, a1, a2] = st.pal;
    const u = Math.min(W, H) / 100;
    const wide = W / H > 1.15;
    const top = opts.web ? Math.max(u * 11, 64 * Math.min(1, W / 1440) + 20) : 0;
    const c = { st, W, H, u, wide, top, web: !!opts.web, dev: opts.dev || '', bgc: bg, sf, ink, a1, a2, ink2: mixC(ink, bg, 0.28), fh: st.f[0], fb: st.f[1], r: rngOf(st.k), defs: [], gid: 0 };
    if (wide) { c.art = { x: W * 0.55, y: top + H * 0.1, w: W * 0.37, h: H * 0.8 - top }; c.tr = { x: W * 0.08, y: top + (H - top) * 0.2, w: W * 0.42 }; }
    else { const ah = (H - top) * (H / W > 1.5 ? 0.42 : H / W > 1.1 ? 0.36 : 0.34); c.art = { x: W * 0.1, y: top + H * 0.07, w: W * 0.8, h: ah }; c.tr = { x: W * 0.1, y: c.art.y + c.art.h + H * 0.05, w: W * 0.8 }; }
    c.txt = opts.txt || { kicker: t(st.gname) + ' · ' + t('стиль'), title: t(st.n), sub: t(st.d), cta: t('Детальніше'), brand: t('Студія'), menu: t('Про нас     Послуги     Контакти') };
    c.titleSize = wide ? H * 0.085 : W * 0.095;
    return c;
  };
  // primitives (id = layer name)
  const R = (id, x, y, w, h, o = {}) => `<rect ${attrs({ id, x, y, width: Math.max(0.5, w), height: Math.max(0.5, h), rx: o.rx, fill: o.fill || 'none', stroke: o.stroke, 'stroke-width': o.sw, opacity: o.op, 'fill-opacity': o.fop, 'stroke-dasharray': o.dash, transform: o.rot ? `rotate(${q(o.rot)} ${q(x + w / 2)} ${q(y + h / 2)})` : o.tf })}/>`;
  const C = (id, cx, cy, r, o = {}) => `<circle ${attrs({ id, cx, cy, r: Math.max(0.5, r), fill: o.fill || 'none', stroke: o.stroke, 'stroke-width': o.sw, opacity: o.op, 'fill-opacity': o.fop, 'stroke-dasharray': o.dash })}/>`;
  const E = (id, cx, cy, rx, ry, o = {}) => `<ellipse ${attrs({ id, cx, cy, rx, ry, fill: o.fill || 'none', stroke: o.stroke, 'stroke-width': o.sw, opacity: o.op, transform: o.rot ? `rotate(${q(o.rot)} ${q(cx)} ${q(cy)})` : undefined })}/>`;
  const P = (id, d, o = {}) => `<path ${attrs({ id, d, fill: o.fill || 'none', stroke: o.stroke, 'stroke-width': o.sw, 'stroke-linecap': o.cap, 'stroke-linejoin': o.join, opacity: o.op, 'fill-opacity': o.fop, 'fill-rule': o.rule, transform: o.tf })}/>`;
  const Ln = (id, x1, y1, x2, y2, o = {}) => `<line ${attrs({ id, x1, y1, x2, y2, stroke: o.stroke, 'stroke-width': o.sw, 'stroke-linecap': o.cap || 'round', opacity: o.op, 'stroke-dasharray': o.dash })}/>`;
  const Pg = (id, pts, o = {}) => `<polygon ${attrs({ id, points: pts.map(p => q(p[0]) + ',' + q(p[1])).join(' '), fill: o.fill || 'none', stroke: o.stroke, 'stroke-width': o.sw, 'stroke-linejoin': o.join, opacity: o.op, transform: o.tf })}/>`;
  const Gp = (id, inner, o = {}) => `<g ${attrs({ id, transform: o.tf, opacity: o.op })}>${inner}</g>`;
  const grad = (c, stops, x1 = 0, y1 = 0, x2 = 0, y2 = 1, radial) => {
    const id = 'gl_' + c.st.k + '_' + (c.gid++);
    const st = stops.map((s, i) => `<stop offset="${Array.isArray(s) ? s[1] : i / Math.max(1, stops.length - 1)}" stop-color="${Array.isArray(s) ? s[0] : s}"${Array.isArray(s) && s[2] !== undefined ? ` stop-opacity="${s[2]}"` : ''}/>`).join('');
    c.defs.push(radial ? `<radialGradient id="${id}" cx="${x1}" cy="${y1}" r="${x2}">${st}</radialGradient>` : `<linearGradient id="${id}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}">${st}</linearGradient>`);
    return `url(#${id})`;
  };
  const Tx = (c, id, str, x, y, size, o = {}) => {
    const fam = o.family || c.fb;
    const k = gw(fam) * (o.upper ? 1.12 : 1) + (o.ls ? o.ls / size : 0);
    const s = o.upper ? String(str).toUpperCase() : String(str);
    const lines = o.maxW ? wrap(s, size, o.maxW, k) : [s];
    const lh = o.lh || 1.2;
    const a = attrs({ id, 'data-lh': lines.length > 1 ? lh : undefined, x, y, 'font-family': `'${fam}', sans-serif`, 'font-size': size, 'font-weight': o.weight || 400, 'font-style': o.italic ? 'italic' : undefined, fill: o.fill || c.ink, 'text-anchor': o.anchor || 'start', 'letter-spacing': o.ls, opacity: o.op, transform: o.rot ? `rotate(${o.rot} ${q(x)} ${q(y)})` : undefined });
    const inner = lines.length === 1 ? esc(lines[0]) : lines.map((l, i) => `<tspan x="${q(x)}" ${i ? `dy="${q(size * lh)}"` : `y="${q(y)}"`}>${esc(l)}</tspan>`).join('');
    return { svg: `<text ${a}>${inner}</text>`, h: size * lh * (lines.length - 1) + size, lines: lines.length };
  };
  // fit the heading: no word wider than the box, at most 3 lines
  const fitTitle = (c, str, size, w, upper) => {
    const k = gw(c.fh) * (upper ? 1.12 : 1);
    const longest = Math.max(...String(str).split(/\s+/).map(x => x.length), 1);
    size = Math.min(size, w / (longest * k));
    while (wrap(str, size, w, k).length > 3 && size > c.u * 2) size *= 0.92;
    return size;
  };
  // kicker, heading, text and button
  const block = (c, o = {}) => {
    const align = o.align || 'left', anchor = align === 'center' ? 'middle' : align === 'right' ? 'end' : 'start';
    const x0 = o.x === undefined ? c.tr.x : o.x, w = o.w || c.tr.w;
    const ax = align === 'center' ? x0 + w / 2 : align === 'right' ? x0 + w : x0;
    let y = o.y === undefined ? c.tr.y : o.y;
    let s = '';
    const ts = fitTitle(c, c.txt.title, (o.size || c.titleSize), w, o.upper);
    if (o.kicker !== false) {
      const ks = Math.max(c.u * 1.5, ts * 0.2);
      s += Tx(c, t('Підпис'), c.txt.kicker, ax, y + ks, ks, { fill: o.kc || c.a1, weight: 600, ls: ks * 0.12, upper: true, anchor }).svg;
      y += ks * 2.4;
    }
    const tt = Tx(c, t('Заголовок'), c.txt.title, ax, y + ts * 0.85, ts, { family: c.fh, fill: o.tc || c.ink, weight: o.tw || 700, maxW: w, lh: 1.08, anchor, italic: o.italic, upper: o.upper, ls: o.tls });
    s += tt.svg;
    y += tt.h + ts * 0.42;
    const ds = Math.max(c.u * 1.9, Math.min(ts * 0.3, c.u * 3.2));
    if (o.desc !== false) {
      const dd = Tx(c, t('Опис'), c.txt.sub, ax, y + ds, ds, { fill: o.dc || c.ink2, maxW: Math.min(w, ds * 26), lh: 1.45, anchor });
      s += dd.svg;
      y += dd.h + ds * 1.5;
    }
    if (o.cta !== false) {
      const bs = ds * 0.92, bh = bs * 2.9, bw = bs * (c.txt.cta.length * 0.6) + bs * 3.4;
      const bx = align === 'center' ? ax - bw / 2 : align === 'right' ? ax - bw : ax;
      const bc = o.bc || c.a1;
      if (o.bshadow) s += R(t('Тінь кнопки'), bx + bs * 0.4, y + bs * 0.4, bw, bh, { fill: o.bshadow, rx: o.br === undefined ? bh / 2 : o.br });
      s += R(t('Кнопка'), bx, y, bw, bh, { fill: o.bfill === undefined ? bc : o.bfill, rx: o.br === undefined ? bh / 2 : o.br, stroke: o.bstroke, sw: o.bsw });
      s += Tx(c, t('Текст кнопки'), c.txt.cta, bx + bw / 2, y + bh / 2 + bs * 0.36, bs, { fill: o.btc || onColor(o.bfill === undefined || o.bfill === 'none' ? (o.bfill === 'none' ? c.bgc : bc) : o.bfill), weight: 600, anchor: 'middle' }).svg;
      y += bh;
    }
    return { svg: s, y };
  };
  const bgRect = (c, fill) => { c.bgFill = /^#/.test(fill) ? fill : c.bgc; return R(t('Тло'), 0, 0, c.W, c.H, { fill }); };
  const footer = (c, color, align) => {
    const fs = Math.max(c.u * 1.3, 9);
    const x = align === 'center' ? c.W / 2 : c.tr.x;
    return Tx(c, t('Підпис внизу'), 'vibsma.design · ' + new Date().getFullYear(), x, c.H - c.u * 5, fs, { fill: color || c.ink2, anchor: align === 'center' ? 'middle' : 'start', ls: fs * 0.1 }).svg;
  };
  // website chrome: logo + menu on every device frame
  const nav = c => {
    if (!c.web) return '';
    const fs = Math.max(14, c.u * 2.2), y = c.top / 2 + fs * 0.35;
    const mob = c.W < 600;
    return Tx(c, t('Логотип'), c.txt.brand, c.tr.x, y, fs * 1.15, { family: c.fh, weight: 700 }).svg + Tx(c, t('Меню'), mob ? '☰' : c.txt.menu, c.W - c.tr.x, y, mob ? fs * 1.4 : fs * 0.85, { anchor: 'end', fill: c.ink2 }).svg + Ln(t('Лінія меню'), 0, c.top, c.W, c.top, { stroke: c.ink, sw: 1, op: 0.12 });
  };
  const A = c => c.art; // art box
  const minA = c => Math.min(c.art.w, c.art.h);
  const blobD = (cx, cy, r, rnd, n = 7, k = 0.35) => {
    const pts = [];
    for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2, rr = r * (1 - k / 2 + rnd() * k); pts.push([cx + Math.cos(a) * rr, cy + Math.sin(a) * rr]); }
    let d = '';
    for (let i = 0; i < n; i++) {
      const p0 = pts[(i - 1 + n) % n], p1 = pts[i], p2 = pts[(i + 1) % n], p3 = pts[(i + 2) % n];
      if (!i) d += `M${q(p1[0])} ${q(p1[1])}`;
      const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6], c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
      d += `C${q(c1[0])} ${q(c1[1])} ${q(c2[0])} ${q(c2[1])} ${q(p2[0])} ${q(p2[1])}`;
    }
    return d + 'Z';
  };
  const star = (cx, cy, r1, r2, n, rot = -90) => { const p = []; for (let i = 0; i < n * 2; i++) { const a = (rot + i * 180 / n) * Math.PI / 180, r = i % 2 ? r2 : r1; p.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); } return p; };
  const archD = (x, y, w, h) => `M${q(x)} ${q(y + h)}V${q(y + w / 2)}A${q(w / 2)} ${q(w / 2)} 0 0 1 ${q(x + w)} ${q(y + w / 2)}V${q(y + h)}Z`;
  const leafD = (x, y, l, a, wdt = 0.36) => {
    const ca = Math.cos(a), sa = Math.sin(a), px = -sa, py = ca;
    const tx = x + ca * l, ty = y + sa * l, mx = x + ca * l / 2, my = y + sa * l / 2;
    return `M${q(x)} ${q(y)}Q${q(mx + px * l * wdt)} ${q(my + py * l * wdt)} ${q(tx)} ${q(ty)}Q${q(mx - px * l * wdt)} ${q(my - py * l * wdt)} ${q(x)} ${q(y)}Z`;
  };

  // ---------- motifs ----------
  const MOTIF = {};
  MOTIF.minimal = c => {
    const a = A(c), m = minA(c);
    const v = c.st.v;
    let s = bgRect(c, c.bgc);
    if (v === 'lux') s += R(t('Рамка'), c.u * 4, c.u * 4 + c.top, c.W - c.u * 8, c.H - c.u * 8 - c.top, { stroke: c.a1, sw: c.u * 0.18 });
    s += C(t('Коло'), a.x + a.w * 0.55, a.y + a.h * 0.5, m * 0.42, { stroke: v === 'mono' ? c.ink : c.a1, sw: c.u * 0.3 });
    s += C(t('Акцент'), a.x + a.w * 0.55 + m * 0.3, a.y + a.h * 0.5 - m * 0.3, m * 0.08, { fill: v === 'dark' ? c.a1 : c.a2 });
    s += Ln(t('Лінія'), a.x + a.w * 0.1, a.y + a.h * 0.95, a.x + a.w, a.y + a.h * 0.95, { stroke: c.ink, sw: c.u * 0.12, op: 0.35 });
    s += block(c, { bc: c.a1, tw: v === 'lux' ? 400 : 700, upper: v === 'lux', tls: v === 'lux' ? c.u * 0.4 : undefined, br: v === 'mono' ? 0 : undefined }).svg;
    return s + footer(c);
  };
  MOTIF.swiss = c => {
    const a = A(c);
    let s = bgRect(c, c.bgc);
    for (let i = 1; i < 6; i++) s += Ln(t('Модульна сітка'), c.W * i / 6, c.top, c.W * i / 6, c.H, { stroke: c.ink, sw: 0.6, op: 0.08 });
    s += R(t('Блок'), a.x + a.w * 0.25, a.y, a.w * 0.75, a.h * 0.78, { fill: c.a1 });
    s += Tx(c, t('Номер'), '01', a.x + a.w * 0.3, a.y + a.h * 0.7, minA(c) * 0.42, { family: c.fh, weight: 800, fill: onColor(c.a1) }).svg;
    s += R(t('Смуга'), a.x, a.y + a.h * 0.86, a.w * 0.5, c.u * 1.4, { fill: c.ink });
    s += block(c, { br: 0, upper: c.st.v === 'swiss', kc: c.a1 }).svg;
    return s + footer(c);
  };
  MOTIF.geo = c => {
    const a = A(c), m = minA(c), r = c.r, v = c.st.v;
    let s = bgRect(c, c.bgc);
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    if (v === 'bauhaus') {
      s += C(t('Коло'), cx - m * 0.18, cy - m * 0.08, m * 0.3, { fill: c.a1 });
      s += Pg(t('Трикутник'), [[cx + m * 0.05, cy + m * 0.42], [cx + m * 0.45, cy + m * 0.42], [cx + m * 0.25, cy + m * 0.02]], { fill: c.a2 });
      s += R(t('Квадрат'), cx + m * 0.08, cy - m * 0.46, m * 0.34, m * 0.34, { fill: '#1F4E9C' });
      s += P(t('Півколо'), `M${q(cx - m * 0.48)} ${q(cy + m * 0.42)}A${q(m * 0.22)} ${q(m * 0.22)} 0 0 1 ${q(cx - m * 0.04)} ${q(cy + m * 0.42)}Z`, { fill: c.ink });
    } else if (v === 'construct') {
      s += P(t('Діагональ'), `M${q(a.x - a.w * 0.3)} ${q(a.y + a.h * 0.85)}L${q(a.x + a.w * 1.1)} ${q(a.y + a.h * 0.05)}L${q(a.x + a.w * 1.1)} ${q(a.y + a.h * 0.3)}L${q(a.x - a.w * 0.3)} ${q(a.y + a.h * 1.1)}Z`, { fill: c.a1 });
      s += C(t('Коло'), cx + m * 0.22, cy - m * 0.12, m * 0.24, { fill: c.ink });
      s += R(t('Брусок'), a.x + a.w * 0.05, a.y + a.h * 0.12, a.w * 0.5, m * 0.07, { fill: c.ink, rot: -28 });
    } else if (v === 'mondrian') {
      const g = c.u * 1.1, x0 = a.x, y0 = a.y, w = a.w, h = a.h;
      const cols = [[0, 0, 0.62, 0.58, '#FFFFFF'], [0.62, 0, 0.38, 0.32, c.a1], [0.62, 0.32, 0.38, 0.26, '#FFFFFF'], [0, 0.58, 0.28, 0.42, '#FFD400'], [0.28, 0.58, 0.46, 0.42, '#FFFFFF'], [0.74, 0.58, 0.26, 0.42, c.a2]];
      s += R(t('Рамка'), x0 - g, y0 - g, w + g * 2, h + g * 2, { fill: c.ink });
      cols.forEach(([x, y, cw, ch, col], i) => { s += R(t('Поле {n}', { n: i + 1 }), x0 + x * w + g / 2, y0 + y * h + g / 2, cw * w - g, ch * h - g, { fill: col }); });
    } else if (v === 'speed') {
      for (let i = 0; i < 14; i++) { const yy = a.y + a.h * (0.1 + i * 0.06); s += Ln(t('Лінія руху'), a.x + a.w * (0.1 + r() * 0.3), yy, a.x + a.w, yy - a.h * 0.25, { stroke: i % 4 === 0 ? c.a1 : c.ink, sw: c.u * (0.2 + r() * 0.6), op: 0.85 }); }
      s += P(t('Дуга'), `M${q(a.x)} ${q(a.y + a.h)}Q${q(cx)} ${q(a.y)} ${q(a.x + a.w)} ${q(a.y + a.h * 0.4)}`, { stroke: c.a1, sw: c.u * 1.4 });
    } else if (v === 'flat') {
      s += C(t('Коло'), cx, cy, m * 0.44, { fill: c.sf });
      s += R(t('Картка'), cx - m * 0.3, cy - m * 0.18, m * 0.6, m * 0.42, { fill: c.a1, rx: m * 0.05 });
      s += C(t('Акцент'), cx + m * 0.28, cy - m * 0.24, m * 0.12, { fill: c.a2 });
      s += R(t('Смуга'), cx - m * 0.22, cy + m * 0.04, m * 0.3, m * 0.05, { fill: '#FFFFFF', rx: m * 0.025 });
    } else { // memphis confetti
      const cols = [c.a1, c.a2, c.ink, '#FFD23F'];
      for (let i = 0; i < 16; i++) {
        const x = a.x + r() * a.w, y = a.y + r() * a.h, sz = m * (0.05 + r() * 0.08), col = cols[i % 4];
        const kind = i % 4;
        if (kind === 0) s += C(t('Конфеті'), x, y, sz / 2, { fill: col });
        else if (kind === 1) s += Pg(t('Конфеті'), [[x, y - sz / 2], [x + sz / 2, y + sz / 2], [x - sz / 2, y + sz / 2]], { fill: col, tf: `rotate(${Math.round(r() * 90)} ${q(x)} ${q(y)})` });
        else if (kind === 2) s += P(t('Зигзаг'), `M${q(x)} ${q(y)}l${q(sz * 0.5)} ${q(-sz * 0.5)}l${q(sz * 0.5)} ${q(sz * 0.5)}l${q(sz * 0.5)} ${q(-sz * 0.5)}l${q(sz * 0.5)} ${q(sz * 0.5)}`, { stroke: col, sw: c.u * 0.6, cap: 'round', join: 'round' });
        else s += R(t('Конфеті'), x, y, sz, sz, { fill: 'none', stroke: col, sw: c.u * 0.5, rot: r() * 60 });
      }
      s += C(t('Коло'), cx, cy, m * 0.22, { fill: c.a1 });
    }
    s += block(c, { br: v === 'flat' ? undefined : 0, upper: v !== 'flat', bc: v === 'mondrian' || v === 'bauhaus' ? c.ink : c.a1 }).svg;
    return s + footer(c);
  };
  MOTIF.deco = c => {
    const a = A(c), m = minA(c);
    let s = bgRect(c, c.bgc);
    const inset = c.u * 3.5;
    s += R(t('Рамка'), inset, inset + c.top, c.W - inset * 2, c.H - inset * 2 - c.top, { stroke: c.a1, sw: c.u * 0.35 });
    s += R(t('Внутрішня рамка'), inset * 1.6, inset * 1.6 + c.top, c.W - inset * 3.2, c.H - inset * 3.2 - c.top, { stroke: c.a1, sw: c.u * 0.12 });
    const cx = a.x + a.w / 2, by = a.y + a.h * 0.92;
    if (c.st.v === 'stream') {
      for (let i = 0; i < 7; i++) s += R(t('Обтічна смуга'), a.x + a.w * (0.05 + i * 0.03), a.y + a.h * (0.25 + i * 0.08), a.w * (0.9 - i * 0.06), m * 0.035, { fill: i % 2 ? c.a2 : c.a1, rx: m * 0.02 });
      s += C(t('Коло'), a.x + a.w * 0.78, a.y + a.h * 0.3, m * 0.18, { fill: c.a1, op: 0.85 });
    } else {
      for (let i = 0; i <= 12; i++) { const ang = Math.PI + i * Math.PI / 12; s += Ln(t('Промінь'), cx, by, cx + Math.cos(ang) * m * 0.5, by + Math.sin(ang) * m * 0.5, { stroke: c.a1, sw: c.u * 0.18 }); }
      for (let k = 1; k <= 3; k++) s += P(t('Віяло'), `M${q(cx - m * 0.16 * k)} ${q(by)}A${q(m * 0.16 * k)} ${q(m * 0.16 * k)} 0 0 1 ${q(cx + m * 0.16 * k)} ${q(by)}`, { stroke: c.a1, sw: c.u * 0.3 });
      s += Pg(t('Ромб'), [[cx, by - m * 0.62], [cx + m * 0.05, by - m * 0.55], [cx, by - m * 0.48], [cx - m * 0.05, by - m * 0.55]], { fill: c.a1 });
      s += Ln(t('Основа'), cx - m * 0.55, by, cx + m * 0.55, by, { stroke: c.a1, sw: c.u * 0.3 });
    }
    s += block(c, { align: c.wide ? 'left' : 'center', upper: true, tw: 400, tls: c.u * 0.3, tc: c.ink, kc: c.a1, br: 0, bfill: 'none', bstroke: c.a1, bsw: c.u * 0.2, btc: c.a1 }).svg;
    return s + footer(c, c.a1, c.wide ? 'left' : 'center');
  };
  const corner = (c, x, y, sx, sy, col) => {
    const k = c.u * 6;
    const d = `M${q(x)} ${q(y + sy * k)}C${q(x)} ${q(y + sy * k * 0.3)} ${q(x + sx * k * 0.3)} ${q(y)} ${q(x + sx * k)} ${q(y)}M${q(x + sx * k * 0.25)} ${q(y + sy * k * 0.25)}c${q(sx * k * 0.25)} 0 ${q(sx * k * 0.25)} ${q(sy * k * 0.25)} 0 ${q(sy * k * 0.25)}`;
    return P(t('Орнамент кута'), d, { stroke: col, sw: c.u * 0.3, cap: 'round' }) + C(t('Перлина'), x + sx * k * 0.12, y + sy * k * 0.12, c.u * 0.6, { fill: col });
  };
  MOTIF.ornate = c => {
    const a = A(c), m = minA(c), v = c.st.v;
    let s = bgRect(c, c.bgc);
    const ins = c.u * (v === 'thin' ? 5 : 3.5), x0 = ins, y0 = ins + c.top, x1 = c.W - ins, y1 = c.H - ins;
    const col = c.a1;
    s += R(t('Рамка'), x0, y0, x1 - x0, y1 - y0, { stroke: col, sw: c.u * (v === 'thin' ? 0.12 : 0.4) });
    if (v !== 'thin') {
      s += R(t('Внутрішня рамка'), x0 + c.u * 1.4, y0 + c.u * 1.4, x1 - x0 - c.u * 2.8, y1 - y0 - c.u * 2.8, { stroke: col, sw: c.u * 0.12 });
      s += corner(c, x0 + c.u * 2.2, y0 + c.u * 2.2, 1, 1, col) + corner(c, x1 - c.u * 2.2, y0 + c.u * 2.2, -1, 1, col) + corner(c, x0 + c.u * 2.2, y1 - c.u * 2.2, 1, -1, col) + corner(c, x1 - c.u * 2.2, y1 - c.u * 2.2, -1, -1, col);
    }
    const cx = a.x + a.w / 2;
    if (v === 'gothic') {
      const w = Math.min(a.w * 0.5, a.h * 0.55), h = a.h * 0.95, x = cx - w / 2, y = a.y + a.h * 0.02;
      s += P(t('Стрілчаста арка'), `M${q(x)} ${q(y + h)}V${q(y + w * 0.6)}Q${q(x)} ${q(y)} ${q(cx)} ${q(y - w * 0.15)}Q${q(x + w)} ${q(y)} ${q(x + w)} ${q(y + w * 0.6)}V${q(y + h)}Z`, { fill: c.sf, stroke: col, sw: c.u * 0.4 });
      s += C(t('Троянда'), cx, y + w * 0.55, w * 0.22, { stroke: c.a1, sw: c.u * 0.3, fill: c.a1, fop: 0.25 });
      s += Ln(t('Імпост'), cx, y + w * 0.8, cx, y + h, { stroke: col, sw: c.u * 0.3 });
    } else if (v === 'arch') {
      const w = Math.min(a.w * 0.62, a.h * 0.7), h = a.h * 0.95, x = cx - w / 2, y = a.y + a.h * 0.03;
      s += P(t('Арка'), archD(x, y, w, h), { fill: c.a1, fop: 0.18, stroke: col, sw: c.u * 0.35 });
      s += P(t('Внутрішня арка'), archD(x + w * 0.16, y + w * 0.16, w * 0.68, h - w * 0.16), { fill: c.a2, fop: 0.35 });
      s += C(t('Сонце'), cx, y + w * 0.5, w * 0.14, { fill: c.a2 === c.ink ? c.a1 : c.a2 });
    } else if (v === 'meander') {
      const band = (y, id) => { let d = ''; const st = c.u * 3, n = Math.floor((x1 - x0 - c.u * 4) / st); for (let i = 0; i < n; i++) { const x = x0 + c.u * 2 + i * st; d += `M${q(x)} ${q(y + st * 0.8)}V${q(y)}H${q(x + st * 0.8)}V${q(y + st * 0.55)}H${q(x + st * 0.3)}V${q(y + st * 0.3)}`; } return P(id, d, { stroke: c.a1, sw: c.u * 0.3, cap: 'square' }); };
      s += band(y0 + c.u * 2.4, t('Меандр угорі')) + band(y1 - c.u * 4.8, t('Меандр унизу'));
      const cw = a.w * 0.12, ch = a.h * 0.8;
      for (let i = 0; i < 3; i++) { const x = cx - a.w * 0.3 + i * a.w * 0.25; s += R(t('Колона'), x, a.y + a.h * 0.12, cw, ch, { fill: c.sf, stroke: c.a1, sw: c.u * 0.2 }); s += R(t('Капітель'), x - cw * 0.2, a.y + a.h * 0.08, cw * 1.4, a.h * 0.05, { fill: c.a1 }); }
    } else if (v === 'medieval') {
      const sz = Math.min(a.w, a.h) * 0.7, x = cx - sz / 2, y = a.y + (a.h - sz) / 2;
      s += R(t('Буквиця'), x, y, sz, sz, { fill: c.a1 });
      s += R(t('Облямівка буквиці'), x + sz * 0.06, y + sz * 0.06, sz * 0.88, sz * 0.88, { stroke: c.bgc, sw: c.u * 0.3 });
      s += Tx(c, t('Літера'), (c.txt.title || 'A')[0], cx, y + sz * 0.78, sz * 0.72, { family: c.fh, fill: c.bgc, anchor: 'middle', weight: 700 }).svg;
      s += C(t('Герб'), x + sz * 0.92, y + sz * 0.1, sz * 0.09, { fill: c.a2 });
    } else {
      // medallion (classic, baroque, rococo, empire, victorian, light)
      const rr = m * 0.4, cy = a.y + a.h / 2;
      s += E(t('Медальйон'), cx, cy, rr * 0.82, rr, { stroke: col, sw: c.u * 0.45, fill: c.sf, op: 1 });
      s += E(t('Внутрішній медальйон'), cx, cy, rr * 0.66, rr * 0.84, { stroke: col, sw: c.u * 0.15 });
      if (v === 'empire' || v === 'baroque') s += Pg(t('Корона'), [[cx - rr * 0.3, cy - rr * 1.05], [cx - rr * 0.18, cy - rr * 1.28], [cx, cy - rr * 1.12], [cx + rr * 0.18, cy - rr * 1.28], [cx + rr * 0.3, cy - rr * 1.05]], { fill: c.a1 });
      for (let i = 0; i < 2; i++) { const sx = i ? 1 : -1; s += P(t('Гілка лавра'), `M${q(cx + sx * rr * 0.2)} ${q(cy + rr * 1.05)}Q${q(cx + sx * rr * 1.2)} ${q(cy + rr * 0.6)} ${q(cx + sx * rr * 0.95)} ${q(cy - rr * 0.6)}`, { stroke: c.a1, sw: c.u * 0.3 }); for (let k = 0; k < 5; k++) { const tt = 0.15 + k * 0.17, px = cx + sx * rr * (0.2 + 0.85 * tt), py = cy + rr * (1.05 - 1.6 * tt); s += P(t('Листок'), leafD(px, py, rr * 0.22, sx > 0 ? -0.6 : Math.PI + 0.6), { fill: c.a1, op: 0.85 }); } }
      s += Tx(c, t('Монограма'), (c.txt.title || 'A')[0], cx, cy + rr * 0.3, rr * 0.8, { family: c.fh, anchor: 'middle', fill: c.a1, italic: v === 'rococo' }).svg;
    }
    s += block(c, { align: c.wide ? 'left' : 'center', tw: v === 'thin' ? 400 : 600, italic: v === 'rococo', br: v === 'thin' ? 0 : c.u * 0.6, bfill: v === 'light' || v === 'thin' ? 'none' : undefined, bstroke: c.a1, bsw: c.u * 0.18, btc: v === 'light' || v === 'thin' ? c.ink : undefined }).svg;
    return s + footer(c, c.a1, c.wide ? 'left' : 'center');
  };
  const flower = (c, cx, cy, r, col, core, id) => {
    let s = '';
    for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2 - Math.PI / 2; s += E(t('Пелюстка'), cx + Math.cos(a) * r * 0.62, cy + Math.sin(a) * r * 0.62, r * 0.5, r * 0.32, { fill: col, rot: a * 180 / Math.PI }); }
    s += C(t('Серцевина'), cx, cy, r * 0.26, { fill: core });
    return Gp(id || t('Квітка'), s);
  };
  MOTIF.nouveau = c => {
    const a = A(c), m = minA(c), v = c.st.v, r = c.r;
    let s = bgRect(c, c.bgc);
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    if (v === 'vine') {
      const ins = c.u * 4;
      s += P(t('Лоза ліворуч'), `M${q(ins)} ${q(c.H - ins)}C${q(ins + c.u * 8)} ${q(c.H * 0.7)} ${q(ins - c.u * 2)} ${q(c.H * 0.45)} ${q(ins + c.u * 6)} ${q(c.top + ins)}`, { stroke: c.a1, sw: c.u * 0.45, cap: 'round' });
      s += P(t('Лоза праворуч'), `M${q(c.W - ins)} ${q(c.H - ins)}C${q(c.W - ins - c.u * 8)} ${q(c.H * 0.7)} ${q(c.W - ins + c.u * 2)} ${q(c.H * 0.45)} ${q(c.W - ins - c.u * 6)} ${q(c.top + ins)}`, { stroke: c.a1, sw: c.u * 0.45, cap: 'round' });
      s += P(t('Арка ар-нуво'), archD(cx - m * 0.36, a.y, m * 0.72, a.h), { fill: c.sf, stroke: c.a1, sw: c.u * 0.35 });
      s += P(t('Батіг'), `M${q(cx - m * 0.25)} ${q(a.y + a.h * 0.9)}C${q(cx - m * 0.4)} ${q(cy)} ${q(cx + m * 0.35)} ${q(cy + m * 0.1)} ${q(cx)} ${q(a.y + a.h * 0.25)}`, { stroke: c.a2, sw: c.u * 0.5, cap: 'round' });
      s += flower(c, cx, a.y + a.h * 0.28, m * 0.12, c.a2, c.a1);
    } else if (v === 'petryk') {
      // Petrykivka: stroke petals «зернятко» around a big flower, leaves and a stem
      s += P(t('Стебло'), `M${q(cx)} ${q(a.y + a.h)}C${q(cx - m * 0.2)} ${q(cy + m * 0.2)} ${q(cx + m * 0.1)} ${q(cy)} ${q(cx)} ${q(cy - m * 0.05)}`, { stroke: '#4E9A3A', sw: c.u * 0.6, cap: 'round' });
      for (let i = 0; i < 9; i++) { const ang = Math.PI + i * Math.PI / 8; s += P(t('Мазок'), leafD(cx + Math.cos(ang) * m * 0.08, cy + Math.sin(ang) * m * 0.08, m * 0.3, ang, 0.28), { fill: i % 2 ? c.a1 : '#F27A1A' }); }
      s += C(t('Серце квітки'), cx, cy, m * 0.09, { fill: c.a2 });
      for (let i = 0; i < 6; i++) { const ty = a.y + a.h * (0.55 + i * 0.07), sx = i % 2 ? 1 : -1; s += P(t('Листок'), leafD(cx + sx * c.u * 0.5, ty, m * 0.22, sx > 0 ? -0.5 : Math.PI + 0.5, 0.32), { fill: '#4E9A3A' }); }
      for (let i = 0; i < 10; i++) s += C(t('Ягідка'), cx + (r() - 0.5) * m * 0.9, cy + (r() - 0.6) * m * 0.7, m * 0.018, { fill: c.a2 });
    } else {
      // floral: scattered flowers and leaves
      const cols = [c.a1, c.a2, mixC(c.a1, '#FFFFFF', 0.4)];
      for (let i = 0; i < 9; i++) { const x = a.x + r() * a.w, y = a.y + r() * a.h; s += P(t('Листок'), leafD(x, y, m * 0.13, r() * Math.PI * 2), { fill: '#8BA57E', op: 0.9 }); }
      for (let i = 0; i < 7; i++) s += flower(c, a.x + a.w * (0.1 + r() * 0.8), a.y + a.h * (0.1 + r() * 0.8), m * (0.06 + r() * 0.06), cols[i % 3], '#E8C766');
    }
    s += block(c, { align: c.wide ? 'left' : 'center', italic: v === 'floral', tc: v === 'petryk' ? c.ink : undefined, bc: c.a1 }).svg;
    return s + footer(c, undefined, c.wide ? 'left' : 'center');
  };
  MOTIF.organic = c => {
    const a = A(c), m = minA(c), v = c.st.v, r = c.r;
    let s = bgRect(c, c.bgc);
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    if (v === 'waves') {
      const cols = [c.a1, c.a2, c.sf, mixC(c.a1, c.a2, 0.5)];
      for (let i = 0; i < 6; i++) { const y = a.y + a.h * (0.1 + i * 0.16), amp = a.h * 0.07; s += P(t('Хвиля'), `M${q(0)} ${q(y)}C${q(c.W * 0.25)} ${q(y - amp)} ${q(c.W * 0.5)} ${q(y + amp)} ${q(c.W * 0.75)} ${q(y)}S${q(c.W)} ${q(y - amp)} ${q(c.W)} ${q(y)}V${q(y + a.h * 0.13)}C${q(c.W * 0.75)} ${q(y + a.h * 0.13 + amp)} ${q(c.W * 0.5)} ${q(y + a.h * 0.13 - amp)} ${q(c.W * 0.25)} ${q(y + a.h * 0.13)}S${q(0)} ${q(y + a.h * 0.13 + amp)} ${q(0)} ${q(y + a.h * 0.13)}Z`, { fill: cols[i % 4], op: 0.9 }); }
    } else if (v === 'leaves') {
      for (let i = 0; i < 12; i++) { const ang = -Math.PI / 2 + (i - 5.5) * 0.24; s += P(t('Листок'), leafD(cx, a.y + a.h * 0.98, m * (0.5 + r() * 0.35), ang, 0.3), { fill: i % 3 === 0 ? c.a2 : mixC(c.a1, c.ink, (i % 3) * 0.2), op: 0.95 }); }
      s += C(t('Плід'), cx + m * 0.28, a.y + a.h * 0.25, m * 0.08, { fill: c.a2 });
    } else if (v === 'sun') {
      s += C(t('Сонце'), cx, cy - m * 0.05, m * 0.26, { fill: c.a2 });
      for (let i = 0; i < 16; i++) { const ang = i / 16 * Math.PI * 2; s += Ln(t('Промінь'), cx + Math.cos(ang) * m * 0.32, cy - m * 0.05 + Math.sin(ang) * m * 0.32, cx + Math.cos(ang) * m * 0.42, cy - m * 0.05 + Math.sin(ang) * m * 0.42, { stroke: c.a2, sw: c.u * 0.5 }); }
      s += P(t('Пагорб'), `M${q(a.x - c.u * 5)} ${q(a.y + a.h)}Q${q(cx)} ${q(cy + m * 0.05)} ${q(a.x + a.w + c.u * 5)} ${q(a.y + a.h)}Z`, { fill: c.a1 });
      for (let i = 0; i < 5; i++) s += P(t('Листок'), leafD(a.x + a.w * (0.15 + i * 0.17), a.y + a.h * 0.95, m * 0.18, -Math.PI / 2 + (r() - 0.5), 0.3), { fill: mixC(c.a1, c.ink, 0.3) });
    } else if (v === 'safari') {
      s += P(t('Савана'), `M${q(a.x - c.u * 5)} ${q(a.y + a.h)}Q${q(cx)} ${q(cy + m * 0.12)} ${q(a.x + a.w + c.u * 5)} ${q(a.y + a.h)}Z`, { fill: c.a2, op: 0.7 });
      s += C(t('Сонце'), cx + m * 0.2, cy - m * 0.1, m * 0.2, { fill: c.a1 });
      for (let i = 0; i < 14; i++) s += E(t('Пляма'), a.x + r() * a.w, a.y + r() * a.h * 0.55, m * (0.02 + r() * 0.03), m * (0.015 + r() * 0.02), { fill: c.ink, op: 0.75, rot: r() * 180 });
      s += P(t('Акація'), `M${q(cx - m * 0.3)} ${q(a.y + a.h * 0.85)}V${q(a.y + a.h * 0.55)}M${q(cx - m * 0.5)} ${q(a.y + a.h * 0.55)}Q${q(cx - m * 0.3)} ${q(a.y + a.h * 0.42)} ${q(cx - m * 0.1)} ${q(a.y + a.h * 0.55)}Z`, { stroke: c.ink, sw: c.u * 0.5, fill: c.ink });
    } else {
      // blobs (scandi soft, contemporary arch, wabi-sabi stone, boho, organic)
      const cols = v === 'stone' ? [c.a2, c.a1, c.sf] : v === 'boho' ? [c.a1, c.a2, c.sf] : [c.a1, c.sf, c.a2];
      s += P(t('Форма 1'), blobD(cx - m * 0.08, cy, m * 0.42, r, 7, v === 'stone' ? 0.2 : 0.35), { fill: cols[1] });
      s += P(t('Форма 2'), blobD(cx + m * 0.18, cy + m * 0.12, m * 0.24, r, 6), { fill: cols[0] });
      if (v === 'arch') s += P(t('Арка'), archD(cx - m * 0.18, cy - m * 0.34, m * 0.36, m * 0.62), { fill: cols[2] });
      else s += C(t('Сонце'), cx - m * 0.22, cy - m * 0.22, m * 0.1, { fill: cols[2] });
      if (v === 'boho') for (let i = 0; i < 7; i++) s += Ln(t('Бахрома'), cx - m * 0.3 + i * m * 0.1, cy + m * 0.38, cx - m * 0.3 + i * m * 0.1, cy + m * 0.5, { stroke: c.a1, sw: c.u * 0.4 });
    }
    s += block(c, { bc: v === 'waves' ? c.a2 : c.a1, tc: c.ink }).svg;
    return s + footer(c);
  };
  MOTIF.neon = c => {
    const a = A(c), m = minA(c), v = c.st.v, r = c.r;
    let s = bgRect(c, v === 'vapor' ? grad(c, [c.bgc, c.sf]) : grad(c, [c.bgc, c.sf]));
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    const glow = (id, d, col, w) => P(id + ' ' + t('сяйво'), d, { stroke: col, sw: w * 3, op: 0.18, cap: 'round' }) + P(id, d, { stroke: col, sw: w, cap: 'round' });
    if (v === 'synth' || v === 'vapor') {
      const sr = m * 0.36, sy = cy - m * 0.02;
      s += C(t('Сонце'), cx, sy, sr, { fill: grad(c, [c.a2, c.a1]) });
      for (let i = 0; i < 5; i++) s += R(t('Смуга сонця'), cx - sr, sy + sr * (0.15 + i * 0.17), sr * 2, sr * (0.03 + i * 0.015), { fill: c.bgc === '#FBD3E9' ? c.sf : c.sf });
      const hy = sy + sr * 0.9;
      s += R(t('Підлога'), 0, hy, c.W, Math.max(1, a.y + a.h - hy + c.u * 4), { fill: v === 'vapor' ? c.sf : c.bgc });
      for (let i = 0; i <= 10; i++) s += Ln(t('Лінія сітки'), cx + (i - 5) * a.w * 0.05, hy, cx + (i - 5) * a.w * 0.32, a.y + a.h + c.u * 4, { stroke: v === 'vapor' ? c.a2 : c.a1, sw: c.u * 0.2 });
      for (let i = 0; i < 5; i++) { const yy = hy + Math.pow(i / 4, 1.8) * (a.y + a.h + c.u * 4 - hy); s += Ln(t('Лінія сітки'), 0, yy, c.W, yy, { stroke: v === 'vapor' ? c.a2 : c.a1, sw: c.u * 0.2 }); }
    } else if (v === 'cyber') {
      s += glow(t('Неонова рамка'), `M${q(a.x)} ${q(a.y + a.h * 0.2)}L${q(a.x + a.w * 0.2)} ${q(a.y)}H${q(a.x + a.w)}V${q(a.y + a.h * 0.8)}L${q(a.x + a.w * 0.8)} ${q(a.y + a.h)}H${q(a.x)}Z`, c.a1, c.u * 0.4);
      for (let i = 0; i < 9; i++) s += R(t('Глітч'), a.x + r() * a.w * 0.8, a.y + r() * a.h, a.w * (0.08 + r() * 0.3), c.u * (0.4 + r() * 1.2), { fill: i % 2 ? c.a2 : c.a1, op: 0.85 });
      s += glow(t('Лінія'), `M${q(a.x + a.w * 0.1)} ${q(cy)}H${q(a.x + a.w * 0.9)}`, c.a2, c.u * 0.3);
    } else {
      // afrofuturism: rings + triangle pattern
      for (let k = 0; k < 5; k++) s += C(t('Орбіта'), cx, cy, m * (0.12 + k * 0.08), { stroke: k % 2 ? c.a2 : c.a1, sw: c.u * 0.35 });
      s += C(t('Планета'), cx, cy, m * 0.1, { fill: c.a1 });
      for (let i = 0; i < 8; i++) { const x = a.x + i * a.w / 8; s += Pg(t('Орнамент'), [[x, a.y + a.h], [x + a.w / 16, a.y + a.h * 0.9], [x + a.w / 8, a.y + a.h]], { fill: i % 2 ? c.a2 : c.a1 }); }
      for (let i = 0; i < 18; i++) s += C(t('Зірка'), r() * c.W, c.top + r() * c.H * 0.5, c.u * (0.15 + r() * 0.3), { fill: '#FFFFFF', op: 0.8 });
    }
    s += block(c, { upper: v !== 'vapor', bc: c.a1, tc: c.ink, kc: c.a2, br: v === 'cyber' ? 0 : undefined }).svg;
    return s + footer(c, c.a2);
  };
  MOTIF.glass = c => {
    const a = A(c), m = minA(c), v = c.st.v, r = c.r;
    const light = lum(c.bgc) > 0.6;
    let s = bgRect(c, v === 'grad' ? grad(c, [c.bgc, c.a1], 0, 0, 1, 1) : v === 'surreal' ? grad(c, [c.bgc, c.sf]) : c.bgc);
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    const orb = (id, x, y, rad, col) => C(id, x, y, rad, { fill: grad(c, [[col, 0, 0.95], [col, 1, 0]], 0.5, 0.5, 0.5, 0, true) });
    if (v === 'surreal') {
      s += P(t('Арка'), archD(cx - m * 0.25, cy - m * 0.3, m * 0.5, m * 0.75), { fill: c.sf });
      s += C(t('Сфера'), cx + m * 0.05, cy - m * 0.05, m * 0.16, { fill: grad(c, ['#FFFFFF', c.a1], 0.3, 0.3, 0.8, 1) });
      s += E(t('Тінь сфери'), cx + m * 0.05, cy + m * 0.42, m * 0.16, m * 0.03, { fill: c.ink, op: 0.25 });
      s += R(t('Сходи'), cx - m * 0.45, cy + m * 0.3, m * 0.25, m * 0.05, { fill: c.a2 });
      s += C(t('Хмара'), cx + m * 0.35, cy - m * 0.38, m * 0.06, { fill: '#FFFFFF' });
    } else {
      s += orb(t('Сяйво 1'), a.x + a.w * 0.3, a.y + a.h * 0.35, m * 0.55, c.a1);
      s += orb(t('Сяйво 2'), a.x + a.w * 0.75, a.y + a.h * 0.6, m * 0.5, c.a2);
      if (v === 'y2k') { s += Pg(t('Хромова зірка'), star(cx + m * 0.25, cy - m * 0.25, m * 0.16, m * 0.05, 4), { fill: grad(c, ['#FFFFFF', c.a1, '#8A96B0']) }); s += C(t('Бульбашка'), cx - m * 0.3, cy + m * 0.3, m * 0.09, { fill: '#FFFFFF', fop: 0.4, stroke: '#FFFFFF', sw: c.u * 0.2 }); }
      s += R(t('Скляна картка'), a.x + a.w * 0.12, a.y + a.h * 0.2, a.w * 0.76, a.h * 0.6, { fill: '#FFFFFF', fop: light ? 0.55 : 0.12, stroke: '#FFFFFF', sw: c.u * 0.15, rx: m * 0.06 });
      s += C(t('Аватар'), a.x + a.w * 0.24, a.y + a.h * 0.32, m * 0.05, { fill: c.a1 });
      for (let i = 0; i < 3; i++) s += R(t('Рядок'), a.x + a.w * 0.2, a.y + a.h * (0.48 + i * 0.09), a.w * (0.5 - i * 0.1), m * 0.03, { fill: light ? c.ink : '#FFFFFF', op: 0.25, rx: m * 0.015 });
    }
    s += block(c, { bc: v === 'light' ? c.a1 : light ? c.ink : '#FFFFFF', btc: v === 'light' ? '#FFFFFF' : light ? '#FFFFFF' : c.bgc, tc: c.ink, kc: c.a2 === '#FFFFFF' ? c.a1 : c.a2 }).svg;
    return s + footer(c);
  };
  MOTIF.brutal = c => {
    const a = A(c), m = minA(c), v = c.st.v;
    let s = bgRect(c, c.bgc);
    const bw = c.u * (v === 'neo' ? 0.7 : 0.45), off = c.u * 1.6;
    s += R(t('Тінь картки'), a.x + off, a.y + off, a.w * 0.9, a.h * 0.8, { fill: c.ink });
    s += R(t('Картка'), a.x, a.y, a.w * 0.9, a.h * 0.8, { fill: v === 'neo' ? c.a1 : c.sf, stroke: c.ink, sw: bw });
    s += R(t('Наліпка'), a.x + a.w * 0.55, a.y + a.h * 0.55, a.w * 0.4, a.h * 0.32, { fill: v === 'neo' ? c.a2 : c.a2, stroke: c.ink, sw: bw, rot: -6 });
    s += Tx(c, t('Знак'), v === 'neo' ? '★' : '→', a.x + a.w * 0.25, a.y + a.h * 0.55, m * 0.38, { fill: c.ink, family: c.fh }).svg;
    if (v === 'raw') for (let i = 0; i < 6; i++) s += Ln(t('Лінійка'), a.x, a.y + a.h * 0.85 + i * c.u, a.x + a.w * (0.2 + i * 0.12), a.y + a.h * 0.85 + i * c.u, { stroke: c.ink, sw: c.u * 0.2, cap: 'butt' });
    s += block(c, { upper: true, br: 0, bc: v === 'neo' ? c.a2 : c.a2, bstroke: c.ink, bsw: bw, btc: c.ink, bshadow: c.ink, tc: c.ink, kc: c.ink }).svg;
    return s + footer(c, c.ink);
  };
  MOTIF.retro = c => {
    const a = A(c), m = minA(c), v = c.st.v, r = c.r;
    let s = bgRect(c, c.bgc);
    const cx = a.x + a.w / 2, by = a.y + a.h * 0.95;
    if (v === 'sun') {
      const cols = [c.a1, c.a2, mixC(c.a1, c.ink, 0.35), c.sf];
      for (let i = 0; i < 4; i++) { const rr = m * (0.55 - i * 0.12); s += P(t('Смуга веселки'), `M${q(cx - rr)} ${q(by)}A${q(rr)} ${q(rr)} 0 0 1 ${q(cx + rr)} ${q(by)}Z`, { fill: cols[i] }); }
    } else if (v === 'space') {
      s += C(t('Планета'), cx, a.y + a.h * 0.5, m * 0.25, { fill: grad(c, [c.a1, mixC(c.a1, c.ink, 0.5)]) });
      s += E(t('Кільце'), cx, a.y + a.h * 0.5, m * 0.42, m * 0.08, { stroke: c.a2, sw: c.u * 0.7, rot: -15 });
      s += P(t('Ракета'), `M${q(cx + m * 0.35)} ${q(a.y + a.h * 0.15)}l${q(m * 0.06)} ${q(-m * 0.1)}l${q(m * 0.06)} ${q(m * 0.1)}v${q(m * 0.15)}h${q(-m * 0.12)}Z`, { fill: c.ink === '#FFF4E0' ? '#FFF4E0' : c.sf });
      for (let i = 0; i < 20; i++) s += C(t('Зірка'), r() * c.W, c.top + r() * c.H * 0.55, c.u * (0.15 + r() * 0.35), { fill: c.ink, op: 0.8 });
    } else {
      // mid-century: boomerangs and starbursts
      s += P(t('Бумеранг'), `M${q(cx - m * 0.4)} ${q(a.y + a.h * 0.3)}Q${q(cx)} ${q(a.y + a.h * 0.75)} ${q(cx + m * 0.42)} ${q(a.y + a.h * 0.25)}Q${q(cx)} ${q(a.y + a.h * 0.55)} ${q(cx - m * 0.4)} ${q(a.y + a.h * 0.3)}Z`, { fill: c.a1 });
      s += Pg(t('Зірка'), star(cx + m * 0.25, a.y + a.h * 0.72, m * 0.12, m * 0.03, 8), { fill: c.a2 });
      s += Pg(t('Зірка'), star(cx - m * 0.3, a.y + a.h * 0.78, m * 0.07, m * 0.02, 8), { fill: c.ink });
      s += C(t('Атом'), cx - m * 0.05, a.y + a.h * 0.12, m * 0.05, { fill: c.a2 });
    }
    s += block(c, { bc: v === 'space' ? c.a1 : c.ink, tc: c.ink, kc: c.a1 }).svg;
    return s + footer(c);
  };
  MOTIF.collage = c => {
    const a = A(c), m = minA(c), v = c.st.v, r = c.r;
    let s = bgRect(c, c.bgc);
    const cols = [c.sf, c.a1, c.a2, mixC(c.bgc, '#FFFFFF', 0.5)];
    for (let i = 0; i < 5; i++) {
      const w = a.w * (0.35 + r() * 0.3), h = a.h * (0.3 + r() * 0.3), x = a.x + r() * (a.w - w), y = a.y + r() * (a.h - h);
      s += R(t('Аркуш {n}', { n: i + 1 }), x, y, w, h, { fill: cols[i % 4], rot: (r() - 0.5) * 16, stroke: v === 'punk' || v === 'grunge' ? c.ink : undefined, sw: c.u * 0.15 });
    }
    s += R(t('Скотч'), a.x + a.w * 0.35, a.y - c.u, a.w * 0.22, c.u * 3, { fill: '#F5E7B8', op: 0.85, rot: -8 });
    if (v === 'punk' || v === 'dada') for (let i = 0; i < 4; i++) s += Tx(c, t('Вирізка'), ['!', '?', '§', '&'][i], a.x + r() * a.w, a.y + r() * a.h, m * (0.14 + r() * 0.12), { family: i % 2 ? c.fh : c.fb, fill: i % 2 ? c.ink : c.a1, rot: Math.round((r() - 0.5) * 40), weight: 700 }).svg;
    if (v === 'kitsch' || v === 'max') for (let i = 0; i < 6; i++) s += Pg(t('Блиск'), star(a.x + r() * a.w, a.y + r() * a.h, m * 0.05, m * 0.015, 4), { fill: i % 2 ? c.a1 : c.a2 });
    if (v === 'fusion' || v === 'eclectic') s += P(t('Арка'), archD(a.x + a.w * 0.6, a.y + a.h * 0.25, a.w * 0.28, a.h * 0.7), { fill: c.a2 === c.ink ? c.a1 : c.a2, op: 0.9 });
    if (v === 'grunge') for (let i = 0; i < 30; i++) s += C(t('Пляма фарби'), a.x + r() * a.w, a.y + r() * a.h, c.u * r() * 0.6, { fill: c.ink, op: 0.6 });
    s += block(c, { upper: v === 'punk' || v === 'grunge' || v === 'dada', br: v === 'punk' || v === 'dada' ? 0 : undefined, bc: c.a1, tc: c.ink, kc: c.a2 === c.ink ? c.a1 : c.a2 }).svg;
    return s + footer(c);
  };
  MOTIF.editorial = c => {
    const a = A(c), m = minA(c), v = c.st.v;
    let s = bgRect(c, c.bgc);
    // masthead line + issue number
    s += Ln(t('Лінія шапки'), c.tr.x, c.top + c.u * 6, c.W - c.tr.x, c.top + c.u * 6, { stroke: c.ink, sw: c.u * 0.25, cap: 'butt' });
    s += Tx(c, t('Номер випуску'), t('Випуск') + ' №07', c.W - c.tr.x, c.top + c.u * 4.6, c.u * 1.6, { anchor: 'end', fill: c.ink2 }).svg;
    s += R(t('Фото'), a.x, a.y + c.u * 3, a.w * 0.62, a.h * 0.92, { fill: grad(c, [mixC(c.a1, '#FFFFFF', 0.25), c.a1]) });
    for (let col = 0; col < 2; col++) for (let i = 0; i < 9; i++) s += R(t('Рядок тексту'), a.x + a.w * (0.67 + col * 0.17), a.y + c.u * 3 + i * a.h * 0.1, a.w * 0.14, c.u * 0.5, { fill: c.ink, op: 0.25 });
    s += block(c, { italic: v !== 'trans', tw: 400, br: 0, bc: c.ink, kc: c.a1 }).svg;
    return s + footer(c);
  };
  MOTIF.japanese = c => {
    const a = A(c), m = minA(c), v = c.st.v, r = c.r;
    let s = bgRect(c, c.bgc);
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    if (v === 'moon') {
      s += C(t('Місячна брама'), cx, cy, m * 0.42, { stroke: c.a1, sw: c.u * 1.4 });
      s += C(t('Сонце'), cx, cy, m * 0.2, { fill: c.a1 });
      for (let i = 0; i < 4; i++) s += R(t('Ліхтарик'), a.x + a.w * (0.05 + i * 0.28), a.y, m * 0.08, m * 0.12, { fill: c.a1, rx: m * 0.03 });
    } else if (v === 'korean') {
      s += R(t('Аркуш ханджі'), cx - m * 0.4, cy - m * 0.4, m * 0.8, m * 0.8, { fill: c.sf, rx: m * 0.04 });
      s += C(t('Коло'), cx, cy, m * 0.22, { fill: c.a1 });
      s += P(t('Хвиля'), `M${q(cx - m * 0.3)} ${q(cy + m * 0.25)}q${q(m * 0.15)} ${q(-m * 0.1)} ${q(m * 0.3)} 0t${q(m * 0.3)} 0`, { stroke: c.a2, sw: c.u * 0.6, cap: 'round' });
    } else {
      s += C(t('Сонце'), cx + (v === 'japandi' ? m * 0.12 : 0), cy - m * 0.05, m * (v === 'japandi' ? 0.22 : 0.3), { fill: c.a1 });
      for (let i = 0; i < 3; i++) s += Ln(t('Лінія'), a.x + a.w * (0.15 + i * 0.05), a.y + a.h * 0.1, a.x + a.w * (0.15 + i * 0.05), a.y + a.h * 0.9, { stroke: c.ink, sw: c.u * 0.12, op: 0.4 });
      if (v === 'japandi') s += R(t('Полиця'), a.x + a.w * 0.1, a.y + a.h * 0.85, a.w * 0.8, c.u * 1.2, { fill: c.a2 });
      else s += P(t('Гілка'), `M${q(a.x + a.w * 0.95)} ${q(a.y + a.h * 0.15)}Q${q(cx)} ${q(cy - m * 0.35)} ${q(a.x + a.w * 0.35)} ${q(a.y + a.h * 0.3)}`, { stroke: c.ink, sw: c.u * 0.45, cap: 'round' });
      if (v !== 'japandi') for (let i = 0; i < 6; i++) s += C(t('Цвіт сакури'), a.x + a.w * (0.4 + r() * 0.5), a.y + a.h * (0.15 + r() * 0.15), c.u * 0.8, { fill: '#F2B5C4' });
    }
    s += block(c, { tw: v === 'moon' ? 700 : 500, bc: c.a1, br: v === 'moon' ? c.u * 0.4 : 0, tc: c.ink }).svg;
    return s + footer(c);
  };
  // borders of a repeated motif + a central motif (ethnic patterns, mosaics, pop dots)
  const band = (c, kind, x, y, w, h, cols) => {
    const n = Math.max(4, Math.round(w / h));
    const st = w / n;
    let s = '';
    for (let i = 0; i < n; i++) {
      const x0 = x + i * st, cx = x0 + st / 2, cy = y + h / 2, col = cols[i % cols.length];
      if (kind === 'kilim' || kind === 'stitch') s += Pg(t('Ромб'), [[cx, y + h * 0.08], [x0 + st * 0.95, cy], [cx, y + h * 0.92], [x0 + st * 0.05, cy]], { fill: col }) + (kind === 'stitch' ? Pg(t('Ромб'), [[cx, y + h * 0.32], [x0 + st * 0.72, cy], [cx, y + h * 0.68], [x0 + st * 0.28, cy]], { fill: c.bgc }) : '');
      else if (kind === 'zigzag') s += P(t('Сходинки'), `M${q(x0)} ${q(y + h)}V${q(y + h * 0.66)}H${q(x0 + st * 0.25)}V${q(y + h * 0.33)}H${q(x0 + st * 0.5)}V${q(y)}H${q(x0 + st * 0.75)}V${q(y + h * 0.33)}H${q(x0 + st)}V${q(y + h)}Z`, { fill: col });
      else if (kind === 'kente') s += R(t('Смуга кенте'), x0, y, st, h, { fill: col }) + R(t('Смуга кенте'), x0 + st * 0.2, y + h * 0.4, st * 0.6, h * 0.2, { fill: cols[(i + 1) % cols.length] });
      else if (kind === 'knit') s += Pg(t('Зірочка'), star(cx, cy, h * 0.42, h * 0.16, 8), { fill: col });
      else if (kind === 'zellige' || kind === 'mosaic') s += kind === 'mosaic' ? R(t('Смальта'), x0 + st * 0.08, y + h * 0.08, st * 0.84, h * 0.84, { fill: col }) : Pg(t('Зірка зелліж'), star(cx, cy, h * 0.46, h * 0.3, 8, -90), { fill: col });
      else if (kind === 'koru') s += P(t('Кору'), `M${q(x0 + st * 0.1)} ${q(cy)}C${q(x0 + st * 0.1)} ${q(y)} ${q(x0 + st * 0.9)} ${q(y)} ${q(x0 + st * 0.9)} ${q(cy)}C${q(x0 + st * 0.9)} ${q(y + h * 0.8)} ${q(x0 + st * 0.4)} ${q(y + h * 0.8)} ${q(x0 + st * 0.45)} ${q(cy)}`, { stroke: col, sw: h * 0.12, cap: 'round' });
      else if (kind === 'fiesta') s += Pg(t('Прапорець'), [[x0 + st * 0.05, y], [x0 + st * 0.95, y], [x0 + st * 0.95, y + h * 0.75], [cx, y + h], [x0 + st * 0.05, y + h * 0.75]], { fill: col });
      else if (kind === 'dots') s += C(t('Растрова крапка'), cx, cy, h * 0.3, { fill: col });
      else if (kind === 'mandala') s += C(t('Намистина'), cx, cy, h * 0.3, { fill: col });
    }
    return Gp(t('Орнамент'), s);
  };
  MOTIF.pattern = c => {
    const a = A(c), m = minA(c), v = c.st.v, r = c.r;
    let s = bgRect(c, c.bgc);
    const cols = [c.a1, c.a2 === c.ink ? c.ink : c.a2, mixC(c.a1, c.bgc, 0.35)];
    const bh = c.u * 4.2;
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    if (v === 'plaid') {
      for (let i = 0; i < 5; i++) { s += R(t('Смуга клітинки'), 0, c.top + c.H * (0.05 + i * 0.2), c.W, c.H * 0.06, { fill: i % 2 ? c.a2 : c.a1, op: 0.45 }); s += R(t('Смуга клітинки'), c.W * (0.05 + i * 0.2), c.top, c.W * 0.06, c.H - c.top, { fill: i % 2 ? c.a2 : c.a1, op: 0.45 }); }
      s += R(t('Табличка'), c.tr.x - c.u * 3, c.tr.y - c.u * 3, c.tr.w + c.u * 6, c.H - c.tr.y - c.u * 4, { fill: c.bgc, op: 0.94, rx: c.u });
    } else if (v === 'stripes') {
      for (let i = 0; i < 9; i++) s += R(t('Смуга тільняшки'), a.x, a.y + i * a.h / 9, a.w, a.h / 18, { fill: c.a1 });
      s += C(t('Рятувальний круг'), cx + m * 0.25, cy, m * 0.2, { stroke: c.a2, sw: m * 0.08 });
    } else if (v === 'dots') {
      for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) s += C(t('Растрова крапка'), a.x + (x + 0.5) * a.w / 8, a.y + (y + 0.5) * a.h / 8, m * 0.03 * (0.4 + (x + y) / 14), { fill: c.a1 });
      s += Pg(t('Вибух'), star(cx, cy, m * 0.36, m * 0.24, 12), { fill: c.a2, stroke: c.ink, sw: c.u * 0.5 });
      s += Tx(c, t('Вигук'), 'WOW!', cx, cy + m * 0.07, m * 0.16, { family: c.fh, anchor: 'middle', fill: '#FFFFFF' }).svg;
    } else if (v === 'mandala') {
      for (let k = 3; k >= 1; k--) for (let i = 0; i < 8 * k; i++) { const ang = i / (8 * k) * Math.PI * 2; s += P(t('Пелюстка мандали'), leafD(cx, cy, m * 0.15 * k, ang, 0.3), { fill: k % 2 ? c.a1 : c.a2, op: 0.9 }); }
      s += C(t('Центр мандали'), cx, cy, m * 0.07, { fill: '#E8C766' });
    } else {
      s += band(c, v, 0, c.top + c.u * 2, c.W, bh, cols);
      s += band(c, v, 0, c.H - c.u * 2 - bh, c.W, bh, cols);
      if (v === 'stitch' || v === 'knit') {
        // cross-stitch rhombus (вишиванка) / knitted star in the middle
        const cs = m * 0.06;
        for (let yy = -3; yy <= 3; yy++) for (let xx = -3; xx <= 3; xx++) if (Math.abs(xx) + Math.abs(yy) <= 3 && (Math.abs(xx) + Math.abs(yy)) % 2 === 1) s += P(t('Хрестик'), `M${q(cx + xx * cs - cs * 0.4)} ${q(cy + yy * cs - cs * 0.4)}l${q(cs * 0.8)} ${q(cs * 0.8)}M${q(cx + xx * cs + cs * 0.4)} ${q(cy + yy * cs - cs * 0.4)}l${q(-cs * 0.8)} ${q(cs * 0.8)}`, { stroke: Math.abs(xx) + Math.abs(yy) === 3 ? c.ink : c.a1, sw: cs * 0.28, cap: 'round' });
        s += Pg(t('Ромб'), [[cx, cy - cs * 0.9], [cx + cs * 0.9, cy], [cx, cy + cs * 0.9], [cx - cs * 0.9, cy]], { fill: c.a1 });
      } else if (v === 'zellige') {
        s += P(t('Арка'), archD(cx - m * 0.3, a.y + c.u * 3, m * 0.6, a.h - c.u * 3), { fill: c.a1, op: 0.18, stroke: c.a1, sw: c.u * 0.4 });
        s += Pg(t('Зірка'), star(cx, a.y + a.h * 0.45, m * 0.2, m * 0.12, 8), { fill: c.a2 === c.ink ? c.a1 : c.a2 });
      } else if (v === 'mosaic') {
        for (let y = 0; y < 6; y++) for (let x = 0; x < 6; x++) s += R(t('Смальта'), cx - m * 0.33 + x * m * 0.11, cy - m * 0.33 + y * m * 0.11, m * 0.1, m * 0.1, { fill: (x + y) % 3 === 0 ? c.a2 : c.a1, op: 0.7 + r() * 0.3 });
      } else {
        s += Pg(t('Ромб'), [[cx, cy - m * 0.38], [cx + m * 0.3, cy], [cx, cy + m * 0.38], [cx - m * 0.3, cy]], { fill: c.a1 });
        s += Pg(t('Ромб'), [[cx, cy - m * 0.2], [cx + m * 0.16, cy], [cx, cy + m * 0.2], [cx - m * 0.16, cy]], { fill: c.a2 === c.ink ? c.bgc : c.a2 });
      }
    }
    s += block(c, { bc: c.a1, tc: c.ink, kc: c.a1, br: v === 'fiesta' || v === 'dots' ? undefined : c.u * 0.4, upper: v === 'dots' }).svg;
    return s + footer(c);
  };
  MOTIF.soft = c => {
    const a = A(c), m = minA(c), v = c.st.v, r = c.r;
    let s = bgRect(c, c.bgc);
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    if (v === 'neu') {
      const w = m * 0.7, h = m * 0.55;
      s += R(t('Світла тінь'), cx - w / 2 - c.u, cy - h / 2 - c.u, w, h, { fill: '#FFFFFF', rx: m * 0.08, op: 0.9 });
      s += R(t('Темна тінь'), cx - w / 2 + c.u, cy - h / 2 + c.u, w, h, { fill: mixC(c.bgc, '#000000', 0.15), rx: m * 0.08 });
      s += R(t('Опукла картка'), cx - w / 2, cy - h / 2, w, h, { fill: c.bgc, rx: m * 0.08 });
      s += C(t('Перемикач'), cx + w * 0.2, cy, m * 0.08, { fill: c.a1 });
      s += R(t('Доріжка'), cx - w * 0.3, cy - m * 0.03, w * 0.4, m * 0.06, { fill: mixC(c.bgc, '#000000', 0.08), rx: m * 0.03 });
    } else if (v === 'clay') {
      const blob = (id, x, y, rad, col) => C(id, x, y, rad, { fill: grad(c, [mixC(col, '#FFFFFF', 0.45), col, mixC(col, '#000000', 0.15)], 0.3, 0.2, 0.7, 1) });
      s += blob(t('Кулька 1'), cx - m * 0.12, cy, m * 0.28, c.a1);
      s += blob(t('Кулька 2'), cx + m * 0.25, cy - m * 0.2, m * 0.13, c.a2);
      s += blob(t('Кулька 3'), cx + m * 0.22, cy + m * 0.25, m * 0.09, mixC(c.a1, c.a2, 0.5));
    } else {
      s += R(t('Форма 1'), cx - m * 0.42, cy - m * 0.3, m * 0.5, m * 0.6, { fill: c.a1, rx: m * 0.25 });
      s += C(t('Форма 2'), cx + m * 0.2, cy - m * 0.12, m * 0.2, { fill: c.a2 });
      s += R(t('Форма 3'), cx, cy + m * 0.12, m * 0.4, m * 0.18, { fill: c.sf, rx: m * 0.09 });
    }
    s += block(c, { bc: c.a1, btc: onColor(c.a1), tc: c.ink }).svg;
    return s + footer(c);
  };
  MOTIF.pixel = c => {
    const a = A(c), m = minA(c);
    let s = bgRect(c, c.bgc);
    const px = m / 13, heart = ['0110110', '1111111', '1111111', '0111110', '0011100', '0001000'];
    const x0 = a.x + a.w / 2 - px * 3.5 * 1.4, y0 = a.y + a.h / 2 - px * 3 * 1.4;
    heart.forEach((row, y) => [...row].forEach((v, x) => { if (v === '1') s += R(t('Піксель'), x0 + x * px * 1.4, y0 + y * px * 1.4, px * 1.4, px * 1.4, { fill: y < 2 && x > 4 ? '#FFFFFF' : c.a1 }); }));
    for (let i = 0; i < 12; i++) s += R(t('Зірочка'), a.x + c.r() * a.w, a.y + c.r() * a.h, px * 0.6, px * 0.6, { fill: c.a2 });
    s += R(t('Рамка'), c.u * 3, c.u * 3 + c.top, c.W - c.u * 6, c.H - c.u * 6 - c.top, { stroke: c.a2, sw: px * 0.5, dash: `${q(px)} ${q(px * 0.5)}` });
    s += block(c, { upper: true, br: 0, bc: c.a1, tc: c.ink, kc: c.a2, size: c.titleSize * 0.7 }).svg;
    return s + footer(c, c.a2);
  };
  MOTIF.tech = c => {
    const a = A(c), m = minA(c), v = c.st.v, r = c.r;
    let s = bgRect(c, c.bgc);
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    if (v === 'iso') {
      const cube = (x, y, sz, col, id) => { const h = sz * 0.58; return Gp(id, Pg(t('Верх'), [[x, y - h], [x + sz, y], [x, y + h], [x - sz, y]], { fill: mixC(col, '#FFFFFF', 0.35) }) + Pg(t('Ліва грань'), [[x - sz, y], [x, y + h], [x, y + h + sz * 1.1], [x - sz, y + sz * 1.1]], { fill: col }) + Pg(t('Права грань'), [[x + sz, y], [x, y + h], [x, y + h + sz * 1.1], [x + sz, y + sz * 1.1]], { fill: mixC(col, '#000000', 0.2) })); };
      s += cube(cx - m * 0.18, cy - m * 0.05, m * 0.17, c.a1, t('Кубик 1'));
      s += cube(cx + m * 0.18, cy + m * 0.05, m * 0.13, c.a2, t('Кубик 2'));
      s += cube(cx, cy - m * 0.3, m * 0.1, mixC(c.a1, c.a2, 0.5), t('Кубик 3'));
    } else {
      for (let i = 0; i < 9; i++) {
        const y = a.y + a.h * (0.1 + i * 0.1), x1 = a.x + r() * a.w * 0.3, x2 = a.x + a.w * (0.5 + r() * 0.5);
        s += P(t('Доріжка схеми'), `M${q(x1)} ${q(y)}H${q((x1 + x2) / 2)}L${q((x1 + x2) / 2 + a.h * 0.05)} ${q(y + a.h * 0.05)}H${q(x2)}`, { stroke: i % 3 ? c.a2 : c.a1, sw: c.u * 0.2 });
        s += C(t('Вузол'), x2, y + a.h * 0.05, c.u * 0.7, { fill: c.a1 });
      }
      s += C(t('Кільце'), cx, cy, m * 0.3, { stroke: c.a1, sw: c.u * 0.3, dash: `${q(c.u * 2)} ${q(c.u)}` });
      s += C(t('Ядро'), cx, cy, m * 0.12, { fill: c.a1, op: 0.85 });
    }
    s += block(c, { upper: v !== 'iso', br: v === 'iso' ? undefined : c.u * 0.4, bc: c.a1, tc: c.ink, kc: c.a1 }).svg;
    return s + footer(c);
  };
  MOTIF.line = c => {
    const a = A(c), m = minA(c), r = c.r;
    let s = bgRect(c, c.bgc);
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    // one continuous line: a face profile + a leaf
    s += P(t('Безперервна лінія'), `M${q(a.x)} ${q(cy + m * 0.3)}C${q(cx - m * 0.4)} ${q(cy + m * 0.3)} ${q(cx - m * 0.35)} ${q(cy - m * 0.45)} ${q(cx)} ${q(cy - m * 0.4)}C${q(cx + m * 0.25)} ${q(cy - m * 0.35)} ${q(cx + m * 0.2)} ${q(cy - m * 0.1)} ${q(cx + m * 0.28)} ${q(cy - m * 0.05)}C${q(cx + m * 0.32)} ${q(cy)} ${q(cx + m * 0.2)} ${q(cy + m * 0.05)} ${q(cx + m * 0.22)} ${q(cy + m * 0.12)}C${q(cx + m * 0.24)} ${q(cy + m * 0.2)} ${q(cx + m * 0.1)} ${q(cy + m * 0.3)} ${q(cx - m * 0.05)} ${q(cy + m * 0.32)}C${q(cx + m * 0.2)} ${q(cy + m * 0.45)} ${q(a.x + a.w)} ${q(cy + m * 0.2)} ${q(a.x + a.w)} ${q(cy - m * 0.3)}`, { stroke: c.ink, sw: c.u * 0.3, cap: 'round' });
    s += C(t('Акцент'), cx + m * 0.12, cy - m * 0.25, m * 0.1, { fill: c.a2, op: 0.85 });
    s += block(c, { tw: 400, bc: c.ink, tc: c.ink, kc: c.a2, br: 0, bfill: 'none', bstroke: c.ink, bsw: c.u * 0.15, btc: c.ink }).svg;
    return s + footer(c);
  };
  MOTIF.cards = c => {
    const a = A(c), m = minA(c);
    let s = bgRect(c, c.bgc);
    for (let i = 2; i >= 0; i--) {
      const x = a.x + a.w * 0.1 + i * c.u * 3, y = a.y + a.h * 0.1 + i * c.u * 3, w = a.w * 0.7, h = a.h * 0.62;
      s += R(t('Тінь картки'), x, y + c.u * 0.8, w, h, { fill: '#000000', op: 0.08, rx: m * 0.04 });
      s += R(t('Картка {n}', { n: 3 - i }), x, y, w, h, { fill: c.sf, rx: m * 0.04 });
      if (!i) { s += R(t('Обкладинка'), x, y, w, h * 0.45, { fill: c.a1, rx: m * 0.04 }); s += R(t('Рядок'), x + w * 0.08, y + h * 0.58, w * 0.6, m * 0.035, { fill: c.ink, op: 0.6, rx: m * 0.017 }); s += R(t('Рядок'), x + w * 0.08, y + h * 0.7, w * 0.4, m * 0.03, { fill: c.ink, op: 0.25, rx: m * 0.015 }); }
    }
    s += C(t('Кнопка дії'), a.x + a.w * 0.82, a.y + a.h * 0.78, m * 0.09, { fill: c.a2 });
    s += Tx(c, t('Плюс'), '+', a.x + a.w * 0.82, a.y + a.h * 0.78 + m * 0.045, m * 0.13, { fill: '#FFFFFF', anchor: 'middle', weight: 400 }).svg;
    s += block(c, { bc: c.a1, br: c.u * 0.8, tc: c.ink }).svg;
    return s + footer(c);
  };
  MOTIF.gears = c => {
    const a = A(c), m = minA(c);
    let s = bgRect(c, c.bgc);
    const gear = (id, x, y, r1, teeth, col) => { const pts = []; for (let i = 0; i < teeth * 2; i++) { const ang = i / (teeth * 2) * Math.PI * 2, rr = i % 2 ? r1 * 0.82 : r1; pts.push([x + Math.cos(ang) * rr, y + Math.sin(ang) * rr]); pts.push([x + Math.cos(ang + Math.PI / teeth * 0.9) * rr, y + Math.sin(ang + Math.PI / teeth * 0.9) * rr]); } return Gp(id, Pg(t('Зубці'), pts, { fill: col }) + C(t('Отвір'), x, y, r1 * 0.3, { fill: c.bgc })); };
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    s += gear(t('Шестерня 1'), cx - m * 0.12, cy, m * 0.3, 12, c.a1);
    s += gear(t('Шестерня 2'), cx + m * 0.28, cy - m * 0.22, m * 0.17, 9, c.a2);
    s += gear(t('Шестерня 3'), cx + m * 0.25, cy + m * 0.26, m * 0.12, 8, mixC(c.a1, '#FFFFFF', 0.25));
    s += block(c, { align: c.wide ? 'left' : 'center', upper: true, bc: c.a1, br: c.u * 0.4, tc: c.ink, kc: c.a1 }).svg;
    return s + footer(c, c.a1, c.wide ? 'left' : 'center');
  };
  MOTIF.duotone = c => {
    const a = A(c), m = minA(c);
    let s = bgRect(c, c.bgc);
    const cx = a.x + a.w / 2, cy = a.y + a.h / 2;
    s += C(t('Коло'), cx, cy, m * 0.45, { fill: c.a1 });
    s += P(t('Половина'), `M${q(cx)} ${q(cy - m * 0.45)}A${q(m * 0.45)} ${q(m * 0.45)} 0 0 1 ${q(cx)} ${q(cy + m * 0.45)}Z`, { fill: c.ink });
    s += Tx(c, t('Велика літера'), (c.txt.title || 'A')[0], cx, cy + m * 0.2, m * 0.6, { family: c.fh, anchor: 'middle', fill: c.bgc, weight: 700 }).svg;
    s += block(c, { upper: true, bc: c.ink, btc: c.bgc, tc: c.ink, kc: c.a1, br: 0 }).svg;
    return s + footer(c);
  };
  MOTIF.type = c => {
    const a = A(c), m = minA(c);
    let s = bgRect(c, c.bgc);
    const L = (c.txt.title || 'Aa').slice(0, 2);
    s += Tx(c, t('Велика літера'), L, a.x - c.u * 2, a.y + a.h * 0.92, a.h * 1.05, { family: c.fh, fill: c.a1, weight: 800 }).svg;
    s += C(t('Крапка'), a.x + a.w * 0.9, a.y + a.h * 0.85, m * 0.07, { fill: c.ink });
    s += block(c, { upper: true, br: 0, bc: c.ink, tc: c.ink, kc: c.a1 }).svg;
    return s + footer(c);
  };
  MOTIF.industrial = c => {
    const a = A(c), m = minA(c), soft = c.st.v === 'soft';
    let s = bgRect(c, c.bgc);
    const bw = a.w / 5, bh = bw / 2.6;
    const rows = Math.floor(a.h / bh);
    let d = '';
    for (let y = 0; y < rows; y++) for (let x = -1; x < 6; x++) { const x0 = a.x + x * bw + (y % 2 ? bw / 2 : 0); const xa = Math.max(a.x, x0 + c.u * 0.3), xb = Math.min(a.x + a.w, x0 + bw - c.u * 0.3); if (xb > xa) d += `M${q(xa)} ${q(a.y + y * bh + c.u * 0.3)}H${q(xb)}V${q(a.y + (y + 1) * bh - c.u * 0.3)}H${q(xa)}Z`; }
    s += P(t('Цегла'), d, { fill: soft ? c.sf : c.a1, op: soft ? 1 : 0.85 });
    s += R(t('Металева балка'), a.x - c.u * 2, a.y + a.h * 0.62, a.w + c.u * 4, c.u * 2.2, { fill: c.a2 });
    s += C(t('Лампа'), a.x + a.w * 0.7, a.y + a.h * 0.3, m * 0.07, { fill: '#F5C26B' });
    s += Ln(t('Дріт'), a.x + a.w * 0.7, a.y, a.x + a.w * 0.7, a.y + a.h * 0.3 - m * 0.07, { stroke: c.ink, sw: c.u * 0.2 });
    s += block(c, { upper: true, br: 0, bc: c.a1, tc: c.ink, kc: c.a1 }).svg;
    return s + footer(c);
  };

  // one template as SVG text (+ the background colour for the frame)
  GL.svg = (st, W, H, opts = {}) => {
    const c = ctxOf(st, W, H, opts);
    let body = '';
    try { body = (MOTIF[st.m] || MOTIF.minimal)(c); } catch (e) { console.error(st.k, e); body = MOTIF.minimal(c); }
    body += nav(c);
    return { svg: `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><defs>${c.defs.join('')}</defs>${body}</svg>`, bg: c.bgFill || st.pal[0] };
  };
  const thumbCache = new Map();
  GL.thumbSVG = (st, fmt = 'post', width = 240) => {
    const f = fmtOf(fmt === 'mix' ? GL.mixFormat(st) : fmt);
    const key = st.k + '|' + f[0] + '|' + O.lang;
    if (!thumbCache.has(key)) thumbCache.set(key, GL.svg(st, f[2], f[3], { web: f[0] === 'web' }).svg.replace('<svg ', `<svg class="gl-svg" preserveAspectRatio="xMidYMid meet" `).replace(/ width="\d+" height="\d+"/, ''));
    return thumbCache.get(key).replace('class="gl-svg"', `class="gl-svg" style="width:${width}px;max-width:100%;aspect-ratio:${f[2]}/${f[3]}"`);
  };
  GL.miniSwatch = st => `<span class="gl-mini">${st.pal.slice(0, 4).map(c => `<i style="background:${c}"></i>`).join('')}</span>`;
  O.on('lang', () => thumbCache.clear());

  // ======================================================================
  // INSERT A STYLE TEMPLATE
  // ======================================================================
  const loadFonts = st => { if (O.fonts) st.f.forEach(f => O.fonts.load(f, 400).catch(() => {})); if (O.fonts) O.fonts.load(st.f[0], 700).catch(() => {}); };
  // the SVG goes into the frame; its layers become the frame's children; the background is locked
  const fill = (f, st, W, H, opts) => {
    const { svg, bg } = GL.svg(st, W, H, opts);
    f.fills = [O.paint.solid(bg)];
    const g = O.io.importSVG(svg, { container: f, noCenter: true, noCommit: true, keepGroup: true, name: t(st.n) });
    if (!g) return;
    const kids = g.children.slice();
    kids.forEach(k => { k.m = M.mul(g.m, k.m); });
    f.children.splice(f.children.indexOf(g), 1, ...kids);
    kids.forEach(k => { if (k.name === t('Тло')) k.locked = true; });
    model.reindex();
  };
  GL.make = (k, fmt, at) => {
    const st = GL.get(k);
    if (!st) return [];
    const f0 = fmtOf(fmt);
    const page = model.page();
    let x = at ? at.x : 0;
    const y = at ? at.y : 0;
    const frames = [];
    const list = f0[0] === 'web' ? GL.WEB.map(([dev, w, h]) => ({ name: O.site ? O.site.frameName(dev, w, h) : `${t(dev)} — ${w}×${h}`, w, h, dev })) : [{ name: `${t(st.n)} — ${t(f0[1])}`, w: f0[2], h: f0[3] }];
    for (const d of list) {
      const f = model.create('frame', { name: d.name, w: d.w, h: d.h, m: M.translate(x, y), fills: [O.paint.solid(st.pal[0])], clip: true });
      model.insert(f, page);
      model.reindex();
      fill(f, st, d.w, d.h, { web: !!d.dev, dev: d.dev });
      if (d.dev && O.site) f.grids = [O.site.gridFor(O.site.kindOf(d.w))];
      frames.push(f);
      x += d.w + 160;
    }
    // website formats are joined by «Перо адаптації» at once: one responsive page
    if (frames.length > 1 && O.links) { const l = O.links.create('adapt', frames.map(f => f.id)); l.name = t(st.n); }
    loadFonts(st);
    return frames;
  };
  GL.use = async (k, fmt, opts = {}) => {
    const st = GL.get(k);
    if (!st) return;
    if (opts.newProject && O.projects && !O.projects.disabled) {
      const d = model.newDoc(); d.name = t(st.n);
      await O.projects.createFrom(d);
    }
    const page = model.page();
    const b = page.children.length ? model.selBounds(page.children.filter(n => n.visible !== false)) : null;
    const frames = GL.make(k, fmt, b ? { x: Math.round(b.x + b.w + 200), y: Math.round(b.y) } : { x: 0, y: 0 });
    O.select(frames.map(f => f.id));
    O.history.commit('Шаблон');
    setTimeout(() => V.fit(model.selBounds(frames), 80, 1), 0);
    remember('style:' + k);
    O.toast(frames.length > 1 ? 'Сайт «{name}»: {n} формати з’єднано «Пером адаптації»' : 'Шаблон «{name}» додано', { name: t(st.n), n: frames.length });
    return frames;
  };
  const remember = key => O.ls.set('glRecent', [key].concat(O.ls.get('glRecent', []).filter(x => x !== key)).slice(0, 24));

  // ======================================================================
  // OWN TEMPLATES (IndexedDB) — save, upload, download
  // ======================================================================
  const idb = O.idb;
  const IDX = 'tpl-index';
  GL.mine = async () => { try { const s = await idb.get('pdata', IDX); return s ? JSON.parse(s) : []; } catch (e) { return []; } };
  const saveIndex = list => idb.put('pdata', JSON.stringify(list), IDX);
  const assetsOf = nodes => {
    const ids = new Set();
    model.walk(nodes, n => { for (const p of (n.fills || []).concat(n.strokes || [])) if (p.type === 'image' && p.asset) ids.add(p.asset); if (n.asset) ids.add(n.asset); if (n.media) ids.add(n.media); });
    const out = {};
    for (const id of ids) if (S.doc.assets[id]) out[id] = S.doc.assets[id];
    return out;
  };
  const thumbOf = async nodes => {
    try { const b = model.selBounds(nodes); const { canvas } = await O.io.renderImage(nodes, { scale: Math.min(1, 420 / Math.max(b.w, b.h)), type: 'image/png', embedFonts: false }); return canvas.toDataURL('image/webp', 0.82); } catch (e) { return ''; }
  };
  // the selection (frames or any objects) → a template; positions are kept relative to each other
  GL.saveSelection = async () => {
    const nodes = O.topSel();
    if (!nodes.length) return O.toast('Виділіть фрейми або об’єкти, з яких зробити шаблон');
    ui.dialog({
      title: 'Зберегти як шаблон',
      body: `<div class="dlg-text">${esc(t('Шаблон з’явиться в галереї «Мої шаблони». Його можна вставити в будь-який проєкт або завантажити файлом .obrystpl, щоб поділитися.'))}</div>`,
      fields: [{ key: 'name', label: 'Назва', type: 'text', value: nodes.length === 1 ? nodes[0].name : S.doc.name }, { key: 'tags', label: 'Теги (через кому)', type: 'text', value: '' }],
      buttons: [{ id: 'ok', label: 'Зберегти шаблон', primary: true }],
      onOk: async v => {
        const data = GL.packNodes(nodes);
        const meta = { id: O.uid(), name: v.name.trim() || t('Шаблон'), tags: v.tags.split(',').map(s => s.trim()).filter(Boolean), w: Math.round(data.w), h: Math.round(data.h), count: nodes.length, created: Date.now(), thumb: await thumbOf(nodes) };
        await GL.storeTemplate(meta, data);
        O.toast('Шаблон «{name}» збережено в «Мої шаблони»', { name: meta.name });
        if (galEl) GL.render();
      }
    });
  };
  GL.packNodes = nodes => {
    const b = model.selBounds(nodes);
    const clones = nodes.map(n => { const c = O.clone(n); c.m = M.mul(M.translate(-b.x, -b.y), model.worldMatrix(n)); return c; });
    const ids = new Set(nodes.map(n => n.id));
    const links = (S.doc.links || []).filter(l => l.ids.every(id => ids.has(id))).map(l => O.clone(l));
    return { obrysTemplate: 1, nodes: clones, assets: assetsOf(nodes), links, w: b.w, h: b.h };
  };
  GL.storeTemplate = async (meta, data) => {
    await idb.put('pdata', JSON.stringify(data), 'tpl:' + meta.id);
    const list = await GL.mine();
    list.unshift(meta);
    await saveIndex(list);
  };
  const reid = (node, map) => { const old = node.id; node.id = O.uid(); map[old] = node.id; (node.children || []).forEach(c => reid(c, map)); };
  GL.insertMine = async (id, opts = {}) => {
    const raw = await idb.get('pdata', 'tpl:' + id);
    if (!raw) return O.toast('Шаблон не знайдено');
    const data = JSON.parse(raw);
    const list = await GL.mine(), meta = list.find(m => m.id === id) || { name: t('Шаблон') };
    if (opts.newProject && O.projects && !O.projects.disabled) { const d = model.newDoc(); d.name = meta.name; await O.projects.createFrom(d); }
    const page = model.page();
    const b = page.children.length ? model.selBounds(page.children.filter(n => n.visible !== false)) : null;
    const at = b ? { x: Math.round(b.x + b.w + 200), y: Math.round(b.y) } : { x: 0, y: 0 };
    let nodes = [];
    if (data.svg) {
      const f = model.create('frame', { name: meta.name, w: data.w, h: data.h, m: M.translate(at.x, at.y), fills: [O.paint.solid('#FFFFFF')], clip: true });
      model.insert(f, page); model.reindex();
      O.io.importSVG(data.svg, { container: f, noCenter: true, noCommit: true });
      nodes = [f];
    } else if (data.image) {
      const aid = O.uid();
      S.doc.assets[aid] = { data: data.image, w: data.w, h: data.h, name: meta.name };
      const f = model.create('frame', { name: meta.name, w: data.w, h: data.h, m: M.translate(at.x, at.y), fills: [O.paint.solid('#FFFFFF')], clip: true });
      f.children = [model.create('rect', { name: t('Зображення'), w: data.w, h: data.h, m: M.id(), fills: [Object.assign(O.paint.image(aid), { mode: 'fill' })] })];
      model.insert(f, page);
      nodes = [f];
    } else {
      Object.assign(S.doc.assets, data.assets || {});
      const map = {};
      nodes = (data.nodes || []).map(n => { const c = O.clone(n); reid(c, map); c.m = M.mul(M.translate(at.x, at.y), c.m); return c; });
      nodes.forEach(n => model.insert(n, page));
      for (const l of data.links || []) { const ids = l.ids.map(x => map[x]).filter(Boolean); if (ids.length > 1) { S.doc.links = S.doc.links || []; S.doc.links.push(Object.assign(O.clone(l), { id: O.uid(), ids })); } }
    }
    model.reindex();
    O.select(nodes.map(n => n.id));
    O.history.commit('Шаблон');
    setTimeout(() => V.fit(model.selBounds(nodes), 80, 1), 0);
    remember('user:' + id);
    O.toast('Шаблон «{name}» додано', { name: meta.name });
  };
  GL.downloadMine = async id => {
    const raw = await idb.get('pdata', 'tpl:' + id), meta = (await GL.mine()).find(m => m.id === id);
    if (!raw || !meta) return;
    const data = Object.assign(JSON.parse(raw), { name: meta.name, tags: meta.tags, thumb: meta.thumb });
    O.download(new Blob([JSON.stringify(data)], { type: 'application/json' }), String(meta.name).replace(/[\\/:*?"<>|]+/g, '_') + '.obrystpl');
  };
  GL.deleteMine = async id => {
    await idb.del('pdata', 'tpl:' + id);
    await saveIndex((await GL.mine()).filter(m => m.id !== id));
  };
  GL.renameMine = async (id, name) => { const list = await GL.mine(); const m = list.find(x => x.id === id); if (m) { m.name = name; await saveIndex(list); } };
  // template files: .obrystpl / .json (template or VIBSma document), .obrys, SVG, PNG / JPG / WEBP
  GL.upload = async files => {
    files = files || await O.io.pickFiles('.obrystpl,.obrys,.json,.svg,image/png,image/jpeg,image/webp', true);
    let n = 0;
    for (const f of files || []) {
      try {
        const base = f.name.replace(/\.[a-z0-9]+$/i, '');
        if (/\.(obrystpl|obrys|json)$/i.test(f.name)) {
          const d = JSON.parse(await f.text());
          if (d.obrysTemplate) { await GL.storeTemplate({ id: O.uid(), name: d.name || base, tags: d.tags || [], w: Math.round(d.w || 0), h: Math.round(d.h || 0), count: (d.nodes || []).length || 1, created: Date.now(), thumb: d.thumb || '' }, d); n++; continue; }
          if (Array.isArray(d.pages)) {
            // a whole VIBSma document: the frames of its first page
            const pg = d.pages[0], frames = (pg.children || []).filter(x => x.type === 'frame');
            const nodes = frames.length ? frames : (pg.children || []);
            if (!nodes.length) continue;
            const xs = nodes.map(x => (x.m || [1, 0, 0, 1, 0, 0])[4]), ys = nodes.map(x => (x.m || [1, 0, 0, 1, 0, 0])[5]);
            const x0 = Math.min(...xs), y0 = Math.min(...ys);
            const clones = nodes.map(x => { const c = O.clone(x); c.m = M.mul(M.translate(-x0, -y0), c.m || M.id()); return c; });
            const w = Math.max(...nodes.map(x => ((x.m || [])[4] || 0) - x0 + (x.w || 0))), h = Math.max(...nodes.map(x => ((x.m || [])[5] || 0) - y0 + (x.h || 0)));
            await GL.storeTemplate({ id: O.uid(), name: d.name || base, tags: [], w: Math.round(w), h: Math.round(h), count: nodes.length, created: Date.now(), thumb: '' }, { obrysTemplate: 1, nodes: clones, assets: d.assets || {}, links: (d.links || []).filter(l => l.ids.every(id => nodes.some(x => x.id === id))), w, h });
            n++;
          }
          continue;
        }
        if (/\.svg$/i.test(f.name) || f.type === 'image/svg+xml') {
          const text = await f.text();
          const doc = new DOMParser().parseFromString(text, 'image/svg+xml').documentElement;
          const vb = (doc.getAttribute('viewBox') || '').split(/[\s,]+/).map(Number);
          const w = parseFloat(doc.getAttribute('width')) || vb[2] || 800, h = parseFloat(doc.getAttribute('height')) || vb[3] || 600;
          await GL.storeTemplate({ id: O.uid(), name: base, tags: ['SVG'], w: Math.round(w), h: Math.round(h), count: 1, created: Date.now(), thumb: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(text) }, { obrysTemplate: 1, svg: text, w, h });
          n++; continue;
        }
        if (/^image\//.test(f.type)) {
          const data = await O.io.blobToData(f);
          const img = await O.io.loadImage(data);
          const k = Math.min(1, 1600 / Math.max(img.naturalWidth, img.naturalHeight));
          const cv = document.createElement('canvas'); cv.width = Math.round(img.naturalWidth * k); cv.height = Math.round(img.naturalHeight * k);
          cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
          const th = document.createElement('canvas'); const tk = Math.min(1, 420 / Math.max(cv.width, cv.height)); th.width = Math.round(cv.width * tk); th.height = Math.round(cv.height * tk); th.getContext('2d').drawImage(cv, 0, 0, th.width, th.height);
          await GL.storeTemplate({ id: O.uid(), name: base, tags: [t('Зображення')], w: img.naturalWidth, h: img.naturalHeight, count: 1, created: Date.now(), thumb: th.toDataURL('image/webp', 0.82) }, { obrysTemplate: 1, image: data, w: img.naturalWidth, h: img.naturalHeight });
          n++;
        }
      } catch (e) { console.warn(e); O.toast('«{name}» не вдалося прочитати як шаблон', { name: f.name }); }
    }
    if (n) O.toast('Додано шаблонів: {n}', { n });
    if (galEl) { view.sec = 'mine'; GL.render(); }
    return n;
  };

  // ======================================================================
  // BOARDS (Pinterest «Зберегти»)
  // ======================================================================
  const boards = () => { const b = O.ls.get('pinBoards', null); return Array.isArray(b) && b.length ? b : [{ id: 'saved', name: 'Збережене', items: [] }]; };
  const setBoards = b => O.ls.set('pinBoards', b);
  const isSaved = key => boards().some(b => b.items.includes(key));
  const toggleSave = (key, boardId) => {
    const b = boards();
    const bd = b.find(x => x.id === (boardId || 'saved')) || b[0];
    if (bd.items.includes(key)) bd.items = bd.items.filter(k => k !== key); else bd.items.unshift(key);
    setBoards(b);
    return bd.items.includes(key);
  };
  const boardName = b => (b.id === 'saved' ? t('Збережене') : b.name);

  // ======================================================================
  // GALLERY UI
  // ======================================================================
  let galEl = null;
  // xa / xm / xc: aesthetic, mood and colour filters of the 10 000 new styles
  const view = { sec: 'all', fmt: 'mix', q: '', detail: null, xa: '', xm: '', xc: '' };
  GL.close = () => { if (galEl) { galEl.remove(); galEl = null; } };
  GL.open = (opts = {}) => {
    GL.close();
    if (opts.sec) view.sec = opts.sec;
    if (opts.fmt) view.fmt = opts.fmt;
    view.detail = opts.style || null;
    galEl = O.h(`<div class="gl-back"><div class="gl" role="dialog" aria-modal="true" aria-label="${esc(t('Шаблони'))}">
      <header class="gl-h"><h2>${esc(t('Шаблони'))}</h2><div class="gl-search">${O.icon('search', 16)}<input type="search" class="gl-q" placeholder="${esc(t('Пошук стилів і шаблонів: бохо, неон, вишиванка…'))}" aria-label="${esc(t('Пошук шаблонів'))}"></div>
        <span class="sp"></span>
        <button type="button" class="btn primary" data-ga="ideas">📌 ${esc(t('1000 пінів Pinterest'))}</button>
        <button type="button" class="btn" data-ga="upload" title="${esc(t('Файли .obrystpl, .obrys, SVG або зображення'))}">${O.icon('download', 14)} ${esc(t('Завантажити шаблон…'))}</button>
        <button type="button" class="btn" data-ga="savesel">${O.icon('plus', 14)} ${esc(t('Зберегти виділене як шаблон'))}</button>
        <button type="button" class="ib" data-ga="close" aria-label="${esc(t('Закрити'))}">${O.icon('close', 16)}</button></header>
      <div class="gl-fmts" role="tablist">${[['mix', 'Мікс']].concat(GL.FORMATS.map(f => [f[0], f[1]])).map(([k, l]) => `<button type="button" data-gf="${k}" role="tab">${esc(t(l))}</button>`).join('')}</div>
      <div class="gl-body"><nav class="gl-side"></nav><main class="gl-main"></main></div></div></div>`);
    document.body.appendChild(galEl);
    const q = galEl.querySelector('.gl-q');
    q.value = view.q || '';
    q.addEventListener('input', O.debounce(() => { view.q = q.value; view.detail = null; GL.render(); }, 120));
    galEl.addEventListener('click', onClick);
    galEl.addEventListener('change', e => { const s = e.target.closest('[data-gx]'); if (s) { view[s.dataset.gx] = s.value; GL.render(); } });
    galEl.addEventListener('keydown', e => { if (e.key === 'Escape' && !O.$('.dlg-back') && !O.$('.menu')) { e.stopPropagation(); if (view.detail) { view.detail = null; GL.render(); } else GL.close(); } });
    galEl.addEventListener('dragover', e => { e.preventDefault(); e.stopPropagation(); galEl.classList.add('drop'); });
    galEl.addEventListener('dragleave', e => { if (e.target === galEl) galEl.classList.remove('drop'); });
    galEl.addEventListener('drop', e => { e.preventDefault(); e.stopPropagation(); galEl.classList.remove('drop'); const fs = Array.from(e.dataTransfer.files || []); if (fs.length) GL.upload(fs); });
    GL.render();
    setTimeout(() => q.focus(), 0);
  };
  let mineCache = [], wallSig = '', wallShown = 0;
  GL.render = async () => {
    if (!galEl) return;
    mineCache = await GL.mine();
    const side = galEl.querySelector('.gl-side'), main = galEl.querySelector('.gl-main');
    galEl.querySelectorAll('[data-gf]').forEach(b => b.classList.toggle('on', b.dataset.gf === view.fmt));
    const cnt = g => GL.STYLES.filter(s => s.g === g).length;
    const bl = boards();
    // the big catalogue (1000 pins, 1000 ideas, every Canva-type template) opens in the template gallery
    const TPm = O.templates;
    const tpAll = TPm ? (GL._tpAll = GL._tpAll || TPm.items('all', 'all', '').length) : 0;
    const catalog = TPm ? `<div class="gl-sh">${esc(t('Каталог шаблонів'))}</div>
      <button type="button" class="gl-s" data-gs="tp:kt"><span>🧩 ${esc(t('Шаблони VIBSma'))}</span><em>${TPm.KT.length}</em></button>
      <button type="button" class="gl-s" data-gs="tp:pins"><span>📌 ${esc(t('Піни Pinterest'))}</span><em>${TPm.items('pins', 'all', '').length}</em></button>
      <button type="button" class="gl-s" data-gs="tp:ideas"><span>✨ ${esc(t('Ідеї як у Canva'))}</span><em>${TPm.items('ideas', 'all', '').length}</em></button>
      <button type="button" class="gl-s" data-gs="tp:all"><span>${esc(t('Усі шаблони'))}</span><em>${tpAll}</em></button>
      <div class="gl-sh">${esc(t('Стилі'))}</div>` : '';
    side.innerHTML = `${catalog}<button type="button" class="gl-s${view.sec === 'all' ? ' on' : ''}" data-gs="all">${O.icon('grid', 15)}<span>${esc(t('Усі стилі'))}</span><em>${GL.STYLES.length}</em></button>
      ${GL.X ? `<button type="button" class="gl-s${view.sec === 'x' ? ' on' : ''}" data-gs="x"><span>✨ ${esc(t('10 000 нових стилів'))}</span><em>${GL.X.count}</em></button>` : ''}
      ${Object.entries(GL.GROUPS).map(([g, l]) => `<button type="button" class="gl-s${view.sec === g ? ' on' : ''}" data-gs="${g}"><i class="gl-dot g-${g}"></i><span>${esc(t(l))}</span><em>${cnt(g)}</em></button>`).join('')}
      <div class="gl-sh">${esc(t('Ваше'))}</div>
      <button type="button" class="gl-s${view.sec === 'mine' ? ' on' : ''}" data-gs="mine">${O.icon('folder', 15)}<span>${esc(t('Мої шаблони'))}</span><em>${mineCache.length}</em></button>
      <button type="button" class="gl-s${view.sec === 'recent' ? ' on' : ''}" data-gs="recent">${O.icon('rotate', 15)}<span>${esc(t('Нещодавні'))}</span></button>
      <div class="gl-sh">${esc(t('Дошки'))}<button type="button" class="ib" data-ga="newboard" title="${esc(t('Нова дошка'))}" aria-label="${esc(t('Нова дошка'))}">${O.icon('plus', 13)}</button></div>
      ${bl.map(b => `<button type="button" class="gl-s${view.sec === 'board:' + b.id ? ' on' : ''}" data-gs="board:${b.id}">${O.icon('heart', 15)}<span>${esc(boardName(b))}</span><em>${b.items.length}</em></button>`).join('')}`;
    main.onscroll = null;
    if (view.detail) { main.innerHTML = detailHTML(GL.get(view.detail)); lazyFonts(main); main.scrollTop = 0; return; }
    let cards = [];
    const fq = norm(view.q);
    const matchMine = m => !fq || norm(m.name).includes(fq) || (m.tags || []).some(x => norm(x).includes(fq));
    if (view.sec === 'mine') cards = mineCache.filter(matchMine).map(m => ({ user: m }));
    else if (view.sec === 'recent') cards = O.ls.get('glRecent', []).map(k => k.startsWith('style:') ? { style: GL.get(k.slice(6)) } : { user: mineCache.find(m => 'user:' + m.id === k) }).filter(x => x.style || x.user);
    else if (view.sec.startsWith('board:')) { const b = bl.find(x => 'board:' + x.id === view.sec); cards = (b ? b.items : []).map(k => k.startsWith('style:') ? { style: GL.get(k.slice(6)) } : { user: mineCache.find(m => 'user:' + m.id === k) }).filter(x => x.style || x.user); }
    else {
      const inX = s => s.x && (!view.xa || s.x.a === view.xa) && (!view.xm || s.x.m === view.xm) && (!view.xc || s.x.c === view.xc);
      cards = GL.search(view.q, Infinity).filter(s => (view.sec === 'x' ? inX(s) : view.sec === 'all' || s.g === view.sec)).map(s => ({ style: GL.get(s.k) }));
    }
    if (view.sec === 'all' && fq) cards = mineCache.filter(matchMine).map(m => ({ user: m })).concat(cards);
    const title = view.sec === 'all' ? t('Усі стилі') : view.sec === 'x' ? t('10 000 нових стилів') : GL.GROUPS[view.sec] ? t(GL.GROUPS[view.sec]) + ' ' + t('стилі') : view.sec === 'mine' ? t('Мої шаблони') : view.sec === 'recent' ? t('Нещодавні') : boardName(bl.find(x => 'board:' + x.id === view.sec) || bl[0]);
    const sel = (key, all, items) => `<select data-gx="${key}" aria-label="${esc(t(all))}"><option value="">${esc(t(all))}</option>${items.map(([k, n]) => `<option value="${k}"${view[key] === k ? ' selected' : ''}>${esc(t(n))}</option>`).join('')}</select>`;
    const filters = view.sec === 'x' && GL.X ? `<span class="gl-xf">${sel('xa', 'Усі стилі', GL.X.aesthetics)}${sel('xm', 'Будь-який настрій', GL.X.moods)}${sel('xc', 'Усі кольори', GL.X.colours)}</span>` : '';
    // thousands of styles: the wall grows while it scrolls (a re-render of the same list, e.g. after «Зберегти»,
    // keeps what was already shown and where the reader was)
    const PAGE = 48, sig = [view.sec, view.q, view.fmt, view.xa, view.xm, view.xc].join('|'), same = sig === wallSig;
    let shown = Math.min(same ? Math.max(PAGE, wallShown) : PAGE, cards.length);
    const keep = same ? main.scrollTop : 0;
    wallSig = sig; wallShown = shown;
    main.innerHTML = `<div class="gl-top"><h3>${esc(title)}</h3><span>${esc(t('Шаблонів: {n}', { n: cards.length }))}</span>${filters}${view.sec === 'mine' ? `<span class="sp"></span><span class="gl-tip">${esc(t('Перетягніть сюди файли шаблонів'))}</span>` : ''}</div>
      ${cards.length ? `<div class="gl-wall">${cards.slice(0, shown).map(cardHTML).join('')}</div>` : `<div class="gl-empty">${esc(view.sec === 'mine' ? t('Тут будуть ваші шаблони. Виділіть фрейм і натисніть «Зберегти виділене як шаблон» або завантажте файл.') : view.sec.startsWith('board:') ? t('Натисніть «Зберегти» на будь-якому шаблоні, щоб додати його на дошку.') : t('Нічого не знайдено'))}</div>`}`;
    main.scrollTop = keep;
    lazyFonts(main);
    const wall = main.querySelector('.gl-wall');
    if (wall && shown < cards.length) main.onscroll = () => {
      if (shown >= cards.length || main.scrollTop + main.clientHeight < main.scrollHeight - 900) return;
      const next = cards.slice(shown, shown + PAGE);
      shown += next.length; wallShown = shown;
      wall.insertAdjacentHTML('beforeend', next.map(cardHTML).join(''));
      lazyFonts(main);
    };
  };
  const cardHTML = c => {
    if (c.user) {
      const m = c.user;
      return `<article class="gl-card user" data-user="${m.id}"><button type="button" class="gl-th" data-ga="usemine" aria-label="${esc(t('Використати'))} ${esc(m.name)}">${m.thumb ? `<img src="${esc(m.thumb)}" alt="" loading="lazy">` : `<span class="gl-noth">${O.icon('frame', 34)}</span>`}</button>
        <button type="button" class="gl-save${isSaved('user:' + m.id) ? ' on' : ''}" data-ga="save" data-key="user:${m.id}">${esc(t(isSaved('user:' + m.id) ? 'Збережено' : 'Зберегти'))}</button>
        <div class="gl-meta"><b title="${esc(m.name)}">${esc(m.name)}</b><span>${m.w ? m.w + '×' + m.h : ''}${(m.tags || []).length ? ' · ' + esc(m.tags.join(', ')) : ''}</span><button type="button" class="ib" data-ga="minemenu" aria-label="${esc(t('Дії з шаблоном'))}">${O.icon('more', 15)}</button></div></article>`;
    }
    const s = c.style, key = 'style:' + s.k;
    return `<article class="gl-card" data-style="${s.k}"><button type="button" class="gl-th" data-ga="detail" aria-label="${esc(t(s.n))}">${GL.thumbSVG(s, view.fmt, 260)}</button>
      <button type="button" class="gl-save${isSaved(key) ? ' on' : ''}" data-ga="save" data-key="${key}">${esc(t(isSaved(key) ? 'Збережено' : 'Зберегти'))}</button>
      <button type="button" class="gl-use" data-ga="use">${esc(t('Використати'))}</button>
      <div class="gl-meta"><b>${esc(t(s.n))}</b><span><i class="gl-dot g-${s.g}"></i>${esc(t(s.gname))}</span>${GL.miniSwatch(s)}</div></article>`;
  };
  const detailHTML = s => {
    const fmt = view.fmt === 'mix' ? 'post' : view.fmt;
    // a new style: its other moods in this colour and other colours in this mood; a hand-made one: its 100 neighbours
    let similar;
    if (s.x) { const sib = GL.STYLES.filter(x => x.x && x !== s && x.x.a === s.x.a); similar = sib.filter(x => x.x.c === s.x.c).slice(0, 4).concat(sib.filter(x => x.x.m === s.x.m).filter((x, i) => i % 4 === 1).slice(0, 4)); }
    else similar = GL.CORE.filter(x => x !== s && (x.m === s.m || x.g === s.g)).sort((a, b) => (b.m === s.m) - (a.m === s.m)).slice(0, 8);
    const sibKey = (m, c) => `x-${s.x.a}-${m}-${c}`;
    const variants = s.x && GL.X ? `<h5>${esc(t('Кольори'))}</h5><div class="gl-xcols">${GL.X.colours.map(([ck, cn]) => { const v = GL.get(sibKey(s.x.m, ck)); return v ? `<button type="button" class="${ck === s.x.c ? 'on' : ''}" data-ga="detail" data-style="${v.k}" title="${esc(t(cn))}" aria-label="${esc(t(cn))}" style="--c:${v.pal[3]};--b:${v.pal[0]}"></button>` : ''; }).join('')}</div>
          <h5>${esc(t('Настрій'))}</h5><div class="gl-dfmt">${GL.X.moods.map(([mk, mn]) => `<button type="button" class="${mk === s.x.m ? 'on' : ''}" data-ga="detail" data-style="${sibKey(mk, s.x.c)}">${esc(t(mn))}</button>`).join('')}</div>` : '';
    return `<div class="gl-detail" data-style="${s.k}"><button type="button" class="link gl-backlink" data-ga="back">← ${esc(t('Усі шаблони'))}</button>
      <div class="gl-d"><div class="gl-d-img">${GL.thumbSVG(s, fmt, 520)}</div>
        <div class="gl-d-info"><span class="gl-kick"><i class="gl-dot g-${s.g}"></i>${esc(t(s.gname))}</span><h3>${esc(t(s.n))}</h3><p>${esc(t(s.d))}</p>
          ${variants}
          <h5>${esc(t('Палітра'))}</h5><div class="gl-pal">${s.pal.map(c => `<button type="button" class="gl-sw" style="--c:${c}" data-ga="copycolor" data-c="${c}" title="${esc(t('Копіювати'))} ${c}"><i></i><span>${c}</span></button>`).join('')}</div>
          <h5>${esc(t('Шрифти'))}</h5><div class="gl-fonts"><span style="font-family:'${esc(s.f[0])}',serif">${esc(s.f[0])}</span><span style="font-family:'${esc(s.f[1])}',sans-serif">${esc(s.f[1])}</span></div>
          <h5>${esc(t('Формат'))}</h5><div class="gl-dfmt">${GL.FORMATS.map(f => `<button type="button" class="${f[0] === fmt ? 'on' : ''}" data-gf="${f[0]}">${esc(t(f[1]))}${f[0] === 'web' ? '' : ` <em>${f[2]}×${f[3]}</em>`}</button>`).join('')}</div>
          ${fmt === 'web' ? `<p class="gl-note">${O.icon('adaptpen', 14)} ${esc(t('Три фрейми (1440, 768, 390 px) одразу з’єднано «Пером адаптації»: експорт HTML дає одну адаптивну сторінку.'))}</p>` : ''}
          <div class="gl-dbtns"><button type="button" class="btn primary" data-ga="use">${esc(t('Використати в цьому проєкті'))}</button><button type="button" class="btn" data-ga="usenew">${esc(t('Новий проєкт із шаблону'))}</button>
            <button type="button" class="btn${isSaved('style:' + s.k) ? ' on' : ''}" data-ga="save" data-key="style:${s.k}">${O.icon('heart', 14)} ${esc(t(isSaved('style:' + s.k) ? 'Збережено' : 'Зберегти'))}</button>
            <button type="button" class="btn" data-ga="claude">${O.icon('sparkle', 14)} ${esc(t('Дизайн з Claude у цьому стилі'))}</button>
            ${O.interior && O.interior.STYLES.some(x => x.k === s.k) ? `<button type="button" class="btn" data-ga="interior">${esc(t('Інтер’єр у цьому стилі'))}</button>` : ''}</div></div></div>
      <h4 class="gl-simh">${esc(t('Схожі стилі'))}</h4><div class="gl-wall small">${similar.map(x => cardHTML({ style: x })).join('')}</div></div>`;
  };
  // fonts of visible cards load as they scroll in
  let io = null;
  const lazyFonts = root => {
    if (!O.fonts) return;
    if (io) io.disconnect();
    io = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { const st = GL.get(e.target.dataset.style); if (st) st.f.forEach(f => O.fonts.load(f, 700).catch(() => {})); io.unobserve(e.target); } }), { root: root, rootMargin: '200px' }) : null;
    root.querySelectorAll('[data-style]').forEach(el => { if (io) io.observe(el); });
  };
  const onClick = async e => {
    if (e.target === galEl) return GL.close();
    const f = e.target.closest('[data-gf]');
    if (f) { view.fmt = f.dataset.gf; GL.render(); return; }
    const sBtn = e.target.closest('[data-gs]');
    if (sBtn && sBtn.dataset.gs.startsWith('tp:')) { GL.close(); if (O.templates) O.templates.open({ cat: sBtn.dataset.gs.slice(3) }); return; }
    if (sBtn) { view.sec = sBtn.dataset.gs; view.detail = null; GL.render(); return; }
    const a = e.target.closest('[data-ga]');
    if (!a) return;
    const card = e.target.closest('[data-style],[data-user]');
    const sk = card && card.dataset.style, uid = card && card.dataset.user;
    const fmt = view.fmt === 'mix' ? (sk && !view.detail ? GL.mixFormat(GL.get(sk)) : 'post') : view.fmt;
    switch (a.dataset.ga) {
      case 'close': GL.close(); break;
      case 'upload': GL.upload(); break;
      case 'ideas': GL.close(); if (O.templates) O.templates.open({ cat: 'pins' }); break;
      case 'savesel': GL.close(); GL.saveSelection(); break;
      case 'detail': view.detail = sk; GL.render(); break;
      case 'back': view.detail = null; GL.render(); break;
      case 'use': GL.close(); await GL.use(sk, fmt); break;
      case 'usenew': GL.close(); await GL.use(sk, fmt, { newProject: true }); break;
      case 'usemine': GL.close(); await GL.insertMine(uid); break;
      case 'claude': GL.close(); if (O.spotlight) O.spotlight.claudeDialog({ style: sk }); break;
      case 'interior': GL.close(); if (O.interior) { O.ls.set('interiorStyle', sk); O.interior.dialog(); } break;
      case 'copycolor': O.copyText(a.dataset.c); O.toast('Скопійовано: {v}', { v: a.dataset.c }); break;
      case 'newboard': ui.dialog({ title: 'Нова дошка', fields: [{ key: 'n', label: 'Назва', type: 'text', value: '' }], onOk: v => { const nm = v.n.trim(); if (!nm) return; const b = boards(); b.push({ id: O.uid(), name: nm, items: [] }); setBoards(b); GL.render(); } }); break;
      case 'save': {
        const key = a.dataset.key, bl = boards();
        if (bl.length === 1 || isSaved(key)) { const on = isSaved(key) ? (bl.forEach(b => { b.items = b.items.filter(k => k !== key); }), setBoards(bl), false) : toggleSave(key, bl[0].id); O.toast(on ? 'Збережено на дошку «{b}»' : 'Прибрано з дошок', { b: boardName(bl[0]) }); GL.render(); break; }
        const r = a.getBoundingClientRect();
        ui.menu(bl.map(b => ({ id: 'b:' + b.id, label: boardName(b) })), r.left, r.bottom + 4, { onPick: id => { toggleSave(key, id.slice(2)); O.toast('Збережено на дошку «{b}»', { b: boardName(bl.find(b => 'b:' + b.id === id)) }); GL.render(); } });
        break;
      }
      case 'minemenu': {
        const r = a.getBoundingClientRect();
        const m = mineCache.find(x => x.id === uid);
        ui.menu([{ id: 'use', label: 'Використати в цьому проєкті' }, { id: 'new', label: 'Новий проєкт із шаблону' }, { id: 'dl', label: 'Завантажити файл .obrystpl' }, { id: 'ren', label: 'Перейменувати' }, '-', { id: 'del', label: 'Видалити шаблон' }], r.left - 180, r.bottom + 4, {
          onPick: async id => {
            if (id === 'use') { GL.close(); GL.insertMine(uid); }
            if (id === 'new') { GL.close(); GL.insertMine(uid, { newProject: true }); }
            if (id === 'dl') GL.downloadMine(uid);
            if (id === 'ren') ui.dialog({ title: 'Перейменувати', fields: [{ key: 'n', label: 'Назва', type: 'text', value: m.name }], onOk: async v => { if (v.n.trim()) { await GL.renameMine(uid, v.n.trim()); GL.render(); } } });
            if (id === 'del') ui.dialog({ title: 'Видалити шаблон', body: `<div class="dlg-text">${esc(t('Видалити шаблон «{name}»? Цю дію не можна скасувати.', { name: m.name }))}</div>`, buttons: [{ id: 'ok', label: 'Видалити', primary: true }], onOk: async () => { await GL.deleteMine(uid); GL.render(); } });
          }
        });
        break;
      }
    }
  };

  // ---------- commands, menus, «New project» ----------
  O.ICONS.heart = O.ICONS.heart || '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>';
  O.ICONS.folder = O.ICONS.folder || '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>';
  O.cmd('templateGallery', 'Шаблони (10 000+ стилів, мої шаблони)…', () => GL.open(), { keys: ['Ctrl+Alt+Shift+T'], group: 'Файл' });
  O.cmd('saveTemplate', 'Зберегти виділене як шаблон…', () => GL.saveSelection(), { group: 'Файл', enabled: () => O.topSel().length > 0 });
  O.cmd('uploadTemplate', 'Завантажити шаблон із файлу…', () => GL.upload(), { group: 'Файл' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл');
  if (fileMenu) { const i = fileMenu[1].indexOf('new'); fileMenu[1].splice(i >= 0 ? i + 1 : 0, 0, 'templateGallery', 'saveTemplate', 'uploadTemplate'); }
  if (O.projects) {
    const tp = O.projects.templates;
    tp.splice(2, 0, { id: 'gallery', name: 'Шаблони: 2000+ дизайнів', icon: 'star', size: t('Canva · Pinterest'), make: () => { openCatalog(); return null; } });
  }
  // every «Templates» entry point opens the big catalogue (the 100 styles and own templates are one click away)
  const openCatalog = () => (O.templates ? O.templates.open({ cat: 'pins' }) : GL.open());
  // the project manager gets a «Шаблони» button
  const origPM = O.projects && O.projects.openManager;
  if (origPM) O.projects.openManager = async (...args) => {
    await origPM.apply(O.projects, args);
    const nb = O.$('.pm-h [data-a="new"]');
    if (nb && !O.$('.pm-h [data-a="gallery"]')) {
      const b = O.h(`<button type="button" class="btn" data-a="gallery">${O.icon('star', 14)} ${esc(t('Шаблони'))}</button>`);
      b.addEventListener('click', e => { e.stopPropagation(); O.projects.closeManager(); openCatalog(); });
      nb.parentNode.insertBefore(b, nb);
    }
  };
})();
