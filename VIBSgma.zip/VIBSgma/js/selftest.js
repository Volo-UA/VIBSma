'use strict';
/* Obrys — built-in self test. Open index.html?selftest to run. */
(function () {
  const O = window.O;
  const errors = [];
  window.addEventListener('error', e => errors.push('onerror: ' + e.message + ' @ ' + String(e.filename || '').split('/').pop() + ':' + e.lineno));
  window.addEventListener('unhandledrejection', e => errors.push('unhandled: ' + ((e.reason && (e.reason.stack || e.reason.message)) || e.reason)));
  const origErr = console.error;
  const short = s => String(s).replace(/file:\/\/\/[^\s)]*\/obrys\//g, '');
  console.error = function (...a) { errors.push(short('console.error: ' + a.map(x => x && x.stack ? x.stack.split('\n').slice(0, 4).join(' | ') : String(x)).join(' '))); origErr.apply(console, a); };

  O.selftest = async () => {
    O.trace = msg => { document.title = document.title.replace(/ \| .*$/, '') + ' | ' + msg; };
    const out = [];
    let fail = 0, pass = 0;
    const { model, M, G, ops, view: V } = O;
    const S = O.state;
    const record = (name, good, info) => { out.push((good ? 'PASS ' : 'FAIL ') + name + (info ? ' — ' + info : '')); if (good) pass++; else fail++; };
    const step = async (name, fn) => {
      const before = errors.length;
      document.title = 'SELFTEST running: ' + name + ' (' + (pass + fail) + ' done, ' + fail + ' failed)';
      try {
        const r = await fn();
        const errs = errors.slice(before);
        if (errs.length) record(name, false, 'errors: ' + errs.join(' || '));
        else record(name, r !== false, typeof r === 'string' ? r : '');
      } catch (e) { record(name, false, e.message + ' :: ' + short(String(e.stack || '').split('\n').slice(1, 3).join(' | '))); }
      O.flushRender();
    };
    const ev = (wx, wy, extra = {}) => {
      const s = V.toScreen({ x: wx, y: wy });
      const r = V.el.getBoundingClientRect();
      return Object.assign({ e: {}, clientX: r.left + s.x, clientY: r.top + s.y, s, p: { x: wx, y: wy }, shift: false, alt: false, ctrl: false, h: null, button: 0 }, extra);
    };
    const drag = (tool, pts, extra) => {
      O.setTool(tool);
      const t = O.tools[tool];
      t.down(ev(pts[0][0], pts[0][1], extra));
      for (const p of pts.slice(1)) if (t.move) t.move(ev(p[0], p[1], extra));
      const l = pts[pts.length - 1];
      if (t.up) t.up(ev(l[0], l[1], extra));
      O.flushRender();
    };
    const line = (a, b, n = 12) => { const o = []; for (let i = 0; i <= n; i++) o.push([a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n]); return o; };
    const count = () => model.page().children.length;
    const mkRect = (x, y, w, h, color) => { const n = model.create('rect', { w, h, m: M.translate(x, y), fills: [O.paint.solid(color || '#3366FF')] }); model.insert(n, model.page()); return n; };
    const geomOK = n => n && n.type === 'path' && n.subpaths.length > 0 && n.subpaths.every(sp => sp.pts.every(p => isFinite(p.x) && isFinite(p.y)));
    const fresh = () => { model.load(model.newDoc()); V.zoom = 1; V.x = 120; V.y = 120; V.apply(); O.setTool('select'); };

    await step('vendor libraries loaded', () => !!(window.paper && window.ClipperLib && window.ImageTracer && window.opentype) ? 'paper ' + window.paper.version : false);
    await step('blank document', () => { fresh(); return count() === 0; });
    await step('rectangle tool (drag)', () => { drag('rect', [[0, 0], [40, 30], [100, 80]]); const n = O.sel()[0]; return n && n.type === 'rect' && Math.abs(n.w - 100) < 0.01 && Math.abs(n.h - 80) < 0.01 ? `${n.w}×${n.h}` : false; });
    await step('ellipse tool (drag, shift)', () => { drag('ellipse', [[60, 20], [120, 70], [160, 100]], { shift: true }); const n = O.sel()[0]; return n && n.type === 'ellipse' && Math.abs(n.w - n.h) < 0.01; });
    await step('render produces SVG nodes', () => O.$$('#doc-root [data-id]').length >= 2 ? O.$$('#doc-root [data-id]').length + ' nodes' : false);
    await step('boolean group (live union)', () => {
      O.select(model.page().children.map(n => n.id));
      const b = ops.boolean('union');
      const r = model.boolResult(b);
      return b && b.type === 'bool' && r.length > 0 && model.localBounds(b).w > 150 ? 'bounds w=' + O.fmt(model.localBounds(b).w) : false;
    });
    await step('undo / redo', () => { O.history.undo(); const a = count(); O.history.redo(); const b = count(); return a === 2 && b === 1 ? '' : false; });
    await step('expand boolean to path', () => { O.select([model.page().children[0].id]); ops.expand(); return geomOK(O.sel()[0]); });
    await step('pathfinder divide', () => {
      fresh(); const a = mkRect(0, 0, 100, 100, '#FF0000'), b = mkRect(50, 50, 100, 100, '#00FF00');
      O.select([a.id, b.id]); ops.pathfinder('divide');
      const g = O.sel()[0];
      return g && g.type === 'group' && g.children.length === 3 ? '3 pieces' : 'pieces=' + (g && g.children && g.children.length) && false;
    });
    for (const k of ['trim', 'merge', 'crop', 'outline', 'minusback']) {
      await step('pathfinder ' + k, () => {
        fresh(); const a = mkRect(0, 0, 100, 100, '#FF0000'), b = mkRect(50, 50, 100, 100, k === 'merge' ? '#FF0000' : '#00FF00');
        O.select([a.id, b.id]); ops.pathfinder(k);
        const g = O.sel()[0];
        return g && g.children && g.children.length >= 1 ? g.children.length + ' result(s)' : false;
      });
    }
    await step('destructive minus front', () => { fresh(); const a = mkRect(0, 0, 100, 100), b = mkRect(50, 50, 100, 100); O.select([a.id, b.id]); const r = ops.boolean('subtract', null, { destructive: true }); return geomOK(r) && Math.abs(Math.abs(G.toPaper(r.subpaths).area) - 7500) < 1 ? 'area 7500' : false; });
    await step('pen tool (corner + smooth + Enter)', () => {
      fresh(); O.setTool('pen'); const t = O.tools.pen;
      t.down(ev(300, 0)); t.up(ev(300, 0));
      t.down(ev(400, 0)); t.move(ev(430, 30)); t.move(ev(450, 50)); t.up(ev(450, 50));
      t.down(ev(500, 100)); t.up(ev(500, 100));
      t.key({ key: 'Enter' });
      const n = model.page().children[0];
      return geomOK(n) && n.subpaths[0].pts.length === 3 && n.subpaths[0].pts[1].o ? '3 anchors, smooth middle' : false;
    });
    await step('pen closes path on first anchor', () => {
      O.setTool('pen'); const t = O.tools.pen; O.select([]);
      t.down(ev(0, 200)); t.up(ev(0, 200)); t.down(ev(100, 200)); t.up(ev(100, 200)); t.down(ev(50, 280)); t.up(ev(50, 280));
      t.down(ev(0, 200)); t.up(ev(0, 200));
      const n = model.page().children[model.page().children.length - 1];
      O.setTool('select');
      return n.subpaths[0].closed && n.subpaths[0].pts.length === 3;
    });
    await step('direct selection moves anchor', () => {
      const n = model.page().children[0];
      O.select([n.id]); S.edit = { id: n.id, sel: new Set(['0:0']) }; O.setTool('direct');
      const t = O.tools.direct, a = n.subpaths[0].pts[0];
      const x0 = a.x;
      t.startDrag(ev(a.x, a.y), n, 'anchors', '0:0'); t.move(ev(a.x + 20, a.y + 10)); t.move(ev(a.x + 30, a.y + 10)); t.up(ev(a.x + 30, a.y + 10));
      const moved = n.subpaths[0].pts[0].x - x0;
      O.setTool('select');
      return Math.abs(moved - 30) < 1 ? 'dx=' + O.fmt(moved) : false;
    });
    await step('pencil tool', () => { fresh(); const pts = []; for (let i = 0; i <= 40; i++) pts.push([i * 5, Math.sin(i / 4) * 30]); drag('pencil', pts); const n = O.sel()[0]; return geomOK(n) && n.subpaths[0].pts.length < 40 ? n.subpaths[0].pts.length + ' anchors after fitting' : false; });
    for (const bt of ['calligraphic', 'taper', 'round']) {
      await step('paintbrush ' + bt, () => {
        O.toolOpts.brushType = bt; const c0 = count();
        const pts = []; for (let i = 0; i <= 40; i++) pts.push([i * 6, 150 + Math.cos(i / 5) * 40]);
        drag('brush', pts); const n = O.sel()[0];
        if (count() !== c0 + 1) throw new Error('no new shape');
        const filled = bt === 'round' ? n.strokes.length && n.sw > 1 : n.fills.length && !n.strokes.length;
        return geomOK(n) && filled ? n.subpaths.length + ' contour(s), ' + n.subpaths[0].pts.length + ' anchors' : false;
      });
    }
    await step('blob brush merges strokes', () => {
      fresh(); drag('blob', line([0, 0], [200, 0])); const first = O.sel()[0].id;
      drag('blob', line([100, -50], [100, 50])); const n = O.sel()[0];
      return geomOK(n) && n.id === first && count() === 1 ? 'merged into one shape' : 'count=' + count() && false;
    });
    await step('eraser cuts shape', () => {
      fresh(); const r = mkRect(0, 0, 200, 100); O.select([]);
      O.view.zoom = 1; O.toolOpts.eraserSize = 20;
      drag('eraser', line([100, -40], [100, 140], 20));
      const n = model.get(r.id);
      return geomOK(n) ? n.subpaths.length + ' contours' : false;
    });
    await step('knife splits shape', () => {
      fresh(); mkRect(0, 0, 200, 100); O.select([]);
      drag('knife', line([100, -40], [100, 140], 20));
      return count() === 2 && model.page().children.every(geomOK) ? '2 pieces' : 'count=' + count() && false;
    });
    await step('scissors cuts open path in two', () => {
      fresh(); const n = model.create('path', { subpaths: [{ closed: false, pts: [G.pt(0, 0), G.pt(200, 0)] }] }); model.insert(n, model.page()); O.select([n.id]);
      O.setTool('scissors'); O.tools.scissors.down(ev(100, 0)); O.setTool('select');
      return count() === 2 ? '' : false;
    });
    await step('text tool + editing', () => {
      fresh(); O.setTool('text'); const t = O.tools.text; t.down(ev(10, 10)); t.up(ev(10, 10));
      const ta = O.$('#text-editor'); ta.value = 'Привіт, Обрис!'; O.textEdit.input(); O.textEdit.end();
      const n = O.sel()[0];
      return n && n.type === 'text' && n.text === 'Привіт, Обрис!' && model.localBounds(n).w > 50 ? 'w=' + O.fmt(model.localBounds(n).w) : false;
    });
    await step('area text wraps', () => { const n = model.create('text', { text: 'Дуже довгий текст, який має переноситися на кілька рядків', width: 120 }); model.insert(n, model.page()); return O.text.layout(n).lines.length > 2 ? O.text.layout(n).lines.length + ' lines' : false; });
    await step('text on path', () => {
      const e = model.create('ellipse', { w: 200, h: 200, m: M.translate(300, 0) }); model.insert(e, model.page());
      ops.textOnPath(e); O.textEdit.end(true);
      const n = O.sel()[0];
      O.flushRender();
      return n && n.type === 'text' && n.path && O.$$('#doc-root textPath').length > 0;
    });
    await step('outline stroke', () => {
      fresh(); const p = model.create('path', { sw: 10, subpaths: [{ closed: false, pts: [G.pt(0, 0), G.pt(100, 50, null, null), G.pt(200, 0)] }] }); model.insert(p, model.page()); O.select([p.id]);
      ops.outlineStroke(); const n = O.sel()[0];
      return geomOK(n) && n.fills.length && !n.strokes.length;
    });
    await step('offset path', () => { fresh(); const r = mkRect(0, 0, 100, 100); O.select([r.id]); ops.offsetPath(10, 'round', 4); const n = O.sel()[0]; const b = model.localBounds(n); return geomOK(n) && Math.abs(b.w - 120) < 1 ? 'w=' + O.fmt(b.w) : false; });
    await step('join two open paths', () => {
      fresh(); const a = model.create('path', { subpaths: [{ closed: false, pts: [G.pt(0, 0), G.pt(100, 0)] }] }), b = model.create('path', { subpaths: [{ closed: false, pts: [G.pt(110, 0), G.pt(200, 50)] }] });
      model.insert(a, model.page()); model.insert(b, model.page()); O.select([a.id, b.id]); ops.join();
      return count() === 1 && model.page().children[0].subpaths[0].pts.length === 4;
    });
    await step('compound path make / release', () => { fresh(); const a = mkRect(0, 0, 100, 100), b = mkRect(25, 25, 50, 50); O.select([a.id, b.id]); ops.makeCompound(); const c = O.sel()[0]; const ok1 = c.subpaths.length === 2 && c.fillRule === 'evenodd'; ops.releaseCompound(); return ok1 && count() === 2; });
    await step('clipping mask make / release', () => { fresh(); const a = mkRect(0, 0, 100, 100), b = model.create('ellipse', { w: 80, h: 80, m: M.translate(10, 10) }); model.insert(b, model.page()); O.select([a.id, b.id]); ops.makeClip('top'); const g = O.sel()[0]; O.flushRender(); const ok1 = g.mask && g.children[0].id === b.id && O.$$('#doc-defs clipPath').length > 0; ops.releaseClip(); return ok1 && !g.mask; });
    await step('group / ungroup / frame selection', () => { fresh(); const a = mkRect(0, 0, 50, 50), b = mkRect(100, 0, 50, 50); O.select([a.id, b.id]); const g = ops.group(); const ok1 = g.children.length === 2; ops.ungroup(); const ok2 = count() === 2; O.select([a.id, b.id]); const f = ops.frameSelection(); return ok1 && ok2 && f.type === 'frame' && Math.abs(f.w - 150) < 0.01; });
    await step('auto layout', () => { fresh(); const a = mkRect(0, 0, 50, 50), b = mkRect(80, 0, 50, 50), c = mkRect(160, 0, 50, 50); O.select([a.id, b.id, c.id]); ops.autoLayout(); const f = O.sel()[0]; model.layoutAll(); return f.layout && f.layout.dir === 'h' && Math.abs(f.w - (10 + 150 + 2 * f.layout.gap + 10)) < 0.01 ? 'gap=' + f.layout.gap : false; });
    await step('component, instance, detach', () => {
      fresh(); const a = mkRect(0, 0, 80, 40); O.select([a.id]); ops.createComponent(); const comp = O.sel()[0];
      ops.insertInstance(comp.id); const inst = O.sel()[0]; O.flushRender();
      const ok1 = comp.component && inst.type === 'instance' && O.$$(`#doc-root [data-id="${inst.id}"]`).length > 0;
      ops.detach(); const d = O.sel()[0];
      return ok1 && d.type === 'frame' && !d.component && d.children.length === 1;
    });
    await step('blend between shapes', () => { fresh(); const a = mkRect(0, 0, 50, 50, '#FF0000'), b = mkRect(300, 0, 50, 50, '#0000FF'); O.select([a.id, b.id]); ops.blend(a, b, 4); const g = O.sel()[0]; return g.children.length === 6 && g.children[2].fills[0].color !== '#FF0000' ? '4 steps' : false; });
    await step('blend different shapes', () => { fresh(); const a = mkRect(0, 0, 50, 50, '#FF0000'); const b = model.create('star', { w: 80, h: 80, m: M.translate(300, 0) }); model.insert(b, model.page()); ops.blend(a, b, 3); return O.sel()[0].children.length === 5; });
    for (const [name, fn] of [['pucker & bloat', () => ops.puckerBloat(40)], ['roughen', () => ops.roughen(3, 20, false)], ['zig zag', () => ops.zigzag(5, 4, true)], ['twist', () => ops.twist(90)], ['round corners', () => ops.roundCorners(8)], ['simplify', () => ops.simplifyPath(1)], ['smooth', () => ops.smoothPath()], ['add anchors', () => ops.addAnchors()], ['reverse', () => ops.reverse()]]) {
      await step('effect: ' + name, () => { fresh(); const s = model.create('star', { w: 100, h: 100 }); model.insert(s, model.page()); O.select([s.id]); fn(); return geomOK(model.get(s.id)); });
    }
    await step('transform each with copies', () => { fresh(); const a = mkRect(0, 0, 40, 40); O.select([a.id]); ops.transformEach({ sx: 90, sy: 90, dx: 50, dy: 0, rotate: 15, copies: 5 }); return count() === 6; });
    await step('rotate tool with Alt copy + transform again', () => {
      fresh(); const a = mkRect(0, 0, 100, 20); O.select([a.id]);
      O.setTool('rotate'); const t = O.tools.rotate; t.pivot = { x: 0, y: 0 };
      t.down(ev(100, 10, { alt: true })); t.move(ev(90, 40, { alt: true })); t.move(ev(80, 60, { alt: true })); t.up(ev(80, 60, { alt: true }));
      const c1 = count(); ops.duplicateCmd(); const c2 = count(); O.setTool('select');
      return c1 === 2 && c2 === 3 ? 'copies chained' : 'c1=' + c1 + ' c2=' + c2 && false;
    });
    for (const k of ['reflect', 'scale', 'shear']) {
      await step(k + ' tool', () => {
        fresh(); const a = mkRect(0, 0, 100, 50); O.select([a.id]); const before = JSON.stringify(a);
        O.setTool(k); const t = O.tools[k]; t.pivot = { x: 0, y: 0 };
        t.down(ev(100, 50)); t.move(ev(140, 70)); t.move(ev(160, 90)); t.up(ev(160, 90)); O.setTool('select');
        const n = model.get(a.id);
        const b = model.worldBounds(n);
        if (JSON.stringify(n) === before) throw new Error('node unchanged');
        return `${n.type}, bounds ${O.fmt(b.w)}×${O.fmt(b.h)}`;
      });
    }
    await step('select tool: move, resize, rotate', () => {
      fresh(); const a = mkRect(0, 0, 100, 100); O.select([a.id]); O.setTool('select'); O.requestRender(); O.flushRender();
      const t = O.tools.select;
      t.down(ev(50, 50)); t.move(ev(70, 60)); t.move(ev(90, 70)); t.up(ev(90, 70));
      const moved = Math.abs(a.m[4] - 40) < 1;
      const box = O.selBox(); void box;
      t.down(ev(140, 170, { h: 'se' })); t.move(ev(170, 200, { h: 'se' })); t.move(ev(190, 220, { h: 'se' })); t.up(ev(190, 220, { h: 'se' }));
      const resized = Math.abs(a.w - 150) < 1;
      t.down(ev(200, 230, { h: 'rot-se' })); t.move(ev(150, 260, { h: 'rot-se' })); t.up(ev(150, 260, { h: 'rot-se' }));
      const rotated = Math.abs(M.decompose(a.m).rot) > 0.05;
      if (!(moved && resized && rotated)) throw new Error(`moved=${moved}(${a.m[4]}) resized=${resized}(${a.w}) rotated=${rotated}`);
      return `w=${O.fmt(a.w)}, rot=${O.fmt(O.deg(M.decompose(a.m).rot), 1)}°`;
    });
    await step('alt-drag duplicates', () => { const t = O.tools.select; const n0 = count(); const c = R => R; void c; const a = model.page().children[0]; O.select([a.id]); const b = model.worldBounds(a); const cx = b.x + b.w / 2, cy = b.y + b.h / 2; t.down(ev(cx, cy, { alt: true })); t.move(ev(cx + 50, cy, { alt: true })); t.move(ev(cx + 300, cy, { alt: true })); t.up(ev(cx + 300, cy, { alt: true })); return count() === n0 + 1; });
    await step('align & distribute', () => { fresh(); const a = mkRect(0, 0, 10, 10), b = mkRect(50, 30, 10, 10), c = mkRect(200, 60, 10, 10); O.select([a.id, b.id, c.id]); ops.align('top'); const top = [a, b, c].every(n => Math.abs(model.worldBounds(n).y) < 1e-6); ops.distribute('h'); return top && Math.abs(model.worldBounds(b).x - 100) < 1e-6; });
    await step('gradient tool', () => { fresh(); const a = mkRect(0, 0, 100, 100); O.select([a.id]); drag('gradient', [[0, 50], [50, 50], [100, 50]]); return a.fills[0].type === 'linear' && Math.abs(a.fills[0].to.x - 1) < 0.01; });
    await step('eyedropper copies appearance', () => { fresh(); const a = mkRect(0, 0, 50, 50, '#FF0000'), b = mkRect(100, 0, 50, 50, '#00FF00'); b.sw = 4; b.strokes = [O.paint.solid('#000000')]; O.flushRender(); O.select([a.id]); O.setTool('eyedropper'); O.tools.eyedropper.down(ev(125, 25)); O.setTool('select'); return a.fills[0].color === '#00FF00' && a.sw === 4; });
    await step('shape builder merges regions', () => {
      fresh(); const a = mkRect(0, 0, 100, 100), b = mkRect(50, 0, 100, 100); O.select([a.id, b.id]); O.setTool('shapebuilder');
      const t = O.tools.shapebuilder; const n0 = t.regions.length;
      O.flushRender();
      t.down(ev(25, 50)); t.move(ev(75, 50)); t.up(ev(75, 50));
      const n1 = t.regions.length; O.setTool('select');
      return n0 === 3 && n1 === 2 ? '3 regions → 2' : `regions ${n0} → ${n1}` && false;
    });
    await step('double-click boolean selects operand', () => {
      fresh(); const a = mkRect(0, 0, 100, 100), b = mkRect(50, 50, 100, 100); O.select([a.id, b.id]); ops.boolean('union'); O.flushRender();
      O.setTool('select'); O.tools.select.dblclick(ev(20, 20));
      return O.sel()[0] && O.sel()[0].id === a.id;
    });
    await step('shortcuts work in Ukrainian layout (Ctrl+G via key «п»)', () => {
      fresh(); const a = mkRect(0, 0, 50, 50), b = mkRect(100, 0, 50, 50); O.select([a.id, b.id]);
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'п', code: 'KeyG', ctrlKey: true, bubbles: true }));
      const g = O.sel()[0];
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'к', code: 'KeyR', bubbles: true }));
      const tool = O.state.tool; O.setTool('select');
      return g && g.type === 'group' && tool === 'rect' ? 'Ctrl+G grouped, R → rectangle tool' : false;
    });
    await step('real pointer events: draw, then resize by handle', () => {
      fresh(); O.setTool('rect');
      const cv = V.el, r = cv.getBoundingClientRect();
      const pe = (type, wx, wy, target) => {
        const s = V.toScreen({ x: wx, y: wy });
        const x = r.left + s.x, y = r.top + s.y;
        const e = new PointerEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, pointerId: 7, button: 0, buttons: type === 'pointerup' ? 0 : 1, pointerType: 'mouse', isPrimary: true });
        (target || document.elementFromPoint(x, y) || cv).dispatchEvent(e);
      };
      pe('pointerdown', 10, 10); pe('pointermove', 60, 40); pe('pointermove', 110, 90); pe('pointerup', 110, 90);
      const n = O.sel()[0];
      if (!n || n.type !== 'rect') throw new Error('rectangle not drawn');
      if (O.state.tool !== 'rect') throw new Error('shape tool should stay active');
      O.setTool('select');
      O.requestOverlay(); O.flushRender();
      const handle = O.$('#overlay [data-h="se"]');
      if (!handle) throw new Error('no resize handle in overlay');
      pe('pointerdown', 110, 90, handle); pe('pointermove', 150, 120); pe('pointermove', 210, 190); pe('pointerup', 210, 190);
      if (!(Math.abs(n.w - 200) < 1 && Math.abs(n.h - 180) < 1)) throw new Error(`size ${n.w}×${n.h}`);
      return `${O.fmt(n.w)}×${O.fmt(n.h)}`;
    });
    await step('copy / paste', () => { fresh(); const a = mkRect(0, 0, 50, 50); O.select([a.id]); const clip = ops.copy(); ops.paste(clip); return count() === 2; });
    await step('export SVG markup', () => { const { svg } = O.render.svg(null, {}); return svg.startsWith('<svg') && svg.includes('<rect') ? svg.length + ' chars' : false; });
    await step('export PNG (canvas render)', async () => { const { blob } = await O.io.renderImage(model.page().children, { scale: 2, type: 'image/png' }); return blob && blob.size > 100 ? blob.size + ' bytes' : false; });
    await step('import SVG (gradients, transforms, arcs, text, clip)', () => {
      fresh();
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="400" height="400">
        <defs><linearGradient id="g1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff0"/><stop offset="1" stop-color="red"/></linearGradient>
        <clipPath id="cp"><circle cx="150" cy="150" r="30"/></clipPath><style>.st0{fill:#0a0;stroke:#000;stroke-width:2}</style></defs>
        <rect x="10" y="10" width="80" height="60" rx="8" fill="url(#g1)"/>
        <g transform="translate(100 0) rotate(15)"><circle class="st0" cx="40" cy="40" r="30"/></g>
        <path d="M10 120 a30 30 0 1 0 60 0 q20 -40 40 0 t40 0" fill="none" stroke="blue" stroke-width="3"/>
        <polygon points="10,190 50,150 90,190" fill="purple"/>
        <text x="110" y="100" font-size="16" font-family="Arial">Текст</text>
        <rect x="110" y="110" width="80" height="80" fill="orange" clip-path="url(#cp)"/>
      </svg>`;
      const g = O.io.importSVG(svg, {});
      if (!g) return false;
      const leaves = []; model.walk([g], n => { if (!n.children) leaves.push(n); });
      const b = model.worldBounds(g);
      const hasGrad = leaves.some(n => (n.fills || []).some(f => f.type === 'linear'));
      const hasClass = leaves.some(n => n.type === 'ellipse' && (n.fills[0] || {}).color === '#00AA00');
      const hasText = leaves.some(n => n.type === 'text');
      const clipped = (function f(n) { return n.mask || (n.children || []).some(f); })(g);
      return hasGrad && hasClass && hasText && clipped && Math.abs(b.w - 360) < 30 ? `${leaves.length} objects, ${O.fmt(b.w)}×${O.fmt(b.h)}` : `grad=${hasGrad} class=${hasClass} text=${hasText} clip=${clipped} w=${b.w}` && false;
    });
    await step('image import + image trace', async () => {
      fresh();
      const cv = document.createElement('canvas'); cv.width = 120; cv.height = 80;
      const c = cv.getContext('2d'); c.fillStyle = '#fff'; c.fillRect(0, 0, 120, 80); c.fillStyle = '#e33'; c.beginPath(); c.arc(40, 40, 25, 0, 7); c.fill(); c.fillStyle = '#33e'; c.fillRect(70, 15, 40, 50);
      const blob = await new Promise(r => cv.toBlob(r, 'image/png'));
      const n = await O.io.importImage(blob);
      if (!n || n.fills[0].type !== 'image') return false;
      O.select([n.id]);
      await ops.imageTrace('poster');
      const g = O.sel()[0];
      return g && g.type === 'group' && g.children.length > 0 ? 'traced ' + g.children.length + ' shapes' : false;
    });
    await step('rasterize', async () => { fresh(); const a = mkRect(0, 0, 60, 40); O.select([a.id]); await ops.rasterize(2); const n = O.sel()[0]; return n && n.fills[0].type === 'image' && S.doc.assets[n.fills[0].asset]; });
    await step('effects render as SVG filters', () => { fresh(); const a = mkRect(0, 0, 60, 40); a.effects = [{ type: 'shadow', x: 0, y: 4, blur: 8, spread: 2, color: '#000000', opacity: 0.3, visible: true }, { type: 'inner', x: 0, y: 2, blur: 4, color: '#000000', opacity: 0.3, visible: true }, { type: 'blur', blur: 2, visible: true }]; a.sa = 'inside'; a.sw = 4; a.strokes = [O.paint.solid('#000')]; O.requestRender(); O.flushRender(); return O.$$('#doc-defs filter').length === 1 && O.$$('#doc-defs clipPath').length >= 1; });
    await step('arrowheads on lines', () => { fresh(); drag('arrow', [[0, 0], [50, 0], [150, 0]]); O.flushRender(); return O.$$('#doc-defs marker').length === 1; });
    await step('shapes: polygon, star, spiral, arc, grid, polar, line, frame', () => {
      fresh(); let i = 0;
      for (const t of ['polygon', 'star', 'spiral', 'arc', 'grid', 'polar', 'line', 'frame']) { drag(t, [[i * 160, 0], [i * 160 + 60, 50], [i * 160 + 120, 100]]); i++; }
      return count() === 8 ? '' : 'count=' + count() && false;
    });
    await step('frame nesting on drop', () => {
      fresh(); drag('frame', [[0, 0], [200, 200], [400, 300]]); const f = O.sel()[0];
      const r = mkRect(500, 50, 50, 50); O.select([r.id]); const t = O.tools.select;
      O.requestRender(); O.flushRender();
      t.down(ev(525, 75)); t.move(ev(400, 75)); t.move(ev(225, 75)); t.up(ev(225, 75));
      if (model.parent(r) !== f) throw new Error('parent is ' + (model.parent(r).name || 'page'));
      return 'rectangle moved into frame';
    });
    await step('history depth', () => O.history.stack.length > 1 ? O.history.stack.length + ' snapshots' : false);
    await step('panels render for many selections', () => {
      O.run('sample');
      const all = []; model.walk(model.page().children, n => { all.push(n); });
      for (const n of all) { O.select([n.id]); O.panels.buildProps(); }
      O.select(all.slice(0, 4).map(n => n.id)); O.panels.buildProps();
      O.select([]); O.panels.buildProps(); O.panels.renderLayers();
      O.setTool('frame'); O.panels.buildProps(); O.setTool('select');
      return all.length + ' nodes inspected';
    });
    await step('inspect CSS for nodes', () => { const all = []; model.walk(model.page().children, n => { all.push(n); }); return all.every(n => typeof O.panels.cssFor(n) === 'string'); });
    await step('menus reference existing commands', () => {
      const missing = [];
      const walk = items => items.forEach(it => { if (it === '-') return; if (typeof it === 'string') { if (!O.cmds.has(it)) missing.push(it); } else if (it.items) walk(it.items); });
      O.MENUS.forEach(([, items]) => walk(items));
      O.MENUS.forEach(([, items], i) => { const el = O.ui.menu(items, 10, 10); void el; void i; O.ui.closeMenus(); });
      return missing.length ? 'missing: ' + missing.join(', ') && false : O.cmds.size + ' commands';
    });
    await step('context menu, palette, color picker, dialogs', () => {
      const n = model.page().children[0]; O.select([n.id]);
      O.showContextMenu(200, 200); O.ui.closeMenus();
      O.ui.palette(); const pal = O.$('.pal-back'); if (pal) pal.remove();
      const btn = document.createElement('button'); document.body.appendChild(btn);
      O.ui.picker.open(btn, O.paint.linear('#FF0000', '#0000FF'), { onChange: () => {} }); O.ui.picker.setType('radial'); O.ui.picker.setType('image'); O.ui.picker.setType('solid'); O.ui.picker.setColor('#123456'); O.ui.picker.close(); btn.remove();
      const d = O.ui.dialog({ title: 'T', fields: [{ key: 'a', label: 'A', type: 'number', value: 1 }], preview: true, apply: () => {} }); d.close();
      O.ops.transformDialog('rotate'); const back = O.$('.dlg-back'); if (back) back.remove();
      return true;
    });
    await step('sample document renders', () => {
      O.run('sample'); O.flushRender();
      const inst = []; model.walk(model.page().children, n => { if (n.type === 'instance') inst.push(n); });
      const comp = model.get(inst[0].ref);
      return O.$$('#doc-root [data-id]').length > 20 && Math.abs(inst[0].w - comp.w) < 0.01 && O.$$('#doc-root textPath').length === 1 ? O.$$('#doc-root [data-id]').length + ' rendered elements' : false;
    });
    await step('document serialize / load roundtrip', () => { const json = O.io.serialize(); const before = model.page().children.length; O.io.loadJSON(json, 'x.obrys'); return model.page().children.length === before; });
    await step('present mode', () => { O.run('present'); const el = O.$('.present'); const ok = el && el.querySelector('svg'); if (el) el.remove(); return !!ok; });
    await step('export selected objects (png, jpg, webp, svg)', async () => {
      O.run('sample');
      const pick = name => { let f = null; model.walk(model.page().children, n => { if (!f && n.name === name) f = n; }); return f; };
      const nested = pick('Сонце') || model.page().children[0].children[0];
      const top = model.page().children.find(n => n.type === 'frame');
      const got = [];
      const other = model.page().children.find(n => n !== nested && !model.isAncestor(n, nested));
      const orig = O.download;
      O.download = (blob, name) => got.push({ blob, name });
      try {
        for (const ids of [[nested.id], [top.id], [nested.id, other.id]]) {
          O.select(ids);
          for (const fmt of ['png', 'jpg', 'webp', 'svg']) { document.title = 'SELFTEST running: export ' + fmt + ' ' + ids.map(i => model.get(i).name).join('+') + ' files=' + got.length; await O.io.export(fmt, 1); }
        }
      } finally { O.download = orig; }
      if (got.length !== 12) throw new Error('files=' + got.length + ' ' + got.map(g => g.name).join(','));
      // several objects → one ZIP with one file per object
      const zips = got.filter(g => /\.zip$/.test(g.name));
      if (zips.length !== 4) throw new Error('zips=' + zips.length);
      const all = got.filter(g => !/\.zip$/.test(g.name));
      for (const z of zips) {
        const entries = O.interop.unzip(new Uint8Array(await z.blob.arrayBuffer()));
        const names = Object.keys(entries);
        if (names.length !== 2) throw new Error('zip entries ' + names.join(','));
        names.forEach(nm => all.push({ name: nm, blob: new Blob([entries[nm].data]) }));
      }
      const bad = [];
      for (const g of all) {
        if (!g.blob || g.blob.size < 60) { bad.push(g.name + ':' + (g.blob ? g.blob.size : 'null')); continue; }
        if (/\.(png|jpg|webp)$/.test(g.name)) {
          document.title = 'SELFTEST running: decode ' + g.name;
          let img;
          img = await O.io.loadImage(await O.io.blobToData(g.blob), 20000);
          const cv = document.createElement('canvas'); cv.width = img.naturalWidth; cv.height = img.naturalHeight;
          const c = cv.getContext('2d'); c.drawImage(img, 0, 0);
          const d = c.getImageData(0, 0, cv.width, cv.height).data;
          let ink = 0; for (let i = 3; i < d.length; i += 4 * 7) if (d[i] > 10 && (d[i - 1] < 240 || d[i - 2] < 240 || d[i - 3] < 240)) ink++;
          if (!ink) bad.push(g.name + ':blank');
        }
      }
      if (bad.length) throw new Error('bad: ' + bad.join(', '));
      // PDF pages (print HTML) and "all in one file"
      O.select([nested.id, other.id]);
      const html = await O.io.exportPDF(O.io.exportTargets(), { noWindow: true });
      if (!/<svg/.test(html) || (html.match(/class="pg"/g) || []).length !== 2) throw new Error('pdf html');
      const one = await O.io.exportFile(O.io.exportTargets({ together: true })[0], 'png', 1);
      if (!one.blob || one.blob.size < 100) throw new Error('together');
      return all.length + ' images (4 ZIPs), e.g. ' + got[0].name + ' ' + got[0].blob.size + ' B';
    });
    await step('fonts: Google Fonts catalogue + picker search', async () => {
      const F = O.fonts;
      if (F.google.length < 1500) throw new Error('catalogue ' + F.google.length);
      const g = F.get('montserrat');
      if (!g || !g.cyr || !/family=Montserrat:ital,wght@0,100;/.test(F.cssURL(g))) throw new Error('montserrat ' + (g && F.cssURL(g)));
      if (F.nearest(F.get('Buda'), 700, false).w !== 300) throw new Error('nearest');
      const btn = document.createElement('button'); document.body.appendChild(btn);
      const el = F.picker(btn, 'Inter', () => {});
      const q = el.querySelector('.fp-q'); q.value = 'Playfair'; q.dispatchEvent(new Event('input'));
      const names = Array.from(el.querySelectorAll('.fp-row')).map(r => r.dataset.fam);
      F.closePicker(); btn.remove();
      if (!names.includes('Playfair Display')) throw new Error('rows ' + names.join(','));
      return F.google.length + ' families; «Playfair» → ' + names.length + ' rows';
    });
    await step('animation: keyframes, interpolation, Lottie JSON, presets', async () => {
      fresh();
      const A = O.anim;
      const r = mkRect(0, 0, 100, 50, '#FF0000');
      O.select([r.id]);
      A.recordKey(r, 0);
      r.m = M.translate(200, 0); r.fills[0].color = '#0000FF';
      A.recordKey(r, 1);
      A.applyAt(0.5, true);
      const x = model.worldBounds(r).x;
      if (Math.abs(x - 100) > 1) throw new Error('mid x=' + x);
      if (r.fills[0].color.toUpperCase() === '#FF0000' || r.fills[0].color.toUpperCase() === '#0000FF') throw new Error('color not interpolated ' + r.fills[0].color);
      const { json } = await A.lottie(A.rootForExport(), {});
      const L = json.layers[0];
      if (!L || L.ty !== 4 || L.ks.p.a !== 1 || L.ks.p.k.length !== 2) throw new Error('lottie ' + JSON.stringify(L && L.ks.p).slice(0, 160));
      const fl = L.shapes.find(s => s.ty === 'fl');
      if (!fl || fl.c.a !== 1) throw new Error('fill not animated');
      A.applyAt(2);
      A.applyPreset('pop');
      const pk = r.anim.filter(k => k.t >= 2 - 1e-6).length;
      if (pk !== 3 || r.anim.length !== 5) throw new Error('preset keys ' + pk + '/' + r.anim.length);
      let keys = 0;
      try { A.toggle(true); A.render(); const tl = O.$('#timeline'); keys = tl ? tl.querySelectorAll('.tl-key').length : 0; } finally { A.toggle(false); }
      return `lottie ${json.w}×${json.h}, ${json.op} frames; timeline keys ${keys}`;
    });
    await step('HTML + CSS export builds', () => {
      O.run('sample');
      const f = model.page().children.find(n => n.type === 'frame');
      const res = O.html.build([f], {});
      if (!/<html/i.test(res.htmlInline) || res.css.length < 50) throw new Error('html ' + res.htmlInline.slice(0, 80));
      return res.css.length + ' B css, ' + res.htmlInline.length + ' B html';
    });
    await step('PSD export → import (ag-psd)', async () => {
      fresh();
      const f = model.create('frame', { name: 'PSD', w: 120, h: 80, m: M.translate(0, 0), fills: [O.paint.solid('#FFFFFF')] });
      model.insert(f, model.page());
      const r = model.create('rect', { w: 40, h: 30, m: M.translate(10, 10), fills: [O.paint.solid('#FF0000')] });
      model.insert(r, f);
      model.reindex();
      O.select([f.id]);
      const got = []; const orig = O.download; O.download = (b, n) => got.push({ b, n });
      try { await O.interop.exportPSD(); } finally { O.download = orig; }
      if (!got.length) throw new Error('no psd');
      await O.interop.importPSD(new File([got[0].b], 'test.psd'), { x: 500, y: 500 });
      const fr = O.sel()[0];
      if (!fr || fr.type !== 'frame' || fr.children.length < 2) throw new Error('import ' + (fr && fr.type) + ' ' + (fr && fr.children && fr.children.length));
      return got[0].b.size + ' B, layers ' + fr.children.length;
    });
    await step('animation pen: click 3 objects → CSS @keyframes', () => {
      fresh();
      const f = model.create('frame', { name: 'Екран', w: 400, h: 300, m: M.translate(0, 0) }); model.insert(f, model.page());
      const mk = (type, name, x, y, w, c) => { const n = model.create(type, { name, w, h: w, m: M.translate(x, y), fills: [O.paint.solid(c)] }); model.insert(n, f); return n; };
      const a = mk('rect', 'Кулька', 20, 20, 40, '#FF0000'), b = mk('rect', 'Кулька 2', 300, 200, 80, '#0000FF'), c = mk('ellipse', 'Кулька 3', 300, 20, 40, '#00FF00');
      model.reindex(); O.requestRender(); O.flushRender();
      O.setTool('animpen');
      const tl = O.tools.animpen;
      const click = n => { const r = model.worldBounds(n); tl.down(ev(r.x + r.w / 2, r.y + r.h / 2)); };
      click(a); click(b); click(c);
      tl.key({ key: 'Escape' });
      const l = (S.doc.links || [])[0];
      if (!l || l.ids.join() !== [a.id, b.id, c.id].join()) throw new Error('link ' + JSON.stringify(S.doc.links || []));
      O.flushRender();
      const arrows = O.$$('#overlay path[fill="#FF3D9A"]').length;
      const res = O.html.build([f], {});
      if (!/@keyframes obrys-kulka/.test(res.css) || !/animation: obrys-kulka/.test(res.css)) throw new Error('no keyframes ' + res.css.slice(-400));
      if (/class="kulka-2"|class="kulka-3"/.test(res.htmlInline)) throw new Error('states exported as elements');
      O.panels.buildProps();
      O.setTool('select');
      return `chain of 3, ${arrows} arrows, css ${res.css.length} B`;
    });
    await step('adaptation pen + website frames → one responsive page (@media)', () => {
      fresh();
      const devs = [{ group: 'Десктоп', name: 'Десктоп', w: 1440, h: 1024 }, { group: 'Планшет', name: 'iPad вертикально', w: 768, h: 1024 }, { group: 'Мобільний', name: 'iPhone 14/15', w: 390, h: 844 }];
      const frames = O.site.makeFrames(model.page().children, devs, { content: true, grids: true, name: 'Головна' });
      model.reindex(); O.requestRender(); O.flushRender();
      const l = (S.doc.links || []).find(x => x.kind === 'adapt');
      if (!l || l.ids.length !== 3) throw new Error('no link');
      if (frames[0].name !== O.t('Десктоп') + ' — 1440×1024' || frames[2].name !== O.t('iPhone 14/15') + ' — 390×844') throw new Error('names ' + frames.map(f => f.name).join(', '));
      const res = O.html.buildSite(l, {});
      const mq = res.css.match(/@media \(max-width: \d+px\)/g) || [];
      if (mq.length !== 2 || !/max-width: 1023px/.test(res.css) || !/max-width: 767px/.test(res.css)) throw new Error('media ' + mq.join(','));
      if (!/class="site"/.test(res.htmlInline) || !/class="zaholovok"/.test(res.htmlInline)) throw new Error('html ' + res.htmlInline.slice(0, 300));
      const grids = O.$('#overlay').innerHTML.split('fill-opacity="0.1"').length - 1;
      if (grids < 24) throw new Error('layout grid columns drawn: ' + grids);
      // the pen: link two new frames by clicking them
      const f1 = model.create('frame', { name: 'A', w: 600, h: 400, m: M.translate(0, 2000) }); model.insert(f1, model.page());
      const f2 = model.create('frame', { name: 'B', w: 300, h: 400, m: M.translate(800, 2000) }); model.insert(f2, model.page());
      model.reindex();
      O.setTool('adaptpen');
      const tl = O.tools.adaptpen;
      tl.down(ev(300, 2200)); tl.down(ev(950, 2200)); tl.key({ key: 'Escape' });
      const l2 = S.doc.links.find(x => x.kind === 'adapt' && x.ids.includes(f1.id));
      O.setTool('select');
      if (!l2 || !l2.ids.includes(f2.id)) throw new Error('pen did not link frames');
      const doc = O.site.siteDoc({ devs, content: true, grids: true, name: 'Про нас' });
      if (doc.pages[0].children.length !== 3 || (doc.links || []).length !== 1) throw new Error('template doc');
      return `${mq.join(' ')}; html ${res.htmlInline.length} B; grid stripes ${grids}`;
    });
    await step('vector PDF: save (bleed, marks, editable) → read with pdf.js → import as vectors', async () => {
      O.run('sample');
      const frames = model.page().children.filter(n => n.type === 'frame');
      const count0 = model.page().children.length;
      const res = await O.pdf.build(frames.map(f => [f]), { bleed: 3 * 72 / 25.4, marks: true, editable: true });
      const head = String.fromCharCode.apply(null, Array.from(res.bytes.slice(0, 5)));
      if (head !== '%PDF-') throw new Error('header ' + head);
      if (model.page().children.length !== count0 || !model.page().children.some(n => n.type === 'frame')) throw new Error('document changed by export');
      const back = await O.pdf.extractDoc(res.bytes);
      if (!back || !back.pages || back.pages[0].children.length !== count0) throw new Error('embedded document');
      const lib = await O.pdf.loadReader();
      const pdf = await lib.getDocument({ data: res.bytes.slice(), isEvalSupported: false }).promise;
      if (pdf.numPages !== frames.length) throw new Error('pages ' + pdf.numPages);
      fresh();
      const made = await O.pdf.open(new File([res.bytes], 'test.pdf', { type: 'application/pdf' }), { auto: true, target: 'page', mode: 'vector', ignoreEmbedded: true });
      if (!made || made.length !== frames.length) throw new Error('import ' + (made && made.length) + ' ' + O.pdf.lastErrors.join(' || ').slice(0, 900));
      let paths = 0, texts = 0, images = 0;
      model.walk(made, n => { if (n.type === 'path') paths++; if (n.type === 'text') texts++; if ((n.fills || []).some(f => f.type === 'image')) images++; });
      if (paths < 5) throw new Error('paths ' + paths);
      return `${res.bytes.length} B, ${pdf.numPages} pages, rasterised ${res.rastered}; import: ${paths} paths, ${texts} texts, ${images} images`;
    });
    await step('workspace areas: split, swap editors, close, maximise, workspaces', () => {
      const L = O.layout;
      if (!L || !L.active || L.mobile) return 'phone layout';
      L.resetSpace();
      const n0 = L.areas().length;
      const c = L.areas().find(a => a.area === 'canvas');
      L.split(c.id, 'v', 'history');
      if (L.areas().length !== n0 + 1 || !L.visible('history') || !O.$('#ws #ed-history')) throw new Error('split');
      const h = L.areas().find(a => a.area === 'history');
      L.setType(h.id, 'design');
      if (L.areas().filter(a => a.area === 'design').length !== 1 || !L.visible('history') || !L.visible('design')) throw new Error('swap');
      L.close(L.areas().find(a => a.area === 'history').id);
      if (L.areas().length !== n0) throw new Error('close');
      L.close(c.id);
      if (!L.visible('canvas')) throw new Error('canvas closed');
      L.toggleMax(c.id);
      if (O.$$('#ws .ws-area').length !== 1 || !O.$('#ws #canvas')) throw new Error('maximise');
      L.toggleMax();
      L.switchTo('anim');
      if (!L.visible('timeline') || !O.$('#ws #timeline')) throw new Error('animation workspace');
      L.switchTo('web');
      if (!L.visible('webview')) throw new Error('web workspace');
      L.switchTo('design'); L.resetSpace();
      const w = O.$('#canvas').clientWidth;
      if (w < 300 || !O.$('#ws #props') || !O.$('#ws #lp-layers')) throw new Error('design layout ' + w);
      return `${L.areas().length} areas, canvas ${w}px`;
    });
    await step('no runtime errors overall', () => errors.length === 0 ? '' : errors.slice(0, 5).join(' || ') && false);

    // leave the UI in a nice state
    O.run('sample');
    O.select([]);
    setTimeout(() => O.view.fit(null, 80, 1), 0);
    const pre = document.createElement('pre');
    pre.id = 'selftest-out';
    pre.textContent = `SELFTEST pass=${pass} fail=${fail}\n` + out.join('\n') + (errors.length ? '\n\nERRORS:\n' + errors.join('\n') : '');
    pre.style.cssText = 'position:fixed;left:8px;top:52px;z-index:5000;max-height:80vh;overflow:auto;background:rgba(0,0,0,.85);color:#9f9;font:11px monospace;padding:8px;border-radius:6px;max-width:60vw;white-space:pre-wrap;';
    document.body.appendChild(pre);
    document.title = `SELFTEST ${fail ? 'FAIL' : 'OK'} ${pass}/${pass + fail}`;
    return { pass, fail, out };
  };

  // visual scenarios for screenshots: index.html?fresh&shot=select&theme=light
  const params = new URLSearchParams(location.search);
  if (params.has('shot')) {
    window.addEventListener('load', () => setTimeout(() => {
      const theme = params.get('theme');
      if (theme) document.documentElement.dataset.theme = theme;
      const { model } = O;
      const find = name => { let f = null; model.walk(model.page().children, n => { if (!f && n.name === name) f = n; }); return f; };
      const shot = params.get('shot');
      if (shot === 'select') { const n = find('Обрис'); O.select([n.id]); }
      if (shot === 'sun') { const n = find('Сонце'); O.select([n.id]); }
      if (shot === 'picker') { const n = find('Сонце'); O.select([n.id]); setTimeout(() => { O.panels.refresh(true); const b = O.$('[data-a="fill-pick"]'); if (b) b.click(); }, 300); }
      if (shot === 'code') { const n = find('Обрис'); O.select([n.id]); setTimeout(() => { const L = O.layout; const a = L && L.active && L.areas().find(x => x.area === 'design'); if (a) L.setType(a.id, 'code'); else O.$('[data-rt="code"]').click(); }, 300); }
      if (shot === 'ws-anim') { O.layout.switchTo('anim'); const n = find('Сонце'); if (n) O.select([n.id]); }
      if (shot === 'ws-web') { O.layout.switchTo('web'); const f = model.page().children.find(x => x.type === 'frame'); if (f) O.select([f.id]); }
      if (shot === 'ws-split') { const L = O.layout; const c = L.areas().find(x => x.area === 'canvas'); L.split(c.id, 'v', 'history'); }
      if (shot === 'menu') { const b = O.$$('.mb-item')[2]; b.click(); setTimeout(() => { const subs = O.$$('.menu .mi.sub'); const pf = subs.find(s => s.textContent.includes('Обробка контурів')); if (pf) pf.dispatchEvent(new PointerEvent('pointerover', { bubbles: true })); }, 100); }
      if (shot === 'path') { const n = find('Близькі гори'); O.select([n.id]); O.state.edit = { id: n.id, sel: new Set(['0:1']) }; O.setTool('direct'); }
      if (shot === 'multi') { O.select(['Перо та криві', 'Обробка контурів', 'Текст по контуру'].map(find).filter(Boolean).map(n => model.parent(n).id)); }
      if (shot === 'pen') O.setTool('brush');
      if (shot === 'textedit') { const n = find('Привіт'); O.select([n.id]); O.view.setZoom(2, O.view.toScreen({ x: 700, y: 90 })); O.textEdit.start(n, { selectAll: false }); }
      if (shot === 'zoomtext') { const n = find('Привіт'); O.select([n.id]); O.view.setZoom(2, O.view.toScreen({ x: 700, y: 90 })); }
      if (shot === 'site' || shot === 'sitehtml') {
        const devs = [{ group: 'Десктоп', name: 'Десктоп', w: 1440, h: 1024 }, { group: 'Планшет', name: 'iPad вертикально', w: 768, h: 1024 }, { group: 'Мобільний', name: 'iPhone 14/15', w: 390, h: 844 }];
        model.load(O.site.siteDoc({ devs, content: true, grids: true, name: 'Головна' }));
        if (shot === 'site') { O.setTool('adaptpen'); setTimeout(() => O.view.fit(null, 60, 1), 50); }
        else {
          const l = O.state.doc.links[0];
          const fr = document.createElement('iframe');
          const fw = +params.get('fw') || 0;
          fr.style.cssText = `position:fixed;left:0;top:0;width:${fw ? fw + 'px' : '100%'};height:100%;border:0;z-index:99999;background:#fff;box-shadow:0 0 0 1px #f0f`;
          document.body.appendChild(fr);
          fr.srcdoc = O.html.buildSite(l, {}).htmlInline;
        }
      }
      if (shot === 'pdfview') {
        (async () => {
          const frames = model.page().children.filter(n => n.type === 'frame');
          const res = await O.pdf.build(frames.map(f => [f]), { bleed: 3 * 72 / 25.4, marks: true });
          const lib = await O.pdf.loadReader();
          const pdf = await lib.getDocument({ data: res.bytes.slice(), isEvalSupported: false }).promise;
          const box = document.createElement('div');
          box.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#555;display:flex;gap:16px;padding:16px;align-items:flex-start;overflow:hidden';
          document.body.appendChild(box);
          for (let i = 1; i <= Math.min(3, pdf.numPages); i++) {
            const page = await pdf.getPage(i);
            const vp0 = page.getViewport({ scale: 1 });
            const vp = page.getViewport({ scale: Math.min(1.1, 900 / vp0.height) });
            const cv = document.createElement('canvas'); cv.width = vp.width; cv.height = vp.height;
            await page.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise;
            box.appendChild(cv);
          }
          const tag = document.createElement('div'); tag.style.cssText = 'position:fixed;left:16px;bottom:8px;color:#fff;font:12px monospace;z-index:100000'; tag.textContent = `PDF ${res.bytes.length} B, pages ${res.pages}, rasterised ${res.rastered}`; document.body.appendChild(tag);
          window.__shotReady = true;
        })().catch(e => { window.__shotReady = 'error: ' + e.message; });
      }
      if (shot === 'animpen') {
        model.load(model.newDoc());
        const f = model.create('frame', { name: 'Екран', w: 600, h: 400, m: O.M.translate(0, 0) }); model.insert(f, model.page());
        const mk = (type, name, x, y, w, c) => { const n = model.create(type, { name, w, h: w, m: O.M.translate(x, y), fills: [O.paint.solid(c)], radius: 12 }); model.insert(n, f); return n; };
        const a = mk('rect', 'Кулька', 40, 40, 60, '#FF3D9A'), b = mk('rect', 'Кулька 2', 420, 240, 120, '#0D99FF'), c = mk('ellipse', 'Кулька 3', 460, 40, 60, '#14AE5C');
        model.reindex();
        O.links.create('anim', [a.id, b.id, c.id]);
        O.setTool('animpen');
        O.links.sel = O.state.doc.links[0].id;
        setTimeout(() => O.view.fit(null, 120, 1.4), 50);
      }
      O.requestRender();
    }, 400));
  }
})();
