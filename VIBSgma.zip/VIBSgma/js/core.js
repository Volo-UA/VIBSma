'use strict';
/* Obrys — core: namespace, matrix math, rects, colors, events, DOM helpers */
(function () {
  const O = window.O = window.O || {};

  // ---------- numbers ----------
  O.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  O.lerp = (a, b, t) => a + (b - a) * t;
  O.n = v => { // compact number for SVG output
    if (!isFinite(v)) return '0';
    const r = Math.round(v * 1000) / 1000;
    return (r === 0 ? 0 : r).toString();
  };
  O.fmt = (v, d = 2) => {
    if (v === null || v === undefined || !isFinite(v)) return '';
    const p = Math.pow(10, d);
    const r = Math.round(v * p) / p;
    return (r === 0 ? 0 : r).toString();
  };
  O.deg = r => r * 180 / Math.PI;
  O.rad = d => d * Math.PI / 180;
  let uidCounter = 0;
  O.uid = () => (Date.now().toString(36).slice(-4) + (uidCounter++).toString(36) + Math.random().toString(36).slice(2, 6));
  O.clone = o => JSON.parse(JSON.stringify(o));

  // ---------- points ----------
  const P = O.P = {
    add: (a, b) => ({ x: a.x + b.x, y: a.y + b.y }),
    sub: (a, b) => ({ x: a.x - b.x, y: a.y - b.y }),
    mul: (a, s) => ({ x: a.x * s, y: a.y * s }),
    len: a => Math.hypot(a.x, a.y),
    dist: (a, b) => Math.hypot(a.x - b.x, a.y - b.y),
    lerp: (a, b, t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t }),
    norm: a => { const l = Math.hypot(a.x, a.y) || 1; return { x: a.x / l, y: a.y / l }; },
    rot: (a, ang, c) => {
      c = c || { x: 0, y: 0 };
      const s = Math.sin(ang), co = Math.cos(ang), dx = a.x - c.x, dy = a.y - c.y;
      return { x: c.x + dx * co - dy * s, y: c.y + dx * s + dy * co };
    },
    angle: (a, b) => Math.atan2(b.y - a.y, b.x - a.x),
    // constrain vector to multiples of 45 degrees
    snap45: (o, p) => {
      const ang = Math.atan2(p.y - o.y, p.x - o.x);
      const a = Math.round(ang / (Math.PI / 4)) * (Math.PI / 4);
      const d = Math.hypot(p.x - o.x, p.y - o.y);
      const len = Math.abs(Math.cos(ang - a)) * d;
      return { x: o.x + Math.cos(a) * len, y: o.y + Math.sin(a) * len };
    }
  };

  // ---------- 2D affine matrices [a,b,c,d,e,f] ----------
  const M = O.M = {
    id: () => [1, 0, 0, 1, 0, 0],
    mul(m, n) {
      return [
        m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1],
        m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3],
        m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]
      ];
    },
    chain(...ms) { return ms.reduce((acc, m) => M.mul(acc, m), M.id()); },
    det: m => m[0] * m[3] - m[1] * m[2],
    inv(m) {
      const det = m[0] * m[3] - m[1] * m[2];
      if (Math.abs(det) < 1e-12) return M.id();
      return [m[3] / det, -m[1] / det, -m[2] / det, m[0] / det,
        (m[2] * m[5] - m[3] * m[4]) / det, (m[1] * m[4] - m[0] * m[5]) / det];
    },
    apply: (m, p) => ({ x: m[0] * p.x + m[2] * p.y + m[4], y: m[1] * p.x + m[3] * p.y + m[5] }),
    applyV: (m, v) => ({ x: m[0] * v.x + m[2] * v.y, y: m[1] * v.x + m[3] * v.y }),
    translate: (x, y) => [1, 0, 0, 1, x, y],
    scale: (sx, sy) => [sx, 0, 0, sy === undefined ? sx : sy, 0, 0],
    rotate(a) { const c = Math.cos(a), s = Math.sin(a); return [c, s, -s, c, 0, 0]; },
    skewX: a => [1, 0, Math.tan(a), 1, 0, 0],
    skewY: a => [1, Math.tan(a), 0, 1, 0, 0],
    about: (m, p) => M.mul(M.translate(p.x, p.y), M.mul(m, M.translate(-p.x, -p.y))),
    // m = T * R * SkewX * S
    decompose(m) {
      const [a, b, c, d, e, f] = m;
      const sx = Math.hypot(a, b);
      const rot = Math.atan2(b, a);
      const co = Math.cos(rot), si = Math.sin(rot);
      const c2 = c * co + d * si;
      const sy = -c * si + d * co;
      const skew = Math.abs(sy) > 1e-12 ? Math.atan(c2 / sy) : 0;
      return { tx: e, ty: f, rot, sx, sy, skew };
    },
    compose(d) {
      return M.chain(M.translate(d.tx, d.ty), M.rotate(d.rot), M.skewX(d.skew || 0), M.scale(d.sx, d.sy));
    },
    isId: m => Math.abs(m[0] - 1) < 1e-9 && Math.abs(m[1]) < 1e-9 && Math.abs(m[2]) < 1e-9 && Math.abs(m[3] - 1) < 1e-9 && Math.abs(m[4]) < 1e-9 && Math.abs(m[5]) < 1e-9,
    str: m => 'matrix(' + m.map(O.n).join(' ') + ')',
    css: m => 'matrix(' + m.join(',') + ')'
  };

  // ---------- rects {x,y,w,h} ----------
  const R = O.R = {
    fromPts(pts) {
      if (!pts.length) return null;
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      for (const p of pts) { if (p.x < x0) x0 = p.x; if (p.y < y0) y0 = p.y; if (p.x > x1) x1 = p.x; if (p.y > y1) y1 = p.y; }
      return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
    },
    union(a, b) {
      if (!a) return b ? { ...b } : null;
      if (!b) return { ...a };
      const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y);
      return { x, y, w: Math.max(a.x + a.w, b.x + b.w) - x, h: Math.max(a.y + a.h, b.y + b.h) - y };
    },
    contains: (r, p) => p.x >= r.x && p.y >= r.y && p.x <= r.x + r.w && p.y <= r.y + r.h,
    containsRect: (r, s) => s.x >= r.x && s.y >= r.y && s.x + s.w <= r.x + r.w && s.y + s.h <= r.y + r.h,
    intersects: (a, b) => a.x <= b.x + b.w && b.x <= a.x + a.w && a.y <= b.y + b.h && b.y <= a.y + a.h,
    expand: (r, d) => ({ x: r.x - d, y: r.y - d, w: r.w + 2 * d, h: r.h + 2 * d }),
    center: r => ({ x: r.x + r.w / 2, y: r.y + r.h / 2 }),
    corners: r => [{ x: r.x, y: r.y }, { x: r.x + r.w, y: r.y }, { x: r.x + r.w, y: r.y + r.h }, { x: r.x, y: r.y + r.h }],
    transform(r, m) { return R.fromPts(R.corners(r).map(p => M.apply(m, p))); },
    norm(a, b) { return { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(b.x - a.x), h: Math.abs(b.y - a.y) }; }
  };

  // ---------- colors ----------
  let colorCtx = null;
  const C = O.color = {
    parse(str) {
      if (str === null || str === undefined) return null;
      str = String(str).trim();
      if (!str || str === 'none' || str === 'transparent') return null;
      let m = /^#?([0-9a-f]{3,8})$/i.exec(str);
      if (m) {
        let h = m[1];
        if (h.length === 3 || h.length === 4) h = h.split('').map(c => c + c).join('');
        if (h.length !== 6 && h.length !== 8) return null;
        return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1 };
      }
      m = /^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+%?))?\s*\)$/i.exec(str);
      if (m) {
        let a = m[4] === undefined ? 1 : (m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]));
        return { r: +m[1], g: +m[2], b: +m[3], a };
      }
      if (!colorCtx) colorCtx = document.createElement('canvas').getContext('2d');
      colorCtx.fillStyle = '#000001';
      colorCtx.fillStyle = str;
      const v = colorCtx.fillStyle;
      if (v === '#000001') return null;
      return C.parse(v);
    },
    hex(c) {
      const h = v => O.clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0');
      return ('#' + h(c.r) + h(c.g) + h(c.b)).toUpperCase();
    },
    norm(str) { const c = C.parse(str); return c ? C.hex(c) : null; },
    rgba(hex, a = 1) { const c = C.parse(hex) || { r: 0, g: 0, b: 0 }; return `rgba(${c.r},${c.g},${c.b},${O.n(a)})`; },
    toHsv({ r, g, b }) {
      r /= 255; g /= 255; b /= 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
      let h = 0;
      if (d) {
        if (max === r) h = ((g - b) / d) % 6; else if (max === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
        h *= 60; if (h < 0) h += 360;
      }
      return { h, s: max ? d / max : 0, v: max };
    },
    fromHsv({ h, s, v }) {
      const c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c;
      let r = 0, g = 0, b = 0;
      if (h < 60) [r, g, b] = [c, x, 0]; else if (h < 120) [r, g, b] = [x, c, 0]; else if (h < 180) [r, g, b] = [0, c, x];
      else if (h < 240) [r, g, b] = [0, x, c]; else if (h < 300) [r, g, b] = [x, 0, c]; else [r, g, b] = [c, 0, x];
      return { r: (r + m) * 255, g: (g + m) * 255, b: (b + m) * 255 };
    },
    toHsl({ r, g, b }) {
      r /= 255; g /= 255; b /= 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2, d = max - min;
      let h = 0, s = 0;
      if (d) {
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)); else if (max === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
        h *= 60;
      }
      return { h, s, l };
    },
    fromHsl({ h, s, l }) {
      const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
      let r = 0, g = 0, b = 0;
      if (h < 60) [r, g, b] = [c, x, 0]; else if (h < 120) [r, g, b] = [x, c, 0]; else if (h < 180) [r, g, b] = [0, c, x];
      else if (h < 240) [r, g, b] = [0, x, c]; else if (h < 300) [r, g, b] = [x, 0, c]; else [r, g, b] = [c, 0, x];
      return { r: (r + m) * 255, g: (g + m) * 255, b: (b + m) * 255 };
    },
    toCmyk({ r, g, b }) {
      r /= 255; g /= 255; b /= 255;
      const k = 1 - Math.max(r, g, b);
      if (k >= 1) return { c: 0, m: 0, y: 0, k: 1 };
      return { c: (1 - r - k) / (1 - k), m: (1 - g - k) / (1 - k), y: (1 - b - k) / (1 - k), k };
    },
    fromCmyk({ c, m, y, k }) {
      return { r: 255 * (1 - c) * (1 - k), g: 255 * (1 - m) * (1 - k), b: 255 * (1 - y) * (1 - k) };
    },
    mix(a, b, t) {
      const x = C.parse(a) || { r: 0, g: 0, b: 0 }, y = C.parse(b) || { r: 0, g: 0, b: 0 };
      return C.hex({ r: O.lerp(x.r, y.r, t), g: O.lerp(x.g, y.g, t), b: O.lerp(x.b, y.b, t) });
    },
    luminance(hex) { const c = C.parse(hex) || { r: 0, g: 0, b: 0 }; return (0.299 * c.r + 0.587 * c.g + 0.114 * c.b) / 255; }
  };

  // ---------- events ----------
  const handlers = {};
  O.on = (ev, fn) => { (handlers[ev] = handlers[ev] || []).push(fn); };
  O.emit = (ev, ...args) => { (handlers[ev] || []).slice().forEach(fn => { try { fn(...args); } catch (err) { console.error(err); } }); };

  // ---------- DOM ----------
  O.esc = s => String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  O.$ = (sel, root) => (root || document).querySelector(sel);
  O.$$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  O.h = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
  O.debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  O.download = (blob, name) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  };
  O.ls = {
    get(k, d) { try { const v = localStorage.getItem('obrys.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('obrys.' + k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } }
  };
  O.isMac = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
  O.keyLabel = k => O.isMac ? k.replace(/Ctrl\+/g, '⌘').replace(/Alt\+/g, '⌥').replace(/Shift\+/g, '⇧') : k;
})();
