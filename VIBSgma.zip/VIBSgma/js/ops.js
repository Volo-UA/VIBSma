'use strict';
/* Obrys — operations (arrange, group, boolean, pathfinder, path ops, effects, components, transforms) */
(function () {
  const O = window.O, M = O.M, G = O.G, R = O.R, P = O.P, model = O.model, S = O.state, V = O.view;
  const ops = O.ops = {};
  const GEOM = new Set(['path', 'rect', 'ellipse', 'polygon', 'star', 'bool', 'group', 'frame', 'instance']);
  const toast = (m, v) => O.toast && O.toast(m, v);

  // ---------- selection helpers ----------
  O.topSel = () => {
    const nodes = O.sel().filter(n => !n.locked);
    return nodes.filter(n => !nodes.some(o => o !== n && model.isAncestor(o, n)));
  };
  const pathOf = n => {
    const out = [];
    let c = n, p = model.parent(c);
    while (p) { out.unshift(p.children.indexOf(c)); if (model.isPage(p)) break; c = p; p = model.parent(c); }
    return out;
  };
  ops.zsort = nodes => nodes.map(n => ({ n, k: pathOf(n) })).sort((a, b) => {
    for (let i = 0; i < Math.min(a.k.length, b.k.length); i++) if (a.k[i] !== b.k[i]) return a.k[i] - b.k[i];
    return a.k.length - b.k.length;
  }).map(x => x.n);
  const need = (nodes, min, msg) => { if (nodes.length < min) { toast(msg || (min > 1 ? 'Виділіть щонайменше {n} об’єкти' : 'Спершу виділіть об’єкт'), { n: min }); return false; } return true; };
  const worldSubs = n => model.subsIn(n, model.worldMatrix(n));
  const toParent = (subs, cont) => G.transformSubs(subs, M.inv(model.containerMatrix(cont)));
  ops.styleOf = n => ({
    fills: O.clone(n.fills || []), strokes: O.clone(n.strokes || []), sw: n.sw === undefined ? 1 : n.sw, sa: n.sa || 'center', dash: O.clone(n.dash || []),
    cap: n.cap || 'butt', join: n.join || 'miter', miter: n.miter || 4, opacity: n.opacity === undefined ? 1 : n.opacity, blend: n.blend || 'normal', effects: O.clone(n.effects || [])
  });
  const styleOf = ops.styleOf;
  const newPath = (subs, style, name) => model.create('path', Object.assign({ subpaths: subs }, O.clone(style), name ? { name } : {}));
  ops.replaceGeometry = (n, subs) => {
    for (const k of ['children', 'op', 'mask', 'w', 'h', 'radius', 'sides', 'points', 'inner', 'ref', 'clip', 'layout', 'component']) delete n[k];
    n.type = 'path'; n.subpaths = subs; n.m = M.id(); n.fillRule = n.fillRule || 'nonzero';
    if (!n.fills) n.fills = []; if (!n.strokes) n.strokes = [];
    model.reindex();
    return n;
  };

  // ---------- basic edit ----------
  ops.duplicate = (nodes, opts = {}) => {
    const out = [];
    for (const n of nodes) {
      const par = model.parent(n);
      if (!par) continue;
      let c;
      if (n.type === 'frame' && n.component) c = model.create('instance', { ref: n.id, w: n.w, h: n.h, m: n.m.slice(), name: n.name, opacity: n.opacity });
      else c = model.cloneNode(n);
      if (opts.offset) c.m = M.mul(M.translate(opts.offset.x, opts.offset.y), c.m);
      model.insert(c, par, par.children.indexOf(n) + 1);
      out.push(c);
    }
    return out;
  };
  // Ctrl+D: duplicate; repeats the last "copy + transform" (Figma smart duplicate / Illustrator Transform Again)
  ops.duplicateCmd = () => {
    const nodes = ops.zsort(O.topSel());
    if (!need(nodes, 1)) return;
    const lt = O.lastTransform;
    const smart = lt && lt.G && lt.ids && lt.ids.join() === S.sel.join() && (lt.copy || lt.afterDup);
    const copies = ops.duplicate(nodes);
    if (smart) copies.forEach(c => model.applyWorld(c, lt.G, lt.mode));
    O.select(copies.map(c => c.id));
    if (smart) O.lastTransform = Object.assign({}, lt, { ids: S.sel.slice() });
    O.lastDupIds = S.sel.slice();
    O.history.commit('Дублювання');
  };
  ops.del = () => {
    if (S.edit && S.edit.sel && S.edit.sel.size) return ops.deleteAnchors();
    const nodes = O.topSel();
    if (!nodes.length) return;
    nodes.forEach(n => model.remove(n));
    O.select([]);
    O.history.commit('Видалення');
  };
  ops.deleteAnchors = () => {
    const n = model.get(S.edit.id);
    if (!n) return;
    if (n.type !== 'path') model.toPath(n);
    const del = S.edit.sel;
    n.subpaths = n.subpaths.map((sp, si) => ({ closed: sp.closed, pts: sp.pts.filter((p, k) => !del.has(si + ':' + k)) }))
      .filter(sp => sp.pts.length > 1).map(sp => (sp.pts.length < 3 ? Object.assign(sp, { closed: false }) : sp));
    S.edit.sel = new Set();
    if (!n.subpaths.length) { model.remove(n); S.edit = null; O.select([]); }
    O.history.commit('Видалення вузлів');
  };
  ops.copy = () => {
    const nodes = ops.zsort(O.topSel());
    if (!nodes.length) return null;
    const assets = {};
    const scan = x => { (x.fills || []).forEach(f => { if (f.type === 'image' && S.doc.assets[f.asset]) assets[f.asset] = S.doc.assets[f.asset]; }); if (x.children) x.children.forEach(scan); if (x.type === 'instance') { const c = model.get(x.ref); if (c) scan(c); } };
    nodes.forEach(scan);
    const clip = { kind: 'obrys-nodes', nodes: nodes.map(n => ({ data: O.clone(n), W: model.worldMatrix(n) })), assets };
    S.clipboard = clip;
    return clip;
  };
  ops.paste = (clip, opts = {}) => {
    clip = clip || S.clipboard;
    if (!clip || !clip.nodes || !clip.nodes.length) return;
    Object.assign(S.doc.assets, clip.assets || {});
    const selN = O.sel();
    let cont = model.page();
    if (selN.length === 1 && selN[0].type === 'frame' && !opts.inPlace) cont = selN[0];
    else if (selN.length) { const p = model.parent(selN[0]); if (p && (model.isPage(p) || p.type === 'frame')) cont = p; }
    const Pc = model.containerMatrix(cont);
    const made = clip.nodes.map(({ data, W }) => {
      const c = model.cloneNode(data);
      c.m = M.mul(M.inv(Pc), W);
      model.insert(c, cont);
      return c;
    });
    const b = model.selBounds(made);
    const vr = V.viewRect();
    if (b && !opts.inPlace && !R.intersects(b, vr)) {
      const c = R.center(vr), bc = R.center(b);
      made.forEach(n => model.applyWorld(n, M.translate(Math.round(c.x - bc.x), Math.round(c.y - bc.y)), 'resize'));
    }
    O.select(made.map(n => n.id));
    O.history.commit('Вставлення');
  };
  ops.pasteStyle = () => {
    const clip = S.clipboard;
    if (!clip || !clip.nodes.length) return;
    const src = clip.nodes[0].data;
    O.topSel().forEach(t => { Object.assign(t, styleOf(src)); });
    O.history.commit('Вставлення стилю');
  };

  // ---------- grouping ----------
  ops.group = (nodes) => {
    nodes = ops.zsort(nodes || O.topSel());
    if (!need(nodes, 1)) return null;
    const top = nodes[nodes.length - 1];
    const par = model.parent(top);
    const g = model.create('group');
    model.insert(g, par, par.children.indexOf(top) + 1);
    nodes.forEach(n => model.reparent(n, g));
    O.select([g.id]);
    O.history.commit('Групування');
    return g;
  };
  ops.ungroup = (nodes) => {
    nodes = nodes || O.topSel();
    const out = [];
    for (const g of nodes) {
      if (!(g.type === 'group' || g.type === 'bool' || (g.type === 'frame' && !g.component))) { out.push(g.id); continue; }
      const par = model.parent(g);
      let i = par.children.indexOf(g);
      for (const c of g.children.slice()) { model.reparent(c, par, i++); out.push(c.id); }
      model.remove(g);
    }
    O.select(out);
    O.history.commit('Розгрупування');
  };
  ops.frameSelection = (nodes, opts = {}) => {
    nodes = ops.zsort(nodes || O.topSel());
    if (!need(nodes, 1)) return null;
    const top = nodes[nodes.length - 1];
    const par = model.parent(top);
    const Pp = model.containerMatrix(par);
    let b = null;
    for (const n of nodes) b = R.union(b, R.transform(model.worldBounds(n), M.inv(Pp)));
    const f = model.create('frame', { w: Math.max(1, b.w), h: Math.max(1, b.h), m: M.translate(b.x, b.y), fills: opts.fill ? [O.paint.solid('#FFFFFF')] : [], clip: false });
    if (opts.name) f.name = opts.name;
    model.insert(f, par, par.children.indexOf(top) + 1);
    nodes.forEach(n => model.reparent(n, f));
    O.select([f.id]);
    if (!opts.quiet) O.history.commit('Фрейм із виділення');
    return f;
  };

  // ---------- arrange ----------
  ops.arrange = dir => {
    const nodes = ops.zsort(O.topSel());
    if (!nodes.length) return;
    const byParent = new Map();
    nodes.forEach(n => { const p = model.parent(n); if (!byParent.has(p)) byParent.set(p, []); byParent.get(p).push(n); });
    for (const [par, list] of byParent) {
      const ch = par.children;
      if (dir === 'front') { list.forEach(n => { ch.splice(ch.indexOf(n), 1); ch.push(n); }); }
      else if (dir === 'back') { list.slice().reverse().forEach(n => { ch.splice(ch.indexOf(n), 1); ch.unshift(n); }); }
      else if (dir === 'forward') {
        list.slice().reverse().forEach(n => { const i = ch.indexOf(n); if (i < ch.length - 1 && !list.includes(ch[i + 1])) { ch[i] = ch[i + 1]; ch[i + 1] = n; } });
      } else if (dir === 'backward') {
        list.forEach(n => { const i = ch.indexOf(n); if (i > 0 && !list.includes(ch[i - 1])) { ch[i] = ch[i - 1]; ch[i - 1] = n; } });
      }
    }
    model.reindex();
    O.history.commit('Порядок');
  };

  // ---------- align / distribute ----------
  ops.align = how => {
    const nodes = O.topSel();
    if (!nodes.length) return;
    let ref;
    if (nodes.length === 1) {
      const par = model.parent(nodes[0]);
      if (!par || model.isPage(par)) return toast('Для вирівнювання одного об’єкта помістіть його у фрейм');
      ref = model.worldBounds(par);
    } else ref = model.selBounds(nodes);
    for (const n of nodes) {
      const b = model.worldBounds(n);
      let dx = 0, dy = 0;
      if (how === 'left') dx = ref.x - b.x;
      if (how === 'hcenter') dx = ref.x + ref.w / 2 - (b.x + b.w / 2);
      if (how === 'right') dx = ref.x + ref.w - (b.x + b.w);
      if (how === 'top') dy = ref.y - b.y;
      if (how === 'vcenter') dy = ref.y + ref.h / 2 - (b.y + b.h / 2);
      if (how === 'bottom') dy = ref.y + ref.h - (b.y + b.h);
      model.applyWorld(n, M.translate(dx, dy), 'resize');
    }
    O.history.commit('Вирівнювання');
  };
  ops.distribute = axis => {
    const nodes = O.topSel();
    if (!need(nodes, 3, 'Для розподілу виділіть щонайменше 3 об’єкти')) return;
    const items = nodes.map(n => ({ n, b: model.worldBounds(n) }));
    const h = axis === 'h';
    items.sort((a, b) => h ? a.b.x - b.b.x : a.b.y - b.b.y);
    const first = items[0].b, last = items[items.length - 1].b;
    const span = h ? last.x + last.w - first.x : last.y + last.h - first.y;
    const total = items.reduce((s, it) => s + (h ? it.b.w : it.b.h), 0);
    const gap = (span - total) / (items.length - 1);
    let pos = h ? first.x : first.y;
    for (const it of items) {
      const d = pos - (h ? it.b.x : it.b.y);
      model.applyWorld(it.n, h ? M.translate(d, 0) : M.translate(0, d), 'resize');
      pos += (h ? it.b.w : it.b.h) + gap;
    }
    O.history.commit('Розподіл');
  };
  ops.flip = axis => {
    const nodes = O.topSel();
    if (!nodes.length) return;
    const c = R.center(model.selBounds(nodes));
    const Gm = M.about(M.scale(axis === 'h' ? -1 : 1, axis === 'v' ? -1 : 1), c);
    nodes.forEach(n => model.applyWorld(n, Gm, 'resize'));
    O.history.commit('Віддзеркалення');
  };
  ops.rotateBy = deg => {
    const nodes = O.topSel();
    if (!nodes.length) return;
    const c = R.center(model.selBounds(nodes));
    const Gm = M.about(M.rotate(-O.rad(deg)), c);
    nodes.forEach(n => model.applyWorld(n, Gm, 'resize'));
    O.history.commit('Поворот');
  };
  ops.nudge = (dx, dy) => {
    if (S.edit && S.edit.sel.size) {
      const n = model.get(S.edit.id);
      if (!n) return;
      if (n.type !== 'path') model.toPath(n);
      const dl = M.applyV(M.inv(model.worldMatrix(n)), { x: dx, y: dy });
      for (const key of S.edit.sel) {
        const [si, k] = key.split(':').map(Number);
        const p = n.subpaths[si] && n.subpaths[si].pts[k];
        if (!p) continue;
        p.x += dl.x; p.y += dl.y;
        if (p.i) { p.i.x += dl.x; p.i.y += dl.y; }
        if (p.o) { p.o.x += dl.x; p.o.y += dl.y; }
      }
    } else {
      const nodes = O.topSel();
      if (!nodes.length) return;
      nodes.forEach(n => model.applyWorld(n, M.translate(dx, dy), 'resize'));
    }
    O.requestRender();
    nudgeCommit();
  };
  const nudgeCommit = O.debounce(() => O.history.commit('Зсув'), 400);

  // ---------- boolean & pathfinder ----------
  const OPNAMES = { union: 'Об’єднання', subtract: 'Віднімання', intersect: 'Перетин', exclude: 'Виключення' };
  ops.boolean = (op, nodes, opts = {}) => {
    nodes = ops.zsort((nodes || O.topSel()).filter(n => GEOM.has(n.type)));
    if (!need(nodes, op === 'union' ? 1 : 2, 'Для булевої операції виділіть щонайменше 2 фігури')) return null;
    const top = nodes[nodes.length - 1], bottom = nodes[0];
    const par = model.parent(top);
    const style = styleOf(op === 'subtract' ? bottom : top);
    if (!opts.destructive) {
      const b = model.create('bool', Object.assign({ op, name: O.t(OPNAMES[op]) }, style));
      model.insert(b, par, par.children.indexOf(top) + 1);
      nodes.forEach(n => model.reparent(n, b));
      O.select([b.id]);
      if (!opts.quiet) O.history.commit(OPNAMES[op]);
      return b;
    }
    let acc = null;
    try {
      if (op === 'subtract') {
        acc = G.toPaper(worldSubs(bottom), bottom.fillRule);
        for (const n of nodes.slice(1)) acc = acc.subtract(G.toPaper(worldSubs(n), n.fillRule));
      } else {
        for (const n of nodes) {
          const it = G.toPaper(worldSubs(n), n.fillRule);
          acc = acc ? G.boolPaper(op, acc, it) : it;
        }
      }
    } catch (e) { console.error(e); toast('Не вдалося виконати булеву операцію'); return null; }
    const subs = toParent(G.fromPaper(acc), par);
    const res = newPath(subs, style, O.t(OPNAMES[op]));
    model.insert(res, par, par.children.indexOf(top) + 1);
    nodes.forEach(n => model.remove(n));
    O.select([res.id]);
    if (!opts.quiet) O.history.commit(OPNAMES[op]);
    return res;
  };
  ops.expand = (nodes) => {
    nodes = nodes || O.topSel();
    const out = [];
    for (const n of nodes) {
      if (n.type === 'bool') {
        const subs = model.subsIn(n, n.m);
        const keepM = M.id();
        ops.replaceGeometry(n, subs); n.m = keepM;
      } else if (model.SHAPES.has(n.type)) model.toPath(n);
      else if (n.type === 'instance') { const d = ops.detach([n], true); if (d[0]) { out.push(d[0].id); continue; } }
      else if (n.type === 'text') { ops.createOutlines([n]); }
      out.push(n.id);
    }
    model.reindex();
    O.select(out.filter(id => model.exists(id)));
    O.history.commit('Розібрати');
  };
  // Pathfinder divide regions: returns [{item, style}]
  function divideItems(items) {
    let regions = [];
    for (const { it, style } of items) {
      const next = [];
      let rest = it;
      for (const r of regions) {
        const inter = r.it.intersect(it);
        const diff = r.it.subtract(it);
        if (!G.isEmptyItem(inter)) next.push({ it: inter, style });
        if (!G.isEmptyItem(diff)) next.push({ it: diff, style: r.style });
        rest = rest.subtract(r.it);
      }
      if (!G.isEmptyItem(rest)) next.push({ it: rest, style });
      regions = next;
    }
    return regions;
  }
  const geomItems = nodes => nodes.map(n => ({ n, it: G.toPaper(worldSubs(n), n.fillRule), style: styleOf(n) }));
  const piecesOf = (it) => G.splitParts(G.fromPaper(it));
  ops.divide = (nodes, opts = {}) => {
    nodes = ops.zsort(nodes.filter(n => GEOM.has(n.type)));
    if (nodes.length < 2) return [];
    const top = nodes[nodes.length - 1], par = model.parent(top);
    let idx = par.children.indexOf(top) + 1;
    const regions = divideItems(geomItems(nodes));
    const made = [];
    for (const r of regions) for (const part of piecesOf(r.it)) {
      const n = newPath(toParent(part, par), r.style);
      model.insert(n, par, idx++);
      made.push(n);
    }
    nodes.forEach(n => model.remove(n));
    if (!opts.quiet) O.history.commit('Розділення');
    return made;
  };
  ops.pathfinder = kind => {
    const nodes = ops.zsort(O.topSel().filter(n => GEOM.has(n.type)));
    if (!need(nodes, 2, 'Для операції Обробки контурів виділіть щонайменше 2 фігури')) return;
    const top = nodes[nodes.length - 1], par = model.parent(top);
    const items = geomItems(nodes);
    let regions = [];
    try {
      if (kind === 'divide' || kind === 'outline') regions = divideItems(items);
      else if (kind === 'crop') {
        // keep what lies under the topmost object; the top object itself is removed
        const mask = items[items.length - 1].it;
        for (let i = 0; i < items.length - 1; i++) {
          let vis = items[i].it;
          for (let j = i + 1; j < items.length - 1; j++) vis = vis.subtract(items[j].it);
          vis = vis.intersect(mask);
          if (!G.isEmptyItem(vis)) regions.push({ it: vis, style: Object.assign(items[i].style, { strokes: [] }) });
        }
      } else if (kind === 'trim' || kind === 'merge') {
        for (let i = 0; i < items.length; i++) {
          let vis = items[i].it;
          for (let j = i + 1; j < items.length; j++) vis = vis.subtract(items[j].it);
          if (!G.isEmptyItem(vis)) regions.push({ it: vis, style: Object.assign(items[i].style, { strokes: [] }) });
        }
        if (kind === 'merge') {
          const groups = new Map();
          for (const r of regions) {
            const f = r.style.fills.find(x => x.visible !== false);
            const key = f && f.type === 'solid' ? f.color + '|' + f.opacity : Math.random();
            if (groups.has(key)) { const g = groups.get(key); g.it = g.it.unite(r.it); } else groups.set(key, { it: r.it, style: r.style });
          }
          regions = Array.from(groups.values());
        }
      } else if (kind === 'minusback') {
        let acc = items[items.length - 1].it;
        for (const it of items.slice(0, -1)) acc = acc.subtract(it.it);
        regions = [{ it: acc, style: items[items.length - 1].style }];
      }
    } catch (e) { console.error(e); toast('Не вдалося виконати операцію'); return; }
    const gName = { divide: 'Розділення', trim: 'Обрізання', merge: 'Злиття', crop: 'Кадрування', outline: 'Контурні лінії', minusback: 'Мінус задній' }[kind];
    const g = model.create('group', { name: O.t(gName) });
    for (const r of regions) {
      if (kind === 'outline') {
        const c = O.paintColor(r.style.fills.find(f => f.visible !== false));
        const st = Object.assign(r.style, { fills: [], strokes: [O.paint.solid(c)], sw: 1 });
        g.children.push(newPath(toParent(G.fromPaper(r.it), par), st));
      } else for (const part of piecesOf(r.it)) g.children.push(newPath(toParent(part, par), r.style));
    }
    model.insert(g, par, par.children.indexOf(top) + 1);
    nodes.forEach(n => model.remove(n));
    O.select([g.id]);
    O.history.commit(gName);
  };

  // ---------- masks & compound ----------
  ops.makeClip = (mode = 'top') => {
    const nodes = ops.zsort(O.topSel());
    if (!need(nodes, 2, 'Для маски виділіть щонайменше 2 об’єкти')) return;
    const top = nodes[nodes.length - 1], par = model.parent(top);
    const maskNode = mode === 'top' ? top : nodes[0];
    const others = nodes.filter(n => n !== maskNode);
    const g = model.create('group', { mask: true, name: O.t('Обтравочна група') });
    model.insert(g, par, par.children.indexOf(top) + 1);
    model.reparent(maskNode, g);
    others.forEach(n => model.reparent(n, g));
    O.select([g.id]);
    O.history.commit('Обтравочна маска');
  };
  ops.releaseClip = () => {
    const nodes = O.topSel().filter(n => n.type === 'group' && n.mask);
    if (!nodes.length) {
      const inner = O.sel().map(n => model.parent(n)).filter(p => p && p.mask);
      if (!inner.length) return toast('Виділіть обтравочну групу');
      nodes.push(...inner);
    }
    nodes.forEach(g => { g.mask = false; });
    O.history.commit('Звільнення маски');
  };
  ops.makeCompound = () => {
    const nodes = ops.zsort(O.topSel().filter(n => GEOM.has(n.type) && n.type !== 'frame'));
    if (!need(nodes, 2)) return;
    const top = nodes[nodes.length - 1], par = model.parent(top);
    const subs = toParent(nodes.flatMap(worldSubs), par);
    const res = newPath(subs, styleOf(nodes[0]), O.t('Складений контур'));
    res.fillRule = 'evenodd';
    model.insert(res, par, par.children.indexOf(top) + 1);
    nodes.forEach(n => model.remove(n));
    O.select([res.id]);
    O.history.commit('Складений контур');
  };
  ops.releaseCompound = () => {
    const nodes = O.topSel().filter(n => n.type === 'path' && n.subpaths.length > 1);
    if (!nodes.length) return toast('Виділіть складений контур');
    const out = [];
    for (const n of nodes) {
      const par = model.parent(n);
      let i = par.children.indexOf(n);
      n.subpaths.forEach(sp => {
        const c = model.cloneNode(n);
        c.subpaths = [O.clone(sp)]; c.fillRule = 'nonzero'; c.name = model.autoName('path');
        model.insert(c, par, ++i);
        out.push(c.id);
      });
      model.remove(n);
    }
    O.select(out);
    O.history.commit('Звільнення складеного контуру');
  };
  ops.flatten = () => {
    const nodes = ops.zsort(O.topSel().filter(n => GEOM.has(n.type) || n.type === 'text'));
    if (!need(nodes, 1)) return;
    const top = nodes[nodes.length - 1], par = model.parent(top);
    const subs = toParent(nodes.flatMap(n => n.type === 'text' ? [] : worldSubs(n)), par);
    if (!subs.length) return;
    const res = newPath(subs, styleOf(top), nodes.length === 1 ? top.name : O.t('Вектор'));
    model.insert(res, par, par.children.indexOf(top) + 1);
    nodes.forEach(n => { if (n.type !== 'text') model.remove(n); });
    O.select([res.id]);
    O.history.commit('Зведення');
  };

  // ---------- path operations ----------
  const pathNodes = () => O.topSel().filter(n => O.isEditablePath(n));
  ops.join = () => {
    const nodes = O.topSel().filter(n => n.type === 'path' || model.SHAPES.has(n.type));
    if (nodes.length === 1) {
      const n = nodes[0];
      if (n.type !== 'path') return;
      if (S.edit && S.edit.id === n.id && S.edit.sel.size === 2) {
        const keys = Array.from(S.edit.sel).map(k => k.split(':').map(Number));
        const [[s1, k1], [s2, k2]] = keys;
        if (s1 !== s2) {
          let A = n.subpaths[s1], B = n.subpaths[s2];
          if (k1 === 0) A = G.reverseSub(A);
          if (k2 !== 0) B = G.reverseSub(B);
          const joined = { closed: false, pts: A.pts.concat(B.pts) };
          n.subpaths = n.subpaths.filter((_, i) => i !== s1 && i !== s2).concat([joined]);
          S.edit.sel = new Set();
          return O.history.commit('З’єднання');
        }
      }
      n.subpaths.forEach(sp => {
        if (!sp.closed && sp.pts.length > 1) {
          const f = sp.pts[0], l = sp.pts[sp.pts.length - 1];
          if (P.dist(f, l) < 0.01) { f.i = l.i; sp.pts.pop(); }
          sp.closed = true;
        }
      });
      return O.history.commit('З’єднання');
    }
    if (nodes.length !== 2) return toast('Виділіть два відкриті контури або один контур');
    const [A, B] = ops.zsort(nodes);
    const par = model.parent(A);
    const sa = toParent(worldSubs(A), par), sb = toParent(worldSubs(B), par);
    const ia = sa.findIndex(s => !s.closed), ib = sb.findIndex(s => !s.closed);
    if (ia < 0 || ib < 0) return toast('Обидва контури мають бути відкритими');
    let a = sa[ia], b = sb[ib];
    const ends = [[a.pts[a.pts.length - 1], b.pts[0], false, false], [a.pts[a.pts.length - 1], b.pts[b.pts.length - 1], false, true], [a.pts[0], b.pts[0], true, false], [a.pts[0], b.pts[b.pts.length - 1], true, true]];
    ends.sort((x, y) => P.dist(x[0], x[1]) - P.dist(y[0], y[1]));
    const [, , ra, rb] = ends[0];
    if (ra) a = G.reverseSub(a);
    if (rb) b = G.reverseSub(b);
    let pts = a.pts.concat(b.pts);
    if (P.dist(a.pts[a.pts.length - 1], b.pts[0]) < 0.01) { const l = pts[a.pts.length - 1]; l.o = b.pts[0].o; pts.splice(a.pts.length, 1); }
    const subs = sa.filter((_, i) => i !== ia).concat(sb.filter((_, i) => i !== ib), [{ closed: false, pts }]);
    if (A.type !== 'path') model.toPath(A);
    A.subpaths = subs; A.m = M.id();
    model.remove(B);
    O.select([A.id]);
    O.history.commit('З’єднання');
  };
  ops.average = (axis = 'both') => {
    let targets = [];
    if (S.edit && S.edit.sel.size) {
      const n = model.get(S.edit.id);
      if (n.type !== 'path') model.toPath(n);
      for (const k of S.edit.sel) { const [si, i] = k.split(':').map(Number); targets.push({ n, p: n.subpaths[si].pts[i] }); }
    } else for (const n of pathNodes()) { if (n.type !== 'path') model.toPath(n); n.subpaths.forEach(sp => sp.pts.forEach(p => targets.push({ n, p }))); }
    if (targets.length < 2) return toast('Виділіть кілька вузлів');
    const wpts = targets.map(t => M.apply(model.worldMatrix(t.n), t.p));
    const avg = { x: wpts.reduce((s, p) => s + p.x, 0) / wpts.length, y: wpts.reduce((s, p) => s + p.y, 0) / wpts.length };
    targets.forEach((t, i) => {
      const w = wpts[i];
      const nw = { x: axis === 'v' ? w.x : avg.x, y: axis === 'h' ? w.y : avg.y };
      const l = M.apply(M.inv(model.worldMatrix(t.n)), nw);
      const dx = l.x - t.p.x, dy = l.y - t.p.y;
      t.p.x += dx; t.p.y += dy;
      if (t.p.i) { t.p.i.x += dx; t.p.i.y += dy; }
      if (t.p.o) { t.p.o.x += dx; t.p.o.y += dy; }
    });
    O.history.commit('Усереднення');
  };
  ops.toggleSmooth = (n, si, k) => {
    const sp = n.subpaths[si], p = sp.pts[k], N = sp.pts.length;
    if (p.i || p.o) { p.i = null; p.o = null; p.t = 'corner'; return; }
    const prev = sp.pts[(k - 1 + N) % N], next = sp.pts[(k + 1) % N];
    const hasPrev = sp.closed || k > 0, hasNext = sp.closed || k < N - 1;
    const a = hasPrev ? prev : p, b = hasNext ? next : p;
    const t = P.norm(P.sub(b, a));
    const l1 = hasPrev ? P.dist(p, prev) / 3 : 0, l2 = hasNext ? P.dist(p, next) / 3 : 0;
    p.i = hasPrev ? { x: p.x - t.x * l1, y: p.y - t.y * l1 } : null;
    p.o = hasNext ? { x: p.x + t.x * l2, y: p.y + t.y * l2 } : null;
    p.t = 'smooth';
  };
  const forPaths = (label, fn) => {
    const nodes = pathNodes();
    if (!need(nodes, 1, 'Виділіть контур або фігуру')) return;
    nodes.forEach(n => { if (n.type !== 'path') model.toPath(n); fn(n); });
    O.history.commit(label);
  };
  ops.reverse = () => forPaths('Зміна напрямку', n => { n.subpaths = n.subpaths.map(G.reverseSub); });
  ops.addAnchors = () => forPaths('Додавання вузлів', n => {
    n.subpaths.forEach(sp => {
      const count = sp.closed ? sp.pts.length : sp.pts.length - 1;
      for (let k = count - 1; k >= 0; k--) G.insertAt(sp, k, 0.5);
    });
  });
  ops.simplifyPath = tol => forPaths('Спрощення', n => { n.subpaths = G.simplify(n.subpaths, tol); });
  ops.smoothPath = () => forPaths('Згладжування', n => { n.subpaths = G.smooth(n.subpaths); });
  ops.cleanup = () => {
    let removed = 0;
    model.walk(model.page().children.slice(), n => {
      const empty = (n.type === 'path' && (!n.subpaths.length || n.subpaths.every(sp => sp.pts.length < 2)))
        || ((n.type === 'group' || n.type === 'bool') && !n.children.length)
        || (n.type === 'text' && !n.text.trim())
        || (['path', 'rect', 'ellipse', 'polygon', 'star'].includes(n.type) && !(n.fills || []).some(f => f.visible !== false) && !(n.strokes || []).some(f => f.visible !== false) && !(n.effects || []).length);
      if (empty) { model.remove(n); removed++; return false; }
    });
    O.select(S.sel.filter(id => model.exists(id)));
    O.history.commit('Очищення');
    toast(removed ? 'Видалено порожніх об’єктів: {n}' : 'Нічого очищувати', { n: removed });
  };
  ops.outlineStroke = () => {
    const nodes = O.topSel().filter(n => GEOM.has(n.type) && n.type !== 'group' && n.type !== 'frame' && n.type !== 'instance');
    if (!need(nodes, 1, 'Виділіть об’єкт з обведенням')) return;
    const out = [];
    for (const n of nodes) {
      const strokes = (n.strokes || []).filter(s => s.visible !== false);
      if (!strokes.length || !(n.sw > 0)) { out.push(n.id); continue; }
      const par = model.parent(n);
      const geom = model.subsIn(n, n.m);
      const open = geom.some(sp => !sp.closed);
      const sa = open ? 'center' : n.sa;
      let subs = G.outlineStroke(geom, sa === 'center' ? n.sw : n.sw * 2, n.cap, n.join, n.miter);
      if (sa !== 'center') {
        const shape = G.toPaper(geom, n.fillRule), ol = G.toPaper(subs);
        subs = G.fromPaper(sa === 'inside' ? ol.intersect(shape) : ol.subtract(shape));
      }
      const st = Object.assign(styleOf(n), { fills: O.clone(strokes), strokes: [] });
      const sNode = newPath(subs, st, n.name + ' (' + O.t('обведення') + ')');
      const hasFill = (n.fills || []).some(f => f.visible !== false);
      if (hasFill) {
        const keep = n;
        keep.strokes = [];
        const g = model.create('group', { name: n.name });
        model.insert(g, par, par.children.indexOf(n) + 1);
        model.reparent(keep, g);
        g.children.push(sNode);
        model.reindex();
        out.push(g.id);
      } else {
        model.insert(sNode, par, par.children.indexOf(n) + 1);
        model.remove(n);
        out.push(sNode.id);
      }
    }
    O.select(out);
    O.history.commit('Обведення в контур');
  };
  ops.offsetPath = (delta, join, miter) => {
    const nodes = O.topSel().filter(n => GEOM.has(n.type));
    if (!need(nodes, 1)) return;
    const out = [];
    for (const n of nodes) {
      const par = model.parent(n);
      const subs = G.offsetPath(model.subsIn(n, n.m), delta, join, miter, n.fillRule === 'evenodd');
      if (!subs.length) continue;
      const res = newPath(subs, styleOf(n), n.name + ' (' + O.t('зміщення') + ')');
      model.insert(res, par, par.children.indexOf(n) + (delta > 0 ? 0 : 1));
      out.push(res.id);
    }
    O.select(out);
    O.history.commit('Зміщення контуру');
  };
  ops.splitGrid = (rows, cols, gx, gy) => {
    const nodes = O.topSel().filter(n => n.type === 'rect' || n.type === 'frame');
    if (!need(nodes, 1, 'Виділіть прямокутник')) return;
    const out = [];
    for (const n of nodes) {
      const par = model.parent(n);
      const cw = (n.w - gx * (cols - 1)) / cols, ch = (n.h - gy * (rows - 1)) / rows;
      if (cw <= 0 || ch <= 0) continue;
      let idx = par.children.indexOf(n);
      for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
        const cell = model.cloneNode(n);
        if (cell.children) cell.children = [];
        cell.w = cw; cell.h = ch;
        cell.m = M.mul(n.m, M.translate(c * (cw + gx), r * (ch + gy)));
        cell.name = model.autoName(n.type);
        model.insert(cell, par, ++idx);
        out.push(cell.id);
      }
      model.remove(n);
    }
    O.select(out);
    O.history.commit('Розбиття на сітку');
  };
  ops.cutWithLine = (geom, line, fillRule) => {
    const A = G.toPaper(geom, fillRule);
    const b = A.bounds, D = (b.width + b.height) * 4 + 1000, n = line.length;
    const d0 = P.norm(P.sub(line[0], line[Math.min(3, n - 1)]));
    const d1 = P.norm(P.sub(line[n - 1], line[Math.max(0, n - 4)]));
    const e0 = P.add(line[0], P.mul(d0, D)), e1 = P.add(line[n - 1], P.mul(d1, D));
    const dir = P.norm(P.sub(e1, e0)), left = { x: dir.y, y: -dir.x };
    const poly = [e0].concat(line, [e1, P.add(e1, P.mul(left, D)), P.add(e0, P.mul(left, D))]);
    const region = G.toPaper([G.polyToSub(poly, true)]);
    const parts = G.splitParts(G.fromPaper(A.intersect(region))).concat(G.splitParts(G.fromPaper(A.subtract(region))));
    return parts.filter(p => p.length);
  };

  // ---------- distortions (destructive effects) ----------
  const distortNodes = (label, fn) => {
    const nodes = pathNodes();
    if (!need(nodes, 1, 'Виділіть контур або фігуру')) return;
    nodes.forEach(n => {
      if (n.type !== 'path') model.toPath(n);
      const b = G.pathBounds(n.subpaths);
      if (!b) return;
      n.subpaths = fn(n.subpaths, b);
    });
    O.history.commit(label);
  };
  ops.puckerBloat = amount => distortNodes('Втягування і роздування', (subs, b) => {
    const c = R.center(b), a = amount / 100;
    return subs.map(sp => {
      const pts = sp.pts.map(p => G.pt(p.x, p.y));
      const N = pts.length, count = sp.closed ? N : N - 1;
      for (let k = 0; k < count; k++) {
        const p = pts[k], q = pts[(k + 1) % N];
        const mid = P.lerp(p, q, 0.5);
        const off = P.mul(P.sub(mid, c), a);
        p.o = P.add(P.lerp(p, q, 1 / 3), off);
        q.i = P.add(P.lerp(p, q, 2 / 3), off);
      }
      return { closed: sp.closed, pts };
    });
  });
  let seed = 1;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const toSmooth = (pts, closed) => {
    const sp = G.polyToSub(pts, closed);
    const it = G.toPaper([sp]);
    it.smooth({ type: 'catmull-rom', factor: 0.5 });
    return G.fromPaper(it)[0] || sp;
  };
  ops.roughen = (sizePct, detail, smooth) => distortNodes('Огрубіння', (subs, b) => {
    seed = Math.floor(Math.random() * 1e6) + 1;
    const size = Math.hypot(b.w, b.h) * sizePct / 100;
    const step = Math.max(1, 72 / Math.max(1, detail));
    return subs.map(sp => {
      const flat = G.flattenSub(sp, 0.5);
      const res = G.resample(flat.pts, flat.closed, Math.max(4, Math.round(G.polyLength(flat.pts, flat.closed) / step)));
      const moved = res.map(p => ({ x: p.x + (rnd() * 2 - 1) * size, y: p.y + (rnd() * 2 - 1) * size }));
      return smooth ? toSmooth(moved, sp.closed) : G.polyToSub(moved, sp.closed);
    });
  });
  ops.zigzag = (size, ridges, smooth) => distortNodes('Зигзаг', subs => subs.map(sp => {
    const out = [];
    const segs = G.segs(sp);
    let sign = 1;
    segs.forEach((s, si) => {
      const n = ridges + 1;
      for (let i = (si === 0 ? 0 : 1); i <= n; i++) {
        if (sp.closed && si === segs.length - 1 && i === n) break;
        const t = i / n;
        const p = G.bez(s.c[0], s.c[1], s.c[2], s.c[3], t);
        const d = P.norm(G.bezD(s.c[0], s.c[1], s.c[2], s.c[3], O.clamp(t, 0.001, 0.999)));
        const nrm = { x: -d.y, y: d.x };
        const off = (i === 0 || i === n) && !sp.closed ? 0 : size * sign;
        out.push({ x: p.x + nrm.x * off, y: p.y + nrm.y * off });
        sign = -sign;
      }
    });
    return smooth ? toSmooth(out, sp.closed) : G.polyToSub(out, sp.closed);
  }));
  ops.twist = deg => distortNodes('Скручування', (subs, b) => {
    const c = R.center(b), maxD = Math.hypot(b.w, b.h) / 2 || 1, a = O.rad(deg);
    return G.simplify(subs.map(sp => {
      const flat = G.flattenSub(sp, 1);
      return G.polyToSub(flat.pts.map(p => P.rot(p, a * (1 - P.dist(p, c) / maxD), c)), sp.closed);
    }), 0.3);
  });
  ops.roundCorners = radius => distortNodes('Округлення кутів', subs => subs.map(sp => {
    const N = sp.pts.length, out = [];
    sp.pts.forEach((p, k) => {
      const hasPrev = sp.closed || k > 0, hasNext = sp.closed || k < N - 1;
      if (p.i || p.o || !hasPrev || !hasNext) { out.push(G.cp(p)); return; }
      const prev = sp.pts[(k - 1 + N) % N], next = sp.pts[(k + 1) % N];
      const d1 = P.dist(p, prev), d2 = P.dist(p, next);
      const r = Math.min(radius, d1 / 2, d2 / 2);
      if (r < 0.01) { out.push(G.cp(p)); return; }
      const u1 = P.norm(P.sub(prev, p)), u2 = P.norm(P.sub(next, p));
      const a = P.add(p, P.mul(u1, r)), b2 = P.add(p, P.mul(u2, r));
      const k2 = 0.5523;
      out.push(G.pt(a.x, a.y, null, P.add(a, P.mul(u1, -r * k2))));
      out.push(G.pt(b2.x, b2.y, P.add(b2, P.mul(u2, -r * k2)), null));
    });
    return { closed: sp.closed, pts: out };
  }));
  ops.transformEach = (v) => {
    const nodes = O.topSel();
    if (!need(nodes, 1)) return;
    const made = [];
    const one = (n, f) => {
      const c = R.center(model.worldBounds(n));
      const rot = O.rad(-(v.rotate || 0) * f);
      const sx = Math.pow((v.sx || 100) / 100, f) * (v.reflectX ? -1 : 1), sy = Math.pow((v.sy || 100) / 100, f) * (v.reflectY ? -1 : 1);
      const Gm = M.chain(M.translate((v.dx || 0) * f, (v.dy || 0) * f), M.about(M.mul(M.rotate(rot), M.scale(sx, sy)), c));
      model.applyWorld(n, Gm, 'scale');
    };
    const copies = Math.max(0, Math.round(v.copies || 0));
    for (const n of nodes) {
      if (!copies) { one(n, 1); continue; }
      let prev = n;
      for (let i = 1; i <= copies; i++) {
        const c = ops.duplicate([prev])[0];
        one(c, 1);
        made.push(c.id);
        prev = c;
      }
    }
    if (made.length) O.select(S.sel.concat(made));
    O.history.commit('Трансформувати кожен');
  };

  // ---------- blend ----------
  ops.blend = (a, b, steps) => {
    steps = Math.max(1, Math.round(steps || 5));
    if (!a || !b || !GEOM.has(a.type) || !GEOM.has(b.type)) return toast('Перехід працює з фігурами та контурами');
    let [lo, hi] = ops.zsort([a, b]);
    const par = model.parent(hi);
    const sa = toParent(worldSubs(lo), par), sb = toParent(worldSubs(hi), par);
    if (!sa.length || !sb.length) return toast('Не вдалося створити перехід');
    const pairs = [];
    const cnt = Math.min(sa.length, sb.length);
    for (let i = 0; i < cnt; i++) pairs.push([sa[i], sb[i]]);
    const sameShape = pairs.every(([x, y]) => x.pts.length === y.pts.length && x.closed === y.closed);
    let prepared;
    if (sameShape) prepared = pairs.map(([x, y]) => ({ exact: true, x, y }));
    else prepared = pairs.map(([x, y]) => {
      const fx = G.flattenSub(x, 1), fy = G.flattenSub(y, 1);
      const N = O.clamp(Math.max(fx.pts.length, fy.pts.length), 24, 400);
      let rx = G.resample(fx.pts, fx.closed, N), ry = G.resample(fy.pts, fy.closed, N);
      if (fx.closed && fy.closed) {
        if (Math.sign(G.area(rx)) !== Math.sign(G.area(ry))) ry = ry.slice().reverse();
        let best = 0, bd = Infinity;
        for (let off = 0; off < N; off++) { let d = 0; for (let i = 0; i < N; i += 4) d += P.dist(rx[i], ry[(i + off) % N]); if (d < bd) { bd = d; best = off; } }
        ry = ry.slice(best).concat(ry.slice(0, best));
      }
      return { exact: false, x: rx, y: ry, closed: fx.closed && fy.closed };
    });
    const st0 = styleOf(lo), st1 = styleOf(hi);
    const lerpPaint = (p, q, t) => {
      if (!p) return q ? O.clone(q) : null;
      if (!q) return O.clone(p);
      if (p.type === 'solid' && q.type === 'solid') return { type: 'solid', color: O.color.mix(p.color, q.color, t), opacity: O.lerp(p.opacity, q.opacity, t), visible: true };
      return O.clone(t < 0.5 ? p : q);
    };
    const g = model.create('group', { name: O.t('Перехід') });
    model.insert(g, par, par.children.indexOf(hi) + 1);
    model.reparent(lo, g);
    for (let s = 1; s <= steps; s++) {
      const t = s / (steps + 1);
      const subs = prepared.map(pp => {
        if (pp.exact) {
          return { closed: pp.x.closed, pts: pp.x.pts.map((p, i) => { const q = pp.y.pts[i]; const L = (u, v) => (u && v ? P.lerp(u, v, t) : (u || v ? P.lerp(u || p, v || q, t) : null)); return G.pt(O.lerp(p.x, q.x, t), O.lerp(p.y, q.y, t), L(p.i, q.i), L(p.o, q.o), p.t); }) };
        }
        return G.simplify([G.polyToSub(pp.x.map((p, i) => P.lerp(p, pp.y[i], t)), pp.closed)], 0.25)[0];
      }).filter(Boolean);
      const st = {
        fills: [lerpPaint(st0.fills[0], st1.fills[0], t)].filter(Boolean),
        strokes: [lerpPaint(st0.strokes[0], st1.strokes[0], t)].filter(Boolean),
        sw: O.lerp(st0.sw, st1.sw, t), opacity: O.lerp(st0.opacity, st1.opacity, t),
        cap: st0.cap, join: st0.join
      };
      const n = newPath(subs, st, O.t('Крок {n}', { n: s }));
      g.children.push(n);
    }
    model.reindex();
    model.reparent(hi, g);
    O.select([g.id]);
    O.history.commit('Перехід');
  };

  // ---------- text ----------
  ops.textOnPath = (pathNode, textNode) => {
    const par = model.parent(pathNode);
    const subs = pathNode.type === 'path' ? O.clone(pathNode.subpaths) : G.cloneSubs(G.shapeSubs(pathNode));
    const n = textNode || model.create('text', { text: O.t('Текст уздовж контуру') });
    if (textNode) model.remove(textNode);
    n.path = subs; n.m = pathNode.m.slice(); n.width = null; n.pathOffset = 0;
    model.insert(n, par, par.children.indexOf(pathNode) + 1);
    model.remove(pathNode);
    O.select([n.id]);
    O.history.commit('Текст по контуру');
    O.textEdit.start(n);
  };
  ops.textToPathCmd = () => {
    const sel = O.topSel();
    const t = sel.find(n => n.type === 'text'), p = sel.find(n => O.isEditablePath(n));
    if (t && p) return ops.textOnPath(p, t);
    if (p) return ops.textOnPath(p);
    toast('Виділіть контур (і, за бажанням, текст)');
  };
  ops.releaseTextPath = () => {
    const nodes = O.topSel().filter(n => n.type === 'text' && n.path);
    if (!nodes.length) return toast('Виділіть текст на контурі');
    nodes.forEach(n => {
      const par = model.parent(n);
      const p = model.create('path', { subpaths: n.path, m: n.m.slice() });
      model.insert(p, par, par.children.indexOf(n));
      n.path = null;
    });
    O.history.commit('Звільнення тексту');
  };
  const fontCache = new Map();
  async function loadFontFor(n) {
    const fam = String(n.font || '').replace(/["']/g, '');
    const key = fam + '|' + (n.weight || 400) + '|' + (n.italic ? 1 : 0);
    if (fontCache.has(key)) return fontCache.get(key);
    const custom = (S.doc.fonts || []).find(f => f.family === fam);
    if (custom && window.opentype) {
      const buf = O.dataToBlob(custom.data).arrayBuffer ? await O.dataToBlob(custom.data).arrayBuffer() : null;
      const font = window.opentype.parse(buf);
      fontCache.set(key, font);
      return font;
    }
    // Google Fonts: TTF subsets from the fontsource CDN (several files → glyph fallback)
    if (O.fonts && O.fonts.isGoogle(fam)) {
      const list = await O.fonts.otFonts(fam, n.weight || 400, !!n.italic, O.text.content(n));
      if (list) return list.length === 1 ? list[0] : list;
    }
    // installed fonts: only when the permission is already granted (no prompt in the middle of an export)
    let granted = false;
    try { granted = !!(window.queryLocalFonts && navigator.permissions && (await navigator.permissions.query({ name: 'local-fonts' })).state === 'granted'); } catch (e) { granted = false; }
    if (granted && window.opentype) {
      try {
        const list = await Promise.race([window.queryLocalFonts(), new Promise((res, rej) => setTimeout(() => rej(new Error('local fonts timeout')), 5000))]);
        const want = n.weight >= 600 ? 'bold' : 'regular';
        const cands = list.filter(f => f.family.toLowerCase() === fam.toLowerCase());
        const pick = cands.find(f => {
          const st = f.style.toLowerCase();
          const it = st.includes('italic') || st.includes('oblique');
          const bold = st.includes('bold') || st.includes('black') || st.includes('heavy') || st.includes('semibold');
          return it === !!n.italic && (want === 'bold') === bold;
        }) || cands[0];
        if (pick) {
          const font = window.opentype.parse(await (await pick.blob()).arrayBuffer());
          fontCache.set(key, font);
          return font;
        }
      } catch (e) { console.warn(e); }
    }
    // a metric-compatible open font (Arial → Arimo, Times New Roman → Tinos, …): same line breaks, near-identical shapes
    const clone = O.fonts && O.fonts.cloneOf(fam);
    if (clone) {
      const list = await O.fonts.otFonts(clone, n.weight || 400, !!n.italic, O.text.content(n));
      if (list) return list.length === 1 ? list[0] : list;
    }
    return null;
  }
  const otPathToSubs = cmds => {
    const subs = [];
    let cur = null;
    for (const c of cmds) {
      if (c.type === 'M') { cur = { closed: false, pts: [G.pt(c.x, c.y)] }; subs.push(cur); }
      else if (c.type === 'L') cur.pts.push(G.pt(c.x, c.y));
      else if (c.type === 'C') { const l = cur.pts[cur.pts.length - 1]; l.o = { x: c.x1, y: c.y1 }; cur.pts.push(G.pt(c.x, c.y, { x: c.x2, y: c.y2 })); }
      else if (c.type === 'Q') { const l = cur.pts[cur.pts.length - 1]; l.o = { x: l.x + 2 / 3 * (c.x1 - l.x), y: l.y + 2 / 3 * (c.y1 - l.y) }; cur.pts.push(G.pt(c.x, c.y, { x: c.x + 2 / 3 * (c.x1 - c.x), y: c.y + 2 / 3 * (c.y1 - c.y) })); }
      else if (c.type === 'Z' && cur) {
        cur.closed = true;
        const f = cur.pts[0], l = cur.pts[cur.pts.length - 1];
        if (cur.pts.length > 1 && P.dist(f, l) < 1e-6) { f.i = l.i; cur.pts.pop(); }
      }
    }
    return subs.filter(s => s.pts.length > 1);
  };
  // glyph by glyph over several subset files (e.g. latin + cyrillic) with kerning inside one file
  const multiFontPath = (fonts, str, x, y, size, ls) => {
    const cmds = [];
    let pen = x, prev = null, prevFont = null;
    for (const ch of str) {
      const f = fonts.find(ft => ft.charToGlyphIndex(ch) > 0) || fonts[0];
      const gl = f.charToGlyph(ch);
      const k = size / f.unitsPerEm;
      if (prev && prevFont === f && f.getKerningValue) pen += f.getKerningValue(prev, gl) * k;
      cmds.push(...gl.getPath(pen, y, size).commands);
      pen += (gl.advanceWidth || 0) * k + ls;
      prev = gl; prevFont = f;
    }
    return cmds;
  };
  // glyph outlines of a text node in its own coordinates (null when no font file is reachable)
  ops.textSubs = async n => {
    if (!window.opentype || n.type !== 'text' || n.path) return null;
    let font = null;
    try { font = await loadFontFor(n); } catch (e) { console.warn(e); }
    if (!font) return null;
    const L = O.text.layout(n);
    let subs = [];
    for (const l of L.lines) {
      const lw = O.text.measure(n, l.t);
      const x = n.align === 'center' ? (L.w - lw) / 2 : n.align === 'right' ? L.w - lw : 0;
      const cmds = Array.isArray(font) ? multiFontPath(font, l.t, x, l.y, n.size, n.ls || 0) : font.getPath(l.t, x, l.y, n.size, { kerning: true, letterSpacing: (n.ls || 0) / n.size }).commands;
      subs = subs.concat(otPathToSubs(cmds));
    }
    return subs;
  };
  ops.createOutlines = async (nodes) => {
    nodes = (nodes || O.topSel()).filter(n => n.type === 'text' && !n.path);
    if (!need(nodes, 1, 'Виділіть текст')) return;
    if (!window.opentype) return toast('Бібліотека шрифтів не завантажилась');
    let done = 0;
    for (const n of nodes) {
      const subs = await ops.textSubs(n);
      if (!subs) {
        toast('Немає доступу до файлу шрифту «{font}». Завантажте файл шрифту (Текст → Завантажити шрифт) або дозвольте доступ до шрифтів у Chrome/Edge.', { font: n.font });
        continue;
      }
      if (!subs.length) continue;
      const par = model.parent(n);
      const res = model.create('path', Object.assign(styleOf(n), { subpaths: subs, m: n.m.slice(), name: n.name, fillRule: 'nonzero' }));
      model.insert(res, par, par.children.indexOf(n) + 1);
      model.remove(n);
      done++;
    }
    if (done) { O.select(S.sel.filter(id => model.exists(id))); O.history.commit('Створення контурів'); }
  };

  // ---------- components / auto layout ----------
  ops.createComponent = () => {
    const nodes = O.topSel();
    if (!need(nodes, 1)) return;
    let f;
    if (nodes.length === 1 && nodes[0].type === 'frame') f = nodes[0];
    else { f = ops.frameSelection(nodes, { quiet: true }); f.name = model.autoName('component'); }
    f.component = true;
    O.select([f.id]);
    O.history.commit('Створення компонента');
  };
  ops.detach = (nodes, quiet) => {
    nodes = (nodes || O.topSel()).filter(n => n.type === 'instance');
    const out = [];
    for (const inst of nodes) {
      const comp = model.get(inst.ref);
      if (!comp) continue;
      const f = model.cloneNode(inst.ov && O.components ? O.components.applyOv(comp, inst.ov) : comp);
      f.component = false; f.name = inst.name;
      delete f.variant; delete f.componentSet; f.m = inst.m.slice(); f.opacity = inst.opacity;
      const sx = comp.w ? inst.w / comp.w : 1, sy = comp.h ? inst.h / comp.h : 1;
      f.w = inst.w; f.h = inst.h;
      if (Math.abs(sx - 1) > 1e-9 || Math.abs(sy - 1) > 1e-9) for (const c of f.children) { c.m = M.mul(M.scale(sx, sy), c.m); model.normalize(c, 'scale', false); }
      const par = model.parent(inst);
      model.insert(f, par, par.children.indexOf(inst) + 1);
      model.remove(inst);
      out.push(f);
    }
    if (!quiet) { O.select(out.map(f => f.id)); O.history.commit('Від’єднання екземпляра'); }
    return out;
  };
  ops.goToComponent = () => {
    const inst = O.sel().find(n => n.type === 'instance');
    if (!inst) return toast('Виділіть екземпляр');
    const comp = model.get(inst.ref);
    if (!comp) return toast('Основний компонент видалено');
    const pg = model.pageOf(comp);
    if (pg && pg.id !== S.pageId) { S.pageId = pg.id; O.emit('page'); }
    O.select([comp.id]);
    V.fit(model.worldBounds(comp), 80, 4);
    O.requestRender();
  };
  ops.insertInstance = compId => {
    const comp = model.get(compId);
    if (!comp) return;
    const c = R.center(V.viewRect());
    const n = model.create('instance', { ref: comp.id, w: comp.w, h: comp.h, name: comp.name, m: M.translate(Math.round(c.x - comp.w / 2), Math.round(c.y - comp.h / 2)) });
    const cont = V.containerAt(c);
    n.m = M.mul(M.inv(model.containerMatrix(cont)), n.m);
    model.insert(n, cont);
    O.select([n.id]);
    O.history.commit('Екземпляр');
  };
  ops.autoLayout = () => {
    let nodes = O.topSel();
    if (!need(nodes, 1)) return;
    let f;
    if (nodes.length === 1 && nodes[0].type === 'frame') {
      f = nodes[0];
      if (f.layout) { f.layout = null; O.history.commit('Без автолейауту'); return; }
    } else {
      const boxes = nodes.map(n => model.worldBounds(n));
      const b = model.selBounds(nodes);
      f = ops.frameSelection(nodes, { quiet: true, fill: false });
      f.name = model.autoName('frame');
      void boxes; void b;
    }
    const kids = f.children.map(c => ({ c, b: model.boundsIn(c, c.m) }));
    const xs = kids.map(k => k.b.x), ys = kids.map(k => k.b.y);
    const spreadX = Math.max(...xs) - Math.min(...xs), spreadY = Math.max(...ys) - Math.min(...ys);
    const dir = spreadX >= spreadY ? 'h' : 'v';
    kids.sort((a, b) => dir === 'h' ? a.b.x - b.b.x : a.b.y - b.b.y);
    let gaps = [];
    for (let i = 1; i < kids.length; i++) gaps.push(dir === 'h' ? kids[i].b.x - (kids[i - 1].b.x + kids[i - 1].b.w) : kids[i].b.y - (kids[i - 1].b.y + kids[i - 1].b.h));
    gaps = gaps.filter(g => g >= 0);
    const gap = gaps.length ? Math.round(gaps.reduce((a, b) => a + b, 0) / gaps.length) : 10;
    f.children = kids.map(k => k.c);
    f.layout = { dir, gap, pad: [10, 10, 10, 10], align: 'start', justify: 'start', wMode: 'hug', hMode: 'hug' };
    f.clip = false;
    model.reindex();
    O.select([f.id]);
    O.history.commit('Автолейаут');
  };

  // ---------- image ops ----------
  ops.rasterize = async (scale = 2) => {
    const nodes = ops.zsort(O.topSel());
    if (!need(nodes, 1)) return;
    const top = nodes[nodes.length - 1], par = model.parent(top);
    const { blob, bounds } = await O.io.renderImage(nodes, { scale, type: 'image/png' });
    const data = await O.io.blobToData(blob);
    const id = O.uid();
    S.doc.assets[id] = { data, w: Math.round(bounds.w * scale), h: Math.round(bounds.h * scale), name: O.t('Растр') };
    const lb = R.transform(bounds, M.inv(model.containerMatrix(par)));
    const r = model.create('rect', { name: O.t('Растр'), w: lb.w, h: lb.h, m: M.translate(lb.x, lb.y), fills: [O.paint.image(id)] });
    model.insert(r, par, par.children.indexOf(top) + 1);
    nodes.forEach(n => model.remove(n));
    O.select([r.id]);
    O.history.commit('Растеризація');
  };
  ops.imageTrace = async (preset) => {
    const n = O.sel().find(x => (x.fills || []).some(f => f.type === 'image'));
    if (!n) return toast('Виділіть зображення');
    if (!window.ImageTracer) return toast('Модуль трасування не завантажився');
    const f = n.fills.find(x => x.type === 'image');
    const a = S.doc.assets[f.asset];
    if (!a) return;
    O.toast('Трасування…');
    const img = await O.io.loadImage(a.data);
    const maxSide = 700, k = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const cw = Math.max(1, Math.round(img.naturalWidth * k)), ch = Math.max(1, Math.round(img.naturalHeight * k));
    const cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
    const cx = cv.getContext('2d'); cx.drawImage(img, 0, 0, cw, ch);
    const imgd = cx.getImageData(0, 0, cw, ch);
    const presets = { photo: 'detailed', poster: 'posterized2', bw: 'posterized1', sketch: 'artistic3', default: 'default' };
    const opts = Object.assign({}, window.ImageTracer.optionpresets[presets[preset] || 'default'] || {}, { viewbox: true, desc: false });
    if (preset === 'bw') Object.assign(opts, { numberofcolors: 2, colorsampling: 0 });
    let svg;
    try { svg = window.ImageTracer.imagedataToSVG(imgd, opts); } catch (e) { console.error(e); return toast('Не вдалося трасувати зображення'); }
    const g = O.io.importSVG(svg, { noCommit: true, name: O.t('Трасування') });
    if (!g) return;
    // place over the image
    const W = model.worldMatrix(n);
    const gb = model.worldBounds(g);
    const fit = M.chain(W, M.scale(n.w / (gb.w || 1), n.h / (gb.h || 1)), M.translate(-gb.x, -gb.y));
    const par = model.parent(n);
    model.remove(g);
    g.m = M.mul(M.inv(model.containerMatrix(par)), M.mul(fit, g.m));
    model.normalize(g, 'scale');
    model.insert(g, par, par.children.indexOf(n) + 1);
    n.visible = false;
    O.select([g.id]);
    O.history.commit('Трасування зображення');
  };

  // ---------- transform dialogs ----------
  const applyG = (Gm, copy, mode) => {
    let nodes = O.topSel();
    if (copy) { nodes = ops.duplicate(nodes); O.select(nodes.map(n => n.id)); }
    nodes.forEach(n => model.applyWorld(n, Gm, mode));
    O.lastTransform = { G: Gm, copy, mode, ids: S.sel.slice() };
  };
  ops.transformAgain = () => {
    const lt = O.lastTransform;
    if (!lt || !lt.G) return toast('Немає попередньої трансформації');
    if (!O.topSel().length) return;
    applyG(lt.G, lt.copy, lt.mode);
    O.history.commit('Повторити трансформацію');
  };
  ops.transformDialog = (kind, pivot) => {
    if (!O.topSel().length) return toast('Спершу виділіть об’єкт');
    const c = pivot || R.center(model.selBounds(O.topSel()));
    const defs = {
      move: { title: 'Переміщення', fields: [{ key: 'dx', label: 'По горизонталі', type: 'number', value: 10, unit: 'px' }, { key: 'dy', label: 'По вертикалі', type: 'number', value: 0, unit: 'px' }], G: v => M.translate(v.dx, v.dy) },
      rotate: { title: 'Поворот', fields: [{ key: 'a', label: 'Кут', type: 'number', value: 45, unit: '°' }], G: v => M.about(M.rotate(-O.rad(v.a)), c) },
      reflect: { title: 'Віддзеркалення', fields: [{ key: 'axis', label: 'Вісь', type: 'select', value: 'v', options: [['v', 'Вертикальна'], ['h', 'Горизонтальна'], ['a', 'Під кутом']] }, { key: 'a', label: 'Кут', type: 'number', value: 90, unit: '°' }], G: v => M.about(O.reflectMatrix(v.axis === 'v' ? Math.PI / 2 : v.axis === 'h' ? 0 : -O.rad(v.a)), c) },
      scale: { title: 'Масштабування', fields: [{ key: 'sx', label: 'По горизонталі', type: 'number', value: 100, unit: '%' }, { key: 'sy', label: 'По вертикалі', type: 'number', value: 100, unit: '%' }], G: v => M.about(M.scale((v.sx || 100) / 100, (v.sy || 100) / 100), c), mode: 'scale' },
      shear: { title: 'Нахил', fields: [{ key: 'a', label: 'Кут нахилу', type: 'number', value: 15, unit: '°' }, { key: 'axis', label: 'Вісь', type: 'select', value: 'h', options: [['h', 'Горизонтальна'], ['v', 'Вертикальна']] }], G: v => M.about(v.axis === 'h' ? M.skewX(-O.rad(v.a)) : M.skewY(O.rad(v.a)), c) }
    };
    const d = defs[kind];
    if (!d) return;
    O.ui.dialog({
      title: d.title, fields: d.fields, preview: true,
      buttons: [{ id: 'copy', label: 'Копія' }, { id: 'ok', label: 'OK', primary: true }],
      apply: (v, btn) => applyG(d.G(v), btn === 'copy', d.mode || 'resize'),
      label: d.title
    });
  };
  ops.transformEachDialog = () => {
    if (!O.topSel().length) return toast('Спершу виділіть об’єкти');
    O.ui.dialog({
      title: 'Трансформувати кожен',
      fields: [
        { key: 'sx', label: 'Масштаб по горизонталі', type: 'number', value: 100, unit: '%' },
        { key: 'sy', label: 'Масштаб по вертикалі', type: 'number', value: 100, unit: '%' },
        { key: 'dx', label: 'Зсув по горизонталі', type: 'number', value: 0, unit: 'px' },
        { key: 'dy', label: 'Зсув по вертикалі', type: 'number', value: 0, unit: 'px' },
        { key: 'rotate', label: 'Поворот', type: 'number', value: 0, unit: '°' },
        { key: 'copies', label: 'Кількість копій', type: 'number', value: 0, min: 0, max: 200 },
        { key: 'reflectX', label: 'Віддзеркалити по X', type: 'checkbox', value: false },
        { key: 'reflectY', label: 'Віддзеркалити по Y', type: 'checkbox', value: false }
      ],
      preview: true, apply: v => ops.transformEach(v), commitInside: true, label: 'Трансформувати кожен'
    });
  };
  // ---------- select menu ----------
  ops.selectAll = () => {
    const first = O.sel()[0];
    const par = first ? model.parent(first) : model.page();
    O.select(par.children.filter(n => n.visible !== false && !n.locked).map(n => n.id));
  };
  ops.selectInverse = () => {
    const first = O.sel()[0];
    const par = first ? model.parent(first) : model.page();
    O.select(par.children.filter(n => n.visible !== false && !n.locked && !S.sel.includes(n.id)).map(n => n.id));
  };
  ops.selectSame = prop => {
    const ref = O.sel()[0];
    if (!ref) return toast('Спершу виділіть зразок');
    const key = n => {
      switch (prop) {
        case 'fill': { const f = (n.fills || []).find(x => x.visible !== false); return f ? JSON.stringify(f.type === 'solid' ? f.color : f) : 'none'; }
        case 'stroke': { const f = (n.strokes || []).find(x => x.visible !== false); return f ? JSON.stringify(f.type === 'solid' ? f.color : f) : 'none'; }
        case 'sw': return n.sw;
        case 'opacity': return n.opacity;
        case 'blend': return n.blend;
        case 'font': return n.type === 'text' ? n.font + '|' + n.weight : null;
        case 'type': return n.type;
      }
    };
    const k = key(ref);
    const out = [];
    model.walk(model.page().children, n => { if (n.visible !== false && !n.locked && key(n) === k && k !== null && k !== undefined) out.push(n.id); });
    O.select(out);
  };
  ops.toggleLock = () => { const ns = O.topSel().length ? O.topSel() : O.sel(); const v = !ns.every(n => n.locked); ns.forEach(n => { n.locked = v; }); if (v) O.select([]); O.history.commit(v ? 'Блокування' : 'Розблокування'); };
  ops.toggleHide = () => { const ns = O.sel(); if (!ns.length) return; const v = ns.every(n => n.visible !== false); ns.forEach(n => { n.visible = !v; }); O.history.commit(v ? 'Приховування' : 'Показ'); };
  ops.unlockAll = () => { model.walk(model.page().children, n => { n.locked = false; }); O.history.commit('Розблокувати все'); };
  ops.showAll = () => { model.walk(model.page().children, n => { n.visible = true; }); O.history.commit('Показати все'); };
  ops.resetBox = () => {
    const nodes = O.topSel();
    nodes.forEach(n => {
      if (n.type === 'path') { n.subpaths = G.transformSubs(n.subpaths, n.m); n.m = M.id(); }
      else if (model.SHAPES.has(n.type) && Math.abs(M.decompose(n.m).rot) > 1e-6) { model.toPath(n); n.subpaths = G.transformSubs(n.subpaths, n.m); n.m = M.id(); }
      else if (n.type === 'group') { const L = n.m; n.children.forEach(c => { c.m = M.mul(L, c.m); }); n.m = M.id(); }
    });
    O.history.commit('Скидання рамки');
  };
})();
