'use strict';
/* Obrys — viewport, rulers, overlay (selection UI), snapping, hit testing */
(function () {
  const O = window.O, M = O.M, G = O.G, R = O.R, model = O.model, S = O.state;
  const n_ = O.n;
  const ACC = '#0D99FF', PURPLE = '#9747FF', GUIDE = '#00B4D8', SMART = '#FF2E7E';
  O.COLORS = { ACC, PURPLE, GUIDE, SMART };

  const V = O.view = {
    zoom: 1, x: 0, y: 0, el: null,
    m() { return [V.zoom, 0, 0, V.zoom, V.x, V.y]; },
    toWorld(p) { return { x: (p.x - V.x) / V.zoom, y: (p.y - V.y) / V.zoom }; },
    toScreen(p) { return { x: p.x * V.zoom + V.x, y: p.y * V.zoom + V.y }; },
    local(e) { const r = V.el.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; },
    size() { return { w: V.el.clientWidth, h: V.el.clientHeight }; },
    apply() {
      O.$('#viewport').setAttribute('transform', `matrix(${V.zoom} 0 0 ${V.zoom} ${V.x} ${V.y})`);
      V.drawRulers();
      O.requestOverlay();
      O.emit('zoom');
      zoomRerender();
    },
    setZoom(z, anchor) {
      z = O.clamp(z, 0.02, 256);
      anchor = anchor || { x: V.el.clientWidth / 2, y: V.el.clientHeight / 2 };
      const w = V.toWorld(anchor);
      V.zoom = z; V.x = anchor.x - w.x * z; V.y = anchor.y - w.y * z;
      V.apply();
    },
    zoomBy(f, anchor) { V.setZoom(V.zoom * f, anchor); },
    zoomStep(dir) {
      const steps = [0.02, 0.05, 0.1, 0.125, 0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4, 6, 8, 12, 16, 24, 32, 64, 128, 256];
      let z = V.zoom;
      if (dir > 0) z = steps.find(s => s > V.zoom + 1e-6) || 256; else z = steps.slice().reverse().find(s => s < V.zoom - 1e-6) || 0.02;
      V.setZoom(z);
    },
    fit(b, pad = 64, maxZoom = 8) {
      const { w, h } = V.size();
      if (!b) b = model.selBounds(model.page().children.filter(n => n.visible !== false));
      if (!b) { V.zoom = 1; V.x = w / 2; V.y = h / 2; V.apply(); return; }
      const bw = Math.max(b.w, 1), bh = Math.max(b.h, 1);
      const z = O.clamp(Math.min((w - pad * 2) / bw, (h - pad * 2) / bh), 0.02, maxZoom);
      V.zoom = z; V.x = w / 2 - (b.x + bw / 2) * z; V.y = h / 2 - (b.y + bh / 2) * z;
      V.apply();
    },
    center(p) { const { w, h } = V.size(); V.x = w / 2 - p.x * V.zoom; V.y = h / 2 - p.y * V.zoom; V.apply(); },
    viewRect() { const { w, h } = V.size(); const a = V.toWorld({ x: 0, y: 0 }), b = V.toWorld({ x: w, y: h }); return { x: a.x, y: a.y, w: b.x - a.x, h: b.y - a.y }; }
  };
  const zoomRerender = O.debounce(() => O.requestRender(), 120);

  // ---------- render scheduling ----------
  let raf = 0, needDoc = false, needOv = false;
  const frame = () => {
    raf = 0;
    if (!S.doc) return;
    try { if (needDoc) { needDoc = false; O.render.page(); } } catch (e) { console.error(e); }
    try { if (needOv) { needOv = false; O.overlay.draw(); } } catch (e) { console.error(e); }
  };
  const schedule = () => { if (!raf) raf = requestAnimationFrame(frame); };
  O.requestRender = () => { needDoc = needOv = true; schedule(); };
  O.requestOverlay = () => { needOv = true; schedule(); };
  O.flushRender = () => { if (raf) cancelAnimationFrame(raf); frame(); };

  // ---------- rulers ----------
  const css = name => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  function pickStep(z) {
    const steps = [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000, 10000, 20000, 50000];
    return steps.find(s => s * z >= 60) || 100000;
  }
  V.drawRulers = () => {
    const rx = O.$('#ruler-x'), ry = O.$('#ruler-y');
    if (!rx || !ry) return;
    const show = S.settings.rulers;
    rx.hidden = ry.hidden = !show; O.$('#ruler-corner').hidden = !show;
    if (!show) return;
    const dpr = window.devicePixelRatio || 1;
    const bg = css('--ruler-bg') || '#fff', fg = css('--ruler-fg') || '#888', line = css('--ruler-line') || '#ddd';
    const selB = S.sel.length ? model.selBounds(O.sel()) : null;
    const step = pickStep(V.zoom), minor = step / (step % 5 === 0 ? 5 : 2);
    for (const [cv, horiz] of [[rx, true], [ry, false]]) {
      const W = cv.clientWidth, H = cv.clientHeight;
      if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
      const c = cv.getContext('2d');
      c.setTransform(dpr, 0, 0, dpr, 0, 0);
      c.fillStyle = bg; c.fillRect(0, 0, W, H);
      const len = horiz ? W : H, thick = horiz ? H : W, off = horiz ? V.x : V.y;
      if (selB) {
        const a = (horiz ? selB.x : selB.y) * V.zoom + off, b = (horiz ? selB.x + selB.w : selB.y + selB.h) * V.zoom + off;
        c.fillStyle = 'rgba(13,153,255,0.18)';
        if (horiz) c.fillRect(a, 0, b - a, H); else c.fillRect(0, a, W, b - a);
      }
      c.strokeStyle = line; c.lineWidth = 1;
      c.beginPath();
      if (horiz) { c.moveTo(0, H - 0.5); c.lineTo(W, H - 0.5); } else { c.moveTo(W - 0.5, 0); c.lineTo(W - 0.5, H); }
      c.stroke();
      const v0 = Math.floor((0 - off) / V.zoom / minor) * minor, v1 = (len - off) / V.zoom;
      c.fillStyle = fg; c.strokeStyle = fg;
      c.font = '10px system-ui, sans-serif';
      c.beginPath();
      for (let v = v0; v <= v1; v += minor) {
        const p = Math.round(v * V.zoom + off) + 0.5;
        const major = Math.abs(v / step - Math.round(v / step)) < 1e-6;
        const tl = major ? thick * 0.45 : thick * 0.2;
        if (horiz) { c.moveTo(p, H); c.lineTo(p, H - tl); } else { c.moveTo(W, p); c.lineTo(W - tl, p); }
        if (major) {
          const label = String(Math.round(v));
          if (horiz) c.fillText(label, p + 3, 10);
          else { c.save(); c.translate(10, p - 3); c.rotate(-Math.PI / 2); c.fillText(label, 0, 0); c.restore(); }
        }
      }
      c.stroke();
      if (selB) {
        c.fillStyle = ACC; c.font = 'bold 10px system-ui, sans-serif';
        const a = (horiz ? selB.x : selB.y), b = (horiz ? selB.x + selB.w : selB.y + selB.h);
        for (const v of [a, b]) {
          const p = v * V.zoom + off, label = O.fmt(v, 1);
          if (horiz) { c.fillStyle = bg; c.fillRect(p - 16, 0, 32, 12); c.fillStyle = ACC; c.textAlign = 'center'; c.fillText(label, p, 10); c.textAlign = 'start'; }
          else { c.save(); c.translate(10, p); c.rotate(-Math.PI / 2); c.fillStyle = bg; c.fillRect(-16, -10, 32, 12); c.fillStyle = ACC; c.textAlign = 'center'; c.fillText(label, 0, 0); c.restore(); }
        }
      }
    }
  };

  // ---------- hit testing ----------
  V.hitLeaf = (clientX, clientY) => {
    const root = O.$('#doc-root');
    const els = document.elementsFromPoint(clientX, clientY);
    for (const el of els) {
      if (el.id === 'stage') break;
      if (!root.contains(el)) continue;
      const g = el.closest('[data-id]');
      if (g) return g.getAttribute('data-id');
    }
    return null;
  };
  V.hitAll = (clientX, clientY) => {
    const root = O.$('#doc-root'), out = [];
    for (const el of document.elementsFromPoint(clientX, clientY)) {
      if (!root.contains(el)) continue;
      const g = el.closest('[data-id]');
      if (g && !out.includes(g.getAttribute('data-id'))) out.push(g.getAttribute('data-id'));
    }
    return out;
  };
  // Resolve which node a click on leaf should select (Figma-like rules)
  V.pick = (leafId, deep) => {
    const leaf = model.get(leafId);
    if (!leaf) return null;
    if (deep) return leaf;
    const chain = [leaf].concat(model.ancestors(leaf));
    let idx = chain.length - 1;
    let cand = chain[idx];
    if (cand.type === 'frame' && idx > 0) { idx--; cand = chain[idx]; }
    const selected = O.sel();
    const isAncOfSel = c => selected.some(s => s !== c && model.isAncestor(c, s));
    while (idx > 0 && model.isContainer(cand) && (isAncOfSel(cand) || S.enteredGroup === cand.id)) {
      idx--; cand = chain[idx];
    }
    return cand;
  };
  V.isTopFrame = n => n && n.type === 'frame' && model.isPage(model.parent(n));
  V.containsWorld = (n, p) => {
    const lp = M.apply(M.inv(model.worldMatrix(n)), p);
    return lp.x >= 0 && lp.y >= 0 && lp.x <= n.w && lp.y <= n.h;
  };
  // deepest frame under point -> parent for new objects
  V.containerAt = (p, exclude) => {
    exclude = exclude || new Set();
    const search = list => {
      for (let i = list.length - 1; i >= 0; i--) {
        const n = list[i];
        if (n.type !== 'frame' || n.visible === false || n.locked || exclude.has(n.id)) continue;
        if (V.containsWorld(n, p)) return search(n.children) || n;
      }
      return null;
    };
    return search(model.page().children) || model.page();
  };
  V.nodesInRect = (r, scope) => {
    const out = [];
    for (const n of scope) {
      if (n.visible === false || n.locked) continue;
      const b = model.worldBounds(n);
      if (!b) continue;
      if (n.type === 'frame' && model.isPage(model.parent(n))) { if (R.containsRect(r, b)) out.push(n); }
      else if (R.intersects(r, b)) out.push(n);
    }
    return out;
  };

  // ---------- snapping ----------
  const Snap = O.snap = {
    xs: [], ys: [], lines: [],
    prepare(excludeIds) {
      const ex = new Set(excludeIds || []);
      const xs = [], ys = [];
      const vr = R.expand(V.viewRect(), 200 / V.zoom);
      const add = n => {
        if (ex.has(n.id) || n.visible === false) return;
        const b = model.worldBounds(n);
        if (!b || !R.intersects(vr, b)) return;
        xs.push({ v: b.x, b }, { v: b.x + b.w / 2, b }, { v: b.x + b.w, b });
        ys.push({ v: b.y, b }, { v: b.y + b.h / 2, b }, { v: b.y + b.h, b });
      };
      for (const n of model.page().children) {
        add(n);
        if (n.type === 'frame' && !ex.has(n.id)) for (const c of n.children) { add(c); if (c.type === 'frame') c.children.forEach(add); }
      }
      // selection siblings inside groups
      for (const id of ex) {
        const p = model.parent(id);
        if (p && !model.isPage(p) && p.children) p.children.forEach(add);
      }
      if (S.settings.guides && S.settings.snapGuides) for (const g of model.page().guides) (g.axis === 'x' ? xs : ys).push({ v: g.v, b: null, guide: true });
      Snap.xs = xs; Snap.ys = ys; Snap.lines = [];
    },
    best(vals, cands, thr) {
      let best = null;
      for (const v of vals) for (const c of cands) {
        const d = c.v - v;
        if (Math.abs(d) <= thr && (!best || Math.abs(d) < Math.abs(best.d) - 1e-9)) best = { d, v: c.v, c, src: v };
      }
      return best;
    },
    // snap moving box; returns {dx,dy}
    rect(box, opts = {}) {
      Snap.lines = [];
      let dx = 0, dy = 0;
      if (S.settings.smart) {
        const thr = 6 / V.zoom;
        const bx = opts.noX ? null : Snap.best([box.x, box.x + box.w / 2, box.x + box.w], Snap.xs, thr);
        const by = opts.noY ? null : Snap.best([box.y, box.y + box.h / 2, box.y + box.h], Snap.ys, thr);
        if (bx) dx = bx.d;
        if (by) dy = by.d;
        const nb = { x: box.x + dx, y: box.y + dy, w: box.w, h: box.h };
        if (bx) for (const c of Snap.xs.filter(c => Math.abs(c.v - bx.v) < 1e-6)) {
          const t = c.b || { y: nb.y, h: nb.h };
          Snap.lines.push({ x1: bx.v, y1: Math.min(nb.y, t.y), x2: bx.v, y2: Math.max(nb.y + nb.h, t.y + t.h), guide: c.guide });
        }
        if (by) for (const c of Snap.ys.filter(c => Math.abs(c.v - by.v) < 1e-6)) {
          const t = c.b || { x: nb.x, w: nb.w };
          Snap.lines.push({ x1: Math.min(nb.x, t.x), y1: by.v, x2: Math.max(nb.x + nb.w, t.x + t.w), y2: by.v, guide: c.guide });
        }
        if (bx && by) return { dx, dy };
        if (!bx) dx = Snap.gridOrPixel(box.x) - box.x;
        if (!by) dy = Snap.gridOrPixel(box.y) - box.y;
        return { dx, dy };
      }
      return { dx: Snap.gridOrPixel(box.x) - box.x, dy: Snap.gridOrPixel(box.y) - box.y };
    },
    gridOrPixel(v) {
      if (S.settings.snapGrid) { const g = S.settings.gridSize || 10; return Math.round(v / g) * g; }
      if (S.settings.snapPixel) return Math.round(v);
      return v;
    },
    point(p, opts = {}) {
      Snap.lines = [];
      const out = { x: p.x, y: p.y };
      let sx = false, sy = false;
      if (S.settings.smart && !opts.noSmart) {
        const thr = 6 / V.zoom;
        const bx = Snap.best([p.x], Snap.xs, thr), by = Snap.best([p.y], Snap.ys, thr);
        if (bx) { out.x = bx.v; sx = true; const t = bx.c.b; Snap.lines.push({ x1: bx.v, y1: Math.min(p.y, t ? t.y : p.y), x2: bx.v, y2: Math.max(p.y, t ? t.y + t.h : p.y) }); }
        if (by) { out.y = by.v; sy = true; const t = by.c.b; Snap.lines.push({ x1: Math.min(p.x, t ? t.x : p.x), y1: by.v, x2: Math.max(p.x, t ? t.x + t.w : p.x), y2: by.v }); }
      }
      if (!sx) out.x = Snap.gridOrPixel(out.x);
      if (!sy) out.y = Snap.gridOrPixel(out.y);
      return out;
    },
    clear() { Snap.lines = []; }
  };

  // ---------- overlay ----------
  const CURSORS = ['ew-resize', 'nwse-resize', 'ns-resize', 'nesw-resize'];
  O.cursorFor = (vx, vy) => {
    let a = Math.atan2(vy, vx) * 180 / Math.PI;
    a = ((a % 180) + 180) % 180;
    return CURSORS[Math.round(a / 45) % 4];
  };
  const HANDLES = { nw: [0, 0], n: [0.5, 0], ne: [1, 0], e: [1, 0.5], se: [1, 1], s: [0.5, 1], sw: [0, 1], w: [0, 0.5] };
  O.HANDLES = HANDLES;
  // current selection box description in screen space
  O.selBox = () => {
    const nodes = O.sel();
    if (!nodes.length) return null;
    if (nodes.length === 1) {
      const n = nodes[0];
      const lb = model.localBounds(n);
      const W = model.worldMatrix(n);
      return { single: n, lb, W, SM: M.mul(V.m(), W) };
    }
    const b = model.selBounds(nodes);
    if (!b) return null;
    return { single: null, lb: b, W: M.id(), SM: V.m() };
  };
  const outlineOf = (n, SM) => {
    if (['path', 'rect', 'ellipse', 'polygon', 'star', 'bool'].includes(n.type)) {
      const subs = n.type === 'bool' ? model.boolResult(n) : G.shapeSubs(n);
      return `<path d="${G.toD(subs, SM)}"/>`;
    }
    if (n.type === 'text' && n.path) return `<path d="${G.toD(n.path, SM)}"/>`;
    const pts = R.corners(model.localBounds(n)).map(p => M.apply(SM, p));
    return `<polygon points="${pts.map(p => n_(p.x) + ',' + n_(p.y)).join(' ')}"/>`;
  };
  O.outlineOf = outlineOf;

  O.overlayHooks = [];
  O.overlay = {
    draw() {
      const ov = O.$('#overlay');
      if (!ov) return;
      const { w: W, h: H } = V.size();
      const Vm = V.m();
      let s = '';
      const pg = model.page();
      // grid
      if (S.settings.grid) {
        const gs = (S.settings.gridSize || 10) * V.zoom;
        if (gs >= 6) s += `<defs><pattern id="ovgrid" patternUnits="userSpaceOnUse" x="${n_(V.x)}" y="${n_(V.y)}" width="${n_(gs)}" height="${n_(gs)}"><path d="M${n_(gs)} 0H0V${n_(gs)}" fill="none" stroke="rgba(13,153,255,0.18)" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(#ovgrid)" pointer-events="none"/>`;
      }
      if (V.zoom >= 8 && S.settings.pixelGrid !== false) {
        const gs = V.zoom;
        s += `<defs><pattern id="ovpx" patternUnits="userSpaceOnUse" x="${n_(V.x)}" y="${n_(V.y)}" width="${n_(gs)}" height="${n_(gs)}"><path d="M${n_(gs)} 0H0V${n_(gs)}" fill="none" stroke="rgba(128,128,128,0.25)" stroke-width="0.5"/></pattern></defs><rect width="100%" height="100%" fill="url(#ovpx)" pointer-events="none"/>`;
      }
      // guides: hovered / selected / dragged guides are highlighted and show their position
      if (S.settings.guides) {
        const locked = !!S.settings.guidesLocked;
        pg.guides.forEach((g, i) => {
          const active = S.guideSel === i || S.guideHover === i || S.guideDrag === i;
          const col = active ? ACC : GUIDE, sw = active ? 2 : 1;
          const cur = locked ? 'default' : (g.axis === 'x' ? 'ew-resize' : 'ns-resize');
          if (g.axis === 'x') {
            const x = n_(g.v * V.zoom + V.x);
            s += `<line x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="${col}" stroke-width="${sw}" pointer-events="none"/><line class="hguide" data-h="guide:${i}" x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="transparent" stroke-width="9" style="cursor:${cur}"/>`;
            if (active) { const tx = O.fmt(g.v), w = tx.length * 6.4 + 10; s += `<g pointer-events="none"><rect x="${n_(+x + 4)}" y="24" width="${n_(w)}" height="16" rx="3" fill="${ACC}"/><text x="${n_(+x + 4 + w / 2)}" y="35.5" fill="#fff" font-size="10.5" text-anchor="middle" font-family="system-ui,sans-serif">${tx}</text></g>`; }
          } else {
            const y = n_(g.v * V.zoom + V.y);
            s += `<line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="${col}" stroke-width="${sw}" pointer-events="none"/><line class="hguide" data-h="guide:${i}" x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="transparent" stroke-width="9" style="cursor:${cur}"/>`;
            if (active) { const tx = O.fmt(g.v), w = tx.length * 6.4 + 10; s += `<g pointer-events="none"><rect x="24" y="${n_(+y + 4)}" width="${n_(w)}" height="16" rx="3" fill="${ACC}"/><text x="${n_(24 + w / 2)}" y="${n_(+y + 15.5)}" fill="#fff" font-size="10.5" text-anchor="middle" font-family="system-ui,sans-serif">${tx}</text></g>`; }
          }
        });
      }
      // frame labels
      for (const n of pg.children) {
        if (n.type !== 'frame' || n.visible === false) continue;
        const Wm = M.mul(Vm, n.m);
        const p = M.apply(Wm, { x: 0, y: 0 }), q = M.apply(Wm, { x: n.w, y: 0 });
        const width = Math.hypot(q.x - p.x, q.y - p.y);
        if (width < 24) continue;
        const sel = S.sel.includes(n.id);
        const col = n.component ? PURPLE : (sel ? ACC : 'var(--label-fg)');
        const maxChars = Math.max(2, Math.floor(width / 6.6));
        let label = (n.component ? '◇ ' : '') + n.name;
        if (label.length > maxChars) label = label.slice(0, maxChars - 1) + '…';
        s += `<text class="frame-label" data-h="frame:${n.id}" x="${n_(p.x)}" y="${n_(p.y - 6)}" fill="${col}">${O.esc(label)}</text>`;
      }
      // hover
      const hov = S.hover && !S.sel.includes(S.hover) ? model.get(S.hover) : null;
      if (hov && hov.visible !== false && model.pageOf(hov) === pg) {
        const SM = M.mul(Vm, model.worldMatrix(hov));
        const col = hov.type === 'instance' || hov.component ? PURPLE : ACC;
        s += `<g fill="none" stroke="${col}" stroke-width="1.5" pointer-events="none">${outlineOf(hov, SM)}</g>`;
      }
      // selection
      const tool = O.tools && O.tools[S.tool];
      const editing = S.edit && model.get(S.edit.id);
      const nodes = O.sel();
      if (nodes.length && !S.textEditActive) {
        const purple = nodes.every(n => n.type === 'instance' || n.component);
        const col = purple ? PURPLE : ACC;
        if (nodes.length > 1 || editing) {
          s += `<g fill="none" stroke="${col}" stroke-width="1" pointer-events="none">`;
          for (const n of nodes) s += outlineOf(n, M.mul(Vm, model.worldMatrix(n)));
          s += '</g>';
        }
        const showBox = !editing && !(tool && tool.hideBox);
        const box = O.selBox();
        if (box && showBox) {
          const { lb, SM } = box;
          const c = R.corners(lb).map(p => M.apply(SM, p));
          s += `<polygon points="${c.map(p => n_(p.x) + ',' + n_(p.y)).join(' ')}" fill="none" stroke="${col}" stroke-width="1" pointer-events="none"/>`;
          const sw = Math.hypot(c[1].x - c[0].x, c[1].y - c[0].y), sh = Math.hypot(c[3].x - c[0].x, c[3].y - c[0].y);
          const locked = nodes.some(n => n.locked);
          if (!locked && (!tool || !tool.noHandles)) {
            const ctr = M.apply(SM, { x: lb.x + lb.w / 2, y: lb.y + lb.h / 2 });
            // rotation zones
            for (const k of ['nw', 'ne', 'se', 'sw']) {
              const [fx, fy] = HANDLES[k];
              const p = M.apply(SM, { x: lb.x + lb.w * fx, y: lb.y + lb.h * fy });
              const d = O.P.norm({ x: p.x - ctr.x, y: p.y - ctr.y });
              s += `<circle class="hrot" data-h="rot-${k}" cx="${n_(p.x + d.x * 9)}" cy="${n_(p.y + d.y * 9)}" r="11" fill="transparent"/>`;
            }
            // edges
            const edges = [['n', 0, 1], ['e', 1, 2], ['s', 2, 3], ['w', 3, 0]];
            for (const [k, a, b] of edges) {
              const [fx, fy] = HANDLES[k];
              const p = M.apply(SM, { x: lb.x + lb.w * fx, y: lb.y + lb.h * fy });
              const cur = O.cursorFor(p.x - ctr.x, p.y - ctr.y);
              s += `<line data-h="${k}" x1="${n_(c[a].x)}" y1="${n_(c[a].y)}" x2="${n_(c[b].x)}" y2="${n_(c[b].y)}" stroke="transparent" stroke-width="8" style="cursor:${cur}"/>`;
            }
            const small = sw < 24 || sh < 24;
            for (const k of ['nw', 'ne', 'se', 'sw']) {
              const [fx, fy] = HANDLES[k];
              const p = M.apply(SM, { x: lb.x + lb.w * fx, y: lb.y + lb.h * fy });
              const cur = O.cursorFor(p.x - ctr.x, p.y - ctr.y);
              if (small && (k === 'ne' || k === 'sw') && (sw < 8 || sh < 8)) continue;
              s += `<rect data-h="${k}" x="${n_(p.x - 4)}" y="${n_(p.y - 4)}" width="8" height="8" fill="#fff" stroke="${col}" stroke-width="1" style="cursor:${cur}"/>`;
            }
          }
          // size label
          const yb = Math.max(...c.map(p => p.y)), xc = (Math.min(...c.map(p => p.x)) + Math.max(...c.map(p => p.x))) / 2;
          let wv, hv;
          if (box.single) { const d = M.decompose(box.W); wv = lb.w * Math.abs(d.sx); hv = lb.h * Math.abs(d.sy); } else { wv = lb.w; hv = lb.h; }
          const label = `${O.fmt(wv)} × ${O.fmt(hv)}`;
          const tw = label.length * 6.2 + 10;
          s += `<g pointer-events="none"><rect x="${n_(xc - tw / 2)}" y="${n_(yb + 6)}" width="${n_(tw)}" height="16" rx="3" fill="${col}"/><text x="${n_(xc)}" y="${n_(yb + 17.5)}" fill="#fff" font-size="11" text-anchor="middle" font-family="system-ui,sans-serif">${label}</text></g>`;
        }
      }
      // path edit
      if (editing) s += O.overlay.pathEdit(editing, Vm);
      // module overlays (link pens, …)
      for (const hk of O.overlayHooks) { try { s += hk(Vm) || ''; } catch (e) { console.error(e); } }
      // tool specific overlay
      if (tool && tool.overlay) { try { s += tool.overlay(Vm) || ''; } catch (e) { console.error(e); } }
      // marquee
      if (S.marquee) {
        const a = V.toScreen(S.marquee), b = V.toScreen({ x: S.marquee.x + S.marquee.w, y: S.marquee.y + S.marquee.h });
        s += `<rect x="${n_(a.x)}" y="${n_(a.y)}" width="${n_(b.x - a.x)}" height="${n_(b.y - a.y)}" fill="rgba(13,153,255,0.08)" stroke="${ACC}" stroke-width="1" pointer-events="none"/>`;
      }
      // smart guides
      for (const l of Snap.lines) {
        const a = V.toScreen({ x: l.x1, y: l.y1 }), b = V.toScreen({ x: l.x2, y: l.y2 });
        s += `<line x1="${n_(a.x)}" y1="${n_(a.y)}" x2="${n_(b.x)}" y2="${n_(b.y)}" stroke="${l.guide ? GUIDE : SMART}" stroke-width="1" pointer-events="none"/>`;
      }
      // measurement (Alt)
      if (S.measure) s += S.measure;
      ov.innerHTML = s;
    },
    pathEdit(n, Vm) {
      const SM = M.mul(Vm, model.worldMatrix(n));
      const subs = n.type === 'path' ? n.subpaths : G.shapeSubs(n);
      if (!subs) return '';
      let s = `<path d="${G.toD(subs, SM)}" fill="none" stroke="${ACC}" stroke-width="1" pointer-events="none"/>`;
      const sel = S.edit.sel || new Set();
      let handles = '', anchors = '';
      subs.forEach((sp, si) => {
        const N = sp.pts.length;
        sp.pts.forEach((p, k) => {
          const key = si + ':' + k;
          const near = sel.has(key) || sel.has(si + ':' + ((k + 1) % N)) || sel.has(si + ':' + ((k - 1 + N) % N)) || S.edit.showAll;
          const a = M.apply(SM, p);
          if (near) for (const [hk, hp] of [['hi', p.i], ['ho', p.o]]) {
            if (!hp) continue;
            const q = M.apply(SM, hp);
            handles += `<line x1="${n_(a.x)}" y1="${n_(a.y)}" x2="${n_(q.x)}" y2="${n_(q.y)}" stroke="${ACC}" stroke-width="1" pointer-events="none"/><circle data-h="${hk}:${key}" cx="${n_(q.x)}" cy="${n_(q.y)}" r="3.5" fill="#fff" stroke="${ACC}" stroke-width="1"/>`;
          }
          const on = sel.has(key);
          const first = !sp.closed && (k === 0 || k === N - 1);
          anchors += first
            ? `<circle data-h="a:${key}" cx="${n_(a.x)}" cy="${n_(a.y)}" r="4" fill="${on ? ACC : '#fff'}" stroke="${ACC}" stroke-width="1.2"/>`
            : `<rect data-h="a:${key}" x="${n_(a.x - 3.5)}" y="${n_(a.y - 3.5)}" width="7" height="7" fill="${on ? ACC : '#fff'}" stroke="${ACC}" stroke-width="1.2"/>`;
        });
      });
      return s + handles + anchors;
    }
  };
})();
