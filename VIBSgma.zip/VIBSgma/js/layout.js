'use strict';
/* Obrys — Blender-style workspace.
   Every panel is an area: drag the gaps to resize, split an area side by side or one above the other, join areas,
   swap them, maximise one (Ctrl+Space) and switch any area to another editor. Workspaces (Дизайн, Анімація, Сайт,
   Код and your own) are remembered in the browser. On phones the classic drawers are used instead. */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const L = O.layout = { editors: {}, tree: null, max: null, mobile: false, active: false };
  O.ICONS.splitH = '<rect x="3.5" y="4.5" width="17" height="15" rx="1.5"/><path d="M12 4.5v15"/>';
  O.ICONS.splitV = '<rect x="3.5" y="4.5" width="17" height="15" rx="1.5"/><path d="M3.5 12h17"/>';
  O.ICONS.maximize = '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>';
  O.ICONS.restore = '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>';
  O.ICONS.history = '<path d="M4 12a8 8 0 1 0 2.4-5.7"/><path d="M4 4v4.5h4.5"/><path d="M12 8v4.5l3 2"/>';
  O.ICONS.workspace = '<rect x="3.5" y="4.5" width="17" height="15" rx="1.5"/><path d="M9 4.5v15M9 12h11.5"/>';
  O.ICONS.web = '<rect x="3.5" y="4.5" width="17" height="15" rx="1.5"/><path d="M3.5 8.5h17"/><circle cx="6" cy="6.5" r=".5" fill="currentColor"/><circle cx="8" cy="6.5" r=".5" fill="currentColor"/>';

  // ---------- editors (each one is a single DOM element moved into its area) ----------
  L.register = (id, def) => { L.editors[id] = Object.assign({ id, visible: false }, def); };
  const elOf = id => { const d = L.editors[id]; return d ? (typeof d.el === 'function' ? d.el() : d.el) : null; };
  const GROUPS = { side: ['layers', 'assets', 'history'], props: ['design', 'code', 'webview'] };
  const stash = document.createElement('div');
  stash.id = 'ws-stash';
  stash.hidden = true;

  // ---------- tree ----------
  const A = ed => ({ id: O.uid(), area: ed });
  const SP = (dir, a, b, o = {}) => Object.assign({ id: O.uid(), split: dir, ratio: 0.5, a, b }, o);
  L.PRESETS = [
    { id: 'design', name: 'Дизайн', tree: () => SP('h', A('layers'), SP('h', A('canvas'), A('design'), { fixed: 'b', size: 280 }), { fixed: 'a', size: 248 }) },
    { id: 'anim', name: 'Анімація', tree: () => SP('h', A('layers'), SP('h', SP('v', A('canvas'), A('timeline'), { fixed: 'b', size: 230 }), A('design'), { fixed: 'b', size: 280 }), { fixed: 'a', size: 220 }) },
    { id: 'web', name: 'Сайт', tree: () => SP('h', A('layers'), SP('h', A('canvas'), SP('v', A('webview'), A('design'), { ratio: 0.55 }), { fixed: 'b', size: 460 }), { fixed: 'a', size: 220 }) },
    { id: 'code', name: 'Код', tree: () => SP('h', A('canvas'), SP('v', A('code'), A('history'), { ratio: 0.7 }), { fixed: 'b', size: 420 }) }
  ];
  const find = (node, id, parent = null) => {
    if (!node) return null;
    if (node.id === id) return { node, parent };
    if (node.split) return find(node.a, id, node) || find(node.b, id, node);
    return null;
  };
  const areas = (node, out = []) => { if (!node) return out; if (node.area) out.push(node); else { areas(node.a, out); areas(node.b, out); } return out; };
  const replace = (target, repl) => {
    const hit = find(L.tree, target.id);
    if (!hit) return;
    if (!hit.parent) L.tree = repl;
    else if (hit.parent.a === target) hit.parent.a = repl; else hit.parent.b = repl;
  };
  L.areas = () => areas(L.tree);
  L.visible = id => !!L.editors[id] && L.editors[id].visible;

  // ---------- rendering ----------
  const headerHTML = node => {
    const d = L.editors[node.area] || L.editors.empty;
    const grp = d.group && GROUPS[d.group];
    const mid = grp
      ? `<div class="ws-tabs" role="tablist">${grp.filter(id => L.editors[id]).map(id => `<button type="button" role="tab" aria-selected="${id === node.area}" class="${id === node.area ? 'on' : ''}" data-wsa="set" data-ed="${id}">${esc(t(L.editors[id].label))}</button>`).join('')}</div>`
      : `<span class="ws-name">${esc(t(d.label))}</span>`;
    const maxed = L.max === node.id;
    const b = (a, icon, title) => `<button type="button" class="ib" data-wsa="${a}" title="${esc(t(title))}" aria-label="${esc(t(title))}">${O.icon(icon, 14)}</button>`;
    return `<header class="ws-ah"><button type="button" class="ws-type" data-wsa="type" title="${esc(t('Тип редактора'))}" aria-label="${esc(t('Тип редактора'))}">${O.icon(d.icon || 'rect', 14)}${O.icon('chevdown', 10)}</button>${mid}<span class="sp"></span>${maxed ? '' : b('split-h', 'splitH', 'Розділити: поруч') + b('split-v', 'splitV', 'Розділити: одна над одною')}${b('max', maxed ? 'restore' : 'maximize', maxed ? 'Відновити (Ctrl+Space)' : 'Розгорнути (Ctrl+Space)')}${maxed ? '' : b('close', 'close', 'Закрити область')}</header>`;
  };
  const sizeChildren = (box, node) => {
    const a = box.children[0], g = box.children[1], b = box.children[2];
    if (node.fixed === 'a') { a.style.flex = `0 0 ${node.size}px`; b.style.flex = '1 1 0'; }
    else if (node.fixed === 'b') { a.style.flex = '1 1 0'; b.style.flex = `0 0 ${node.size}px`; }
    else { a.style.flex = `${node.ratio} 1 0`; b.style.flex = `${1 - node.ratio} 1 0`; }
    g.setAttribute('aria-valuenow', String(Math.round(node.fixed ? node.size : node.ratio * 100)));
  };
  const renderNode = node => {
    if (node.area) return O.h(`<section class="ws-area" data-aid="${node.id}" data-ed="${node.area}" aria-label="${esc(t((L.editors[node.area] || L.editors.empty).label))}">${L.headers === false && node.area === 'canvas' ? '' : headerHTML(node)}<div class="ws-ab"></div></section>`);
    const box = O.h(`<div class="ws-split ${node.split}" data-sid="${node.id}"><div class="ws-c"></div><div class="ws-gutter" data-gid="${node.id}" role="separator" tabindex="0" aria-orientation="${node.split === 'h' ? 'vertical' : 'horizontal'}" aria-label="${esc(t('Межа областей: тягніть, щоб змінити розмір. Правий клік — дії'))}"></div><div class="ws-c"></div></div>`);
    sizeChildren(box, node);
    box.children[0].appendChild(renderNode(node.a));
    box.children[2].appendChild(renderNode(node.b));
    return box;
  };
  const emptyHTML = () => `<div class="ws-empty"><p>${esc(t('Оберіть, що показати в цій області:'))}</p><div class="ws-pick">${Object.values(L.editors).filter(d => d.id !== 'empty').map(d => `<button type="button" class="btn" data-wsa="set" data-ed="${d.id}"${d.visible ? ' disabled' : ''}>${O.icon(d.icon || 'rect', 14)} ${esc(t(d.label))}</button>`).join('')}</div></div>`;
  L.apply = () => {
    if (L.mobile || !L.tree) return;
    const ws = O.$('#ws');
    for (const id of Object.keys(L.editors)) { const e = elOf(id); if (e && e.parentElement !== stash) stash.appendChild(e); }
    ws.innerHTML = '';
    const maxNode = L.max && find(L.tree, L.max);
    if (L.max && !maxNode) L.max = null;
    ws.appendChild(renderNode(maxNode ? maxNode.node : L.tree));
    const shown = new Set();
    ws.querySelectorAll('.ws-area').forEach(box => {
      const id = box.dataset.ed;
      const body = box.querySelector('.ws-ab');
      const e = elOf(id);
      if (!e || shown.has(id)) { body.innerHTML = emptyHTML(); box.dataset.ed = 'empty'; return; }
      shown.add(id);
      e.hidden = false;
      body.appendChild(e);
    });
    for (const [id, d] of Object.entries(L.editors)) {
      const vis = shown.has(id);
      if (!vis) { const e = elOf(id); if (e) e.hidden = id !== 'canvas'; }
      if (vis !== d.visible) { d.visible = vis; try { if (vis && d.onShow) d.onShow(); if (!vis && d.onHide) d.onHide(); } catch (err) { console.error(err); } }
    }
    // empty areas list editors that are free right now
    ws.querySelectorAll('.ws-area[data-ed="empty"] .ws-ab').forEach(b => { b.innerHTML = emptyHTML(); });
    save();
    O.emit('layout');
    requestAnimationFrame(() => { if (O.view && O.view.el) { O.view.drawRulers(); O.requestOverlay(); } });
  };

  // ---------- operations ----------
  const freeEditor = () => ['design', 'layers', 'assets', 'code', 'history', 'webview', 'timeline'].find(id => L.editors[id] && !L.visible(id)) || 'empty';
  L.split = (aid, dir, ed) => {
    const hit = find(L.tree, aid);
    if (!hit || !hit.node.area) return;
    const n = hit.node;
    const fresh = SP(dir, A(n.area), A(ed || freeEditor()), { ratio: 0.5 });
    fresh.a.id = n.id;
    replace(n, fresh);
    L.max = null;
    L.apply();
  };
  L.close = aid => {
    const hit = find(L.tree, aid);
    if (!hit || !hit.parent) return O.toast('Це остання область');
    if (hit.node.area === 'canvas') return O.toast('Полотно не можна закрити: змініть тип цієї області або закрийте сусідню');
    const sib = hit.parent.a === hit.node ? hit.parent.b : hit.parent.a;
    replace(hit.parent, sib);
    if (L.max === aid) L.max = null;
    L.apply();
  };
  L.setType = (aid, ed) => {
    const hit = find(L.tree, aid);
    if (!hit || !hit.node.area || !L.editors[ed]) return;
    const n = hit.node;
    if (n.area === ed) return;
    const other = areas(L.tree).find(a => a.area === ed && a !== n);
    if (other) other.area = n.area === 'empty' ? 'empty' : n.area;
    else if (n.area === 'canvas') return O.toast('Полотно має бути видимим: оберіть для нього іншу область');
    n.area = ed;
    L.apply();
  };
  L.swap = sid => {
    const hit = find(L.tree, sid);
    if (!hit || !hit.node.split) return;
    const s = hit.node;
    [s.a, s.b] = [s.b, s.a];
    if (s.fixed) s.fixed = s.fixed === 'a' ? 'b' : 'a';
    L.apply();
  };
  L.rotate = sid => { const hit = find(L.tree, sid); if (!hit || !hit.node.split) return; hit.node.split = hit.node.split === 'h' ? 'v' : 'h'; if (hit.node.fixed) { hit.node.fixed = null; hit.node.ratio = 0.5; } L.apply(); };
  L.join = (sid, keep) => { const hit = find(L.tree, sid); if (!hit || !hit.node.split) return; const s = hit.node; const kept = keep === 'a' ? s.a : s.b; const gone = keep === 'a' ? s.b : s.a; if (areas(gone).some(a => a.area === 'canvas')) return O.toast('Полотно не можна закрити: змініть тип цієї області або закрийте сусідню'); replace(s, kept); L.apply(); };
  L.toggleMax = aid => { L.max = L.max ? null : (aid || (areas(L.tree).find(a => a.area === 'canvas') || {}).id); L.apply(); };
  // show an editor somewhere (used by «Таймлайн», «Вебперегляд»…): split the canvas area if it is not visible
  L.show = (ed, opts = {}) => {
    if (L.mobile) return false;
    if (L.visible(ed)) return true;
    const canvas = areas(L.tree).find(a => a.area === 'canvas');
    if (!canvas) return false;
    const hit = find(L.tree, canvas.id);
    const dir = opts.dir || 'v';
    const fresh = SP(dir, A('canvas'), A(ed), { fixed: 'b', size: opts.size || (dir === 'v' ? 230 : 380) });
    fresh.a.id = canvas.id;
    replace(hit.node, fresh);
    L.max = null;
    L.apply();
    return true;
  };
  L.hide = ed => { const a = areas(L.tree).find(x => x.area === ed); if (a) L.close(a.id); };
  L.toggle = (ed, opts) => { if (L.visible(ed)) L.hide(ed); else L.show(ed, opts); };

  // ---------- workspaces ----------
  let spaces = null, current = 'design';
  const clone = x => JSON.parse(JSON.stringify(x));
  const defaults = () => L.PRESETS.map(p => ({ id: p.id, name: p.name, preset: true, tree: p.tree() }));
  const save = O.debounce(() => { if (!spaces) return; const s = spaces.find(w => w.id === current); if (s) s.tree = clone(L.tree); O.ls.set('workspaces', { v: 1, current, spaces }); }, 200);
  const load = () => {
    const st = O.ls.get('workspaces', null);
    spaces = st && st.v === 1 && Array.isArray(st.spaces) && st.spaces.length ? st.spaces : defaults();
    // new presets from later versions
    for (const p of L.PRESETS) if (!spaces.some(s => s.id === p.id)) spaces.push({ id: p.id, name: p.name, preset: true, tree: p.tree() });
    current = st && spaces.some(s => s.id === st.current) ? st.current : 'design';
    const s = spaces.find(w => w.id === current);
    L.tree = clone(s.tree);
    if (!areas(L.tree).some(a => a.area === 'canvas')) L.tree = L.PRESETS[0].tree();
  };
  L.spaces = () => spaces.slice();
  L.current = () => current;
  L.switchTo = id => {
    const s = spaces.find(w => w.id === id);
    if (!s) return;
    const cur = spaces.find(w => w.id === current);
    if (cur) cur.tree = clone(L.tree);
    current = id;
    L.tree = clone(s.tree);
    L.max = null;
    L.apply();
    updateBtn();
  };
  L.addSpace = () => {
    const cur = spaces.find(w => w.id === current);
    const s = { id: O.uid(), name: t('Робочий простір {n}', { n: spaces.length + 1 }), tree: clone(L.tree) };
    if (cur) cur.tree = clone(L.tree);
    spaces.push(s);
    current = s.id;
    save(); updateBtn();
    O.toast('Створено «{name}». Змінюйте області — простір запам’ятає розкладку.', { name: s.name });
  };
  L.renameSpace = () => {
    const s = spaces.find(w => w.id === current);
    ui.dialog({ title: 'Перейменувати робочий простір', fields: [{ key: 'name', label: 'Назва', type: 'text', value: s.preset ? t(s.name) : s.name }], onOk: v => { if (v.name.trim()) { s.name = v.name.trim(); s.preset = false; save(); updateBtn(); } } });
  };
  L.deleteSpace = () => {
    if (spaces.length < 2) return O.toast('Це останній робочий простір');
    spaces = spaces.filter(w => w.id !== current);
    current = spaces[0].id;
    L.tree = clone(spaces[0].tree);
    L.apply(); updateBtn();
  };
  L.resetSpace = () => {
    const p = L.PRESETS.find(x => x.id === current);
    L.tree = p ? p.tree() : L.PRESETS[0].tree();
    L.max = null;
    L.apply();
  };
  const spaceName = s => (s.preset ? t(s.name) : s.name);
  const updateBtn = () => { const b = O.$('#btn-ws .lbl'); const s = spaces && spaces.find(w => w.id === current); if (b && s) b.textContent = spaceName(s); };
  L.menu = anchor => {
    const r = anchor.getBoundingClientRect();
    const items = spaces.map(s => ({ id: 'ws:' + s.id, label: spaceName(s), raw: true, check: () => s.id === current })).concat(['-',
      { id: 'ws-new', label: 'Новий робочий простір' }, { id: 'ws-rename', label: 'Перейменувати…' }, { id: 'ws-reset', label: 'Скинути розкладку' }, { id: 'ws-delete', label: 'Видалити робочий простір' }, '-',
      { id: 'ws-headers', label: 'Заголовки областей', check: () => L.headers !== false }]);
    ui.menu(items, r.left, r.bottom + 4, {
      onPick: id => {
        if (id.startsWith('ws:')) L.switchTo(id.slice(3));
        if (id === 'ws-new') L.addSpace();
        if (id === 'ws-rename') L.renameSpace();
        if (id === 'ws-reset') L.resetSpace();
        if (id === 'ws-delete') L.deleteSpace();
        if (id === 'ws-headers') { L.headers = L.headers === false; O.ls.set('wsHeaders', L.headers); L.apply(); }
      }
    });
  };

  // ---------- events ----------
  let hoverArea = null;
  const typeMenu = (btn, aid) => {
    const r = btn.getBoundingClientRect();
    const items = Object.values(L.editors).filter(d => d.id !== 'empty').map(d => ({ id: 'ed:' + d.id, label: d.label, check: () => { const h = find(L.tree, aid); return h && h.node.area === d.id; } }));
    ui.menu(items, r.left, r.bottom + 2, { onPick: id => L.setType(aid, id.slice(3)) });
  };
  const areaMenu = (x, y, aid) => {
    const hit = find(L.tree, aid);
    const sib = hit && hit.parent;
    ui.menu([{ id: 'sh', label: 'Розділити: поруч' }, { id: 'sv', label: 'Розділити: одна над одною' }, '-', { id: 'mx', label: L.max ? 'Відновити (Ctrl+Space)' : 'Розгорнути (Ctrl+Space)' }, sib ? { id: 'sw', label: 'Поміняти місцями із сусідньою' } : null, sib ? { id: 'ro', label: 'Повернути поділ' } : null, '-', { id: 'cl', label: 'Закрити область' }].filter(Boolean), x, y, {
      onPick: id => { if (id === 'sh') L.split(aid, 'h'); if (id === 'sv') L.split(aid, 'v'); if (id === 'mx') L.toggleMax(aid); if (id === 'sw' && sib) L.swap(sib.id); if (id === 'ro' && sib) L.rotate(sib.id); if (id === 'cl') L.close(aid); }
    });
  };
  const gutterMenu = (x, y, sid) => {
    const hit = find(L.tree, sid);
    if (!hit) return;
    const h = hit.node.split === 'h';
    ui.menu([{ id: 'ka', label: h ? 'Об’єднати: залишити ліву' : 'Об’єднати: залишити верхню' }, { id: 'kb', label: h ? 'Об’єднати: залишити праву' : 'Об’єднати: залишити нижню' }, '-', { id: 'sw', label: 'Поміняти області місцями' }, { id: 'ro', label: 'Повернути поділ' }, { id: 'eq', label: 'Порівну' }], x, y, {
      onPick: id => { if (id === 'ka') L.join(sid, 'a'); if (id === 'kb') L.join(sid, 'b'); if (id === 'sw') L.swap(sid); if (id === 'ro') L.rotate(sid); if (id === 'eq') { hit.node.fixed = null; hit.node.ratio = 0.5; L.apply(); } }
    });
  };
  const bind = ws => {
    ws.addEventListener('click', e => {
      const b = e.target.closest('[data-wsa]');
      if (!b) return;
      const box = b.closest('.ws-area');
      const aid = box && box.dataset.aid;
      const a = b.dataset.wsa;
      if (a === 'type') typeMenu(b, aid);
      if (a === 'set') L.setType(aid, b.dataset.ed);
      if (a === 'split-h') L.split(aid, 'h');
      if (a === 'split-v') L.split(aid, 'v');
      if (a === 'max') L.toggleMax(aid);
      if (a === 'close') L.close(aid);
    });
    ws.addEventListener('contextmenu', e => {
      const g = e.target.closest('.ws-gutter');
      if (g) { e.preventDefault(); gutterMenu(e.clientX, e.clientY, g.dataset.gid); return; }
      const h = e.target.closest('.ws-ah');
      if (h) { e.preventDefault(); areaMenu(e.clientX, e.clientY, h.closest('.ws-area').dataset.aid); }
    });
    ws.addEventListener('dblclick', e => { const h = e.target.closest('.ws-ah'); if (h && !e.target.closest('button')) L.toggleMax(h.closest('.ws-area').dataset.aid); });
    ws.addEventListener('pointerover', e => { const a = e.target.closest('.ws-area'); if (a) hoverArea = a.dataset.aid; });
    ws.addEventListener('pointerdown', e => {
      const g = e.target.closest('.ws-gutter');
      if (!g || e.button !== 0) return;
      e.preventDefault();
      const hit = find(L.tree, g.dataset.gid);
      if (!hit) return;
      const node = hit.node, box = g.parentElement, r = box.getBoundingClientRect(), horiz = node.split === 'h';
      try { g.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      g.classList.add('on');
      document.body.classList.add(horiz ? 'ws-drag-h' : 'ws-drag-v');
      const mv = ev => {
        const total = horiz ? r.width : r.height;
        const MIN = horiz ? 150 : 90;
        const p = O.clamp((horiz ? ev.clientX - r.left : ev.clientY - r.top), MIN, Math.max(MIN, total - MIN));
        if (node.fixed === 'a') node.size = Math.round(p);
        else if (node.fixed === 'b') node.size = Math.round(total - p);
        else node.ratio = p / total;
        sizeChildren(box, node);
      };
      const up = () => { g.removeEventListener('pointermove', mv); g.removeEventListener('pointerup', up); g.classList.remove('on'); document.body.classList.remove('ws-drag-h', 'ws-drag-v'); save(); O.emit('layout'); };
      g.addEventListener('pointermove', mv); g.addEventListener('pointerup', up);
    });
    ws.addEventListener('keydown', e => {
      const g = e.target.closest('.ws-gutter');
      if (!g) return;
      const hit = find(L.tree, g.dataset.gid);
      if (!hit) return;
      const node = hit.node, step = e.shiftKey ? 64 : 16;
      const d = { ArrowLeft: -step, ArrowUp: -step, ArrowRight: step, ArrowDown: step }[e.key];
      if (!d) return;
      e.preventDefault(); e.stopPropagation();
      const box = g.parentElement, total = node.split === 'h' ? box.clientWidth : box.clientHeight;
      if (node.fixed === 'a') node.size = O.clamp(node.size + d, 120, total - 120);
      else if (node.fixed === 'b') node.size = O.clamp(node.size - d, 120, total - 120);
      else node.ratio = O.clamp(node.ratio + d / total, 0.1, 0.9);
      sizeChildren(box, node);
      save();
    });
  };
  // Ctrl+Space: maximise / restore the area under the pointer (before the canvas takes Space for panning)
  document.addEventListener('keydown', e => {
    if (!L.active || L.mobile) return;
    if (e.code === 'Space' && (e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey) {
      const tg = e.target;
      if (tg && (tg.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(tg.tagName))) return;
      e.preventDefault(); e.stopPropagation();
      L.toggleMax(hoverArea);
    }
  }, true);

  // ---------- phones: classic drawers ----------
  const mq = matchMedia('(max-width: 760px)');
  const toDrawers = () => {
    const left = O.$('#left'), right = O.$('#right');
    for (const id of ['layers', 'assets']) { const e = elOf(id); if (e) left.appendChild(e); }
    for (const id of ['design', 'code']) { const e = elOf(id); if (e) right.appendChild(e); }
    const lt = O.$('#left .ptabs button.on'), rt = O.$('#right .ptabs button.on');
    O.$('#lp-layers').hidden = lt ? lt.dataset.lt !== 'layers' : false;
    O.$('#lp-assets').hidden = lt ? lt.dataset.lt !== 'assets' : true;
    O.$('#props').hidden = rt ? rt.dataset.rt !== 'design' : false;
    O.$('#code').hidden = rt ? rt.dataset.rt !== 'code' : true;
    const ws = O.$('#ws');
    ws.innerHTML = '';
    for (const id of Object.keys(L.editors)) { const e = elOf(id); if (e && !left.contains(e) && !right.contains(e) && e.parentElement !== stash) stash.appendChild(e); }
    ws.appendChild(O.$('#canvas'));
    for (const [id, d] of Object.entries(L.editors)) { const vis = id === 'canvas' || ['layers', 'assets', 'design', 'code'].includes(id); if (vis !== d.visible) { d.visible = vis; try { if (vis && d.onShow) d.onShow(); if (!vis && d.onHide) d.onHide(); } catch (err) { console.error(err); } } }
    O.panels.refresh(true);
  };
  const mode = () => {
    L.mobile = mq.matches;
    document.body.classList.toggle('ws-mobile', L.mobile);
    if (L.mobile) toDrawers(); else { document.body.classList.remove('show-left', 'show-right'); L.apply(); O.panels.refresh(true); }
  };

  // ---------- built-in extra editors ----------
  // history (like Photoshop's History panel): click a step to go back or forward
  const histEl = O.h('<div id="ed-history" class="ed-list" role="listbox"></div>');
  const renderHistory = () => {
    if (!L.visible('history')) return;
    const H = O.history;
    const rows = H.labels.map((lb, i) => `<button type="button" role="option" class="eh-row${i === H.idx ? ' on' : ''}${i > H.idx ? ' fut' : ''}" data-hi="${i}" aria-selected="${i === H.idx}">${O.icon(i === 0 ? 'page' : 'history', 13)}<span>${esc(i === 0 ? t('Відкриття документа') : (lb ? t(lb) : t('Зміна')))}</span></button>`).reverse().join('');
    histEl.innerHTML = rows || `<div class="ws-empty">${esc(t('Історія порожня'))}</div>`;
  };
  histEl.addEventListener('click', e => {
    const r = e.target.closest('[data-hi]');
    if (!r) return;
    const want = +r.dataset.hi, H = O.history;
    while (H.idx > want) H.undo();
    while (H.idx < want) H.redo();
    renderHistory();
  });
  O.on('change', O.debounce(renderHistory, 60));
  O.on('docload', () => setTimeout(renderHistory, 0));
  O.on('lang', renderHistory);
  // web preview: the selected frame or its responsive page, live
  const webEl = O.h(`<div id="ed-web" class="ed-web"><div class="ew-bar"><select class="sel mini" data-ew="w" aria-label="Width"><option value="0">100%</option><option value="1440">1440</option><option value="1024">1024</option><option value="768">768</option><option value="390">390</option><option value="360">360</option></select><span class="ew-what"></span><span class="sp"></span><button type="button" class="ib" data-ew="open" aria-label="Open">${O.icon('maximize', 14)}</button></div><div class="ew-stage"><iframe title="preview" sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox"></iframe></div></div>`);
  let webHTML = '';
  const webSource = () => {
    if (!S.doc || !O.html) return null;
    const sel = O.sel();
    const pg = model.page();
    let f = sel.map(n => (n.type === 'frame' && model.isPage(model.parent(n)) ? n : O.html.topFrameOf(n))).find(Boolean);
    if (!f) f = pg.children.find(n => n.type === 'frame' && n.visible !== false);
    if (!f) {
      // no frames: show the page's objects as they are
      const loose = (sel.length ? O.topSel() : pg.children).filter(n => n.visible !== false);
      return loose.length ? { html: O.html.pageHTML(loose, { fit: true }), label: t('Об’єкти сторінки') } : null;
    }
    const g = O.html.links('adapt').find(l => l.ids.includes(f.id));
    if (g) return { html: O.html.buildSite(g, {}).htmlInline, label: g.name || f.name };
    // prototype links lead to other frames: put the whole flow on the page and start at this frame
    let flow = false;
    model.walk(pg.children, n => { if (n.proto && n.proto.some(it => it.action === 'navigate')) flow = true; });
    if (flow) {
      const frames = pg.children.filter(n => n.type === 'frame' && n.visible !== false);
      const html = O.html.build(frames, { fit: true, bg: '#ffffff' }).htmlInline.replace('</body>', `<script>document.addEventListener('DOMContentLoaded',function(){var s=document.querySelector(${JSON.stringify('[aria-label=' + JSON.stringify(f.name) + ']')});if(s)s.scrollIntoView();});</script></body>`);
      return { html, label: f.name + ' · ' + t('прототип, екранів: {n}', { n: frames.length }) };
    }
    return { html: O.html.build([f], { fit: true, bg: '#ffffff' }).htmlInline, label: f.name };
  };
  const renderWeb = () => {
    if (!L.visible('webview')) return;
    let src = null, err = null;
    try { src = webSource(); } catch (e) { console.warn(e); err = e; }
    const what = webEl.querySelector('.ew-what');
    if (err) { what.textContent = t('Помилка: {msg}', { msg: err.message }); return; }
    if (!src) { what.textContent = t('Додайте фрейм або об’єкти, щоб побачити вебсторінку'); webEl.querySelector('iframe').srcdoc = ''; webHTML = ''; return; }
    what.textContent = src.label;
    if (src.html !== webHTML) { webHTML = src.html; webEl.querySelector('iframe').srcdoc = src.html; }
  };
  const webSoon = O.debounce(renderWeb, 500);
  O.on('change', webSoon);
  O.on('selection', webSoon);
  O.on('page', webSoon);
  webEl.addEventListener('change', e => { if (e.target.dataset.ew === 'w') { const v = +e.target.value; const fr = webEl.querySelector('iframe'); fr.style.width = v ? v + 'px' : '100%'; fr.style.flex = v ? 'none' : '1'; } });
  webEl.addEventListener('click', e => { if (e.target.closest('[data-ew="open"]') && webHTML) O.html.previewHTML(webHTML, {}); });

  L.register('canvas', { label: 'Полотно', icon: 'frame', el: () => O.$('#canvas') });
  L.register('layers', { label: 'Шари', icon: 'layers', el: () => O.$('#lp-layers'), group: 'side' });
  L.register('assets', { label: 'Ресурси', icon: 'grid', el: () => O.$('#lp-assets'), group: 'side', onShow: () => O.panels.refresh(true) });
  L.register('history', { label: 'Історія', icon: 'history', el: histEl, group: 'side', onShow: renderHistory });
  L.register('design', { label: 'Дизайн', icon: 'sliders', el: () => O.$('#props'), group: 'props', onShow: () => O.panels.refresh(true) });
  L.register('code', { label: 'Код', icon: 'code', el: () => O.$('#code'), group: 'props', onShow: () => O.panels.refresh(true) });
  L.register('webview', { label: 'Вебперегляд', icon: 'web', el: webEl, group: 'props', onShow: () => { webHTML = ''; renderWeb(); } });
  L.register('empty', { label: 'Порожня область', icon: 'workspace', el: null });

  // ---------- start ----------
  L.init = () => {
    if (L.active) return;
    document.body.appendChild(stash);
    stash.appendChild(histEl);
    stash.appendChild(webEl);
    L.headers = O.ls.get('wsHeaders', true);
    load();
    L.active = true;
    document.body.classList.add('ws-on');
    bind(O.$('#ws'));
    // workspace switcher in the top bar
    const btn = O.h(`<button id="btn-ws" class="ws-btn" type="button" title="${esc(t('Робочий простір'))}" aria-label="${esc(t('Робочий простір'))}">${O.icon('workspace', 15)}<span class="lbl"></span>${O.icon('chevdown', 11)}</button>`);
    O.$('#menubar').after(btn);
    btn.addEventListener('click', () => L.menu(btn));
    updateBtn();
    mq.addEventListener ? mq.addEventListener('change', mode) : mq.addListener(mode);
    mode();
  };
  O.on('lang', () => { if (!L.active) return; updateBtn(); const b = O.$('#btn-ws'); if (b) { b.title = t('Робочий простір'); b.setAttribute('aria-label', t('Робочий простір')); } if (!L.mobile) L.apply(); });
  // commands
  L.PRESETS.forEach(p => O.cmd('ws:' + p.id, 'Робочий простір: ' + p.name, () => L.switchTo(p.id), { group: 'Вигляд', label: () => t('Робочий простір') + ': ' + t(p.name) }));
  O.cmd('wsMax', 'Розгорнути / відновити область', () => L.toggleMax(hoverArea), { group: 'Вигляд', keys: ['Ctrl+Space'] });
  O.cmd('wsHistory', 'Історія змін', () => L.toggle('history', { dir: 'h', size: 260 }), { group: 'Вигляд', check: () => L.visible('history') });
  O.cmd('wsWeb', 'Вебперегляд', () => L.toggle('webview', { dir: 'h', size: 460 }), { group: 'Вигляд', check: () => L.visible('webview') });
  const view = O.MENUS.find(m => m[0] === 'Вигляд');
  if (view) view[1].splice(view[1].indexOf('toggleUI'), 0, { label: 'Робочий простір', items: L.PRESETS.map(p => 'ws:' + p.id).concat(['-', 'wsMax', 'wsHistory', 'wsWeb']) });
  // «Сховати панелі» maximises the canvas area
  const tu = O.cmds.get('toggleUI');
  if (tu) tu.run = () => { if (L.active && !L.mobile) { const c = L.areas().find(a => a.area === 'canvas'); L.toggleMax(c && c.id); } else document.body.classList.toggle('noui'); };
})();
