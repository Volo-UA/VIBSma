'use strict';
/* Obrys — geometry: bezier math, shapes as paths, path data, booleans (paper.js), offsets (Clipper) */
(function () {
  const O = window.O, M = O.M, P = O.P;
  const G = O.G = {};
  const K = 0.5522847498;

  G.pt = (x, y, i, o, t) => ({ x, y, i: i || null, o: o || null, t: t || 'corner' });
  G.cp = p => ({ x: p.x, y: p.y, i: p.i ? { x: p.i.x, y: p.i.y } : null, o: p.o ? { x: p.o.x, y: p.o.y } : null, t: p.t || 'corner' });
  G.cloneSubs = subs => subs.map(sp => ({ closed: !!sp.closed, pts: sp.pts.map(G.cp) }));

  // ---------- cubic bezier ----------
  G.bez = (p0, p1, p2, p3, t) => {
    const u = 1 - t, a = u * u * u, b = 3 * u * u * t, c = 3 * u * t * t, d = t * t * t;
    return { x: a * p0.x + b * p1.x + c * p2.x + d * p3.x, y: a * p0.y + b * p1.y + c * p2.y + d * p3.y };
  };
  G.bezD = (p0, p1, p2, p3, t) => {
    const u = 1 - t;
    return {
      x: 3 * u * u * (p1.x - p0.x) + 6 * u * t * (p2.x - p1.x) + 3 * t * t * (p3.x - p2.x),
      y: 3 * u * u * (p1.y - p0.y) + 6 * u * t * (p2.y - p1.y) + 3 * t * t * (p3.y - p2.y)
    };
  };
  G.split = (p0, p1, p2, p3, t) => {
    const a = P.lerp(p0, p1, t), b = P.lerp(p1, p2, t), c = P.lerp(p2, p3, t);
    const d = P.lerp(a, b, t), e = P.lerp(b, c, t), f = P.lerp(d, e, t);
    return [[p0, a, d, f], [f, e, c, p3]];
  };
  function quadRoots(a, b, c) {
    const out = [];
    if (Math.abs(a) < 1e-12) { if (Math.abs(b) > 1e-12) out.push(-c / b); return out; }
    const disc = b * b - 4 * a * c;
    if (disc < 0) return out;
    const s = Math.sqrt(disc);
    out.push((-b + s) / (2 * a), (-b - s) / (2 * a));
    return out;
  }
  G.cubicExtrema = (p0, p1, p2, p3) => {
    const ts = [];
    for (const k of ['x', 'y']) {
      const a = 3 * (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]);
      const b = 6 * (p0[k] - 2 * p1[k] + p2[k]);
      const c = 3 * (p1[k] - p0[k]);
      for (const t of quadRoots(a, b, c)) if (t > 0 && t < 1) ts.push(t);
    }
    return ts;
  };

  // segments of a subpath: [{k, a, b, c:[p0,p1,p2,p3], line}]
  G.segs = sp => {
    const pts = sp.pts, n = pts.length, out = [];
    const count = sp.closed ? n : n - 1;
    for (let k = 0; k < count; k++) {
      const a = pts[k], b = pts[(k + 1) % n];
      out.push({ k, a, b, line: !a.o && !b.i, c: [a, a.o || a, b.i || b, b] });
    }
    return out;
  };

  G.pathBounds = (subs, m) => {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    const add = p => { if (p.x < x0) x0 = p.x; if (p.y < y0) y0 = p.y; if (p.x > x1) x1 = p.x; if (p.y > y1) y1 = p.y; };
    const T = m ? (p => M.apply(m, p)) : (p => p);
    for (const sp of subs || []) {
      if (!sp.pts.length) continue;
      add(T(sp.pts[0]));
      for (const s of G.segs(sp)) {
        const c = s.c.map(T);
        add(c[3]);
        if (!s.line) for (const t of G.cubicExtrema(c[0], c[1], c[2], c[3])) add(G.bez(c[0], c[1], c[2], c[3], t));
      }
    }
    if (x0 === Infinity) return null;
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  };

  G.toD = (subs, m) => {
    const T = m ? (p => M.apply(m, p)) : (p => p);
    const n = O.n;
    let d = '';
    for (const sp of subs || []) {
      const pts = sp.pts;
      if (!pts.length) continue;
      const p0 = T(pts[0]);
      d += 'M' + n(p0.x) + ' ' + n(p0.y);
      const segs = G.segs(sp);
      segs.forEach((s, idx) => {
        const isClosing = sp.closed && idx === segs.length - 1;
        if (s.line) {
          if (!isClosing) { const b = T(s.b); d += 'L' + n(b.x) + ' ' + n(b.y); }
        } else {
          const c1 = T(s.c[1]), c2 = T(s.c[2]), b = T(s.b);
          d += 'C' + n(c1.x) + ' ' + n(c1.y) + ' ' + n(c2.x) + ' ' + n(c2.y) + ' ' + n(b.x) + ' ' + n(b.y);
        }
      });
      if (sp.closed) d += 'Z';
    }
    return d;
  };

  G.transformSubs = (subs, m) => subs.map(sp => ({
    closed: sp.closed,
    pts: sp.pts.map(p => ({
      x: M.apply(m, p).x, y: M.apply(m, p).y,
      i: p.i ? M.apply(m, p.i) : null, o: p.o ? M.apply(m, p.o) : null, t: p.t
    }))
  }));

  G.reverseSub = sp => ({ closed: sp.closed, pts: sp.pts.slice().reverse().map(p => ({ x: p.x, y: p.y, i: p.o, o: p.i, t: p.t })) });

  // ---------- primitive shapes ----------
  G.rectSub = (w, h, r) => {
    let rad = Array.isArray(r) ? r.slice() : [r || 0, r || 0, r || 0, r || 0];
    const lim = Math.min(Math.abs(w), Math.abs(h)) / 2;
    rad = rad.map(v => O.clamp(v || 0, 0, lim));
    const [tl, tr, br, bl] = rad;
    if (!tl && !tr && !br && !bl) return [{ closed: true, pts: [G.pt(0, 0), G.pt(w, 0), G.pt(w, h), G.pt(0, h)] }];
    const pts = [];
    const corner = (r, a, b, ao, bi) => {
      if (r <= 1e-9) { pts.push(G.pt(a.x, a.y)); return; }
      pts.push(G.pt(a.x, a.y, null, ao));
      pts.push(G.pt(b.x, b.y, bi, null));
    };
    // walking clockwise starting at top-left corner arc end
    if (tl > 1e-9) pts.push(G.pt(tl, 0, { x: tl - tl * K, y: 0 }, null)); else pts.push(G.pt(0, 0));
    corner(tr, { x: w - tr, y: 0 }, { x: w, y: tr }, { x: w - tr + tr * K, y: 0 }, { x: w, y: tr - tr * K });
    corner(br, { x: w, y: h - br }, { x: w - br, y: h }, { x: w, y: h - br + br * K }, { x: w - br + br * K, y: h });
    corner(bl, { x: bl, y: h }, { x: 0, y: h - bl }, { x: bl - bl * K, y: h }, { x: 0, y: h - bl + bl * K });
    if (tl > 1e-9) pts.push(G.pt(0, tl, null, { x: 0, y: tl - tl * K }));
    return [{ closed: true, pts }];
  };
  G.ellipseSub = (w, h) => {
    const rx = w / 2, ry = h / 2, cx = rx, cy = ry;
    return [{
      closed: true, pts: [
        G.pt(cx, 0, { x: cx - K * rx, y: 0 }, { x: cx + K * rx, y: 0 }, 'sym'),
        G.pt(w, cy, { x: w, y: cy - K * ry }, { x: w, y: cy + K * ry }, 'sym'),
        G.pt(cx, h, { x: cx + K * rx, y: h }, { x: cx - K * rx, y: h }, 'sym'),
        G.pt(0, cy, { x: 0, y: cy + K * ry }, { x: 0, y: cy - K * ry }, 'sym')
      ]
    }];
  };
  function fitPts(raw, w, h) {
    const b = O.R.fromPts(raw);
    return raw.map(p => G.pt(b.w ? (p.x - b.x) / b.w * w : 0, b.h ? (p.y - b.y) / b.h * h : 0));
  }
  G.polySub = (w, h, sides) => {
    sides = Math.max(3, Math.round(sides || 3));
    const raw = [];
    for (let k = 0; k < sides; k++) { const a = -Math.PI / 2 + k * 2 * Math.PI / sides; raw.push({ x: Math.cos(a), y: Math.sin(a) }); }
    return [{ closed: true, pts: fitPts(raw, w, h) }];
  };
  G.starSub = (w, h, points, inner) => {
    points = Math.max(3, Math.round(points || 5));
    inner = O.clamp(inner === undefined ? 0.382 : inner, 0.01, 1);
    const raw = [];
    for (let k = 0; k < points * 2; k++) {
      const a = -Math.PI / 2 + k * Math.PI / points, r = k % 2 ? inner : 1;
      raw.push({ x: Math.cos(a) * r, y: Math.sin(a) * r });
    }
    return [{ closed: true, pts: fitPts(raw, w, h) }];
  };
  G.shapeSubs = n => {
    switch (n.type) {
      case 'rect': case 'frame': case 'instance': return G.rectSub(n.w, n.h, n.radius);
      case 'ellipse': return G.ellipseSub(n.w, n.h);
      case 'polygon': return G.polySub(n.w, n.h, n.sides);
      case 'star': return G.starSub(n.w, n.h, n.points, n.inner);
      case 'path': return n.subpaths;
      default: return null;
    }
  };

  // ---------- flattening / sampling ----------
  G.flattenSub = (sp, step) => {
    step = step || 1;
    const out = [];
    if (!sp.pts.length) return { closed: sp.closed, pts: out };
    out.push({ x: sp.pts[0].x, y: sp.pts[0].y });
    for (const s of G.segs(sp)) {
      if (s.line) { out.push({ x: s.b.x, y: s.b.y }); continue; }
      const c = s.c;
      const L = P.dist(c[0], c[1]) + P.dist(c[1], c[2]) + P.dist(c[2], c[3]);
      const n = O.clamp(Math.ceil(L / step), 2, 500);
      for (let i = 1; i <= n; i++) out.push(G.bez(c[0], c[1], c[2], c[3], i / n));
    }
    if (sp.closed && out.length > 1 && P.dist(out[0], out[out.length - 1]) < 1e-9) out.pop();
    return { closed: sp.closed, pts: out };
  };
  G.flatten = (subs, step) => (subs || []).map(sp => G.flattenSub(sp, step));
  G.polyLength = (pts, closed) => {
    let L = 0;
    for (let i = 1; i < pts.length; i++) L += P.dist(pts[i - 1], pts[i]);
    if (closed && pts.length > 1) L += P.dist(pts[pts.length - 1], pts[0]);
    return L;
  };
  // resample polyline into n points evenly spaced (closed or open)
  G.resample = (pts, closed, n) => {
    const seq = closed ? pts.concat([pts[0]]) : pts;
    const total = G.polyLength(seq, false);
    const out = [];
    if (total === 0 || seq.length < 2) { for (let i = 0; i < n; i++) out.push({ ...pts[0] }); return out; }
    const stepL = total / (closed ? n : n - 1);
    let seg = 0, segStart = 0, segLen = P.dist(seq[0], seq[1]);
    for (let i = 0; i < n; i++) {
      const target = Math.min(i * stepL, total);
      while (seg < seq.length - 2 && segStart + segLen < target) { segStart += segLen; seg++; segLen = P.dist(seq[seg], seq[seg + 1]); }
      const t = segLen ? (target - segStart) / segLen : 0;
      out.push(P.lerp(seq[seg], seq[seg + 1], O.clamp(t, 0, 1)));
    }
    return out;
  };
  // Ramer–Douglas–Peucker
  G.rdp = (pts, eps) => {
    if (pts.length < 3) return pts.slice();
    const keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1;
    const stack = [[0, pts.length - 1]];
    while (stack.length) {
      const [a, b] = stack.pop();
      let maxD = 0, idx = -1;
      const A = pts[a], B = pts[b], dx = B.x - A.x, dy = B.y - A.y, L = Math.hypot(dx, dy) || 1e-12;
      for (let i = a + 1; i < b; i++) {
        const d = Math.abs((pts[i].x - A.x) * dy - (pts[i].y - A.y) * dx) / L;
        if (d > maxD) { maxD = d; idx = i; }
      }
      if (maxD > eps && idx > 0) { keep[idx] = 1; stack.push([a, idx], [idx, b]); }
    }
    return pts.filter((_, i) => keep[i]);
  };
  G.polyToSub = (poly, closed = true) => ({ closed, pts: poly.map(p => G.pt(p.x, p.y)) });
  G.area = poly => { let a = 0; for (let i = 0, n = poly.length; i < n; i++) { const p = poly[i], q = poly[(i + 1) % n]; a += p.x * q.y - q.x * p.y; } return a / 2; };

  // ---------- nearest point / insertion / splitting ----------
  G.nearest = (subs, p) => {
    let best = null;
    (subs || []).forEach((sp, si) => {
      for (const s of G.segs(sp)) {
        const c = s.c;
        const f = t => G.bez(c[0], c[1], c[2], c[3], t);
        let bt = 0, bd = Infinity;
        const N = s.line ? 8 : 32;
        for (let i = 0; i <= N; i++) { const t = i / N, q = f(t), d = P.dist(q, p); if (d < bd) { bd = d; bt = t; } }
        let lo = Math.max(0, bt - 1 / N), hi = Math.min(1, bt + 1 / N);
        for (let it = 0; it < 30; it++) {
          const m1 = lo + (hi - lo) / 3, m2 = hi - (hi - lo) / 3;
          if (P.dist(f(m1), p) < P.dist(f(m2), p)) hi = m2; else lo = m1;
        }
        const t = (lo + hi) / 2, q = f(t), d = P.dist(q, p);
        if (!best || d < best.d) best = { si, k: s.k, t, x: q.x, y: q.y, d };
      }
    });
    return best;
  };
  // insert anchor in subpath at segment k, param t. returns index of new point
  G.insertAt = (sp, k, t) => {
    const n = sp.pts.length, a = sp.pts[k], b = sp.pts[(k + 1) % n];
    const line = !a.o && !b.i;
    let np;
    if (line) np = G.pt(O.lerp(a.x, b.x, t), O.lerp(a.y, b.y, t));
    else {
      const [L, Rr] = G.split(a, a.o || a, b.i || b, b, t);
      const same = (u, v) => P.dist(u, v) < 1e-9;
      a.o = same(L[1], a) ? null : { x: L[1].x, y: L[1].y };
      b.i = same(Rr[2], b) ? null : { x: Rr[2].x, y: Rr[2].y };
      np = G.pt(L[3].x, L[3].y, { x: L[2].x, y: L[2].y }, { x: Rr[1].x, y: Rr[1].y }, 'smooth');
    }
    sp.pts.splice(k + 1, 0, np);
    return k + 1;
  };
  // split subpaths at location -> returns array of resulting subpath lists (one or two pieces)
  G.cutAt = (sp, k, t) => {
    const s = { closed: sp.closed, pts: sp.pts.map(G.cp) };
    let j;
    if (t <= 1e-6) j = k; else if (t >= 1 - 1e-6) j = (k + 1) % s.pts.length; else j = G.insertAt(s, k, t);
    const pts = s.pts;
    if (s.closed) {
      const rot = pts.slice(j).concat(pts.slice(0, j));
      const first = G.cp(rot[0]), last = G.cp(rot[0]);
      first.i = null; last.o = null;
      return [{ closed: false, pts: [first].concat(rot.slice(1).map(G.cp), [last]) }];
    }
    if (j <= 0 || j >= pts.length - 1) return [s];
    const a = pts.slice(0, j + 1).map(G.cp), b = pts.slice(j).map(G.cp);
    a[a.length - 1].o = null; b[0].i = null;
    return [{ closed: false, pts: a }, { closed: false, pts: b }];
  };

  // ---------- SVG path data parser ----------
  function arcToCubics(x1, y1, rx, ry, phiDeg, fa, fs, x2, y2) {
    if (!rx || !ry) return [[{ x: x1, y: y1 }, { x: x2, y: y2 }, { x: x2, y: y2 }]];
    rx = Math.abs(rx); ry = Math.abs(ry);
    const phi = phiDeg * Math.PI / 180, sp = Math.sin(phi), cp = Math.cos(phi);
    const dx = (x1 - x2) / 2, dy = (y1 - y2) / 2;
    const x1p = cp * dx + sp * dy, y1p = -sp * dx + cp * dy;
    const lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry);
    if (lam > 1) { const s = Math.sqrt(lam); rx *= s; ry *= s; }
    const sign = fa === fs ? -1 : 1;
    const num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p;
    const den = rx * rx * y1p * y1p + ry * ry * x1p * x1p;
    const coef = den ? sign * Math.sqrt(Math.max(0, num / den)) : 0;
    const cxp = coef * rx * y1p / ry, cyp = -coef * ry * x1p / rx;
    const cx = cp * cxp - sp * cyp + (x1 + x2) / 2, cy = sp * cxp + cp * cyp + (y1 + y2) / 2;
    const ang = (ux, uy, vx, vy) => Math.atan2(ux * vy - uy * vx, ux * vx + uy * vy);
    const th1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry);
    let dth = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry);
    if (!fs && dth > 0) dth -= 2 * Math.PI;
    if (fs && dth < 0) dth += 2 * Math.PI;
    const segs = Math.max(1, Math.ceil(Math.abs(dth) / (Math.PI / 2) - 1e-9));
    const delta = dth / segs, k = 4 / 3 * Math.tan(delta / 4);
    const map = u => ({ x: cx + rx * u.x * cp - ry * u.y * sp, y: cy + rx * u.x * sp + ry * u.y * cp });
    const out = [];
    for (let i = 0; i < segs; i++) {
      const t1 = th1 + i * delta, t2 = t1 + delta;
      out.push([
        map({ x: Math.cos(t1) - k * Math.sin(t1), y: Math.sin(t1) + k * Math.cos(t1) }),
        map({ x: Math.cos(t2) + k * Math.sin(t2), y: Math.sin(t2) - k * Math.cos(t2) }),
        map({ x: Math.cos(t2), y: Math.sin(t2) })
      ]);
    }
    return out;
  }
  G.arcToCubics = arcToCubics;

  G.parseD = d => {
    const subs = [];
    let i = 0;
    const s = String(d || '');
    const isCmd = c => /[MmLlHhVvCcSsQqTtAaZz]/.test(c);
    const skip = () => { while (i < s.length && /[\s,]/.test(s[i])) i++; };
    const num = () => {
      skip();
      const m = /^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(s.slice(i, i + 40));
      if (!m) return null;
      i += m[0].length;
      return parseFloat(m[0]);
    };
    const flag = () => { skip(); const c = s[i]; if (c === '0' || c === '1') { i++; return c === '1'; } return null; };
    const hasNum = () => { skip(); return i < s.length && /[+\-.\d]/.test(s[i]); };
    let cur = null, cx = 0, cy = 0, sx = 0, sy = 0, lastC2 = null, lastQ = null, prevCmd = '';
    const start = (x, y) => { cur = { closed: false, pts: [G.pt(x, y)] }; subs.push(cur); sx = x; sy = y; };
    const ensure = () => { if (!cur) start(cx, cy); };
    const lineTo = (x, y) => { ensure(); cur.pts.push(G.pt(x, y)); };
    const curveTo = (c1, c2, p) => {
      ensure();
      const last = cur.pts[cur.pts.length - 1];
      if (P.dist(c1, last) > 1e-9) last.o = { x: c1.x, y: c1.y };
      cur.pts.push(G.pt(p.x, p.y, P.dist(c2, p) > 1e-9 ? { x: c2.x, y: c2.y } : null, null));
    };
    while (i < s.length) {
      skip();
      if (i >= s.length) break;
      let cmd = s[i];
      if (isCmd(cmd)) i++; else if (prevCmd && hasNum()) { cmd = prevCmd === 'M' ? 'L' : prevCmd === 'm' ? 'l' : prevCmd; } else { i++; continue; }
      const rel = cmd === cmd.toLowerCase();
      const C = cmd.toUpperCase();
      let first = true;
      do {
        if (C === 'Z') {
          if (cur) {
            cur.closed = true;
            const f = cur.pts[0], l = cur.pts[cur.pts.length - 1];
            if (cur.pts.length > 1 && P.dist(f, l) < 1e-6) { f.i = l.i; cur.pts.pop(); }
          }
          cx = sx; cy = sy; cur = null; lastC2 = lastQ = null;
          break;
        }
        if (C === 'M') {
          const x = num(), y = num(); if (x === null || y === null) break;
          const nx = rel ? cx + x : x, ny = rel ? cy + y : y;
          if (first) start(nx, ny); else lineTo(nx, ny);
          cx = nx; cy = ny; lastC2 = lastQ = null;
        } else if (C === 'L') {
          const x = num(), y = num(); if (x === null || y === null) break;
          cx = rel ? cx + x : x; cy = rel ? cy + y : y; lineTo(cx, cy); lastC2 = lastQ = null;
        } else if (C === 'H') {
          const x = num(); if (x === null) break; cx = rel ? cx + x : x; lineTo(cx, cy); lastC2 = lastQ = null;
        } else if (C === 'V') {
          const y = num(); if (y === null) break; cy = rel ? cy + y : y; lineTo(cx, cy); lastC2 = lastQ = null;
        } else if (C === 'C') {
          const v = [num(), num(), num(), num(), num(), num()]; if (v.includes(null)) break;
          const ox = rel ? cx : 0, oy = rel ? cy : 0;
          const c1 = { x: v[0] + ox, y: v[1] + oy }, c2 = { x: v[2] + ox, y: v[3] + oy }, p = { x: v[4] + ox, y: v[5] + oy };
          curveTo(c1, c2, p); cx = p.x; cy = p.y; lastC2 = c2; lastQ = null;
        } else if (C === 'S') {
          const v = [num(), num(), num(), num()]; if (v.includes(null)) break;
          const ox = rel ? cx : 0, oy = rel ? cy : 0;
          const c1 = lastC2 ? { x: 2 * cx - lastC2.x, y: 2 * cy - lastC2.y } : { x: cx, y: cy };
          const c2 = { x: v[0] + ox, y: v[1] + oy }, p = { x: v[2] + ox, y: v[3] + oy };
          curveTo(c1, c2, p); cx = p.x; cy = p.y; lastC2 = c2; lastQ = null;
        } else if (C === 'Q') {
          const v = [num(), num(), num(), num()]; if (v.includes(null)) break;
          const ox = rel ? cx : 0, oy = rel ? cy : 0;
          const q = { x: v[0] + ox, y: v[1] + oy }, p = { x: v[2] + ox, y: v[3] + oy };
          const c1 = { x: cx + 2 / 3 * (q.x - cx), y: cy + 2 / 3 * (q.y - cy) }, c2 = { x: p.x + 2 / 3 * (q.x - p.x), y: p.y + 2 / 3 * (q.y - p.y) };
          curveTo(c1, c2, p); cx = p.x; cy = p.y; lastQ = q; lastC2 = null;
        } else if (C === 'T') {
          const v = [num(), num()]; if (v.includes(null)) break;
          const p = { x: v[0] + (rel ? cx : 0), y: v[1] + (rel ? cy : 0) };
          const q = lastQ ? { x: 2 * cx - lastQ.x, y: 2 * cy - lastQ.y } : { x: cx, y: cy };
          const c1 = { x: cx + 2 / 3 * (q.x - cx), y: cy + 2 / 3 * (q.y - cy) }, c2 = { x: p.x + 2 / 3 * (q.x - p.x), y: p.y + 2 / 3 * (q.y - p.y) };
          curveTo(c1, c2, p); cx = p.x; cy = p.y; lastQ = q; lastC2 = null;
        } else if (C === 'A') {
          const rx = num(), ry = num(), rot = num(), fa = flag(), fs = flag(), x = num(), y = num();
          if ([rx, ry, rot, fa, fs, x, y].includes(null)) break;
          const p = { x: x + (rel ? cx : 0), y: y + (rel ? cy : 0) };
          for (const [c1, c2, q] of arcToCubics(cx, cy, rx, ry, rot, fa, fs, p.x, p.y)) curveTo(c1, c2, q);
          cx = p.x; cy = p.y; lastC2 = lastQ = null;
        }
        first = false;
      } while (hasNum());
      prevCmd = cmd;
    }
    // mark smooth points
    for (const sp of subs) for (const p of sp.pts) p.t = G.detectType(p);
    return subs.filter(sp => sp.pts.length);
  };
  G.detectType = p => {
    if (!p.i || !p.o) return 'corner';
    const a = P.sub(p.i, p), b = P.sub(p.o, p);
    const la = P.len(a), lb = P.len(b);
    if (la < 1e-9 || lb < 1e-9) return 'corner';
    const cross = (a.x * b.y - a.y * b.x) / (la * lb), dot = (a.x * b.x + a.y * b.y) / (la * lb);
    if (Math.abs(cross) < 0.02 && dot < 0) return Math.abs(la - lb) < 0.01 * Math.max(la, lb) ? 'sym' : 'smooth';
    return 'corner';
  };

  // ---------- paper.js bridge ----------
  let paperOk = false;
  G.paper = () => {
    if (paperOk) return window.paper;
    if (!window.paper) throw new Error(O.t('Бібліотека paper.js не завантажилась'));
    window.paper.setup(new window.paper.Size(1, 1));
    window.paper.settings.insertItems = false;
    paperOk = true;
    return window.paper;
  };
  G.toPaper = (subs, fillRule) => {
    const pp = G.paper();
    const zero = () => new pp.Point(0, 0);
    const paths = (subs || []).filter(sp => sp.pts.length).map(sp => {
      const path = new pp.Path({ insert: false });
      path.segments = sp.pts.map(p => new pp.Segment(new pp.Point(p.x, p.y),
        p.i ? new pp.Point(p.i.x - p.x, p.i.y - p.y) : zero(),
        p.o ? new pp.Point(p.o.x - p.x, p.o.y - p.y) : zero()));
      path.closed = !!sp.closed;
      return path;
    });
    let item;
    if (paths.length === 1) item = paths[0];
    else { item = new pp.CompoundPath({ insert: false }); item.addChildren(paths); }
    item.fillRule = fillRule || 'nonzero';
    return item;
  };
  G.fromPaper = item => {
    if (!item) return [];
    let paths = [];
    const collect = it => {
      if (!it) return;
      if (it.className === 'Path') paths.push(it);
      else if (it.children) it.children.forEach(collect);
    };
    collect(item);
    return paths.map(p => ({
      closed: p.closed,
      pts: p.segments.map(s => {
        const x = s.point.x, y = s.point.y;
        const pt = G.pt(x, y,
          s.handleIn.isZero() ? null : { x: x + s.handleIn.x, y: y + s.handleIn.y },
          s.handleOut.isZero() ? null : { x: x + s.handleOut.x, y: y + s.handleOut.y });
        pt.t = G.detectType(pt);
        return pt;
      })
    })).filter(sp => sp.pts.length > 1 || (sp.pts.length === 1 && !sp.closed));
  };
  G.isEmptyItem = it => {
    if (!it) return true;
    const subs = G.fromPaper(it);
    if (!subs.length) return true;
    const b = G.pathBounds(subs);
    if (!b || (b.w < 1e-3 && b.h < 1e-3)) return true;
    return Math.abs(it.area || 0) < 1e-3 && subs.every(s => s.closed);
  };
  G.boolPaper = (op, a, b) => {
    switch (op) {
      case 'union': return a.unite(b);
      case 'subtract': return a.subtract(b);
      case 'intersect': return a.intersect(b);
      case 'exclude': return a.exclude(b);
      case 'divide': return a.divide(b);
      default: return a;
    }
  };
  // split a compound result into separate connected parts (outer contours with their holes)
  G.splitParts = subs => {
    const closed = subs.filter(s => s.closed && s.pts.length > 2);
    if (closed.length <= 1) return closed.length ? [closed] : [];
    const pp = G.paper();
    const items = closed.map(sp => G.toPaper([sp]));
    const areas = items.map(it => Math.abs(it.area));
    const probe = items.map(it => { try { return it.interiorPoint || it.bounds.center; } catch (e) { return it.bounds.center; } });
    const depth = items.map((it, i) => items.reduce((acc, other, j) => acc + (i !== j && areas[j] > areas[i] && other.contains(probe[i]) ? 1 : 0), 0));
    const parts = [];
    const outerIdx = [];
    items.forEach((it, i) => { if (depth[i] % 2 === 0) { outerIdx.push(i); parts.push([closed[i]]); } });
    items.forEach((it, i) => {
      if (depth[i] % 2 === 1) {
        let best = -1, bestA = Infinity;
        outerIdx.forEach((oi, k) => { if (areas[oi] > areas[i] && areas[oi] < bestA && items[oi].contains(probe[i])) { best = k; bestA = areas[oi]; } });
        if (best >= 0) parts[best].push(closed[i]); else parts.push([closed[i]]);
      }
    });
    void pp;
    return parts;
  };
  G.simplify = (subs, tol) => {
    const out = [];
    for (const sp of subs) {
      const it = G.toPaper([sp]);
      if (it.segments && it.segments.length > 2) it.simplify(tol === undefined ? 2.5 : tol);
      out.push(...G.fromPaper(it));
    }
    return out;
  };
  G.smooth = subs => subs.map(sp => {
    const it = G.toPaper([sp]);
    it.smooth({ type: 'catmull-rom', factor: 0.5 });
    return G.fromPaper(it)[0] || sp;
  });

  // ---------- Clipper bridge (offsets & stroke outlines) ----------
  const SC = 100;
  const toCl = poly => poly.map(p => ({ X: Math.round(p.x * SC), Y: Math.round(p.y * SC) }));
  const fromCl = path => path.map(p => ({ x: p.X / SC, y: p.Y / SC }));
  G.clipperOffset = (closedPolys, openPolys, delta, opts = {}) => {
    const CL = window.ClipperLib;
    if (!CL) throw new Error(O.t('Бібліотека Clipper не завантажилась'));
    const jt = { miter: CL.JoinType.jtMiter, round: CL.JoinType.jtRound, bevel: CL.JoinType.jtSquare }[opts.join || 'miter'];
    const co = new CL.ClipperOffset(opts.miter || 4, 0.1 * SC);
    if (closedPolys.length) {
      let polys = closedPolys.map(toCl);
      if (opts.closedAsLine) polys.forEach(p => co.AddPath(p, jt, CL.EndType.etClosedLine));
      else {
        polys = CL.Clipper.SimplifyPolygons(polys, opts.evenOdd ? CL.PolyFillType.pftEvenOdd : CL.PolyFillType.pftNonZero);
        co.AddPaths(polys, jt, CL.EndType.etClosedPolygon);
      }
    }
    if (openPolys.length) {
      const et = { butt: CL.EndType.etOpenButt, round: CL.EndType.etOpenRound, square: CL.EndType.etOpenSquare }[opts.cap || 'butt'];
      openPolys.forEach(p => co.AddPath(toCl(p), jt, et));
    }
    const sol = new CL.Paths();
    co.Execute(sol, delta * SC);
    return sol.map(fromCl).filter(p => p.length > 2);
  };
  G.polysToSubs = (polys, eps) => polys.map(p => G.polyToSub(G.rdpClosed(p, eps === undefined ? 0.05 : eps), true)).filter(sp => sp.pts.length > 2);
  // RDP for a closed ring: split at the point farthest from the start so neither half is degenerate
  G.rdpClosed = (poly, eps) => {
    if (poly.length < 4) return poly;
    let k = 1, best = -1;
    for (let i = 1; i < poly.length; i++) { const d = P.dist(poly[0], poly[i]); if (d > best) { best = d; k = i; } }
    const a = G.rdp(poly.slice(0, k + 1), eps);
    const b = G.rdp(poly.slice(k).concat([poly[0]]), eps);
    return a.slice(0, -1).concat(b.slice(0, -1));
  };
  G.outlineStroke = (subs, width, cap, join, miter) => {
    const flat = G.flatten(subs, 0.5);
    const closed = flat.filter(f => f.closed && f.pts.length > 2).map(f => f.pts);
    const open = flat.filter(f => !f.closed && f.pts.length > 1).map(f => f.pts);
    const polys = G.clipperOffset(closed, open, width / 2, { join, cap, miter, closedAsLine: true });
    return G.polysToSubs(polys);
  };
  G.offsetPath = (subs, delta, join, miter, evenOdd) => {
    const flat = G.flatten(subs, 0.5);
    const closed = flat.filter(f => f.closed && f.pts.length > 2).map(f => f.pts);
    const open = flat.filter(f => !f.closed && f.pts.length > 1).map(f => f.pts);
    const polys = G.clipperOffset(closed, open, open.length && !closed.length ? Math.abs(delta) : delta, { join, miter, evenOdd, cap: 'butt' });
    return G.polysToSubs(polys);
  };
})();
