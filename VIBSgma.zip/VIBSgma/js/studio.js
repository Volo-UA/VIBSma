'use strict';
/* Obrys — music studio in the spirit of FL Studio.
   S.doc.studio = { bpm, swing, metro, mode ('pattern' | 'song'), pattern (current id),
     channels: [{ id, name, type: 'drum' | 'synth' | 'sample', drum, synth, sample, vol, pan, mute, solo, mixer }],
     patterns: [{ id, name, len (steps of 1/16), steps: { chId: [vel…] }, notes: { chId: [{ p, s, l, v }] } }],
     playlist: { tracks: [{ id, name, mute }], clips: [{ id, track, kind: 'pattern' | 'audio', ref, start, len }] },
     mixer: [{ id, name, vol, pan, mute, solo, fx: [{ type, on, … }] }] (0 = Master) }
   Channel rack (step sequencer), piano roll, playlist, mixer with effects, computer keyboard and MIDI input,
   offline WAV export, «use in video» and «project music». */
(function () {
  const O = window.O, S = O.state, ui = O.ui, io = O.io;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const ST = O.studio = {};
  const COLORS = ['#F24822', '#FFA629', '#FFCD29', '#14AE5C', '#0D99FF', '#9747FF', '#E05A9C', '#00B4D8', '#8F8F8F'];
  const NOTE = n => ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'][n % 12] + (Math.floor(n / 12) - 1);
  const DRUMS = [['kick', 'Kick'], ['snare', 'Snare'], ['clap', 'Clap'], ['hat', 'Hi-hat'], ['ohat', 'Open hat'], ['tom', 'Tom'], ['808', '808 Bass'], ['rim', 'Rim'], ['cowbell', 'Cowbell'], ['crash', 'Crash'], ['perc', 'Perc']];
  const SYNTHS = {
    'Saw Lead': { osc: [{ w: 'sawtooth', o: 0, d: -7, v: 0.5 }, { w: 'sawtooth', o: 0, d: 7, v: 0.5 }, { w: 'square', o: -1, d: 0, v: 0.25 }], a: 0.005, dc: 0.2, s: 0.7, r: 0.25, cut: 6000, res: 2, env: 2500 },
    'Square Bass': { osc: [{ w: 'square', o: -1, d: 0, v: 0.6 }, { w: 'sine', o: -2, d: 0, v: 0.5 }, { w: 'sawtooth', o: -1, d: 5, v: 0 }], a: 0.003, dc: 0.15, s: 0.6, r: 0.1, cut: 900, res: 4, env: 1800 },
    'Soft Pad': { osc: [{ w: 'sawtooth', o: 0, d: -12, v: 0.35 }, { w: 'sawtooth', o: 0, d: 12, v: 0.35 }, { w: 'triangle', o: 1, d: 0, v: 0.3 }], a: 0.6, dc: 0.8, s: 0.8, r: 1.2, cut: 2200, res: 1, env: 600 },
    'Pluck': { osc: [{ w: 'sawtooth', o: 0, d: 0, v: 0.6 }, { w: 'square', o: 1, d: 3, v: 0.2 }, { w: 'sine', o: 0, d: 0, v: 0 }], a: 0.002, dc: 0.18, s: 0, r: 0.15, cut: 1200, res: 6, env: 5000 },
    'Sub Bass': { osc: [{ w: 'sine', o: -1, d: 0, v: 0.9 }, { w: 'triangle', o: -1, d: 0, v: 0.2 }, { w: 'sine', o: 0, d: 0, v: 0 }], a: 0.005, dc: 0.3, s: 0.9, r: 0.15, cut: 400, res: 0.7, env: 200 },
    'Bell': { osc: [{ w: 'sine', o: 1, d: 0, v: 0.5 }, { w: 'sine', o: 2, d: 3, v: 0.3 }, { w: 'triangle', o: 3, d: -4, v: 0.15 }], a: 0.001, dc: 1.2, s: 0, r: 1, cut: 9000, res: 0.5, env: 0 },
    'Organ': { osc: [{ w: 'sine', o: 0, d: 0, v: 0.5 }, { w: 'sine', o: 1, d: 0, v: 0.35 }, { w: 'sine', o: 2, d: 0, v: 0.25 }], a: 0.01, dc: 0.1, s: 1, r: 0.08, cut: 8000, res: 0.5, env: 0 },
    'Supersaw': { osc: [{ w: 'sawtooth', o: 0, d: -18, v: 0.4 }, { w: 'sawtooth', o: 0, d: 18, v: 0.4 }, { w: 'sawtooth', o: 1, d: 0, v: 0.3 }], a: 0.01, dc: 0.4, s: 0.8, r: 0.5, cut: 7000, res: 1, env: 1500 }
  };
  const FX = {
    eq: { label: 'EQ 3-смуговий', p: { low: 0, mid: 0, high: 0 }, r: { low: [-24, 24], mid: [-24, 24], high: [-24, 24] } },
    comp: { label: 'Компресор', p: { thr: -24, ratio: 4, atk: 0.003, rel: 0.25, gain: 3 }, r: { thr: [-60, 0], ratio: [1, 20], atk: [0, 0.2], rel: [0.01, 1], gain: [0, 24] } },
    reverb: { label: 'Реверб', p: { size: 2.5, mix: 0.3 }, r: { size: [0.2, 8], mix: [0, 1] } },
    delay: { label: 'Дилей', p: { time: 0.375, fb: 0.35, mix: 0.25 }, r: { time: [0.02, 1.5], fb: [0, 0.9], mix: [0, 1] } },
    dist: { label: 'Дисторшн', p: { amt: 20, mix: 0.5 }, r: { amt: [0, 100], mix: [0, 1] } },
    filter: { label: 'Фільтр', p: { type: 'lowpass', freq: 2000, q: 1 }, r: { freq: [40, 18000], q: [0.1, 20] } },
    chorus: { label: 'Хорус', p: { rate: 1.2, depth: 0.004, mix: 0.4 }, r: { rate: [0.05, 8], depth: [0.0005, 0.01], mix: [0, 1] } },
    limiter: { label: 'Лімітер', p: { thr: -1 }, r: { thr: [-24, 0] } }
  };

  // ======================================================================
  // MODEL
  // ======================================================================
  const ch = (name, type, extra) => Object.assign({ id: O.uid(), name, type, vol: 0.8, pan: 0, mute: false, solo: false, mixer: 0, color: COLORS[Math.floor(Math.random() * COLORS.length)] }, extra);
  ST.newState = () => {
    const chans = [ch('Kick', 'drum', { drum: { kind: 'kick', pitch: 0, decay: 1, tone: 0.5 }, mixer: 1, color: COLORS[0] }), ch('Clap', 'drum', { drum: { kind: 'clap', pitch: 0, decay: 1, tone: 0.5 }, mixer: 2, color: COLORS[1] }), ch('Hi-hat', 'drum', { drum: { kind: 'hat', pitch: 0, decay: 1, tone: 0.5 }, mixer: 3, color: COLORS[2] }), ch('Snare', 'drum', { drum: { kind: 'snare', pitch: 0, decay: 1, tone: 0.5 }, mixer: 4, color: COLORS[3] }), ch('Saw Lead', 'synth', { synth: O.clone(SYNTHS['Saw Lead']), mixer: 5, color: COLORS[4] })];
    const steps = {};
    steps[chans[0].id] = [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0];
    steps[chans[1].id] = [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0];
    steps[chans[2].id] = [0, 0, 0.7, 0, 0, 0, 0.7, 0, 0, 0, 0.7, 0, 0, 0, 0.7, 0];
    const p1 = { id: O.uid(), name: t('Патерн {n}', { n: 1 }), len: 16, steps, notes: {} };
    p1.notes[chans[4].id] = [{ p: 60, s: 0, l: 2, v: 0.8 }, { p: 63, s: 4, l: 2, v: 0.8 }, { p: 67, s: 8, l: 2, v: 0.8 }, { p: 70, s: 12, l: 3, v: 0.8 }];
    const mixer = [{ id: 'm0', name: 'Master', vol: 0.85, pan: 0, mute: false, solo: false, fx: [{ type: 'limiter', on: true, thr: -1 }] }];
    for (let i = 1; i <= 8; i++) mixer.push({ id: 'm' + i, name: t('Інсерт {n}', { n: i }), vol: 0.8, pan: 0, mute: false, solo: false, fx: [] });
    const tracks = Array.from({ length: 8 }, (_, i) => ({ id: O.uid(), name: t('Доріжка {n}', { n: i + 1 }), mute: false }));
    return { bpm: 128, swing: 0, metro: false, mode: 'pattern', pattern: p1.id, channels: chans, patterns: [p1], playlist: { tracks, clips: [{ id: O.uid(), track: tracks[0].id, kind: 'pattern', ref: p1.id, start: 0, len: 16 }, { id: O.uid(), track: tracks[0].id, kind: 'pattern', ref: p1.id, start: 16, len: 16 }] }, mixer };
  };
  ST.doc = () => (S.doc.studio || (S.doc.studio = ST.newState()));
  const D = () => ST.doc();
  const pat = id => D().patterns.find(p => p.id === (id || D().pattern)) || D().patterns[0];
  const chan = id => D().channels.find(c => c.id === id);
  const stepDur = () => 60 / D().bpm / 4;
  let selCh = null;
  const commit = O.debounce ? (label => { O.history.commit(label); }) : (label => O.history.commit(label));

  // ======================================================================
  // SOUND
  // ======================================================================
  const noiseBuf = new WeakMap();
  const noise = ctx => { let b = noiseBuf.get(ctx); if (!b) { b = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate); const d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; noiseBuf.set(ctx, b); } return b; };
  const env = (g, time, peak, dur, attack = 0.001) => { g.gain.setValueAtTime(0.0001, time); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), time + attack); g.gain.exponentialRampToValueAtTime(0.0001, time + attack + dur); };
  const noiseSrc = (ctx, time, dur) => { const s = ctx.createBufferSource(); s.buffer = noise(ctx); s.start(time, Math.random()); s.stop(time + dur + 0.05); return s; };
  const drum = (ctx, out, time, vel, P, note) => {
    const k = P.kind, dec = P.decay || 1, pt = Math.pow(2, (P.pitch || 0) / 12), tone = P.tone === undefined ? 0.5 : P.tone;
    const g = ctx.createGain(); g.connect(out);
    const osc = (type, f0, f1, dur) => { const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(f0, time); if (f1) o.frequency.exponentialRampToValueAtTime(f1, time + dur); o.start(time); o.stop(time + dur + 0.05); return o; };
    if (k === 'kick') { const o = osc('sine', 160 * pt, 42 * pt, 0.12); env(g, time, vel, 0.45 * dec); o.connect(g); const c = ctx.createGain(); env(c, time, vel * 0.4 * tone, 0.015); const n = noiseSrc(ctx, time, 0.02); n.connect(c); c.connect(out); }
    else if (k === 'snare') { const o = osc('triangle', 190 * pt, 120 * pt, 0.1); const og = ctx.createGain(); env(og, time, vel * 0.7, 0.12 * dec); o.connect(og); og.connect(out); const n = noiseSrc(ctx, time, 0.3 * dec); const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 800 + tone * 1500; n.connect(hp); hp.connect(g); env(g, time, vel * 0.8, 0.2 * dec); }
    else if (k === 'hat' || k === 'ohat') { const n = noiseSrc(ctx, time, 0.6); const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = (6000 + tone * 3000) * pt; const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 10000 * pt; bp.Q.value = 0.7; n.connect(hp); hp.connect(bp); bp.connect(g); env(g, time, vel * 0.5, (k === 'hat' ? 0.05 : 0.35) * dec); }
    else if (k === 'clap') { const n = noiseSrc(ctx, time, 0.5); const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1200 + tone * 800; bp.Q.value = 0.9; n.connect(bp); bp.connect(g); g.gain.setValueAtTime(0.0001, time); [0, 0.011, 0.022].forEach(d => { g.gain.setValueAtTime(vel * 0.9, time + d); g.gain.exponentialRampToValueAtTime(vel * 0.15, time + d + 0.009); }); g.gain.setValueAtTime(vel * 0.6, time + 0.033); g.gain.exponentialRampToValueAtTime(0.0001, time + 0.033 + 0.22 * dec); }
    else if (k === 'tom') { const o = osc('sine', 220 * pt, 110 * pt, 0.25); o.connect(g); env(g, time, vel * 0.9, 0.35 * dec); }
    else if (k === '808') { const f = 440 * Math.pow(2, ((note || 36) - 69) / 12) * pt; const o = osc('sine', f * 1.6, f, 0.06); const ws = ctx.createWaveShaper(); ws.curve = curveDist(8 + tone * 30); o.connect(ws); ws.connect(g); env(g, time, vel * 0.9, 1.1 * dec, 0.003); }
    else if (k === 'rim') { const o = osc('square', 1700 * pt, 0, 0.03); const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1700 * pt; bp.Q.value = 4; o.connect(bp); bp.connect(g); env(g, time, vel * 0.6, 0.03 * dec); }
    else if (k === 'cowbell') { const a = osc('square', 545 * pt, 0, 0.4), b = osc('square', 815 * pt, 0, 0.4); const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 2640; bp.Q.value = 1.2; a.connect(bp); b.connect(bp); bp.connect(g); env(g, time, vel * 0.5, 0.3 * dec); }
    else if (k === 'crash') { const n = noiseSrc(ctx, time, 2); const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 4000 + tone * 3000; n.connect(hp); hp.connect(g); env(g, time, vel * 0.45, 1.6 * dec); }
    else { const o = osc('triangle', 600 * pt, 300 * pt, 0.08); o.connect(g); env(g, time, vel * 0.7, 0.08 * dec); }
  };
  const curveDist = amt => { const n = 2048, c = new Float32Array(n), k = amt; for (let i = 0; i < n; i++) { const x = i * 2 / n - 1; c[i] = (3 + k) * x * 20 * Math.PI / 180 / (Math.PI + k * Math.abs(x)); } return c; };
  const synth = (ctx, out, time, vel, P, note, dur) => {
    const f = 440 * Math.pow(2, (note - 69) / 12);
    const g = ctx.createGain(), flt = ctx.createBiquadFilter();
    flt.type = 'lowpass'; flt.Q.value = P.res || 1;
    const cut = Math.max(40, P.cut || 5000);
    flt.frequency.setValueAtTime(cut, time);
    if (P.env) { flt.frequency.linearRampToValueAtTime(Math.min(18000, cut + P.env), time + Math.max(0.003, P.a)); flt.frequency.linearRampToValueAtTime(cut, time + P.a + P.dc); }
    flt.connect(g); g.connect(out);
    const peak = vel * 0.35, sus = Math.max(0.0001, peak * P.s), end = time + Math.max(0.01, dur);
    g.gain.setValueAtTime(0.0001, time);
    g.gain.linearRampToValueAtTime(peak, time + Math.max(0.002, P.a));
    g.gain.linearRampToValueAtTime(sus, time + P.a + P.dc);
    g.gain.setValueAtTime(sus, end);
    g.gain.exponentialRampToValueAtTime(0.0001, end + Math.max(0.02, P.r));
    for (const o of P.osc) {
      if (!o.v) continue;
      const os = ctx.createOscillator(), og = ctx.createGain();
      os.type = o.w; os.frequency.value = f * Math.pow(2, o.o); os.detune.value = o.d;
      og.gain.value = o.v;
      os.connect(og); og.connect(flt);
      os.start(time); os.stop(end + P.r + 0.1);
    }
  };
  const buffers = new Map();
  ST.bufferOf = async (ctx, assetId) => {
    if (buffers.has(assetId)) return buffers.get(assetId);
    const p = (async () => { const ab = await (await fetch(O.assetURL(assetId))).arrayBuffer(); return (ctx.decodeAudioData.length > 1 ? new Promise((res, rej) => ctx.decodeAudioData(ab, res, rej)) : ctx.decodeAudioData(ab)); })();
    buffers.set(assetId, p);
    return p;
  };
  const sample = (ctx, out, time, vel, P, note, dur, buf) => {
    if (!buf) return;
    const s = ctx.createBufferSource(); s.buffer = buf;
    s.playbackRate.value = Math.pow(2, ((note || 60) - (P.root || 60)) / 12);
    const g = ctx.createGain(); g.gain.value = vel; s.connect(g); g.connect(out);
    s.start(time, P.start || 0);
    if (P.cut && dur) { g.gain.setValueAtTime(vel, time + dur); g.gain.linearRampToValueAtTime(0, time + dur + 0.05); s.stop(time + dur + 0.06); }
  };

  // ---------- effects and mixer graph ----------
  const impulse = (ctx, secs) => { const len = Math.max(1, Math.floor(ctx.sampleRate * secs)), b = ctx.createBuffer(2, len, ctx.sampleRate); for (let c = 0; c < 2; c++) { const d = b.getChannelData(c); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.5); } return b; };
  const makeFx = (ctx, f) => {
    const input = ctx.createGain(), output = ctx.createGain();
    if (!f.on) { input.connect(output); return { input, output }; }
    const wetdry = (node, mix) => { const dry = ctx.createGain(), wet = ctx.createGain(); dry.gain.value = 1 - mix; wet.gain.value = mix; input.connect(dry); dry.connect(output); input.connect(node.input || node); (node.output || node).connect(wet); wet.connect(output); };
    switch (f.type) {
      case 'eq': { const l = ctx.createBiquadFilter(), m = ctx.createBiquadFilter(), h = ctx.createBiquadFilter(); l.type = 'lowshelf'; l.frequency.value = 200; l.gain.value = f.low; m.type = 'peaking'; m.frequency.value = 1000; m.Q.value = 0.8; m.gain.value = f.mid; h.type = 'highshelf'; h.frequency.value = 5000; h.gain.value = f.high; input.connect(l); l.connect(m); m.connect(h); h.connect(output); break; }
      case 'comp': { const c = ctx.createDynamicsCompressor(); c.threshold.value = f.thr; c.ratio.value = f.ratio; c.attack.value = f.atk; c.release.value = f.rel; const mk = ctx.createGain(); mk.gain.value = Math.pow(10, f.gain / 20); input.connect(c); c.connect(mk); mk.connect(output); break; }
      case 'limiter': { const c = ctx.createDynamicsCompressor(); c.threshold.value = f.thr; c.ratio.value = 20; c.attack.value = 0.001; c.release.value = 0.05; c.knee.value = 0; input.connect(c); c.connect(output); break; }
      case 'reverb': { const cv = ctx.createConvolver(); cv.buffer = impulse(ctx, f.size); wetdry(cv, f.mix); break; }
      case 'delay': { const d = ctx.createDelay(2); d.delayTime.value = f.time; const fb = ctx.createGain(); fb.gain.value = f.fb; d.connect(fb); fb.connect(d); wetdry(d, f.mix); break; }
      case 'dist': { const ws = ctx.createWaveShaper(); ws.curve = curveDist(f.amt); ws.oversample = '4x'; wetdry(ws, f.mix); break; }
      case 'filter': { const b = ctx.createBiquadFilter(); b.type = f.type2 || f.ftype || 'lowpass'; b.frequency.value = f.freq; b.Q.value = f.q; input.connect(b); b.connect(output); break; }
      case 'chorus': { const d = ctx.createDelay(0.05); d.delayTime.value = 0.015; const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = f.rate; lg.gain.value = f.depth; lfo.connect(lg); lg.connect(d.delayTime); lfo.start(); wetdry(d, f.mix); break; }
      default: input.connect(output);
    }
    return { input, output };
  };
  // the whole mixer for a context (live or offline)
  const buildGraph = (ctx, st) => {
    const anyStripSolo = st.mixer.some((m, i) => i && m.solo);
    const strips = st.mixer.map((m, i) => {
      const input = ctx.createGain();
      let node = input;
      for (const f of m.fx || []) { const x = makeFx(ctx, f); node.connect(x.input); node = x.output; }
      const pan = ctx.createStereoPanner(); pan.pan.value = m.pan || 0;
      const vol = ctx.createGain(); vol.gain.value = m.mute || (i && anyStripSolo && !m.solo) ? 0 : m.vol;
      const an = ctx.createAnalyser(); an.fftSize = 256;
      node.connect(pan); pan.connect(vol); vol.connect(an);
      return { input, vol, an };
    });
    strips.forEach((s, i) => { if (i) s.an.connect(strips[0].input); });
    strips[0].an.connect(ctx.destination);
    const anySolo = st.channels.some(c => c.solo);
    const chans = new Map();
    for (const c of st.channels) {
      const g = ctx.createGain(); g.gain.value = c.mute || (anySolo && !c.solo) ? 0 : c.vol;
      const p = ctx.createStereoPanner(); p.pan.value = c.pan || 0;
      g.connect(p); p.connect((strips[c.mixer] || strips[0]).input);
      chans.set(c.id, g);
    }
    return { strips, chans };
  };
  const trigger = (ctx, graph, c, time, vel, note, dur, bufs) => {
    const out = graph.chans.get(c.id);
    if (!out) return;
    if (c.type === 'drum') drum(ctx, out, time, vel, c.drum, note);
    else if (c.type === 'synth') synth(ctx, out, time, vel, c.synth, note || 60, dur || stepDur() * 2);
    else if (c.type === 'sample') sample(ctx, out, time, vel, c.sample, note || (c.sample.root || 60), dur, bufs && bufs.get(c.sample.asset));
  };
  // all note events of a pattern step (0 … len-1)
  const eventsAt = (p, step) => {
    const ev = [];
    for (const [cid, arr] of Object.entries(p.steps || {})) { const v = arr[step]; if (v) ev.push({ cid, vel: v, note: null, len: 1 }); }
    for (const [cid, list] of Object.entries(p.notes || {})) for (const n of list) if (n.s === step) ev.push({ cid, vel: n.v, note: n.p, len: n.l });
    return ev;
  };
  ST.songLen = () => D().playlist.clips.reduce((m, c) => Math.max(m, c.start + c.len), 0) || 16;

  // ---------- live engine ----------
  let ac = null, graph = null, bufs = new Map(), timer = 0, playing = false, step = 0, nextTime = 0, startTime = 0, startStep = 0, audioSrcs = [];
  const ensure = () => {
    if (!ac) ac = new (window.AudioContext || window.webkitAudioContext)();
    if (ac.state === 'suspended') ac.resume().catch(() => {});
    if (!graph) graph = buildGraph(ac, D());
    return ac;
  };
  ST.rebuild = O.debounce(() => { if (!ac) return; const old = graph; graph = buildGraph(ac, D()); if (old) setTimeout(() => old.strips.forEach(s => { try { s.an.disconnect(); } catch (e) { /* ignore */ } }), 1500); }, 60);
  const loadBuffers = async ctx => {
    const ids = new Set(D().channels.filter(c => c.type === 'sample' && c.sample && c.sample.asset).map(c => c.sample.asset).concat(D().playlist.clips.filter(c => c.kind === 'audio').map(c => c.ref)));
    for (const id of ids) { if (!bufs.has(id)) { try { bufs.set(id, await ST.bufferOf(ctx, id)); } catch (e) { console.warn(e); } } }
  };
  const swingOffset = s => (s % 2 ? D().swing / 100 * stepDur() * 0.5 : 0);
  const scheduleStep = (s, time) => {
    const st = D();
    if (st.metro && s % 4 === 0) { const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = s % 16 === 0 ? 1600 : 1000; o.connect(g); g.connect(ac.destination); env(g, time, 0.3, 0.04); o.start(time); o.stop(time + 0.06); }
    const tt = time + swingOffset(s);
    if (st.mode === 'pattern') {
      const p = pat();
      for (const e of eventsAt(p, s % p.len)) { const c = chan(e.cid); if (c) trigger(ac, graph, c, tt, e.vel, e.note, e.len * stepDur(), bufs); }
    } else {
      const muted = new Set(st.playlist.tracks.filter(x => x.mute).map(x => x.id));
      for (const cl of st.playlist.clips) {
        if (muted.has(cl.track) || s < cl.start || s >= cl.start + cl.len) continue;
        if (cl.kind === 'pattern') { const p = pat(cl.ref); if (!p) continue; for (const e of eventsAt(p, (s - cl.start) % p.len)) { const c = chan(e.cid); if (c) trigger(ac, graph, c, tt, e.vel, e.note, e.len * stepDur(), bufs); } }
        else if (cl.kind === 'audio' && s === cl.start) { const b = bufs.get(cl.ref); if (b) { const src = ac.createBufferSource(); src.buffer = b; src.connect(graph.strips[0].input); src.start(time, 0, cl.len * stepDur()); audioSrcs.push(src); } }
      }
    }
  };
  const tick = () => {
    while (nextTime < ac.currentTime + 0.12) {
      const st = D();
      const end = st.mode === 'pattern' ? pat().len : ST.songLen();
      if (step >= end) { step = 0; }
      scheduleStep(step, nextTime);
      step++; nextTime += stepDur();
    }
  };
  ST.play = async () => {
    if (playing) return;
    ensure();
    await loadBuffers(ac);
    graph = buildGraph(ac, D());
    playing = true; step = startStep = ST.pos || 0; nextTime = startTime = ac.currentTime + 0.06;
    // audio clips that started before the playhead
    if (D().mode === 'song') for (const cl of D().playlist.clips) if (cl.kind === 'audio' && cl.start < step && cl.start + cl.len > step) { const b = bufs.get(cl.ref); if (b) { const src = ac.createBufferSource(); src.buffer = b; src.connect(graph.strips[0].input); src.start(nextTime, (step - cl.start) * stepDur(), (cl.start + cl.len - step) * stepDur()); audioSrcs.push(src); } }
    tick();
    timer = setInterval(tick, 25);
    anim();
    renderTransport();
  };
  ST.stop = () => {
    playing = false; clearInterval(timer);
    audioSrcs.forEach(s => { try { s.stop(); } catch (e) { /* ignore */ } }); audioSrcs = [];
    if (graph) { graph.strips.forEach(s => { try { s.vol.gain.setTargetAtTime(0, ac.currentTime, 0.01); } catch (e) { /* ignore */ } }); graph = null; }
    ST.pos = 0;
    renderTransport(); drawPlayheads();
  };
  ST.curStep = () => { if (!playing || !ac) return ST.pos || 0; const st = D(); const end = st.mode === 'pattern' ? pat().len : ST.songLen(); return ((startStep + Math.max(0, (ac.currentTime - startTime) / stepDur())) % end); };
  // preview one note of a channel (piano roll clicks, keyboard, MIDI)
  ST.preview = (c, note, vel = 0.8) => {
    ensure();
    if (!graph) graph = buildGraph(ac, D());
    const go = () => trigger(ac, graph, c, ac.currentTime + 0.01, vel, note, stepDur() * 2, bufs);
    if (c.type === 'sample' && c.sample && c.sample.asset && !bufs.has(c.sample.asset)) ST.bufferOf(ac, c.sample.asset).then(b => { bufs.set(c.sample.asset, b); go(); }); else go();
  };

  // ---------- offline render → WAV ----------
  ST.render = async (opts = {}) => {
    const st = D();
    const sr = 44100;
    const steps = st.mode === 'pattern' ? pat().len * (opts.loops || 4) : ST.songLen();
    const secs = steps * stepDur() + (opts.tail === undefined ? 2 : opts.tail);
    const ctx = new OfflineAudioContext(2, Math.ceil(sr * secs), sr);
    const g = buildGraph(ctx, st);
    const b2 = new Map();
    for (const id of new Set(st.channels.filter(c => c.type === 'sample' && c.sample && c.sample.asset).map(c => c.sample.asset).concat(st.playlist.clips.filter(c => c.kind === 'audio').map(c => c.ref)))) { try { b2.set(id, await ST.bufferOf(ensure(), id)); } catch (e) { /* skip */ } }
    for (let s = 0; s < steps; s++) {
      const time = s * stepDur(), tt = time + swingOffset(s);
      if (st.mode === 'pattern') { const p = pat(); for (const e of eventsAt(p, s % p.len)) { const c = chan(e.cid); if (c) trigger(ctx, g, c, tt, e.vel, e.note, e.len * stepDur(), b2); } }
      else {
        const muted = new Set(st.playlist.tracks.filter(x => x.mute).map(x => x.id));
        for (const cl of st.playlist.clips) {
          if (muted.has(cl.track) || s < cl.start || s >= cl.start + cl.len) continue;
          if (cl.kind === 'pattern') { const p = pat(cl.ref); if (p) for (const e of eventsAt(p, (s - cl.start) % p.len)) { const c = chan(e.cid); if (c) trigger(ctx, g, c, tt, e.vel, e.note, e.len * stepDur(), b2); } }
          else if (s === cl.start) { const b = b2.get(cl.ref); if (b) { const src = ctx.createBufferSource(); src.buffer = b; src.connect(g.strips[0].input); src.start(time, 0, cl.len * stepDur()); } }
        }
      }
    }
    return ctx.startRendering();
  };
  ST.wav = buf => {
    const n = buf.length, chs = buf.numberOfChannels, sr = buf.sampleRate;
    const out = new DataView(new ArrayBuffer(44 + n * chs * 2));
    const w = (o, s) => [...s].forEach((c, i) => out.setUint8(o + i, c.charCodeAt(0)));
    w(0, 'RIFF'); out.setUint32(4, 36 + n * chs * 2, true); w(8, 'WAVE'); w(12, 'fmt '); out.setUint32(16, 16, true); out.setUint16(20, 1, true); out.setUint16(22, chs, true); out.setUint32(24, sr, true); out.setUint32(28, sr * chs * 2, true); out.setUint16(32, chs * 2, true); out.setUint16(34, 16, true); w(36, 'data'); out.setUint32(40, n * chs * 2, true);
    const data = Array.from({ length: chs }, (_, c) => buf.getChannelData(c));
    let o = 44;
    for (let i = 0; i < n; i++) for (let c = 0; c < chs; c++) { const v = Math.max(-1, Math.min(1, data[c][i])); out.setInt16(o, v < 0 ? v * 0x8000 : v * 0x7fff, true); o += 2; }
    return new Blob([out.buffer], { type: 'audio/wav' });
  };
  const renderToAsset = async () => {
    O.toast('Рендер музики…');
    const buf = await ST.render();
    const blob = ST.wav(buf);
    const id = O.uid();
    S.doc.assets[id] = { data: await io.blobToData(blob), kind: 'audio', name: t('Трек студії') + ' ' + D().bpm + ' BPM', duration: buf.duration, size: blob.size };
    return { id, blob, duration: buf.duration };
  };

  // ======================================================================
  // UI
  // ======================================================================
  let root = null, tab = 'rack', raf = 0, cell = 22, prState = { snap: 1, len: 2, scaleRoot: 0, scale: 'none', chord: 'none', top: 84, rec: false };
  const SCALES = { none: null, major: [0, 2, 4, 5, 7, 9, 11], minor: [0, 2, 3, 5, 7, 8, 10], penta: [0, 2, 4, 7, 9], minpenta: [0, 3, 5, 7, 10], blues: [0, 3, 5, 6, 7, 10] };
  const CHORDS = { none: [0], maj: [0, 4, 7], min: [0, 3, 7], dom7: [0, 4, 7, 10], maj7: [0, 4, 7, 11], min7: [0, 3, 7, 10], sus4: [0, 5, 7], power: [0, 7, 12] };
  const anim = () => { cancelAnimationFrame(raf); const f = () => { drawPlayheads(); drawMeters(); if (playing || root) raf = requestAnimationFrame(f); }; raf = requestAnimationFrame(f); };
  const renderTransport = () => {
    if (!root) return;
    const st = D();
    root.querySelector('[data-st="play"]').textContent = playing ? '■' : '▶';
    root.querySelector('[data-st="play"]').classList.toggle('on', playing);
    root.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('on', b.dataset.mode === st.mode));
    root.querySelector('[data-st="bpm"]').value = st.bpm;
    root.querySelector('[data-st="swing"]').value = st.swing;
    root.querySelector('[data-st="metro"]').classList.toggle('on', !!st.metro);
    const ps = root.querySelector('[data-st="pattern"]');
    ps.innerHTML = st.patterns.map(p => `<option value="${p.id}"${p.id === st.pattern ? ' selected' : ''}>${esc(p.name)}</option>`).join('');
  };
  const renderBrowser = () => {
    const el = root.querySelector('.st-browser');
    const auds = Object.entries(S.doc.assets || {}).filter(([, a]) => a && (a.kind === 'audio' || /^data:audio\//.test(a.data || '')));
    el.innerHTML = `<h5>${esc(t('Ударні'))}</h5>${DRUMS.map(([k, l]) => `<button type="button" data-addd="${k}">🥁 ${esc(l)}</button>`).join('')}
      <h5>${esc(t('Синтезатори'))}</h5>${Object.keys(SYNTHS).map(k => `<button type="button" data-adds="${esc(k)}">🎹 ${esc(k)}</button>`).join('')}
      <h5>${esc(t('Семпли й аудіо'))}</h5><button type="button" data-st="importsample" class="st-imp">${esc(t('Імпорт семплу…'))}</button>${auds.map(([id, a]) => `<div class="st-smp"><span title="${esc(a.name || '')}">♪ ${esc(a.name || id)}</span><button type="button" data-addsmp="${id}" title="${esc(t('Новий канал із семплом'))}">+${esc(t('Канал'))}</button><button type="button" data-addaud="${id}" title="${esc(t('Додати в плейлист'))}">+${esc(t('Плейлист'))}</button></div>`).join('')}`;
  };
  // ---------- channel rack ----------
  const renderRack = () => {
    const st = D(), p = pat();
    const el = root.querySelector('.st-pane');
    el.innerHTML = `<div class="st-rack-top"><span>${esc(t('Кроків'))}</span>${[16, 32, 64].map(n => `<button type="button" data-len="${n}" class="${p.len === n ? 'on' : ''}">${n}</button>`).join('')}<span class="sp"></span><span class="st-hint">${esc(t('Клік — крок, Shift+клік — сила удару, правий клік — стерти. Подвійний клік по назві — піаноролл.'))}</span></div>
      <div class="st-rack">${st.channels.map(c => {
        const arr = (p.steps[c.id] || []);
        const hasNotes = (p.notes[c.id] || []).length;
        return `<div class="st-row${c.id === selCh ? ' sel' : ''}" data-ch="${c.id}"><button type="button" class="st-led${c.mute ? '' : ' on'}" data-cha="mute" title="${esc(t('Увімкнути / вимкнути'))}"></button><button type="button" class="st-solo${c.solo ? ' on' : ''}" data-cha="solo" title="Solo">S</button>
          <input type="range" min="0" max="1" step="0.01" value="${c.vol}" data-chp="vol" title="${esc(t('Гучність'))}"><input type="range" min="-1" max="1" step="0.01" value="${c.pan}" data-chp="pan" title="${esc(t('Панорама'))}" class="st-pan">
          <select data-chp="mixer" title="${esc(t('Інсерт мікшера'))}">${st.mixer.map((m, i) => `<option value="${i}"${c.mixer === i ? ' selected' : ''}>${i ? i : 'M'}</option>`).join('')}</select>
          <button type="button" class="st-name" data-cha="sel" style="--c:${c.color}">${esc(c.name)}</button>
          <div class="st-steps${hasNotes ? ' pr' : ''}">${hasNotes ? `<button type="button" class="st-prmini" data-cha="pr">${esc(t('Піаноролл: {n} нот', { n: hasNotes }))}</button>` : Array.from({ length: p.len }, (_, i) => `<button type="button" class="st-step${arr[i] ? ' on' : ''}${Math.floor(i / 4) % 2 ? ' alt' : ''}" data-step="${i}" style="${arr[i] ? `--v:${arr[i]};` : ''}"></button>`).join('')}</div></div>`;
      }).join('')}</div>
      <div class="st-add"><button type="button" class="btn" data-addd="kick">+ ${esc(t('Канал'))}</button></div><div class="st-params"></div>`;
    renderParams();
  };
  const knob = (path, label, val, mn, mx, st = 0.01) => `<label class="st-k"><span>${esc(t(label))}</span><input type="range" min="${mn}" max="${mx}" step="${st}" value="${val}" data-par="${path}"><em>${O.fmt(+val, 2)}</em></label>`;
  const renderParams = () => {
    const el = root.querySelector('.st-params');
    if (!el) return;
    const c = chan(selCh);
    if (!c) { el.innerHTML = `<div class="st-hint">${esc(t('Виділіть канал, щоб налаштувати звук.'))}</div>`; return; }
    let h = `<div class="st-ph"><input type="text" value="${esc(c.name)}" data-chp="name" aria-label="${esc(t('Назва'))}"><input type="color" value="${c.color}" data-chp="color"><button type="button" class="btn" data-cha="pr">🎹 ${esc(t('Піаноролл'))}</button><button type="button" class="btn" data-cha="dup">${esc(t('Дублювати'))}</button><button type="button" class="btn" data-cha="del">${esc(t('Видалити канал'))}</button></div>`;
    if (c.type === 'drum') h += `<div class="st-kn"><label class="st-k"><span>${esc(t('Звук'))}</span><select data-par="drum.kind">${DRUMS.map(([k, l]) => `<option value="${k}"${c.drum.kind === k ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></label>${knob('drum.pitch', 'Висота', c.drum.pitch, -24, 24, 1)}${knob('drum.decay', 'Згасання', c.drum.decay, 0.2, 3)}${knob('drum.tone', 'Тембр', c.drum.tone, 0, 1)}</div>`;
    if (c.type === 'synth') {
      const P = c.synth;
      h += `<div class="st-kn"><label class="st-k"><span>${esc(t('Пресет'))}</span><select data-par="preset"><option value="">—</option>${Object.keys(SYNTHS).map(k => `<option value="${esc(k)}">${esc(k)}</option>`).join('')}</select></label>` +
        P.osc.map((o, i) => `<div class="st-osc"><b>OSC ${i + 1}</b><select data-par="osc.${i}.w">${['sine', 'triangle', 'square', 'sawtooth'].map(w => `<option value="${w}"${o.w === w ? ' selected' : ''}>${w}</option>`).join('')}</select>${knob(`osc.${i}.o`, 'Октава', o.o, -3, 3, 1)}${knob(`osc.${i}.d`, 'Розстроювання', o.d, -50, 50, 1)}${knob(`osc.${i}.v`, 'Рівень', o.v, 0, 1)}</div>`).join('') +
        `${knob('synth.a', 'Атака', P.a, 0.001, 2, 0.001)}${knob('synth.dc', 'Спад', P.dc, 0.01, 3)}${knob('synth.s', 'Утримання', P.s, 0, 1)}${knob('synth.r', 'Відпускання', P.r, 0.01, 4)}${knob('synth.cut', 'Зріз фільтра', P.cut, 60, 16000, 10)}${knob('synth.res', 'Резонанс', P.res, 0.1, 20, 0.1)}${knob('synth.env', 'Обвідна фільтра', P.env, 0, 8000, 10)}</div>`;
    }
    if (c.type === 'sample') h += `<div class="st-kn">${knob('sample.root', 'Базова нота', c.sample.root || 60, 24, 96, 1)}${knob('sample.start', 'Початок, с', c.sample.start || 0, 0, 10, 0.01)}<label class="st-k"><span>${esc(t('Обрізати за довжиною ноти'))}</span><input type="checkbox" data-par="sample.cut"${c.sample.cut ? ' checked' : ''}></label></div>`;
    el.innerHTML = h;
  };
  // ---------- piano roll (canvas) ----------
  const PR_KEYS = 48, ROW = 14, LOW = 24, HIGH = 108;
  const renderPR = () => {
    const el = root.querySelector('.st-pane');
    const c = chan(selCh) || D().channels.find(x => x.type !== 'drum') || D().channels[0];
    if (c && !selCh) selCh = c.id;
    el.innerHTML = `<div class="st-rack-top"><span>${esc(t('Канал'))}:</span><select data-pr="ch">${D().channels.map(x => `<option value="${x.id}"${x.id === selCh ? ' selected' : ''}>${esc(x.name)}</option>`).join('')}</select>
      <span>${esc(t('Прив’язка'))}</span><select data-pr="snap">${[[1, '1/16'], [2, '1/8'], [4, '1/4 (доля)'], [16, '1 такт']].map(([v, l]) => `<option value="${v}"${prState.snap === v ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select>
      <span>${esc(t('Лад'))}</span><select data-pr="root">${Array.from({ length: 12 }, (_, i) => `<option value="${i}"${prState.scaleRoot === i ? ' selected' : ''}>${NOTE(i + 12).replace(/\d+$/, '')}</option>`).join('')}</select><select data-pr="scale">${[['none', 'Без ладу'], ['major', 'Мажор'], ['minor', 'Мінор'], ['penta', 'Пентатоніка'], ['minpenta', 'Мінорна пентатоніка'], ['blues', 'Блюз']].map(([k, l]) => `<option value="${k}"${prState.scale === k ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select>
      <span>${esc(t('Акорд'))}</span><select data-pr="chord">${[['none', 'Одна нота'], ['maj', 'Мажорний'], ['min', 'Мінорний'], ['dom7', '7'], ['maj7', 'maj7'], ['min7', 'm7'], ['sus4', 'sus4'], ['power', 'Квінта']].map(([k, l]) => `<option value="${k}"${prState.chord === k ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select>
      <button type="button" class="btn" data-pr="quant">${esc(t('Квантувати'))}</button><button type="button" class="btn" data-pr="clear">${esc(t('Очистити'))}</button><label class="st-chk"><input type="checkbox" data-pr="rec"${prState.rec ? ' checked' : ''}> ● ${esc(t('Запис з клавіатури / MIDI'))}</label></div>
      <div class="st-pr"><canvas class="st-prc"></canvas></div><div class="st-hint">${esc(t('Клік — нота, тягніть — перемістити, правий край — довжина, правий клік — видалити. Нижня смуга — сила (velocity). Грайте на клавіатурі: Z S X D C V… та Q 2 W 3 E…'))}</div>`;
    drawPR();
    bindPR();
  };
  const prGeom = () => { const p = pat(); const cvs = root.querySelector('.st-prc'); const W = Math.max(cvs.parentElement.clientWidth, 60 + p.len * cell); return { cvs, W, H: (HIGH - LOW) * ROW + 70, kw: 56, p }; };
  const drawPR = () => {
    const g = prGeom(); if (!g.cvs) return;
    const { cvs, W, H, kw, p } = g;
    cvs.width = W; cvs.height = H; cvs.style.height = H + 'px';
    const c = cvs.getContext('2d');
    const sc = SCALES[prState.scale];
    for (let n = HIGH - 1; n >= LOW; n--) {
      const y = (HIGH - 1 - n) * ROW, black = [1, 3, 6, 8, 10].includes(n % 12);
      const inScale = !sc || sc.includes((n - prState.scaleRoot + 120) % 12);
      c.fillStyle = black ? '#1d1d22' : '#26262c'; if (!inScale) c.fillStyle = '#141417';
      c.fillRect(kw, y, W - kw, ROW);
      c.fillStyle = black ? '#222' : '#e8e8ec'; c.fillRect(0, y, kw - 2, ROW - 1);
      if (n % 12 === 0) { c.fillStyle = '#555'; c.font = '9px system-ui'; c.fillText(NOTE(n), 4, y + ROW - 3); }
    }
    for (let s = 0; s <= p.len; s++) { c.fillStyle = s % 16 === 0 ? 'rgba(255,255,255,.28)' : s % 4 === 0 ? 'rgba(255,255,255,.13)' : 'rgba(255,255,255,.05)'; c.fillRect(kw + s * cell, 0, 1, H - 70); }
    const notes = p.notes[selCh] || [];
    const col = (chan(selCh) || {}).color || '#0D99FF';
    for (const n of notes) {
      const x = kw + n.s * cell, y = (HIGH - 1 - n.p) * ROW;
      c.fillStyle = col; c.globalAlpha = 0.45 + 0.55 * n.v; c.fillRect(x + 1, y + 1, n.l * cell - 2, ROW - 2); c.globalAlpha = 1;
      c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(x + n.l * cell - 5, y + 1, 4, ROW - 2);
      if (n.l * cell > 26) { c.fillStyle = '#fff'; c.font = '9px system-ui'; c.fillText(NOTE(n.p), x + 3, y + ROW - 3); }
    }
    // velocity lane
    const vy = H - 66;
    c.fillStyle = '#18181c'; c.fillRect(kw, vy, W - kw, 66);
    for (const n of notes) { const x = kw + n.s * cell; c.fillStyle = col; c.fillRect(x + 2, vy + 62 - n.v * 58, 4, n.v * 58); }
  };
  const bindPR = () => {
    const cvs = root.querySelector('.st-prc');
    cvs.addEventListener('contextmenu', e => e.preventDefault());
    cvs.addEventListener('pointerdown', e => {
      const g = prGeom(), r = cvs.getBoundingClientRect();
      const x = (e.clientX - r.left) * cvs.width / r.width, y = e.clientY - r.top;
      const p = g.p, notes = (p.notes[selCh] = p.notes[selCh] || []);
      if (x < g.kw) { const n = HIGH - 1 - Math.floor(y / ROW); if (n >= LOW && chan(selCh)) ST.preview(chan(selCh), n); return; }
      const sx = (x - g.kw) / cell;
      if (y > g.H - 66) {
        // velocity lane: drag sets velocity of notes under the pointer
        const setV = ev => { const xx = ((ev.clientX - r.left) * cvs.width / r.width - g.kw) / cell, v = Math.min(1, Math.max(0.05, (g.H - 4 - (ev.clientY - r.top)) / 58)); for (const n of notes) if (xx >= n.s && xx < n.s + Math.max(1, n.l * 0.5)) n.v = v; drawPR(); };
        setV(e); cvs.setPointerCapture(e.pointerId);
        const mv = ev => setV(ev), up = () => { cvs.removeEventListener('pointermove', mv); cvs.removeEventListener('pointerup', up); commit('Сила нот'); };
        cvs.addEventListener('pointermove', mv); cvs.addEventListener('pointerup', up);
        return;
      }
      const pitch = HIGH - 1 - Math.floor(y / ROW);
      const hit = notes.find(n => n.p === pitch && sx >= n.s && sx < n.s + n.l);
      if (e.button === 2) { if (hit) { notes.splice(notes.indexOf(hit), 1); drawPR(); commit('Видалити ноту'); } return; }
      const snap = v => Math.round(v / prState.snap) * prState.snap;
      let target = hit, mode = 'move';
      if (hit && sx > hit.s + hit.l - 0.35) mode = 'resize';
      if (!hit) {
        const s0 = Math.max(0, Math.floor(sx / prState.snap) * prState.snap);
        const made = CHORDS[prState.chord].map(iv => ({ p: pitch + iv, s: s0, l: prState.len, v: 0.8 })).filter(n => n.p < HIGH);
        notes.push(...made);
        target = made[0]; mode = 'resize';
        made.forEach(n => ST.preview(chan(selCh), n.p));
      } else ST.preview(chan(selCh), hit.p);
      const sx0 = sx, s0 = target.s, p0 = target.p, l0 = target.l;
      cvs.setPointerCapture(e.pointerId);
      const mv = ev => {
        const xx = ((ev.clientX - r.left) * cvs.width / r.width - g.kw) / cell, yy = ev.clientY - r.top;
        if (mode === 'resize') target.l = Math.max(prState.snap === 16 ? 1 : 1, snap(l0 + xx - sx0) || prState.snap);
        else { target.s = Math.max(0, Math.min(p.len - 1, snap(s0 + xx - sx0))); target.p = Math.min(HIGH - 1, Math.max(LOW, HIGH - 1 - Math.floor(yy / ROW))); if (target.p !== p0) { /* audition the new pitch */ } }
        drawPR();
      };
      const up = () => { cvs.removeEventListener('pointermove', mv); cvs.removeEventListener('pointerup', up); prState.len = target.l; commit('Нота'); };
      cvs.addEventListener('pointermove', mv); cvs.addEventListener('pointerup', up);
      drawPR();
    });
    // scroll to the middle C region
    const box = root.querySelector('.st-pr'); box.scrollTop = (HIGH - 1 - prState.top) * ROW;
  };
  // ---------- playlist ----------
  const BAR = 16;
  const renderPL = () => {
    const el = root.querySelector('.st-pane');
    const st = D();
    el.innerHTML = `<div class="st-rack-top"><span>${esc(t('Патерн для вставки'))}: <b>${esc(pat().name)}</b></span><span class="sp"></span><span class="st-hint">${esc(t('Клік — вставити патерн, тягніть — перемістити, правий край — довжина, правий клік — видалити. Режим SONG грає плейлист.'))}</span></div>
      <div class="st-pl"><div class="st-plh">${st.playlist.tracks.map(tk => `<div class="st-plt" data-tk="${tk.id}"><button type="button" class="st-led${tk.mute ? '' : ' on'}" data-tka="mute"></button><span>${esc(tk.name)}</span></div>`).join('')}<button type="button" class="btn" data-st="addtrack">+ ${esc(t('Доріжка'))}</button></div><div class="st-plw"><canvas class="st-plc"></canvas></div></div>`;
    drawPL(); bindPL();
  };
  const plGeom = () => { const cvs = root.querySelector('.st-plc'); const bars = Math.max(32, Math.ceil(ST.songLen() / BAR) + 8); const bw = cell * 4; return { cvs, bars, bw, W: bars * bw, H: 22 + D().playlist.tracks.length * 40 }; };
  const drawPL = () => {
    const g = plGeom(); if (!g.cvs) return;
    const { cvs, bars, bw, W, H } = g;
    cvs.width = W; cvs.height = H;
    const c = cvs.getContext('2d');
    c.fillStyle = '#1b1b20'; c.fillRect(0, 0, W, H);
    c.fillStyle = '#121215'; c.fillRect(0, 0, W, 22);
    for (let b = 0; b <= bars; b++) { c.fillStyle = b % 4 === 0 ? 'rgba(255,255,255,.2)' : 'rgba(255,255,255,.07)'; c.fillRect(b * bw, 0, 1, H); if (b < bars) { c.fillStyle = '#888'; c.font = '10px system-ui'; c.fillText(String(b + 1), b * bw + 4, 15); } }
    D().playlist.tracks.forEach((tk, i) => { c.fillStyle = 'rgba(255,255,255,.04)'; c.fillRect(0, 22 + i * 40 + 39, W, 1); });
    for (const cl of D().playlist.clips) {
      const ti = D().playlist.tracks.findIndex(x => x.id === cl.track); if (ti < 0) continue;
      const x = cl.start / BAR * bw, y = 22 + ti * 40 + 2, w = cl.len / BAR * bw;
      const p = cl.kind === 'pattern' ? pat(cl.ref) : null;
      c.fillStyle = cl.kind === 'audio' ? '#2f6b4f' : '#3b4a7a'; c.fillRect(x + 1, y, w - 2, 36);
      c.fillStyle = 'rgba(255,255,255,.85)'; c.font = '11px system-ui'; c.fillText(cl.kind === 'audio' ? '♪ ' + ((S.doc.assets[cl.ref] || {}).name || '') : (p ? p.name : '?'), x + 5, y + 14);
      // mini notes
      if (p) { c.fillStyle = 'rgba(255,255,255,.55)'; for (let s = 0; s < cl.len; s++) { const ev = eventsAt(p, s % p.len); if (ev.length) c.fillRect(x + s / BAR * bw + 1, y + 22, Math.max(1, bw / BAR - 1), 8); } }
      c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(x + w - 6, y, 4, 36);
    }
  };
  const bindPL = () => {
    const cvs = root.querySelector('.st-plc');
    cvs.addEventListener('contextmenu', e => e.preventDefault());
    cvs.addEventListener('pointerdown', e => {
      const g = plGeom(), r = cvs.getBoundingClientRect();
      const x = e.clientX - r.left, y = e.clientY - r.top;
      const stepAt = xx => Math.max(0, Math.round(xx / g.bw * BAR / 4) * 4);
      if (y < 22) { ST.pos = Math.floor(x / g.bw) * BAR; drawPlayheads(); return; }
      const ti = Math.floor((y - 22) / 40), tk = D().playlist.tracks[ti];
      if (!tk) return;
      const s = x / g.bw * BAR;
      const hit = D().playlist.clips.find(cl => cl.track === tk.id && s >= cl.start && s < cl.start + cl.len);
      if (e.button === 2) { if (hit) { D().playlist.clips = D().playlist.clips.filter(c => c !== hit); drawPL(); commit('Видалити кліп'); } return; }
      let target = hit, mode = 'move';
      if (hit && s > hit.start + hit.len - 1.5) mode = 'resize';
      if (!hit) { target = { id: O.uid(), track: tk.id, kind: 'pattern', ref: D().pattern, start: Math.floor(s / BAR) * BAR, len: pat().len }; D().playlist.clips.push(target); mode = 'move'; }
      const s0 = target.start, l0 = target.len, x0 = x;
      cvs.setPointerCapture(e.pointerId);
      const mv = ev => {
        const dx = ev.clientX - r.left - x0;
        const ds = dx / g.bw * BAR;
        if (mode === 'resize') target.len = Math.max(4, Math.round((l0 + ds) / 4) * 4);
        else { target.start = Math.max(0, Math.round((s0 + ds) / 4) * 4); const nt = D().playlist.tracks[Math.floor((ev.clientY - r.top - 22) / 40)]; if (nt) target.track = nt.id; }
        drawPL();
      };
      void stepAt;
      const up = () => { cvs.removeEventListener('pointermove', mv); cvs.removeEventListener('pointerup', up); commit('Плейлист'); };
      cvs.addEventListener('pointermove', mv); cvs.addEventListener('pointerup', up);
      drawPL();
    });
  };
  // ---------- mixer ----------
  const renderMixer = () => {
    const el = root.querySelector('.st-pane');
    const st = D();
    el.innerHTML = `<div class="st-mix">${st.mixer.map((m, i) => `<div class="st-strip${i === 0 ? ' master' : ''}" data-mx="${i}"><div class="st-sn">${esc(i === 0 ? 'Master' : m.name)}</div><canvas class="st-meter" width="16" height="140"></canvas><input type="range" class="st-fader" min="0" max="1.25" step="0.01" value="${m.vol}" data-mxp="vol" orient="vertical" title="${esc(t('Гучність'))}"><input type="range" min="-1" max="1" step="0.01" value="${m.pan}" data-mxp="pan" title="${esc(t('Панорама'))}"><div class="st-ms"><button type="button" class="${m.mute ? 'on' : ''}" data-mxa="mute">M</button>${i ? `<button type="button" class="${m.solo ? 'on' : ''}" data-mxa="solo">S</button>` : ''}</div>
      <div class="st-fx">${(m.fx || []).map((f, j) => `<div class="st-fxi${f.on ? '' : ' off'}"><div class="st-fxh"><button type="button" data-fxa="on" data-j="${j}" class="st-led${f.on ? ' on' : ''}"></button><b>${esc(t(FX[f.type].label))}</b><button type="button" data-fxa="del" data-j="${j}">✕</button></div>${Object.entries(FX[f.type].r).map(([k, [mn, mx]]) => `<label class="st-k mini"><span>${esc(t({ low: 'Низ', mid: 'Середина', high: 'Верх', thr: 'Поріг', ratio: 'Ступінь', atk: 'Атака', rel: 'Відновлення', gain: 'Підсилення', size: 'Розмір', mix: 'Мікс', time: 'Час', fb: 'Повтори', amt: 'Сила', freq: 'Частота', q: 'Q', rate: 'Швидкість', depth: 'Глибина' }[k] || k))}</span><input type="range" min="${mn}" max="${mx}" step="${(mx - mn) / 200}" value="${f[k]}" data-fxp="${k}" data-j="${j}"></label>`).join('')}${f.type === 'filter' ? `<select data-fxp="ftype" data-j="${j}">${['lowpass', 'highpass', 'bandpass', 'notch'].map(x => `<option${(f.ftype || 'lowpass') === x ? ' selected' : ''}>${x}</option>`).join('')}</select>` : ''}</div>`).join('')}
      <select data-mxa="addfx"><option value="">+ ${esc(t('Ефект'))}</option>${Object.entries(FX).map(([k, v]) => `<option value="${k}">${esc(t(v.label))}</option>`).join('')}</select></div>
      <div class="st-route">${st.channels.filter(c => c.mixer === i).map(c => `<i style="--c:${c.color}" title="${esc(c.name)}"></i>`).join('')}</div></div>`).join('')}</div>`;
  };
  const drawMeters = () => {
    if (!root || tab !== 'mixer' || !graph) return;
    root.querySelectorAll('.st-strip').forEach(el => {
      const i = +el.dataset.mx, s = graph.strips[i]; if (!s) return;
      const a = new Uint8Array(s.an.fftSize); s.an.getByteTimeDomainData(a);
      let pk = 0; for (const v of a) pk = Math.max(pk, Math.abs(v - 128) / 128);
      const cv = el.querySelector('.st-meter'), c = cv.getContext('2d');
      c.fillStyle = '#111'; c.fillRect(0, 0, 16, 140);
      const h = Math.min(1, pk) * 140;
      const gr = c.createLinearGradient(0, 140, 0, 0); gr.addColorStop(0, '#14AE5C'); gr.addColorStop(0.75, '#FFCD29'); gr.addColorStop(1, '#F24822');
      c.fillStyle = gr; c.fillRect(2, 140 - h, 12, h);
    });
  };
  const drawPlayheads = () => {
    if (!root) return;
    const s = ST.curStep();
    if (tab === 'rack') { const p = pat(); const cur = Math.floor(s) % p.len; root.querySelectorAll('.st-step').forEach(b => b.classList.toggle('cur', playing && D().mode === 'pattern' && +b.dataset.step === cur)); }
    const ph = root.querySelector('.st-phl');
    if (tab === 'playlist') { const g = plGeom(); if (!ph) { const d = document.createElement('div'); d.className = 'st-phl'; root.querySelector('.st-plw').appendChild(d); } const el = root.querySelector('.st-phl'); if (el) el.style.left = (D().mode === 'song' || !playing ? s : 0) / BAR * g.bw + 'px'; }
    const pos = root.querySelector('.st-pos'); if (pos) { const bar = Math.floor(s / 16) + 1, beat = Math.floor((s % 16) / 4) + 1; pos.textContent = `${bar}:${beat}:${Math.floor(s % 4) + 1}`; }
  };
  const renderPane = () => {
    root.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
    if (tab === 'rack') renderRack();
    if (tab === 'piano') renderPR();
    if (tab === 'playlist') renderPL();
    if (tab === 'mixer') renderMixer();
  };
  ST.refresh = () => { if (!root) return; renderTransport(); renderBrowser(); renderPane(); };

  // ---------- computer keyboard & MIDI ----------
  const KEYMAP = { KeyZ: 0, KeyS: 1, KeyX: 2, KeyD: 3, KeyC: 4, KeyV: 5, KeyG: 6, KeyB: 7, KeyH: 8, KeyN: 9, KeyJ: 10, KeyM: 11, Comma: 12, KeyQ: 12, Digit2: 13, KeyW: 14, Digit3: 15, KeyE: 16, KeyR: 17, Digit5: 18, KeyT: 19, Digit6: 20, KeyY: 21, Digit7: 22, KeyU: 23, KeyI: 24 };
  let octave = 4;
  const recNote = (note, vel) => {
    if (!prState.rec || !playing || !selCh) return;
    const p = pat(), s = Math.round(ST.curStep()) % p.len;
    (p.notes[selCh] = p.notes[selCh] || []).push({ p: note, s, l: 2, v: vel });
    if (tab === 'piano') drawPR();
    O.history.commit('Запис нот');
  };
  const playKey = (note, vel = 0.8) => { const c = chan(selCh) || D().channels[0]; if (!c) return; ST.preview(c, note, vel); recNote(note, vel); };
  ST.midi = async () => {
    if (!navigator.requestMIDIAccess) return O.toast('Цей браузер не підтримує MIDI');
    try {
      const m = await navigator.requestMIDIAccess();
      let n = 0;
      for (const inp of m.inputs.values()) { n++; inp.onmidimessage = e => { const [st, d1, d2] = e.data; if ((st & 0xf0) === 0x90 && d2 > 0) playKey(d1, d2 / 127); }; }
      O.toast(n ? 'MIDI: підключено пристроїв {n}' : 'MIDI-пристроїв не знайдено', { n });
    } catch (e) { O.toast('MIDI недоступний: {msg}', { msg: e.message }); }
  };

  // ---------- shell ----------
  ST.open = () => {
    if (root) return;
    D();
    if (!selCh) selCh = (D().channels[0] || {}).id;
    root = O.h(`<div class="st-root" role="dialog" aria-label="${esc(t('Музична студія'))}">
      <div class="st-top"><b class="st-logo">🎹 ${esc(t('Студія'))}</b><button type="button" class="st-play" data-st="play" title="${esc(t('Пробіл'))}">▶</button><button type="button" data-st="stop" title="${esc(t('Стоп'))}">⏹</button>
        <div class="st-modes"><button type="button" data-mode="pattern">PAT</button><button type="button" data-mode="song">SONG</button></div>
        <label class="st-bpm">BPM <input type="number" min="40" max="300" step="1" data-st="bpm"></label><label class="st-sw">${esc(t('Свінг'))} <input type="range" min="0" max="75" data-st="swing"></label><button type="button" data-st="metro" title="${esc(t('Метроном'))}">♩</button><span class="st-pos">1:1:1</span>
        <select data-st="pattern" title="${esc(t('Патерн'))}"></select><button type="button" data-st="newpat" title="${esc(t('Новий патерн'))}">+</button><button type="button" data-st="clonepat" title="${esc(t('Клонувати патерн'))}">⧉</button><button type="button" data-st="renpat" title="${esc(t('Перейменувати патерн'))}">✎</button>
        <span class="sp"></span><button type="button" class="btn" data-st="midi">MIDI</button><button type="button" class="btn" data-st="wav">${esc(t('Експорт WAV'))}</button><button type="button" class="btn" data-st="tovideo">${esc(t('У відео'))}</button><button type="button" class="btn" data-st="music">${esc(t('Музика проєкту'))}</button><button type="button" class="btn" data-st="close">✕</button></div>
      <div class="st-body"><div class="st-browser"></div><div class="st-main"><div class="st-tabs">${[['rack', 'Channel Rack'], ['piano', 'Піаноролл'], ['playlist', 'Плейлист'], ['mixer', 'Мікшер']].map(([k, l]) => `<button type="button" data-tab="${k}">${esc(t(l))}</button>`).join('')}</div><div class="st-pane"></div></div></div></div>`);
    document.body.appendChild(root);
    root.addEventListener('click', onClick);
    root.addEventListener('change', onChange);
    root.addEventListener('input', onInput);
    root.addEventListener('contextmenu', e => { const b = e.target.closest('.st-step'); if (b) { e.preventDefault(); const p = pat(), cid = b.closest('[data-ch]').dataset.ch; (p.steps[cid] = p.steps[cid] || [])[+b.dataset.step] = 0; commit('Крок'); renderRack(); } });
    root.addEventListener('dblclick', e => { const b = e.target.closest('[data-cha="sel"]'); if (b) { selCh = b.closest('[data-ch]').dataset.ch; tab = 'piano'; renderPane(); } });
    document.addEventListener('keydown', keys, true);
    document.addEventListener('keyup', keysUp, true);
    ST.refresh();
    anim();
  };
  ST.close = () => { if (!root) return; ST.stop(); document.removeEventListener('keydown', keys, true); document.removeEventListener('keyup', keysUp, true); cancelAnimationFrame(raf); root.remove(); root = null; };
  ST.isOpen = () => !!root;
  const held = new Set();
  const keys = e => {
    if (!root || O.$('.dlg-back')) return;
    const tg = e.target;
    if (tg && (tg.tagName === 'TEXTAREA' || (tg.tagName === 'INPUT' && !['range', 'checkbox', 'color'].includes(tg.type)) || tg.tagName === 'SELECT')) { e.stopPropagation(); return; }
    e.stopPropagation();
    if (e.code === 'Space') { e.preventDefault(); playing ? ST.stop() : ST.play(); return; }
    if ((e.ctrlKey || e.metaKey) && e.code === 'KeyZ') { e.preventDefault(); if (e.shiftKey) O.history.redo(); else O.history.undo(); ST.refresh(); return; }
    if (e.key === 'Escape') { ST.close(); return; }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.code === 'NumpadAdd' || e.key === '+') { octave = Math.min(8, octave + 1); O.toast('Октава {n}', { n: octave }); return; }
    if (e.code === 'NumpadSubtract' || e.key === '-') { octave = Math.max(0, octave - 1); O.toast('Октава {n}', { n: octave }); return; }
    if (KEYMAP[e.code] !== undefined && !held.has(e.code)) { held.add(e.code); e.preventDefault(); playKey(12 * (octave + 1) + KEYMAP[e.code]); }
  };
  const keysUp = e => { held.delete(e.code); };
  const onClick = async e => {
    const st = D();
    const b = e.target.closest('button,[data-tab]');
    if (!b) return;
    if (b.dataset.tab) { tab = b.dataset.tab; renderPane(); return; }
    if (b.dataset.mode) { st.mode = b.dataset.mode; commit('Режим'); renderTransport(); if (playing) { ST.stop(); ST.play(); } return; }
    if (b.dataset.len) { pat().len = +b.dataset.len; commit('Довжина патерну'); renderRack(); return; }
    if (b.dataset.addd) { const [k, l] = DRUMS.find(x => x[0] === b.dataset.addd); const c = ch(l, 'drum', { drum: { kind: k, pitch: 0, decay: 1, tone: 0.5 }, mixer: Math.min(8, st.channels.length + 1) }); st.channels.push(c); selCh = c.id; ST.preview(c, 60); commit('Канал'); tab = 'rack'; ST.refresh(); return; }
    if (b.dataset.adds) { const c = ch(b.dataset.adds, 'synth', { synth: O.clone(SYNTHS[b.dataset.adds]), mixer: Math.min(8, st.channels.length + 1) }); st.channels.push(c); selCh = c.id; ST.preview(c, 60); commit('Канал'); tab = 'piano'; ST.refresh(); return; }
    if (b.dataset.addsmp) { const a = S.doc.assets[b.dataset.addsmp]; const c = ch(a.name || t('Семпл'), 'sample', { sample: { asset: b.dataset.addsmp, root: 60, start: 0, cut: false }, mixer: Math.min(8, st.channels.length + 1) }); st.channels.push(c); selCh = c.id; commit('Канал'); tab = 'rack'; ST.refresh(); return; }
    if (b.dataset.addaud) { const a = S.doc.assets[b.dataset.addaud]; const len = Math.max(4, Math.ceil((a.duration || 4) / stepDur() / 4) * 4); st.playlist.clips.push({ id: O.uid(), track: st.playlist.tracks[st.playlist.tracks.length - 1].id, kind: 'audio', ref: b.dataset.addaud, start: Math.floor((ST.pos || 0) / 16) * 16, len }); commit('Аудіо в плейлисті'); tab = 'playlist'; st.mode = 'song'; ST.refresh(); return; }
    if (b.dataset.cha) {
      const row = b.closest('[data-ch]'); const c = chan(row ? row.dataset.ch : selCh); if (!c) return;
      const a = b.dataset.cha;
      if (a === 'mute') { c.mute = !c.mute; commit('Канал'); ST.rebuild(); renderRack(); }
      if (a === 'solo') { c.solo = !c.solo; commit('Канал'); ST.rebuild(); renderRack(); }
      if (a === 'sel') { selCh = c.id; ST.preview(c, 60); renderRack(); }
      if (a === 'pr') { selCh = c.id; tab = 'piano'; renderPane(); }
      if (a === 'dup') { const d = Object.assign(O.clone(c), { id: O.uid(), name: c.name + ' 2' }); st.channels.push(d); for (const p of st.patterns) { if (p.steps[c.id]) p.steps[d.id] = p.steps[c.id].slice(); if (p.notes[c.id]) p.notes[d.id] = O.clone(p.notes[c.id]); } selCh = d.id; commit('Канал'); renderRack(); }
      if (a === 'del') { st.channels = st.channels.filter(x => x !== c); for (const p of st.patterns) { delete p.steps[c.id]; delete p.notes[c.id]; } selCh = (st.channels[0] || {}).id; commit('Видалити канал'); renderRack(); }
      return;
    }
    if (b.classList.contains('st-step')) {
      const p = pat(), cid = b.closest('[data-ch]').dataset.ch, i = +b.dataset.step;
      const arr = (p.steps[cid] = p.steps[cid] || []);
      if (e.shiftKey && arr[i]) arr[i] = arr[i] > 0.75 ? 0.6 : arr[i] > 0.45 ? 0.35 : 1;
      else arr[i] = arr[i] ? 0 : 1;
      if (arr[i]) ST.preview(chan(cid), null, arr[i]);
      commit('Крок'); renderRack(); return;
    }
    if (b.dataset.tka) { const tk = st.playlist.tracks.find(x => x.id === b.closest('[data-tk]').dataset.tk); tk.mute = !tk.mute; commit('Доріжка'); renderPL(); return; }
    if (b.dataset.mxa) { const i = +b.closest('[data-mx]').dataset.mx, m = st.mixer[i]; if (b.dataset.mxa === 'mute') m.mute = !m.mute; if (b.dataset.mxa === 'solo') m.solo = !m.solo; commit('Мікшер'); ST.rebuild(); renderMixer(); return; }
    if (b.dataset.fxa) { const i = +b.closest('[data-mx]').dataset.mx, m = st.mixer[i], j = +b.dataset.j; if (b.dataset.fxa === 'del') m.fx.splice(j, 1); else m.fx[j].on = !m.fx[j].on; commit('Ефект'); ST.rebuild(); renderMixer(); return; }
    if (b.dataset.pr === 'quant') { const p = pat(); for (const n of p.notes[selCh] || []) n.s = Math.round(n.s / prState.snap) * prState.snap; commit('Квантування'); drawPR(); return; }
    if (b.dataset.pr === 'clear') { pat().notes[selCh] = []; commit('Очистити'); drawPR(); return; }
    const a = b.dataset.st;
    if (a === 'play') playing ? ST.stop() : ST.play();
    if (a === 'stop') ST.stop();
    if (a === 'metro') { st.metro = !st.metro; commit('Метроном'); renderTransport(); }
    if (a === 'close') ST.close();
    if (a === 'midi') ST.midi();
    if (a === 'newpat') { const p = { id: O.uid(), name: t('Патерн {n}', { n: st.patterns.length + 1 }), len: 16, steps: {}, notes: {} }; st.patterns.push(p); st.pattern = p.id; commit('Новий патерн'); ST.refresh(); }
    if (a === 'clonepat') { const p = Object.assign(O.clone(pat()), { id: O.uid(), name: pat().name + ' 2' }); st.patterns.push(p); st.pattern = p.id; commit('Клонувати патерн'); ST.refresh(); }
    if (a === 'renpat') ui.dialog({ title: 'Перейменувати патерн', fields: [{ key: 'n', label: 'Назва', type: 'text', value: pat().name }], onOk: v => { if (v.n.trim()) { pat().name = v.n.trim(); commit('Патерн'); ST.refresh(); } } });
    if (a === 'addtrack') { st.playlist.tracks.push({ id: O.uid(), name: t('Доріжка {n}', { n: st.playlist.tracks.length + 1 }), mute: false }); commit('Доріжка'); renderPL(); }
    if (a === 'importsample') { const fs = await io.pickFiles('audio/*,.wav,.mp3,.ogg,.flac,.m4a,.aac', true); for (const f of fs) { const id = O.uid(); S.doc.assets[id] = { data: await io.blobToData(f), kind: 'audio', name: f.name.replace(/\.[^.]+$/, ''), size: f.size }; } if (fs.length) { commit('Семпли'); renderBrowser(); } }
    if (a === 'wav') { try { const { blob } = await renderToAsset(); O.download(blob, String(S.doc.name || 'track').replace(/[\\/:*?"<>|]+/g, '_') + ' ' + st.bpm + 'bpm.wav'); commit('Трек студії'); O.toast('WAV збережено'); } catch (err) { console.error(err); O.toast('Помилка рендеру: {msg}', { msg: err.message }); } }
    if (a === 'tovideo') {
      try {
        const { id } = await renderToAsset();
        if (O.video) { const c = O.video.addAsset(id, {}); if (c) c.start = 0; }
        commit('Музика у відео');
        O.toast('Трек додано на аудіодоріжку відеоредактора');
        ST.close(); if (O.video) O.video.open();
      } catch (err) { console.error(err); O.toast('Помилка рендеру: {msg}', { msg: err.message }); }
    }
    if (a === 'music') { try { const { id } = await renderToAsset(); S.doc.music = { asset: id, name: S.doc.assets[id].name, volume: 0.8, loop: true }; commit('Фонова музика'); O.toast('Фонова музика: «{name}»', { name: S.doc.assets[id].name }); } catch (err) { O.toast('Помилка рендеру: {msg}', { msg: err.message }); } }
  };
  const setPath = (obj, path, val) => { const ks = path.split('.'); let o = obj; for (let i = 0; i < ks.length - 1; i++) o = o[ks[i]]; o[ks[ks.length - 1]] = val; };
  const onInput = e => {
    const el = e.target;
    if (el.dataset.par) { const c = chan(selCh); if (!c) return; const v = el.type === 'range' ? +el.value : el.value; if (/^osc\./.test(el.dataset.par)) { const [, i, k] = el.dataset.par.split('.'); c.synth.osc[+i][k] = k === 'w' ? v : +v; } else if (el.dataset.par !== 'preset') setPath(c, el.dataset.par, v); if (el.nextElementSibling && el.nextElementSibling.tagName === 'EM') el.nextElementSibling.textContent = O.fmt(+el.value, 2); return; }
    if (el.dataset.chp === 'vol' || el.dataset.chp === 'pan') { const c = chan(el.closest('[data-ch]').dataset.ch); c[el.dataset.chp] = +el.value; ST.rebuild(); return; }
    if (el.dataset.mxp) { const m = D().mixer[+el.closest('[data-mx]').dataset.mx]; m[el.dataset.mxp] = +el.value; ST.rebuild(); return; }
    if (el.dataset.fxp && el.type === 'range') { const m = D().mixer[+el.closest('[data-mx]').dataset.mx]; m.fx[+el.dataset.j][el.dataset.fxp] = +el.value; ST.rebuild(); return; }
    if (el.dataset.st === 'swing') { D().swing = +el.value; return; }
  };
  const onChange = e => {
    const el = e.target, st = D();
    if (el.dataset.st === 'bpm') { st.bpm = Math.min(300, Math.max(40, +el.value || 128)); commit('Темп'); return; }
    if (el.dataset.st === 'swing') { commit('Свінг'); return; }
    if (el.dataset.st === 'pattern') { st.pattern = el.value; commit('Патерн'); ST.refresh(); return; }
    if (el.dataset.par) {
      const c = chan(selCh); if (!c) return;
      if (el.dataset.par === 'preset' && el.value) { c.synth = O.clone(SYNTHS[el.value]); c.name = el.value; renderParams(); }
      if (el.type === 'checkbox') setPath(c, el.dataset.par, el.checked);
      if (el.tagName === 'SELECT' && el.dataset.par !== 'preset') { if (/^osc\./.test(el.dataset.par)) { const [, i, k] = el.dataset.par.split('.'); c.synth.osc[+i][k] = el.value; } else setPath(c, el.dataset.par, el.value); }
      ST.preview(c, 60);
      commit('Звук каналу'); return;
    }
    if (el.dataset.chp) { const row = el.closest('[data-ch]'); const c = chan(row ? row.dataset.ch : selCh); if (!c) return; const k = el.dataset.chp; c[k] = k === 'mixer' ? +el.value : el.type === 'range' ? +el.value : el.value; commit('Канал'); ST.rebuild(); if (k === 'name' || k === 'color') renderRack(); return; }
    if (el.dataset.mxp || (el.dataset.fxp && el.type === 'range')) { commit('Мікшер'); return; }
    if (el.dataset.fxp === 'ftype') { const m = st.mixer[+el.closest('[data-mx]').dataset.mx]; m.fx[+el.dataset.j].ftype = el.value; commit('Ефект'); ST.rebuild(); return; }
    if (el.dataset.mxa === 'addfx' && el.value) { const m = st.mixer[+el.closest('[data-mx]').dataset.mx]; m.fx = m.fx || []; m.fx.push(Object.assign({ type: el.value, on: true }, O.clone(FX[el.value].p))); commit('Ефект'); ST.rebuild(); renderMixer(); return; }
    if (el.dataset.pr === 'ch') { selCh = el.value; drawPR(); return; }
    if (el.dataset.pr === 'snap') { prState.snap = +el.value; return; }
    if (el.dataset.pr === 'root') { prState.scaleRoot = +el.value; drawPR(); return; }
    if (el.dataset.pr === 'scale') { prState.scale = el.value; drawPR(); return; }
    if (el.dataset.pr === 'chord') { prState.chord = el.value; return; }
    if (el.dataset.pr === 'rec') { prState.rec = el.checked; return; }
  };
  O.on('change', () => { if (root && !playing) { /* keep UI in step after undo / redo */ } });
  O.cmd('studio', 'Музична студія (як FL Studio)…', () => ST.open(), { keys: ['Ctrl+Alt+Shift+M'], group: 'Медіа' });
  O.MENUS.splice(O.MENUS.findIndex(m => m[0] === 'Вигляд'), 0, ['Медіа', ['videoEditor', 'studio']]);
  // top bar shortcuts
  window.addEventListener('load', () => setTimeout(() => {
    const bar = O.$('#topbar .tb-r');
    if (!bar || O.$('#btn-video')) return;
    const mk = (id, ico, label, fn) => { const b = O.h(`<button id="${id}" type="button" class="ib media-btn" title="${esc(t(label))}" aria-label="${esc(t(label))}">${ico}</button>`); b.addEventListener('click', fn); bar.insertBefore(b, O.$('#btn-aformat') || O.$('#btn-export')); };
    mk('btn-video', '🎬', 'Відеоредактор (як CapCut)…', () => O.video && O.video.open());
    mk('btn-studio', '🎹', 'Музична студія (як FL Studio)…', () => ST.open());
  }, 0));
})();
