'use strict';
/* Obrys — photos the InDesign way: two layers.
   A graphic frame (the container that crops: frame, or a mask group for round / polygon shapes) holds the
   photo content (a rectangle filled with the image). Select the frame to move / resize the crop, select the
   content (double-click, Enter, or «Select content») or drag the content grabber ◎ to move the photo inside.
   Fitting: fill frame proportionally, fit content proportionally, fit content to frame, fit frame to content,
   centre content, auto-fit. Photo adjustments: brightness, contrast, saturation, hue, black & white, sepia. */
(function () {
  const O = window.O, M = O.M, R = O.R, model = O.model, S = O.state, ui = O.ui, V = O.view, io = O.io, ph = O.ph;
  const t = (s, v) => O.t(s, v), esc = O.esc, n_ = O.n;
  const PF = O.photo = {};

  // ---------- structure ----------
  PF.isFrame = n => !!(n && n.gframe && n.children && n.children.some(c => c.photo));
  PF.contentOf = gf => (gf && gf.children ? gf.children.find(c => c.photo) : null);
  PF.frameOf = n => { if (!n) return null; if (PF.isFrame(n)) return n; const p = model.parent(n); return p && PF.isFrame(p) && n.photo ? p : null; };
  const imgFill = n => (n && n.fills || []).find(f => f.type === 'image');
  const assetOf = c => { const f = imgFill(c); return f ? S.doc.assets[f.asset] : null; };
  // the crop box in the coordinates of the content's parent
  PF.box = gf => (gf.type === 'frame' ? { x: 0, y: 0, w: gf.w, h: gf.h } : model.boundsIn(gf.children[0], gf.children[0].m));
  const contentBox = c => ({ x: c.m[4], y: c.m[5], w: c.w, h: c.h });
  const setContent = (c, x, y, w, h) => { const d = M.decompose(c.m); c.w = Math.max(1, w); c.h = Math.max(1, h); c.m = M.chain(M.translate(x, y), M.rotate(d.rot)); };

  // ---------- fitting (Object → Fitting in InDesign) ----------
  PF.FITS = [['fill', 'Заповнити фрейм пропорційно'], ['fit', 'Вписати вміст пропорційно'], ['stretch', 'Вписати вміст у фрейм'], ['frame', 'Підігнати фрейм під вміст'], ['center', 'Центрувати вміст']];
  PF.fit = (gf, kind) => {
    const c = PF.contentOf(gf);
    if (!c) return;
    const a = assetOf(c) || { w: c.w, h: c.h };
    const B = PF.box(gf);
    const aw = a.w || c.w, ah = a.h || c.h;
    if (kind === 'fill' || kind === 'fit') {
      const k = kind === 'fill' ? Math.max(B.w / aw, B.h / ah) : Math.min(B.w / aw, B.h / ah);
      const w = aw * k, h = ah * k;
      setContent(c, B.x + (B.w - w) / 2, B.y + (B.h - h) / 2, w, h);
    } else if (kind === 'stretch') setContent(c, B.x, B.y, B.w, B.h);
    else if (kind === 'center') setContent(c, B.x + (B.w - c.w) / 2, B.y + (B.h - c.h) / 2, c.w, c.h);
    else if (kind === 'frame') {
      const C = contentBox(c);
      if (gf.type === 'frame') {
        // move the frame onto the content, keep the content where it is on the page
        gf.m = M.mul(gf.m, M.translate(C.x, C.y));
        gf.w = C.w; gf.h = C.h;
        setContent(c, 0, 0, C.w, C.h);
      } else {
        const sh = gf.children[0];
        if (['rect', 'ellipse', 'polygon', 'star'].includes(sh.type)) { sh.w = C.w; sh.h = C.h; sh.m = M.translate(C.x, C.y); }
      }
    }
    if (kind !== 'frame' && kind !== 'center') gf.lastFit = kind;
    gf.fitBox = PF.box(gf);
  };

  // ---------- creating graphic frames ----------
  const newContent = (assetId, name) => model.create('rect', { name: name || t('Фото'), photo: true, w: 10, h: 10, fills: [Object.assign(O.paint.image(assetId), { mode: 'stretch' })], strokes: [] });
  // put a photo into a shape / frame / existing graphic frame (replaces the photo)
  PF.putInto = (target, assetId, fitKind) => {
    const parent = model.parent(target);
    let gf;
    if (PF.isFrame(target)) {
      const c = PF.contentOf(target);
      c.fills = [Object.assign(O.paint.image(assetId), { mode: 'stretch' })];
      c.adjust = c.adjust; // keep the photo corrections
      gf = target;
    } else if (target.type === 'frame') {
      gf = target;
      gf.gframe = true; gf.clip = true;
      gf.children.unshift(newContent(assetId));
    } else if (target.type === 'rect') {
      // the rectangle becomes the frame: same place, size, corners, stroke and effects
      gf = model.create('frame', { name: target.name, m: target.m.slice(), w: target.w, h: target.h, radius: target.radius || 0, strokes: target.strokes || [], sw: target.sw, sa: target.sa, dash: target.dash, effects: target.effects || [], opacity: target.opacity, blend: target.blend, fills: (target.fills || []).filter(f => f.type !== 'image'), clip: true, gframe: true });
      gf.children = [newContent(assetId)];
      parent.children.splice(parent.children.indexOf(target), 1, gf);
    } else {
      // round / polygon / star / path: a clipping group (first child is the frame shape)
      gf = model.create('group', { name: target.name, mask: true, gframe: true, m: M.id() });
      const shape = O.clone(target);
      gf.children = [shape, newContent(assetId)];
      parent.children.splice(parent.children.indexOf(target), 1, gf);
    }
    model.reindex();
    PF.fit(gf, fitKind || gf.lastFit || 'fill');
    return gf;
  };
  // an image-filled rectangle → frame + photo (keeps what was visible)
  PF.toFrame = n => {
    const f = imgFill(n);
    if (!f || n.photo) return null;
    const kind = { fit: 'fit', stretch: 'stretch' }[f.mode] || 'fill';
    const others = (n.fills || []).filter(x => x !== f);
    const gf = PF.putInto(n, f.asset, kind);
    if (gf && gf.type === 'frame') gf.fills = others;
    const c = PF.contentOf(gf);
    if (c && f.opacity !== undefined && f.opacity < 1) c.opacity = f.opacity;
    return gf;
  };
  // InDesign «Place»: one photo per selected frame / shape, the rest as new frames
  PF.place = async () => {
    const files = await io.pickFiles('image/*,' + io.EXTRA_MEDIA, true);
    if (!files.length) return;
    const targets = O.topSel().filter(n => PF.isFrame(n) || ['frame', 'rect', 'ellipse', 'polygon', 'star', 'path'].includes(n.type));
    const made = [];
    for (let i = 0; i < files.length; i++) {
      let data;
      try { data = await io.blobToData(files[i]); } catch (e) { continue; }
      let a;
      try { a = await io.addAsset(data, files[i].name.replace(/\.[^.]+$/, '')); } catch (e) { O.toast('Не вдалося відкрити «{name}»', { name: files[i].name }); continue; }
      let target = targets[i];
      if (!target) {
        // a new frame the size of the photo (fitted into the view), next to the previous one
        const vr = V.viewRect();
        const k = Math.min(1, vr.w * 0.6 / a.w, vr.h * 0.6 / a.h);
        const w = Math.round(a.w * k), h = Math.round(a.h * k);
        const c = R.center(vr);
        const off = made.length * 30;
        const cont = V.containerAt(c);
        const lp = M.apply(M.inv(model.containerMatrix(cont)), c);
        target = model.create('frame', { name: files[i].name.replace(/\.[^.]+$/, ''), w, h, m: M.translate(Math.round(lp.x - w / 2 + off), Math.round(lp.y - h / 2 + off)), fills: [], clip: true });
        model.insert(target, cont);
      }
      made.push(PF.putInto(target, a.id, 'fill'));
    }
    O.select(made.map(g => g.id));
    O.history.commit('Помістити фото');
    O.toast('Фото у фреймах: {n}. Подвійний клік або ◎ — рухати фото всередині фрейма', { n: made.length });
  };
  // new photos arrive as frame + photo (setting, on by default)
  {
    const orig = io.importImage;
    io.importImage = async (file, at) => {
      const n = await orig(file, at);
      if (!n || S.settings.photoFrames === false || O.projects && O.projects.disabled) return n;
      const gf = PF.toFrame(n);
      if (!gf) return n;
      O.select([gf.id]);
      O.history.commit('Фото-фрейм');
      return gf;
    };
  }

  // a graphic frame holds only its photo: new objects (drawn, pasted, dropped) go to the frame's parent
  {
    const orig = V.containerAt;
    V.containerAt = (...a) => { let c = orig(...a); while (c && c.gframe && !model.isPage(c)) c = model.parent(c) || model.page(); return c; };
  }

  // ---------- auto-fit: refit when the frame is resized ----------
  {
    const H = O.history, orig = H.commit;
    H.commit = label => {
      try {
        if (S.doc) for (const pg of S.doc.pages) model.walk(pg.children, n => {
          if (!PF.isFrame(n) || !n.autoFit) return;
          const B = PF.box(n), F = n.fitBox;
          if (!F || Math.abs(F.w - B.w) > 0.01 || Math.abs(F.h - B.h) > 0.01) PF.fit(n, n.lastFit || 'fill');
        });
      } catch (e) { console.error(e); }
      return orig(label);
    };
  }

  // ---------- content grabber ◎ and the ghost of the cropped part ----------
  let layer = null, drag = null;
  const ensureLayer = () => {
    if (layer && layer.isConnected) return layer;
    layer = O.h('<div id="pf-layer"></div>');
    V.el.appendChild(layer);
    layer.addEventListener('pointerdown', e => {
      const b = e.target.closest('[data-pf]');
      if (!b) return;
      e.preventDefault(); e.stopPropagation();
      const gf = model.get(b.dataset.pf), c = PF.contentOf(gf);
      if (!c) return;
      const P = M.inv(M.mul(model.worldMatrix(gf), gf.type === 'frame' ? M.id() : M.id()));
      drag = { c, gf, x0: e.clientX, y0: e.clientY, m0: c.m.slice(), P };
      try { b.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      O.select([c.id]);
    });
    layer.addEventListener('pointermove', e => {
      if (!drag) return;
      const d = M.applyV(drag.P, { x: (e.clientX - drag.x0) / V.zoom, y: (e.clientY - drag.y0) / V.zoom });
      drag.c.m = drag.m0.slice(); drag.c.m[4] += d.x; drag.c.m[5] += d.y;
      O.requestRender();
    });
    const end = () => { if (!drag) return; drag = null; O.history.commit('Положення фото у фреймі'); };
    layer.addEventListener('pointerup', end);
    layer.addEventListener('pointercancel', end);
    layer.addEventListener('dblclick', e => { const b = e.target.closest('[data-pf]'); if (b) { const gf = model.get(b.dataset.pf); O.select([gf.id]); } });
    return layer;
  };
  O.overlayHooks.push(Vm => {
    if (!S.doc || !V.el) return '';
    const L = ensureLayer();
    const sel = O.sel();
    let s = '', grab = '';
    for (const n of sel.slice(0, 20)) {
      const gf = PF.frameOf(n);
      if (!gf || model.pageOf(gf) !== model.page()) continue;
      const c = PF.contentOf(gf);
      const W = M.mul(Vm, model.worldMatrix(c));
      // the whole photo, also the part hidden by the frame (InDesign shows it when the content is selected)
      if (n === c || drag) {
        const f = imgFill(c);
        const url = f ? O.assetURL(f.asset) : '';
        if (url) s += `<image href="${esc(url)}" width="${n_(c.w)}" height="${n_(c.h)}" preserveAspectRatio="none" transform="${M.str(W)}" opacity="0.35" pointer-events="none"/>`;
        const pts = R.corners({ x: 0, y: 0, w: c.w, h: c.h }).map(p => M.apply(W, p));
        s += `<polygon points="${pts.map(p => n_(p.x) + ',' + n_(p.y)).join(' ')}" fill="none" stroke="#E8833A" stroke-width="1.5" pointer-events="none"/>`;
      }
      // grabber in the middle of the frame
      const b = model.worldBounds(gf);
      const cc = V.toScreen({ x: b.x + b.w / 2, y: b.y + b.h / 2 });
      if (b.w * V.zoom > 40 && b.h * V.zoom > 40) grab += `<button type="button" class="pf-grab${n === c ? ' on' : ''}" data-pf="${gf.id}" style="left:${n_(cc.x)}px;top:${n_(cc.y)}px" title="${esc(t('Тягніть, щоб рухати фото всередині фрейма. Подвійний клік — виділити фрейм'))}" aria-label="${esc(t('Рухати фото у фреймі'))}"></button>`;
    }
    if (L.innerHTML !== grab) L.innerHTML = grab;
    return s;
  });

  // ---------- photo adjustments (rendered as SVG filters; CSS filter in HTML) ----------
  PF.ADJ = [['b', 'Яскравість фото', -100, 100], ['c', 'Контраст', -100, 100], ['s', 'Насиченість', -100, 100], ['h', 'Тон', -180, 180], ['gray', 'Чорно-біле', 0, 100], ['sepia', 'Сепія', 0, 100]];
  const hasAdj = a => a && PF.ADJ.some(([k]) => a[k]);
  O.photoAdjustPrims = n => {
    const a = n.adjust;
    if (!hasAdj(a)) return '';
    let p = '', src = 'SourceGraphic', i = 0;
    const step = prim => { const r = 'pa' + (i++); p += prim.replace('IN', src).replace('OUT', r); src = r; };
    if (a.b) { const k = 1 + a.b / 100; step(`<feComponentTransfer in="IN" result="OUT"><feFuncR type="linear" slope="${n_(k)}"/><feFuncG type="linear" slope="${n_(k)}"/><feFuncB type="linear" slope="${n_(k)}"/></feComponentTransfer>`); }
    if (a.c) { const k = 1 + a.c / 100, b = 0.5 - 0.5 * k; step(`<feComponentTransfer in="IN" result="OUT"><feFuncR type="linear" slope="${n_(k)}" intercept="${n_(b)}"/><feFuncG type="linear" slope="${n_(k)}" intercept="${n_(b)}"/><feFuncB type="linear" slope="${n_(k)}" intercept="${n_(b)}"/></feComponentTransfer>`); }
    if (a.s || a.gray) step(`<feColorMatrix in="IN" type="saturate" values="${n_(Math.max(0, (1 + (a.s || 0) / 100) * (1 - (a.gray || 0) / 100)))}" result="OUT"/>`);
    if (a.h) step(`<feColorMatrix in="IN" type="hueRotate" values="${n_(a.h)}" result="OUT"/>`);
    if (a.sepia) {
      const k = a.sepia / 100, m = (x, y) => n_(x + (y - x) * k);
      step(`<feColorMatrix in="IN" type="matrix" values="${m(1, 0.393)} ${m(0, 0.769)} ${m(0, 0.189)} 0 0 ${m(0, 0.349)} ${m(1, 0.686)} ${m(0, 0.168)} 0 0 ${m(0, 0.272)} ${m(0, 0.534)} ${m(1, 0.131)} 0 0 0 0 0 1 0" result="OUT"/>`);
    }
    // the last result is named «adj» for the effect chain
    return p.replace(new RegExp(`result="${src}"`), 'result="adj"');
  };
  PF.cssFilter = a => !hasAdj(a) ? '' : [a.b ? `brightness(${O.fmt(1 + a.b / 100, 2)})` : '', a.c ? `contrast(${O.fmt(1 + a.c / 100, 2)})` : '', a.s ? `saturate(${O.fmt(1 + a.s / 100, 2)})` : '', a.h ? `hue-rotate(${a.h}deg)` : '', a.gray ? `grayscale(${a.gray}%)` : '', a.sepia ? `sepia(${a.sepia}%)` : ''].filter(Boolean).join(' ');

  // ---------- Design panel ----------
  const target = () => { const n = O.sel()[0]; if (!n) return null; const gf = PF.frameOf(n); return gf ? { gf, c: PF.contentOf(gf), n } : (imgFill(n) ? { gf: null, c: n, n } : null); };
  O.panels.extraSections.push(nodes => {
    if (nodes.length !== 1) return '';
    const tg = target();
    if (!tg) return '';
    let h = '';
    if (tg.gf) {
      const c = tg.c, a = assetOf(c) || {};
      const sc = a.w ? Math.round(c.w / a.w * 1000) / 10 : 100;
      const ppi = a.w ? Math.round(a.w / (c.w / 72)) : 0;
      const fits = PF.FITS.map(([k, l]) => `<button type="button" class="btn pf-fit" data-pfa="fit-${k}" title="${esc(t(l))}">${esc(t(l))}</button>`).join('');
      h += ph.sec('Фото-фрейм (InDesign)', `<div class="row note">${esc(t(tg.n === c ? 'Виділено вміст (фото). Рухайте й масштабуйте його всередині фрейма.' : 'Виділено фрейм. Розмір фрейма обрізає фото, вміст не змінюється.'))}</div>
        <div class="row"><button type="button" class="btn" data-pfa="toggle">${esc(t(tg.n === c ? 'Виділити фрейм' : 'Виділити вміст'))}</button><button type="button" class="btn" data-pfa="replace">${esc(t('Замінити фото…'))}</button></div>
        <div class="pf-fits">${fits}</div>
        <div class="row"><label class="chk"><input type="checkbox" data-pfc="auto"${tg.gf.autoFit ? ' checked' : ''}><span>${esc(t('Автопідгонка при зміні розміру фрейма'))}</span></label></div>
        <div class="grid2">${ph.inp('data-pfc="scale"', O.fmt(sc, 1), 'Масштаб фото', '%')}${ph.inp('data-pfc="rot"', O.fmt(-O.deg(M.decompose(c.m).rot), 1), 'Поворот фото', '°')}</div>
        <div class="grid2">${ph.inp('data-pfc="x"', O.fmt(c.m[4], 1), 'Зсув X')}${ph.inp('data-pfc="y"', O.fmt(c.m[5], 1), 'Зсув Y')}</div>
        ${ppi ? `<div class="row note${ppi < 150 ? ' warn' : ''}">${esc(t('Ефективна роздільна здатність: {p} ppi', { p: ppi }))}${ppi < 150 ? ' · ' + esc(t('замало для друку')) : ''}</div>` : ''}`);
    } else {
      h += ph.sec('Фото', `<div class="row"><button type="button" class="btn" data-pfa="toframe">${esc(t('Розділити на фрейм і фото (2 шари)'))}</button></div>`);
    }
    const adj = tg.c.adjust || {};
    h += ph.sec('Корекція фото', PF.ADJ.map(([k, l, mn, mx]) => `<label class="pf-adj"><span>${esc(t(l))}</span><input type="range" min="${mn}" max="${mx}" step="1" value="${adj[k] || 0}" data-pfadj="${k}" aria-label="${esc(t(l))}"><em>${adj[k] || 0}</em></label>`).join('') + (hasAdj(adj) ? `<div class="row"><button type="button" class="btn" data-pfa="adjreset">${esc(t('Скинути корекцію'))}</button></div>` : ''));
    return h;
  });
  document.addEventListener('input', e => {
    const el = e.target;
    if (!el.dataset || !el.dataset.pfadj || !ph.inProps(el)) return;
    const tg = target(); if (!tg) return;
    tg.c.adjust = Object.assign({}, tg.c.adjust, { [el.dataset.pfadj]: +el.value });
    el.nextElementSibling.textContent = el.value;
    O.requestRender();
  });
  document.addEventListener('change', e => {
    const el = e.target;
    if (!el.dataset || !ph.inProps(el)) return;
    const tg = target(); if (!tg) return;
    if (el.dataset.pfadj) { tg.c.adjust = Object.assign({}, tg.c.adjust, { [el.dataset.pfadj]: +el.value }); O.history.commit('Корекція фото'); return; }
    const k = el.dataset.pfc;
    if (!k || !tg.gf) return;
    const c = tg.c, v = parseFloat(el.value);
    if (k === 'auto') { tg.gf.autoFit = el.checked; tg.gf.fitBox = PF.box(tg.gf); }
    else if (!isFinite(v)) return;
    if (k === 'scale') { const a = assetOf(c) || { w: c.w, h: c.h }; const cx = c.m[4] + c.w / 2, cy = c.m[5] + c.h / 2; const w = a.w * v / 100, hh = (a.h || c.h) * v / 100; setContent(c, cx - w / 2, cy - hh / 2, w, hh); }
    if (k === 'rot') { const d = M.decompose(c.m); c.m = M.chain(M.translate(d.tx, d.ty), M.rotate(-O.rad(v))); }
    if (k === 'x') c.m[4] = v;
    if (k === 'y') c.m[5] = v;
    O.history.commit('Фото у фреймі');
  });
  document.addEventListener('click', async e => {
    const b = e.target.closest && e.target.closest('button[data-pfa]');
    if (!b || !ph.inProps(b)) return;
    const tg = target(); if (!tg) return;
    const a = b.dataset.pfa;
    if (a.startsWith('fit-')) { PF.fit(tg.gf, a.slice(4)); O.history.commit('Підгонка фото'); }
    if (a === 'toggle') O.select([tg.n === tg.c ? tg.gf.id : tg.c.id]);
    if (a === 'toframe') { const gf = PF.toFrame(tg.c); if (gf) { O.select([gf.id]); O.history.commit('Фото-фрейм'); } }
    if (a === 'adjreset') { delete tg.c.adjust; O.history.commit('Корекція фото'); }
    if (a === 'replace') {
      const f = (await io.pickFiles('image/*,' + io.EXTRA_MEDIA, false))[0];
      if (!f) return;
      const asset = await io.addAsset(await io.blobToData(f), f.name.replace(/\.[^.]+$/, ''));
      PF.putInto(tg.gf, asset.id, tg.gf.lastFit || 'fill');
      O.history.commit('Замінити фото');
    }
  });

  // ---------- commands ----------
  const gfSel = () => O.sel().map(PF.frameOf).filter(Boolean);
  const fitCmd = kind => () => { const list = gfSel(); if (!list.length) return O.toast('Виділіть фото-фрейм'); list.forEach(g => PF.fit(g, kind)); O.history.commit('Підгонка фото'); };
  O.cmd('placePhoto', 'Помістити фото у фрейм…', () => PF.place(), { keys: ['Ctrl+Alt+Shift+I'], group: 'Фото' });
  O.cmd('photoFill', 'Заповнити фрейм пропорційно', fitCmd('fill'), { keys: ['Ctrl+Alt+Shift+C'], group: 'Фото' });
  O.cmd('photoFit', 'Вписати вміст пропорційно', fitCmd('fit'), { keys: ['Ctrl+Alt+Shift+E'], group: 'Фото' });
  O.cmd('photoStretch', 'Вписати вміст у фрейм', fitCmd('stretch'), { group: 'Фото' });
  O.cmd('photoFrameToContent', 'Підігнати фрейм під вміст', fitCmd('frame'), { group: 'Фото' });
  O.cmd('photoCenter', 'Центрувати вміст', fitCmd('center'), { group: 'Фото' });
  O.cmd('photoContent', 'Виділити вміст / фрейм', () => { const n = O.sel()[0], gf = PF.frameOf(n); if (!gf) return O.toast('Виділіть фото-фрейм'); O.select([n === gf ? PF.contentOf(gf).id : gf.id]); }, { group: 'Фото' });
  O.cmd('photoToFrame', 'Розділити на фрейм і фото (2 шари)', () => { const out = O.topSel().map(PF.toFrame).filter(Boolean); if (!out.length) return O.toast('Виділіть зображення'); O.select(out.map(g => g.id)); O.history.commit('Фото-фрейм'); }, { group: 'Фото' });
  O.cmd('photoFramesSetting', 'Нові фото — у фрейм (як в InDesign)', () => { S.settings.photoFrames = S.settings.photoFrames === false; O.saveSettings(); }, { group: 'Фото', check: () => S.settings.photoFrames !== false });
  const objMenu = O.MENUS.find(m => m[0] === 'Об’єкт');
  if (objMenu) objMenu[1].splice(objMenu[1].indexOf('rasterize'), 0, { label: 'Фото (InDesign)', items: ['placePhoto', '-', 'photoFill', 'photoFit', 'photoStretch', 'photoFrameToContent', 'photoCenter', '-', 'photoContent', 'photoToFrame', '-', 'photoFramesSetting'] }, '-');
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл')[1];
  fileMenu.splice(fileMenu.indexOf('placeImage') + 1, 0, 'placePhoto');
})();
