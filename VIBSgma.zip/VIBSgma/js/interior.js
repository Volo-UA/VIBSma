'use strict';
/* Obrys — interior design styles: 20 styles (minimalism … Mediterranean) with palettes, font pairs,
   procedural material textures (wood, concrete, brick, marble, linen, rattan, terracotta …),
   style effects for the selection (palette recolour, fonts, photo look, materials) and templates:
   a mood board and a room scene (wall elevation with window, sofa, lamp, plants, art) per style. */
(function () {
  const O = window.O, S = O.state, model = O.model, ui = O.ui, V = O.view, M = O.M, G = O.geom;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const IN = O.interior = {};
  const P = O.paint;

  // ======================================================================
  // MATERIALS (procedural, tileable textures)
  // ======================================================================
  const SZ = 384;
  const rng = seed => { let s = seed >>> 0 || 1; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; };
  // tileable value noise on a period of `per` cells
  const mkNoise = (seed, per) => {
    const r = rng(seed), g = new Float32Array(per * per).map(() => r());
    const sm = x => x * x * (3 - 2 * x);
    return (x, y) => {
      const xi = Math.floor(x), yi = Math.floor(y), xf = sm(x - xi), yf = sm(y - yi);
      const a = (i, j) => g[(((j % per) + per) % per) * per + (((i % per) + per) % per)];
      const v0 = a(xi, yi) + (a(xi + 1, yi) - a(xi, yi)) * xf, v1 = a(xi, yi + 1) + (a(xi + 1, yi + 1) - a(xi, yi + 1)) * xf;
      return v0 + (v1 - v0) * yf;
    };
  };
  const fbm = (n, x, y, oct = 4) => { let v = 0, amp = 0.5, f = 1, tot = 0; for (let i = 0; i < oct; i++) { v += n(x * f, y * f) * amp; tot += amp; amp *= 0.5; f *= 2; } return v / tot; };
  const hex = c => { const h = c.replace('#', ''); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; };
  const mix = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
  const pixels = (ctx, fn) => { const id = ctx.createImageData(SZ, SZ), d = id.data; for (let y = 0; y < SZ; y++) for (let x = 0; x < SZ; x++) { const c = fn(x, y), i = (y * SZ + x) * 4; d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255; } ctx.putImageData(id, 0, 0); };
  const wood = (light, dark, opts = {}) => (ctx, r) => {
    const n = mkNoise(Math.floor(r() * 1e6), 16), L = hex(light), D = hex(dark);
    const rows = opts.rows || 6, ph = SZ / rows;
    const tone = Array.from({ length: rows * 3 }, () => (r() - 0.5) * 0.25);
    const off = Array.from({ length: rows }, () => r() * SZ);
    pixels(ctx, (x, y) => {
      const row = Math.floor(y / ph);
      const xx = (x + off[row]) % SZ, seg = Math.floor(xx / (SZ / 1.5)) % 3;
      const g = fbm(n, xx / SZ * 16, (y / SZ) * 16 * 0.15 + row * 3.3, 3);
      let v = 0.5 + 0.5 * Math.sin((y / SZ * 16 * 9 + g * 14) * 1.3);
      v = Math.pow(v, 2.2) * 0.55 + g * 0.45 + tone[row * 3 + seg];
      if (opts.knots) { const kx = (row * 97) % SZ, ky = row * ph + ph / 2, dd = Math.hypot((xx - kx) * 0.6, y - ky); if (dd < 10) v += (10 - dd) / 14; }
      let c = mix(L, D, Math.max(0, Math.min(1, v)));
      const edge = y % ph < 1.2 || (xx % (SZ / 1.5)) < 1.2;
      if (edge) c = mix(c, D, 0.55);
      return c;
    });
  };
  const noiseTex = (a, b, scale, opts = {}) => (ctx, r) => {
    const n = mkNoise(Math.floor(r() * 1e6), 32), A = hex(a), B = hex(b);
    pixels(ctx, (x, y) => { let v = fbm(n, x / SZ * scale, y / SZ * scale, opts.oct || 5); if (opts.pow) v = Math.pow(v, opts.pow); return mix(A, B, Math.max(0, Math.min(1, (v - 0.3) * 2.2))); });
    if (opts.pores) { for (let i = 0; i < opts.pores; i++) { ctx.fillStyle = `rgba(0,0,0,${0.15 + r() * 0.25})`; ctx.beginPath(); ctx.arc(r() * SZ, r() * SZ, 0.6 + r() * 1.6, 0, Math.PI * 2); ctx.fill(); } }
    if (opts.streaks) { for (let i = 0; i < opts.streaks; i++) { ctx.fillStyle = `rgba(90,70,50,${0.08 + r() * 0.12})`; ctx.fillRect(r() * SZ, r() * SZ, 8 + r() * 30, 1 + r() * 2); } }
  };
  const marble = (base, vein, opts = {}) => (ctx, r) => {
    const n = mkNoise(Math.floor(r() * 1e6), 16), A = hex(base), B = hex(vein);
    pixels(ctx, (x, y) => {
      const g = fbm(n, x / SZ * 6, y / SZ * 6, 5);
      const v = Math.abs(Math.sin((x / SZ + y / SZ) * Math.PI * 2 + g * 9));
      const k = Math.pow(1 - Math.min(1, v * (opts.sharp || 5)), 3) + g * 0.12;
      return mix(A, B, Math.min(1, k));
    });
  };
  const draw = fn => (ctx, r) => fn(ctx, r);
  const bricks = (brick, mortar, opts = {}) => draw((ctx, r) => {
    ctx.fillStyle = mortar; ctx.fillRect(0, 0, SZ, SZ);
    const bh = SZ / 8, bw = SZ / 4, m = 5;
    const n = mkNoise(7, 16);
    for (let row = 0; row < 8; row++) for (let col = -1; col < 5; col++) {
      const x = col * bw + (row % 2 ? bw / 2 : 0), y = row * bh;
      const c = mix(hex(brick), hex(opts.alt || brick), r()).map(v => v * (0.85 + r() * 0.25));
      ctx.fillStyle = `rgb(${c.map(Math.round).join(',')})`; ctx.fillRect(x + m / 2, y + m / 2, bw - m, bh - m);
    }
    const id = ctx.getImageData(0, 0, SZ, SZ);
    for (let i = 0; i < id.data.length; i += 4) { const p = i / 4, v = (fbm(n, (p % SZ) / SZ * 16, Math.floor(p / SZ) / SZ * 16, 3) - 0.5) * 50; id.data[i] += v; id.data[i + 1] += v; id.data[i + 2] += v; }
    ctx.putImageData(id, 0, 0);
  });
  const tiles = (cols, grout, opts = {}) => draw((ctx, r) => {
    ctx.fillStyle = grout; ctx.fillRect(0, 0, SZ, SZ);
    const n = opts.n || 4, s = SZ / n, g = opts.g || 4;
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const c = hex(cols[Math.floor(r() * cols.length)]).map(v => v * (0.88 + r() * 0.2));
      ctx.fillStyle = `rgb(${c.map(Math.round).join(',')})`;
      if (opts.hex) { ctx.beginPath(); for (let i = 0; i < 8; i++) { const a = Math.PI / 8 + i * Math.PI / 4; ctx.lineTo(x * s + s / 2 + Math.cos(a) * s * 0.52, y * s + s / 2 + Math.sin(a) * s * 0.52); } ctx.fill(); }
      else ctx.fillRect(x * s + g / 2, y * s + g / 2, s - g, s - g);
      if (opts.motif) { ctx.save(); ctx.translate(x * s + s / 2, y * s + s / 2); ctx.strokeStyle = opts.motif; ctx.lineWidth = 3; for (let i = 0; i < 4; i++) { ctx.rotate(Math.PI / 2); ctx.beginPath(); ctx.arc(s * 0.25, s * 0.25, s * 0.18, 0, Math.PI * 2); ctx.stroke(); } ctx.beginPath(); ctx.arc(0, 0, s * 0.12, 0, Math.PI * 2); ctx.fillStyle = opts.motif; ctx.fill(); ctx.restore(); }
    }
  });
  const weave = (a, b, opts = {}) => draw((ctx, r) => {
    ctx.fillStyle = a; ctx.fillRect(0, 0, SZ, SZ);
    const st = opts.step || 4;
    for (let y = 0; y < SZ; y += st) { ctx.fillStyle = `rgba(${hex(b).join(',')},${0.12 + r() * 0.18})`; ctx.fillRect(0, y, SZ, 1); }
    for (let x = 0; x < SZ; x += st) { ctx.fillStyle = `rgba(${hex(b).join(',')},${0.1 + r() * 0.15})`; ctx.fillRect(x, 0, 1, SZ); }
    for (let i = 0; i < 2600; i++) { ctx.fillStyle = `rgba(255,255,255,${r() * 0.08})`; ctx.fillRect(r() * SZ, r() * SZ, 2 + r() * 6, 1); }
  });
  const TEX = {
    oak: ['Світлий дуб', wood('#E2C9A0', '#B88A57')],
    walnut: ['Горіх', wood('#7A5235', '#3E2716')],
    pine: ['Сосна з сучками', wood('#E8C690', '#A8733F', { knots: true, rows: 4 })],
    whitewood: ['Біле дерево', wood('#F1EEE8', '#CFC8BC', { rows: 5 })],
    ashgray: ['Сірий ясен', wood('#CFC7BD', '#8F857A')],
    herringbone: ['Ялинка (паркет)', draw((ctx, r) => { ctx.fillStyle = '#9C6E43'; ctx.fillRect(0, 0, SZ, SZ); const w = SZ / 8, l = SZ / 2.67; for (let y = -SZ; y < SZ * 2; y += w * 2) for (let x = -SZ; x < SZ * 2; x += l + w) { for (const s of [1, -1]) { ctx.save(); ctx.translate(x + (s < 0 ? l * 0.72 : 0), y); ctx.rotate(s * Math.PI / 4); const c = mix(hex('#C9965F'), hex('#8A5A33'), r()); ctx.fillStyle = `rgb(${c.map(Math.round).join(',')})`; ctx.fillRect(0, 0, l, w - 2); ctx.restore(); } } })],
    concrete: ['Бетон', noiseTex('#B9B6B0', '#7E7B75', 10, { pores: 900 })],
    microcement: ['Мікроцемент', noiseTex('#D8D2C8', '#B5AC9F', 3, { oct: 6 })],
    plaster: ['Венеційська штукатурка', noiseTex('#EFE6D8', '#CDBEA8', 2.5, { oct: 6, pow: 1.4 })],
    travertine: ['Травертин', noiseTex('#E5D6BD', '#C2AD8B', 6, { streaks: 260 })],
    brick: ['Червона цегла', bricks('#9A4B32', '#CDBFAE', { alt: '#B5603E' })],
    whitebrick: ['Біла цегла', bricks('#ECEAE5', '#D3CEC5', { alt: '#DEDAD2' })],
    stone: ['Природний камінь', draw((ctx, r) => { ctx.fillStyle = '#6F6A63'; ctx.fillRect(0, 0, SZ, SZ); for (let i = 0; i < 70; i++) { const w = 40 + r() * 70, h = 26 + r() * 40, x = r() * SZ, y = r() * SZ, c = mix(hex('#A69E92'), hex('#7C756C'), r()); for (const [dx, dy] of [[0, 0], [-SZ, 0], [0, -SZ], [-SZ, -SZ]]) { ctx.fillStyle = `rgb(${c.map(Math.round).join(',')})`; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x + dx, y + dy, w, h, 12) : ctx.rect(x + dx, y + dy, w, h); ctx.fill(); } } })],
    marble: ['Білий мармур', marble('#F3F1EE', '#9C9A98')],
    blackmarble: ['Чорний мармур', marble('#1E1E20', '#C9A85A', { sharp: 9 })],
    greenmarble: ['Зелений мармур', marble('#1F4A3C', '#D9E2DA', { sharp: 6 })],
    terrazzo: ['Тераццо', draw((ctx, r) => { ctx.fillStyle = '#EFEAE2'; ctx.fillRect(0, 0, SZ, SZ); const cols = ['#C96F4A', '#7A8C7E', '#2F3A4A', '#E2B34C', '#B9B2A6']; for (let i = 0; i < 260; i++) { const x = r() * SZ, y = r() * SZ, s = 3 + r() * 9; ctx.fillStyle = cols[Math.floor(r() * cols.length)]; ctx.beginPath(); for (let k = 0; k < 5; k++) { const a = k / 5 * Math.PI * 2 + r(); ctx.lineTo(x + Math.cos(a) * s * (0.6 + r() * 0.5), y + Math.sin(a) * s * (0.6 + r() * 0.5)); } ctx.fill(); } })],
    terracotta: ['Теракотова плитка', tiles(['#B85C38', '#C46B43', '#A9512F', '#CC7A50'], '#E6D3BC')],
    cement: ['Цементна плитка', tiles(['#F2EDE4'], '#D8D0C2', { n: 3, motif: '#2E5A73' })],
    zellige: ['Зелліж', tiles(['#2E7D8C', '#2A6F7D', '#3B8C99', '#286878'], '#E8E2D6', { n: 6, g: 3 })],
    linen: ['Льон', weave('#E7DED0', '#9B8C76')],
    jute: ['Джут / сизаль', draw((ctx, r) => { ctx.fillStyle = '#C6A97A'; ctx.fillRect(0, 0, SZ, SZ); for (let y = 0; y < SZ; y += 8) for (let x = 0; x < SZ; x += 8) { ctx.strokeStyle = `rgba(110,80,40,${0.3 + r() * 0.3})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x + ((y / 8) % 2 ? 4 : 0), y + 4, 4, 3, 0, 0, Math.PI * 2); ctx.stroke(); } })],
    rattan: ['Ротанг (віденське плетіння)', draw((ctx) => { ctx.fillStyle = '#3A2A1C'; ctx.fillRect(0, 0, SZ, SZ); const s = SZ / 12; ctx.strokeStyle = '#D9B47A'; ctx.lineWidth = 3.2; for (let i = -12; i <= 24; i++) { ctx.beginPath(); ctx.moveTo(i * s, 0); ctx.lineTo(i * s, SZ); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, i * s); ctx.lineTo(SZ, i * s); ctx.stroke(); ctx.beginPath(); ctx.moveTo(i * s, 0); ctx.lineTo(i * s + SZ, SZ); ctx.stroke(); ctx.beginPath(); ctx.moveTo(i * s, 0); ctx.lineTo(i * s - SZ, SZ); ctx.stroke(); } })],
    velvet: ['Оксамит смарагдовий', noiseTex('#0F5944', '#2E8C6E', 2, { oct: 3 })],
    velvetpink: ['Оксамит пудровий', noiseTex('#C98F8F', '#E8B7B0', 2, { oct: 3 })],
    boucle: ['Букле', draw((ctx, r) => { ctx.fillStyle = '#EDE7DC'; ctx.fillRect(0, 0, SZ, SZ); for (let i = 0; i < 5200; i++) { ctx.strokeStyle = `rgba(${r() > 0.5 ? '255,255,255' : '170,160,145'},${0.35 + r() * 0.4})`; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(r() * SZ, r() * SZ, 1.5 + r() * 2.5, 0, Math.PI * 2); ctx.stroke(); } })],
    fur: ['Овчина', draw((ctx, r) => { ctx.fillStyle = '#E9E1D2'; ctx.fillRect(0, 0, SZ, SZ); for (let i = 0; i < 6000; i++) { const x = r() * SZ, y = r() * SZ, a = r() * Math.PI * 2, l = 6 + r() * 10; ctx.strokeStyle = `rgba(${r() > 0.5 ? '255,252,245' : '196,184,165'},.6)`; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + Math.cos(a) * l, y + Math.sin(a) * l * 0.5, x + Math.cos(a + 0.6) * l, y + Math.sin(a + 0.6) * l); ctx.stroke(); } })],
    steel: ['Шліфована сталь', draw((ctx, r) => { const n = mkNoise(5, 64); pixels(ctx, (x, y) => { const v = 175 + (fbm(n, x / SZ * 2, y / SZ * 64, 3) - 0.5) * 70; return [v, v + 2, v + 5]; }); })],
    brass: ['Латунь', draw((ctx, r) => { const n = mkNoise(9, 64); pixels(ctx, (x, y) => { const v = (fbm(n, x / SZ * 2, y / SZ * 64, 3) - 0.5) * 60; return [196 + v, 160 + v, 90 + v * 0.6]; }); })],
    blackmetal: ['Чорний метал', noiseTex('#2A2A2C', '#3C3C40', 20, { oct: 3 })],
    fluted: ['Рифлене скло', draw((ctx) => { const w = SZ / 24; for (let i = 0; i < 24; i++) { const g = ctx.createLinearGradient(i * w, 0, i * w + w, 0); g.addColorStop(0, '#C8D6DC'); g.addColorStop(0.5, '#EEF4F6'); g.addColorStop(1, '#AFC1C8'); ctx.fillStyle = g; ctx.fillRect(i * w, 0, w, SZ); } })],
    boiserie: ['Буазері (стінові панелі)', draw((ctx) => { ctx.fillStyle = '#EDE6DA'; ctx.fillRect(0, 0, SZ, SZ); const pnl = (x, y, w, h) => { ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 3; ctx.strokeRect(x, y, w, h); ctx.strokeStyle = 'rgba(150,135,110,.55)'; ctx.lineWidth = 2; ctx.strokeRect(x + 3, y + 3, w - 6, h - 6); }; pnl(24, 24, SZ / 2 - 48, SZ * 0.55); pnl(SZ / 2 + 24, 24, SZ / 2 - 48, SZ * 0.55); pnl(24, SZ * 0.55 + 60, SZ / 2 - 48, SZ * 0.45 - 84); pnl(SZ / 2 + 24, SZ * 0.55 + 60, SZ / 2 - 48, SZ * 0.45 - 84); })],
    plaid: ['Клітинка (тартан)', draw((ctx) => { ctx.fillStyle = '#EFE6D2'; ctx.fillRect(0, 0, SZ, SZ); const band = (pos, w, col, a) => { ctx.fillStyle = col; ctx.globalAlpha = a; ctx.fillRect(pos, 0, w, SZ); ctx.fillRect(0, pos, SZ, w); ctx.globalAlpha = 1; }; for (const o of [0, SZ / 2]) { band(o + 20, 70, '#8E2B24', 0.55); band(o + 110, 18, '#1F3B2D', 0.6); band(o + 150, 6, '#E2B34C', 0.8); } })],
    stripes: ['Морська смужка', draw((ctx) => { ctx.fillStyle = '#F7F5EF'; ctx.fillRect(0, 0, SZ, SZ); ctx.fillStyle = '#1F3A5F'; for (let x = 0; x < SZ; x += SZ / 8) ctx.fillRect(x, 0, SZ / 16, SZ); })],
    floral: ['Квітковий принт (Прованс)', draw((ctx, r) => { ctx.fillStyle = '#F6F1E7'; ctx.fillRect(0, 0, SZ, SZ); const flower = (x, y, s, c) => { ctx.fillStyle = c; for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2; ctx.beginPath(); ctx.ellipse(x + Math.cos(a) * s, y + Math.sin(a) * s, s * 0.8, s * 0.5, a, 0, Math.PI * 2); ctx.fill(); } ctx.fillStyle = '#E8C766'; ctx.beginPath(); ctx.arc(x, y, s * 0.45, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#8BA57E'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, y + s * 1.2); ctx.quadraticCurveTo(x + s * 1.5, y + s * 2, x + s * 0.6, y + s * 3); ctx.stroke(); }; const s = SZ / 4; for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) flower(x * s + (y % 2 ? s / 2 : s / 4), y * s + s / 3, 9 + r() * 4, ['#B7A3D6', '#9C86C4', '#D9A7B8'][Math.floor(r() * 3)]); })],
    artdeco: ['Арт-деко віяла', draw((ctx) => { ctx.fillStyle = '#121214'; ctx.fillRect(0, 0, SZ, SZ); const s = SZ / 6; ctx.strokeStyle = '#C9A85A'; ctx.lineWidth = 2; for (let row = -1; row < 13; row++) for (let col = -1; col < 8; col++) { const x = col * s + (row % 2 ? s / 2 : 0), y = row * s / 2; for (let k = 1; k <= 4; k++) { ctx.beginPath(); ctx.arc(x, y, s / 2 * k / 4, Math.PI, 0); ctx.stroke(); } } })],
    kilim: ['Кілім (етно)', draw((ctx) => { const cols = ['#B5482F', '#D9A441', '#2F4F6F', '#EFE4CF', '#6B3E2E']; const h = SZ / 8; for (let row = 0; row < 8; row++) { ctx.fillStyle = cols[row % cols.length]; ctx.fillRect(0, row * h, SZ, h); ctx.fillStyle = cols[(row + 2) % cols.length]; for (let x = 0; x < SZ; x += h) { ctx.beginPath(); ctx.moveTo(x, row * h + h / 2); ctx.lineTo(x + h / 2, row * h + 4); ctx.lineTo(x + h, row * h + h / 2); ctx.lineTo(x + h / 2, row * h + h - 4); ctx.closePath(); ctx.fill(); } } })],
    leaves: ['Тропічне листя', draw((ctx, r) => { ctx.fillStyle = '#1E3B2F'; ctx.fillRect(0, 0, SZ, SZ); for (let i = 0; i < 40; i++) { const x = r() * SZ, y = r() * SZ, a = r() * Math.PI * 2, s = 22 + r() * 30; for (const [dx, dy] of [[0, 0], [SZ, 0], [-SZ, 0], [0, SZ], [0, -SZ]]) { ctx.save(); ctx.translate(x + dx, y + dy); ctx.rotate(a); ctx.fillStyle = ['#3E7A55', '#2F6446', '#5B9A6B'][i % 3]; ctx.beginPath(); ctx.ellipse(0, 0, s, s * 0.42, 0, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(-s, 0); ctx.lineTo(s, 0); ctx.stroke(); ctx.restore(); } } })],
    tatami: ['Татамі / рисовий папір', draw((ctx, r) => { ctx.fillStyle = '#D7CFA4'; ctx.fillRect(0, 0, SZ, SZ); for (let x = 0; x < SZ; x += 3) { ctx.fillStyle = `rgba(120,110,60,${0.1 + r() * 0.15})`; ctx.fillRect(x, 0, 1, SZ); } ctx.fillStyle = '#3C4A3A'; ctx.fillRect(0, 0, SZ, 10); ctx.fillRect(0, SZ / 2, SZ, 10); })]
  };
  IN.TEX = TEX;
  // texture → asset of the current document (made once per document)
  IN.texAsset = key => {
    const found = Object.entries(S.doc.assets).find(([, a]) => a && a.tex === key);
    if (found) return found[0];
    const def = TEX[key]; if (!def) return null;
    const cv = document.createElement('canvas'); cv.width = cv.height = SZ;
    def[1](cv.getContext('2d'), rng(key.split('').reduce((s, c) => s * 31 + c.charCodeAt(0), 7)));
    const id = O.uid();
    S.doc.assets[id] = { data: cv.toDataURL('image/jpeg', 0.9), w: SZ, h: SZ, name: t(def[0]), tex: key };
    return id;
  };
  const texPaint = (key, scale = 0.6) => Object.assign(P.image(IN.texAsset(key)), { mode: 'tile', scale });
  IN.texPaint = texPaint;
  const thumbs = new Map();
  const thumb = key => { if (!thumbs.has(key)) { const cv = document.createElement('canvas'); cv.width = cv.height = SZ; TEX[key][1](cv.getContext('2d'), rng(key.split('').reduce((s, c) => s * 31 + c.charCodeAt(0), 7))); const c2 = document.createElement('canvas'); c2.width = c2.height = 72; c2.getContext('2d').drawImage(cv, 0, 0, 72, 72); thumbs.set(key, c2.toDataURL('image/jpeg', 0.8)); } return thumbs.get(key); };

  // ======================================================================
  // STYLES
  // ======================================================================
  // pal: [wall, floor/wood, main furniture, accent 1, accent 2, dark]; room: scene description
  const ST = [
    { k: 'minimal', n: 'Мінімалізм', d: 'Прості лінії, багато вільного простору, нейтральні кольори та приховане зберігання.', pal: ['#F4F2EE', '#D9D4CC', '#BDB6AC', '#8C857B', '#2E2C29', '#FFFFFF'], f: ['Inter', 'Inter'], tex: ['microcement', 'oak', 'linen', 'steel'], kw: ['простір', 'порядок', 'нейтральні тони', 'приховане зберігання'], ph: { s: -20, c: 5, b: 4 }, room: { wall: '#F4F2EE', floor: 'microcement', win: 'large', winCol: '#2E2C29', sofa: 'boxy', sofaCol: '#D9D4CC', rug: '#E6E1D9', lamp: 'pendant', plant: 'small', art: 'line' } },
    { k: 'scandi', n: 'Скандинавський', d: 'Світлі відтінки (переважно білий), натуральне дерево, м’який текстиль і багато природного світла.', pal: ['#FFFFFF', '#E2C9A0', '#D7D2CA', '#A7B8A8', '#6E7F8D', '#3A3A3A'], f: ['Nunito Sans', 'Nunito Sans'], tex: ['oak', 'whitewood', 'linen', 'boucle'], kw: ['світло', 'дерево', 'хюґе', 'текстиль'], ph: { b: 8, s: -10 }, room: { wall: '#FBFAF7', floor: 'oak', win: 'large', winCol: '#FFFFFF', sofa: 'mid', sofaCol: '#D7D2CA', rug: 'boucle', lamp: 'globe', plant: 'big', art: 'gallery' } },
    { k: 'loft', n: 'Лофт (індустріальний)', d: 'Цегляні стіни, відкриті комунікації, бетон, метал і великі вікна.', pal: ['#9A4B32', '#7E7B75', '#3B3B3D', '#C9A15C', '#6B4A33', '#1E1E1F'], f: ['Oswald', 'Roboto'], tex: ['brick', 'concrete', 'blackmetal', 'walnut'], kw: ['цегла', 'бетон', 'метал', 'великі вікна', 'відкриті труби'], ph: { c: 18, s: -18 }, room: { wall: 'brick', floor: 'concrete', win: 'loft', winCol: '#1E1E1F', sofa: 'boxy', sofaCol: '#6B4A33', rug: '#3B3B3D', lamp: 'edison', plant: 'big', art: 'poster', pipes: true } },
    { k: 'hitech', n: 'Хай-тек', d: 'Строга геометрія, монохром, скло, метал та інтегровані системи «розумний дім».', pal: ['#E9ECEF', '#2B2D31', '#BFC5CC', '#0D99FF', '#6C7480', '#0E0F11'], f: ['Exo 2', 'Roboto'], tex: ['steel', 'fluted', 'blackmarble', 'concrete'], kw: ['скло', 'хром', 'монохром', 'смарт-дім', 'LED'], ph: { c: 12, s: -30, h: -8 }, room: { wall: '#E9ECEF', floor: '#2B2D31', win: 'panoramic', winCol: '#6C7480', sofa: 'boxy', sofaCol: '#BFC5CC', rug: '#0E0F11', lamp: 'led', plant: 'none', art: 'screen' } },
    { k: 'contemporary', n: 'Сучасний (Contemporary)', d: 'Функціональність, нейтральна палітра, м’які форми та гра фактур.', pal: ['#EEE9E2', '#C8B9A6', '#A39383', '#7B8B74', '#4C4A47', '#1F1E1C'], f: ['DM Sans', 'DM Sans'], tex: ['travertine', 'boucle', 'ashgray', 'brass'], kw: ['м’які форми', 'фактури', 'функціональність', 'нейтральність'], ph: { s: -8 }, room: { wall: '#EEE9E2', floor: 'ashgray', win: 'large', winCol: '#4C4A47', sofa: 'round', sofaCol: '#EDE7DC', rug: 'jute', lamp: 'arc', plant: 'big', art: 'abstract' } },
    { k: 'classic', n: 'Класичний', d: 'Симетрія, стримана розкіш, ліпнина, колони та благородні матеріали.', pal: ['#EDE6DA', '#7A5235', '#C9B79C', '#8C6D3F', '#5A2E2E', '#2B2420'], f: ['Playfair Display', 'Lora'], tex: ['boiserie', 'marble', 'walnut', 'herringbone'], kw: ['симетрія', 'ліпнина', 'колони', 'класичні пропорції'], ph: { c: 6, s: 4, sepia: 10 }, room: { wall: 'boiserie', floor: 'herringbone', win: 'classic', winCol: '#FFFFFF', sofa: 'tufted', sofaCol: '#5A2E2E', rug: '#8C6D3F', lamp: 'chandelier', plant: 'none', art: 'mirror', molding: true } },
    { k: 'artdeco', n: 'Арт-деко', d: 'Геометричні візерунки, блиск металу, дзеркала, оксамит і розкішні акценти.', pal: ['#0F5944', '#121214', '#C9A85A', '#E8D9B5', '#7A1F3D', '#1B1B1D'], f: ['Poiret One', 'Josefin Sans'], tex: ['artdeco', 'blackmarble', 'velvet', 'brass'], kw: ['геометрія', 'золото', 'оксамит', 'дзеркала', 'розкіш'], ph: { c: 14, s: 10 }, room: { wall: '#0F5944', floor: 'blackmarble', win: 'none', winCol: '#C9A85A', sofa: 'tufted', sofaCol: '#7A1F3D', rug: 'artdeco', lamp: 'fan', plant: 'none', art: 'sunburst' } },
    { k: 'eco', n: 'Еко-стиль', d: 'Натуральні матеріали, живі рослини, органічні форми та земна палітра.', pal: ['#E9E2D3', '#A0754A', '#7A8C5E', '#C9A37A', '#4E5B3A', '#3A2E22'], f: ['Quicksand', 'Nunito'], tex: ['pine', 'jute', 'linen', 'stone'], kw: ['рослини', 'дерево', 'льон', 'земляні тони'], ph: { s: -5, b: 3, h: 5 }, room: { wall: '#E9E2D3', floor: 'pine', win: 'large', winCol: '#A0754A', sofa: 'round', sofaCol: '#C9B79C', rug: 'jute', lamp: 'rattan', plant: 'jungle', art: 'botanical' } },
    { k: 'wabisabi', n: 'Вабі-сабі', d: 'Естетика неповноти, природна простота, грубі фактури та спокійні тони.', pal: ['#E8DFD1', '#B9A68C', '#8F7E69', '#6F675C', '#4A433B', '#2E2A25'], f: ['Cormorant Garamond', 'Karla'], tex: ['plaster', 'travertine', 'linen', 'ashgray'], kw: ['неповнота', 'тиша', 'глина', 'штукатурка', 'спокій'], ph: { s: -30, c: -6, sepia: 12 }, room: { wall: 'plaster', floor: 'microcement', win: 'arch', winCol: '#8F7E69', sofa: 'low', sofaCol: '#D8CCBB', rug: 'linen', lamp: 'paper', plant: 'branch', art: 'vase' } },
    { k: 'boho', n: 'Бохо', d: 'Еклектика, вінтажні речі, яскраві етнічні візерунки, килими та рослини.', pal: ['#F1E4D0', '#C46B43', '#D9A441', '#2F4F6F', '#7B8F5A', '#5A3524'], f: ['Amatic SC', 'Josefin Sans'], tex: ['kilim', 'rattan', 'jute', 'terracotta'], kw: ['етно', 'макраме', 'ротанг', 'вінтаж', 'рослини'], ph: { s: 12, h: 6, b: 4 }, room: { wall: '#F1E4D0', floor: 'oak', win: 'arch', winCol: '#C46B43', sofa: 'low', sofaCol: '#C46B43', rug: 'kilim', lamp: 'rattan', plant: 'jungle', art: 'macrame' } },
    { k: 'japandi', n: 'Жапанді', d: 'Поєднання японського та скандинавського стилів: мінімум речей, дерево та природна гармонія.', pal: ['#EFEAE2', '#C2A27C', '#8A7A66', '#5E6B5A', '#2F2C28', '#1B1A18'], f: ['Noto Serif JP', 'Noto Sans'], tex: ['ashgray', 'tatami', 'linen', 'walnut'], kw: ['гармонія', 'мінімум речей', 'дерево', 'папір', 'тиша'], ph: { s: -18, c: 4 }, room: { wall: '#EFEAE2', floor: 'ashgray', win: 'shoji', winCol: '#2F2C28', sofa: 'low', sofaCol: '#C9BBA6', rug: 'tatami', lamp: 'paper', plant: 'bonsai', art: 'ink' } },
    { k: 'provence', n: 'Прованс', d: 'Пастельні кольори, старі або штучно зістарені меблі, квіткові мотиви та кераміка.', pal: ['#F6F1E7', '#B7A3D6', '#C9D6C2', '#E8D9A8', '#8FA9C9', '#6A5D4D'], f: ['Libre Baskerville', 'Lato'], tex: ['floral', 'whitewood', 'terracotta', 'linen'], kw: ['лаванда', 'пастель', 'кераміка', 'зістарені меблі'], ph: { s: -12, b: 6, sepia: 8 }, room: { wall: 'floral', floor: 'terracotta', win: 'shutters', winCol: '#8FA9C9', sofa: 'round', sofaCol: '#F2ECDF', rug: '#C9D6C2', lamp: 'chandelier', plant: 'lavender', art: 'mirror' } },
    { k: 'country', n: 'Кантрі', d: 'Грубе дерево, клітинка, камін і відчуття заміського затишку.', pal: ['#EFE6D2', '#8A5A33', '#8E2B24', '#1F3B2D', '#C9A15C', '#3A2A1C'], f: ['Rye', 'Merriweather'], tex: ['pine', 'plaid', 'stone', 'whitewood'], kw: ['клітинка', 'камін', 'грубе дерево', 'затишок'], ph: { s: 5, sepia: 15, b: 2 }, room: { wall: 'whitewood', floor: 'pine', win: 'classic', winCol: '#8A5A33', sofa: 'tufted', sofaCol: '#8E2B24', rug: 'plaid', lamp: 'lantern', plant: 'small', art: 'antlers', fireplace: true, beams: true } },
    { k: 'midcentury', n: 'Модерн середини століття', d: 'Стиль 1940–1960-х років, органічні форми меблів, ніжки з дерева та ретро-шарм.', pal: ['#EDE3D1', '#7A5235', '#D98E32', '#2E6E6A', '#C2492F', '#2A2522'], f: ['Josefin Sans', 'Work Sans'], tex: ['walnut', 'terrazzo', 'boucle', 'brass'], kw: ['ретро', 'горіх', 'ніжки-шпильки', 'гірчичний', 'органічні форми'], ph: { s: 10, c: 8, h: 4 }, room: { wall: '#EDE3D1', floor: 'walnut', win: 'large', winCol: '#7A5235', sofa: 'mid', sofaCol: '#D98E32', rug: '#2E6E6A', lamp: 'sputnik', plant: 'big', art: 'abstract' } },
    { k: 'neoclassic', n: 'Неокласика', d: 'Переосмислення класики з легким сучасним меблюванням і світлою гамою.', pal: ['#F3EFE8', '#D6CBB9', '#A99B86', '#8BA0A6', '#C9A85A', '#3F3A35'], f: ['Cormorant Garamond', 'Montserrat'], tex: ['boiserie', 'marble', 'herringbone', 'velvetpink'], kw: ['ліпнина', 'світла гама', 'легкі меблі', 'симетрія'], ph: { b: 5, s: -6 }, room: { wall: 'boiserie', floor: 'herringbone', win: 'classic', winCol: '#FFFFFF', sofa: 'round', sofaCol: '#C98F8F', rug: '#D6CBB9', lamp: 'chandelier', plant: 'olive', art: 'mirror', molding: true } },
    { k: 'fusion', n: 'Ф’южн', d: 'Сміливе поєднання різних епох, кольорів та культур в одному просторі.', pal: ['#2E5A73', '#C96F4A', '#E2B34C', '#7A1F3D', '#3E7A55', '#F1E4D0'], f: ['Abril Fatface', 'Raleway'], tex: ['zellige', 'velvet', 'terrazzo', 'kilim'], kw: ['еклектика', 'контраст епох', 'культури', 'сміливий колір'], ph: { s: 20, c: 10 }, room: { wall: '#2E5A73', floor: 'cement', win: 'arch', winCol: '#E2B34C', sofa: 'tufted', sofaCol: '#C96F4A', rug: 'kilim', lamp: 'globe', plant: 'jungle', art: 'gallery' } },
    { k: 'maximal', n: 'Максималізм', d: '«Більше є більше»: насичені кольори, багато декору, шари текстилю та арт-об’єкти.', pal: ['#7A1F3D', '#0F5944', '#E2B34C', '#E05A9C', '#2E3A8C', '#1B1B1D'], f: ['DM Serif Display', 'Poppins'], tex: ['leaves', 'velvet', 'greenmarble', 'artdeco'], kw: ['насичені кольори', 'декор', 'шари', 'арт-об’єкти', 'патерни'], ph: { s: 30, c: 12 }, room: { wall: 'leaves', floor: 'greenmarble', win: 'classic', winCol: '#E2B34C', sofa: 'tufted', sofaCol: '#E05A9C', rug: 'kilim', lamp: 'chandelier', plant: 'jungle', art: 'gallery' } },
    { k: 'chalet', n: 'Шале', d: 'Масивні дерев’яні балки, камінь, хутро та тепле освітлення.', pal: ['#7A5235', '#3E2716', '#A69E92', '#E9E1D2', '#B5482F', '#2A1E14'], f: ['Bitter', 'Source Sans 3'], tex: ['walnut', 'stone', 'fur', 'plaid'], kw: ['балки', 'камінь', 'хутро', 'камін', 'тепле світло'], ph: { s: 4, sepia: 18, b: -2 }, room: { wall: 'walnut', floor: 'pine', win: 'classic', winCol: '#3E2716', sofa: 'boxy', sofaCol: '#6B4A33', rug: 'fur', lamp: 'lantern', plant: 'none', art: 'antlers', fireplace: true, beams: true } },
    { k: 'nautical', n: 'Морський', d: 'Білі, блакитні та темно-сині тони, льон, бавовна та легкість.', pal: ['#F7F5EF', '#1F3A5F', '#8BB8D0', '#E7DED0', '#C9A15C', '#0F2238'], f: ['Lobster Two', 'Open Sans'], tex: ['stripes', 'whitewood', 'linen', 'jute'], kw: ['море', 'синій', 'льон', 'мотузка', 'легкість'], ph: { b: 6, h: -6, s: 5 }, room: { wall: '#F7F5EF', floor: 'whitewood', win: 'porthole', winCol: '#1F3A5F', sofa: 'boxy', sofaCol: '#1F3A5F', rug: 'stripes', lamp: 'lantern', plant: 'small', art: 'anchor' } },
    { k: 'mediterranean', n: 'Середземноморський', d: 'Світлі стіни, теракотова плитка, арки, ковані елементи та морський бриз.', pal: ['#F8F4EC', '#C46B43', '#2E7D8C', '#E8C766', '#6F8F5A', '#2B2A28'], f: ['Marcellus', 'Mulish'], tex: ['terracotta', 'plaster', 'zellige', 'blackmetal'], kw: ['арки', 'теракота', 'кований метал', 'олива', 'бриз'], ph: { b: 6, s: 10, h: 3 }, room: { wall: 'plaster', floor: 'terracotta', win: 'arch', winCol: '#2B2A28', sofa: 'low', sofaCol: '#F2ECDF', rug: 'zellige', lamp: 'lantern', plant: 'olive', art: 'plates' } }
  ];
  IN.STYLES = ST;

  // ======================================================================
  // ROOM SCENE (front wall elevation)
  // ======================================================================
  const T = (x, y) => M.translate(Math.round(x), Math.round(y));
  const solid = c => [P.solid(c)];
  const shade = (c, k) => { const v = hex(c).map(x => Math.round(Math.max(0, Math.min(255, x * k)))); return '#' + v.map(x => x.toString(16).padStart(2, '0')).join('').toUpperCase(); };
  const fillOf = v => (v && TEX[v] ? [texPaint(v)] : solid(v || '#DDDDDD'));
  const R = (name, x, y, w, h, fills, extra) => model.create('rect', Object.assign({ name: t(name), w: Math.max(1, w), h: Math.max(1, h), m: T(x, y), fills, strokes: [] }, extra || {}));
  const E = (name, x, y, w, h, fills, extra) => model.create('ellipse', Object.assign({ name: t(name), w, h, m: T(x, y), fills, strokes: [] }, extra || {}));
  const PATH = (name, pts, fills, extra) => model.create('path', Object.assign({ name: t(name), fills, strokes: [], subpaths: [{ closed: true, pts: pts.map(p => G.pt(p[0], p[1], p[2] || null, p[3] || null)) }] }, extra || {}));
  const LINE = (name, pts, col, sw) => model.create('path', { name: t(name), fills: [], strokes: [P.solid(col)], sw, cap: 'round', subpaths: [{ closed: false, pts: pts.map(p => G.pt(p[0], p[1])) }] });
  const grp = (name, children) => { const g = model.create('group', { name: t(name), children }); return g; };
  const shadow = (o = 0.18, b = 24, y = 10) => [{ type: 'shadow', x: 0, y, blur: b, spread: 0, color: '#000000', opacity: o, visible: true }];

  IN.room = (st, W = 1200, H = 800) => {
    const r = st.room, pal = st.pal;
    const fy = Math.round(H * 0.74); // floor line
    const kids = [];
    kids.push(R('Стіна', 0, 0, W, fy, fillOf(r.wall)));
    if (r.molding) { kids.push(R('Карниз', 0, 0, W, 18, solid('#FFFFFF'), { effects: shadow(0.12, 8, 3) })); kids.push(R('Плінтус', 0, fy - 22, W, 22, solid('#FFFFFF'))); }
    if (r.beams) for (let i = 0; i < 4; i++) kids.push(R('Балка', i * W / 3 - 30, 0, 60, 44, [texPaint('walnut', 0.4)], { effects: shadow(0.3, 10, 6) }));
    if (r.pipes) { kids.push(R('Труба', 0, 70, W, 14, [texPaint('blackmetal', 0.5)])); kids.push(R('Труба', W * 0.86, 70, 14, fy - 70, [texPaint('blackmetal', 0.5)])); }
    // floor
    kids.push(R('Підлога', 0, fy, W, H - fy, fillOf(r.floor)));
    kids.push(R('Тінь біля стіни', 0, fy, W, 26, [Object.assign(P.linear('#000000', '#000000'), { from: { x: 0.5, y: 0 }, to: { x: 0.5, y: 1 }, stops: [{ o: 0, color: '#000000', a: 0.22 }, { o: 1, color: '#000000', a: 0 }] })]));
    // window
    const wx = Math.round(W * 0.08), wy = Math.round(H * 0.1), ww = Math.round(W * 0.3), wh = Math.round(fy * 0.62);
    const sky = [Object.assign(P.linear('#BFDDF2', '#EAF4FA'), { from: { x: 0.5, y: 0 }, to: { x: 0.5, y: 1 } })];
    const winParts = [];
    if (r.win === 'large' || r.win === 'loft') {
      winParts.push(R('Скло', wx, wy, ww, wh, sky));
      const n = r.win === 'loft' ? 4 : 2, m = r.win === 'loft' ? 5 : 2, bar = r.win === 'loft' ? 8 : 12;
      winParts.push(R('Рама', wx - bar, wy - bar, ww + bar * 2, bar, solid(r.winCol)), R('Рама', wx - bar, wy + wh, ww + bar * 2, bar, solid(r.winCol)), R('Рама', wx - bar, wy, bar, wh, solid(r.winCol)), R('Рама', wx + ww, wy, bar, wh, solid(r.winCol)));
      for (let i = 1; i < n; i++) winParts.push(R('Імпост', wx + ww * i / n - bar / 2, wy, bar * 0.7, wh, solid(r.winCol)));
      for (let i = 1; i < m; i++) winParts.push(R('Імпост', wx, wy + wh * i / m - bar / 2, ww, bar * 0.7, solid(r.winCol)));
    } else if (r.win === 'panoramic') {
      winParts.push(R('Панорамне скло', W * 0.05, wy * 0.6, W * 0.5, fy - wy * 0.6, sky, { opacity: 0.95 }), R('Профіль', W * 0.05, wy * 0.6, 6, fy - wy * 0.6, solid(r.winCol)), R('Профіль', W * 0.3, wy * 0.6, 6, fy - wy * 0.6, solid(r.winCol)), R('Профіль', W * 0.55, wy * 0.6, 6, fy - wy * 0.6, solid(r.winCol)));
      winParts.push(R('LED-лінія', 0, 6, W, 4, solid('#CFE8FF'), { effects: [{ type: 'shadow', x: 0, y: 0, blur: 18, spread: 2, color: '#7CC4FF', opacity: 0.9, visible: true }] }));
    } else if (r.win === 'arch' || r.win === 'classic' || r.win === 'shutters') {
      const arch = r.win === 'arch';
      // an arch is a half-ellipse on top of the opening (bezier handles at 0.55 of the radius)
      const rr = ww / 2, kq = 0.5523;
      winParts.push(PATH('Скло', arch ? [[wx, wy + rr, null, { x: wx, y: wy + rr - rr * kq }], [wx + rr, wy, { x: wx + rr - rr * kq, y: wy }, { x: wx + rr + rr * kq, y: wy }], [wx + ww, wy + rr, { x: wx + ww, y: wy + rr - rr * kq }, null], [wx + ww, wy + wh], [wx, wy + wh]] : [[wx, wy], [wx + ww, wy], [wx + ww, wy + wh], [wx, wy + wh]], sky, { strokes: [P.solid(r.winCol)], sw: 12, sa: 'center' }));
      winParts.push(R('Імпост', wx + ww / 2 - 4, wy + (arch ? ww * 0.1 : 0), 8, wh - (arch ? ww * 0.1 : 0), solid(r.winCol)), R('Імпост', wx, wy + wh * 0.55, ww, 8, solid(r.winCol)));
      if (r.win === 'classic') { winParts.push(R('Штора', wx - 70, wy - 30, 90, fy - wy + 10, solid(pal[3]), { radius: [0, 0, 30, 30] }), R('Штора', wx + ww - 20, wy - 30, 90, fy - wy + 10, solid(pal[3]), { radius: [0, 0, 30, 30] }), R('Карниз для штор', wx - 90, wy - 40, ww + 180, 10, solid(pal[4] || '#8C6D3F'), { radius: 5 })); }
      if (r.win === 'shutters') for (const sx of [wx - ww / 2 - 8, wx + ww + 8]) { winParts.push(R('Віконниця', sx, wy, ww / 2, wh, solid(r.winCol))); for (let i = 1; i < 12; i++) winParts.push(R('Ламель', sx + 8, wy + wh * i / 12, ww / 2 - 16, 3, solid(shade(r.winCol, 0.8)))); }
    } else if (r.win === 'shoji') {
      winParts.push(R('Сьодзі', wx, wy, ww * 1.2, wh, solid('#F4EFE3'), { opacity: 0.95 }));
      for (let i = 0; i <= 4; i++) winParts.push(R('Рейка', wx + ww * 1.2 * i / 4 - 3, wy, 6, wh, solid(r.winCol)));
      for (let i = 0; i <= 6; i++) winParts.push(R('Рейка', wx, wy + wh * i / 6 - 3, ww * 1.2, 6, solid(r.winCol)));
    } else if (r.win === 'porthole') {
      for (const k of [0, 1]) { const cx = wx + k * ww * 0.6, s = ww * 0.45; winParts.push(E('Ілюмінатор', cx, wy + 40, s, s, sky, { strokes: [P.solid(r.winCol)], sw: 16 })); }
    }
    if (winParts.length) kids.push(grp('Вікно', winParts));
    // fireplace
    if (r.fireplace) kids.push(grp('Камін', [R('Камін', W * 0.42, fy - 260, 240, 260, [texPaint('stone', 0.5)], { effects: shadow(0.25, 18, 8) }), R('Топка', W * 0.42 + 50, fy - 150, 140, 150, solid('#1B1410'), { radius: [70, 70, 0, 0] }), E('Вогонь', W * 0.42 + 85, fy - 80, 70, 60, [Object.assign(P.radial('#FFD27A', '#E0522D'), { stops: [{ o: 0, color: '#FFE7A3', a: 1 }, { o: 1, color: '#E0522D', a: 0.9 }] })], { effects: [{ type: 'shadow', x: 0, y: 0, blur: 30, spread: 0, color: '#FF8A3D', opacity: 0.8, visible: true }] }), R('Полиця каміна', W * 0.42 - 20, fy - 272, 280, 16, [texPaint('walnut', 0.4)])]));
    // art on the wall
    const ax = Math.round(W * 0.56), ay = Math.round(H * 0.12);
    const art = [];
    if (r.art === 'abstract' || r.art === 'poster' || r.art === 'line' || r.art === 'botanical' || r.art === 'ink') {
      art.push(R('Рамка', ax, ay, 240, 300, solid(r.art === 'poster' ? '#1E1E1F' : '#FFFFFF'), { strokes: [P.solid(pal[5] === '#FFFFFF' ? '#2E2C29' : pal[5])], sw: 8, sa: 'inside', effects: shadow(0.16, 16, 6) }));
      if (r.art === 'abstract') art.push(E('Форма', ax + 40, ay + 60, 120, 120, solid(pal[3])), R('Форма', ax + 110, ay + 150, 90, 110, solid(pal[4])));
      if (r.art === 'poster') art.push(R('Плакат', ax + 30, ay + 40, 180, 200, solid(pal[3])), E('Коло', ax + 80, ay + 90, 80, 80, solid('#1E1E1F')));
      if (r.art === 'line') art.push(LINE('Лінійний малюнок', [[ax + 60, ay + 220], [ax + 100, ay + 120], [ax + 140, ay + 200], [ax + 180, ay + 90]], '#2E2C29', 3));
      if (r.art === 'botanical' || r.art === 'ink') { art.push(LINE('Стебло', [[ax + 120, ay + 260], [ax + 120, ay + 60]], r.art === 'ink' ? '#1B1A18' : '#4E5B3A', 3)); for (let i = 0; i < 5; i++) art.push(E('Листок', ax + (i % 2 ? 122 : 62), ay + 80 + i * 34, 56, 20, solid(r.art === 'ink' ? '#1B1A18' : '#7A8C5E'), { opacity: 0.85 })); }
    } else if (r.art === 'gallery') {
      [[0, 0, 150, 190], [170, 0, 120, 120], [170, 140, 120, 150], [310, 30, 130, 170]].forEach(([x, y, w, h], i) => art.push(R('Рамка', ax - 60 + x, ay + y, w, h, solid(pal[(i + 2) % pal.length]), { strokes: [P.solid('#1B1B1D')], sw: 6, sa: 'inside', effects: shadow(0.15, 12, 5) })));
    } else if (r.art === 'mirror' || r.art === 'sunburst') {
      if (r.art === 'sunburst') { for (let i = 0; i < 24; i++) { const a = i / 24 * Math.PI * 2, cx = ax + 130, cy = ay + 150; art.push(LINE('Промінь', [[cx + Math.cos(a) * 80, cy + Math.sin(a) * 80], [cx + Math.cos(a) * 150, cy + Math.sin(a) * 150]], '#C9A85A', 6)); } art.push(E('Дзеркало', ax + 50, ay + 70, 160, 160, [Object.assign(P.linear('#E8EEF2', '#AEB8C0'), { from: { x: 0, y: 0 }, to: { x: 1, y: 1 } })], { strokes: [P.solid('#C9A85A')], sw: 10 })); }
      else art.push(R('Дзеркало', ax + 10, ay - 20, 220, 320, [Object.assign(P.linear('#EEF2F4', '#B8C2C8'), { from: { x: 0, y: 0 }, to: { x: 1, y: 1 } })], { radius: [110, 110, 6, 6], strokes: [P.solid('#C9A85A')], sw: 12, effects: shadow(0.2, 16, 6) }));
    } else if (r.art === 'screen') art.push(R('Медіапанель', ax - 40, ay + 40, 380, 214, solid('#0E0F11'), { radius: 6, effects: [{ type: 'shadow', x: 0, y: 0, blur: 30, spread: 0, color: '#0D99FF', opacity: 0.35, visible: true }] }));
    else if (r.art === 'vase' || r.art === 'plates') {
      art.push(R('Ніша / полиця', ax - 20, ay + 220, 300, 14, [texPaint('ashgray', 0.4)]));
      if (r.art === 'vase') art.push(PATH('Ваза', [[ax + 60, ay + 220], [ax + 40, ay + 150, null, { x: ax + 20, y: ay + 190 }], [ax + 70, ay + 100, { x: ax + 55, y: ay + 110 }], [ax + 90, ay + 100], [ax + 120, ay + 150, null, { x: ax + 140, y: ay + 120 }], [ax + 100, ay + 220, { x: ax + 140, y: ay + 190 }]], solid('#B9A68C')), LINE('Гілка', [[ax + 80, ay + 100], [ax + 60, ay + 20], [ax + 20, ay - 10]], '#4A433B', 3), E('Чаша', ax + 170, ay + 185, 80, 36, solid('#6F675C')));
      else [0, 1, 2].forEach(i => art.push(E('Тарілка', ax + i * 90, ay + 60 + (i % 2) * 40, 84, 84, solid('#FFFFFF'), { strokes: [P.solid(i % 2 ? '#2E7D8C' : '#C46B43')], sw: 10, effects: shadow(0.15, 10, 4) })));
    } else if (r.art === 'macrame') { art.push(R('Палиця', ax, ay, 220, 10, solid('#8A5A33'), { radius: 5 })); for (let i = 0; i < 12; i++) art.push(LINE('Шнур', [[ax + 15 + i * 17, ay + 10], [ax + 110 + (i - 6) * 6, ay + 150], [ax + 15 + i * 17, ay + 260]], '#F1E4D0', 4)); }
    else if (r.art === 'antlers') art.push(R('Табличка', ax + 70, ay + 60, 100, 120, [texPaint('walnut', 0.4)], { radius: 50 }), LINE('Ріг', [[ax + 120, ay + 70], [ax + 60, ay], [ax + 30, ay - 20]], '#E9E1D2', 9), LINE('Ріг', [[ax + 120, ay + 70], [ax + 180, ay], [ax + 210, ay - 20]], '#E9E1D2', 9));
    else if (r.art === 'anchor') art.push(E('Рятувальний круг', ax + 40, ay + 20, 170, 170, [], { strokes: [P.solid('#E5484D')], sw: 34, dash: [40, 40] }), E('Круг', ax + 40, ay + 20, 170, 170, [], { strokes: [P.solid('#FFFFFF')], sw: 30, dash: [40, 40], opacity: 0.95 }));
    if (art.length) kids.push(grp('Декор стіни', art));
    // lamp
    const lx = Math.round(W * 0.66), lamp = [];
    if (['pendant', 'globe', 'edison', 'paper', 'rattan', 'sputnik', 'fan', 'chandelier'].includes(r.lamp)) {
      lamp.push(LINE('Шнур', [[lx, 0], [lx, H * 0.2]], '#2E2C29', 2));
      const ly = H * 0.2;
      if (r.lamp === 'pendant') lamp.push(PATH('Плафон', [[lx - 50, ly + 60], [lx - 14, ly], [lx + 14, ly], [lx + 50, ly + 60]], solid(pal[4])));
      if (r.lamp === 'globe' || r.lamp === 'paper') lamp.push(E('Плафон', lx - 45, ly, 90, r.lamp === 'paper' ? 110 : 90, solid(r.lamp === 'paper' ? '#FFF8EA' : '#FFFFFF'), { opacity: 0.95, effects: [{ type: 'shadow', x: 0, y: 0, blur: 40, spread: 0, color: '#FFE2A8', opacity: 0.9, visible: true }] }));
      if (r.lamp === 'edison') for (const dx of [-60, 0, 60]) lamp.push(LINE('Шнур', [[lx + dx, 0], [lx + dx, ly + (dx ? 30 : 0)]], '#1E1E1F', 2), E('Лампа Едісона', lx + dx - 16, ly + (dx ? 30 : 0), 32, 44, solid('#FFC56B'), { effects: [{ type: 'shadow', x: 0, y: 0, blur: 26, spread: 0, color: '#FFB347', opacity: 0.95, visible: true }] }));
      if (r.lamp === 'rattan') lamp.push(E('Плафон з ротангу', lx - 60, ly, 120, 90, [texPaint('rattan', 0.25)], { effects: [{ type: 'shadow', x: 0, y: 0, blur: 30, spread: 0, color: '#FFD9A0', opacity: 0.7, visible: true }] }));
      if (r.lamp === 'sputnik') { lamp.push(E('Центр', lx - 12, ly - 12, 24, 24, solid('#C9A85A'))); for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2; lamp.push(LINE('Промінь', [[lx, ly], [lx + Math.cos(a) * 80, ly + Math.sin(a) * 60]], '#C9A85A', 3), E('Лампа', lx + Math.cos(a) * 80 - 8, ly + Math.sin(a) * 60 - 8, 16, 16, solid('#FFF4D6'))); } }
      if (r.lamp === 'fan') lamp.push(PATH('Віялова лампа', [[lx - 70, ly + 60], [lx, ly - 10, [lx - 60, ly], [lx + 60, ly]], [lx + 70, ly + 60]], solid('#C9A85A'), { effects: [{ type: 'shadow', x: 0, y: 20, blur: 40, spread: 0, color: '#FFE2A8', opacity: 0.8, visible: true }] }));
      if (r.lamp === 'chandelier') { lamp.push(PATH('Люстра', [[lx - 90, ly + 30], [lx, ly + 70, [lx - 60, ly + 80], [lx + 60, ly + 80]], [lx + 90, ly + 30]], [], { strokes: [P.solid('#C9A85A')], sw: 5 })); for (const dx of [-90, -45, 0, 45, 90]) lamp.push(R('Свічка', lx + dx - 5, ly + (Math.abs(dx) > 50 ? 10 : dx === 0 ? 46 : 28), 10, 22, solid('#FFF8EA')), E('Вогник', lx + dx - 7, ly + (Math.abs(dx) > 50 ? -4 : dx === 0 ? 32 : 14), 14, 16, solid('#FFD27A'), { effects: [{ type: 'shadow', x: 0, y: 0, blur: 16, spread: 0, color: '#FFB347', opacity: 0.9, visible: true }] })); }
    } else if (r.lamp === 'arc') lamp.push(LINE('Дуга торшера', [[W * 0.9, fy], [W * 0.92, fy - 380], [W * 0.78, fy - 420], [W * 0.7, fy - 360]], '#2E2C29', 6), PATH('Плафон', [[W * 0.7 - 50, fy - 330], [W * 0.7 - 20, fy - 370], [W * 0.7 + 20, fy - 370], [W * 0.7 + 50, fy - 330]], solid('#2E2C29')), E('Основа', W * 0.9 - 40, fy - 14, 80, 20, solid('#2E2C29')));
    else if (r.lamp === 'lantern') lamp.push(R('Ліхтар', W * 0.83, fy - 140, 70, 110, [], { strokes: [P.solid('#2B2A28')], sw: 6, radius: [30, 30, 4, 4] }), E('Свічка', W * 0.83 + 22, fy - 90, 26, 40, solid('#FFD27A'), { effects: [{ type: 'shadow', x: 0, y: 0, blur: 30, spread: 0, color: '#FFB347', opacity: 0.9, visible: true }] }));
    else if (r.lamp === 'led') lamp.push(R('LED-торшер', W * 0.9, fy - 420, 8, 420, solid('#FFFFFF'), { effects: [{ type: 'shadow', x: 0, y: 0, blur: 24, spread: 2, color: '#9FD3FF', opacity: 1, visible: true }] }));
    if (lamp.length) kids.push(grp('Світильник', lamp));
    // rug
    const rugW = W * 0.62, rugX = (W - rugW) / 2 + W * 0.05;
    kids.push(E('Килим', rugX, fy + (H - fy) * 0.35, rugW, (H - fy) * 0.5, fillOf(r.rug), { effects: shadow(0.12, 8, 2) }));
    // sofa
    const sw = W * 0.46, sx = W * 0.5 - sw / 2 + W * 0.06, sh = r.sofa === 'low' ? 150 : 210, sy = fy + 40 - sh, col = r.sofaCol || pal[2];
    const sofa = [];
    const legs = r.sofa === 'mid' ? 38 : r.sofa === 'low' ? 0 : 14;
    const back = r.sofa === 'tufted' ? 18 : r.sofa === 'round' ? 70 : r.sofa === 'low' ? 26 : 10;
    sofa.push(R('Спинка', sx + 20, sy - legs, sw - 40, sh * 0.62, solid(shade(col, 0.92)), { radius: [back, back, 6, 6], effects: shadow(0.2, 24, 12) }));
    if (r.sofa === 'tufted') for (let i = 1; i < 8; i++) for (let j = 1; j < 3; j++) sofa.push(E('Ґудзик', sx + 20 + (sw - 40) * i / 8 - 4, sy - legs + sh * 0.62 * j / 3 - 4, 8, 8, solid(shade(col, 0.7))));
    sofa.push(R('Сидіння', sx, sy + sh * 0.5 - legs, sw, sh * 0.38, solid(col), { radius: r.sofa === 'round' ? 40 : 14 }));
    sofa.push(R('Підлокітник', sx - 10, sy + sh * 0.3 - legs, 60, sh * 0.58, solid(shade(col, 0.95)), { radius: r.sofa === 'boxy' ? 6 : 30 }), R('Підлокітник', sx + sw - 50, sy + sh * 0.3 - legs, 60, sh * 0.58, solid(shade(col, 0.95)), { radius: r.sofa === 'boxy' ? 6 : 30 }));
    sofa.push(R('Подушка', sx + 70, sy + sh * 0.22 - legs, 90, 80, solid(pal[3]), { radius: 18 }), R('Подушка', sx + sw - 160, sy + sh * 0.22 - legs, 90, 80, TEX[r.rug] ? [texPaint(r.rug, 0.25)] : solid(pal[4]), { radius: 18 }));
    if (legs) for (const lx2 of [sx + 20, sx + sw - 30]) sofa.push(PATH('Ніжка', [[lx2, sy + sh * 0.88 - legs], [lx2 + 10, sy + sh * 0.88 - legs], [lx2 + (r.sofa === 'mid' ? 16 : 10), sy + sh * 0.88], [lx2 + (r.sofa === 'mid' ? 6 : 0), sy + sh * 0.88]], solid(r.sofa === 'mid' ? '#7A5235' : '#2E2C29')));
    kids.push(grp('Диван', sofa));
    // coffee table
    if (r.sofa !== 'low') kids.push(grp('Журнальний столик', [E('Стільниця', W * 0.36, fy + (H - fy) * 0.42, 220, 40, TEX[st.tex[3]] ? [texPaint(st.tex[3], 0.3)] : solid(pal[1]), { effects: shadow(0.2, 10, 6) })]));
    else kids.push(grp('Низький столик', [R('Стільниця', W * 0.38, fy + 30, 200, 20, [texPaint('walnut', 0.3)], { radius: 4, effects: shadow(0.2, 10, 4) })]));
    // plants
    const plant = [], px = W * 0.06, py = fy;
    const pot = (x, w, h, c) => plant.push(PATH('Горщик', [[x, py - h], [x + w, py - h], [x + w * 0.85, py], [x + w * 0.15, py]], solid(c), { effects: shadow(0.18, 10, 4) }));
    if (r.plant === 'big' || r.plant === 'jungle') {
      pot(px, 110, 100, r.plant === 'jungle' ? '#C46B43' : '#E9E4DC');
      for (let i = 0; i < 9; i++) { const a = -Math.PI / 2 + (i - 4) * 0.32, l = 150 + (i % 3) * 40; plant.push(LINE('Стебло', [[px + 55, py - 100], [px + 55 + Math.cos(a) * l * 0.8, py - 100 + Math.sin(a) * l * 0.8]], '#3E6B47', 3), E('Листок монстери', px + 55 + Math.cos(a) * l * 0.8 - 40, py - 100 + Math.sin(a) * l * 0.8 - 26, 80, 52, solid(['#2F6446', '#3E7A55', '#4F8A60'][i % 3]))); }
      if (r.plant === 'jungle') { plant.push(LINE('Ліана', [[W * 0.3, 0], [W * 0.28, 120], [W * 0.33, 220]], '#3E6B47', 3)); for (let i = 0; i < 6; i++) plant.push(E('Листок', W * 0.28 + (i % 2 ? 6 : -30), 30 + i * 32, 30, 16, solid('#4F8A60'))); }
    } else if (r.plant === 'small' || r.plant === 'lavender' || r.plant === 'bonsai') {
      pot(px + 20, 70, 60, r.plant === 'lavender' ? '#C9D6C2' : r.plant === 'bonsai' ? '#2F2C28' : '#FFFFFF');
      if (r.plant === 'lavender') for (let i = 0; i < 9; i++) plant.push(LINE('Лаванда', [[px + 55, py - 60], [px + 25 + i * 8, py - 150 - (i % 3) * 20]], '#7A8C6E', 2), E('Суцвіття', px + 21 + i * 8, py - 175 - (i % 3) * 20, 9, 26, solid('#9C86C4')));
      else if (r.plant === 'bonsai') plant.push(LINE('Стовбур', [[px + 55, py - 60], [px + 40, py - 110], [px + 70, py - 150]], '#4A3A2A', 8), E('Крона', px + 20, py - 190, 110, 60, solid('#5E6B5A')), E('Крона', px + 60, py - 150, 80, 44, solid('#4E5B3A')));
      else for (let i = 0; i < 7; i++) plant.push(E('Листок', px + 25 + (i % 3) * 18, py - 110 - Math.floor(i / 3) * 26, 34, 22, solid('#5B9A6B')));
    } else if (r.plant === 'olive' || r.plant === 'branch') {
      plant.push(PATH('Ваза', [[px + 30, py - 140], [px + 90, py - 140], [px + 100, py], [px + 20, py]], [texPaint(r.plant === 'olive' ? 'terracotta' : 'plaster', 0.3)], { effects: shadow(0.18, 10, 4) }));
      plant.push(LINE('Гілка', [[px + 60, py - 140], [px + 40, py - 300], [px + 10, py - 380]], '#5A4A3A', 4), LINE('Гілка', [[px + 60, py - 140], [px + 100, py - 280], [px + 140, py - 340]], '#5A4A3A', 4));
      if (r.plant === 'olive') for (let i = 0; i < 18; i++) plant.push(E('Листок оливи', px + 10 + (i * 37) % 140, py - 380 + (i * 53) % 240, 26, 9, solid(i % 2 ? '#7E8C6A' : '#9AA886'), { m: M.mul(T(px + 10 + (i * 37) % 140, py - 380 + (i * 53) % 240), M.rotate(((i * 47) % 90 - 45) * Math.PI / 180)) }));
    }
    if (plant.length) kids.push(grp('Рослини', plant));
    return kids;
  };

  // ======================================================================
  // TEMPLATES
  // ======================================================================
  const place = (f) => {
    const vr = V.viewRect(), c = { x: vr.x + vr.w / 2, y: vr.y + vr.h / 2 };
    const b = model.page().children.length ? model.selBounds(model.page().children) : null;
    f.m = b ? T(b.x + b.w + 200, b.y) : T(c.x - f.w / 2, c.y - f.h / 2);
    model.insert(f, model.page());
    O.select([f.id]);
    if (O.fonts && O.fonts.ensure) O.fonts.ensure([f]).catch(() => {});
    setTimeout(() => V.fit(model.worldBounds(f), 80, 1), 0);
  };
  const txt = (text, x, y, size, font, weight, color, extra) => model.create('text', Object.assign({ name: text.slice(0, 32), text, font, size, weight, fills: solid(color), m: T(x, y) }, extra || {}));
  const styleOf = k => ST.find(s => s.k === k) || ST[0];
  IN.roomFrame = (k, W = 1920, H = 1080) => {
    const st = styleOf(k);
    const f = model.create('frame', { name: `${t('Інтер’єр')}: ${t(st.n)} — ${W}×${H}`, w: W, h: H, fills: solid(st.pal[0]), clip: true, interior: st.k });
    f.children = IN.room(st, W, H);
    return f;
  };
  IN.moodboard = k => {
    const st = styleOf(k);
    const W = 1800, H = 1100, pad = 64;
    const dark = st.pal.slice().sort((a, b) => lum(a) - lum(b))[0], light = st.pal.slice().sort((a, b) => lum(b) - lum(a))[0];
    const bg = lum(st.pal[0]) > 0.5 ? '#FBFAF7' : '#F4F1EA';
    const f = model.create('frame', { name: `${t('Мудборд')}: ${t(st.n)} — ${W}×${H}`, w: W, h: H, fills: solid(bg), clip: true, interior: st.k });
    const kids = [];
    kids.push(txt(t('Мудборд інтер’єру').toUpperCase(), pad, pad, 16, st.f[1], 600, '#8A8A8A', { ls: 2 }));
    kids.push(txt(t(st.n), pad, pad + 30, 76, st.f[0], 700, dark, { width: 640 }));
    kids.push(txt(t(st.d), pad, pad + 150, 22, st.f[1], 400, '#4A4A4A', { width: 600, lh: 1.45 }));
    // keywords
    let kx = pad, ky = pad + 280;
    st.kw.forEach(w => { const s = t(w), wd = Math.round(s.length * 9.6 + 34); if (kx + wd > pad + 620) { kx = pad; ky += 46; } kids.push(R('Тег', kx, ky, wd, 34, solid(lum(st.pal[3]) > 0.6 ? st.pal[3] : '#FFFFFF'), { radius: 17, strokes: [P.solid(st.pal[3])], sw: 1.5 })); kids.push(txt(s, kx + 17, ky + 8, 15, st.f[1], 500, '#2E2C29')); kx += wd + 10; });
    // palette
    const py = pad + 400;
    kids.push(txt(t('Палітра'), pad, py, 18, st.f[1], 700, dark));
    st.pal.forEach((c, i) => { const x = pad + i * 104; kids.push(R('Колір палітри', x, py + 34, 92, 120, solid(c), { radius: 10, strokes: [P.solid('#000000', 0.08)], sw: 1, effects: shadow(0.08, 10, 3) })); kids.push(txt(c, x, py + 164, 13, 'Inter', 500, '#555555')); });
    // materials
    const my = py + 220;
    kids.push(txt(t('Матеріали'), pad, my, 18, st.f[1], 700, dark));
    st.tex.forEach((k2, i) => { const x = pad + i * 156; kids.push(R('Матеріал', x, my + 34, 140, 140, [texPaint(k2, 0.4)], { radius: 10, effects: shadow(0.12, 12, 4) })); kids.push(txt(t(TEX[k2][0]), x, my + 184, 13, st.f[1], 500, '#555555', { width: 140 })); });
    // fonts
    kids.push(txt(`${t('Шрифти')}: ${st.f[0]} / ${st.f[1]}`, pad, H - pad - 20, 14, 'Inter', 500, '#777777'));
    // room scene
    const rw = 1000, rh = 680;
    const room = model.create('frame', { name: t('Сцена кімнати'), w: rw, h: rh, m: T(W - pad - rw, pad + 40), fills: solid(st.pal[0]), clip: true, radius: 18, effects: shadow(0.18, 40, 16) });
    room.children = IN.room(st, rw, rh);
    kids.push(room);
    kids.push(txt(t('Ескіз стіни: замініть фото чи об’єкти своїми — усі елементи редагуються.'), W - pad - rw, pad + 40 + rh + 20, 14, st.f[1], 400, '#777777', { width: rw }));
    // swatch strip at the bottom of the scene
    st.pal.forEach((c, i) => kids.push(R('Смуга палітри', W - pad - rw + i * (rw / 6), pad + 40 + rh + 60, rw / 6, 16, solid(c))));
    f.children = kids;
    void light;
    return f;
  };
  const lum = c => { const [r, g, b] = hex(c).map(v => v / 255); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };

  // ======================================================================
  // STYLE EFFECTS FOR THE SELECTION
  // ======================================================================
  // recolour by lightness rank: the darkest colours of the selection get the darkest colours of the palette
  IN.applyStyle = (k, opts = {}) => {
    const st = styleOf(k);
    const nodes = O.sel();
    if (!nodes.length) return O.toast('Виділіть об’єкти');
    const all = [];
    model.walk(nodes, n => { all.push(n); });
    const cols = new Set();
    for (const n of all) { for (const p of (n.fills || []).concat(n.strokes || [])) if (p.type === 'solid') cols.add(p.color.toUpperCase()); }
    const src = Array.from(cols).sort((a, b) => lum(a) - lum(b));
    const pal = st.pal.slice().sort((a, b) => lum(a) - lum(b));
    const map = new Map(src.map((c, i) => [c, pal[Math.min(pal.length - 1, Math.round(i / Math.max(1, src.length - 1) * (pal.length - 1)))]]));
    let photos = 0, texts = 0;
    for (const n of all) {
      if (opts.colors !== false) for (const p of (n.fills || []).concat(n.strokes || [])) if (p.type === 'solid' && map.has(p.color.toUpperCase())) p.color = map.get(p.color.toUpperCase());
      if (opts.fonts !== false && n.type === 'text') { n.font = n.size >= 28 ? st.f[0] : st.f[1]; texts++; }
      if (opts.photo !== false && (n.fills || []).some(p => p.type === 'image' && !(S.doc.assets[p.asset] || {}).tex)) { n.adjust = Object.assign({}, st.ph); photos++; }
    }
    if (O.fonts && O.fonts.ensure) O.fonts.ensure(nodes).catch(() => {});
    O.history.commit('Стиль інтер’єру');
    O.toast('Стиль «{name}»: кольорів {c}, текстів {t}, фото {p}', { name: t(st.n), c: map.size, t: texts, p: photos });
  };
  IN.addPalette = k => {
    const st = styleOf(k);
    const names = ['Стіни', 'Підлога / дерево', 'Меблі', 'Акцент 1', 'Акцент 2', 'Темний'];
    for (let i = 0; i < st.pal.length; i++) if (!S.doc.swatches.some(s => s.color.toUpperCase() === st.pal[i].toUpperCase() && s.name.startsWith(t(st.n)))) S.doc.swatches.push({ id: O.uid(), name: `${t(st.n)} · ${t(names[i])}`, color: st.pal[i] });
    O.history.commit('Палітра стилю');
    O.toast('Палітру «{name}» додано до кольорів документа', { name: t(st.n) });
  };
  IN.applyMaterial = key => {
    const nodes = O.sel().filter(n => ['rect', 'ellipse', 'polygon', 'star', 'path', 'frame', 'bool'].includes(n.type));
    if (!nodes.length) {
      // no selection: a material swatch at the centre of the view
      const vr = V.viewRect();
      const n = model.create('rect', { name: t(TEX[key][0]), w: 300, h: 300, radius: 12, m: T(vr.x + vr.w / 2 - 150, vr.y + vr.h / 2 - 150), fills: [texPaint(key, 0.6)], strokes: [] });
      model.insert(n, model.page()); O.select([n.id]);
    } else for (const n of nodes) n.fills = [texPaint(key, 0.6)];
    O.history.commit('Матеріал');
  };

  // ======================================================================
  // UI
  // ======================================================================
  IN.dialog = () => {
    let cur = O.ls.get('interiorStyle', 'scandi');
    const card = st => `<button type="button" class="in-card${st.k === cur ? ' on' : ''}" data-st="${st.k}"><span class="in-sw">${st.pal.map(c => `<i style="background:${c}"></i>`).join('')}</span><span class="in-mt">${st.tex.map(k => `<img src="${thumb(k)}" alt="">`).join('')}</span><b>${esc(t(st.n))}</b></button>`;
    const d = ui.dialog({
      title: 'Стилі інтер’єру',
      body: `<div class="in"><div class="in-grid">${ST.map(card).join('')}</div><aside class="in-side"></aside></div>`,
      buttons: [{ id: 'cancel', label: 'Закрити' }],
      onOk: () => {}
    });
    d.el.querySelector('.dlg').classList.add('wide', 'in-dlg');
    const side = () => {
      const st = styleOf(cur);
      d.el.querySelector('.in-side').innerHTML = `<h3 style="font-family:'${esc(st.f[0])}',serif">${esc(t(st.n))}</h3><p>${esc(t(st.d))}</p>
        <div class="in-pal">${st.pal.map(c => `<span><i style="background:${c}"></i>${c}</span>`).join('')}</div>
        <div class="in-mats">${st.tex.map(k => `<button type="button" data-mat="${k}" title="${esc(t('Застосувати матеріал до виділеного'))}"><img src="${thumb(k)}" alt=""><em>${esc(t(TEX[k][0]))}</em></button>`).join('')}</div>
        <div class="in-kw">${st.kw.map(w => `<span>${esc(t(w))}</span>`).join('')}</div>
        <div class="in-f">${esc(t('Шрифти'))}: <b>${esc(st.f[0])}</b> / ${esc(st.f[1])}</div>
        <div class="in-act"><button type="button" class="btn primary" data-in="mood">${esc(t('Створити мудборд'))}</button><button type="button" class="btn" data-in="room">${esc(t('Сцена кімнати 1920×1080'))}</button><button type="button" class="btn" data-in="apply">${esc(t('Застосувати стиль до виділеного'))}</button><button type="button" class="btn" data-in="pal">${esc(t('Додати палітру в документ'))}</button></div>`;
      if (O.fonts && O.fonts.load) { O.fonts.load(st.f[0]); }
    };
    d.el.addEventListener('click', e => {
      const c = e.target.closest('[data-st]');
      if (c) { cur = c.dataset.st; O.ls.set('interiorStyle', cur); d.el.querySelectorAll('.in-card').forEach(x => x.classList.toggle('on', x === c)); side(); return; }
      const m = e.target.closest('[data-mat]');
      if (m) { IN.applyMaterial(m.dataset.mat); return; }
      const a = e.target.closest('[data-in]');
      if (!a) return;
      const act = a.dataset.in;
      if (act === 'mood') { place(IN.moodboard(cur)); O.history.commit('Мудборд'); d.close(); }
      if (act === 'room') { place(IN.roomFrame(cur)); O.history.commit('Сцена кімнати'); d.close(); }
      if (act === 'apply') IN.applyStyle(cur);
      if (act === 'pal') IN.addPalette(cur);
    });
    side();
  };
  IN.materialsDialog = () => {
    const d = ui.dialog({
      title: 'Матеріали інтер’єру',
      body: `<div class="dlg-text">${esc(t('Клік заповнює виділені фігури текстурою (плиткою). Без виділення додається зразок матеріалу.'))}</div><div class="in-matgrid">${Object.entries(TEX).map(([k, [n]]) => `<button type="button" data-mat="${k}"><img src="${thumb(k)}" alt=""><em>${esc(t(n))}</em></button>`).join('')}</div>`,
      buttons: [{ id: 'cancel', label: 'Закрити' }],
      onOk: () => {}
    });
    d.el.querySelector('.dlg').classList.add('wide');
    d.el.addEventListener('click', e => { const m = e.target.closest('[data-mat]'); if (m) IN.applyMaterial(m.dataset.mat); });
  };
  O.cmd('interiorStyles', 'Стилі інтер’єру (шаблони й ефекти)…', () => IN.dialog(), { keys: ['Ctrl+Alt+Shift+H'], group: 'Інтер’єр' });
  O.cmd('interiorMaterials', 'Матеріали інтер’єру (текстури)…', () => IN.materialsDialog(), { group: 'Інтер’єр' });
  O.cmd('interiorMood', 'Мудборд у вибраному стилі', () => { place(IN.moodboard(O.ls.get('interiorStyle', 'scandi'))); O.history.commit('Мудборд'); }, { group: 'Інтер’єр' });
  O.MENUS.splice(O.MENUS.findIndex(m => m[0] === 'Вигляд'), 0, ['Інтер’єр', ['interiorStyles', 'interiorMaterials', 'interiorMood']]);
})();
