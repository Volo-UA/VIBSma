'use strict';
/* Obrys — component variants and instance properties (Figma: Variants, Component properties).
   · «Combine as variants»: components go into a component set (dashed purple frame with auto layout);
     each variant has property values parsed from its name «Size=Large, State=Hover».
   · Instance of a variant: one select per property swaps the variant.
   · Instance overrides n.ov = { "layer/path": { text, visible, color } } keep working across variants (matched by name). */
(function () {
  const O = window.O, M = O.M, model = O.model, S = O.state, ui = O.ui;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const C = O.components = {};

  // ---------- small panel helpers shared by the new modules ----------
  O.ph = {
    sec: (title, body, extra = '') => `<section class="ps"><div class="ps-h"><span>${esc(t(title))}</span>${extra ? `<span class="ps-x">${extra}</span>` : ''}</div>${body}</section>`,
    sel: (attrs, value, options, label) => `<select class="sel" ${attrs} aria-label="${esc(t(label || ''))}">${options.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(value) ? ' selected' : ''}>${esc(t(l))}</option>`).join('')}</select>`,
    inp: (attrs, value, label, unit) => `<label class="fld" title="${esc(t(label))}"><span class="fl">${esc(t(label))}</span><input type="text" ${attrs} value="${esc(value)}" aria-label="${esc(t(label))}">${unit ? `<em>${esc(unit)}</em>` : ''}</label>`,
    ib: (attrs, icon, label) => `<button type="button" class="ib" ${attrs} title="${esc(t(label))}" aria-label="${esc(t(label))}">${O.icon(icon, 15)}</button>`,
    inProps: el => { const p = O.$('#props'); return !!(p && el && p.contains(el)); }
  };
  const ph = O.ph;

  // ---------- overrides ----------
  const pathMap = root => {
    const out = new Map();
    const walk = (list, prefix) => {
      const seen = new Map();
      for (const c of list) {
        const nm = String(c.name || c.type);
        const k = (seen.get(nm) || 0) + 1; seen.set(nm, k);
        const key = prefix + nm + (k > 1 ? '#' + k : '');
        out.set(key, c);
        if (c.children && c.type !== 'bool') walk(c.children, key + '/');
      }
    };
    walk(root.children || [], '');
    return out;
  };
  C.pathMap = pathMap;
  C.applyOv = (comp, ov) => {
    const c = O.clone(comp);
    const map = pathMap(c);
    for (const [key, o] of Object.entries(ov || {})) {
      const n = map.get(key);
      if (!n || !o) continue;
      if (o.text !== undefined && n.type === 'text') n.text = o.text;
      if (o.visible !== undefined) n.visible = o.visible;
      if (o.color) { const f = (n.fills || []).find(p => p.type === 'solid'); if (f) f.color = o.color; else n.fills = [O.paint.solid(o.color)]; }
    }
    return c;
  };

  // ---------- variants ----------
  C.setOf = comp => { const p = comp && model.parent(comp); return p && p.componentSet ? p : null; };
  C.props = set => {
    const props = new Map();
    for (const v of set.children) if (v.variant) for (const [k, val] of Object.entries(v.variant)) { if (!props.has(k)) props.set(k, []); if (!props.get(k).includes(val)) props.get(k).push(val); }
    return props;
  };
  C.parseName = (name, i) => {
    const parts = String(name).split(',').map(s => s.trim()).filter(s => s.includes('='));
    if (parts.length) { const o = {}; parts.forEach(p => { const [k, ...v] = p.split('='); o[k.trim()] = v.join('=').trim(); }); return o; }
    return { [t('Властивість 1')]: i === 0 ? t('За замовчуванням') : String(name || t('Варіант {n}', { n: i + 1 })) };
  };
  C.nameOf = variant => Object.entries(variant).map(([k, v]) => `${k}=${v}`).join(', ');
  const SET_STYLE = { strokes: [O.paint.solid('#9747FF')], sw: 1, dash: [6, 4], sa: 'inside', fills: [], radius: 8, clip: false, layout: { dir: 'h', gap: 24, pad: [24, 24, 24, 24], align: 'start', justify: 'start', wMode: 'hug', hMode: 'hug' } };
  C.combine = () => {
    let nodes = O.topSel().filter(n => n.type === 'frame' && !n.componentSet);
    if (!nodes.length) return O.toast('Виділіть компоненти або фрейми, які стануть варіантами');
    const parent = model.parent(nodes[0]);
    const b = model.selBounds(nodes);
    const set = model.create('frame', Object.assign({ name: (nodes[0].name.split(/[=,]/)[0] || t('Компонент')).trim() + ' ' + t('(набір)'), w: b.w + 48, h: b.h + 48, m: M.translate(Math.round(b.x - 24), Math.round(b.y - 24)), componentSet: true }, O.clone(SET_STYLE)));
    const idx = Math.min(...nodes.map(n => parent.children.indexOf(n)));
    model.insert(set, parent, idx);
    nodes.sort((a, b2) => model.worldBounds(a).x - model.worldBounds(b2).x).forEach((n, i) => {
      n.component = true;
      n.variant = n.variant || C.parseName(n.name, i);
      n.name = C.nameOf(n.variant);
      model.reparent(n, set);
    });
    // every variant has every property
    const props = C.props(set);
    set.children.forEach(v => { for (const [k, vals] of props) if (!(k in v.variant)) v.variant[k] = vals[0]; v.name = C.nameOf(v.variant); });
    model.reindex();
    O.select([set.id]);
    O.history.commit('Об’єднати як варіанти');
    O.toast('Набір із {n} варіантів. Екземпляри перемикають варіанти на панелі «Дизайн»', { n: set.children.length });
  };
  C.addVariant = set => {
    const last = set.children[set.children.length - 1];
    if (!last) return;
    const v = model.cloneNode(last);
    const props = C.props(set);
    const first = Array.from(props.keys())[0];
    v.variant = Object.assign({}, last.variant, { [first]: t('Варіант {n}', { n: set.children.length + 1 }) });
    v.name = C.nameOf(v.variant);
    model.insert(v, set);
    O.select([v.id]);
    O.history.commit('Новий варіант');
  };
  // pick the variant of the set closest to the wanted property values
  C.find = (set, want) => {
    let best = null, score = -1;
    for (const v of set.children) {
      if (!v.variant) continue;
      let s = 0;
      for (const [k, val] of Object.entries(want)) if (v.variant[k] === val) s += k === want.__changed ? 100 : 1;
      if (s > score) { score = s; best = v; }
    }
    return best;
  };
  C.swap = (inst, prop, val) => {
    const comp = model.get(inst.ref), set = C.setOf(comp);
    if (!set) return;
    const want = Object.assign({}, comp.variant, { [prop]: val, __changed: prop });
    const v = C.find(set, want);
    if (v && v.id !== inst.ref) { inst.ref = v.id; if (inst.autoSize !== false) { inst.w = v.w; inst.h = v.h; } }
  };

  // ---------- Design panel ----------
  O.panels.extraSections.push(nodes => {
    if (nodes.length !== 1) return '';
    const n = nodes[0];
    let h = '';
    // component set: properties
    if (n.componentSet) {
      const props = C.props(n);
      h += ph.sec('Властивості варіантів', Array.from(props).map(([k, vals], i) => `<div class="row">${ph.inp(`data-vp="name" data-k="${esc(k)}"`, k, 'Властивість')}<span class="note vp-vals">${esc(vals.join(' · '))}</span></div>`).join('') +
        `<div class="row"><button type="button" class="btn" data-va="addprop">${esc(t('Нова властивість'))}</button><button type="button" class="btn" data-va="addvar">${esc(t('Новий варіант'))}</button></div>`);
    }
    // a variant: its values
    if (n.type === 'frame' && n.component && n.variant && C.setOf(n)) {
      h += ph.sec('Варіант', Object.entries(n.variant).map(([k, v]) => `<div class="row">${ph.inp(`data-vv="${esc(k)}"`, v, k)}</div>`).join(''));
    }
    // instance: variant selects + overrides
    if (n.type === 'instance') {
      const comp = model.get(n.ref);
      if (!comp) return h;
      const set = C.setOf(comp);
      let body = '';
      if (set) {
        for (const [k, vals] of C.props(set)) body += `<div class="row"><span class="vp-l">${esc(k)}</span>${ph.sel(`data-iv="${esc(k)}"`, comp.variant ? comp.variant[k] : '', vals.map(v => [v, v]), k)}</div>`;
      }
      // text layers and top-level layers of the component
      const map = pathMap(comp);
      const ov = n.ov || {};
      const texts = Array.from(map).filter(([, c]) => c.type === 'text').slice(0, 12);
      body += texts.map(([key, c]) => `<div class="row">${ph.inp(`data-io="text" data-key="${esc(key)}"`, ov[key] && ov[key].text !== undefined ? ov[key].text : c.text, c.name)}</div>`).join('');
      const tops = (comp.children || []).slice(0, 12);
      const tm = pathMap({ children: tops });
      body += `<div class="col">${Array.from(tm).filter(([key]) => !key.includes('/')).map(([key, c]) => { const vis = ov[key] && ov[key].visible !== undefined ? ov[key].visible : c.visible !== false; return `<label class="chk"><input type="checkbox" data-io="vis" data-key="${esc(key)}"${vis ? ' checked' : ''}><span>${esc(c.name)}</span></label>`; }).join('')}</div>`;
      if (Object.keys(ov).length) body += `<div class="row"><button type="button" class="btn" data-va="reset">${esc(t('Скинути зміни екземпляра'))}</button></div>`;
      h += ph.sec(set ? 'Властивості екземпляра' : 'Перевизначення екземпляра', body);
    }
    return h;
  });
  const sel1 = () => O.sel()[0];
  document.addEventListener('change', e => {
    const el = e.target;
    if (!ph.inProps(el)) return;
    const n = sel1();
    if (!n) return;
    if (el.dataset.iv && n.type === 'instance') { C.swap(n, el.dataset.iv, el.value); O.history.commit('Варіант'); return; }
    if (el.dataset.io && n.type === 'instance') {
      const key = el.dataset.key;
      n.ov = n.ov || {};
      n.ov[key] = n.ov[key] || {};
      if (el.dataset.io === 'text') n.ov[key].text = el.value;
      if (el.dataset.io === 'vis') n.ov[key].visible = el.checked;
      O.history.commit('Зміна екземпляра');
      return;
    }
    if (el.dataset.vv && n.variant) {
      n.variant[el.dataset.vv] = el.value.trim() || n.variant[el.dataset.vv];
      n.name = C.nameOf(n.variant);
      O.history.commit('Значення варіанта');
      return;
    }
    if (el.dataset.vp === 'name' && n.componentSet) {
      const old = el.dataset.k, nk = el.value.trim();
      if (!nk || nk === old) return;
      n.children.forEach(v => { if (v.variant && old in v.variant) { const o = {}; for (const [k, val] of Object.entries(v.variant)) o[k === old ? nk : k] = val; v.variant = o; v.name = C.nameOf(o); } });
      O.history.commit('Назва властивості');
    }
  });
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('button[data-va]');
    if (!b || !ph.inProps(b)) return;
    const n = sel1();
    if (!n) return;
    if (b.dataset.va === 'addvar' && n.componentSet) C.addVariant(n);
    if (b.dataset.va === 'addprop' && n.componentSet) {
      const k = t('Властивість {n}', { n: C.props(n).size + 1 });
      n.children.forEach(v => { v.variant = Object.assign({}, v.variant, { [k]: t('За замовчуванням') }); v.name = C.nameOf(v.variant); });
      O.history.commit('Нова властивість');
    }
    if (b.dataset.va === 'reset' && n.type === 'instance') { delete n.ov; O.history.commit('Скинути зміни екземпляра'); }
  });

  // component sets in the Assets panel insert their default (first) variant
  const orig = O.ops.insertInstance;
  O.ops.insertInstance = id => { const n = model.get(id); if (n && n.componentSet && n.children[0]) return orig(n.children[0].id); return orig(id); };
  // overlay: name of the set
  O.cmd('combineVariants', 'Об’єднати як варіанти', () => C.combine(), { keys: ['Ctrl+Alt+Shift+K'], group: 'Компоненти', enabled: () => O.sel().length >= 1 });
  O.cmd('addVariant', 'Додати варіант', () => { const n = sel1(); const set = n && (n.componentSet ? n : C.setOf(n)); if (set) C.addVariant(set); else O.toast('Виділіть набір варіантів'); }, { group: 'Компоненти' });
  const objMenu = O.MENUS.find(m => m[0] === 'Об’єкт');
  const compSub = objMenu && objMenu[1].find(x => x && x.label === 'Компоненти');
  if (compSub) compSub.items.splice(1, 0, 'combineVariants', 'addVariant');
})();
