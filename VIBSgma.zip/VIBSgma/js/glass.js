'use strict';
/* Obrys — Liquid Glass effect (Apple style): the content under a shape is blurred, saturated and
   refracted at the edges like a thick glass lens, then tinted by the shape's fills and lit by a specular rim.
   Rendered in plain SVG (displacement map + filters), so it shows on the canvas and in PNG / SVG / PDF export;
   the HTML export uses backdrop-filter. */
(function () {
  const O = window.O, M = O.M, R = O.R, model = O.model, S = O.state;
  const n_ = O.n, esc = O.esc, t = (s, v) => O.t(s, v);
  const GL = O.glass = {};
  GL.DEFAULT = { type: 'glass', visible: true, blur: 8, refract: 36, depth: 22, light: 0.7, sat: 1.6, x: 0, y: 0, color: '#FFFFFF', opacity: 0.15 };
  const SHAPES = new Set(['rect', 'frame', 'instance', 'ellipse', 'polygon', 'star', 'path', 'bool']);

  // displacement map: R / G = outward normal × lens strength near the edge, 128 = no shift
  const maps = new Map();
  GL.map = (w, h, r, depth, ellipse) => {
    const key = [Math.round(w), Math.round(h), Math.round(r), Math.round(depth), ellipse ? 1 : 0].join('|');
    if (maps.has(key)) return maps.get(key);
    const k = Math.min(1, 256 / Math.max(w, h, 1));
    const cw = Math.max(2, Math.round(w * k)), ch = Math.max(2, Math.round(h * k));
    const cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
    const c = cv.getContext('2d');
    const img = c.createImageData(cw, ch), d = img.data;
    const hw = w / 2, hh = h / 2, rr = Math.max(0, Math.min(r, hw, hh));
    const dep = Math.max(1, depth);
    for (let py = 0; py < ch; py++) {
      for (let px = 0; px < cw; px++) {
        const x = (px + 0.5) / k - hw, y = (py + 0.5) / k - hh;
        let dist, nx, ny;
        if (ellipse) {
          const ex = x / hw, ey = y / hh, rad = Math.hypot(ex, ey) || 1e-6;
          dist = (1 - rad) * Math.min(hw, hh);
          const gx = x / (hw * hw), gy = y / (hh * hh), gl = Math.hypot(gx, gy) || 1;
          nx = gx / gl; ny = gy / gl;
        } else {
          const qx = Math.abs(x) - (hw - rr), qy = Math.abs(y) - (hh - rr);
          if (qx > 0 && qy > 0) { const l = Math.hypot(qx, qy) || 1; dist = rr - l; nx = qx / l; ny = qy / l; }
          else if (qx > qy) { dist = rr - qx; nx = 1; ny = 0; }
          else { dist = rr - qy; nx = 0; ny = 1; }
          nx *= Math.sign(x) || 1; ny *= Math.sign(y) || 1;
        }
        const s = dist >= 0 && dist < dep ? Math.pow(1 - dist / dep, 2) : 0;
        const i = (py * cw + px) * 4;
        d[i] = Math.round(128 + nx * s * 127); d[i + 1] = Math.round(128 + ny * s * 127); d[i + 2] = 128; d[i + 3] = 255;
      }
    }
    c.putImageData(img, 0, 0);
    const url = cv.toDataURL('image/png');
    maps.set(key, url);
    if (maps.size > 80) maps.delete(maps.keys().next().value);
    return url;
  };

  // everything painted before n, in world coordinates (siblings below it, then up the tree)
  const backdrop = (n, sub) => {
    const parts = [];
    let child = n, parent = model.parent(n);
    while (parent) {
      const isPg = model.isPage(parent);
      const below = parent.children.slice(0, parent.children.indexOf(child)).filter(c => c.visible !== false);
      const P = isPg ? M.id() : model.worldMatrix(parent);
      const own = below.map(c => O.render.nodeMarkup(c, sub)).join('');
      if (own) parts.unshift(M.isId(P) ? own : `<g transform="${M.str(P)}">${own}</g>`);
      if (isPg) { if (parent.bg) parts.unshift(`<rect x="-100000" y="-100000" width="200000" height="200000" fill="${parent.bg}"/>`); break; }
      if (parent.type === 'frame') {
        // the frame's own background (without children or effects)
        const bare = Object.assign({}, parent, { children: [], effects: [], m: M.id(), strokes: [] });
        parts.unshift(`<g transform="${M.str(P)}">${O.render.nodeMarkup(bare, sub)}</g>`);
      }
      child = parent; parent = model.parent(parent);
    }
    return parts.join('');
  };

  O.render.fxHooks.push((n, ctx) => {
    const g = (n.effects || []).find(e => e.type === 'glass' && e.visible !== false);
    if (!g || ctx.ghost || !SHAPES.has(n.type) || !model.exists(n.id)) return null;
    const geo = O.geo(n);
    if (!geo) return null;
    const b = model.localBounds(n);
    if (b.w < 1 || b.h < 1) return null;
    const id = ctx.pfx + 'lg' + n.id;
    const sub = Object.assign({}, ctx, { ghost: true, hit: false, pfx: ctx.pfx + 'lg' + n.id + '_', defs: ctx.defs });
    let back = '';
    // inside component instances the tree position is the component's, not the instance's: no backdrop there
    if (!ctx.depth) { try { back = backdrop(n, sub); } catch (e) { console.warn(e); } }
    const blur = Math.max(0, g.blur || 0), refr = g.refract === undefined ? 36 : g.refract, depth = Math.max(1, g.depth || 22);
    const light = g.light === undefined ? 0.7 : g.light, sat = g.sat === undefined ? 1.6 : g.sat;
    const r = Array.isArray(n.radius) ? n.radius[0] : (n.radius || 0);
    const map = GL.map(b.w, b.h, n.type === 'ellipse' ? 0 : r, depth, n.type === 'ellipse');
    const pad = blur * 3 + Math.abs(refr) + 8;
    const inv = M.inv(model.worldMatrix(n));
    ctx.defs.push(`<clipPath id="${id}c"><${geo.tag} ${geo.attrs}/></clipPath>`);
    ctx.defs.push(`<filter id="${id}f" filterUnits="userSpaceOnUse" x="${n_(b.x - pad)}" y="${n_(b.y - pad)}" width="${n_(b.w + 2 * pad)}" height="${n_(b.h + 2 * pad)}" color-interpolation-filters="sRGB">` +
      `<feGaussianBlur in="SourceGraphic" stdDeviation="${n_(blur / 2)}" result="b"/>` +
      `<feImage href="${map}" xlink:href="${map}" x="${n_(b.x)}" y="${n_(b.y)}" width="${n_(b.w)}" height="${n_(b.h)}" preserveAspectRatio="none" result="m"/>` +
      `<feDisplacementMap in="b" in2="m" scale="${n_(refr)}" xChannelSelector="R" yChannelSelector="G" result="d"/>` +
      `<feColorMatrix in="d" type="saturate" values="${n_(sat)}"/></filter>`);
    // specular rim: bright top-left and bottom-right edges, plus a soft sheen from the top
    ctx.defs.push(`<linearGradient id="${id}r" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="${n_(light)}"/><stop offset=".32" stop-color="#fff" stop-opacity="0"/><stop offset=".7" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#fff" stop-opacity="${n_(light * 0.55)}"/></linearGradient>`);
    ctx.defs.push(`<linearGradient id="${id}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="${n_(light * 0.22)}"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/></linearGradient>`);
    const rim = Math.max(1, Math.min(b.w, b.h) / 60);
    const pre = `<g clip-path="url(#${id}c)" pointer-events="none"><g filter="url(#${id}f)"><g transform="${M.str(inv)}">${back}</g></g></g>`;
    const post = `<g pointer-events="none" clip-path="url(#${id}c)"><${geo.tag} ${geo.attrs} fill="url(#${id}s)"/><${geo.tag} ${geo.attrs} fill="none" stroke="url(#${id}r)" stroke-width="${n_(rim * 2)}"/></g>`;
    return { pre, post };
  });

  // apply to the selection: a light tint so the glass reads on any background
  GL.apply = () => {
    const ns = O.topSel().filter(n => SHAPES.has(n.type));
    if (!ns.length) return O.toast('Виділіть прямокутник, еліпс, фрейм або контур');
    ns.forEach(n => {
      n.effects = (n.effects || []).filter(e => e.type !== 'glass');
      n.effects.unshift(Object.assign({}, GL.DEFAULT));
      if (!n.effects.some(e => e.type === 'shadow')) n.effects.push({ type: 'shadow', x: 0, y: 8, blur: 24, spread: 0, color: '#000000', opacity: 0.18, visible: true });
      const solid = (n.fills || []).filter(f => f.visible !== false);
      if (!solid.length || solid.every(f => f.type === 'solid' && (f.opacity === undefined || f.opacity > 0.5))) n.fills = [O.paint.solid('#FFFFFF', 0.12)];
      if ((n.type === 'rect' || n.type === 'frame') && !n.radius) n.radius = Math.round(Math.min(n.w, n.h) * 0.22);
    });
    O.history.commit('Liquid Glass');
  };
  // ready-made glass panel over whatever is under the view centre
  GL.panel = () => {
    const V = O.view, c = R.center(V.viewRect());
    const cont = V.containerAt(c);
    const lp = M.apply(M.inv(model.containerMatrix(cont)), c);
    const n = model.create('rect', { name: 'Liquid Glass', w: 320, h: 120, radius: 36, m: M.translate(Math.round(lp.x - 160), Math.round(lp.y - 60)), fills: [O.paint.solid('#FFFFFF', 0.12)], effects: [Object.assign({}, GL.DEFAULT), { type: 'shadow', x: 0, y: 8, blur: 24, spread: 0, color: '#000000', opacity: 0.18, visible: true }] });
    model.insert(n, cont);
    O.select([n.id]);
    O.history.commit('Liquid Glass');
  };
  O.cmd('fxGlass', 'Liquid Glass (рідке скло)', () => GL.apply(), { group: 'Ефект' });
  O.cmd('glassPanel', 'Нова панель Liquid Glass', () => GL.panel(), { group: 'Ефект' });
  const fx = O.MENUS.find(m => m[0] === 'Ефект');
  if (fx) fx[1].splice(fx[1].indexOf('fxBlur') + 1, 0, 'fxGlass', 'glassPanel');
})();
