'use strict';
/* Obrys — design system (Figma: Styles & Variables).
   · Colour styles = document swatches. A paint linked to a style keeps p.sw = swatch id: editing the swatch
     recolours every linked fill / stroke. Swatches can have a value per mode (Light / Dark …) — colour variables.
   · Text styles (paragraph styles of the publishing module), effect styles, layout-grid styles.
   All of them live in the Assets tab and travel with Libraries. */
(function () {
  const O = window.O, model = O.model, S = O.state, ui = O.ui, ph = O.ph;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const ST = O.styles = {};

  // ---------- colour styles & modes ----------
  ST.modes = () => (S.doc.modes && S.doc.modes.length ? S.doc.modes : [t('Світлий')]);
  ST.mode = () => S.doc.mode || ST.modes()[0];
  ST.value = sw => { const m = ST.mode(); return (sw.modes && sw.modes[m]) || sw.color; };
  const paints = n => (n.fills || []).concat(n.strokes || []);
  const eachNode = fn => { for (const pg of S.doc.pages) model.walk(pg.children, fn); };
  // write the current values of the colour styles into every linked paint
  ST.sync = () => {
    const by = new Map((S.doc.swatches || []).map(s => [s.id, s]));
    eachNode(n => {
      for (const p of paints(n)) if (p.sw) { const s = by.get(p.sw); if (s) p.color = ST.value(s); else delete p.sw; }
      for (const e of n.effects || []) if (e.sw) { const s = by.get(e.sw); if (s) e.color = ST.value(s); }
    });
  };
  // a paint whose colour was changed by hand is no longer linked
  const detachEdited = () => {
    if (!S.doc) return;
    const by = new Map((S.doc.swatches || []).map(s => [s.id, s]));
    eachNode(n => { for (const p of paints(n)) if (p.sw) { const s = by.get(p.sw); if (!s || (p.type !== 'solid') || String(p.color).toUpperCase() !== String(ST.value(s)).toUpperCase()) delete p.sw; } });
  };
  {
    const H = O.history, orig = H.commit;
    H.commit = label => { try { if (!ST.syncing) detachEdited(); } catch (e) { console.error(e); } return orig(label); };
  }
  ST.apply = (sw, stroke) => {
    const nodes = O.topSel();
    nodes.forEach(n => {
      const p = Object.assign(O.paint.solid(ST.value(sw)), { sw: sw.id });
      if (stroke) { n.strokes = [p]; if (!n.sw) n.sw = 1; } else n.fills = [p];
    });
    O.history.commit('Кольоровий стиль');
  };
  ST.setMode = m => { S.doc.mode = m; ST.syncing = true; try { ST.sync(); O.history.commit('Режим кольорів'); } finally { ST.syncing = false; } };
  ST.editSwatch = sw => {
    const modes = ST.modes();
    ui.dialog({
      title: 'Кольоровий стиль',
      body: `<div class="dlg-text">${esc(t('Зміна кольору оновить усі об’єкти, пов’язані з цим стилем. Для кожного режиму можна задати свій колір (як змінні Figma).'))}</div>`,
      fields: [{ key: 'name', label: 'Назва (можна групу: «Бренд/Основний»)', type: 'text', value: sw.name }].concat(modes.map((m, i) => ({ key: 'm' + i, label: t('Колір: {m}', { m }), type: 'text', value: (i === 0 ? sw.color : (sw.modes && sw.modes[m]) || sw.color) }))),
      onOk: v => {
        sw.name = v.name.trim() || sw.name;
        modes.forEach((m, i) => {
          const c = O.color.norm(v['m' + i]);
          if (!c) return;
          if (i === 0) sw.color = c;
          sw.modes = sw.modes || {};
          sw.modes[m] = c;
        });
        ST.syncing = true; try { ST.sync(); O.history.commit('Кольоровий стиль'); } finally { ST.syncing = false; }
      }
    });
  };
  // swatch clicks in Assets: link the paint (capture phase, before the plain «copy colour» handler)
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('#lp-assets [data-sw]');
    if (!b || !O.topSel().length) return;
    const sw = (S.doc.swatches || []).find(x => x.id === b.dataset.sw);
    if (!sw) return;
    e.stopPropagation(); e.preventDefault();
    ST.apply(sw, e.shiftKey);
  }, true);
  document.addEventListener('dblclick', e => {
    const b = e.target.closest && e.target.closest('#lp-assets [data-sw]');
    if (!b) return;
    const sw = (S.doc.swatches || []).find(x => x.id === b.dataset.sw);
    if (sw) ST.editSwatch(sw);
  });
  document.addEventListener('contextmenu', e => {
    const b = e.target.closest && e.target.closest('#lp-assets [data-sw]');
    if (!b) return;
    e.preventDefault(); e.stopPropagation();
    const sw = (S.doc.swatches || []).find(x => x.id === b.dataset.sw);
    ui.menu([{ id: 'edit', label: 'Редагувати стиль…' }, { id: 'fill', label: 'Застосувати як заливку' }, { id: 'stroke', label: 'Застосувати як обведення' }, { id: 'sel', label: 'Виділити об’єкти з цим стилем' }, '-', { id: 'del', label: 'Видалити стиль' }], e.clientX, e.clientY, {
      onPick: id => {
        if (id === 'edit') ST.editSwatch(sw);
        if (id === 'fill' || id === 'stroke') ST.apply(sw, id === 'stroke');
        if (id === 'sel') { const ids = []; model.walk(model.page().children, n => { if (paints(n).some(p => p.sw === sw.id)) ids.push(n.id); }); O.select(ids); }
        if (id === 'del') { S.doc.swatches = S.doc.swatches.filter(x => x !== sw); eachNode(n => paints(n).forEach(p => { if (p.sw === sw.id) delete p.sw; })); O.history.commit('Видалення стилю'); }
      }
    });
  }, true);

  // ---------- effect & grid styles ----------
  const fxStyles = () => (S.doc.fxStyles = S.doc.fxStyles || []);
  const gridStyles = () => (S.doc.gridStyles = S.doc.gridStyles || []);
  ST.newFx = () => {
    const n = O.sel()[0];
    if (!n || !(n.effects || []).length) return O.toast('Виділіть об’єкт з ефектами (тінь, розмиття, Liquid Glass…)');
    ui.dialog({ title: 'Новий стиль ефектів', fields: [{ key: 'n', label: 'Назва', type: 'text', value: t('Тінь {n}', { n: fxStyles().length + 1 }) }], onOk: v => { const st = { id: O.uid(), name: v.n.trim() || t('Ефект'), effects: O.clone(n.effects) }; fxStyles().push(st); n.fxStyle = st.id; O.history.commit('Стиль ефектів'); } });
  };
  ST.newGrid = () => {
    const n = O.sel()[0];
    if (!n || n.type !== 'frame' || !(n.grids || []).length) return O.toast('Виділіть фрейм із сіткою макета');
    ui.dialog({ title: 'Новий стиль сітки', fields: [{ key: 'n', label: 'Назва', type: 'text', value: t('Сітка {n}', { n: gridStyles().length + 1 }) }], onOk: v => { const st = { id: O.uid(), name: v.n.trim() || t('Сітка'), grids: O.clone(n.grids) }; gridStyles().push(st); n.gridStyle = st.id; O.history.commit('Стиль сітки'); } });
  };
  const applyFx = st => { O.topSel().forEach(n => { n.effects = O.clone(st.effects); n.fxStyle = st.id; }); O.history.commit('Стиль ефектів'); };
  const applyGrid = st => { O.topSel().filter(n => n.type === 'frame').forEach(n => { n.grids = O.clone(st.grids); n.gridStyle = st.id; }); O.history.commit('Стиль сітки'); };
  // redefine from the selection and update every user
  const redefine = (kind, st) => {
    const n = O.sel()[0];
    if (!n) return;
    if (kind === 'fx') { st.effects = O.clone(n.effects || []); eachNode(x => { if (x.fxStyle === st.id) x.effects = O.clone(st.effects); }); }
    if (kind === 'grid') { st.grids = O.clone(n.grids || []); eachNode(x => { if (x.gridStyle === st.id) x.grids = O.clone(st.grids); }); }
    O.history.commit('Оновлення стилю');
  };

  // ---------- Assets tab: modes, text / effect / grid styles ----------
  const box = () => O.$('#lp-assets');
  const ensureSection = () => {
    let el = O.$('#as-styles');
    if (!el && box()) { el = O.h('<div id="as-styles"></div>'); box().appendChild(el); }
    return el;
  };
  ST.render = () => {
    const el = ensureSection();
    if (!el || !S.doc || box().hidden) return;
    const modes = ST.modes();
    const pst = S.doc.pstyles || [];
    const sw = (S.doc.swatches || []);
    const groups = new Map();
    for (const s of sw) { const g = s.name.includes('/') ? s.name.split('/')[0] : ''; if (!groups.has(g)) groups.set(g, []); groups.get(g).push(s); }
    el.innerHTML = `<section><div class="sec-h"><span>${esc(t('Режими кольорів'))}</span><button type="button" class="ib" data-st="addmode" title="${esc(t('Додати режим (наприклад «Темний»)'))}" aria-label="${esc(t('Додати режим'))}">${O.icon('plus', 16)}</button></div>
        <div class="st-modes">${modes.map(m => `<button type="button" class="st-mode${m === ST.mode() ? ' on' : ''}" data-mode="${esc(m)}">${esc(m)}</button>`).join('')}</div>
        <div class="as-empty small">${esc(t('Клік на колір — заливка, Shift+клік — обведення, подвійний клік — редагувати. Колір з прив’язкою оновлюється всюди.'))}</div></section>
      ${groups.size > 1 ? `<section><div class="sec-h"><span>${esc(t('Групи кольорів'))}</span></div>${Array.from(groups).map(([g, list]) => `<div class="st-grp"><b>${esc(g || t('Без групи'))}</b><div class="as-sw">${list.map(s => `<button type="button" class="sw big" style="--c:${ST.value(s)}" data-sw="${s.id}" title="${esc(s.name)} ${ST.value(s)}"></button>`).join('')}</div></div>`).join('')}</section>` : ''}
      <section><div class="sec-h"><span>${esc(t('Стилі тексту'))}</span><button type="button" class="ib" data-st="addtext" title="${esc(t('Новий стиль тексту з виділеного'))}" aria-label="${esc(t('Новий стиль тексту'))}">${O.icon('plus', 16)}</button></div>
        ${pst.length ? pst.map(s => `<button type="button" class="st-row" data-pst-apply="${s.id}" title="${esc(t('Застосувати до виділених текстів'))}"><span class="st-prev" style="font-family:'${esc(s.props.font)}',var(--font);font-weight:${s.props.weight || 400};${s.props.italic ? 'font-style:italic;' : ''}">${esc(t('Аа'))}</span><span>${esc(s.name)}</span><em>${esc(s.props.font)} · ${O.fmt(s.props.size)}</em></button>`).join('') : `<div class="as-empty">${esc(t('Немає. Виділіть текст і натисніть +'))}</div>`}</section>
      <section><div class="sec-h"><span>${esc(t('Стилі ефектів'))}</span><button type="button" class="ib" data-st="addfx" title="${esc(t('Новий стиль з ефектів виділеного'))}" aria-label="${esc(t('Новий стиль ефектів'))}">${O.icon('plus', 16)}</button></div>
        ${fxStyles().length ? fxStyles().map(s => `<div class="st-row2"><button type="button" class="st-row" data-fx-apply="${s.id}"><span class="st-fx"></span><span>${esc(s.name)}</span><em>${esc(s.effects.map(e => e.type).join(', '))}</em></button>${ph.ib(`data-st="fxupd" data-id="${s.id}"`, 'rotate', 'Оновити з виділеного')}${ph.ib(`data-st="fxdel" data-id="${s.id}"`, 'minus', 'Видалити')}</div>`).join('') : `<div class="as-empty">${esc(t('Немає. Виділіть об’єкт з тінню і натисніть +'))}</div>`}</section>
      <section><div class="sec-h"><span>${esc(t('Стилі сітки'))}</span><button type="button" class="ib" data-st="addgrid" title="${esc(t('Новий стиль із сітки виділеного фрейма'))}" aria-label="${esc(t('Новий стиль сітки'))}">${O.icon('plus', 16)}</button></div>
        ${gridStyles().length ? gridStyles().map(s => `<div class="st-row2"><button type="button" class="st-row" data-grid-apply="${s.id}"><span class="st-grid"></span><span>${esc(s.name)}</span><em>${esc(s.grids.map(g => g.type === 'grid' ? g.size + 'px' : g.count + ' ' + t(g.type === 'columns' ? 'колонок' : 'рядків')).join(', '))}</em></button>${ph.ib(`data-st="gridupd" data-id="${s.id}"`, 'rotate', 'Оновити з виділеного')}${ph.ib(`data-st="griddel" data-id="${s.id}"`, 'minus', 'Видалити')}</div>`).join('') : `<div class="as-empty">${esc(t('Немає. Виділіть фрейм із сіткою макета і натисніть +'))}</div>`}</section>`;
  };
  const origRender = O.panels.renderAssets;
  O.panels.renderAssets = () => { origRender(); try { ST.render(); } catch (e) { console.error(e); } };
  // the swatch list shows the colour of the current mode
  O.on('change', () => { const el = O.$('#as-sw'); if (!el) return; el.querySelectorAll('[data-sw]').forEach(b => { const s = (S.doc.swatches || []).find(x => x.id === b.dataset.sw); if (s) b.style.setProperty('--c', ST.value(s)); }); });
  document.addEventListener('click', e => {
    const el = e.target.closest && e.target.closest('#as-styles [data-st], #as-styles [data-mode], #as-styles [data-pst-apply], #as-styles [data-fx-apply], #as-styles [data-grid-apply]');
    if (!el) return;
    const d = el.dataset;
    if (d.mode) return ST.setMode(d.mode);
    if (d.pstApply) { const st = (S.doc.pstyles || []).find(s => s.id === d.pstApply); const texts = O.sel().filter(n => n.type === 'text'); if (!texts.length) return O.toast('Виділіть текст'); texts.forEach(n => O.print.applyStyle(n, st)); O.history.commit('Стиль тексту'); return; }
    if (d.fxApply) { const st = fxStyles().find(s => s.id === d.fxApply); if (!O.sel().length) return O.toast('Виділіть об’єкт'); applyFx(st); return; }
    if (d.gridApply) { const st = gridStyles().find(s => s.id === d.gridApply); if (!O.sel().some(n => n.type === 'frame')) return O.toast('Виділіть фрейм'); applyGrid(st); return; }
    switch (d.st) {
      case 'addmode': ui.dialog({ title: 'Новий режим кольорів', fields: [{ key: 'n', label: 'Назва', type: 'text', value: ST.modes().length === 1 ? t('Темний') : t('Режим {n}', { n: ST.modes().length + 1 }) }], onOk: v => { const nm = v.n.trim(); if (!nm || ST.modes().includes(nm)) return; S.doc.modes = ST.modes().concat([nm]); O.history.commit('Режим кольорів'); O.toast('Подвійний клік по кольору — задати його значення в режимі «{m}»', { m: nm }); } }); break;
      case 'addtext': { const tx = O.sel().find(n => n.type === 'text'); if (!tx) return O.toast('Виділіть текст'); ui.dialog({ title: 'Новий стиль тексту', fields: [{ key: 'n', label: 'Назва', type: 'text', value: t('Стиль {n}', { n: (S.doc.pstyles || []).length + 1 }) }], onOk: v => { const st = { id: O.uid(), name: v.n.trim() || t('Стиль'), props: O.print.styleOf(tx) }; S.doc.pstyles = (S.doc.pstyles || []).concat([st]); O.print.applyStyle(tx, st); O.history.commit('Стиль тексту'); } }); break; }
      case 'addfx': ST.newFx(); break;
      case 'addgrid': ST.newGrid(); break;
      case 'fxupd': redefine('fx', fxStyles().find(s => s.id === d.id)); break;
      case 'gridupd': redefine('grid', gridStyles().find(s => s.id === d.id)); break;
      case 'fxdel': S.doc.fxStyles = fxStyles().filter(s => s.id !== d.id); eachNode(n => { if (n.fxStyle === d.id) delete n.fxStyle; }); O.history.commit('Видалення стилю'); break;
      case 'griddel': S.doc.gridStyles = gridStyles().filter(s => s.id !== d.id); eachNode(n => { if (n.gridStyle === d.id) delete n.gridStyle; }); O.history.commit('Видалення стилю'); break;
    }
  });
  // Design panel: which styles the selection uses
  O.panels.extraSections.push(nodes => {
    if (nodes.length !== 1) return '';
    const n = nodes[0];
    const chips = [];
    const sw = new Map((S.doc.swatches || []).map(s => [s.id, s]));
    (n.fills || []).forEach((p, i) => { if (p.sw && sw.get(p.sw)) chips.push(`<span class="st-chip"><i style="--c:${p.color}"></i>${esc(t('Заливка'))}: ${esc(sw.get(p.sw).name)}<button type="button" class="link" data-stu="fill" data-i="${i}">${esc(t('від’єднати'))}</button></span>`); });
    (n.strokes || []).forEach((p, i) => { if (p.sw && sw.get(p.sw)) chips.push(`<span class="st-chip"><i style="--c:${p.color}"></i>${esc(t('Обведення'))}: ${esc(sw.get(p.sw).name)}<button type="button" class="link" data-stu="stroke" data-i="${i}">${esc(t('від’єднати'))}</button></span>`); });
    const fx = n.fxStyle && fxStyles().find(s => s.id === n.fxStyle);
    if (fx) chips.push(`<span class="st-chip">${esc(t('Ефекти'))}: ${esc(fx.name)}<button type="button" class="link" data-stu="fx">${esc(t('від’єднати'))}</button></span>`);
    const gr = n.gridStyle && gridStyles().find(s => s.id === n.gridStyle);
    if (gr) chips.push(`<span class="st-chip">${esc(t('Сітка'))}: ${esc(gr.name)}<button type="button" class="link" data-stu="grid">${esc(t('від’єднати'))}</button></span>`);
    const solid = (n.fills || []).find(p => p.type === 'solid' && !p.sw);
    const mk = solid ? `<button type="button" class="btn" data-stu="mkcolor">${esc(t('Створити кольоровий стиль із заливки'))}</button>` : '';
    if (!chips.length && !mk) return '';
    return ph.sec('Стилі', `<div class="col">${chips.join('')}</div>${mk ? `<div class="row">${mk}</div>` : ''}`);
  });
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('[data-stu]');
    if (!b || !ph.inProps(b)) return;
    const n = O.sel()[0];
    if (!n) return;
    const k = b.dataset.stu, i = +b.dataset.i;
    if (k === 'fill') delete n.fills[i].sw;
    if (k === 'stroke') delete n.strokes[i].sw;
    if (k === 'fx') delete n.fxStyle;
    if (k === 'grid') delete n.gridStyle;
    if (k === 'mkcolor') {
      const p = (n.fills || []).find(x => x.type === 'solid' && !x.sw);
      const sw = { id: O.uid(), name: t('Колір {n}', { n: (S.doc.swatches || []).length + 1 }), color: p.color };
      S.doc.swatches.push(sw); p.sw = sw.id;
      O.history.commit('Кольоровий стиль');
      return ST.editSwatch(sw);
    }
    O.history.commit('Від’єднати стиль');
  });
  O.cmd('colorModeNext', 'Перемкнути режим кольорів (світлий / темний)', () => { const m = ST.modes(); if (m.length < 2) return O.toast('Додайте другий режим у вкладці «Ресурси» → «Режими кольорів»'); ST.setMode(m[(m.indexOf(ST.mode()) + 1) % m.length]); O.toast('Режим: {m}', { m: ST.mode() }); }, { keys: ['Alt+M'], group: 'Ресурси' });
  O.cmd('newFxStyle', 'Новий стиль ефектів', () => ST.newFx(), { group: 'Ресурси' });
  O.cmd('newGridStyle', 'Новий стиль сітки', () => ST.newGrid(), { group: 'Ресурси' });
})();
