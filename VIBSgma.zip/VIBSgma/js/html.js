'use strict';
/* Obrys — design → HTML + CSS
   · frames → pages, auto layout → flexbox, boxes and text → elements, complex vectors → inline SVG
   · «Перо анімації» chains → CSS @keyframes on the first object (the other objects are its key states)
   · «Перо адаптації» groups → one responsive page: the widest frame is the base, narrower frames become @media overrides.
     Elements are matched between frames by their layer path (names), like Smart Animate. */
(function () {
  const O = window.O, M = O.M, R = O.R, model = O.model, S = O.state;
  const t = (s, v) => O.t(s, v), esc = O.esc;
  const HX = O.html = {};
  const px = v => (Math.round(v * 100) / 100) + 'px';
  const num = v => Math.round(v * 1000) / 1000;
  const rgba = (hex, a) => { const c = O.color.parse(hex) || { r: 0, g: 0, b: 0 }; return a >= 1 ? String(hex).toLowerCase() : `rgba(${c.r}, ${c.g}, ${c.b}, ${num(a)})`; };
  const slug = s => (String(s || 'el').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '')
    .replace(/[а-яіїєґё]/g, ch => ({ а: 'a', б: 'b', в: 'v', г: 'h', ґ: 'g', д: 'd', е: 'e', є: 'ie', ж: 'zh', з: 'z', и: 'y', і: 'i', ї: 'i', й: 'i', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'kh', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'shch', ь: '', ю: 'iu', я: 'ia', ы: 'y', э: 'e', ё: 'e', ъ: '' }[ch] || ''))
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 32) || 'el');
  HX.slug = s => { const v = slug(s); return /^[0-9]/.test(v) ? 'x' + v : v; };

  // ---------- paints & effects ----------
  const paintCSS = (p, n, url) => {
    const op = p.opacity === undefined ? 1 : p.opacity;
    if (p.type === 'solid') return { color: rgba(p.color, op), layer: `linear-gradient(${rgba(p.color, op)}, ${rgba(p.color, op)})` };
    const stops = (p.stops || []).slice().sort((a, b) => a.o - b.o).map(s => rgba(s.color, (s.a === undefined ? 1 : s.a) * op) + ' ' + Math.round(s.o * 100) + '%').join(', ');
    if (p.type === 'linear') {
      const b = model.localBounds(n);
      const dx = (p.to.x - p.from.x) * b.w, dy = (p.to.y - p.from.y) * b.h;
      return { layer: `linear-gradient(${Math.round(O.deg(Math.atan2(dx, -dy)))}deg, ${stops})` };
    }
    if (p.type === 'radial') return { layer: `radial-gradient(ellipse at ${num(p.from.x * 100)}% ${num(p.from.y * 100)}%, ${stops})` };
    if (p.type === 'image') {
      const a = S.doc.assets[p.asset];
      if (!a) return null;
      const size = p.mode === 'fit' ? 'contain' : p.mode === 'stretch' ? '100% 100%' : p.mode === 'tile' ? `${num((a.w || 100) * (p.scale || 1))}px auto` : 'cover';
      return { layer: `url("${url(p.asset)}") center / ${size} ${p.mode === 'tile' ? 'repeat' : 'no-repeat'}` };
    }
    return null;
  };
  const effectsCSS = (n, text) => {
    const out = [];
    const all = (n.effects || []).filter(e => e.visible !== false);
    const fx = all.filter(e => e.type !== 'glass');
    // Liquid Glass → backdrop-filter + light rim
    const gl = all.find(e => e.type === 'glass');
    if (gl && !text) {
      const bf = `blur(${px(Math.max(0, gl.blur || 0) / 2)}) saturate(${O.fmt(gl.sat === undefined ? 1.6 : gl.sat, 2)})`;
      out.push(`backdrop-filter: ${bf}`, `-webkit-backdrop-filter: ${bf}`);
    }
    const sh = fx.filter(e => e.type !== 'blur').map(e => {
      const glow = e.type === 'glow' || e.type === 'innerglow';
      const inset = e.type === 'inner' || e.type === 'innerglow';
      const c = rgba(e.color || '#000000', e.opacity === undefined ? 0.25 : e.opacity);
      return text ? `${px(glow ? 0 : e.x)} ${px(glow ? 0 : e.y)} ${px(e.blur || 0)} ${c}` : `${inset ? 'inset ' : ''}${px(glow ? 0 : e.x)} ${px(glow ? 0 : e.y)} ${px(e.blur || 0)} ${px(e.spread || 0)} ${c}`;
    });
    if (sh.length && text) out.push(`text-shadow: ${sh.join(', ')}`);
    const bl = fx.find(e => e.type === 'blur');
    // photo corrections + layer blur share the CSS filter property
    const filters = [n.adjust && O.photo ? O.photo.cssFilter(n.adjust) : '', bl ? `blur(${px((bl.blur || 0) / 2)})` : ''].filter(Boolean);
    if (filters.length) out.push(`filter: ${filters.join(' ')}`);
    if (gl && !text) { const l = gl.light === undefined ? 0.6 : gl.light; sh.push(`inset 1px 1px 0 ${rgba('#FFFFFF', l)}`, `inset -1px -1px 0 ${rgba('#FFFFFF', l * 0.45)}`, `inset 0 0 ${px((gl.depth || 20) / 2)} ${rgba('#FFFFFF', l * 0.25)}`); }
    return { lines: out, shadows: text ? [] : sh };
  };
  const strokeShadows = n => {
    const st = (n.strokes || []).filter(s => s.visible !== false && s.type === 'solid');
    if (!st.length || !(n.sw > 0)) return [];
    const c = rgba(st[0].color, st[0].opacity === undefined ? 1 : st[0].opacity);
    if (n.sa === 'inside') return [`inset 0 0 0 ${px(n.sw)} ${c}`];
    if (n.sa === 'outside') return [`0 0 0 ${px(n.sw)} ${c}`];
    return [`0 0 0 ${px(n.sw / 2)} ${c}`, `inset 0 0 0 ${px(n.sw / 2)} ${c}`];
  };
  const radiusCSS = n => {
    if (n.type === 'ellipse') return 'border-radius: 50%';
    if (!n.radius) return '';
    return 'border-radius: ' + (Array.isArray(n.radius) ? n.radius.map(px).join(' ') : px(n.radius));
  };
  const solidOf = n => { const f = (n.fills || []).find(p => p.visible !== false); return f && f.type === 'solid' ? rgba(f.color, f.opacity === undefined ? 1 : f.opacity) : null; };
  // can this node be expressed as a plain element (no skew, no flips, no scaling)?
  const simpleBox = rel => {
    const d = M.decompose(rel);
    return Math.abs(d.skew) < 1e-6 && d.sy > 0 && Math.abs(d.sx - 1) < 1e-3 && Math.abs(d.sy - 1) < 1e-3;
  };

  // ---------- CSS declarations as ordered maps ----------
  const decl = lines => { const m = new Map(); for (const l of lines) { if (!l) continue; const i = l.indexOf(':'); if (i > 0) m.set(l.slice(0, i).trim(), l.slice(i + 1).trim()); } return m; };
  const block = (sel, m, ind = '') => (m && m.size ? `${ind}${sel} {\n${Array.from(m).map(([k, v]) => `${ind}  ${k}: ${v};`).join('\n')}\n${ind}}\n` : '');
  const RESET = { transform: 'none', 'transform-origin': '50% 50%', opacity: '1', 'mix-blend-mode': 'normal', filter: 'none', 'box-shadow': 'none', background: 'none', 'border-radius': '0', outline: 'none', 'outline-offset': '0', 'text-shadow': 'none', 'letter-spacing': 'normal', 'text-align': 'start', 'text-decoration': 'none', 'text-transform': 'none', 'font-style': 'normal', 'line-height': 'normal', overflow: 'visible', width: 'auto', height: 'auto', left: 'auto', top: 'auto', 'white-space': 'normal', color: 'inherit', '-webkit-background-clip': 'border-box', 'background-clip': 'border-box', 'flex-direction': 'row', gap: '0', padding: '0', 'align-items': 'normal', 'justify-content': 'normal', 'object-fit': 'fill', 'font-weight': '400' };
  const KEEP = new Set(['animation', 'animation-play-state', 'will-change']);

  // ---------- links ----------
  HX.links = kind => ((S.doc && S.doc.links) || []).filter(l => l.kind === kind && l.ids.filter(id => model.exists(id)).length >= 2);
  HX.EASE = { 'ease-in-out': 'ease-in-out', ease: 'ease', 'ease-in': 'ease-in', 'ease-out': 'ease-out', linear: 'linear', spring: 'cubic-bezier(0.34, 1.56, 0.64, 1)', smooth: 'cubic-bezier(0.65, 0, 0.35, 1)' };
  const topFrameOf = n => { let c = n, p = model.parent(c); while (p && !model.isPage(p)) { c = p; p = model.parent(c); } return c !== n && c.type === 'frame' ? c : null; };
  HX.topFrameOf = topFrameOf;
  // world matrix of a key state; a state in another frame keeps its position relative to that frame (Smart Animate)
  const stateWorld = (actor, st) => {
    const fa = topFrameOf(actor), fs = topFrameOf(st);
    const W = model.worldMatrix(st);
    if (fa && fs && fa !== fs) return M.mul(model.worldMatrix(fa), M.mul(M.inv(model.worldMatrix(fs)), W));
    return W;
  };
  const geom = (n, W, container, box) => {
    const rel = M.mul(M.inv(model.containerMatrix(container)), W);
    const lb = model.localBounds(n);
    if (box) { const b = R.transform(lb, rel); return { c: { x: b.x + b.w / 2, y: b.y + b.h / 2 }, rot: 0, w: b.w, h: b.h }; }
    const d = M.decompose(rel);
    return { c: M.apply(rel, { x: lb.x + lb.w / 2, y: lb.y + lb.h / 2 }), rot: O.deg(d.rot), w: lb.w * Math.abs(d.sx), h: lb.h * Math.abs(d.sy) };
  };
  HX.animFor = (link, actor, container, box) => {
    const nodes = link.ids.filter(id => model.exists(id)).map(model.get);
    const g0 = geom(actor, model.worldMatrix(actor), container, box);
    const durs = nodes.slice(1).map((_, i) => Math.max(0.05, +(link.steps && link.steps[i]) || +link.step || 0.8));
    const total = durs.reduce((a, b) => a + b, 0);
    const ease = HX.EASE[link.ease] || 'ease-in-out';
    const name = 'obrys-' + HX.slug(actor.name) + '-' + String(link.id).slice(-4);
    const c0 = solidOf(actor);
    let acc = 0;
    const steps = nodes.map((st, i) => {
      const g = i === 0 ? g0 : geom(st, stateWorld(actor, st), container, box);
      if (i > 0) acc += durs[i - 1];
      const pct = i === 0 ? 0 : acc / total * 100;
      const lines = [`transform: translate(${px(g.c.x - g0.c.x)}, ${px(g.c.y - g0.c.y)}) rotate(${num(g.rot)}deg) scale(${num(g.w / (g0.w || 1))}, ${num(g.h / (g0.h || 1))})`, `opacity: ${num(st.opacity === undefined ? 1 : st.opacity)}`];
      const col = solidOf(st);
      if (col && c0 && !box) lines.push(actor.type === 'text' ? `color: ${col}` : `background-color: ${col}`);
      if (i < nodes.length - 1) lines.push(`animation-timing-function: ${ease}`);
      return `  ${num(pct)}% { ${lines.join('; ')}; }`;
    });
    const iter = link.repeat === 'once' ? '1' : 'infinite';
    const dir = link.repeat === 'pingpong' ? 'alternate' : 'normal';
    return { name, total, keyframes: `@keyframes ${name} {\n${steps.join('\n')}\n}\n`, anim: `${name} ${num(total)}s linear ${num(link.delay || 0)}s ${iter} ${dir} both` };
  };

  // ---------- emitter: design nodes → element tree + CSS per class ----------
  const newCtx = (opts = {}) => {
    const used = new Map();
    const ctx = { rules: new Map(), extra: [], kf: [], fonts: new Set(), skip: new Set(), actors: new Map(), keys: null, byKey: new Map(), assets: opts.files ? new Map() : null, script: false };
    ctx.uniq = base => { const b = HX.slug(base); const k = (used.get(b) || 0) + 1; used.set(b, k); return k > 1 ? b + '-' + k : b; };
    ctx.classOf = n => {
      const key = ctx.keys ? (ctx.keys.get(n.id) || n.id) : n.id;
      let c = ctx.byKey.get(key);
      if (!c) { c = ctx.uniq(n.name || n.type); ctx.byKey.set(key, c); }
      return c;
    };
    ctx.keyOf = n => (ctx.keys ? (ctx.keys.get(n.id) || n.id) : n.id);
    if (opts.links !== false) for (const l of HX.links('anim')) { const ids = l.ids.filter(id => model.exists(id)); ctx.actors.set(ids[0], l); ids.slice(1).forEach(id => ctx.skip.add(id)); }
    ctx.url = id => {
      const a = S.doc.assets[id];
      if (!a) return '';
      if (!ctx.assets) return a.data;
      if (!ctx.assets.has(id)) {
        const mt = /^data:(image|video|audio)\/([\w+.-]+)/.exec(a.data) || [];
        const kind = mt[1] || 'image';
        const EXT = { jpeg: 'jpg', 'svg+xml': 'svg', quicktime: 'mov', 'x-matroska': 'mkv', 'x-msvideo': 'avi', 'x-wav': 'wav', wave: 'wav', 'x-m4a': 'm4a', 'x-flac': 'flac', mpeg: kind === 'audio' ? 'mp3' : 'mpg' };
        const ext = EXT[mt[2]] || mt[2] || 'png';
        ctx.assets.set(id, { path: (kind === 'image' ? 'images/' : 'media/') + HX.slug(a.name || kind) + '-' + String(id).slice(-5) + '.' + ext, data: a.data });
      }
      return ctx.assets.get(id).path;
    };
    return ctx;
  };
  const emitter = ctx => {
    const rule = (name, lines) => { const m = ctx.rules.get(name) || new Map(); for (const [k, v] of decl(lines)) m.set(k, v); ctx.rules.set(name, m); };
    const svgMarkup = n => {
      let { svg, bounds } = O.render.svg([n], {});
      if (ctx.assets) for (const id of Object.keys(S.doc.assets)) { const a = S.doc.assets[id]; if (a && a.data && svg.includes(a.data)) svg = svg.split(a.data).join(ctx.url(id)); }
      return { svg: svg.replace(/width="[^"]*" height="[^"]*"/, 'width="100%" height="100%"'), bounds };
    };
    const animate = (el, n, name, container, box) => {
      const link = ctx.actors.get(n.id);
      if (!link) return;
      const a = HX.animFor(link, n, container, box);
      ctx.kf.push(a.keyframes);
      const m = ctx.rules.get(name) || new Map();
      m.set('transform-origin', '50% 50%');
      m.set('will-change', 'transform, opacity');
      const tr = link.trigger || 'load';
      if (tr === 'load') m.set('animation', a.anim);
      else if (tr === 'hover') { m.set('animation', a.anim); m.set('animation-play-state', 'paused'); ctx.extra.push(`.${name}:hover { animation-play-state: running; }`); }
      else { ctx.extra.push(`.${name}.obrys-play { animation: ${a.anim}; }`); el.attrs = (el.attrs || '') + ` data-obrys-trigger="${tr}"`; ctx.script = true; }
      ctx.extra.push(`@media (prefers-reduced-motion: reduce) { .${name}, .${name}.obrys-play { animation: none !important; } }`);
      ctx.rules.set(name, m);
    };
    // n relative to its container (container-local coordinates)
    const emit = (n, container, inFlex) => {
      if (n.visible === false || ctx.skip.has(n.id)) return [];
      const key = ctx.keyOf(n);
      const rel = M.mul(M.inv(model.containerMatrix(container)), model.worldMatrix(n));
      const d = M.decompose(rel);
      const lb = model.localBounds(n);
      const actor = ctx.actors.has(n.id);
      const pos = (w, h, extra) => {
        let lines;
        if (inFlex) lines = ['position: relative', 'flex: none'];
        else if (actor) {
          // actors rotate around their centre so the keyframes can transform them
          const c = M.apply(rel, { x: lb.x + lb.w / 2, y: lb.y + lb.h / 2 });
          const bw = w === null ? lb.w : w, bh = h === null ? lb.h : h;
          lines = ['position: absolute', `left: ${px(c.x - bw / 2)}`, `top: ${px(c.y - bh / 2)}`];
          if (w === null) lines.push(`width: ${px(lb.w)}`);
          if (Math.abs(d.rot) > 1e-6) lines.push(`transform: rotate(${num(O.deg(d.rot))}deg)`);
        } else lines = ['position: absolute', `left: ${px(d.tx + lb.x)}`, `top: ${px(d.ty + lb.y)}`];
        if (w !== null) lines.push(`width: ${px(w)}`);
        if (h !== null) lines.push(`height: ${px(h)}`);
        if (!inFlex && !actor && Math.abs(d.rot) > 1e-6) lines.push(`transform: rotate(${num(O.deg(d.rot))}deg)`, `transform-origin: ${px(-lb.x)} ${px(-lb.y)}`);
        return lines.concat(extra || []);
      };
      const opacityBlend = [n.opacity !== undefined && n.opacity < 1 ? `opacity: ${num(n.opacity)}` : '', n.blend && n.blend !== 'normal' ? `mix-blend-mode: ${n.blend}` : ''];
      const fallbackSVG = () => {
        const { svg, bounds } = svgMarkup(n);
        const cb = (!model.isPage(container) && model.worldBounds(container)) || { x: 0, y: 0 };
        const name = ctx.classOf(n);
        const lines = inFlex ? ['position: relative', 'flex: none', `width: ${px(bounds.w)}`, `height: ${px(bounds.h)}`] : ['position: absolute', `left: ${px(bounds.x - cb.x)}`, `top: ${px(bounds.y - cb.y)}`, `width: ${px(bounds.w)}`, `height: ${px(bounds.h)}`];
        rule(name, lines.concat(['line-height: 0']));
        const el = { key, tag: 'div', cls: name, attrs: ' aria-hidden="true"', html: svg, content: true };
        animate(el, n, name, container, true);
        return [el];
      };
      const groupLike = n.type === 'group' && !n.mask && (n.opacity === undefined || n.opacity >= 1) && !(n.effects || []).length && (!n.blend || n.blend === 'normal') && !actor;
      if (groupLike && !inFlex) return n.children.reduce((a, c) => a.concat(emit(c, container, false)), []);
      if (!simpleBox(rel) || n.mask || ['path', 'polygon', 'star', 'bool', 'instance', 'group'].includes(n.type) || (n.type === 'text' && n.path)) return fallbackSVG();
      const name = ctx.classOf(n);
      if (n.type === 'text') {
        const fill = (n.fills || []).find(f => f.visible !== false);
        const fam = String(n.font || 'Arial');
        ctx.fonts.add(fam);
        const fx = effectsCSS(n, true);
        const lines = pos(n.width === null || n.width === undefined ? null : n.width, null, [
          'margin: 0', `font-family: "${fam}", ${/serif/i.test(fam) && !/sans/i.test(fam) ? 'serif' : 'sans-serif'}`, `font-size: ${px(n.size)}`, `font-weight: ${n.weight || 400}`,
          n.italic ? 'font-style: italic' : '', `line-height: ${n.lh ? px(n.size * n.lh) : 'normal'}`, n.ls ? `letter-spacing: ${px(n.ls)}` : '',
          n.align && n.align !== 'left' ? `text-align: ${n.align}` : '', n.deco && n.deco !== 'none' ? `text-decoration: ${n.deco}` : '',
          n.tcase && n.tcase !== 'none' ? `text-transform: ${{ upper: 'uppercase', lower: 'lowercase', title: 'capitalize' }[n.tcase]}` : '',
          `white-space: ${n.width === null || n.width === undefined ? 'pre' : 'pre-wrap'}`
        ]);
        if (fill && fill.type === 'solid') lines.push(`color: ${rgba(fill.color, fill.opacity === undefined ? 1 : fill.opacity)}`);
        else if (fill) { const pc = paintCSS(fill, n, ctx.url); if (pc) lines.push(`background: ${pc.layer}`, '-webkit-background-clip: text', 'background-clip: text', 'color: transparent'); }
        rule(name, lines.concat(fx.lines, opacityBlend));
        const tag = n.size >= 40 ? 'h1' : n.size >= 28 ? 'h2' : n.size >= 20 ? 'h3' : 'p';
        const el = { key, tag, cls: name, html: esc(n.text), content: true };
        animate(el, n, name, container, false);
        return [el];
      }
      const fills = (n.fills || []).filter(f => f.visible !== false);
      const layers = fills.slice().reverse().map(p => paintCSS(p, n, ctx.url)).filter(Boolean);
      const fx = effectsCSS(n, false);
      const shadows = fx.shadows.concat(strokeShadows(n));
      const box = [];
      if (layers.length === 1 && fills[0].type === 'solid') box.push(`background: ${layers[0].color}`);
      else if (layers.length) box.push(`background: ${layers.map(l => l.layer).join(', ')}`);
      box.push(radiusCSS(n));
      if (shadows.length) box.push(`box-shadow: ${shadows.join(', ')}`);
      const dash = (n.dash || []).length && (n.strokes || []).some(s => s.visible !== false);
      if (dash) { const s0 = n.strokes.find(s => s.visible !== false); box.push(`outline: ${px(n.sw)} dashed ${rgba(O.paintColor(s0), s0.opacity === undefined ? 1 : s0.opacity)}`, `outline-offset: ${px(-n.sw)}`); }
      box.push(...fx.lines, ...opacityBlend);
      if (n.type === 'raster') {
        rule(name, pos(n.w, n.h, box.concat(['object-fit: fill', 'display: block'])));
        const el = { key, tag: 'img', cls: name, attrs: ` src="${esc(n.asset ? ctx.url(n.asset) : '')}" alt="${esc(n.name)}"`, void: true, html: String(n.asset), content: true };
        animate(el, n, name, container, false);
        return [el];
      }
      if (n.type === 'video' || n.type === 'audio' || n.media) {
        const media = O.media && O.media.htmlFor ? O.media.htmlFor(n, ctx) : null;
        if (media) { rule(name, pos(n.w, n.h, box.concat(media.css || []))); const el = Object.assign({ key, cls: name, content: true }, media.el); animate(el, n, name, container, false); return [el]; }
      }
      if (n.type === 'frame') {
        const L = n.layout;
        const lines = pos(n.w, n.h, box.concat([n.clip ? 'overflow: hidden' : '']));
        if (L) {
          lines.push('display: flex', `flex-direction: ${L.dir === 'v' ? 'column' : 'row'}`, `gap: ${px(L.gap || 0)}`, `padding: ${(L.pad || [0, 0, 0, 0]).map(px).join(' ')}`, 'box-sizing: border-box',
            `align-items: ${{ start: 'flex-start', center: 'center', end: 'flex-end' }[L.align] || 'flex-start'}`, `justify-content: ${{ start: 'flex-start', center: 'center', end: 'flex-end', between: 'space-between' }[L.justify] || 'flex-start'}`);
        }
        rule(name, lines);
        const el = { key, tag: n.component ? 'div' : 'div', cls: name, children: emitAll(n.children, n, !!L) };
        if (O.proto && O.proto.linkAttrs) el.attrs = O.proto.linkAttrs(n, ctx) || '';
        animate(el, n, name, container, false);
        return [el];
      }
      rule(name, pos(n.w, n.h, box));
      const el = { key, tag: 'div', cls: name, html: '' };
      if (O.proto && O.proto.linkAttrs) el.attrs = O.proto.linkAttrs(n, ctx) || '';
      animate(el, n, name, container, false);
      return [el];
    };
    const emitAll = (list, container, inFlex) => list.reduce((a, c) => a.concat(emit(c, container, inFlex)), []);
    return { rule, emit, emitAll };
  };
  // root block of a frame (page background, size, auto layout)
  const rootLines = (f, ctx) => {
    const L = f.layout;
    const fills = (f.fills || []).filter(p => p.visible !== false);
    const layers = fills.slice().reverse().map(p => paintCSS(p, f, ctx.url)).filter(Boolean);
    const fx = effectsCSS(f, false);
    const lines = ['position: relative', `width: ${px(f.w)}`, `height: ${px(f.h)}`, f.clip ? 'overflow: hidden' : '', radiusCSS(f)];
    if (layers.length === 1 && fills[0].type === 'solid') lines.push(`background: ${layers[0].color}`);
    else if (layers.length) lines.push(`background: ${layers.map(l => l.layer).join(', ')}`);
    const shadows = fx.shadows.concat(strokeShadows(f));
    if (shadows.length) lines.push(`box-shadow: ${shadows.join(', ')}`);
    if (L) lines.push('display: flex', `flex-direction: ${L.dir === 'v' ? 'column' : 'row'}`, `gap: ${px(L.gap || 0)}`, `padding: ${(L.pad || [0, 0, 0, 0]).map(px).join(' ')}`, 'box-sizing: border-box');
    return lines;
  };
  const toHTML = (el, depth) => {
    const pad = '  '.repeat(depth);
    const open = `<${el.tag}${el.cls ? ` class="${el.cls}"` : ''}${el.attrs || ''}>`;
    if (el.void) return pad + open + '\n';
    if (el.children && el.children.length) return `${pad}${open}\n${el.children.map(c => toHTML(c, depth + 1)).join('')}${pad}</${el.tag}>\n`;
    return `${pad}${open}${el.inner !== undefined ? el.inner : (el.html || '')}</${el.tag}>\n`;
  };
  const FIT = `function obrysFit() {
    document.querySelectorAll('[data-obrys-fit]').forEach(function (m) {
      m.style.zoom = '';
      var w = parseFloat(getComputedStyle(m).width) || m.offsetWidth;
      var k = (window.innerWidth - (m.hasAttribute('data-obrys-pad') ? 32 : 0)) / w;
      if (!m.hasAttribute('data-obrys-up')) k = Math.min(1, k);
      if (Math.abs(k - 1) > 0.001) m.style.zoom = k;
    });
  }
  window.addEventListener('resize', obrysFit); obrysFit();`;
  const TRIGGERS = `document.querySelectorAll('[data-obrys-trigger]').forEach(function (el) {
    var tr = el.getAttribute('data-obrys-trigger');
    function play() { el.classList.remove('obrys-play'); void el.offsetWidth; el.classList.add('obrys-play'); }
    if (tr === 'click') { el.style.cursor = 'pointer'; el.addEventListener('click', play); }
    if (tr === 'scroll') { if ('IntersectionObserver' in window) new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) play(); }); }, { threshold: 0.3 }).observe(el); else play(); }
  });`;
  const fontLinks = ctx => {
    const fams = Array.from(ctx.fonts);
    if (O.fonts) { const u = O.fonts.cssURLs(fams); return u ? `<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n<link rel="stylesheet" href="${esc(u)}">\n` : ''; }
    return '';
  };
  const customFonts = ctx => (S.doc.fonts || []).filter(f => ctx.fonts.has(f.family)).map(f => `@font-face { font-family: "${f.family.replace(/"/g, '')}"; src: url(${f.data}); }`).join('\n');
  const assemble = (ctx, roots, o) => {
    const extraCSS = (ctx.extra.length ? '\n' + Array.from(new Set(ctx.extra)).join('\n') + '\n' : '') + (ctx.kf.length ? '\n' + Array.from(new Set(ctx.kf)).join('\n') : '');
    const css = [o.base, customFonts(ctx), o.rulesCSS, extraCSS].filter(Boolean).join('\n') + '\n';
    const scripts = [o.fit ? FIT : '', ctx.script ? TRIGGERS : '', (o.scripts || []).join('\n')].filter(Boolean).join('\n  ');
    const head = `<!doctype html>\n<html lang="${O.lang}">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>${esc(o.title)}</title>\n${o.meta || ''}${fontLinks(ctx)}`;
    const body = roots.map(r => toHTML(r, 1)).join('');
    const tail = scripts ? `<script>\n  ${scripts}\n</script>\n` : '';
    return {
      css,
      htmlLinked: `${head}<link rel="stylesheet" href="${o.cssPath || 'styles.css'}">\n</head>\n<body>\n${body}${tail}</body>\n</html>\n`,
      htmlInline: `${head}<style>\n${css}</style>\n</head>\n<body>\n${body}${tail}</body>\n</html>\n`,
      assets: ctx.assets ? Array.from(ctx.assets.values()) : []
    };
  };
  const rulesCSS = ctx => Array.from(ctx.rules).map(([c, m]) => block('.' + c, m)).join('\n');

  // ---------- separate frames ----------
  HX.build = (frames, opts = {}) => {
    const ctx = newCtx(opts);
    const E = emitter(ctx);
    const roots = frames.map(f => {
      const name = ctx.classOf(f);
      E.rule(name, rootLines(f, ctx).concat(['margin: 0 auto 40px']));
      return { tag: 'main', cls: name, attrs: ` aria-label="${esc(f.name)}"${opts.fit ? ' data-obrys-fit data-obrys-pad' : ''}`, children: E.emitAll(f.children, f, !!f.layout) };
    });
    const base = `* { box-sizing: border-box; }\nhtml, body { margin: 0; }\nbody { background: ${opts.bg || '#f3f3f5'}; padding: 40px 16px; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }\nimg { max-width: none; }\n`;
    return assemble(ctx, roots, { base, rulesCSS: rulesCSS(ctx), title: frames.length === 1 ? frames[0].name : S.doc.name, fit: opts.fit });
  };

  // ---------- HTML + CSS of any selection (Code tab) ----------
  // images are referenced as files (images/…) instead of pasting megabytes of data: URLs into the panel
  HX.snippet = (nodes, opts = {}) => {
    const ctx = newCtx({ files: opts.files !== false });
    const E = emitter(ctx);
    const roots = [];
    for (const n of nodes) {
      const parent = model.parent(n);
      if (n.type === 'frame' && (!parent || model.isPage(parent))) {
        const name = ctx.classOf(n);
        E.rule(name, rootLines(n, ctx));
        roots.push({ tag: 'section', cls: name, attrs: ` aria-label="${esc(n.name)}"`, children: E.emitAll(n.children, n, !!n.layout) });
      } else roots.push(...E.emit(n, parent, false));
    }
    const extra = (ctx.extra.length ? '\n' + Array.from(new Set(ctx.extra)).join('\n') : '') + (ctx.kf.length ? '\n' + Array.from(new Set(ctx.kf)).join('\n') : '');
    const css = rulesCSS(ctx) + extra;
    const html = roots.map(r => toHTML(r, 0)).join('');
    return { html, css, fonts: fontLinks(ctx), assets: ctx.assets ? Array.from(ctx.assets.values()) : [] };
  };

  // a standalone page for any objects (loose shapes too): images inside, objects moved to the top-left corner
  HX.pageHTML = (nodes, opts = {}) => {
    const list = nodes.slice(0, 200);
    const s = HX.snippet(list, { files: false });
    const loose = list.filter(n => !(n.type === 'frame' && model.isPage(model.parent(n))));
    let body = s.html;
    if (loose.length) {
      let b = null;
      for (const n of loose) b = O.R.union(b, model.boundsIn(n, n.m));
      if (b) body = `<div class="obrys-loose" data-obrys-fit style="position: relative; width: ${Math.ceil(b.w)}px; height: ${Math.ceil(b.h)}px; margin: 0 auto;">\n<div style="position: absolute; left: ${-Math.floor(b.x)}px; top: ${-Math.floor(b.y)}px;">\n${s.html}</div>\n</div>\n`;
    }
    return `<!doctype html>\n<html lang="${O.lang}">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>${esc(opts.title || (list[0] && list[0].name) || S.doc.name)}</title>\n${s.fonts}<style>\n* { box-sizing: border-box; }\nbody { margin: 0; position: relative; background: ${opts.bg || '#fff'}; }\n${s.css}\n</style>\n</head>\n<body>\n${body}${opts.fit ? `<script>\n${FIT}\n</script>\n` : ''}</body>\n</html>\n`;
  };

  // ---------- responsive site from an adaptation group ----------
  HX.deviceOf = w => (w >= 1024 ? 'Десктоп' : w >= 600 ? 'Планшет' : 'Мобільний');
  // frames widest first with the viewport range each one covers
  HX.siteLevels = link => {
    const frames = link.ids.map(model.get).filter(f => f && f.type === 'frame').sort((a, b) => b.w - a.w);
    const mins = frames.map((f, i) => {
      const custom = link.mins && link.mins[f.id];
      if (custom !== undefined && custom !== null && custom !== '' && isFinite(+custom)) return Math.max(0, Math.round(+custom));
      if (i === frames.length - 1) return 0;
      if (f.w >= 1024 && frames[i + 1].w < 1024) return 1024;
      return Math.round(f.w);
    });
    for (let i = 1; i < mins.length; i++) if (mins[i] >= mins[i - 1]) mins[i] = Math.max(0, mins[i - 1] - 1);
    return frames.map((f, i) => ({ f, min: mins[i], max: i === 0 ? Infinity : mins[i - 1] - 1 }));
  };
  HX.rangeLabel = lv => (lv.max === Infinity ? (lv.min > 0 ? `≥ ${lv.min} px` : t('усі ширини')) : lv.min > 0 ? `${lv.min}–${lv.max} px` : `≤ ${lv.max} px`);
  // layer path inside a frame: names from the frame down ("header/logo"), repeated names get #2, #3…
  const pathKeys = root => {
    const map = new Map([[root.id, '/']]);
    const walk = (list, prefix) => {
      const seen = new Map();
      for (const c of list) {
        const nm = String(c.name || c.type).trim().toLowerCase();
        const k = (seen.get(nm) || 0) + 1;
        seen.set(nm, k);
        const key = prefix + '/' + nm + (k > 1 ? '#' + k : '');
        map.set(c.id, key);
        if (c.children && c.type !== 'bool' && c.type !== 'instance') walk(c.children, key);
      }
    };
    walk(root.children, '');
    return map;
  };
  const cloneEl = el => Object.assign({}, el, { children: el.children ? el.children.map(cloneEl) : undefined });
  const indexTree = (list, map = new Map(), parent = null) => { for (const el of list) { map.set(el.key, { el, parent }); if (el.children) indexTree(el.children, map, el); } return map; };
  // add the elements of another breakpoint that the base tree does not have, next to their siblings
  const mergeInto = (base, other) => {
    const idx = indexTree(base);
    const walk = (list, target) => {
      let prevKey = null;
      for (const el of list) {
        const hit = idx.get(el.key);
        if (hit) { if (el.children && el.children.length) walk(el.children, hit.el.children || (hit.el.children = [])); prevKey = el.key; continue; }
        const copy = cloneEl(el);
        const at = prevKey ? target.findIndex(x => x.key === prevKey) : -1;
        if (at >= 0) target.splice(at + 1, 0, copy); else if (prevKey === null) target.unshift(copy); else target.push(copy);
        indexTree([copy], idx);
        prevKey = el.key;
      }
    };
    walk(other, base);
  };
  HX.buildSite = (link, opts = {}) => {
    const levels = HX.siteLevels(link);
    if (!levels.length) throw new Error(t('У групі немає фреймів'));
    const ctx = newCtx(opts);
    const E = emitter(ctx);
    ctx.byKey.set('/', 'site');
    const per = levels.map(lv => {
      ctx.keys = pathKeys(lv.f);
      ctx.rules = new Map();
      E.rule('site', rootLines(lv.f, ctx).concat(['margin: 0 auto']));
      const tree = E.emitAll(lv.f.children, lv.f, !!lv.f.layout);
      return { lv, rules: ctx.rules, tree };
    });
    // same layer path but different content (text, vectors) → a separate element per breakpoint
    const baseIdx = indexTree(per[0].tree);
    per.slice(1).forEach((p, i) => {
      const walk = list => list.forEach(el => {
        const b = baseIdx.get(el.key);
        if (b && el.content && (b.el.html !== el.html || b.el.tag !== el.tag)) {
          const nc = el.cls + '-v' + (i + 2);
          if (p.rules.has(el.cls)) { p.rules.set(nc, p.rules.get(el.cls)); p.rules.delete(el.cls); }
          el.cls = nc; el.key = el.key + '@' + (i + 1);
        }
        if (el.children) walk(el.children);
      });
      walk(p.tree);
    });
    const tree = per[0].tree;
    per.slice(1).forEach(p => mergeInto(tree, p.tree));
    // cascade: base rules, then one @media block per narrower frame with only the differences
    const classes = [];
    per.forEach(p => p.rules.forEach((_, c) => { if (!classes.includes(c)) classes.push(c); }));
    const eff = new Map();
    let css = `/* ${t(HX.deviceOf(levels[0].f.w))} — «${levels[0].f.name}», ${HX.rangeLabel(levels[0])} */\n`;
    for (const c of classes) {
      const d = per[0].rules.get(c);
      const m = d ? new Map(d) : new Map([['display', 'none']]);
      eff.set(c, m);
      css += block('.' + c, m);
    }
    for (let i = 1; i < per.length; i++) {
      let inner = '';
      for (const c of classes) {
        const prev = eff.get(c), d = per[i].rules.get(c);
        const out = new Map();
        if (d) {
          const wasHidden = prev.get('display') === 'none';
          for (const [k, v] of d) if (prev.get(k) !== v) out.set(k, v);
          for (const [k] of prev) if (!d.has(k) && k !== 'display' && !KEEP.has(k)) out.set(k, RESET[k] || 'unset');
          const next = new Map(d);
          for (const k of KEEP) if (prev.has(k) && !next.has(k)) next.set(k, prev.get(k));
          if (wasHidden) { const disp = d.get('display') || 'block'; out.set('display', disp); next.set('display', disp); }
          eff.set(c, next);
        } else if (prev.get('display') !== 'none') { out.set('display', 'none'); eff.set(c, new Map([['display', 'none']])); }
        inner += block('.' + c, out, '  ');
      }
      const lv = per[i].lv;
      css += `\n/* ${t(HX.deviceOf(lv.f.w))} — «${lv.f.name}», ${HX.rangeLabel(lv)} */\n@media (max-width: ${per[i - 1].lv.min - 1}px) {\n${inner}}\n`;
    }
    const bgFill = (levels[0].f.fills || []).find(p => p.visible !== false && p.type === 'solid');
    const base = `* { box-sizing: border-box; }\nhtml, body { margin: 0; }\nbody { background: ${bgFill ? rgba(bgFill.color, 1) : '#ffffff'}; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; overflow-x: hidden; }\nimg { max-width: none; }\n.site { margin: 0 auto; }\n`;
    const root = { tag: 'div', cls: 'site', attrs: ` data-obrys-fit${opts.scaleUp ? ' data-obrys-up' : ''}`, children: tree };
    const res = assemble(ctx, [root], { base, rulesCSS: css, title: link.name || S.doc.name, fit: opts.fit !== false, cssPath: opts.cssPath });
    res.levels = levels;
    return res;
  };

  // ---------- targets, preview, export ----------
  const targets = () => {
    const sel = O.topSel().filter(n => n.type === 'frame');
    if (sel.length) return sel;
    return model.page().children.filter(n => n.type === 'frame' && n.visible !== false);
  };
  // adaptation groups touching these frames (or all groups on the page)
  HX.groupsFor = frames => {
    const all = HX.links('adapt');
    const ids = new Set(frames.map(f => f.id));
    const hit = all.filter(l => l.ids.some(id => ids.has(id)));
    return hit.length ? hit : all.filter(l => l.ids.some(id => { const n = model.get(id); return n && model.pageOf(n) === model.page(); }));
  };
  // preview window with device widths
  HX.previewHTML = (html, opts = {}) => {
    const w = window.open('', '_blank');
    if (!w) { O.download(new Blob([html], { type: 'text/html' }), 'index.html'); return O.toast('Спливне вікно заблоковано. Завантажено index.html.'); }
    const sizes = opts.sizes || [['Десктоп', 1440], ['Ноутбук', 1280], ['Планшет', 768], ['Мобільний', 390], ['Малий', 360]];
    w.document.open();
    w.document.write(`<!doctype html><html lang="${O.lang}"><head><meta charset="utf-8"><title>${esc(opts.title || t('Перегляд'))}</title><style>
      html, body { margin: 0; height: 100%; } body { font: 13px system-ui, sans-serif; background: #2b2b31; color: #eee; display: flex; flex-direction: column; }
      .bar { display: flex; gap: 6px; align-items: center; padding: 8px 12px; background: #1e1e24; flex-wrap: wrap; }
      .bar button { background: #34343c; color: #eee; border: 0; border-radius: 6px; padding: 6px 10px; cursor: pointer; font: inherit; }
      .bar button.on { background: #0d99ff; color: #fff; } .bar .w { margin-left: auto; color: #aaa; }
      .wrap { flex: 1; overflow: auto; display: flex; justify-content: center; padding: 16px; min-height: 0; }
      iframe { border: 0; background: #fff; height: 100%; width: 100%; box-shadow: 0 4px 24px rgba(0,0,0,.4); transition: width .2s; flex: none; max-width: 100%; }
    </style></head><body><div class="bar"><button type="button" data-w="0" class="on">${esc(t('На всю ширину'))}</button>${sizes.map(([l, v]) => `<button type="button" data-w="${v}">${esc(t(l))} · ${v}</button>`).join('')}<span class="w"></span></div><div class="wrap"><iframe title="preview"></iframe></div></body></html>`);
    w.document.close();
    const fr = w.document.querySelector('iframe');
    fr.srcdoc = html;
    const bar = w.document.querySelector('.bar');
    const lab = w.document.querySelector('.w');
    const set = v => { fr.style.width = v ? v + 'px' : '100%'; fr.style.maxWidth = v ? 'none' : '100%'; bar.querySelectorAll('button').forEach(b => b.classList.toggle('on', +b.dataset.w === v)); setTimeout(() => { lab.textContent = Math.round(fr.getBoundingClientRect().width) + ' px'; }, 250); };
    bar.addEventListener('click', e => { const b = e.target.closest('[data-w]'); if (b) set(+b.dataset.w); });
    set(0);
    return w;
  };
  HX.preview = () => {
    const frames = targets();
    const groups = HX.groupsFor(frames);
    if (groups.length) return HX.previewHTML(HX.buildSite(groups[0], {}).htmlInline, { title: groups[0].name });
    if (!frames.length) return O.toast('Виділіть фрейм (або додайте фрейми на сторінку), щоб перетворити дизайн на HTML');
    HX.previewHTML(HX.build(frames, { fit: true }).htmlInline, { title: S.doc.name });
  };
  const assetFiles = list => list.map(a => ({ name: a.path, blob: O.dataToBlob(a.data) }));
  // whole site: every adaptation group becomes a page (index.html first), shared images folder
  HX.siteFiles = (groups, opts = {}) => {
    const files = [];
    const names = new Set();
    const assets = new Map();
    groups.forEach((g, i) => {
      let base = i === 0 ? 'index' : HX.slug(g.name || ('page-' + (i + 1)));
      while (names.has(base)) base += '-2';
      names.add(base);
      const res = HX.buildSite(g, { files: true, fit: opts.fit, scaleUp: opts.scaleUp, cssPath: 'css/' + base + '.css' });
      files.push({ name: base + '.html', blob: new Blob([res.htmlLinked], { type: 'text/html' }) }, { name: 'css/' + base + '.css', blob: new Blob([res.css], { type: 'text/css' }) });
      res.assets.forEach(a => assets.set(a.path, a));
    });
    return files.concat(assetFiles(Array.from(assets.values())));
  };
  HX.exportDialog = (frames) => {
    frames = (frames && frames.length ? frames : targets()).filter(f => f && f.type === 'frame');
    const groups = HX.groupsFor(frames);
    if (!frames.length && !groups.length) return O.toast('Виділіть фрейм (або додайте фрейми на сторінку), щоб перетворити дизайн на HTML');
    const allGroups = HX.links('adapt');
    const info = groups.length
      ? t('Адаптивний сайт: {n} груп(и) фреймів, з’єднаних «Пером адаптації». Найширший фрейм — основа, вужчі стають медіазапитами @media.', { n: allGroups.length })
      : t('Фреймів для експорту: {n}. Автолейаут стане flexbox, прямокутники й текст — HTML-елементами з CSS, складні вектори — вбудованим SVG.', { n: frames.length });
    O.ui.dialog({
      title: 'Експорт HTML/CSS',
      body: `<div class="dlg-text">${esc(info)}</div>`,
      fields: [
        groups.length ? { key: 'what', label: 'Що експортувати', type: 'select', value: 'site', options: [['site', 'Адаптивний сайт (усі групи)'], ['frames', 'Окремі фрейми']] } : null,
        { key: 'mode', label: 'Файли', type: 'select', value: O.ls.get('htmlMode', 'zip'), options: [['zip', 'ZIP: HTML + CSS + зображення'], ['single', 'Один файл index.html (усе всередині)']] },
        { key: 'fit', label: 'Підлаштовувати під ширину екрана', type: 'checkbox', value: true },
        { key: 'up', label: 'Також збільшувати на широких екранах', type: 'checkbox', value: false }
      ].filter(Boolean),
      buttons: [{ id: 'preview', label: 'Переглянути' }, { id: 'ok', label: 'Експортувати', primary: true }],
      onOk: async (v, btn) => {
        O.ls.set('htmlMode', v.mode);
        const site = groups.length && v.what !== 'frames';
        if (btn === 'preview') {
          if (site) HX.previewHTML(HX.buildSite(groups[0], { fit: v.fit, scaleUp: v.up }).htmlInline, { title: groups[0].name });
          else HX.previewHTML(HX.build(frames, { fit: v.fit }).htmlInline, { title: S.doc.name });
          return;
        }
        const nm = String(S.doc.name || 'site').replace(/[\\/:*?"<>|]+/g, '_');
        if (site) {
          if (v.mode === 'single') O.download(new Blob([HX.buildSite(groups[0], { fit: v.fit, scaleUp: v.up }).htmlInline], { type: 'text/html' }), 'index.html');
          else O.download(await O.io.zip(HX.siteFiles(allGroups, { fit: v.fit, scaleUp: v.up })), nm + ' — HTML.zip');
        } else {
          if (v.mode === 'single') O.download(new Blob([HX.build(frames, { fit: v.fit }).htmlInline], { type: 'text/html' }), 'index.html');
          else {
            const res = HX.build(frames, { fit: v.fit, files: true });
            O.download(await O.io.zip([{ name: 'index.html', blob: new Blob([res.htmlLinked], { type: 'text/html' }) }, { name: 'styles.css', blob: new Blob([res.css], { type: 'text/css' }) }].concat(assetFiles(res.assets))), nm + ' — HTML.zip');
          }
        }
        O.toast('HTML/CSS експортовано');
      }
    });
  };
  HX.copyHTML = async () => {
    const frames = targets();
    const groups = HX.groupsFor(frames);
    if (!frames.length && !groups.length) return O.toast('Виділіть фрейм (або додайте фрейми на сторінку), щоб перетворити дизайн на HTML');
    await O.copyText(groups.length ? HX.buildSite(groups[0], {}).htmlInline : HX.build(frames, {}).htmlInline);
    O.toast('HTML скопійовано');
  };
  O.cmd('exportHTML', 'Експорт HTML/CSS…', () => HX.exportDialog(), { keys: ['Ctrl+Alt+H'], group: 'Файл' });
  O.cmd('previewHTML', 'Переглянути як вебсторінку', () => HX.preview(), { group: 'Файл' });
  O.cmd('copyHTML', 'Копіювати як HTML', () => HX.copyHTML(), { group: 'Файл' });
  const fileMenu = O.MENUS.find(m => m[0] === 'Файл')[1];
  fileMenu.splice(fileMenu.indexOf('exportDialog') + 1, 0, 'exportHTML', 'previewHTML');
  fileMenu.splice(fileMenu.indexOf('copySVG') + 1, 0, 'copyHTML');
})();
